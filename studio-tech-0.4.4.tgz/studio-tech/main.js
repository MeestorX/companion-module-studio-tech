import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual" },
    ...discoveredDevices.map((d) => ({
      id: d.ip,
      label: `Model ${d.model} (${d.ip})`
    }))
  ];
  return [
    // ── Device discovery dropdown ────────────────────────────────────────
    // Mirrors the bonjour-device field: selecting a device populates the
    // host automatically; selecting 'Manual' shows the textinput below.
    {
      type: "dropdown",
      id: "discoveredHost",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies Dante device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry ──────────────────────────────────────────────────
    // Only visible when discoveredHost is '' (Manual selected).
    // Matches the pattern from the bonjour-device docs.
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Model selector ───────────────────────────────────────────────────
    // Only visible when Manual mode is selected (no discovered device).
    // When a discovered device is selected, the model is auto-detected.
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Select which Studio Technologies model is active for actions and Get All Settings"
    }
  ];
}
function resolveHost(config) {
  return config.discoveredHost || config.host;
}
function resolveModel(config, discoveredDevices) {
  if (config.discoveredHost) {
    const device = discoveredDevices.find((d) => d.ip === config.discoveredHost);
    logger.debug(`resolveModel: discoveredHost="${config.discoveredHost}", found device: ${device?.model ?? "none"}`);
    if (device?.model) {
      return device.model;
    }
    if (discoveredDevices.length === 0) {
      logger.warn(`resolveModel: No devices discovered, cannot determine model`);
      return "";
    }
  }
  logger.debug(`resolveModel: falling back to activeModel="${config.activeModel}"`);
  return config.activeModel;
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_BUS_GET:
      return "Get Bus Setting";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "textinput":
    case "colorpicker":
    case "static-text":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  for (const { cmd_id, id, valueBytes } of parsed) {
    let action = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (!action) {
      for (const c of candidates) {
        const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
        if (match) {
          action = structuredClone(match);
          action.name = `${match.name} (inferred from Model ${c.model})`;
          logger2.info(`Inferred setting ${toHex(id)} from Model ${c.model}`);
          break;
        }
      }
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown Setting ${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      logger2.warn(`Could not infer setting ${toHex(id)}`);
    } else {
      const opt = action.options?.[0];
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
    }
    const exists = out.cmdSchema.some((a) => a.cmd_id === action.cmd_id && a.id === action.id);
    if (!exists)
      out.cmdSchema.push(action);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("refreshAfterCommand" in jsonObj) {
      orderedObj.refreshAfterCommand = jsonObj.refreshAfterCommand;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema;
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = resolveModel(self.config, self.devices);
  logger3.info(`UpdateActions: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  if (self.stController.isDeviceAuthorized(self.host)) {
    wiredActions["global_getAllSettings"] = {
      name: "GLOBAL: Get All Settings (Auto-Update JSON)",
      options: [],
      callback: async () => {
        const model = activeModel;
        const ip = self.host;
        const buf = await self.stController.requestAllSettings(ip);
        let modelJson = getDeviceSchema(model);
        if (!modelJson) {
          logger3.error(`Model ${model} schema not found in cache`);
          return;
        }
        const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
        logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
        if (detectedSectioned !== null) {
          logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
          modelJson = { ...modelJson, sectioned: detectedSectioned };
        }
        const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
        logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
        const devicesFolder2 = getDevicesFolder();
        const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
        saveModelJsonPretty(schemaPath, updated);
        reloadDeviceSchemas();
        logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
      }
    };
  }
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(activeModel, cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(activeModel, ip);
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
  logger3.info(`UpdateActions: wired actions: ${Object.keys(wiredActions).length}`);
}

// dist/feedbacks.js
var logger4 = createModuleLogger("Feedbacks");
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = resolveModel(self.config, self.devices);
  logger4.info(`UpdateFeedbacks: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const busCh = feedbackEvent.options["busCh"];
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
  logger4.info(`UpdateFeedbacks: wired feedbacks: ${Object.keys(wiredFeedbacks).length}`);
}

// dist/stcontroller.js
import dgram2 from "dgram";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger5 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, _onDeviceFound, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const found = /* @__PURE__ */ new Map();
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve(Array.from(found.values()));
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger5.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger5.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      ensureMembership(srcIp).then(() => {
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger5.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      }).catch((err) => logger5.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger5.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger5.warn(`Could not join announce multicast group: ${err}`);
      }
    });
  });
}

// dist/stcontroller.js
var logger6 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks;
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  constructor() {
    logger6.info("StController initialized");
    this.pendingAcks = /* @__PURE__ */ new Map();
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger6.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger6.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger6.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger6.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger6.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger6.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger6.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    logger6.debug(`Revoked device at ${ip}`);
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    return new Promise((resolve) => {
      const key = `__probe_${ip}__`;
      let resolved = false;
      const finish = (result) => {
        if (resolved)
          return;
        resolved = true;
        this.discoveryListeners.delete(key);
        resolve(result);
      };
      this.discoveryListeners.set(key, (device) => {
        if (device.ip === ip)
          finish(device);
      });
      const timer = setTimeout(() => finish(null), timeoutMs);
      timer.unref?.();
      this.ensureMembershipFor(ip).then(async () => this.txReady).then(() => {
        const query = buildDanteInfoRequest();
        this.txSocket.send(query, this.defaultPort, ip, (err) => {
          if (err) {
            logger6.warn(`Probe to ${ip} failed: ${err.message}`);
            clearTimeout(timer);
            finish(null);
          }
        });
      }).catch((e) => {
        logger6.warn(`probeDevice setup failed for ${ip}: ${e}`);
        clearTimeout(timer);
        finish(null);
      });
    });
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger6.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(this.model, CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /** Return a snapshot of the current device state for a given IP (for feedbacks). */
  getDeviceState(deviceIp) {
    return this.deviceState.get(deviceIp) ?? /* @__PURE__ */ new Map();
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      foundDevices.push(device);
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(
        this.txSocket,
        onDeviceFound,
        // dante.ts doesn't actually use this, but kept for compatibility
        async (destIp) => this.ensureMembershipFor(destIp),
        timeoutMs
      );
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger6.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(this.model, CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger6.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    let minorStr;
    if (minor === 2) {
      minorStr = "2";
    } else if (minor < 10) {
      minorStr = minor.toString().padStart(2, "0");
    } else {
      minorStr = minor.toString();
    }
    const firmware = `${major}.${minorStr}`;
    logger6.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Ensure we've joined the multicast group on the interface that routes to destIp.
   * Option B behavior: join ONLY the interface used to reach the device.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger6.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger6.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger6.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger6.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(model, cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(model, cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && this.refreshAfterCommand && settingId !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger6.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(model, cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    if (!this.authorizedIps.has(destIp)) {
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    await this.ensureMembershipFor(destIp);
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (busCh !== void 0)
      payloadBody.push(busCh & 255);
    if (addLen)
      payloadBody.push(dataBlock.length);
    if (dataBlock.length > 0)
      payloadBody.push(...dataBlock);
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await _StController.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    const cmdName = getCommandName(cmdId);
    if (settingId !== void 0 && value !== void 0) {
      let action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
      if (!action) {
        action = this.actions.find((a) => {
          if (a.cmd_id !== cmdId)
            return false;
          const hasIdAdd = a.options?.some((opt) => opt.id === "idAdd");
          if (!hasIdAdd)
            return false;
          return settingId >= a.id && settingId < a.id + 10;
        });
      }
      let settingName = action?.name ?? "Unknown Setting";
      if (action) {
        const hasIdAdd = action.options?.some((opt) => opt.id === "idAdd");
        if (hasIdAdd && settingId !== action.id) {
          const channelOffset = settingId - action.id;
          settingName = `${settingName} Ch${channelOffset + 1}`;
        }
      }
      const valueOption = action?.options?.find((opt) => opt.id === "value");
      const choices = valueOption?.choices;
      const valueBytes = _StController.buildValueBytes(value);
      const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
      const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
      const cmdHex = toHex(cmdId);
      const idHex = toHex(settingId);
      const valHex = bytesToHex(valueBytes);
      const valDec = valueBytes.length === 1 ? valueBytes[0] : valueBytes.join(",");
      const prefix = `cmd:${cmdHex} id:${idHex} val:${valHex}`;
      const suffix = choiceLabel ? `${settingName}: ${choiceLabel} (${valDec})` : `${settingName}: ${valDec}`;
      logger6.info(`TX ${destIp} | ${prefix} | ${suffix}`);
    } else {
      logger6.info(`TX ${destIp} | ${cmdName}`);
    }
    logger6.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    await this.txReady;
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model${model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger6.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger6.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    this.logStPayload(srcIp, originalCmdId, msg, stPayload, isResponse);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload, isResponse = true) {
    const cmdName = `cmd_${toHex(cmdId)}`;
    const data = stPayload.subarray(2, stPayload.length - 1);
    const magic = stPayload[0];
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[magic:${toHex(magic)} cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    const direction = isResponse ? "RX" : "SNIFF";
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger6.info(`${direction} ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, s.id);
              this.feedbackCallback(baseFeedbackKey);
            } else {
              logger6.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger6.debug(`${direction} ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger6.warn(`${direction} ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    if (decoded) {
      logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   *
   * msg is the full packet buffer — required by the settings parsers which
   * locate the Studio-T signature themselves.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  static async buildHeader(totalLen, destIp) {
    const mac = await getMacForDestination(destIp);
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(model, destIp) {
    return this.sendAwaitAck(model, CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(model, destIp) {
    return this.sendAwaitAck(model, CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger7 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Ok);
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger7.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger7.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger7.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger7.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger7.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger7.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger7.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger7.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    logger7.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger7.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current host+model combination is authorized.
   * Called on every config change so that switching model or IP is always validated.
   *
   * Rules:
   * - discoveredHost set → device already verified by Dante, always authorize
   * - manual host → check against discovered list first; probe if unknown
   *   - discovered device at that IP with matching model → authorize
   *   - discovered device at that IP with wrong model → revoke + log error
   *   - not in discovered list → probe; authorize on match, revoke on mismatch/timeout
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.discoveredHost) {
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        try {
          await this.stController.requestAllSettings(newHost);
        } catch (e) {
          logger7.warn(`Failed to get all settings from ${newHost}: ${e}`);
        }
      }
      return;
    }
    const manualModel = this.config.activeModel;
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          try {
            await this.stController.requestAllSettings(newHost);
          } catch (e) {
            logger7.warn(`Failed to get all settings from ${newHost}: ${e}`);
          }
        }
      } else {
        logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
      }
      return;
    }
    logger7.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger7.error(`No device responded at ${newHost} \u2014 commands blocked`);
    } else if (probed.model !== manualModel) {
      logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
    } else {
      logger7.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      try {
        await this.stController.requestAllSettings(newHost);
      } catch (e) {
        logger7.warn(`Failed to get all settings from ${newHost}: ${e}`);
      }
    }
  }
  /** Loads the device JSON for the given model and pushes it to the controller. */
  syncModel(model) {
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger7.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, [], true);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    const refreshAfterCommand = schema.refreshAfterCommand ?? true;
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger7.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger7.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}, refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, preferring the discovered device selection. */
  get host() {
    return resolveHost(this.config);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0aG9zdDogc3RyaW5nXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcblx0LyoqIElQIG9mIGEgZGlzY292ZXJlZCBEYW50ZSBkZXZpY2UsIG9yICcnIHdoZW4gdGhlIHVzZXIgY2hvb3NlcyBNYW51YWwgKi9cblx0ZGlzY292ZXJlZEhvc3Q6IHN0cmluZ1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBDRU5UUkFMSVpFRCBERVZJQ0UgU0NIRU1BIENBQ0hFXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBBbGwgZGV2aWNlIEpTT04gZmlsZXMgYXJlIGxvYWRlZCBvbmNlIGludG8gbWVtb3J5IGhlcmUuIE90aGVyIG1vZHVsZXMgc2hvdWxkXG4vLyB1c2UgZ2V0RGV2aWNlc0ZvbGRlcigpLCBnZXREZXZpY2VTY2hlbWFzKCksIGFuZCBnZXREZXZpY2VTY2hlbWEoKSBpbnN0ZWFkIG9mXG4vLyByZWFkaW5nIGZpbGVzIGRpcmVjdGx5LiBDYWxsIHJlbG9hZERldmljZVNjaGVtYXMoKSBhZnRlciB3cml0aW5nIHRvIGEgZmlsZS5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuLyoqXG4gKiBEZXRlcm1pbmVzIHRoZSBjb3JyZWN0IGRldmljZXMgZm9sZGVyIHBhdGggd2l0aCBmYWxsYmFjayBzdXBwb3J0LlxuICogQ2hlY2tzIHByaW1hcnkgcGF0aCBmaXJzdCwgdGhlbiBmYWxsYmFjaywgdGhlbiB0aHJvd3MgZXJyb3IgaWYgbmVpdGhlciBleGlzdHMuXG4gKi9cbmZ1bmN0aW9uIHJlc29sdmVEZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdGNvbnN0IHByaW1hcnlQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuLi9kZXZpY2VzJylcblx0Y29uc3QgZmFsbGJhY2tQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuL2RldmljZXMnKVxuXG5cdC8vIENoZWNrIHByaW1hcnkgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhwcmltYXJ5UGF0aCkpIHtcblx0XHRsb2dnZXIuZGVidWcoYFVzaW5nIGRldmljZXMgZm9sZGVyOiAke3ByaW1hcnlQYXRofWApXG5cdFx0cmV0dXJuIHByaW1hcnlQYXRoXG5cdH1cblxuXHQvLyBDaGVjayBmYWxsYmFjayBwYXRoXG5cdGlmIChmcy5leGlzdHNTeW5jKGZhbGxiYWNrUGF0aCkpIHtcblx0XHRsb2dnZXIud2FybihgUHJpbWFyeSBkZXZpY2VzIGZvbGRlciBub3QgZm91bmQsIHVzaW5nIGZhbGxiYWNrOiAke2ZhbGxiYWNrUGF0aH1gKVxuXHRcdHJldHVybiBmYWxsYmFja1BhdGhcblx0fVxuXG5cdC8vIE5laXRoZXIgcGF0aCBleGlzdHMgLSBmYXRhbCBlcnJvclxuXHRjb25zdCBlcnJvck1zZyA9IGBEZXZpY2VzIGZvbGRlciBub3QgZm91bmQhXFxuVHJpZWQ6XFxuICAtICR7cHJpbWFyeVBhdGh9XFxuICAtICR7ZmFsbGJhY2tQYXRofVxcbk1vZHVsZSBjYW5ub3QgY29udGludWUgd2l0aG91dCBkZXZpY2Ugc2NoZW1hcy5gXG5cdGxvZ2dlci5lcnJvcihlcnJvck1zZylcblx0dGhyb3cgbmV3IEVycm9yKGVycm9yTXNnKVxufVxuXG4vLyBSZXNvbHZlIHRoZSBkZXZpY2VzIGZvbGRlciBwYXRoICh3aXRoIGV4aXN0ZW5jZSBjaGVjayBhbmQgZmFsbGJhY2spXG5jb25zdCBkZXZpY2VzRm9sZGVyID0gcmVzb2x2ZURldmljZXNGb2xkZXIoKVxuXG4vLyBJbi1tZW1vcnkgY2FjaGUgb2YgYWxsIGRldmljZSBzY2hlbWFzLCBrZXllZCBieSBtb2RlbCBudW1iZXJcbmxldCBkZXZpY2VTY2hlbWFzQ2FjaGU6IFJlY29yZDxzdHJpbmcsIGFueT4gfCBudWxsID0gbnVsbFxuXG4vKipcbiAqIFJldHVybnMgdGhlIGFic29sdXRlIHBhdGggdG8gdGhlIGRldmljZXMgZm9sZGVyLlxuICogVXNlIHRoaXMgaW5zdGVhZCBvZiByZWRlZmluaW5nIHRoZSBwYXRoIGluIGV2ZXJ5IGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdHJldHVybiBkZXZpY2VzRm9sZGVyXG59XG5cbi8qKlxuICogTG9hZHMgYWxsIGRldmljZSBKU09OIGZpbGVzIGZyb20gdGhlIGRldmljZXMgZm9sZGVyIGludG8gbWVtb3J5LlxuICogVGhpcyBzaG91bGQgb25seSBiZSBjYWxsZWQgb25jZSBhdCBpbml0aWFsaXphdGlvbiwgb3IgYWZ0ZXIgYSBmaWxlIGlzIHdyaXR0ZW4uXG4gKi9cbmZ1bmN0aW9uIGxvYWREZXZpY2VTY2hlbWFzKCk6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRjb25zdCBzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge31cblx0dHJ5IHtcblx0XHRjb25zdCBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKGRldmljZXNGb2xkZXIpLmZpbHRlcigoZikgPT4gZi5lbmRzV2l0aCgnLmpzb24nKSlcblxuXHRcdGZvciAoY29uc3QgZiBvZiBmaWxlcykge1xuXHRcdFx0Y29uc3QgZnVsbFBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgZilcblx0XHRcdGNvbnN0IGpzb24gPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCwgJ3V0ZjgnKSlcblx0XHRcdGlmIChqc29uPy5tb2RlbCkge1xuXHRcdFx0XHRzY2hlbWFzW1N0cmluZyhqc29uLm1vZGVsKV0gPSBqc29uXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBMb2FkZWQgJHtPYmplY3Qua2V5cyhzY2hlbWFzKS5sZW5ndGh9IGRldmljZSBzY2hlbWFzIGludG8gY2FjaGVgKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmVycm9yKGBGYWlsZWQgdG8gbG9hZCBkZXZpY2Ugc2NoZW1hczogJHtlfWApXG5cdH1cblx0cmV0dXJuIHNjaGVtYXNcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIHRoZSBjYWNoZS5cbiAqIEluaXRpYWxpemVzIHRoZSBjYWNoZSBvbiBmaXJzdCBjYWxsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0aWYgKCFkZXZpY2VTY2hlbWFzQ2FjaGUpIHtcblx0XHRkZXZpY2VTY2hlbWFzQ2FjaGUgPSBsb2FkRGV2aWNlU2NoZW1hcygpXG5cdH1cblx0cmV0dXJuIGRldmljZVNjaGVtYXNDYWNoZVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBzcGVjaWZpYyBkZXZpY2Ugc2NoZW1hIGJ5IG1vZGVsIG51bWJlci5cbiAqIFJldHVybnMgdW5kZWZpbmVkIGlmIHRoZSBtb2RlbCBkb2Vzbid0IGV4aXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsOiBzdHJpbmcpOiBhbnkge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBzY2hlbWFzW21vZGVsXVxufVxuXG4vKipcbiAqIFJlbG9hZHMgYWxsIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay5cbiAqIENhbGwgdGhpcyBhZnRlciB3cml0aW5nIHRvIGEgZGV2aWNlIEpTT04gZmlsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbG9hZERldmljZVNjaGVtYXMoKTogdm9pZCB7XG5cdGxvZ2dlci5pbmZvKCdSZWxvYWRpbmcgZGV2aWNlIHNjaGVtYXMgZnJvbSBkaXNrLi4uJylcblx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBsaXN0IG9mIGF2YWlsYWJsZSBtb2RlbCBudW1iZXJzLCBzb3J0ZWQuXG4gKi9cbmZ1bmN0aW9uIGxvYWRBdmFpbGFibGVNb2RlbHMoKTogc3RyaW5nW10ge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBPYmplY3Qua2V5cyhzY2hlbWFzKS5zb3J0KClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEdldENvbmZpZ0ZpZWxkcyhkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW10pOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdGNvbnN0IG1vZGVscyA9IGxvYWRBdmFpbGFibGVNb2RlbHMoKVxuXG5cdC8vIEJ1aWxkIGNob2ljZXMgbWlycm9yaW5nIHRoZSBib25qb3VyLWRldmljZSBwYXR0ZXJuOlxuXHQvLyAgIGZpcnN0IGVudHJ5IGlzIGFsd2F5cyAnTWFudWFsJyAoZW1wdHkgdmFsdWUpXG5cdC8vICAgdGhlbiBvbmUgZW50cnkgcGVyIGRpc2NvdmVyZWQgZGV2aWNlXG5cdGNvbnN0IGRldmljZUNob2ljZXMgPSBbXG5cdFx0eyBpZDogJycsIGxhYmVsOiAnTWFudWFsJyB9LFxuXHRcdC4uLmRpc2NvdmVyZWREZXZpY2VzLm1hcCgoZCkgPT4gKHtcblx0XHRcdGlkOiBkLmlwLFxuXHRcdFx0bGFiZWw6IGBNb2RlbCAke2QubW9kZWx9ICgke2QuaXB9KWAsXG5cdFx0fSkpLFxuXHRdXG5cblx0cmV0dXJuIFtcblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2aWNlIGRpc2NvdmVyeSBkcm9wZG93biBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBNaXJyb3JzIHRoZSBib25qb3VyLWRldmljZSBmaWVsZDogc2VsZWN0aW5nIGEgZGV2aWNlIHBvcHVsYXRlcyB0aGVcblx0XHQvLyBob3N0IGF1dG9tYXRpY2FsbHk7IHNlbGVjdGluZyAnTWFudWFsJyBzaG93cyB0aGUgdGV4dGlucHV0IGJlbG93LlxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2Rpc2NvdmVyZWRIb3N0Jyxcblx0XHRcdGxhYmVsOiAnRGV2aWNlJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRjaG9pY2VzOiBkZXZpY2VDaG9pY2VzLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCBhbiBhdXRvLWRpc2NvdmVyZWQgU3R1ZGlvIFRlY2hub2xvZ2llcyBEYW50ZSBkZXZpY2UsIG9yIGNob29zZSBNYW51YWwgdG8gZW50ZXIgYW4gSVAgYWRkcmVzcy4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgTWFudWFsIElQIGVudHJ5IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIE9ubHkgdmlzaWJsZSB3aGVuIGRpc2NvdmVyZWRIb3N0IGlzICcnIChNYW51YWwgc2VsZWN0ZWQpLlxuXHRcdC8vIE1hdGNoZXMgdGhlIHBhdHRlcm4gZnJvbSB0aGUgYm9uam91ci1kZXZpY2UgZG9jcy5cblx0XHR7XG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGlkOiAnaG9zdCcsXG5cdFx0XHRsYWJlbDogJ1RhcmdldCBJUCcsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0cmVnZXg6IFJlZ2V4LklQLFxuXHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogYCEkKG9wdGlvbnM6ZGlzY292ZXJlZEhvc3QpYCxcblx0XHRcdHRvb2x0aXA6ICdFbnRlciB0aGUgSVAgYWRkcmVzcyBvZiB0aGUgZGV2aWNlIG1hbnVhbGx5LicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNb2RlbCBzZWxlY3RvciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBPbmx5IHZpc2libGUgd2hlbiBNYW51YWwgbW9kZSBpcyBzZWxlY3RlZCAobm8gZGlzY292ZXJlZCBkZXZpY2UpLlxuXHRcdC8vIFdoZW4gYSBkaXNjb3ZlcmVkIGRldmljZSBpcyBzZWxlY3RlZCwgdGhlIG1vZGVsIGlzIGF1dG8tZGV0ZWN0ZWQuXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnYWN0aXZlTW9kZWwnLFxuXHRcdFx0bGFiZWw6ICdBY3RpdmUgRGV2aWNlIE1vZGVsJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogbW9kZWxzWzBdID8/ICcnLFxuXHRcdFx0Y2hvaWNlczogbW9kZWxzLm1hcCgobW9kZWwpID0+ICh7XG5cdFx0XHRcdGlkOiBtb2RlbCxcblx0XHRcdFx0bGFiZWw6IGBNb2RlbCAke21vZGVsfWAsXG5cdFx0XHR9KSksXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkaXNjb3ZlcmVkSG9zdClgLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCB3aGljaCBTdHVkaW8gVGVjaG5vbG9naWVzIG1vZGVsIGlzIGFjdGl2ZSBmb3IgYWN0aW9ucyBhbmQgR2V0IEFsbCBTZXR0aW5ncycsXG5cdFx0fSxcblx0XVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQIGZyb20gY29uZmlnIFx1MjAxNCBwcmVmZXJzIHRoZSBkaXNjb3ZlcmVkIGRldmljZVxuICogSVAgd2hlbiBvbmUgaXMgc2VsZWN0ZWQsIGZhbGxzIGJhY2sgdG8gdGhlIG1hbnVhbGx5IGVudGVyZWQgaG9zdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVIb3N0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogc3RyaW5nIHtcblx0cmV0dXJuIGNvbmZpZy5kaXNjb3ZlcmVkSG9zdCB8fCBjb25maWcuaG9zdFxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBtb2RlbCBcdTIwMTQgaWYgYSBkaXNjb3ZlcmVkIGRldmljZSBpcyBzZWxlY3RlZCwgZXh0cmFjdHNcbiAqIGl0cyBtb2RlbCBmcm9tIHRoZSBkaXNjb3ZlcmVkRGV2aWNlcyBsaXN0OyBvdGhlcndpc2UgdXNlcyBhY3RpdmVNb2RlbC5cbiAqIFJldHVybnMgZW1wdHkgc3RyaW5nIGlmIG5vIGRldmljZXMgYXJlIGRpc2NvdmVyZWQgYW5kIHVzaW5nIGRpc2NvdmVyZWRIb3N0IG1vZGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlTW9kZWwoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRpc2NvdmVyZWRIb3N0KSB7XG5cdFx0Y29uc3QgZGV2aWNlID0gZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY29uZmlnLmRpc2NvdmVyZWRIb3N0KVxuXHRcdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBkaXNjb3ZlcmVkSG9zdD1cIiR7Y29uZmlnLmRpc2NvdmVyZWRIb3N0fVwiLCBmb3VuZCBkZXZpY2U6ICR7ZGV2aWNlPy5tb2RlbCA/PyAnbm9uZSd9YClcblx0XHRpZiAoZGV2aWNlPy5tb2RlbCkge1xuXHRcdFx0cmV0dXJuIGRldmljZS5tb2RlbFxuXHRcdH1cblx0XHQvLyBJZiB1c2luZyBkaXNjb3ZlcmVkSG9zdCBtb2RlIGJ1dCBubyBkZXZpY2UgZm91bmQsIGRvbid0IGZhbGwgYmFjayB0byBhY3RpdmVNb2RlbFxuXHRcdGlmIChkaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGggPT09IDApIHtcblx0XHRcdGxvZ2dlci53YXJuKGByZXNvbHZlTW9kZWw6IE5vIGRldmljZXMgZGlzY292ZXJlZCwgY2Fubm90IGRldGVybWluZSBtb2RlbGApXG5cdFx0XHRyZXR1cm4gJydcblx0XHR9XG5cdH1cblx0bG9nZ2VyLmRlYnVnKGByZXNvbHZlTW9kZWw6IGZhbGxpbmcgYmFjayB0byBhY3RpdmVNb2RlbD1cIiR7Y29uZmlnLmFjdGl2ZU1vZGVsfVwiYClcblx0cmV0dXJuIGNvbmZpZy5hY3RpdmVNb2RlbFxufVxuIiwgImltcG9ydCB0eXBlIE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcblxuLyoqXG4gKiBEZWZpbmUgQ29tcGFuaW9uIHZhcmlhYmxlcyBmb3IgdGhpcyBtb2R1bGUuXG4gKiBWYXJpYWJsZXMgY2FuIGJlIHVzZWQgdG8gZGlzcGxheSBkeW5hbWljIHN0YXRlIGluIGJ1dHRvbiBsYWJlbHMsIHRyaWdnZXJzLCBldGMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh7XG5cdFx0bW9kZWw6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOdW1iZXInIH0sXG5cdFx0bW9kZWxOYW1lOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTmFtZSAoRnVsbCBEZXNjcmlwdGlvbiknIH0sXG5cdFx0bWFudWZhY3R1cmVyOiB7IG5hbWU6ICdEZXZpY2UgTWFudWZhY3R1cmVyJyB9LFxuXHRcdGZpcm13YXJlOiB7IG5hbWU6ICdEZXZpY2UgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRkYW50ZUZXOiB7IG5hbWU6ICdEYW50ZSBNb2R1bGUgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRtYWM6IHsgbmFtZTogJ0RldmljZSBNQUMgQWRkcmVzcycgfSxcblx0XHRpcDogeyBuYW1lOiAnRGV2aWNlIElQIEFkZHJlc3MnIH0sXG5cdH0pXG59XG5cbmNvbnN0IENMRUFSRURfVkFSSUFCTEVTID0ge1xuXHRtb2RlbDogJycsXG5cdG1vZGVsTmFtZTogJycsXG5cdG1hbnVmYWN0dXJlcjogJycsXG5cdGZpcm13YXJlOiAnJyxcblx0ZGFudGVGVzogJycsXG5cdG1hYzogJycsXG5cdGlwOiAnJyxcbn1cblxuLyoqXG4gKiBVcGRhdGUgdmFyaWFibGUgdmFsdWVzIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaW5mb3JtYXRpb24uXG4gKiBPbmx5IHBvcHVsYXRlcyB2YXJpYWJsZXMgd2hlbiB0aGUgY3VycmVudCBob3N0IGlzIGF1dGhvcml6ZWQuXG4gKiBDbGVhcnMgYWxsIHZhcmlhYmxlcyBpZiB0aGUgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkIG9yIG5vdCBmb3VuZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IGN1cnJlbnRIb3N0ID0gc2VsZi5ob3N0XG5cblx0Ly8gQ2xlYXIgdmFyaWFibGVzIGlmIG5vIGhvc3QgY29uZmlndXJlZCBvciBkZXZpY2UgaXMgbm90IGF1dGhvcml6ZWRcblx0aWYgKCFjdXJyZW50SG9zdCB8fCAhc2VsZi5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKGN1cnJlbnRIb3N0KSkge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoQ0xFQVJFRF9WQVJJQUJMRVMpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBkZXZpY2UgPSBzZWxmLmRldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY3VycmVudEhvc3QpXG5cdGlmIChkZXZpY2UpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdG1vZGVsOiBkZXZpY2UubW9kZWwgfHwgJycsXG5cdFx0XHRtb2RlbE5hbWU6IGRldmljZS5tb2RlbE5hbWUgfHwgJycsXG5cdFx0XHRtYW51ZmFjdHVyZXI6IGRldmljZS5tYW51ZmFjdHVyZXIgfHwgJycsXG5cdFx0XHRmaXJtd2FyZTogZGV2aWNlLmZpcm13YXJlTWFpbiB8fCAnJyxcblx0XHRcdGRhbnRlRlc6IGRldmljZS5kYW50ZUZpcm13YXJlIHx8ICcnLFxuXHRcdFx0bWFjOiBkZXZpY2UubWFjIHx8ICcnLFxuXHRcdFx0aXA6IGRldmljZS5pcCxcblx0XHR9KVxuXHR9IGVsc2Uge1xuXHRcdC8vIEF1dGhvcml6ZWQgYnV0IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgKG1hbnVhbCBJUCB0aGF0IHByb2JlZCBzdWNjZXNzZnVsbHkpXG5cdFx0Ly8gV2Uga25vdyBpdCdzIHRoZSByaWdodCBkZXZpY2UgYnV0IGRvbid0IGhhdmUgZnVsbCBpbmZvIHlldFxuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0Li4uQ0xFQVJFRF9WQVJJQUJMRVMsXG5cdFx0XHRpcDogY3VycmVudEhvc3QsXG5cdFx0fSlcblx0fVxufVxuIiwgImltcG9ydCB0eXBlIHsgQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG5leHBvcnQgY29uc3QgVXBncmFkZVNjcmlwdHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQ8TW9kdWxlQ29uZmlnPltdID0gW1xuXHQvKlxuXHQgKiBQbGFjZSB5b3VyIHVwZ3JhZGUgc2NyaXB0cyBoZXJlXG5cdCAqIFJlbWVtYmVyIHRoYXQgb25jZSBpdCBoYXMgYmVlbiBhZGRlZCBpdCBjYW5ub3QgYmUgcmVtb3ZlZCFcblx0ICovXG5cdC8vIGZ1bmN0aW9uIChjb250ZXh0LCBwcm9wcykge1xuXHQvLyBcdHJldHVybiB7XG5cdC8vIFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHQvLyBcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHQvLyBcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdC8vIFx0fVxuXHQvLyB9LFxuXVxuIiwgImV4cG9ydCB0eXBlIENvbXBhbmlvbklucHV0Q2hvaWNlID0ge1xuXHRpZDogc3RyaW5nIHwgbnVtYmVyXG5cdGxhYmVsOiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgRGV2aWNlU2V0dGluZyA9IHtcblx0dHlwZTogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVmYXVsdDogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhblxuXHRjaG9pY2VzPzogQ29tcGFuaW9uSW5wdXRDaG9pY2VbXVxufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBHZXQgc2V0dGluZyBmcm9tIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0JVU19TRVQgPSAweDA0IC8vIFNldCBzZXR0aW5nIG9uIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0hFQURQSE9ORSA9IDB4MDUgLy8gSGVhZHBob25lIGNvbnRyb2xzIChyZXNlcnZlZCBmb3IgZnV0dXJlIHVzZSlcbmV4cG9ydCBjb25zdCBDTURfQlVUVE9OX01PREUgPSAweDA3IC8vIEJ1dHRvbiBtb2RlIGNvbmZpZ3VyYXRpb24gKHJlc2VydmVkIGZvciBmdXR1cmUgdXNlKVxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kcyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5leHBvcnQgY29uc3QgQ01EX0dFVF9BTExfU0VUVElOR1MgPSAweDBhIC8vIFJlcXVlc3QgYWxsIGN1cnJlbnQgc2V0dGluZ3MgZnJvbSBkZXZpY2VcbmV4cG9ydCBjb25zdCBDTURfU0VUVElOR1NfUFVTSCA9IDB4MGIgLy8gVW5zb2xpY2l0ZWQgc2V0dGluZ3MgdXBkYXRlIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX0RFVl9TUEVDID0gMHgwZCAvLyBEZXZpY2Utc3BlY2lmaWMgc2V0dGluZyBnZXQvc2V0IHdpdGggQUNLXG5leHBvcnQgY29uc3QgQ01EX1JFU0VUX0RFVklDRSA9IDB4MGUgLy8gRmFjdG9yeSByZXNldCBjb21tYW5kXG5leHBvcnQgY29uc3QgQ01EX0dMT0JBTF9NSUNfS0lMTCA9IDB4MTAgLy8gRW1lcmdlbmN5IG1pYyBraWxsIChhbGwgY2hhbm5lbHMpXG5leHBvcnQgY29uc3QgQ01EX01JQ19QUkVfQlVTID0gMHgxMiAvLyBNaWMvcHJlYW1wIHNldHRpbmdzIHBlciBidXMgKGdhaW4sIHBoYW50b20sIGV0YylcbmV4cG9ydCBjb25zdCBDTURfQ0hBTk5FTCA9IDB4MTQgLy8gQ2hhbm5lbC1zcGVjaWZpYyBjb250cm9scyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBDb21tYW5kIE5hbWUgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbW1hbmROYW1lKGNtZElkOiBudW1iZXIpOiBzdHJpbmcge1xuXHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0Y2FzZSBDTURfR0VUX0ZJUk1XQVJFOlxuXHRcdFx0cmV0dXJuICdHZXQgRmlybXdhcmUgVmVyc2lvbidcblx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0cmV0dXJuICdHZXQgQnVzIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfQlVTX1NFVDpcblx0XHRcdHJldHVybiAnU2V0IEJ1cyBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0hFQURQSE9ORTpcblx0XHRcdHJldHVybiAnSGVhZHBob25lIENvbnRyb2wnXG5cdFx0Y2FzZSBDTURfQlVUVE9OX01PREU6XG5cdFx0XHRyZXR1cm4gJ0J1dHRvbiBNb2RlJ1xuXHRcdGNhc2UgQ01EX1NZU1RFTTpcblx0XHRcdHJldHVybiAnU3lzdGVtIENvbW1hbmQnXG5cdFx0Y2FzZSBDTURfR0VUX0FMTF9TRVRUSU5HUzpcblx0XHRcdHJldHVybiAnUmVxdWVzdCBBbGwgU2V0dGluZ3MnXG5cdFx0Y2FzZSBDTURfU0VUVElOR1NfUFVTSDpcblx0XHRcdHJldHVybiAnU2V0dGluZ3MgUHVzaCdcblx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzpcblx0XHRcdHJldHVybiAnTWljL1ByZSBCdXMnXG5cdFx0Y2FzZSBDTURfREVWX1NQRUM6XG5cdFx0XHRyZXR1cm4gJ0RldmljZSBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0NIQU5ORUw6XG5cdFx0XHRyZXR1cm4gJ0NoYW5uZWwgU2V0dGluZydcblx0XHRjYXNlIENNRF9SRVNFVF9ERVZJQ0U6XG5cdFx0XHRyZXR1cm4gJ1Jlc2V0IERldmljZSdcblx0XHRjYXNlIENNRF9HTE9CQUxfTUlDX0tJTEw6XG5cdFx0XHRyZXR1cm4gJ0dsb2JhbCBNaWMgS2lsbCdcblx0XHRkZWZhdWx0OlxuXHRcdFx0cmV0dXJuIGBjbWRfMHgke2NtZElkLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfWBcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSUQgR2VuZXJhdGlvbiBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENyZWF0ZXMgYSBjb25zaXN0ZW50IElEIGZvciBhY3Rpb25zLCBmZWVkYmFja3MsIGFuZCBzdGF0ZSBrZXlzLlxuICogRm9ybWF0OiBgJHttb2RlbH1fJHtjbWRfaWR9XyR7YnVzQ2h9XyR7aWR9YCBmb3IgY29tbWFuZHMgd2l0aCBidXNDaCAoZS5nLiwgXCI1MzA0XzE0XzBfMFwiKVxuICogRm9ybWF0OiBgJHttb2RlbH1fJHtjbWRfaWR9XyR7aWR9YCBmb3IgY29tbWFuZHMgd2l0aG91dCBidXNDaCAoZS5nLiwgXCI1MzA0XzEyX2RcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1ha2VTZXR0aW5nSWQoXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIgfCBzdHJpbmcsXG5cdHNldHRpbmdJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRidXNDaD86IG51bWJlciB8IHN0cmluZyxcbik6IHN0cmluZyB7XG5cdGNvbnN0IGNtZCA9IHR5cGVvZiBjbWRJZCA9PT0gJ251bWJlcicgPyBjbWRJZC50b1N0cmluZygxNikgOiBjbWRJZFxuXHRjb25zdCBpZCA9IHR5cGVvZiBzZXR0aW5nSWQgPT09ICdudW1iZXInID8gc2V0dGluZ0lkLnRvU3RyaW5nKDE2KSA6IHNldHRpbmdJZFxuXG5cdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0Y29uc3QgY2ggPSB0eXBlb2YgYnVzQ2ggPT09ICdudW1iZXInID8gYnVzQ2gudG9TdHJpbmcoMTYpIDogYnVzQ2hcblx0XHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2NofV8ke2lkfWBcblx0fVxuXG5cdHJldHVybiBgJHttb2RlbH1fJHtjbWR9XyR7aWR9YFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSGV4IEZvcm1hdHRpbmcgSGVscGVycyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogQ29udmVydHMgYSBudW1iZXIgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4IGFuZCBwYWRkaW5nLlxuICogQHBhcmFtIHZhbHVlIC0gVGhlIG51bWJlciB0byBjb252ZXJ0XG4gKiBAcGFyYW0gcGFkTGVuZ3RoIC0gTnVtYmVyIG9mIGhleCBkaWdpdHMgdG8gcGFkIHRvIChkZWZhdWx0OiAyKVxuICogQHJldHVybnMgRm9ybWF0dGVkIGhleCBzdHJpbmcgKGUuZy4sIFwiMHgwZFwiLCBcIjB4ZmZcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSGV4KHZhbHVlOiBudW1iZXIsIHBhZExlbmd0aCA9IDIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHt2YWx1ZS50b1N0cmluZygxNikucGFkU3RhcnQocGFkTGVuZ3RoLCAnMCcpfWBcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBhcnJheSBvZiBieXRlcyB0byBhIGhleCBzdHJpbmcgd2l0aCAweCBwcmVmaXguXG4gKiBAcGFyYW0gYnl0ZXMgLSBBcnJheSBvZiBieXRlcyBvciBCdWZmZXJcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGFmZjEyXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBieXRlc1RvSGV4KGJ5dGVzOiBudW1iZXJbXSB8IEJ1ZmZlcik6IHN0cmluZyB7XG5cdHJldHVybiBgMHgke0FycmF5LmZyb20oYnl0ZXMpXG5cdFx0Lm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJyl9YFxufVxuXG4vKipcbiAqIEZvcm1hdHMgUkdCIGNvbG9yIGJ5dGVzIGFzIGEgQ1NTIGhleCBjb2xvciBzdHJpbmcuXG4gKiBAcGFyYW0gciAtIFJlZCBjb21wb25lbnQgKDAtMjU1KVxuICogQHBhcmFtIGcgLSBHcmVlbiBjb21wb25lbnQgKDAtMjU1KVxuICogQHBhcmFtIGIgLSBCbHVlIGNvbXBvbmVudCAoMC0yNTUpXG4gKiBAcmV0dXJucyBDU1MgaGV4IGNvbG9yIHN0cmluZyAoZS5nLiwgXCIjRkYwMEFCXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRSZ2JDb2xvcihyOiBudW1iZXIsIGc6IG51bWJlciwgYjogbnVtYmVyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAjJHtbciwgZywgYl1cblx0XHQubWFwKCh2KSA9PiB2LnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuXHRcdC5qb2luKCcnKVxuXHRcdC50b1VwcGVyQ2FzZSgpfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIFBhcnNpbmcgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBQYXJzZXMgYSBzZXR0aW5nIElEIHN0cmluZyBpbnRvIGl0cyBjb21wb25lbnRzLlxuICogQHBhcmFtIGlkIC0gU2V0dGluZyBJRCBzdHJpbmcgKGUuZy4sIFwiMzkxX2RfMFwiIG9yIFwiNTMwNF8xNF8wXzFcIilcbiAqIEByZXR1cm5zIFBhcnNlZCBjb21wb25lbnRzIHdpdGggaGV4IHN0cmluZ3MgY29udmVydGVkIHRvIG51bWJlcnNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ0lkKGlkOiBzdHJpbmcpOiB7IG1vZGVsOiBzdHJpbmc7IGNtZElkOiBudW1iZXI7IGJhc2VJZDogbnVtYmVyIH0ge1xuXHRjb25zdCBbbW9kZWwsIGNtZElkU3RyLCBpZFN0cl0gPSBpZC5zcGxpdCgnXycpXG5cdHJldHVybiB7XG5cdFx0bW9kZWwsXG5cdFx0Y21kSWQ6IHBhcnNlSW50KGNtZElkU3RyLCAxNiksXG5cdFx0YmFzZUlkOiBwYXJzZUludChpZFN0ciwgMTYpLFxuXHR9XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBNb2RlbCBEaXN0YW5jZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENhbGN1bGF0ZXMgbnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIHR3byBtb2RlbCBudW1iZXJzLlxuICogVXNlZCBmb3IgZmluZGluZyBzaW1pbGFyIG1vZGVscyBmb3Igc2V0dGluZyBpbmZlcmVuY2UuXG4gKiBAcGFyYW0gbW9kZWxBIC0gRmlyc3QgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MVwiKVxuICogQHBhcmFtIG1vZGVsQiAtIFNlY29uZCBtb2RlbCBudW1iZXIgKGUuZy4sIFwiMzkyXCIpXG4gKiBAcmV0dXJucyBOdW1lcmljIGRpc3RhbmNlIGJldHdlZW4gbW9kZWxzLCBvciBJbmZpbml0eSBpZiBlaXRoZXIgaXMgbm9uLW51bWVyaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1vZGVsRGlzdGFuY2UobW9kZWxBOiBzdHJpbmcsIG1vZGVsQjogc3RyaW5nKTogbnVtYmVyIHtcblx0Y29uc3QgbmEgPSBwYXJzZUludChtb2RlbEEucmVwbGFjZSgvXFxEL2csICcnKSwgMTApXG5cdGNvbnN0IG5iID0gcGFyc2VJbnQobW9kZWxCLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRpZiAoTnVtYmVyLmlzTmFOKG5hKSB8fCBOdW1iZXIuaXNOYU4obmIpKSByZXR1cm4gSW5maW5pdHlcblx0cmV0dXJuIE1hdGguYWJzKG5hIC0gbmIpXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBTY2hlbWEgTm9ybWFsaXphdGlvbiBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIE5vcm1hbGl6ZXMgZGV2aWNlIHNjaGVtYXMgdG8gZW5zdXJlIGNtZFNjaGVtYSBpcyBhbHdheXMgYW4gYXJyYXkuXG4gKiBUaGlzIGhlbHBlciBlbGltaW5hdGVzIGR1cGxpY2F0ZSBzY2hlbWEgdHJhbnNmb3JtYXRpb24gY29kZS5cbiAqIEBwYXJhbSBzY2hlbWFzUmF3IC0gUmF3IHNjaGVtYXMgZnJvbSBnZXREZXZpY2VTY2hlbWFzKClcbiAqIEByZXR1cm5zIE5vcm1hbGl6ZWQgc2NoZW1hcyB3aXRoIGd1YXJhbnRlZWQgY21kU2NoZW1hIGFycmF5c1xuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoXG5cdHNjaGVtYXNSYXc6IFJlY29yZDxzdHJpbmcsIGFueT4sXG4pOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4ge1xuXHRjb25zdCBub3JtYWxpemVkOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4gPSB7fVxuXHRmb3IgKGNvbnN0IFttb2RlbCwganNvbl0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hc1JhdykpIHtcblx0XHRub3JtYWxpemVkW21vZGVsXSA9IHtcblx0XHRcdG1vZGVsOiBqc29uLm1vZGVsLFxuXHRcdFx0Y21kU2NoZW1hOiBBcnJheS5pc0FycmF5KGpzb24uY21kU2NoZW1hKSA/IGpzb24uY21kU2NoZW1hIDogW10sXG5cdFx0fVxuXHR9XG5cdHJldHVybiBub3JtYWxpemVkXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBBY3Rpb24gTG9va3VwIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogRmluZHMgYW4gYWN0aW9uL3NldHRpbmcgaW4gdGhlIHNjaGVtYSwgc3VwcG9ydGluZyBib3RoIGV4YWN0IG1hdGNoZXMgYW5kIGlkQWRkIG9mZnNldHMuXG4gKiBUaGlzIGhlbHBlciBlbGltaW5hdGVzIGR1cGxpY2F0ZSBhY3Rpb24gbG9va3VwIGxvZ2ljIGFjcm9zcyBtdWx0aXBsZSBmaWxlcy5cbiAqIEBwYXJhbSBzY2hlbWFzIC0gTm9ybWFsaXplZCBkZXZpY2Ugc2NoZW1hc1xuICogQHBhcmFtIG1vZGVsIC0gRGV2aWNlIG1vZGVsIChlLmcuLCBcIjM5MVwiKVxuICogQHBhcmFtIGNtZElkIC0gQ29tbWFuZCBJRFxuICogQHBhcmFtIHNldHRpbmdJZCAtIFNldHRpbmcgSUQgKG1heSBpbmNsdWRlIGlkQWRkIG9mZnNldClcbiAqIEByZXR1cm5zIE1hdGNoaW5nIGFjdGlvbi9zZXR0aW5nIG9yIHVuZGVmaW5lZFxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZEFjdGlvbkZvclNldHRpbmcoXG5cdHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9Pixcblx0bW9kZWw6IHN0cmluZyxcblx0Y21kSWQ6IG51bWJlcixcblx0c2V0dGluZ0lkOiBudW1iZXIsXG4pOiBhbnkge1xuXHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRpZiAoIXNjaGVtYSB8fCAhQXJyYXkuaXNBcnJheShzY2hlbWEuY21kU2NoZW1hKSkgcmV0dXJuIHVuZGVmaW5lZFxuXG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHMuY21kX2lkID09PSBjbWRJZCAmJiBzLmlkID09PSBzZXR0aW5nSWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2gsIHRyeSB0byBmaW5kIGJhc2UgYWN0aW9uIHdpdGggaWRBZGRcblx0aWYgKCFhY3Rpb24pIHtcblx0XHRhY3Rpb24gPSBzY2hlbWEuY21kU2NoZW1hLmZpbmQoKHM6IGFueSkgPT4ge1xuXHRcdFx0aWYgKHMuY21kX2lkICE9PSBjbWRJZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IHMub3B0aW9ucz8uZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgc2V0dGluZ0lkIG1hdGNoZXMgYmFzZSArIGFueSBpZEFkZCBvZmZzZXRcblx0XHRcdGNvbnN0IG9mZnNldCA9IHNldHRpbmdJZCAtIHMuaWRcblx0XHRcdHJldHVybiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KVxuXHRcdH0pXG5cdH1cblxuXHRyZXR1cm4gYWN0aW9uXG59XG4iLCAiLyoqXG4gKiBidWlsZC1jb21tYW5kcy50c1xuICogLSBVc2VzIGNlbnRyYWxpemVkIGRldmljZSBzY2hlbWEgY2FjaGUgZnJvbSBjb25maWcudHNcbiAqIC0gUHJvZHVjZXMgQ29tcGFuaW9uIGFjdGlvbiBkZWZpbml0aW9ucyBhbmQgZmVlZGJhY2tzXG4gKi9cblxuaW1wb3J0IHtcblx0Q29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMsXG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24sXG5cdENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBtYWtlU2V0dGluZ0lkIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLSBPcHRpb24gQnVpbGRlciAtLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5mdW5jdGlvbiBidWlsZE9wdGlvbihvOiBhbnkpOiBhbnkge1xuXHRjb25zdCBiYXNlID0ge1xuXHRcdHR5cGU6IG8udHlwZSxcblx0XHRpZDogby5pZCxcblx0XHRsYWJlbDogby5sYWJlbCxcblx0XHRkZWZhdWx0OiBvLmRlZmF1bHQsXG5cdFx0dG9vbHRpcDogby50b29sdGlwLFxuXHR9XG5cblx0c3dpdGNoIChvLnR5cGUpIHtcblx0XHRjYXNlICdkcm9wZG93bic6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBjaG9pY2VzOiBvLmNob2ljZXMgPz8gW10gfVxuXG5cdFx0Y2FzZSAnbnVtYmVyJzpcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdC4uLmJhc2UsXG5cdFx0XHRcdG1pbjogby5taW4sXG5cdFx0XHRcdG1heDogby5tYXgsXG5cdFx0XHRcdHN0ZXA6IG8uc3RlcCA/PyAxLFxuXHRcdFx0XHRyYW5nZTogdHJ1ZSxcblx0XHRcdH1cblxuXHRcdGNhc2UgJ2NoZWNrYm94Jzpcblx0XHRcdHJldHVybiB7IC4uLmJhc2UsIGRlZmF1bHQ6IG8uZGVmYXVsdCA/PyBmYWxzZSB9XG5cblx0XHRjYXNlICd0ZXh0aW5wdXQnOlxuXHRcdGNhc2UgJ2NvbG9ycGlja2VyJzpcblx0XHRjYXNlICdzdGF0aWMtdGV4dCc6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIGEuY21kX2lkLCBhLmlkKVxuXG5cdFx0XHRjb25zdCBvcHRpb25zID0gKGEub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHRjb25zdCBhY3Rpb246IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHthLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVBY3Rpb25zICovXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGFjdGlvbnNbYWN0aW9uSWRdID0gYWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvbnNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBGZWVkYmFja3MgLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGZWVkYmFja3MoKTogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgZmVlZGJhY2tzOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3Qgc2V0dGluZyBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0lkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgc2V0dGluZy5jbWRfaWQsIHNldHRpbmcuaWQpXG5cblx0XHRcdC8vIEJ1aWxkIG9wdGlvbnNcblx0XHRcdGNvbnN0IGFsbE9wdGlvbnMgPSAoc2V0dGluZy5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdC8vIEZpbHRlciBvdXQgJ3ZhbHVlJyBvcHRpb24gZm9yIHZhbHVlIGZlZWRiYWNrIChrZWVwIG9ubHkgYnVzQ2gvaWRBZGQpXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbnMgPSBhbGxPcHRpb25zLmZpbHRlcigob3B0OiBhbnkpID0+IG9wdC5pZCAhPT0gJ3ZhbHVlJylcblxuXHRcdFx0Ly8gQWRkIGEgY2hlY2tib3ggb3B0aW9uIHRvIHJldHVybiBsYWJlbCBpbnN0ZWFkIG9mIHZhbHVlXG5cdFx0XHR2YWx1ZU9wdGlvbnMucHVzaCh7XG5cdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0bGFiZWw6ICdTaG93IExhYmVsJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHR9KVxuXG5cdFx0XHQvLyBWYWx1ZSBmZWVkYmFjayBmb3IgYWxsIHNldHRpbmdzIChhcHBlYXJzIGluIFZhcmlhYmxlcyBsaXN0KVxuXHRcdFx0Y29uc3QgdmFsdWVGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHR0eXBlOiAndmFsdWUnLFxuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnM6IHZhbHVlT3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRyZXR1cm4gMFxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRmZWVkYmFja3NbYmFzZUZlZWRiYWNrSWRdID0gdmFsdWVGZWVkYmFja1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IHJlc29sdmVNb2RlbCwgZ2V0RGV2aWNlc0ZvbGRlciwgZ2V0RGV2aWNlU2NoZW1hLCBnZXREZXZpY2VTY2hlbWFzLCByZWxvYWREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMgfSBmcm9tICcuL3R5cGVzLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5cbmltcG9ydCB7IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uLCBzYXZlTW9kZWxKc29uUHJldHR5LCB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MgfSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ0FjdGlvbnMnKVxuXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlQWN0aW9ucyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBzY2hlbWFzUmF3ID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IHJhd0FjdGlvbnMgPSBidWlsZEFjdGlvbnMoKVxuXHRjb25zdCBzY2hlbWFzID0gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoc2NoZW1hc1Jhdylcblx0Y29uc3Qgd2lyZWRBY3Rpb25zOiBhbnkgPSB7fVxuXG5cdC8vIEdldCB0aGUgYWN0aXZlIG1vZGVsIHVzaW5nIHJlc29sdmVNb2RlbFxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbChzZWxmLmNvbmZpZywgc2VsZi5kZXZpY2VzKVxuXHRsb2dnZXIuaW5mbyhcblx0XHRgVXBkYXRlQWN0aW9uczogYWN0aXZlTW9kZWw9XCIke2FjdGl2ZU1vZGVsfVwiLCBkaXNjb3ZlcmVkSG9zdD1cIiR7c2VsZi5jb25maWcuZGlzY292ZXJlZEhvc3R9XCIsIGRldmljZXMgY291bnQ9JHtzZWxmLmRldmljZXMubGVuZ3RofWAsXG5cdClcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEdMT0JBTDogR0VUIEFMTCBTRVRUSU5HUyAoQVVUTyBKU09OIFVQREFURSlcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0Ly8gT25seSB3aXJlIHRoZSBnZXRBbGxTZXR0aW5ncyBhY3Rpb24gaWYgdGhlIGRldmljZSBpcyBhdXRob3JpemVkXG5cdGlmIChzZWxmLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQoc2VsZi5ob3N0KSkge1xuXHRcdHdpcmVkQWN0aW9uc1snZ2xvYmFsX2dldEFsbFNldHRpbmdzJ10gPSB7XG5cdFx0XHRuYW1lOiAnR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzIChBdXRvLVVwZGF0ZSBKU09OKScsXG5cdFx0XHRvcHRpb25zOiBbXSxcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IG1vZGVsID0gYWN0aXZlTW9kZWxcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3RcblxuXHRcdFx0XHRjb25zdCBidWYgPSBhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApXG5cblx0XHRcdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIHRvIGdldCB0aGUgc2NoZW1hXG5cdFx0XHRcdGxldCBtb2RlbEpzb24gPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0XHRcdGlmICghbW9kZWxKc29uKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmVycm9yKGBNb2RlbCAke21vZGVsfSBzY2hlbWEgbm90IGZvdW5kIGluIGNhY2hlYClcblx0XHRcdFx0XHRyZXR1cm5cblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFBhcnNlIHdpdGggYXV0by1kZXRlY3Rpb25cblx0XHRcdFx0Y29uc3QgeyBzZXR0aW5nczogcGFyc2VkLCBkZXRlY3RlZFNlY3Rpb25lZCB9ID0gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24obW9kZWwsIGJ1Zilcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBwYXJzZWQgcmVwbHk6ICR7SlNPTi5zdHJpbmdpZnkocGFyc2VkKX1gKVxuXG5cdFx0XHRcdC8vIElmIHdlIGF1dG8tZGV0ZWN0ZWQgdGhlIGZvcm1hdCwgYWRkIGl0IHRvIHRoZSBKU09OXG5cdFx0XHRcdGlmIChkZXRlY3RlZFNlY3Rpb25lZCAhPT0gbnVsbCkge1xuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIHNlY3Rpb25lZD0ke2RldGVjdGVkU2VjdGlvbmVkfSwgYWRkaW5nIHRvIG1vZGVsIEpTT05gKVxuXHRcdFx0XHRcdG1vZGVsSnNvbiA9IHsgLi4ubW9kZWxKc29uLCBzZWN0aW9uZWQ6IGRldGVjdGVkU2VjdGlvbmVkIH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IHVwZGF0ZWQgPSB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MobW9kZWxKc29uLCBwYXJzZWQsIHNjaGVtYXMpXG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgbmV3IEFjdGlvbnMganNvbjogJHtKU09OLnN0cmluZ2lmeSh1cGRhdGVkLCBudWxsLCAyKX1gKVxuXG5cdFx0XHRcdC8vIFNhdmUgdGhlIHVwZGF0ZWQgSlNPTiB0byBkaXNrXG5cdFx0XHRcdGNvbnN0IGRldmljZXNGb2xkZXIgPSBnZXREZXZpY2VzRm9sZGVyKClcblx0XHRcdFx0Y29uc3Qgc2NoZW1hUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBgTW9kZWwke21vZGVsfS5qc29uYClcblx0XHRcdFx0c2F2ZU1vZGVsSnNvblByZXR0eShzY2hlbWFQYXRoLCB1cGRhdGVkKVxuXG5cdFx0XHRcdC8vIFJlbG9hZCB0aGUgY2FjaGUgYWZ0ZXIgd3JpdGluZyB0byBmaWxlXG5cdFx0XHRcdHJlbG9hZERldmljZVNjaGVtYXMoKVxuXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBNb2RlbCAke21vZGVsfSBKU09OIGF1dG8tdXBkYXRlZCBmcm9tIGdldEFsbFNldHRpbmdzYClcblx0XHRcdH0sXG5cdFx0fVxuXHR9IC8vIGVuZCBpc0RldmljZUF1dGhvcml6ZWRcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEFDVElPTlMgKEZJTFRFUkVEIEJZIEFDVElWRSBNT0RFTClcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0Zm9yIChjb25zdCBbYWN0aW9uSWQsIGFjdGlvbl0gb2YgT2JqZWN0LmVudHJpZXMocmF3QWN0aW9ucykpIHtcblx0XHRjb25zdCB7IG1vZGVsLCBjbWRJZCwgYmFzZUlkIH0gPSBwYXJzZVNldHRpbmdJZChhY3Rpb25JZClcblxuXHRcdC8vIE9ubHkgaW5jbHVkZSBhY3Rpb25zIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBtb2RlbFxuXHRcdGlmIChtb2RlbCAhPT0gYWN0aXZlTW9kZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBHZXQgdGhlIHJhdyBhY3Rpb24gc2NoZW1hIHRvIGFjY2VzcyBmaXhlZCBidXNDaCB2YWx1ZVxuXHRcdGNvbnN0IHNjaGVtYSA9IHNjaGVtYXNbbW9kZWxdXG5cdFx0Y29uc3QgcmF3QWN0aW9uID0gc2NoZW1hPy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IGJhc2VJZClcblxuXHRcdHdpcmVkQWN0aW9uc1thY3Rpb25JZF0gPSB7XG5cdFx0XHQuLi5hY3Rpb24sXG5cdFx0XHRjYWxsYmFjazogYXN5bmMgKGV2ZW50OiBhbnkpID0+IHtcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBldmVudC5vcHRpb25zWydidXNDaCddICE9PSB1bmRlZmluZWQgPyBldmVudC5vcHRpb25zWydidXNDaCddIDogcmF3QWN0aW9uPy5idXNDaFxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGV2ZW50Lm9wdGlvbnNbJ3ZhbHVlJ11cblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBldmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblxuXHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5zZW5kQXdhaXRBY2soYWN0aXZlTW9kZWwsIGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgaXApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgTUlDIEtJTEwgKE9OTFkgSUYgQUNUSVZFIE1PREVMIFNVUFBPUlRTIElUKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Y29uc3QgYWN0aXZlU2NoZW1hID0gc2NoZW1hc1thY3RpdmVNb2RlbF1cblx0aWYgKGFjdGl2ZVNjaGVtYSkge1xuXHRcdGNvbnN0IHN1cHBvcnRzTWljS2lsbCA9IChhY3RpdmVTY2hlbWEuY21kU2NoZW1hID8/IFtdKS5zb21lKChhOiBhbnkpID0+IGEubmFtZS5pbmNsdWRlcygnS2lsbCcpKVxuXG5cdFx0aWYgKHN1cHBvcnRzTWljS2lsbCkge1xuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBgJHthY3RpdmVNb2RlbH1fbWljS2lsbGBcblxuXHRcdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7YWN0aXZlTW9kZWx9XSBNaWMgS2lsbGAsXG5cdFx0XHRcdG9wdGlvbnM6IFtdLFxuXHRcdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYE1pYyBLaWxsIFx1MjE5MiBNb2RlbCAke2FjdGl2ZU1vZGVsfSBAICR7aXB9YClcblx0XHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5nbG9iYWxNaWNLaWxsKGFjdGl2ZU1vZGVsLCBpcClcblx0XHRcdFx0fSxcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEFjdGlvbkRlZmluaXRpb25zKHdpcmVkQWN0aW9ucylcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRlQWN0aW9uczogd2lyZWQgYWN0aW9uczogJHtPYmplY3Qua2V5cyh3aXJlZEFjdGlvbnMpLmxlbmd0aH1gKVxufVxuIiwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYSB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9CVVNfU0VULFxuXHRDTURfQ0hBTk5FTCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdGZvcm1hdFJnYkNvbG9yLFxuXHRtb2RlbERpc3RhbmNlLFxufSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1NldHRpbmdzUGFyc2VyJylcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVFlQRVNcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IHR5cGUgUGFyc2VkU2V0dGluZyA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRidXNDaD86IG51bWJlciAvLyBPcHRpb25hbDogb25seSBwcmVzZW50IGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoICgweDA0LCAweDEyLCAweDE0KVxuXHR2YWx1ZUJ5dGVzOiBudW1iZXJbXVxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbk9wdGlvbiA9IHtcblx0aWQ/OiBzdHJpbmdcblx0bGFiZWw6IHN0cmluZ1xuXHR0eXBlOiBzdHJpbmdcblx0ZGVmYXVsdDogdW5rbm93blxuXHR0b29sdGlwPzogc3RyaW5nXG5cdGNob2ljZXM/OiBBcnJheTx7IGlkOiBudW1iZXI7IGxhYmVsOiBzdHJpbmcgfT5cbn1cblxuZXhwb3J0IHR5cGUgU3RBY3Rpb24gPSB7XG5cdGNtZF9pZDogbnVtYmVyXG5cdGlkOiBudW1iZXJcblx0bmFtZTogc3RyaW5nXG5cdG9wdGlvbnM6IFN0QWN0aW9uT3B0aW9uW11cblx0YnVzQ2g/OiBudW1iZXIgLy8gRml4ZWQgY2hhbm5lbCB2YWx1ZSBmb3IgYWN0aW9ucyB0aGF0IGRvbid0IGhhdmUgYSBjaGFubmVsIG9wdGlvblxufVxuXG5leHBvcnQgdHlwZSBTdE1vZGVsSnNvbiA9IHtcblx0bW9kZWw6IHN0cmluZ1xuXHRzZWN0aW9uZWQ/OiBib29sZWFuXG5cdHJlZnJlc2hBZnRlckNvbW1hbmQ/OiBib29sZWFuXG5cdGNtZFNjaGVtYTogU3RBY3Rpb25bXVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGT1JNQVQgSEVMUEVSU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBnZXRNb2RlbENvbmZpZyhtb2RlbDogc3RyaW5nKTogeyBzZWN0aW9uZWQ6IGJvb2xlYW47IHJnYklkczogU2V0PG51bWJlcj4gfSB7XG5cdGNvbnN0IHJnYklkcyA9IG5ldyBTZXQ8bnVtYmVyPigpXG5cdGxldCBzZWN0aW9uZWQgPSBmYWxzZVxuXG5cdHRyeSB7XG5cdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIGluc3RlYWQgb2YgcmVhZGluZyBmcm9tIGRpc2tcblx0XHRjb25zdCBqc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghanNvbikge1xuXHRcdFx0Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgc2NoZW1hLCByZXR1cm4gZGVmYXVsdHNcblx0XHRcdHJldHVybiB7IHNlY3Rpb25lZCwgcmdiSWRzIH1cblx0XHR9XG5cblx0XHQvLyBSZWFkIHNlY3Rpb25lZCBwcm9wZXJ0eSAoZGVmYXVsdCB0byBmYWxzZSBpZiBub3Qgc3BlY2lmaWVkKVxuXHRcdHNlY3Rpb25lZCA9IGpzb24uc2VjdGlvbmVkID8/IGZhbHNlXG5cblx0XHQvLyBCdWlsZCBSR0IgSURzIHNldFxuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHQvLyBBZGQgdGhlIGJhc2UgSURcblx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQpXG5cblx0XHRcdFx0Ly8gSWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkIGNob2ljZXMsIGFkZCBhbGwgdGhlIG9mZnNldCBJRHMgdG9vXG5cdFx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjaG9pY2Ugb2YgaWRBZGRPcHRpb24uY2hvaWNlcykge1xuXHRcdFx0XHRcdFx0aWYgKHR5cGVvZiBjaG9pY2UuaWQgPT09ICdudW1iZXInKSB7XG5cdFx0XHRcdFx0XHRcdHJnYklkcy5hZGQoYWN0aW9uLmlkICsgY2hvaWNlLmlkKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCAoX2Vycikge1xuXHRcdC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHNjaGVtYSwgcmV0dXJuIGRlZmF1bHRzXG5cdH1cblxuXHRyZXR1cm4geyBzZWN0aW9uZWQsIHJnYklkcyB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZJTkQgVEhFIFJFQUwgNUEgUEFZTE9BRCBJTkRFWFxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmOiBCdWZmZXIpOiBudW1iZXIge1xuXHRjb25zdCBzaWdJbmRleCA9IGJ1Zi5pbmRleE9mKEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcpKVxuXHRpZiAoc2lnSW5kZXggPCAwKSB0aHJvdyBuZXcgRXJyb3IoJ05vIFN0dWRpby1UIHNpZ25hdHVyZSBpbiBwYWNrZXQnKVxuXG5cdGNvbnN0IHBheWxvYWRJbmRleCA9IHNpZ0luZGV4ICsgOFxuXHRpZiAoYnVmW3BheWxvYWRJbmRleF0gIT09IDB4NWEpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIDB4NUEgYWZ0ZXIgU3R1ZGlvLVQsIGZvdW5kICR7YnVmW3BheWxvYWRJbmRleF0udG9TdHJpbmcoMTYpfWApXG5cdH1cblxuXHRyZXR1cm4gcGF5bG9hZEluZGV4XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZMQVQgUEFSU0VSXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYmxvY2s6IEJ1ZmZlciwgcmdiSWRzOiBTZXQ8bnVtYmVyPiA9IG5ldyBTZXQoKSk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGxldCBwID0gMFxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0d2hpbGUgKHAgPCBibG9jay5sZW5ndGgpIHtcblx0XHRjb25zdCBpZCA9IGJsb2NrW3BdXG5cdFx0aWYgKHAgKyAxID49IGJsb2NrLmxlbmd0aCkgYnJlYWtcblxuXHRcdC8vIFJHQiBjYXNlIC0gY2hlY2sgaWYgdGhpcyBJRCBpcyBhIGtub3duIGNvbG9ycGlja2VyXG5cdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHAgKyAzIDwgYmxvY2subGVuZ3RoKSB7XG5cdFx0XHRvdXQucHVzaCh7XG5cdFx0XHRcdGNtZF9pZDogQ01EX0RFVl9TUEVDLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXSwgYmxvY2tbcCArIDJdLCBibG9ja1twICsgM11dLFxuXHRcdFx0fSlcblx0XHRcdHAgKz0gNFxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHRvdXQucHVzaCh7IGNtZF9pZDogQ01EX0RFVl9TUEVDLCBpZCwgdmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXV0gfSlcblx0XHRwICs9IDJcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Y29uc3QgYmxvY2tMZW4gPSBidWZbaWR4ICsgMl1cblx0Y29uc3Qgc3RhcnQgPSBpZHggKyAzXG5cdGNvbnN0IGVuZCA9IHN0YXJ0ICsgYmxvY2tMZW5cblx0aWYgKGVuZCA+IGJ1Zi5sZW5ndGgpIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBibG9jayBsZW5ndGgnKVxuXG5cdGNvbnN0IHsgcmdiSWRzIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYnVmLnN1YmFycmF5KHN0YXJ0LCBlbmQpLCByZ2JJZHMpXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNFQ1RJT05FRCBQQVJTRVJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZjogQnVmZmVyLCBtb2RlbDogc3RyaW5nKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgYSBnZXRBbGxTZXR0aW5ncyByZXBseScpXG5cdH1cblxuXHQvLyBDTURfR0VUX0FMTF9TRVRUSU5HUyBoYXMgYSB0b3RhbC1sZW5ndGggYnl0ZSBhdCBpZHgrMiBiZWZvcmUgdGhlIHNlY3Rpb25zOyBDTURfU0VUVElOR1NfUFVTSCBkb2VzIG5vdC5cblx0bGV0IHAgPSBjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgPyBpZHggKyAzIDogaWR4ICsgMlxuXHRjb25zdCBlbmQgPSBidWYubGVuZ3RoIC0gMVxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0Ly8gR2V0IFJHQiBJRHMgZm9yIHRoaXMgbW9kZWxcblx0Y29uc3QgeyByZ2JJZHMgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgaW4gdGhlaXIgc2VjdGlvbiBzdHJ1Y3R1cmVcblx0Y29uc3QgY29tbWFuZHNXaXRoQnVzQ2ggPSBbQ01EX0JVU19TRVQsIENNRF9NSUNfUFJFX0JVUywgQ01EX0NIQU5ORUxdXG5cblx0d2hpbGUgKHAgKyAyIDwgZW5kKSB7XG5cdFx0Y29uc3QgY21kTGVuID0gYnVmW3BdXG5cdFx0Y29uc3Qgc2VjdGlvbkNtZElkID0gYnVmW3AgKyAxXVxuXG5cdFx0Y29uc3Qgc2VjdGlvbkVuZCA9IHAgKyAxICsgY21kTGVuXG5cdFx0aWYgKHNlY3Rpb25FbmQgPiBlbmQpIGJyZWFrXG5cblx0XHQvLyBDaGVjayBpZiB0aGlzIGNvbW1hbmQgaW5jbHVkZXMgYSBidXNDaCBieXRlXG5cdFx0Y29uc3QgaGFzQnVzQ2ggPSBjb21tYW5kc1dpdGhCdXNDaC5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cblx0XHRsZXQgYnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZFxuXHRcdGxldCBkYXRhTGVuOiBudW1iZXJcblx0XHRsZXQgcTogbnVtYmVyXG5cblx0XHRpZiAoaGFzQnVzQ2gpIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRkYXRhTGVuID0gYnVmW3AgKyAzXVxuXHRcdFx0cSA9IHAgKyA0IC8vIERhdGEgc3RhcnRzIGFmdGVyIGNtZExlbiwgY21kSWQsIGJ1c0NoLCBkYXRhTGVuXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbZGF0YUxlbl0gW2lkOnZhbCBwYWlyc11cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDJdXG5cdFx0XHRxID0gcCArIDMgLy8gRGF0YSBzdGFydHMgYWZ0ZXIgY21kTGVuLCBjbWRJZCwgZGF0YUxlblxuXHRcdH1cblxuXHRcdGNvbnN0IHFFbmQgPSBxICsgZGF0YUxlblxuXG5cdFx0d2hpbGUgKHEgKyAxIDwgcUVuZCkge1xuXHRcdFx0Y29uc3QgaWQgPSBidWZbcV1cblx0XHRcdGxldCB2YWx1ZUJ5dGVzOiBudW1iZXJbXVxuXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIElEIGlzIGFuIFJHQiBjb2xvcnBpY2tlciAobmVlZHMgMyBieXRlcylcblx0XHRcdGlmIChyZ2JJZHMuaGFzKGlkKSAmJiBxICsgMyA8IHFFbmQpIHtcblx0XHRcdFx0dmFsdWVCeXRlcyA9IFtidWZbcSArIDFdLCBidWZbcSArIDJdLCBidWZbcSArIDNdXVxuXHRcdFx0XHRxICs9IDRcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXV1cblx0XHRcdFx0cSArPSAyXG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHNldHRpbmc6IFBhcnNlZFNldHRpbmcgPSB7XG5cdFx0XHRcdGNtZF9pZDogc2VjdGlvbkNtZElkLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdHNldHRpbmcuYnVzQ2ggPSBidXNDaFxuXHRcdFx0fVxuXHRcdFx0b3V0LnB1c2goc2V0dGluZylcblx0XHR9XG5cblx0XHRwID0gc2VjdGlvbkVuZFxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBHRU5FUklDIFNFVFRJTkdTIFJFU1BPTlNFIFBBUlNFUiAoMHgwYSBnZXQtYWxsICsgMHgwYiB1bnNvbGljaXRlZCBwdXNoKVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBhbnkgZnVsbCBzZXR0aW5ncyBibG9jayByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhlIGNtZElkIGlzIDB4MGFcbiAqIChyZXNwb25zZSB0byBHZXQgQWxsIFNldHRpbmdzKSBvciAweDBiICh1bnNvbGljaXRlZCBwdXNoIGFmdGVyIGEgc2V0KS5cbiAqIEJvdGggdXNlIHRoZSBzYW1lIHNlY3Rpb25lZCBvciBmbGF0IGJsb2NrIGxheW91dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ3NSZXNwb25zZShtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgTm90IGEgc2V0dGluZ3MgYmxvY2sgKGNtZElkPTB4JHtjbWRJZC50b1N0cmluZygxNil9KWApXG5cdH1cblx0Y29uc3QgeyBzZWN0aW9uZWQgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gc2VjdGlvbmVkID8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbCkgOiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcbn1cblxuLyoqXG4gKiBGb3JtYXRzIGEgc2luZ2xlIHBhcnNlZCBzZXR0aW5nIGludG8gYSBodW1hbi1yZWFkYWJsZSBzdHJpbmcgdXNpbmcgYWN0aW9uXG4gKiBkZWZpbml0aW9ucyBmcm9tIHRoZSBkZXZpY2UgSlNPTi4gRmFsbHMgYmFjayB0byBoZXggSURzIHdoZW4gdW5rbm93bi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZzogUGFyc2VkU2V0dGluZywgYWN0aW9uczogU3RBY3Rpb25bXSk6IHN0cmluZyB7XG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gc2V0dGluZy5jbWRfaWQgJiYgYS5pZCA9PT0gc2V0dGluZy5pZClcblxuXHQvLyBJZiBubyBleGFjdCBtYXRjaCBhbmQgaWQgPiBiYXNlIGlkLCB0cnkgdG8gZmluZCBhY3Rpb24gd2l0aCBpZEFkZCBvcHRpb25cblx0Ly8gVGhpcyBoYW5kbGVzIGNhc2VzIGxpa2UgY21kX2lkIDUgKFBob25lcyBSb3V0aW5nKSBhbmQgY21kX2lkIDcgKEJ1dHRvbnMpXG5cdC8vIHdoZXJlIGlkIDAtMyByZXByZXNlbnRzIGNoYW5uZWxzIDEtNFxuXHRpZiAoIWFjdGlvbikge1xuXHRcdGNvbnN0IGJhc2VBY3Rpb24gPSBhY3Rpb25zLmZpbmQoKGEpID0+IHtcblx0XHRcdGlmIChhLmNtZF9pZCAhPT0gc2V0dGluZy5jbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBhY3Rpb24gaGFzIGFuIGlkQWRkIG9wdGlvbiAoaW5kaWNhdGluZyBjaGFubmVsIHNlbGVjdGlvbilcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYS5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhlIHNldHRpbmcuaWQgb2Zmc2V0IG1hdGNoZXMgb25lIG9mIHRoZSBpZEFkZCBjaG9pY2UgSURzXG5cdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZy5pZCAtIGEuaWRcblx0XHRcdHJldHVybiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGMpID0+IGMuaWQgPT09IGNoYW5uZWxPZmZzZXQpXG5cdFx0fSlcblx0XHRpZiAoYmFzZUFjdGlvbikge1xuXHRcdFx0YWN0aW9uID0gYmFzZUFjdGlvblxuXHRcdH1cblx0fVxuXG5cdGNvbnN0IGNtZEhleCA9IHRvSGV4KHNldHRpbmcuY21kX2lkKVxuXHRjb25zdCBpZEhleCA9IHRvSGV4KHNldHRpbmcuaWQpXG5cdGNvbnN0IHZhbEhleCA9IGJ5dGVzVG9IZXgoc2V0dGluZy52YWx1ZUJ5dGVzKVxuXHRjb25zdCB2YWxEZWMgPVxuXHRcdHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdD8gZm9ybWF0UmdiQ29sb3Ioc2V0dGluZy52YWx1ZUJ5dGVzWzBdLCBzZXR0aW5nLnZhbHVlQnl0ZXNbMV0sIHNldHRpbmcudmFsdWVCeXRlc1syXSlcblx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMVxuXHRcdFx0XHQ/IHNldHRpbmcudmFsdWVCeXRlc1swXVxuXHRcdFx0XHQ6IHNldHRpbmcudmFsdWVCeXRlcy5qb2luKCcsJylcblxuXHQvLyBCdWlsZCB0aGUgcHJlZml4OiBjbWQ6MHgxMiBjaDowIGlkOjB4MDEgdmFsOjB4MTQgKGNoIG9ubHkgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2gpXG5cdGNvbnN0IGJ1c0NoU3RyID0gc2V0dGluZy5idXNDaCAhPT0gdW5kZWZpbmVkID8gYCBjaDoke3NldHRpbmcuYnVzQ2h9YCA6ICcnXG5cdGNvbnN0IHByZWZpeCA9IGBjbWQ6JHtjbWRIZXh9JHtidXNDaFN0cn0gaWQ6JHtpZEhleH0gdmFsOiR7dmFsSGV4fWBcblxuXHQvLyBJZiB3ZSBoYXZlIGFuIGFjdGlvbiB3aXRoIGEgbmFtZSBhbmQgY2hvaWNlIGxhYmVsLCB1c2UgaXRcblx0aWYgKGFjdGlvbikge1xuXHRcdGxldCBuYW1lID0gYWN0aW9uLm5hbWVcblxuXHRcdC8vIElmIHNldHRpbmcgaGFzIGJ1c0NoLCBhZGQgY2hhbm5lbCBpbmZvIHRvIG5hbWVcblx0XHRpZiAoc2V0dGluZy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRuYW1lID0gYCR7bmFtZX0gQ2gke3NldHRpbmcuYnVzQ2ggKyAxfWBcblx0XHR9XG5cdFx0Ly8gT3RoZXJ3aXNlLCBpZiB0aGlzIGFjdGlvbiBoYXMgaWRBZGQsIGluY2x1ZGUgdGhlIGlkQWRkIGxhYmVsXG5cdFx0ZWxzZSB7XG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmIChpZEFkZE9wdGlvbj8uY2hvaWNlcykge1xuXHRcdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZy5pZCAtIGFjdGlvbi5pZFxuXHRcdFx0XHRjb25zdCBpZEFkZENob2ljZSA9IGlkQWRkT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHRcdFx0aWYgKGlkQWRkQ2hvaWNlKSB7XG5cdFx0XHRcdFx0bmFtZSA9IGAke25hbWV9ICR7aWRBZGRDaG9pY2UubGFiZWx9YFxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gTG9vayBmb3IgdGhlIHZhbHVlIG9wdGlvbiAobm90IGJ1c0NoIG9yIGlkQWRkKVxuXHRcdGNvbnN0IHZhbHVlT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAndmFsdWUnKVxuXHRcdGlmICh2YWx1ZU9wdGlvbj8uY2hvaWNlcyAmJiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRjb25zdCBjaG9pY2UgPSB2YWx1ZU9wdGlvbi5jaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHNldHRpbmcudmFsdWVCeXRlc1swXSlcblx0XHRcdGlmIChjaG9pY2UpIHtcblx0XHRcdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke2Nob2ljZS5sYWJlbH0gKCR7dmFsRGVjfSlgXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBgJHtwcmVmaXh9IHwgJHtuYW1lfTogJHt2YWxEZWN9YFxuXHR9XG5cblx0Ly8gTm8gYWN0aW9uIGZvdW5kIC0ganVzdCBzaG93IHRoZSByYXcgdmFsdWVzXG5cdHJldHVybiBgJHtwcmVmaXh9IHwgVW5rbm93biBTZXR0aW5nYFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBQQVJTRVIgRElTUEFUQ0ggV0lUSCBBVVRPLURFVEVDVElPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBnZXRBbGxTZXR0aW5ncyByZXNwb25zZSB3aXRoIGF1dG9tYXRpYyBmb3JtYXQgZGV0ZWN0aW9uLlxuICpcbiAqIFN0cmF0ZWd5OlxuICogMS4gSWYgbW9kZWwgaGFzIGV4cGxpY2l0IFwic2VjdGlvbmVkXCIgcHJvcGVydHksIHVzZSB0aGF0XG4gKiAyLiBPdGhlcndpc2UsIHRyeSBGTEFUIHBhcnNlciBmaXJzdCAoaXQncyBzaW1wbGVyKVxuICogMy4gSWYgRkxBVCByZXR1cm5zIDAgc2V0dGluZ3MsIHRyeSBTRUNUSU9ORUQgcGFyc2VyXG4gKiA0LiBVc2Ugd2hpY2hldmVyIHBhcnNlciByZXR1cm5zIG1vcmUgc2V0dGluZ3NcbiAqXG4gKiBAcmV0dXJucyB7c2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGJvb2xlYW4gfCBudWxsfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24oXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGJ1ZjogQnVmZmVyLFxuKTogeyBzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdOyBkZXRlY3RlZFNlY3Rpb25lZDogYm9vbGVhbiB8IG51bGwgfSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0Y29uc3QgZGVjbGFyZWRTZWN0aW9uZWQgPSBzY2hlbWE/LnNlY3Rpb25lZFxuXG5cdC8vIElmIGV4cGxpY2l0bHkgZGVjbGFyZWQgaW4gSlNPTiwgdXNlIHRoYXRcblx0aWYgKGRlY2xhcmVkU2VjdGlvbmVkICE9PSB1bmRlZmluZWQpIHtcblx0XHRjb25zdCBzZXR0aW5ncyA9IGRlY2xhcmVkU2VjdGlvbmVkXG5cdFx0XHQ/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG5cdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxuXHRcdHJldHVybiB7IHNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9IC8vIG51bGwgPSB1c2VkIGRlY2xhcmVkIHZhbHVlXG5cdH1cblxuXHQvLyBObyBkZWNsYXJhdGlvbiAtIHRyeSBib3RoIHBhcnNlcnMgYW5kIHBpY2sgdGhlIGJlc3Qgb25lXG5cdGxldCBmbGF0U2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cdGxldCBzZWN0aW9uZWRTZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHR0cnkge1xuXHRcdGZsYXRTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBGbGF0IHBhcnNlciBmYWlsZWQ6ICR7ZX1gKVxuXHR9XG5cblx0dHJ5IHtcblx0XHRzZWN0aW9uZWRTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZGVidWcoYFNlY3Rpb25lZCBwYXJzZXIgZmFpbGVkOiAke2V9YClcblx0fVxuXG5cdC8vIFBpY2sgdGhlIHBhcnNlciB0aGF0IHJldHVybmVkIG1vcmUgc2V0dGluZ3Ncblx0aWYgKHNlY3Rpb25lZFNldHRpbmdzLmxlbmd0aCA+IGZsYXRTZXR0aW5ncy5sZW5ndGgpIHtcblx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBTRUNUSU9ORUQgZm9ybWF0IChzZWN0aW9uZWQ9JHtzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGh9IHZzIGZsYXQ9JHtmbGF0U2V0dGluZ3MubGVuZ3RofSlgKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBzZWN0aW9uZWRTZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IHRydWUgfVxuXHR9IGVsc2UgaWYgKGZsYXRTZXR0aW5ncy5sZW5ndGggPiAwKSB7XG5cdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgRkxBVCBmb3JtYXQgKGZsYXQ9JHtmbGF0U2V0dGluZ3MubGVuZ3RofSB2cyBzZWN0aW9uZWQ9JHtzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGh9KWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IGZsYXRTZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGZhbHNlIH1cblx0fSBlbHNlIHtcblx0XHQvLyBCb3RoIHBhcnNlcnMgcmV0dXJuZWQgMCBzZXR0aW5nc1xuXHRcdGxvZ2dlci53YXJuKGBXYXJuaW5nOiBCb3RoIHBhcnNlcnMgcmV0dXJuZWQgMCBzZXR0aW5ncyBmb3IgbW9kZWwgJHttb2RlbH1gKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfVxuXHR9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwobW9kZWw6IHN0cmluZywgYnVmOiBCdWZmZXIpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCB7IHNlY3Rpb25lZCB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cdHJldHVybiBzZWN0aW9uZWQgPyBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKSA6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxufVxuXG4vKiBcdTI3MDUgYmFja3dhcmQtY29tcGF0aWJsZSBleHBvcnQgKi9cbmV4cG9ydCBjb25zdCBwYXJzZUdldEFsbFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFZBTFVFIFx1MjE5MiBPUFRJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXM6IG51bWJlcltdKTogU3RBY3Rpb25PcHRpb24ge1xuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdudW1iZXInLCBkZWZhdWx0OiB2YWx1ZUJ5dGVzWzBdIH1cblx0fVxuXG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMykge1xuXHRcdGNvbnN0IFtyLCBnLCBiXSA9IHZhbHVlQnl0ZXNcblx0XHRyZXR1cm4ge1xuXHRcdFx0aWQ6ICd2YWx1ZScsXG5cdFx0XHRsYWJlbDogJ0NvbG9yJyxcblx0XHRcdHR5cGU6ICdjb2xvcnBpY2tlcicsXG5cdFx0XHRkZWZhdWx0OiBmb3JtYXRSZ2JDb2xvcihyLCBnLCBiKSxcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdyYXcnLCBkZWZhdWx0OiBbLi4udmFsdWVCeXRlc10gfVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTTUFSVCBKU09OIFVQREFURVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKFxuXHRtb2RlbEpzb246IFN0TW9kZWxKc29uLFxuXHRwYXJzZWQ6IFBhcnNlZFNldHRpbmdbXSxcblx0YWxsTW9kZWxzOiBSZWNvcmQ8c3RyaW5nLCBTdE1vZGVsSnNvbj4sXG4pOiBTdE1vZGVsSnNvbiB7XG5cdGNvbnN0IG91dCA9IHN0cnVjdHVyZWRDbG9uZShtb2RlbEpzb24pXG5cblx0Ly8gRW5zdXJlIGNtZFNjaGVtYSBhcnJheSBleGlzdHNcblx0aWYgKCFvdXQuY21kU2NoZW1hKSB7XG5cdFx0b3V0LmNtZFNjaGVtYSA9IFtdXG5cdH1cblxuXHQvLyBTb3J0IG90aGVyIG1vZGVscyBieSBudW1lcmljIGRpc3RhbmNlIHRvIGN1cnJlbnQgbW9kZWxcblx0Y29uc3QgY2FuZGlkYXRlcyA9IE9iamVjdC52YWx1ZXMoYWxsTW9kZWxzKVxuXHRcdC5maWx0ZXIoKG0pID0+IG0ubW9kZWwgIT09IG1vZGVsSnNvbi5tb2RlbCkgLy8gZXhjbHVkZSBzZWxmXG5cdFx0LnNvcnQoKGEsIGIpID0+IG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBhLm1vZGVsKSAtIG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBiLm1vZGVsKSlcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRpbmcgbW9kZWw6ICR7bW9kZWxKc29uLm1vZGVsfWApXG5cdGxvZ2dlci5kZWJ1ZyhgQ2FuZGlkYXRlcyBmb3IgaW5mZXJlbmNlOiAke2NhbmRpZGF0ZXMubWFwKChjKSA9PiBjLm1vZGVsKS5qb2luKCcsICcpfWApXG5cblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQsIHZhbHVlQnl0ZXMgfSBvZiBwYXJzZWQpIHtcblx0XHRsZXQgYWN0aW9uID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXG5cdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdC8vIFRyeSBjYW5kaWRhdGVzIGluIG9yZGVyIG9mIHByb3hpbWl0eVxuXHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0Y29uc3QgbWF0Y2ggPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZClcblx0XHRcdFx0aWYgKG1hdGNoKSB7XG5cdFx0XHRcdFx0YWN0aW9uID0gc3RydWN0dXJlZENsb25lKG1hdGNoKVxuXHRcdFx0XHRcdGFjdGlvbi5uYW1lID0gYCR7bWF0Y2gubmFtZX0gKGluZmVycmVkIGZyb20gTW9kZWwgJHtjLm1vZGVsfSlgXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYEluZmVycmVkIHNldHRpbmcgJHt0b0hleChpZCl9IGZyb20gTW9kZWwgJHtjLm1vZGVsfWApXG5cdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSB7XG5cdFx0XHRcdGNtZF9pZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdG5hbWU6IGBVbmtub3duIFNldHRpbmcgJHt0b0hleChpZCkudG9VcHBlckNhc2UoKX1gLFxuXHRcdFx0XHRvcHRpb25zOiBbdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpXSxcblx0XHRcdH1cblx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgaW5mZXIgc2V0dGluZyAke3RvSGV4KGlkKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCBvcHQgPSBhY3Rpb24ub3B0aW9ucz8uWzBdXG5cdFx0XHRpZiAob3B0KSBvcHQuZGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cdFx0fVxuXG5cdFx0Ly8gQXZvaWQgZHVwbGljYXRlc1xuXHRcdGNvbnN0IGV4aXN0cyA9IG91dC5jbWRTY2hlbWEuc29tZSgoYSkgPT4gYS5jbWRfaWQgPT09IGFjdGlvbi5jbWRfaWQgJiYgYS5pZCA9PT0gYWN0aW9uLmlkKVxuXHRcdGlmICghZXhpc3RzKSBvdXQuY21kU2NoZW1hLnB1c2goYWN0aW9uKVxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTQVZFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBzYXZlTW9kZWxKc29uUHJldHR5KGZpbGVQYXRoOiBzdHJpbmcsIGpzb25PYmo6IFN0TW9kZWxKc29uKTogdm9pZCB7XG5cdHRyeSB7XG5cdFx0Ly8gRW5zdXJlIHByb3BlciBrZXkgb3JkZXJpbmc6IG1vZGVsLCBzZWN0aW9uZWQgKGlmIHByZXNlbnQpLCByZWZyZXNoQWZ0ZXJDb21tYW5kLCBjbWRTY2hlbWFcblx0XHRjb25zdCBvcmRlcmVkT2JqOiBhbnkgPSB7IG1vZGVsOiBqc29uT2JqLm1vZGVsIH1cblxuXHRcdC8vIEFkZCBzZWN0aW9uZWQga2V5IGlmIHByZXNlbnQgKHJpZ2h0IGFmdGVyIG1vZGVsKVxuXHRcdGlmICgnc2VjdGlvbmVkJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLnNlY3Rpb25lZCA9IGpzb25PYmouc2VjdGlvbmVkXG5cdFx0fVxuXG5cdFx0Ly8gQWRkIG90aGVyIGtleXMgaW4gb3JkZXJcblx0XHRpZiAoJ3JlZnJlc2hBZnRlckNvbW1hbmQnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmoucmVmcmVzaEFmdGVyQ29tbWFuZCA9IGpzb25PYmoucmVmcmVzaEFmdGVyQ29tbWFuZFxuXHRcdH1cblx0XHRpZiAoJ2NtZFNjaGVtYScgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5jbWRTY2hlbWEgPSBqc29uT2JqLmNtZFNjaGVtYVxuXHRcdH1cblx0XHQvLyBDb3B5IGFueSBvdGhlciBrZXlzIHRoYXQgbWlnaHQgZXhpc3Rcblx0XHRmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhqc29uT2JqKSkge1xuXHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRPYmopKSB7XG5cdFx0XHRcdG9yZGVyZWRPYmpba2V5XSA9IChqc29uT2JqIGFzIGFueSlba2V5XVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIEN1c3RvbSBmb3JtYXR0ZXI6IGtlZXAgY2hvaWNlIG9iamVjdHMgY29tcGFjdCBvbiBvbmUgbGluZVxuXHRcdGxldCBqc29uID0gSlNPTi5zdHJpbmdpZnkob3JkZXJlZE9iaiwgbnVsbCwgMilcblxuXHRcdC8vIFJlcGxhY2UgZXhwYW5kZWQgY2hvaWNlIG9iamVjdHMgd2l0aCBjb21wYWN0IHNpbmdsZS1saW5lIGZvcm1hdFxuXHRcdC8vIE1hdGNoZXM6IHtcXG4gICAgICAgICAgICBcImlkXCI6IFgsXFxuICAgICAgICAgICAgXCJsYWJlbFwiOiBcIllcIlxcbiAgICAgICAgICB9XG5cdFx0Ly8gUmVwbGFjZXMgd2l0aDogeyBcImlkXCI6IFgsIFwibGFiZWxcIjogXCJZXCIgfVxuXHRcdGpzb24gPSBqc29uLnJlcGxhY2UoL1xce1xcblxccytcImlkXCI6XFxzKihcXGQrKSxcXG5cXHMrXCJsYWJlbFwiOlxccypcIihbXlwiXSopXCJcXG5cXHMrXFx9L2csICd7IFwiaWRcIjogJDEsIFwibGFiZWxcIjogXCIkMlwiIH0nKVxuXG5cdFx0ZnMud3JpdGVGaWxlU3luYyhmaWxlUGF0aCwganNvbiArICdcXG4nLCAndXRmOCcpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZXJyb3IoYEZpbGUgV3JpdGUgRXJyb3I6ICR7ZX1gKVxuXHR9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIExPQUQgREVWSUNFIEpTT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBMb2FkcyB0aGUgYWN0aW9ucyBhcnJheSBmb3IgYSBnaXZlbiBtb2RlbCBmcm9tIHRoZSBjZW50cmFsaXplZCBjYWNoZS5cbiAqIFJldHVybnMgYW4gZW1wdHkgYXJyYXkgaWYgdGhlIG1vZGVsIGlzIG5vdCBmb3VuZC5cbiAqIEBkZXByZWNhdGVkIC0gVGhpcyBmdW5jdGlvbiBpcyBubyBsb25nZXIgbmVlZGVkLiBVc2UgZ2V0RGV2aWNlU2NoZW1hKCkgZnJvbSBjb25maWcudHMgaW5zdGVhZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxvYWRBY3Rpb25zRm9yTW9kZWwoX2RldmljZXNGb2xkZXI6IHN0cmluZywgbW9kZWw6IHN0cmluZyk6IFN0QWN0aW9uW10ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdHJldHVybiBzY2hlbWE/LmNtZFNjaGVtYSA/PyBbXVxufVxuXG4vKipcbiAqIExvYWRzIHRoZSBtb2RlbCBjb25maWd1cmF0aW9uIGZyb20gdGhlIGNlbnRyYWxpemVkIGNhY2hlLlxuICogQGRlcHJlY2F0ZWQgLSBUaGlzIGZ1bmN0aW9uIGlzIG5vIGxvbmdlciBuZWVkZWQuIFVzZSBnZXREZXZpY2VTY2hlbWEoKSBmcm9tIGNvbmZpZy50cyBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZE1vZGVsQ29uZmlnKFxuXHRfZGV2aWNlc0ZvbGRlcjogc3RyaW5nLFxuXHRtb2RlbDogc3RyaW5nLFxuKTogeyBhY3Rpb25zOiBTdEFjdGlvbltdOyByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuIH0ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdHJldHVybiB7XG5cdFx0YWN0aW9uczogc2NoZW1hPy5jbWRTY2hlbWEgPz8gW10sXG5cdFx0cmVmcmVzaEFmdGVyQ29tbWFuZDogc2NoZW1hPy5yZWZyZXNoQWZ0ZXJDb21tYW5kID8/IHRydWUsIC8vIERlZmF1bHQgdG8gdHJ1ZSBpZiBub3Qgc3BlY2lmaWVkXG5cdH1cbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRGZWVkYmFja3MgfSBmcm9tICcuL2J1aWxkLWNvbW1hbmRzLmpzJ1xuaW1wb3J0IHsgcmVzb2x2ZU1vZGVsLCBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMsIGZpbmRBY3Rpb25Gb3JTZXR0aW5nIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRmVlZGJhY2tzJylcblxuLyoqXG4gKiBIZWxwZXIgZnVuY3Rpb24gdG8gZ2V0IGxhYmVsIGZyb20gY2hvaWNlcyBiYXNlZCBvbiB2YWx1ZVxuICovXG5mdW5jdGlvbiBnZXRMYWJlbEZvclZhbHVlKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuXHR2YWx1ZTogbnVtYmVyLFxuKTogc3RyaW5nIHwgbnVtYmVyIHtcblx0Y29uc3Qgc2V0dGluZyA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRpZiAoIXNldHRpbmcgfHwgIUFycmF5LmlzQXJyYXkoc2V0dGluZy5vcHRpb25zKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgJ3ZhbHVlJyBvcHRpb24gd2hpY2ggY29udGFpbnMgdGhlIGNob2ljZXNcblx0Y29uc3QgdmFsdWVPcHRpb24gPSBzZXR0aW5nLm9wdGlvbnMuZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0aWYgKCF2YWx1ZU9wdGlvbiB8fCAhQXJyYXkuaXNBcnJheSh2YWx1ZU9wdGlvbi5jaG9pY2VzKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgY2hvaWNlIHdpdGggbWF0Y2hpbmcgaWRcblx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjOiBhbnkpID0+IGMuaWQgPT09IHZhbHVlKVxuXHRyZXR1cm4gY2hvaWNlPy5sYWJlbCA/PyB2YWx1ZVxufVxuXG4vKipcbiAqIEJ1aWxkIGFuZCB3aXJlIENvbXBhbmlvbiBmZWVkYmFjayBkZWZpbml0aW9uc1xuICogUGF0dGVybiBtYXRjaGVzIGFjdGlvbnMudHMgLSBmaWx0ZXJzIGJ5IGFjdGl2ZSBtb2RlbCBhbmQgd2lyZXMgY2FsbGJhY2tzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVGZWVkYmFja3Moc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdGZWVkYmFja3MgPSBidWlsZEZlZWRiYWNrcygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEZlZWRiYWNrczogYW55ID0ge31cblxuXHQvLyBHZXQgdGhlIGFjdGl2ZSBtb2RlbCB1c2luZyByZXNvbHZlTW9kZWxcblx0Y29uc3QgYWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwoc2VsZi5jb25maWcsIHNlbGYuZGV2aWNlcylcblx0bG9nZ2VyLmluZm8oXG5cdFx0YFVwZGF0ZUZlZWRiYWNrczogYWN0aXZlTW9kZWw9XCIke2FjdGl2ZU1vZGVsfVwiLCBkaXNjb3ZlcmVkSG9zdD1cIiR7c2VsZi5jb25maWcuZGlzY292ZXJlZEhvc3R9XCIsIGRldmljZXMgY291bnQ9JHtzZWxmLmRldmljZXMubGVuZ3RofWAsXG5cdClcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEZFRURCQUNLUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFtmZWVkYmFja0lkLCBmZWVkYmFja10gb2YgT2JqZWN0LmVudHJpZXMocmF3RmVlZGJhY2tzKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGZlZWRiYWNrSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgZmVlZGJhY2tzIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBtb2RlbFxuXHRcdGlmIChtb2RlbCAhPT0gYWN0aXZlTW9kZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBWQUxVRSBGRUVEQkFDSzogUmV0dXJucyBjdXJyZW50IHZhbHVlIGZvciBsb2NhbCB2YXJpYWJsZVxuXHRcdHdpcmVkRmVlZGJhY2tzW2ZlZWRiYWNrSWRdID0ge1xuXHRcdFx0Li4uZmVlZGJhY2ssXG5cdFx0XHRjYWxsYmFjazogKGZlZWRiYWNrRXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snYnVzQ2gnXVxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cdFx0XHRcdGNvbnN0IGN1cnJlbnQgPSBzZWxmLnN0Q29udHJvbGxlci5nZXRTZXR0aW5nVmFsdWUoaXAsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXG5cdFx0XHRcdC8vIENoZWNrIGlmIHVzZXIgd2FudHMgbGFiZWwgaW5zdGVhZCBvZiBudW1lcmljIHZhbHVlXG5cdFx0XHRcdGNvbnN0IHNob3dMYWJlbCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snc2hvd0xhYmVsJ10gPz8gZmFsc2VcblxuXHRcdFx0XHRpZiAoc2hvd0xhYmVsICYmIGN1cnJlbnQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdC8vIFJldHVybiB0aGUgbGFiZWwgZnJvbSBjaG9pY2VzXG5cdFx0XHRcdFx0cmV0dXJuIGdldExhYmVsRm9yVmFsdWUoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQsIGN1cnJlbnQpXG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBSZXR1cm4gbnVtZXJpYyB2YWx1ZSBkaXJlY3RseSBmb3IgbG9jYWwgdmFyaWFibGUgKHR5cGU6ICd2YWx1ZScpXG5cdFx0XHRcdHJldHVybiBjdXJyZW50ID8/IDBcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0c2VsZi5zZXRGZWVkYmFja0RlZmluaXRpb25zKHdpcmVkRmVlZGJhY2tzKVxuXG5cdGxvZ2dlci5pbmZvKGBVcGRhdGVGZWVkYmFja3M6IHdpcmVkIGZlZWRiYWNrczogJHtPYmplY3Qua2V5cyh3aXJlZEZlZWRiYWNrcykubGVuZ3RofWApXG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9CVVNfR0VULFxuXHRDTURfQlVTX1NFVCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX0dFVF9GSVJNV0FSRSxcblx0Q01EX0dMT0JBTF9NSUNfS0lMTCxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfUkVTRVRfREVWSUNFLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0Z2V0Q29tbWFuZE5hbWUsXG5cdG1ha2VTZXR0aW5nSWQsXG5cdHRvSGV4LFxuXHRieXRlc1RvSGV4LFxuXHR0eXBlIERldmljZUluZm8sXG59IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQge1xuXHRwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwsXG5cdHBhcnNlU2V0dGluZ3NSZXNwb25zZSxcblx0Zm9ybWF0UGFyc2VkU2V0dGluZyxcblx0dHlwZSBTdEFjdGlvbixcbn0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcbmltcG9ydCB7XG5cdERBTlRFX01TR19JTkZPX1JFU1BPTlNFLFxuXHRwYXJzZURhbnRlSW5mb1Jlc3BvbnNlLFxuXHRkaXNjb3ZlckRldmljZXMsXG5cdGJ1aWxkRGFudGVJbmZvUmVxdWVzdCxcblx0Z2V0TWFjRm9yRGVzdGluYXRpb24sXG5cdGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uLFxufSBmcm9tICcuL2RhbnRlLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1N0Q29udHJvbGxlcicpXG5cbmV4cG9ydCBjbGFzcyBTdENvbnRyb2xsZXIge1xuXHRwcml2YXRlIHJlYWRvbmx5IGRlZmF1bHRQb3J0OiBudW1iZXIgPSA4NzAwXG5cdHByaXZhdGUgcmVhZG9ubHkgbXVsdGljYXN0R3JvdXAgPSAnMjI0LjAuMC4yMzEnXG5cdHByaXZhdGUgcmVhZG9ubHkgcnhQb3J0ID0gODcwMlxuXG5cdHByaXZhdGUgdHhTb2NrZXQ6IGRncmFtLlNvY2tldFxuXHRwcml2YXRlIHJ4U29ja2V0OiBkZ3JhbS5Tb2NrZXQgLy8gZm9yIHJlY2VpdmluZyByZXNwb25zZXMgKDg3MDIpXG5cdHByaXZhdGUgcGVuZGluZ0Fja3M6IE1hcDxcblx0XHRzdHJpbmcsXG5cdFx0eyByZXNvbHZlOiAoYnVmOiBCdWZmZXIpID0+IHZvaWQ7IHJlamVjdDogKGU6IEVycm9yKSA9PiB2b2lkOyB0aW1lcjogTm9kZUpTLlRpbWVvdXQgfVxuXHQ+XG5cdHByaXZhdGUgam9pbmVkSW50ZXJmYWNlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KCkgLy8gbG9jYWwgSVBzIHdlJ3ZlIGpvaW5lZCBtdWx0aWNhc3Qgb25cblxuXHQvKiogU2VyaWFsaXplcyBvdXRnb2luZyBjb21tYW5kcyBzbyBlYWNoIHdhaXRzIGZvciBBQ0sgYmVmb3JlIHRoZSBuZXh0IGlzIHNlbnQgKi9cblx0cHJpdmF0ZSBzZW5kUXVldWU6IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKVxuXG5cdC8qKiBUcmFja3MgaG93IG1hbnkgY29tbWFuZHMgYXJlIHF1ZXVlZC9pbi1mbGlnaHQsIHRvIGRlZmVyIHJlcXVlc3RBbGxTZXR0aW5ncyAqL1xuXHRwcml2YXRlIHBlbmRpbmdDb21tYW5kQ291bnQgPSAwXG5cblx0LyoqIFJlc29sdmVzIG9uY2UgdHhTb2NrZXQgaXMgYm91bmQgYW5kIHJlYWR5IHRvIHNlbmQgKi9cblx0cHJpdmF0ZSB0eFJlYWR5OiBQcm9taXNlPHZvaWQ+XG5cblx0LyoqIEFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBmb3Igc2V0dGluZ3MgZGVjb2RpbmcgKi9cblx0cHJpdmF0ZSBtb2RlbDogc3RyaW5nID0gJydcblx0cHJpdmF0ZSBhY3Rpb25zOiBTdEFjdGlvbltdID0gW11cblx0cHJpdmF0ZSByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuID0gdHJ1ZSAvLyBEZWZhdWx0IHRvIHRydWUgKG1vc3QgZGV2aWNlcyBuZWVkIGl0KVxuXG5cdC8qKlxuXHQgKiBLbm93biBzdGF0ZSBvZiBldmVyeSBzZXR0aW5nIHBlciBkZXZpY2UgSVAuXG5cdCAqIEtleWVkIGJ5IElQIFx1MjE5MiBNYXAgb2YgXCIke2NtZElkfS8ke3NldHRpbmdJZH1cIiBcdTIxOTIgY3VycmVudCB2YWx1ZSBieXRlLlxuXHQgKiBQb3B1bGF0ZWQgb24gY29ubmVjdCB2aWEgcmVxdWVzdEFsbFNldHRpbmdzKCksIHVwZGF0ZWQgb24gZXZlcnkgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpLlxuXHQgKiBVc2VkIHRvIGRpZmYgaW5jb21pbmcgcHVzaGVzIChjaGFuZ2VkID0gaW5mbywgdW5jaGFuZ2VkID0gZGVidWcpIGFuZCBmb3IgZmVlZGJhY2tzLlxuXHQgKi9cblx0cHJpdmF0ZSBkZXZpY2VTdGF0ZTogTWFwPHN0cmluZywgTWFwPHN0cmluZywgbnVtYmVyPj4gPSBuZXcgTWFwKClcblxuXHQvKipcblx0ICogSVBzIHRoYXQgaGF2ZSBiZWVuIHZlcmlmaWVkIGFnYWluc3QgdGhlIGNvbmZpZ3VyZWQgbW9kZWwgYW5kIGFyZSBhbGxvd2VkXG5cdCAqIHRvIHJlY2VpdmUgU3R1ZGlvLVQgY29tbWFuZHMuIFBvcHVsYXRlZCBieSBhdXRob3JpemVEZXZpY2UoKSBhZnRlciBhXG5cdCAqIHN1Y2Nlc3NmdWwgcHJvYmVEZXZpY2UoKSBtb2RlbCBtYXRjaCwgb3IgYWZ0ZXIgbXVsdGljYXN0IGRpc2NvdmVyeS5cblx0ICogX3NlbmRBd2FpdEFjaygpIHJlamVjdHMgYW55IGRlc3RJcCBub3QgaW4gdGhpcyBzZXQuXG5cdCAqL1xuXHRwcml2YXRlIGF1dGhvcml6ZWRJcHM6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpXG5cblx0LyoqIENhbGxiYWNrcyByZWdpc3RlcmVkIGJ5IGRpc2NvdmVyRGV2aWNlcygpIFx1MjAxNCBrZXllZCBieSBzb3VyY2UgSVAgKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcnlMaXN0ZW5lcnM6IE1hcDxzdHJpbmcsIChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQ+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrIHRvIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlcyB3aGVuIHN0YXRlIGNoYW5nZXMgKi9cblx0cHJpdmF0ZSBmZWVkYmFja0NhbGxiYWNrPzogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZFxuXG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdGxvZ2dlci5pbmZvKCdTdENvbnRyb2xsZXIgaW5pdGlhbGl6ZWQnKVxuXG5cdFx0dGhpcy5wZW5kaW5nQWNrcyA9IG5ldyBNYXAoKVxuXG5cdFx0Ly8gU2VuZCBzb2NrZXQgXHUyMDE0IGJpbmQgdG8gZXBoZW1lcmFsIHBvcnQuIFJlc3BvbnNlcyBhbHdheXMgZ28gdG8gcnhTb2NrZXQgb25cblx0XHQvLyBwb3J0IDg3MDIgKERhbnRlIGhhcmRjb2RlcyB0aGUgcmVzcG9uc2UgZGVzdGluYXRpb24gcG9ydCB0byA4NzAyKS5cblx0XHR0aGlzLnR4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnR4UmVhZHkgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0dGhpcy50eFNvY2tldC5iaW5kKDAsICgpID0+IHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBUWCBzb2NrZXQgYm91bmQgdG8gcG9ydCAkeyh0aGlzLnR4U29ja2V0LmFkZHJlc3MoKSBhcyB7IHBvcnQ6IG51bWJlciB9KS5wb3J0fWApXG5cdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdHRoaXMudHhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBUWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdC8vIFJlY2VpdmUgc29ja2V0IC0gYmluZCB0byBhbGwgYWRkcmVzc2VzIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0c1xuXHRcdHRoaXMucnhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbGlzdGVuaW5nJywgKCkgPT4ge1xuXHRcdFx0Y29uc3QgYWRkciA9IHRoaXMucnhTb2NrZXQuYWRkcmVzcygpXG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBsaXN0ZW5pbmcgb24gJHtKU09OLnN0cmluZ2lmeShhZGRyKX1gKVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5zZXRNdWx0aWNhc3RMb29wYmFjayh0cnVlKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBSWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5oYW5kbGVJbmNvbWluZyhtc2csIHJpbmZvLmFkZHJlc3MpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoYEVycm9yIGhhbmRsaW5nIGluY29taW5nIG1lc3NhZ2U6ICR7X2V9YClcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gQmluZCB0byB3aWxkY2FyZCBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHMgZm9yIGpvaW5lZCBpbnRlcmZhY2VzXG5cdFx0dGhpcy5yeFNvY2tldC5iaW5kKHsgYWRkcmVzczogJzAuMC4wLjAnLCBwb3J0OiB0aGlzLnJ4UG9ydCB9LCAoKSA9PiB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBib3VuZCB0byAwLjAuMC4wOiR7dGhpcy5yeFBvcnR9YClcblx0XHR9KVxuXHR9XG5cblx0cHVibGljIGNsb3NlKCk6IHZvaWQge1xuXHRcdHRyeSB7XG5cdFx0XHRmb3IgKGNvbnN0IGxvY2FsQWRkciBvZiBBcnJheS5mcm9tKHRoaXMuam9pbmVkSW50ZXJmYWNlcykpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR0aGlzLnJ4U29ja2V0LmRyb3BNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy5yeFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFByb3ZpZGUgdGhlIGFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBzbyBpbmNvbWluZyBtZXNzYWdlc1xuXHQgKiBjYW4gYmUgZGVjb2RlZCBpbnRvIGh1bWFuLXJlYWRhYmxlIG5hbWVzLiBDYWxsIGZyb20gbWFpbi50cyBhZnRlciBjb25maWcgbG9hZC5cblx0ICovXG5cdHB1YmxpYyBzZXRNb2RlbChtb2RlbDogc3RyaW5nLCBhY3Rpb25zOiBTdEFjdGlvbltdLCByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xuXHRcdHRoaXMubW9kZWwgPSBtb2RlbFxuXHRcdHRoaXMuYWN0aW9ucyA9IGFjdGlvbnNcblx0XHR0aGlzLnJlZnJlc2hBZnRlckNvbW1hbmQgPSByZWZyZXNoQWZ0ZXJDb21tYW5kXG5cdH1cblxuXHQvKipcblx0ICogU2V0IGNhbGxiYWNrIHRvIHRyaWdnZXIgd2hlbiBkZXZpY2Ugc3RhdGUgY2hhbmdlcyAoZm9yIGZlZWRiYWNrcykuXG5cdCAqIENhbGwgZnJvbSBtYWluLnRzIHRvIHdpcmUgdXAgY2hlY2tGZWVkYmFja3MuXG5cdCAqL1xuXHRwdWJsaWMgc2V0RmVlZGJhY2tDYWxsYmFjayhjYWxsYmFjazogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZCk6IHZvaWQge1xuXHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayA9IGNhbGxiYWNrXG5cdH1cblxuXHQvKiogUmV0dXJucyB0cnVlIGlmIHRoZSBkZXZpY2UgYXQgdGhlIGdpdmVuIElQIGhhcyBiZWVuIGF1dGhvcml6ZWQgdG8gcmVjZWl2ZSBjb21tYW5kcy4gKi9cblx0cHVibGljIGlzRGV2aWNlQXV0aG9yaXplZChpcDogc3RyaW5nKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuYXV0aG9yaXplZElwcy5oYXMoaXApXG5cdH1cblxuXHQvKiogTWFyayBhbiBJUCBhcyB2ZXJpZmllZCBhbmQgYWxsb3dlZCB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgYXV0aG9yaXplRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuYWRkKGlwKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgQXV0aG9yaXplZCBkZXZpY2UgYXQgJHtpcH1gKVxuXHR9XG5cblx0LyoqIFJlbW92ZSBhdXRob3JpemF0aW9uIGZvciBhbiBJUCAoZS5nLiBvbiBjb25maWcgY2hhbmdlIG9yIG1vZGVsIG1pc21hdGNoKS4gKi9cblx0cHVibGljIHJldm9rZURldmljZShpcDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hdXRob3JpemVkSXBzLmRlbGV0ZShpcClcblx0XHR0aGlzLmRldmljZVN0YXRlLmRlbGV0ZShpcClcblx0XHRsb2dnZXIuZGVidWcoYFJldm9rZWQgZGV2aWNlIGF0ICR7aXB9YClcblx0fVxuXG5cdC8qKlxuXHQgKiBTZW5kcyBhIHVuaWNhc3QgRGFudGUgaW5mbyByZXF1ZXN0IHRvIGEgc3BlY2lmaWMgSVAgYW5kIHdhaXRzIGZvciB0aGVcblx0ICogZGV2aWNlIGluZm8gcmVzcG9uc2UuIFJldHVybnMgdGhlIERldmljZUluZm8gaWYgdGhlIGRldmljZSByZXNwb25kcyB3aXRoaW5cblx0ICogdGltZW91dE1zLCBvciBudWxsIGlmIG5vIHJlc3BvbnNlLiBVc2VkIHRvIHZlcmlmeSBhIG1hbnVhbGx5IGNvbmZpZ3VyZWQgSVAuXG5cdCAqIERvZXMgTk9UIHJlcXVpcmUgYXV0aG9yaXphdGlvbiBcdTIwMTQgdGhpcyBpcyBob3cgYXV0aG9yaXphdGlvbiBpcyBlc3RhYmxpc2hlZC5cblx0ICovXG5cdHB1YmxpYyBhc3luYyBwcm9iZURldmljZShpcDogc3RyaW5nLCB0aW1lb3V0TXMgPSAzMDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4oKHJlc29sdmUpID0+IHtcblx0XHRcdGNvbnN0IGtleSA9IGBfX3Byb2JlXyR7aXB9X19gXG5cdFx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXG5cdFx0XHRjb25zdCBmaW5pc2ggPSAocmVzdWx0OiBEZXZpY2VJbmZvIHwgbnVsbCkgPT4ge1xuXHRcdFx0XHRpZiAocmVzb2x2ZWQpIHJldHVyblxuXHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKGtleSlcblx0XHRcdFx0cmVzb2x2ZShyZXN1bHQpXG5cdFx0XHR9XG5cblx0XHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChrZXksIChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdFx0aWYgKGRldmljZS5pcCA9PT0gaXApIGZpbmlzaChkZXZpY2UpXG5cdFx0XHR9KVxuXG5cdFx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gZmluaXNoKG51bGwpLCB0aW1lb3V0TXMpXG5cdFx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdFx0dGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGlwKVxuXHRcdFx0XHQudGhlbihhc3luYyAoKSA9PiB0aGlzLnR4UmVhZHkpXG5cdFx0XHRcdC50aGVuKCgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBxdWVyeSA9IGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpXG5cdFx0XHRcdFx0dGhpcy50eFNvY2tldC5zZW5kKHF1ZXJ5LCB0aGlzLmRlZmF1bHRQb3J0LCBpcCwgKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgUHJvYmUgdG8gJHtpcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRcdFx0ZmluaXNoKG51bGwpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSlcblx0XHRcdFx0LmNhdGNoKChlKSA9PiB7XG5cdFx0XHRcdFx0bG9nZ2VyLndhcm4oYHByb2JlRGV2aWNlIHNldHVwIGZhaWxlZCBmb3IgJHtpcH06ICR7ZX1gKVxuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRmaW5pc2gobnVsbClcblx0XHRcdFx0fSlcblx0XHR9KVxuXHR9XG5cblx0LyoqXG5cdCAqIFNlbmQgYSBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgcmVxdWVzdCB0byB0aGUgZGV2aWNlIGFuZCBzdG9yZSB0aGUgcmVzcG9uc2Vcblx0ICogaW4gZGV2aWNlU3RhdGUuIFJldHVybnMgdGhlIHJhdyByZXNwb25zZSBidWZmZXIgZm9yIHBhcnNpbmcuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEFsbFNldHRpbmdzKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGxvZ2dlci5pbmZvKGBSZXF1ZXN0aW5nIGFsbCBzZXR0aW5ncyBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKFxuXHRcdFx0dGhpcy5tb2RlbCxcblx0XHRcdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRcdFx0dW5kZWZpbmVkLFxuXHRcdFx0dW5kZWZpbmVkLFxuXHRcdFx0dW5kZWZpbmVkLFxuXHRcdFx0ZGV2aWNlSXAsXG5cdFx0XHRmYWxzZSxcblx0XHQpXG5cdFx0Ly8gZGV2aWNlU3RhdGUgaXMgcG9wdWxhdGVkIGJ5IGxvZ1N0UGF5bG9hZCB3aGVuIHRoZSBDTURfR0VUX0FMTF9TRVRUSU5HUyByZXNwb25zZSBhcnJpdmVzXG5cdFx0cmV0dXJuIHJlc3BvbnNlXG5cdH1cblxuXHQvKiogUmV0dXJuIGEgc25hcHNob3Qgb2YgdGhlIGN1cnJlbnQgZGV2aWNlIHN0YXRlIGZvciBhIGdpdmVuIElQIChmb3IgZmVlZGJhY2tzKS4gKi9cblx0cHVibGljIGdldERldmljZVN0YXRlKGRldmljZUlwOiBzdHJpbmcpOiBNYXA8c3RyaW5nLCBudW1iZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoZGV2aWNlSXApID8/IG5ldyBNYXAoKVxuXHR9XG5cblx0LyoqXG5cdCAqIERpc2NvdmVycyBTdHVkaW8gVGVjaG5vbG9naWVzIERhbnRlIGRldmljZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsuXG5cdCAqXG5cdCAqIFN0cmF0ZWd5OlxuXHQgKiAgRGFudGUgZGV2aWNlcyBicm9hZGNhc3QgYSAxLXNlY29uZCBhbm5vdW5jZSB0byBtdWx0aWNhc3QgMjI0LjAuMC4yMzM6ODcwOC5cblx0ICogIFdlIGxpc3RlbiBvbiB0aGF0IGdyb3VwLCBjb2xsZWN0IHNvdXJjZSBJUHMsIHRoZW4gc2VuZCBhIHVuaWNhc3QgZGV2aWNlIGluZm9cblx0ICogIHJlcXVlc3QgKDB4MDAyMCkgdG8gZWFjaCBuZXcgSVAgb24gcG9ydCA4NzAwLiBUaGUgZGV2aWNlIHJlc3BvbmRzIHRvIG91ciBJUFxuXHQgKiAgb24gcG9ydCA4NzAyIChyeFNvY2tldCksIHdoZXJlIGhhbmRsZUluY29taW5nKCkgcGlja3MgaXQgdXAgYW5kIGZpcmVzIHRoZVxuXHQgKiAgZGlzY292ZXJ5TGlzdGVuZXJzIGNhbGxiYWNrLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIGRpc2NvdmVyRGV2aWNlcyh0aW1lb3V0TXMgPSA1MDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvW10+IHtcblx0XHQvLyBSZWdpc3RlciBsaXN0ZW5lciBcdTIwMTQgaGFuZGxlSW5jb21pbmcoKSBmaXJlcyB0aGlzIGZvciBlYWNoIDB4MDE3MCByZXNwb25zZVxuXHRcdGNvbnN0IERJU0NPVkVSWV9LRVkgPSAnX19kaXNjb3ZlcnlfXydcblx0XHRjb25zdCBmb3VuZERldmljZXM6IERldmljZUluZm9bXSA9IFtdXG5cblx0XHRjb25zdCBvbkRldmljZUZvdW5kID0gKGRldmljZTogRGV2aWNlSW5mbykgPT4ge1xuXHRcdFx0Zm91bmREZXZpY2VzLnB1c2goZGV2aWNlKVxuXHRcdH1cblxuXHRcdC8vIFJlZ2lzdGVyIHRoZSBjYWxsYmFjayBzbyBoYW5kbGVJbmNvbWluZygpIGNhbiBpbnZva2UgaXQgd2hlbiAweDAxNzAgYXJyaXZlc1xuXHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChESVNDT1ZFUllfS0VZLCBvbkRldmljZUZvdW5kKVxuXG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHRoaXMudHhSZWFkeVxuXHRcdFx0Ly8gZGlzY292ZXJEZXZpY2VzKCkgaW4gZGFudGUudHMgaGFuZGxlcyB0aGUgYW5ub3VuY2UgbGlzdGVuaW5nIGFuZCBxdWVyeSBzZW5kaW5nXG5cdFx0XHQvLyBSZXNwb25zZXMgY29tZSBiYWNrIHRvIHJ4U29ja2V0IFx1MjE5MiBoYW5kbGVJbmNvbWluZygpIFx1MjE5MiBkaXNjb3ZlcnlMaXN0ZW5lcnNcblx0XHRcdGF3YWl0IGRpc2NvdmVyRGV2aWNlcyhcblx0XHRcdFx0dGhpcy50eFNvY2tldCxcblx0XHRcdFx0b25EZXZpY2VGb3VuZCwgLy8gZGFudGUudHMgZG9lc24ndCBhY3R1YWxseSB1c2UgdGhpcywgYnV0IGtlcHQgZm9yIGNvbXBhdGliaWxpdHlcblx0XHRcdFx0YXN5bmMgKGRlc3RJcCkgPT4gdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcCksXG5cdFx0XHRcdHRpbWVvdXRNcyxcblx0XHRcdClcblx0XHRcdHJldHVybiBmb3VuZERldmljZXNcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKERJU0NPVkVSWV9LRVkpXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFJlcXVlc3RzIGRldmljZSBmaXJtd2FyZSB2ZXJzaW9uIHZpYSBTdHVkaW8tVCBwcm90b2NvbCAoQ01EX0dFVF9GSVJNV0FSRSkuXG5cdCAqIFJldHVybnMgdGhlIGZpcm13YXJlIHZlcnNpb24gc3RyaW5nIChlLmcuLCBcIjMuMDFcIiwgXCIyLjJcIiwgXCIxLjA1XCIpLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHJlcXVlc3RGaXJtd2FyZVZlcnNpb24oZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgZmlybXdhcmUgdmVyc2lvbiBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKFxuXHRcdFx0dGhpcy5tb2RlbCxcblx0XHRcdENNRF9HRVRfRklSTVdBUkUsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHRkZXZpY2VJcCxcblx0XHRcdGZhbHNlLFxuXHRcdClcblxuXHRcdC8vIFJlc3BvbnNlIHN0cnVjdHVyZTogW2hlYWRlcl0gMHg1YSAweDgwIFtmaXJtd2FyZV9kYXRhXSBDUkNcblx0XHQvLyBGaXJtd2FyZSBkYXRhIHN0YXJ0cyBhdCBieXRlIDI2ICgyNC1ieXRlIGhlYWRlciArIDB4NWEgKyAweDgwKVxuXHRcdGNvbnN0IGRhdGFTdGFydCA9IDI2XG5cblx0XHRpZiAocmVzcG9uc2UubGVuZ3RoIDwgZGF0YVN0YXJ0ICsgMykge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEZpcm13YXJlIHJlc3BvbnNlIHRvbyBzaG9ydDogJHtyZXNwb25zZS5sZW5ndGh9IGJ5dGVzYClcblx0XHRcdHJldHVybiAnVW5rbm93bidcblx0XHR9XG5cblx0XHQvLyBGaXJtd2FyZSBmb3JtYXQ6IFt1bmtub3duX2J5dGUsIG1ham9yLCBtaW5vcl1cblx0XHRjb25zdCBtYWpvciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDFdXG5cdFx0Y29uc3QgbWlub3IgPSByZXNwb25zZVtkYXRhU3RhcnQgKyAyXVxuXG5cdFx0bGV0IG1pbm9yU3RyOiBzdHJpbmdcblx0XHRpZiAobWlub3IgPT09IDIpIHtcblx0XHRcdG1pbm9yU3RyID0gJzInIC8vIFNwZWNpYWwgY2FzZTogMi4yIG5vdCAyLjAyXG5cdFx0fSBlbHNlIGlmIChtaW5vciA8IDEwKSB7XG5cdFx0XHRtaW5vclN0ciA9IG1pbm9yLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKSAvLyAxXHUyMTkyXCIwMVwiLCA1XHUyMTkyXCIwNVwiXG5cdFx0fSBlbHNlIHtcblx0XHRcdG1pbm9yU3RyID0gbWlub3IudG9TdHJpbmcoKSAvLyAxMCtcdTIxOTJcIjEwXCIsIFwiMjBcIiwgZXRjXG5cdFx0fVxuXG5cdFx0Y29uc3QgZmlybXdhcmUgPSBgJHttYWpvcn0uJHttaW5vclN0cn1gXG5cblx0XHRsb2dnZXIuaW5mbyhgRmlybXdhcmUgdmVyc2lvbjogJHtmaXJtd2FyZX1gKVxuXHRcdHJldHVybiBmaXJtd2FyZVxuXHR9XG5cblx0LyoqXG5cdCAqIEVuc3VyZSB3ZSd2ZSBqb2luZWQgdGhlIG11bHRpY2FzdCBncm91cCBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIGRlc3RJcC5cblx0ICogT3B0aW9uIEIgYmVoYXZpb3I6IGpvaW4gT05MWSB0aGUgaW50ZXJmYWNlIHVzZWQgdG8gcmVhY2ggdGhlIGRldmljZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhd2FpdCBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHRpZiAoIWxvY2FsQWRkcikge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGRldGVybWluZSBsb2NhbCBhZGRyZXNzIGZvciBkZXN0aW5hdGlvbiAke2Rlc3RJcH1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0aWYgKHRoaXMuam9pbmVkSW50ZXJmYWNlcy5oYXMobG9jYWxBZGRyKSkge1xuXHRcdFx0XHQvLyBhbHJlYWR5IGpvaW5lZFxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5hZGRNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0dGhpcy5qb2luZWRJbnRlcmZhY2VzLmFkZChsb2NhbEFkZHIpXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBKb2luZWQgbXVsdGljYXN0ICR7dGhpcy5tdWx0aWNhc3RHcm91cH0gb24gJHtsb2NhbEFkZHJ9YClcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gam9pbiBtdWx0aWNhc3Qgb24gJHtsb2NhbEFkZHJ9OiAke1N0cmluZyhfZSl9YClcblx0XHRcdH1cblx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYGVuc3VyZU1lbWJlcnNoaXBGb3IgZmFpbGVkOiAke19lfWApXG5cdFx0fVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHNlbmRBd2FpdEFjayhcblx0XHRtb2RlbDogc3RyaW5nLFxuXHRcdGNtZElkOiBudW1iZXIsXG5cdFx0YnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHRzZXR0aW5nSWQ6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHR2YWx1ZTogdW5rbm93bixcblx0XHRkZXN0SXA6IHN0cmluZyxcblx0XHRhZGRMZW4gPSB0cnVlLFxuXHQpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudCsrXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPEJ1ZmZlcj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0dGhpcy5zZW5kUXVldWUgPSB0aGlzLnNlbmRRdWV1ZS50aGVuKGFzeW5jICgpID0+XG5cdFx0XHRcdHRoaXMuX3NlbmRBd2FpdEFjayhtb2RlbCwgY21kSWQsIGJ1c0NoLCBzZXR0aW5nSWQsIHZhbHVlLCBkZXN0SXAsIGFkZExlbilcblx0XHRcdFx0XHQudGhlbigoYnVmKSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQtLVxuXHRcdFx0XHRcdFx0Ly8gT25seSB0cmlnZ2VyIHJlcXVlc3RBbGxTZXR0aW5ncyB3aGVuIHRoZSBxdWV1ZSBpcyBmdWxseSBkcmFpbmVkXG5cdFx0XHRcdFx0XHRpZiAodGhpcy5wZW5kaW5nQ29tbWFuZENvdW50ID09PSAwICYmIHRoaXMucmVmcmVzaEFmdGVyQ29tbWFuZCAmJiBzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdFx0XHR0aGlzLnJlcXVlc3RBbGxTZXR0aW5ncyhkZXN0SXApLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0LmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHRyZWplY3QoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIgOiBuZXcgRXJyb3IoU3RyaW5nKGVycikpKVxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIF9zZW5kQXdhaXRBY2soXG5cdFx0bW9kZWw6IHN0cmluZyxcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0KTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRjb25zdCB0aW1lb3V0TXMgPSAyMDAwXG5cblx0XHQvLyBSZWplY3QgY29tbWFuZHMgdG8gdW52ZXJpZmllZCBkZXZpY2VzLiBwcm9iZURldmljZSgpIGJ5cGFzc2VzIHRoaXNcblx0XHQvLyBiZWNhdXNlIGl0IHVzZXMgdGhlIERhbnRlIHByb3RvY29sIGRpcmVjdGx5IHZpYSB0eFNvY2tldCwgbm90IHNlbmRBd2FpdEFjay5cblx0XHRpZiAoIXRoaXMuYXV0aG9yaXplZElwcy5oYXMoZGVzdElwKSkge1xuXHRcdFx0dGhyb3cgbmV3IEVycm9yKGBEZXZpY2UgYXQgJHtkZXN0SXB9IGlzIG5vdCBhdXRob3JpemVkIFx1MjAxNCB2ZXJpZnkgdGhlIElQIGFuZCBtb2RlbCBtYXRjaCBiZWZvcmUgc2VuZGluZyBjb21tYW5kc2ApXG5cdFx0fVxuXG5cdFx0Ly8gRW5zdXJlIHdlIGFyZSBsaXN0ZW5pbmcgZm9yIHJlcGxpZXMgb24gdGhlIGludGVyZmFjZSB0aGF0IHdpbGwgcmVjZWl2ZSB0aGVtXG5cdFx0YXdhaXQgdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcClcblxuXHRcdGNvbnN0IGRhdGFCbG9jazogbnVtYmVyW10gPSBbXVxuXHRcdGlmIChzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCkgZGF0YUJsb2NrLnB1c2goc2V0dGluZ0lkICYgMHhmZilcblx0XHRpZiAodmFsdWUgIT09IHVuZGVmaW5lZCkgZGF0YUJsb2NrLnB1c2goLi4uU3RDb250cm9sbGVyLmJ1aWxkVmFsdWVCeXRlcyh2YWx1ZSkpXG5cblx0XHRjb25zdCBwYXlsb2FkQm9keTogbnVtYmVyW10gPSBbMHg1YSwgY21kSWQgJiAweGZmXVxuXG5cdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHBheWxvYWRCb2R5LnB1c2goYnVzQ2ggJiAweGZmKVxuXHRcdGlmIChhZGRMZW4pIHBheWxvYWRCb2R5LnB1c2goZGF0YUJsb2NrLmxlbmd0aClcblxuXHRcdGlmIChkYXRhQmxvY2subGVuZ3RoID4gMCkgcGF5bG9hZEJvZHkucHVzaCguLi5kYXRhQmxvY2spXG5cblx0XHRjb25zdCBjcmMgPSBTdENvbnRyb2xsZXIuY3JjOER2YlMyKHBheWxvYWRCb2R5KVxuXHRcdGNvbnN0IHBheWxvYWRXaXRoQ3JjID0gQnVmZmVyLmZyb20oWy4uLnBheWxvYWRCb2R5LCBjcmNdKVxuXG5cdFx0Y29uc3QgdG90YWxMZW4gPSAyNCArIHBheWxvYWRXaXRoQ3JjLmxlbmd0aFxuXHRcdGNvbnN0IGhlYWRlciA9IGF3YWl0IFN0Q29udHJvbGxlci5idWlsZEhlYWRlcih0b3RhbExlbiwgZGVzdElwKVxuXHRcdGNvbnN0IHBhY2tldCA9IEJ1ZmZlci5jb25jYXQoW2hlYWRlciwgcGF5bG9hZFdpdGhDcmNdKVxuXG5cdFx0Ly8gSHVtYW4tcmVhZGFibGUgaW5mbyBsb2cgZm9yIHRoZSBvdXRnb2luZyBjb21tYW5kXG5cdFx0Y29uc3QgY21kTmFtZSA9IGdldENvbW1hbmROYW1lKGNtZElkKVxuXHRcdGlmIChzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0XHRcdGxldCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblxuXHRcdFx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2gsIHRyeSB0byBmaW5kIGFjdGlvbiB3aXRoIGlkQWRkIG9wdGlvblxuXHRcdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdFx0YWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IHtcblx0XHRcdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZElkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRjb25zdCBoYXNJZEFkZCA9IGEub3B0aW9ucz8uc29tZSgob3B0KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdFx0aWYgKCFoYXNJZEFkZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0cmV0dXJuIHNldHRpbmdJZCA+PSBhLmlkICYmIHNldHRpbmdJZCA8IGEuaWQgKyAxMFxuXHRcdFx0XHR9KVxuXHRcdFx0fVxuXG5cdFx0XHRsZXQgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gJ1Vua25vd24gU2V0dGluZydcblxuXHRcdFx0Ly8gSWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkIGFuZCB0aGUgc2V0dGluZyBpZCBpcyBvZmZzZXQgZnJvbSBiYXNlLCBpbmNsdWRlIGNoYW5uZWwgaW5mb1xuXHRcdFx0aWYgKGFjdGlvbikge1xuXHRcdFx0XHRjb25zdCBoYXNJZEFkZCA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0aWYgKGhhc0lkQWRkICYmIHNldHRpbmdJZCAhPT0gYWN0aW9uLmlkKSB7XG5cdFx0XHRcdFx0Y29uc3QgY2hhbm5lbE9mZnNldCA9IHNldHRpbmdJZCAtIGFjdGlvbi5pZFxuXHRcdFx0XHRcdHNldHRpbmdOYW1lID0gYCR7c2V0dGluZ05hbWV9IENoJHtjaGFubmVsT2Zmc2V0ICsgMX1gXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Ly8gTG9vayBmb3IgdGhlIHZhbHVlIG9wdGlvbiB0byBnZXQgY2hvaWNlc1xuXHRcdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBhY3Rpb24/Lm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAndmFsdWUnKVxuXHRcdFx0Y29uc3QgY2hvaWNlcyA9IHZhbHVlT3B0aW9uPy5jaG9pY2VzXG5cdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gU3RDb250cm9sbGVyLmJ1aWxkVmFsdWVCeXRlcyh2YWx1ZSlcblx0XHRcdGNvbnN0IHZhbHVlTnVtID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdW5kZWZpbmVkXG5cdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9IGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXG5cdFx0XHRjb25zdCBjbWRIZXggPSB0b0hleChjbWRJZClcblx0XHRcdGNvbnN0IGlkSGV4ID0gdG9IZXgoc2V0dGluZ0lkKVxuXHRcdFx0Y29uc3QgdmFsSGV4ID0gYnl0ZXNUb0hleCh2YWx1ZUJ5dGVzKVxuXHRcdFx0Y29uc3QgdmFsRGVjID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdmFsdWVCeXRlcy5qb2luKCcsJylcblxuXHRcdFx0Y29uc3QgcHJlZml4ID0gYGNtZDoke2NtZEhleH0gaWQ6JHtpZEhleH0gdmFsOiR7dmFsSGV4fWBcblx0XHRcdGNvbnN0IHN1ZmZpeCA9IGNob2ljZUxhYmVsID8gYCR7c2V0dGluZ05hbWV9OiAke2Nob2ljZUxhYmVsfSAoJHt2YWxEZWN9KWAgOiBgJHtzZXR0aW5nTmFtZX06ICR7dmFsRGVjfWBcblxuXHRcdFx0bG9nZ2VyLmluZm8oYFRYICR7ZGVzdElwfSB8ICR7cHJlZml4fSB8ICR7c3VmZml4fWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBUWCAke2Rlc3RJcH0gfCAke2NtZE5hbWV9YClcblx0XHR9XG5cdFx0bG9nZ2VyLmRlYnVnKGBTZW5kaW5nIHBhY2tldCB0byAke2Rlc3RJcH06ICR7cGFja2V0LnRvU3RyaW5nKCdoZXgnKX1gKVxuXG5cdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cblx0XHRjb25zdCBrZXkgPSBgJHtkZXN0SXB9OiR7Y21kSWR9YFxuXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPEJ1ZmZlcj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGBUaW1lb3V0IHdhaXRpbmcgZm9yIEFDSyBmcm9tIE1vZGVsJHttb2RlbH0gYXQgJHtkZXN0SXB9Ojg3MDBgKSlcblx0XHRcdH0sIHRpbWVvdXRNcylcblxuXHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5zZXQoa2V5LCB7XG5cdFx0XHRcdHJlc29sdmU6IChidWYpID0+IHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVzb2x2ZShidWYpXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHJlamVjdDogKGVycikgPT4ge1xuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZWplY3QoZXJyKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHR0aW1lcixcblx0XHRcdH0pXG5cblx0XHRcdHRoaXMudHhTb2NrZXQuc2VuZChwYWNrZXQsIHRoaXMuZGVmYXVsdFBvcnQsIGRlc3RJcCwgKGVycikgPT4ge1xuXHRcdFx0XHRpZiAoZXJyKSB7XG5cdFx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHRcdFx0fVxuXHRcdFx0fSlcblx0XHR9KVxuXHR9XG5cblx0cHJpdmF0ZSBoYW5kbGVJbmNvbWluZyhtc2c6IEJ1ZmZlciwgc3JjSXA6IHN0cmluZykge1xuXHRcdGlmIChtc2cubGVuZ3RoIDwgNCkgcmV0dXJuXG5cdFx0aWYgKG1zZ1swXSAhPT0gMHhmZiB8fCBtc2dbMV0gIT09IDB4ZmYpIHJldHVyblxuXG5cdFx0Y29uc3QgbXNnVHlwZSA9IG1zZy5yZWFkVUludDE2QkUoMilcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSAoMHgwMTcwKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBUaGVzZSBoYXZlIFwiQXVkaW5hdGVcIiBhdCBvZmZzZXQgMTYsIG5vdCBcIlN0dWRpby1UXCIgXHUyMDE0IGhhbmRsZSBiZWZvcmVcblx0XHQvLyB0aGUgU3R1ZGlvLVQgc2lnbmF0dXJlIGNoZWNrIGJlbG93LlxuXHRcdGlmIChtc2dUeXBlID09PSBEQU5URV9NU0dfSU5GT19SRVNQT05TRSAmJiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5zaXplID4gMCkge1xuXHRcdFx0Y29uc3QgZGV2aWNlID0gcGFyc2VEYW50ZUluZm9SZXNwb25zZShtc2csIHNyY0lwKVxuXHRcdFx0aWYgKGRldmljZSkge1xuXHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0YERhbnRlIGluZm8gcmVzcG9uc2UgZnJvbSAke3NyY0lwfTogYCArXG5cdFx0XHRcdFx0XHRgRGV2aWNlSUQ9XCIke2RldmljZS5uYW1lfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNb2RlbD1cIiR7ZGV2aWNlLm1vZGVsfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNb2RlbE5hbWU9XCIke2RldmljZS5tb2RlbE5hbWV9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1hbnVmYWN0dXJlcj1cIiR7ZGV2aWNlLm1hbnVmYWN0dXJlcn1cImAsXG5cdFx0XHRcdClcblxuXHRcdFx0XHQvLyBPbmx5IGFjY2VwdCBTdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZXMgKGlkZW50aWZpZWQgYnkgRGV2aWNlSUQgXCJTdHVkaW8tVFwiKVxuXHRcdFx0XHRpZiAoZGV2aWNlLm5hbWUgPT09ICdTdHVkaW8tVCcpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGNiIG9mIHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnZhbHVlcygpKSB7XG5cdFx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0XHRjYihkZXZpY2UpXG5cdFx0XHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgSWdub3Jpbmcgbm9uLVN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlOiBEZXZpY2VJRD1cIiR7ZGV2aWNlLm5hbWV9XCIgQCAke3NyY0lwfWApXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGlmIChtc2cubGVuZ3RoIDwgMjUpIHJldHVyblxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIFN0dWRpby1UIGNvbnRyb2wgcHJvdG9jb2wgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Y29uc3Qgc2lnID0gbXNnLnN1YmFycmF5KDE2LCAyNClcblx0XHRpZiAoc2lnLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnU3R1ZGlvLVQnKSByZXR1cm5cblxuXHRcdC8vIFBheWxvYWQgc3RhcnRzIGF0IG9mZnNldCAyNFxuXHRcdC8vIExheW91dDogWzB4NWFdIFtjbWRJZHwweDgwXSBbZGF0YS4uLl0gW2NyY11cblx0XHRjb25zdCBzdFBheWxvYWQgPSBtc2cuc3ViYXJyYXkoMjQpXG5cdFx0aWYgKHN0UGF5bG9hZC5sZW5ndGggPCAyKSByZXR1cm5cblx0XHRpZiAoc3RQYXlsb2FkWzBdICE9PSAweDVhKSByZXR1cm5cblxuXHRcdC8vIERldmljZSByZXBsaWVzIHdpdGggY21kIHwgMHg4MFxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGlzUmVzcG9uc2UgPSAocmVzcENtZElkICYgMHg4MCkgIT09IDBcblx0XHRjb25zdCBvcmlnaW5hbENtZElkID0gcmVzcENtZElkICYgMHg3ZiAvLyBzdHJpcCB0aGUgcmVzcG9uc2UgZmxhZ1xuXG5cdFx0Ly8gTG9nIHRoZSBwYXlsb2FkICh3b3JrcyBmb3IgYm90aCByZXF1ZXN0cyBhbmQgcmVzcG9uc2VzKVxuXHRcdHRoaXMubG9nU3RQYXlsb2FkKHNyY0lwLCBvcmlnaW5hbENtZElkLCBtc2csIHN0UGF5bG9hZCwgaXNSZXNwb25zZSlcblxuXHRcdC8vIE9ubHkgcHJvY2VzcyBhcyBBQ0sgaWYgdGhpcyBpcyBhIHJlc3BvbnNlIHRvIG91ciByZXF1ZXN0XG5cdFx0aWYgKGlzUmVzcG9uc2UpIHtcblx0XHRcdGNvbnN0IGtleSA9IGAke3NyY0lwfToke29yaWdpbmFsQ21kSWR9YFxuXHRcdFx0Y29uc3QgcGVuZGluZyA9IHRoaXMucGVuZGluZ0Fja3MuZ2V0KGtleSlcblx0XHRcdGlmIChwZW5kaW5nKSB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cGVuZGluZy5yZXNvbHZlKG1zZylcblx0XHRcdH1cblx0XHR9XG5cdFx0Ly8gVW5zb2xpY2l0ZWQgbWVzc2FnZXMgYW5kIHJlcXVlc3RzIGZyb20gb3RoZXIgc291cmNlcyBhcmUgbG9nZ2VkIGFib3ZlXG5cdH1cblxuXHQvKipcblx0ICogRGVjb2RlcyBhbmQgbG9ncyBhIFN0dWRpby1UIHJlc3BvbnNlIHBheWxvYWQuXG5cdCAqIFJlY2VpdmVzIGJvdGggdGhlIGZ1bGwgbXNnIChmb3IgcGFyc2VycyB0aGF0IG5lZWQgdGhlIFN0dWRpby1UIGhlYWRlcilcblx0ICogYW5kIHN0UGF5bG9hZCAobXNnLnN1YmFycmF5KDI0KSwgZm9yIGRpcmVjdCBieXRlIGFjY2VzcykuXG5cdCAqXG5cdCAqIHN0UGF5bG9hZCBsYXlvdXQ6XG5cdCAqICAgWzBdICAgICAgMHg1YSAgbWFnaWNcblx0ICogICBbMV0gICAgICBjbWRJZCB8IDB4ODBcblx0ICogICBbMi4uLTJdICBkYXRhIGJ5dGVzXG5cdCAqICAgWy0xXSAgICAgQ1JDLTgvRFZCLVMyXG5cdCAqL1xuXHRwcml2YXRlIGxvZ1N0UGF5bG9hZChzcmNJcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBtc2c6IEJ1ZmZlciwgc3RQYXlsb2FkOiBCdWZmZXIsIGlzUmVzcG9uc2UgPSB0cnVlKTogdm9pZCB7XG5cdFx0Y29uc3QgY21kTmFtZSA9IGBjbWRfJHt0b0hleChjbWRJZCl9YFxuXHRcdGNvbnN0IGRhdGEgPSBzdFBheWxvYWQuc3ViYXJyYXkoMiwgc3RQYXlsb2FkLmxlbmd0aCAtIDEpIC8vIHN0cmlwIG1hZ2ljK2NtZElkIGhlYWRlciBhbmQgQ1JDXG5cblx0XHQvLyBTaG93IGNvbXBsZXRlIHBheWxvYWQgc3RydWN0dXJlOiBbMHg1YV0gW2NtZElkfDB4ODBdIFtkYXRhIGJ5dGVzLi4uXSBbY3JjXVxuXHRcdGNvbnN0IG1hZ2ljID0gc3RQYXlsb2FkWzBdXG5cdFx0Y29uc3QgcmVzcENtZElkID0gc3RQYXlsb2FkWzFdXG5cdFx0Y29uc3QgY3JjID0gc3RQYXlsb2FkW3N0UGF5bG9hZC5sZW5ndGggLSAxXVxuXHRcdGNvbnN0IGZ1bGxTdHJ1Y3R1cmUgPSBgW21hZ2ljOiR7dG9IZXgobWFnaWMpfSBjbWQ6JHt0b0hleChyZXNwQ21kSWQpfSBkYXRhOiR7ZGF0YS50b1N0cmluZygnaGV4Jyl9IGNyYzoke3RvSGV4KGNyYyl9XWBcblxuXHRcdC8vIERldGVybWluZSBkaXJlY3Rpb24gcHJlZml4XG5cdFx0Y29uc3QgZGlyZWN0aW9uID0gaXNSZXNwb25zZSA/ICdSWCcgOiAnU05JRkYnXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIGFuZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gUGFyc2UgYWxsIHNldHRpbmdzLCBkaWZmIGFnYWluc3QgZGV2aWNlU3RhdGUsIGxvZyBjaGFuZ2VkIGF0IGluZm8gLyB1bmNoYW5nZWQgYXQgZGVidWcsXG5cdFx0Ly8gdGhlbiB1cGRhdGUgZGV2aWNlU3RhdGUuIENNRF9HRVRfQUxMX1NFVFRJTkdTIGFsc28gc2VydmVzIGFzIHRoZSBpbml0aWFsIHN0YXRlIHBvcHVsYXRpb24gb24gY29ubmVjdC5cblx0XHRpZiAoY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTIHx8IGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0aWYgKCF0aGlzLm1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ3MgPVxuXHRcdFx0XHRcdGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSFxuXHRcdFx0XHRcdFx0PyBwYXJzZVNldHRpbmdzUmVzcG9uc2UodGhpcy5tb2RlbCwgbXNnKVxuXHRcdFx0XHRcdFx0OiBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwodGhpcy5tb2RlbCwgbXNnKVxuXG5cdFx0XHRcdGNvbnN0IHByZXZTdGF0ZSA9IHRoaXMuZGV2aWNlU3RhdGUuZ2V0KHNyY0lwKSA/PyBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpXG5cdFx0XHRcdGNvbnN0IG5ld1N0YXRlID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4ocHJldlN0YXRlKSAvLyBjb3B5IFx1MjAxNCB1cGRhdGUgaW4gcGxhY2VcblxuXHRcdFx0XHRmb3IgKGNvbnN0IHMgb2Ygc2V0dGluZ3MpIHtcblx0XHRcdFx0XHRjb25zdCBzdGF0ZUtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgcy5jbWRfaWQsIHMuaWQsIHMuYnVzQ2gpXG5cdFx0XHRcdFx0Ly8gRm9yIFJHQiBjb2xvcnMgKDMgYnl0ZXMpLCBwYWNrIGludG8gc2luZ2xlIG51bWJlcjogKFIgPDwgMTYpIHwgKEcgPDwgOCkgfCBCXG5cdFx0XHRcdFx0Y29uc3QgbmV3VmFsdWUgPVxuXHRcdFx0XHRcdFx0cy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0XHRcdFx0XHQ/IChzLnZhbHVlQnl0ZXNbMF0gPDwgMTYpIHwgKHMudmFsdWVCeXRlc1sxXSA8PCA4KSB8IHMudmFsdWVCeXRlc1syXVxuXHRcdFx0XHRcdFx0XHQ6IChzLnZhbHVlQnl0ZXNbMF0gPz8gMClcblx0XHRcdFx0XHRjb25zdCBwcmV2VmFsdWUgPSBwcmV2U3RhdGUuZ2V0KHN0YXRlS2V5KVxuXHRcdFx0XHRcdGNvbnN0IGNoYW5nZWQgPSBwcmV2VmFsdWUgPT09IHVuZGVmaW5lZCB8fCBwcmV2VmFsdWUgIT09IG5ld1ZhbHVlXG5cblx0XHRcdFx0XHRuZXdTdGF0ZS5zZXQoc3RhdGVLZXksIG5ld1ZhbHVlKVxuXG5cdFx0XHRcdFx0Y29uc3QgZm9ybWF0dGVkID0gZm9ybWF0UGFyc2VkU2V0dGluZyhzLCB0aGlzLmFjdGlvbnMpXG5cdFx0XHRcdFx0aWYgKGNoYW5nZWQpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5pbmZvKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdFx0Ly8gVHJpZ2dlciBmZWVkYmFjayB1cGRhdGUgXHUyMDE0IHVzZSBiYXNlIGtleSB3aXRob3V0IGJ1c0NoIHNvIGl0IG1hdGNoZXMgdGhlIGZlZWRiYWNrIGRlZmluaXRpb24gSURcblx0XHRcdFx0XHRcdGlmICh0aGlzLmZlZWRiYWNrQ2FsbGJhY2spIHtcblx0XHRcdFx0XHRcdFx0Y29uc3QgYmFzZUZlZWRiYWNrS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgcy5pZClcblx0XHRcdFx0XHRcdFx0Ly9sb2dnZXIuZGVidWcoYFRyaWdnZXJpbmcgZmVlZGJhY2sgdXBkYXRlIGZvciBrZXk6ICR7YmFzZUZlZWRiYWNrS2V5fWApXG5cdFx0XHRcdFx0XHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayhiYXNlRmVlZGJhY2tLZXkpXG5cdFx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgZmVlZGJhY2tDYWxsYmFjayBub3Qgc2V0IFx1MjAxNCBza2lwcGluZyBmZWVkYmFjayB1cGRhdGUgZm9yICR7c3RhdGVLZXl9YClcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLmRldmljZVN0YXRlLnNldChzcmNJcCwgbmV3U3RhdGUpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgcGFyc2UgZmFpbGVkOiAke2V9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQWxsIG90aGVyIGNvbW1hbmRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGNvbnN0IGRlY29kZWQgPSB0aGlzLmRlY29kZVN0RGF0YShjbWRJZCwgZGF0YSlcblx0XHRpZiAoZGVjb2RlZCkge1xuXHRcdFx0bG9nZ2VyLmluZm8oYCR7ZGlyZWN0aW9ufSAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9IHwgJHtkZWNvZGVkfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEF0dGVtcHRzIHRvIGRlY29kZSB0aGUgZGF0YSBieXRlcyBvZiBhIFN0dWRpby1UIHJlc3BvbnNlIGludG8gYVxuXHQgKiBodW1hbi1yZWFkYWJsZSBzdHJpbmcuIFJldHVybnMgbnVsbCB0byBmYWxsIGJhY2sgdG8gcmF3IGhleC5cblx0ICpcblx0ICogbXNnIGlzIHRoZSBmdWxsIHBhY2tldCBidWZmZXIgXHUyMDE0IHJlcXVpcmVkIGJ5IHRoZSBzZXR0aW5ncyBwYXJzZXJzIHdoaWNoXG5cdCAqIGxvY2F0ZSB0aGUgU3R1ZGlvLVQgc2lnbmF0dXJlIHRoZW1zZWx2ZXMuXG5cdCAqL1xuXHRwcml2YXRlIGRlY29kZVN0RGF0YShjbWRJZDogbnVtYmVyLCBkYXRhOiBCdWZmZXIpOiBzdHJpbmcgfCBudWxsIHtcblx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDApIHJldHVybiAnQUNLJ1xuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIENoZWNrIGZvciBzaW5nbGUtYnl0ZSByZXNwb25zZXMgKEFDSyBvciBlcnJvcikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0aWYgKGRhdGEubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRpZiAoZGF0YVswXSA9PT0gMHgwMCkge1xuXHRcdFx0XHRyZXR1cm4gJ0FDSyBvaydcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHJldHVybiBgRVJST1IgJHt0b0hleChkYXRhWzBdKX1gXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0c3dpdGNoIChjbWRJZCkge1xuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9ERVZfU1BFQyAoMHgwZCk6IHNpbmdsZS1ieXRlIEFDSyBvciBlY2hvIG9mIGFwcGxpZWQgc2V0dGluZyBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIERldmljZSBzZW5kcyB0d28gQ01EX0RFVl9TUEVDIHBhY2tldHMgaW4gcmVzcG9uc2UgdG8gYSBzZXQ6XG5cdFx0XHQvLyAgIDEuIEFDSzogIFtzdGF0dXNdICAgICAgICAgICAgICAgKDEgYnl0ZSwgMHgwMCA9IG9rKVxuXHRcdFx0Ly8gICAyLiBFY2hvOiBbYnVzQ2hdIFtzZXR0aW5nSWRdIFt2YWx1ZS4uLl0gIChjb25maXJtaW5nIHdoYXQgd2FzIGFwcGxpZWQpXG5cdFx0XHRjYXNlIENNRF9ERVZfU1BFQzoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdFx0XHRyZXR1cm4gZGF0YVswXSA9PT0gMHgwMCA/ICdBQ0sgb2snIDogYEFDSyBlcnI9JHt0b0hleChkYXRhWzBdKX1gXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID49IDMpIHtcblx0XHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0XHRjb25zdCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyBgc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9YFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LlswXT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IHZhbHVlTnVtID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/IGAke2Nob2ljZUxhYmVsfSAoJHt0b0hleCh2YWx1ZU51bSEpfSlgIDogYnl0ZXNUb0hleChBcnJheS5mcm9tKHZhbHVlQnl0ZXMpKVxuXHRcdFx0XHRcdGNvbnN0IHJhd1RhZyA9IGBbJHt0b0hleChjbWRJZCl9LyR7dG9IZXgoc2V0dGluZ0lkKX1dPSR7Ynl0ZXNUb0hleChBcnJheS5mcm9tKHZhbHVlQnl0ZXMpKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9ICR7cmF3VGFnfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gYHJhdzogJHtkYXRhLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfTUlDX1BSRV9CVVMgKDB4MTIpOiBNdWx0aS1ieXRlIGVjaG8gcmVzcG9uc2VzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6IHtcblx0XHRcdFx0Ly8gQWxyZWFkeSBoYW5kbGVkIHNpbmdsZS1ieXRlIGFib3ZlLCBzbyBtdWx0aS1ieXRlIG11c3QgYmUgZWNob1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VzID0gYWN0aW9uPy5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID1cblx0XHRcdFx0XHRcdGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlU3RyID0gY2hvaWNlTGFiZWwgPz8gYDB4JHt2YWx1ZUJ5dGVzLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBudWxsXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBCdXMtc2NvcGVkIGdldC9zZXQgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0Y2FzZSBDTURfQlVTX1NFVDoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPCAyKSByZXR1cm4gbnVsbFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0cmV0dXJuIGBjaD0ke2J1c0NofSBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX0gdmFsdWU9JHt2YWx1ZS50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0fVxuXG5cdFx0XHRkZWZhdWx0OlxuXHRcdFx0XHRyZXR1cm4gbnVsbCAvLyBmYWxsIHRocm91Z2ggdG8gcmF3IGhleFxuXHRcdH1cblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGJ1aWxkVmFsdWVCeXRlcyh2YWx1ZTogdW5rbm93bik6IG51bWJlcltdIHtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiBbdmFsdWUgPyAxIDogMF1cblx0XHRpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiB2YWx1ZS5tYXAoKHYpID0+IE51bWJlcih2KSAmIDB4ZmYpXG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcblx0XHRcdGlmICh2YWx1ZSA+IDB4ZmYpIHJldHVybiBbKHZhbHVlID4+IDE2KSAmIDB4ZmYsICh2YWx1ZSA+PiA4KSAmIDB4ZmYsIHZhbHVlICYgMHhmZl1cblx0XHRcdHJldHVybiBbdmFsdWUgJiAweGZmXVxuXHRcdH1cblx0XHR0aHJvdyBuZXcgRXJyb3IoYFVuc3VwcG9ydGVkIHZhbHVlIHR5cGUgZm9yIFNUY29udHJvbGxlcjogJHt2YWx1ZX1gKVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgYXN5bmMgYnVpbGRIZWFkZXIodG90YWxMZW46IG51bWJlciwgZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGNvbnN0IG1hYyA9IGF3YWl0IGdldE1hY0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblxuXHRcdHJldHVybiBCdWZmZXIuY29uY2F0KFtcblx0XHRcdEJ1ZmZlci5mcm9tKFsweGZmLCAweGZmLCAweDAwLCB0b3RhbExlbiAmIDB4ZmYsIDB4MDcsIDB4ZTEsIDB4MDAsIDB4MDAsIC4uLm1hYywgMHgwMCwgMHgwMF0pLFxuXHRcdFx0QnVmZmVyLmZyb20oJ1N0dWRpby1UJywgJ3V0ZjgnKSxcblx0XHRdKVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgY3JjOER2YlMyKGRhdGE6IG51bWJlcltdKTogbnVtYmVyIHtcblx0XHRsZXQgY3JjID0gMFxuXHRcdGZvciAoY29uc3QgYiBvZiBkYXRhKSB7XG5cdFx0XHRjcmMgXj0gYlxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCA4OyBpKyspIHtcblx0XHRcdFx0Y3JjID0gKGNyYyAmIDB4ODApICE9PSAwID8gKChjcmMgPDwgMSkgXiAweGQ1KSAmIDB4ZmYgOiAoY3JjIDw8IDEpICYgMHhmZlxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gY3JjXG5cdH1cblxuXHQvKipcblx0ICogUmV0dXJucyB0aGUgY3VycmVudCBrbm93biB2YWx1ZSBmb3IgYSBzZXR0aW5nIG9uIGEgZGV2aWNlLCBvciB1bmRlZmluZWQgaWYgdW5rbm93bi5cblx0ICogVXNlIGZvciBmZWVkYmFja3MgXHUyMDE0IHZhbHVlIGlzIHVwZGF0ZWQgb24gZXZlcnkgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpIGZyb20gdGhlIGRldmljZS5cblx0ICpcblx0ICogQHBhcmFtIGlwICAgICAgICBEZXZpY2UgSVAgYWRkcmVzc1xuXHQgKiBAcGFyYW0gY21kSWQgICAgIENvbW1hbmQgSUQgKGUuZy4gQ01EX0RFVl9TUEVDKVxuXHQgKiBAcGFyYW0gc2V0dGluZ0lkIFNldHRpbmcgSUQgKGUuZy4gMHgwMiBmb3IgQ29udHJvbCBTb3VyY2UpXG5cdCAqIEBwYXJhbSBidXNDaCAgICAgT3B0aW9uYWwgYnVzL2NoYW5uZWwgSUQgZm9yIG11bHRpLWNoYW5uZWwgY29tbWFuZHNcblx0ICovXG5cdHB1YmxpYyBnZXRTZXR0aW5nVmFsdWUoaXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgc2V0dGluZ0lkOiBudW1iZXIsIGJ1c0NoPzogbnVtYmVyKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcblx0XHRjb25zdCBrZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXHRcdHJldHVybiB0aGlzLmRldmljZVN0YXRlLmdldChpcCk/LmdldChrZXkpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgcmVzZXREZXZpY2UobW9kZWw6IHN0cmluZywgZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHJldHVybiB0aGlzLnNlbmRBd2FpdEFjayhtb2RlbCwgQ01EX1JFU0VUX0RFVklDRSwgdW5kZWZpbmVkLCAweDAwLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgZ2xvYmFsTWljS2lsbChtb2RlbDogc3RyaW5nLCBkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKG1vZGVsLCBDTURfR0xPQkFMX01JQ19LSUxMLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IG9zIGZyb20gJ29zJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRGFudGUnKVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgRGFudGUgZGlzY292ZXJ5IGNvbnN0YW50cyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlcXVlc3QgbWVzc2FnZSB0eXBlIChzZW50IHRvIHBvcnQgODcwMCkgKi9cbmV4cG9ydCBjb25zdCBEQU5URV9NU0dfSU5GT19SRVFVRVNUID0gMHgwMDIwXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgbWVzc2FnZSB0eXBlIChyZWNlaXZlZCBvbiBwb3J0IDg3MDIpICovXG5leHBvcnQgY29uc3QgREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgPSAweDAxNzBcblxuLyoqXG4gKiBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSBsYXlvdXQgKGFsbCBvZmZzZXRzIGFyZSBpbnRvIHRoZSBVRFAgcGF5bG9hZCk6XG4gKiAgIDB4MDAgIHVpbnQxNkJFICBNYWdpYyAoMHhmZmZmKVxuICogICAweDAyICB1aW50MTZCRSAgTWVzc2FnZSB0eXBlICgweDAxNzApXG4gKiAgIDB4MDQgIHVpbnQxNkJFICBTZXF1ZW5jZSBudW1iZXJcbiAqICAgMHgwNiAgMiBieXRlcyAgIFBhZGRpbmdcbiAqICAgMHgwOCAgOCBieXRlcyAgIEVVSS02NCAoc291cmNlIE1BQyB3aXRoIGZmOmZlIGluc2VydGVkIG1pZClcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBBU0NJSSBpZGVudGlmaWVyXG4gKiAgIDB4MTggIDIgYnl0ZXMgICBEYW50ZSBtb2R1bGUgZmlybXdhcmUgdmVyc2lvbiAobWFqb3IsIG1pbm9yKVxuICogICAweDIwICAzMSBieXRlcyAgRGV2aWNlIG5hbWUsIG51bGwtcGFkZGVkIEFTQ0lJIChtYXggMzEgY2hhcnMgcGVyIERhbnRlIHNwZWMpXG4gKiAgIDB4MmUgIHVpbnQxNkJFICBQcm9kdWN0IElEXG4gKiAgIDB4NGMgIDY0IGJ5dGVzICBNYW51ZmFjdHVyZXIgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICogICAweGNjICA2NCBieXRlcyAgTW9kZWwgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICovXG5leHBvcnQgY29uc3QgREFOVEVfSU5GT19NSU5fTEVOID0gMHhjYyArIDY0IC8vIDI2OCBieXRlcyBcdTIwMTQgbmVlZCBmdWxsIG1vZGVsIGZpZWxkXG5cbi8qKlxuICogQnVpbGRzIGEgRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBwYWNrZXQgKHR5cGUgMHgwMDIwKS5cbiAqXG4gKiBQYWNrZXQgbGF5b3V0ICgzMiBieXRlcykgXHUyMDE0IGRlcml2ZWQgZnJvbSBsaXZlIGNhcHR1cmUgYW5hbHlzaXM6XG4gKiAgIDB4MDAgIHVpbnQxNkJFICBNYWdpYyAoMHhmZmZmKVxuICogICAweDAyICB1aW50MTZCRSAgTWVzc2FnZSB0eXBlICgweDAwMjAgPSBkZXZpY2UgaW5mbyByZXF1ZXN0KVxuICogICAweDA0ICB1aW50MTZCRSAgU2VxdWVuY2UgbnVtYmVyIChyYW5kb20pXG4gKiAgIDB4MDYgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MDggIDYgYnl0ZXMgICBTb3VyY2UgTUFDXG4gKiAgIDB4MGUgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgQVNDSUkgaWRlbnRpZmllclxuICogICAweDE4ICAyIGJ5dGVzICAgUHJvdG9jb2wgdmVyc2lvbiAoMHgwNzM5KVxuICogICAweDFhICAyIGJ5dGVzICAgU3ViLXR5cGUgKDB4MDBjMSlcbiAqICAgMHgxYyAgdWludDMyQkUgIENhcGFiaWxpdHkgbWFzayAoMHgwMDBmNDI0MClcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpOiBCdWZmZXIge1xuXHRjb25zdCBidWYgPSBCdWZmZXIuYWxsb2MoMzIsIDApXG5cdGNvbnN0IHNlcSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDB4ZmZmZilcblxuXHRidWYud3JpdGVVSW50MTZCRSgweGZmZmYsIDApXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKERBTlRFX01TR19JTkZPX1JFUVVFU1QsIDIpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKHNlcSwgNClcblxuXHRjb25zdCBtYWMgPSBnZXRGaXJzdExvY2FsTWFjKClcblx0bWFjLmNvcHkoYnVmLCA4KVxuXG5cdEJ1ZmZlci5mcm9tKCdBdWRpbmF0ZScsICdhc2NpaScpLmNvcHkoYnVmLCAxNilcblx0YnVmLndyaXRlVUludDE2QkUoMHgwNzM5LCAyNClcblx0YnVmLndyaXRlVUludDE2QkUoMHgwMGMxLCAyNilcblx0YnVmLndyaXRlVUludDMyQkUoMHgwMDBmNDI0MCwgMjgpXG5cblx0cmV0dXJuIGJ1ZlxufVxuXG4vKiogUmV0dXJucyB0aGUgZmlyc3Qgbm9uLWxvb3BiYWNrIE1BQyBhcyBhIDYtYnl0ZSBCdWZmZXIsIG9yIHplcm9zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEZpcnN0TG9jYWxNYWMoKTogQnVmZmVyIHtcblx0dHJ5IHtcblx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdGZvciAoY29uc3QgYWRkciBvZiBpZmFjZXNbbmFtZV0gPz8gW10pIHtcblx0XHRcdFx0aWYgKCFhZGRyLmludGVybmFsICYmIGFkZHIuZmFtaWx5ID09PSAnSVB2NCcgJiYgYWRkci5tYWMgJiYgYWRkci5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCcpIHtcblx0XHRcdFx0XHRyZXR1cm4gQnVmZmVyLmZyb20oYWRkci5tYWMuc3BsaXQoJzonKS5tYXAoKGg6IHN0cmluZykgPT4gcGFyc2VJbnQoaCwgMTYpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCB7XG5cdFx0LyogaWdub3JlICovXG5cdH1cblx0cmV0dXJuIEJ1ZmZlci5hbGxvYyg2LCAwKVxufVxuXG4vKipcbiAqIFBhcnNlcyBhIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlICh0eXBlIDB4MDE3MCkgaW50byBhIERldmljZUluZm8uXG4gKlxuICogUmVzcG9uc2UgbGF5b3V0IChrZXkgb2Zmc2V0cyk6XG4gKiAgIDB4MDggIDggYnl0ZXMgICBFVUktNjQgXHUyMDE0IGNvbnZlcnQgdG8gTUFDIGJ5IGRyb3BwaW5nIGJ5dGVzIFszXSBhbmQgWzRdIChmZjpmZSlcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBpZGVudGlmaWVyICh1c2VkIHRvIHZlcmlmeSB0aGlzIGlzIGEgcmVhbCByZXNwb25zZSlcbiAqICAgMHgxOCAgMSBieXRlICAgIERhbnRlIEZXIG1ham9yXG4gKiAgIDB4MTkgIDEgYnl0ZSAgICBEYW50ZSBGVyBtaW5vclxuICogICAweDIwICAzMSBieXRlcyAgRGV2aWNlIG5hbWUgKERhbnRlIGxhYmVsKSwgbnVsbC1wYWRkZWQgQVNDSUkgKG1heCAzMSBjaGFycylcbiAqICAgMHgyZSAgdWludDE2QkUgIFByb2R1Y3QgSURcbiAqICAgMHg0YyAgNjQgYnl0ZXMgIE1hbnVmYWN0dXJlciwgbnVsbC1wYWRkZWQgQVNDSUlcbiAqICAgMHhjYyAgNjQgYnl0ZXMgIE1vZGVsIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqXG4gKiBSZXR1cm5zIG51bGwgaWYgYnVmZmVyIGlzIHRvbyBzaG9ydCwgd3JvbmcgbWFnaWMsIG9yIG1pc3NpbmcgbW9kZWwgc3RyaW5nLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VEYW50ZUluZm9SZXNwb25zZShtc2c6IEJ1ZmZlciwgc3JjSXA6IHN0cmluZyk6IERldmljZUluZm8gfCBudWxsIHtcblx0aWYgKG1zZy5sZW5ndGggPCBEQU5URV9JTkZPX01JTl9MRU4pIHJldHVybiBudWxsXG5cdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmYpIHJldHVybiBudWxsXG5cdGlmIChtc2cucmVhZFVJbnQxNkJFKDIpICE9PSBEQU5URV9NU0dfSU5GT19SRVNQT05TRSkgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm4gbnVsbFxuXG5cdGNvbnN0IHJlYWRTdHIgPSAob2Zmc2V0OiBudW1iZXIsIGxlbjogbnVtYmVyKTogc3RyaW5nID0+XG5cdFx0bXNnXG5cdFx0XHQuc3ViYXJyYXkob2Zmc2V0LCBvZmZzZXQgKyBsZW4pXG5cdFx0XHQudG9TdHJpbmcoJ2FzY2lpJylcblx0XHRcdC5zcGxpdCgnXFwwJylbMF1cblx0XHRcdC50cmltKClcblxuXHRjb25zdCBldWk2NCA9IG1zZy5zdWJhcnJheSg4LCAxNilcblx0Y29uc3QgbWFjQnl0ZXMgPSBbZXVpNjRbMF0sIGV1aTY0WzFdLCBldWk2NFsyXSwgZXVpNjRbNV0sIGV1aTY0WzZdLCBldWk2NFs3XV1cblx0Y29uc3QgbWFjID0gbWFjQnl0ZXMubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKS5qb2luKCc6JylcblxuXHRjb25zdCBuYW1lID0gcmVhZFN0cigweDIwLCAzMSkgLy8gRGFudGUgZGV2aWNlIGxhYmVsIChjYW4gYmUgdXAgdG8gMzEgY2hhcnMgcGVyIERhbnRlIHNwZWMpXG5cdGNvbnN0IG1hbnVmYWN0dXJlciA9IHJlYWRTdHIoMHg0YywgNjQpIC8vIGUuZy4gXCJTdHVkaW8gVGVjaG5vbG9naWVzLCBJbmMuXCJcblx0Y29uc3QgbW9kZWxSYXcgPSByZWFkU3RyKDB4Y2MsIDY0KVxuXHRjb25zdCBkYW50ZUZpcm13YXJlID0gYCR7bXNnWzB4MThdfS4ke21zZ1sweDE5XX1gXG5cblx0aWYgKCFtb2RlbFJhdykgcmV0dXJuIG51bGxcblxuXHQvLyBFeHRyYWN0IGp1c3QgdGhlIG1vZGVsIG51bWJlci9jb2RlIChlLmcuIFwiTW9kZWwgMzkxIEFsZXJ0aW5nIFVuaXRcIiBcdTIxOTIgXCIzOTFcIilcblx0Ly8gU3RyaXAgXCJNb2RlbCBcIiBwcmVmaXgsIHRoZW4gdGFrZSBvbmx5IHRoZSBmaXJzdCB3b3JkICh0aGUgbW9kZWwgbnVtYmVyKVxuXHRjb25zdCBtb2RlbCA9IG1vZGVsUmF3XG5cdFx0LnJlcGxhY2UoL15Nb2RlbFxccysvaSwgJycpXG5cdFx0LnRyaW0oKVxuXHRcdC5zcGxpdCgvXFxzKy8pWzBdXG5cblx0cmV0dXJuIHtcblx0XHRpcDogc3JjSXAsXG5cdFx0bmFtZSxcblx0XHRtYW51ZmFjdHVyZXIsXG5cdFx0bW9kZWwsXG5cdFx0bW9kZWxOYW1lOiBtb2RlbFJhdywgLy8gRnVsbCBtb2RlbCBkZXNjcmlwdGlvblxuXHRcdG1hYyxcblx0XHRkYW50ZUZpcm13YXJlLFxuXHR9XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgTUFDIGFkZHJlc3MgYnl0ZXMgb2YgdGhlIGxvY2FsIGludGVyZmFjZSB1c2VkIHRvIHJvdXRlIHRvIGRlc3RJcC5cbiAqIFVzZXMgYSB0ZW1wb3JhcnkgVURQIGNvbm5lY3QgdG8gbGV0IHRoZSBPUyBzZWxlY3QgdGhlIG91dGdvaW5nIGludGVyZmFjZSxcbiAqIHRoZW4gZmluZHMgdGhlIG1hdGNoaW5nIE1BQyBmcm9tIG9zLm5ldHdvcmtJbnRlcmZhY2VzKCkuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8bnVtYmVyW10+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPG51bWJlcltdPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHR9KVxuXG5cdFx0dG1wLmNvbm5lY3QoOSwgZGVzdElwLCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGFkZHIuYWRkcmVzc1xuXHRcdFx0XHR0bXAuY2xvc2UoKVxuXG5cdFx0XHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRcdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGlmYWNlIG9mIGlmYWNlc1tuYW1lXSA/PyBbXSkge1xuXHRcdFx0XHRcdFx0aWYgKFxuXHRcdFx0XHRcdFx0XHRpZmFjZS5mYW1pbHkgPT09ICdJUHY0JyAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5hZGRyZXNzID09PSBsb2NhbEFkZHIgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UubWFjICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAhPT0gJzAwOjAwOjAwOjAwOjAwOjAwJ1xuXHRcdFx0XHRcdFx0KSB7XG5cdFx0XHRcdFx0XHRcdHJldHVybiByZXNvbHZlKGlmYWNlLm1hYy5zcGxpdCgnOicpLm1hcCgoYikgPT4gcGFyc2VJbnQoYiwgMTYpICYgMHhmZikpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYE5vIGludGVyZmFjZSBmb3VuZCBmb3IgbG9jYWwgYWRkcmVzcyAke2xvY2FsQWRkcn1gKSlcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoU3RyaW5nKF9lKSkpXG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBsb2NhbCBJUCBhZGRyZXNzIHVzZWQgYnkgdGhlIE9TIHRvIHJvdXRlIHRvIGRlc3RJcC5cbiAqIFVzZXMgYSB0ZW1wb3JhcnkgVURQIHNvY2tldCBjb25uZWN0IHRvIGxldCB0aGUgT1Mgc2VsZWN0IHRoZSBvdXRnb2luZyBpbnRlcmZhY2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTxzdHJpbmc+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCB0bXAgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoJ3VkcDQnKVxuXG5cdFx0bGV0IHJlc29sdmVkID0gZmFsc2Vcblx0XHR0bXAub25jZSgnZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gVXNlIGFuIGFyYml0cmFyeSBwb3J0IGZvciBjb25uZWN0OyB3ZSBvbmx5IG5lZWQgdGhlIGtlcm5lbCB0byBhc3NpZ24gYSBsb2NhbCBhZGRyZXNzLlxuXHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgYWRkciA9IHRtcC5hZGRyZXNzKCkgYXMgeyBhZGRyZXNzOiBzdHJpbmcgfVxuXHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3Ncblx0XHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdFx0cmVzb2x2ZShsb2NhbEFkZHIpXG5cdFx0XHRcdH1cblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoU3RyaW5nKF9lKSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuXG4vKipcbiAqIERpc2NvdmVycyBTdHVkaW8gVGVjaG5vbG9naWVzIERhbnRlIGRldmljZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsuXG4gKlxuICogU3RyYXRlZ3k6XG4gKiAgRGFudGUgZGV2aWNlcyBicm9hZGNhc3QgYSAxLXNlY29uZCBhbm5vdW5jZSB0byBtdWx0aWNhc3QgMjI0LjAuMC4yMzM6ODcwOC5cbiAqICBXZSBsaXN0ZW4gb24gdGhhdCBncm91cCwgY29sbGVjdCBzb3VyY2UgSVBzLCB0aGVuIHNlbmQgYSB1bmljYXN0IGRldmljZSBpbmZvXG4gKiAgcmVxdWVzdCAoMHgwMDIwKSB0byBlYWNoIG5ldyBJUCBvbiBwb3J0IDg3MDAuIFRoZSBkZXZpY2UgcmVzcG9uZHMgb24gcG9ydCA4NzAyLFxuICogIHdoZXJlIHRoZSBwcm92aWRlZCBvbkRldmljZUZvdW5kIGNhbGxiYWNrIGlzIGludm9rZWQuXG4gKlxuICogQHBhcmFtIHR4U29ja2V0IC0gVGhlIHNvY2tldCB0byB1c2UgZm9yIHNlbmRpbmcgZGlzY292ZXJ5IHJlcXVlc3RzXG4gKiBAcGFyYW0gb25EZXZpY2VGb3VuZCAtIENhbGxiYWNrIGludm9rZWQgd2hlbiBhIGRldmljZSBpbmZvIHJlc3BvbnNlICgweDAxNzApIGlzIHJlY2VpdmVkXG4gKiBAcGFyYW0gZW5zdXJlTWVtYmVyc2hpcCAtIENhbGxiYWNrIHRvIGVuc3VyZSBtdWx0aWNhc3QgbWVtYmVyc2hpcCBmb3IgZGV2aWNlIElQXG4gKiBAcGFyYW0gdGltZW91dE1zIC0gRGlzY292ZXJ5IHRpbWVvdXQgaW4gbWlsbGlzZWNvbmRzXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkaXNjb3ZlckRldmljZXMoXG5cdHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXQsXG5cdF9vbkRldmljZUZvdW5kOiAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB2b2lkLCAvLyBJbnZva2VkIGJ5IFN0Q29udHJvbGxlci5oYW5kbGVJbmNvbWluZygpLCBub3QgaGVyZVxuXHRlbnN1cmVNZW1iZXJzaGlwOiAoZGVzdElwOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD4sXG5cdHRpbWVvdXRNcyA9IDUwMDAsXG4pOiBQcm9taXNlPERldmljZUluZm9bXT4ge1xuXHRjb25zdCBEQU5URV9BTk5PVU5DRV9HUk9VUCA9ICcyMjQuMC4wLjIzMydcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfUE9SVCA9IDg3MDhcblx0Y29uc3QgREVGQVVMVF9QT1JUID0gODcwMFxuXG5cdGNvbnN0IGZvdW5kID0gbmV3IE1hcDxzdHJpbmcsIERldmljZUluZm8+KClcblx0Y29uc3QgcXVlcmllZElwcyA9IG5ldyBTZXQ8c3RyaW5nPigpXG5cblx0cmV0dXJuIG5ldyBQcm9taXNlPERldmljZUluZm9bXT4oKHJlc29sdmUpID0+IHtcblx0XHQvLyBOb3RlOiBvbkRldmljZUZvdW5kIGNhbGxiYWNrIGlzIGludm9rZWQgYnkgU3RDb250cm9sbGVyLmhhbmRsZUluY29taW5nKClcblx0XHQvLyB3aGVuIGl0IHJlY2VpdmVzIDB4MDE3MCByZXNwb25zZXMuIFdlIGRvbid0IGNhbGwgaXQgaGVyZSB0byBhdm9pZCBkdXBsaWNhdGVzLlxuXG5cdFx0Ly8gT3BlbiBhIHNob3J0LWxpdmVkIHNvY2tldCBqdXN0IHRvIHJlY2VpdmUgdGhlIERhbnRlIHBlcmlvZGljIGFubm91bmNlc1xuXHRcdGNvbnN0IGFubm91bmNlU29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblxuXHRcdGNvbnN0IGNsZWFudXAgPSAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhbm5vdW5jZVNvY2tldC5kcm9wTWVtYmVyc2hpcChEQU5URV9BTk5PVU5DRV9HUk9VUClcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmNsb3NlKClcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHRcdHJlc29sdmUoQXJyYXkuZnJvbShmb3VuZC52YWx1ZXMoKSkpXG5cdFx0fVxuXG5cdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KGNsZWFudXAsIHRpbWVvdXRNcylcblx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdGFubm91bmNlU29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci53YXJuKGBBbm5vdW5jZSBzb2NrZXQgZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0Y29uc3Qgc3JjSXAgPSByaW5mby5hZGRyZXNzXG5cdFx0XHQvLyBWYWxpZGF0ZSBpdCdzIGEgRGFudGUgYW5ub3VuY2UgKG1hZ2ljIDB4ZmZmZSArIFwiQXVkaW5hdGVcIiBhdCBvZmZzZXQgMTYpXG5cdFx0XHRpZiAobXNnLmxlbmd0aCA8IDI0KSByZXR1cm5cblx0XHRcdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmUpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm5cblxuXHRcdFx0aWYgKHF1ZXJpZWRJcHMuaGFzKHNyY0lwKSkgcmV0dXJuXG5cdFx0XHRxdWVyaWVkSXBzLmFkZChzcmNJcClcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgQW5ub3VuY2UgZnJvbSAke3NyY0lwfSBcdTIwMTQgc2VuZGluZyB1bmljYXN0IHF1ZXJ5YClcblxuXHRcdFx0Ly8gSm9pbiAyMjQuMC4wLjIzMSBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIHRoaXMgZGV2aWNlIEJFRk9SRSBzZW5kaW5nXG5cdFx0XHQvLyB0aGUgcXVlcnkuIFRoZSBkZXZpY2UgbXVsdGljYXN0cyBpdHMgMHgwMTcwIHJlc3BvbnNlIHRvIDIyNC4wLjAuMjMxOjg3MDJcblx0XHRcdC8vIGluIGFkZGl0aW9uIHRvIHVuaWNhc3RpbmcgaXQgXHUyMDE0IHJ4U29ja2V0IG11c3QgYmUgYSBtZW1iZXIgdG8gcmVjZWl2ZSBpdC5cblx0XHRcdGVuc3VyZU1lbWJlcnNoaXAoc3JjSXApXG5cdFx0XHRcdC50aGVuKCgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBxdWVyeSA9IGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpXG5cdFx0XHRcdFx0dHhTb2NrZXQuc2VuZChxdWVyeSwgREVGQVVMVF9QT1JULCBzcmNJcCwgKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKGVycikgbG9nZ2VyLndhcm4oYFVuaWNhc3QgcXVlcnkgdG8gJHtzcmNJcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSlcblx0XHRcdFx0LmNhdGNoKChlcnIpID0+IGxvZ2dlci53YXJuKGBRdWVyeSBzZXR1cCBmYWlsZWQ6ICR7ZXJyfWApKVxuXHRcdH0pXG5cblx0XHRhbm5vdW5jZVNvY2tldC5iaW5kKERBTlRFX0FOTk9VTkNFX1BPUlQsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmFkZE1lbWJlcnNoaXAoREFOVEVfQU5OT1VOQ0VfR1JPVVApXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBMaXN0ZW5pbmcgZm9yIERhbnRlIGFubm91bmNlcyBvbiAke0RBTlRFX0FOTk9VTkNFX0dST1VQfToke0RBTlRFX0FOTk9VTkNFX1BPUlR9YClcblx0XHRcdH0gY2F0Y2ggKGVycikge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGpvaW4gYW5ub3VuY2UgbXVsdGljYXN0IGdyb3VwOiAke2Vycn1gKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHQvLyBTdG9yZSBjYWxsYmFjayBmb3IgY2xlYW51cFxuXHR9KVxufVxuIiwgImltcG9ydCB7XG5cdEluc3RhbmNlVHlwZXMsXG5cdEluc3RhbmNlQmFzZSxcblx0SW5zdGFuY2VTdGF0dXMsXG5cdFNvbWVDb21wYW5pb25Db25maWdGaWVsZCxcblx0Y3JlYXRlTW9kdWxlTG9nZ2VyLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgR2V0Q29uZmlnRmllbGRzLCByZXNvbHZlSG9zdCwgcmVzb2x2ZU1vZGVsLCBnZXREZXZpY2VTY2hlbWEsIHR5cGUgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zLCBVcGRhdGVWYXJpYWJsZVZhbHVlcyB9IGZyb20gJy4vdmFyaWFibGVzLmpzJ1xuaW1wb3J0IHsgVXBncmFkZVNjcmlwdHMgfSBmcm9tICcuL3VwZ3JhZGVzLmpzJ1xuaW1wb3J0IHsgVXBkYXRlQWN0aW9ucyB9IGZyb20gJy4vYWN0aW9ucy5qcydcbmltcG9ydCB7IFVwZGF0ZUZlZWRiYWNrcyB9IGZyb20gJy4vZmVlZGJhY2tzLmpzJ1xuaW1wb3J0IHsgU3RDb250cm9sbGVyIH0gZnJvbSAnLi9zdGNvbnRyb2xsZXIuanMnXG5pbXBvcnQgdHlwZSB7IERldmljZUluZm8gfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ01vZHVsZUluc3RhbmNlJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlVHlwZXMgPSBJbnN0YW5jZVR5cGVzICYge1xuXHRjb25maWc6IE1vZHVsZUNvbmZpZ1xufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNb2R1bGVJbnN0YW5jZSBleHRlbmRzIEluc3RhbmNlQmFzZTxNb2R1bGVUeXBlcz4ge1xuXHRjb25maWchOiBNb2R1bGVDb25maWcgLy8gU2V0dXAgaW4gaW5pdCgpXG5cdHN0Q29udHJvbGxlciE6IFN0Q29udHJvbGxlclxuXG5cdC8qKiBDYWNoZWQgZGlzY292ZXJ5IHJlc3VsdHMgXHUyMDE0IHBhc3NlZCBpbnRvIGdldENvbmZpZ0ZpZWxkcygpIHNvIHRoZSBVSVxuXHQgKiAgY2FuIHNob3cgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIGRyb3Bkb3duIG9uIHN1YnNlcXVlbnQgY29uZmlnIG9wZW5zLiAqL1xuXHRwcml2YXRlIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXVxuXG5cdGNvbnN0cnVjdG9yKGludGVybmFsOiB1bmtub3duKSB7XG5cdFx0c3VwZXIoaW50ZXJuYWwpXG5cdH1cblxuXHRhc3luYyBpbml0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRpZiAoIXRoaXMuc3RDb250cm9sbGVyKSB7XG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlciA9IG5ldyBTdENvbnRyb2xsZXIoKVxuXHRcdH1cblx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5PaylcblxuXHRcdC8vIFdpcmUgZmVlZGJhY2sgY2FsbGJhY2sgc28gc3RDb250cm9sbGVyIGNhbiB0cmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZXNcblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRGZWVkYmFja0NhbGxiYWNrKChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHtcblx0XHRcdHRoaXMuY2hlY2tGZWVkYmFja3MoZmVlZGJhY2tJZClcblx0XHR9KVxuXG5cdFx0Ly8gU3RhcnQgZGlzY292ZXJ5IGluIHRoZSBiYWNrZ3JvdW5kIFx1MjAxNCBhbGwgbW9kZWwgcmVzb2x1dGlvbiwgc2NoZW1hIHN5bmMsXG5cdFx0Ly8gYW5kIFVJIHVwZGF0ZXMgaGFwcGVuIGluc2lkZSBydW5EaXNjb3ZlcnkoKSBvbmNlIHRoZSBkZXZpY2UgbGlzdCBpcyBrbm93bi5cblx0XHR0aGlzLnJ1bkRpc2NvdmVyeSgpLmNhdGNoKChlKSA9PiB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYERpc2NvdmVyeSBmYWlsZWQ6ICR7ZX1gKVxuXHRcdH0pXG5cdH1cblxuXHQvKipcblx0ICogUnVuIGRldmljZSBkaXNjb3ZlcnksIHRoZW4gcmVzb2x2ZSB0aGUgbW9kZWwgYW5kIHVwZGF0ZSBhbGwgVUkuXG5cdCAqIC0gSWYgZGlzY292ZXJ5IGZpbmRzIGRldmljZXMsIHJlc29sdmVNb2RlbCBwaWNrcyBmcm9tIHRob3NlLlxuXHQgKiAtIE9ubHkgaWYgdGhlIGxpc3QgaXMgZW1wdHkgZG8gd2UgZmFsbCBiYWNrIHRvIHRoZSBtYW51YWwgY29uZmlnIHNlbGVjdGlvbi5cblx0ICogQWxsIGFjdGlvbnMvZmVlZGJhY2tzL3ZhcmlhYmxlcyBhcmUgYnVpbHQgYWZ0ZXIgdGhlIG1vZGVsIGlzIGtub3duLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBydW5EaXNjb3ZlcnkoKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0bG9nZ2VyLmluZm8oJ1N0YXJ0aW5nIGRldmljZSBkaXNjb3ZlcnkuLi4nKVxuXG5cdFx0dGhpcy5kaXNjb3ZlcmVkRGV2aWNlcyA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLmRpc2NvdmVyRGV2aWNlcygpXG5cblx0XHQvLyBEZXRlcm1pbmUgZWZmZWN0aXZlIG1vZGVsIFx1MjAxNCBmcm9tIGRpc2NvdmVyZWQgZGV2aWNlcyBmaXJzdCwgbWFudWFsIGNvbmZpZyBvbmx5IGFzIGZhbGxiYWNrXG5cdFx0bGV0IGVmZmVjdGl2ZU1vZGVsOiBzdHJpbmdcblx0XHRpZiAodGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGggPT09IDApIHtcblx0XHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWxcblx0XHRcdGlmICghdGhpcy5jb25maWcuaG9zdCB8fCAhbWFudWFsTW9kZWwpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oJ05vIGRldmljZXMgZGlzY292ZXJlZCBhbmQgbm8gbWFudWFsIElQL21vZGVsIGNvbmZpZ3VyZWQnKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKCdObyBkZXZpY2VzIGRpc2NvdmVyZWQgXHUyMDE0IHdpbGwgcHJvYmUgbWFudWFsIElQIGR1cmluZyBhdXRob3JpemF0aW9uJylcblx0XHRcdGVmZmVjdGl2ZU1vZGVsID0gbWFudWFsTW9kZWxcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYERpc2NvdmVyZWQgJHt0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aH0gZGV2aWNlKHMpOmApXG5cdFx0XHRmb3IgKGNvbnN0IGQgb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtIE1vZGVsICR7ZC5tb2RlbH0gJHtkLm1hbnVmYWN0dXJlciA/PyAnJ30gQCAke2QuaXB9YClcblx0XHRcdH1cblxuXHRcdFx0Ly8gQXV0aG9yaXplIGFsbCBkaXNjb3ZlcmVkIGRldmljZXMgc28gZmlybXdhcmUgcmVxdWVzdHMgY2FuIHByb2NlZWQuXG5cdFx0XHQvLyB2ZXJpZnlBdXRob3JpemF0aW9uIChjYWxsZWQgYmVsb3cpIHdpbGwgcmV2b2tlIGFueSB0aGF0IGRvbid0IG1hdGNoXG5cdFx0XHQvLyB0aGUgY3VycmVudCBjb25maWcgc2VsZWN0aW9uLlxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UoZGV2aWNlLmlwKVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBSZXF1ZXN0IGZpcm13YXJlIHZlcnNpb24gZnJvbSBlYWNoIGRpc2NvdmVyZWQgZGV2aWNlXG5cdFx0XHRmb3IgKGNvbnN0IGRldmljZSBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0Y29uc3QgZmlybXdhcmUgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5yZXF1ZXN0RmlybXdhcmVWZXJzaW9uKGRldmljZS5pcClcblx0XHRcdFx0XHRkZXZpY2UuZmlybXdhcmVNYWluID0gZmlybXdhcmVcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtICR7ZGV2aWNlLmlwfTogRmlybXdhcmUgJHtmaXJtd2FyZX0sIERhbnRlICR7ZGV2aWNlLmRhbnRlRmlybXdhcmV9YClcblx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdGxvZ2dlci53YXJuKGAgIC0gJHtkZXZpY2UuaXB9OiBGYWlsZWQgdG8gZ2V0IGZpcm13YXJlOiAke2V9YClcblx0XHRcdFx0XHRkZXZpY2UuZmlybXdhcmVNYWluID0gJ1Vua25vd24nXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0ZWZmZWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwodGhpcy5jb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdFx0fVxuXG5cdFx0Ly8gU3luYyBtb2RlbCBzY2hlbWEgdG8gY29udHJvbGxlclxuXHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXG5cdFx0Ly8gVmVyaWZ5IHRoYXQgdGhlIGN1cnJlbnRseSBjb25maWd1cmVkIGhvc3QrbW9kZWwgaXMgdmFsaWQgbm93IHRoYXRcblx0XHQvLyBkaXNjb3ZlcnkgcmVzdWx0cyBhcmUga25vd24uIFRoaXMgaXMgdGhlIHNhbWUgY2hlY2sgY29uZmlnVXBkYXRlZCB1c2VzLlxuXHRcdGNvbnN0IHRhcmdldEhvc3QgPSB0aGlzLmhvc3Rcblx0XHRhd2FpdCB0aGlzLnZlcmlmeUF1dGhvcml6YXRpb24oJycsIHRhcmdldEhvc3QpXG5cblx0XHQvLyBCdWlsZCBhbGwgVUkgbm93IHRoYXQgbW9kZWwgYW5kIGF1dGhvcml6YXRpb24gc3RhdGUgYXJlIGtub3duXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblxuXHRcdGxvZ2dlci5pbmZvKCdEZXZpY2UgZGlzY292ZXJ5IGNvbXBsZXRlJylcblx0fVxuXG5cdC8vIFdoZW4gbW9kdWxlIGdldHMgZGVsZXRlZFxuXHRhc3luYyBkZXN0cm95KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuc3RDb250cm9sbGVyPy5jbG9zZSgpXG5cdFx0bG9nZ2VyLmRlYnVnKCdkZXN0cm95Jylcblx0fVxuXG5cdGFzeW5jIGNvbmZpZ1VwZGF0ZWQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRjb25zdCBwcmV2aW91c0hvc3QgPSB0aGlzLmhvc3Rcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGNvbnN0IGVmZmVjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKGNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIENsZWFyIHZhcmlhYmxlcyBpbW1lZGlhdGVseSBcdTIwMTQgdGhlIG5ldyBzZWxlY3Rpb24gaXNuJ3QgYXV0aG9yaXplZCB5ZXQuXG5cdFx0Ly8gVGhleSdsbCBiZSByZXBvcHVsYXRlZCBiZWxvdyBvbmNlIHZlcmlmeUF1dGhvcml6YXRpb24gY29tcGxldGVzLlxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXG5cdFx0Y29uc3QgbmV3SG9zdCA9IHRoaXMuaG9zdFxuXG5cdFx0Ly8gUmUtdmVyaWZ5IGF1dGhvcml6YXRpb24gb24gZXZlcnkgY29uZmlnIGNoYW5nZSAobW9kZWwgb3IgSVApLlxuXHRcdC8vIFRoaXMgaGFuZGxlcyBzd2l0Y2hpbmcgZnJvbSBhIHZhbGlkIGRldmljZSB0byBhbiBpbnZhbGlkIG9uZSBhbmQgYmFjay5cblx0XHRhd2FpdCB0aGlzLnZlcmlmeUF1dGhvcml6YXRpb24ocHJldmlvdXNIb3N0LCBuZXdIb3N0KVxuXG5cdFx0Ly8gUmVidWlsZCBVSSBhZnRlciBhdXRob3JpemF0aW9uIHN0YXRlIGlzIHNldHRsZWRcblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXHR9XG5cblx0LyoqXG5cdCAqIFJlLWV2YWx1YXRlcyB3aGV0aGVyIHRoZSBjdXJyZW50IGhvc3QrbW9kZWwgY29tYmluYXRpb24gaXMgYXV0aG9yaXplZC5cblx0ICogQ2FsbGVkIG9uIGV2ZXJ5IGNvbmZpZyBjaGFuZ2Ugc28gdGhhdCBzd2l0Y2hpbmcgbW9kZWwgb3IgSVAgaXMgYWx3YXlzIHZhbGlkYXRlZC5cblx0ICpcblx0ICogUnVsZXM6XG5cdCAqIC0gZGlzY292ZXJlZEhvc3Qgc2V0IFx1MjE5MiBkZXZpY2UgYWxyZWFkeSB2ZXJpZmllZCBieSBEYW50ZSwgYWx3YXlzIGF1dGhvcml6ZVxuXHQgKiAtIG1hbnVhbCBob3N0IFx1MjE5MiBjaGVjayBhZ2FpbnN0IGRpc2NvdmVyZWQgbGlzdCBmaXJzdDsgcHJvYmUgaWYgdW5rbm93blxuXHQgKiAgIC0gZGlzY292ZXJlZCBkZXZpY2UgYXQgdGhhdCBJUCB3aXRoIG1hdGNoaW5nIG1vZGVsIFx1MjE5MiBhdXRob3JpemVcblx0ICogICAtIGRpc2NvdmVyZWQgZGV2aWNlIGF0IHRoYXQgSVAgd2l0aCB3cm9uZyBtb2RlbCBcdTIxOTIgcmV2b2tlICsgbG9nIGVycm9yXG5cdCAqICAgLSBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjE5MiBwcm9iZTsgYXV0aG9yaXplIG9uIG1hdGNoLCByZXZva2Ugb24gbWlzbWF0Y2gvdGltZW91dFxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyB2ZXJpZnlBdXRob3JpemF0aW9uKHByZXZpb3VzSG9zdDogc3RyaW5nLCBuZXdIb3N0OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRpZiAoIW5ld0hvc3QpIHtcblx0XHRcdGlmIChwcmV2aW91c0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAodGhpcy5jb25maWcuZGlzY292ZXJlZEhvc3QpIHtcblx0XHRcdC8vIERpc2NvdmVyZWQgZGV2aWNlIFx1MjAxNCBpZGVudGl0eSBjb25maXJtZWQgYnkgRGFudGUsIGFsd2F5cyBhdXRob3JpemVkLlxuXHRcdFx0Ly8gUmV2b2tlIHRoZSBvbGQgaG9zdCBpZiBpdCBjaGFuZ2VkLlxuXHRcdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdH1cblx0XHRcdGNvbnN0IHdhc0F1dGhvcml6ZWQgPSB0aGlzLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQobmV3SG9zdClcblx0XHRcdGlmICghd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdH1cblx0XHRcdC8vIEZldGNoIHNldHRpbmdzIGlmIGhvc3QgY2hhbmdlZCBvciBkZXZpY2Ugd2Fzbid0IHByZXZpb3VzbHkgYXV0aG9yaXplZFxuXHRcdFx0aWYgKG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCB8fCAhd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhuZXdIb3N0KVxuXHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBnZXQgYWxsIHNldHRpbmdzIGZyb20gJHtuZXdIb3N0fTogJHtlfWApXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIE1hbnVhbCBtb2RlIFx1MjAxNCBjb25maWcuaG9zdCArIGNvbmZpZy5hY3RpdmVNb2RlbCBtdXN0IG1hdGNoXG5cdFx0Y29uc3QgbWFudWFsTW9kZWwgPSB0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbFxuXHRcdGNvbnN0IGRpc2NvdmVyZWRBdElwID0gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLmlwID09PSBuZXdIb3N0KVxuXG5cdFx0aWYgKGRpc2NvdmVyZWRBdElwKSB7XG5cdFx0XHQvLyBXZSBhbHJlYWR5IGtub3cgd2hhdCdzIGF0IHRoaXMgSVAgZnJvbSBkaXNjb3Zlcnlcblx0XHRcdGlmIChkaXNjb3ZlcmVkQXRJcC5tb2RlbCA9PT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRcdGNvbnN0IHdhc0F1dGhvcml6ZWQgPSB0aGlzLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQobmV3SG9zdClcblx0XHRcdFx0aWYgKCF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCB8fCAhd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MobmV3SG9zdClcblx0XHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIGdldCBhbGwgc2V0dGluZ3MgZnJvbSAke25ld0hvc3R9OiAke2V9YClcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdC8vIFdyb25nIG1vZGVsIHNlbGVjdGVkIGZvciB0aGlzIElQXG5cdFx0XHRcdGxvZ2dlci5lcnJvcihcblx0XHRcdFx0XHRgRGV2aWNlIHNlbGVjdGVkIChNb2RlbCAke21hbnVhbE1vZGVsfSkgZG9lcyBub3QgbWF0Y2ggZGV0ZWN0ZWQgZGV2aWNlIChNb2RlbCAke2Rpc2NvdmVyZWRBdElwLm1vZGVsfSkgYXQgJHtuZXdIb3N0fSBcdTIwMTQgY29tbWFuZHMgYmxvY2tlZGAsXG5cdFx0XHRcdClcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBJUCBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iZSBpdFxuXHRcdGxvZ2dlci5pbmZvKGAke25ld0hvc3R9IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgXHUyMDE0IHByb2JpbmdgKVxuXHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KSAvLyByZXZva2Ugd2hpbGUgd2UgcHJvYmVcblxuXHRcdGNvbnN0IHByb2JlZCA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnByb2JlRGV2aWNlKG5ld0hvc3QpXG5cdFx0aWYgKCFwcm9iZWQpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihgTm8gZGV2aWNlIHJlc3BvbmRlZCBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYClcblx0XHR9IGVsc2UgaWYgKHByb2JlZC5tb2RlbCAhPT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihcblx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtwcm9iZWQubW9kZWx9KSBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYCxcblx0XHRcdClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFZlcmlmaWVkIE1vZGVsICR7cHJvYmVkLm1vZGVsfSBhdCAke25ld0hvc3R9YClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKG5ld0hvc3QpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZ2V0IGFsbCBzZXR0aW5ncyBmcm9tICR7bmV3SG9zdH06ICR7ZX1gKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdC8qKiBMb2FkcyB0aGUgZGV2aWNlIEpTT04gZm9yIHRoZSBnaXZlbiBtb2RlbCBhbmQgcHVzaGVzIGl0IHRvIHRoZSBjb250cm9sbGVyLiAqL1xuXHRwcml2YXRlIHN5bmNNb2RlbChtb2RlbDogc3RyaW5nKTogdm9pZCB7XG5cdFx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghc2NoZW1hKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTW9kZWwgXCIke21vZGVsfVwiIG5vdCBmb3VuZCBpbiBkZXZpY2Ugc2NoZW1hc2ApXG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRNb2RlbChtb2RlbCwgW10sIHRydWUpXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRjb25zdCBhY3Rpb25zID0gQXJyYXkuaXNBcnJheShzY2hlbWEuY21kU2NoZW1hKSA/IHNjaGVtYS5jbWRTY2hlbWEgOiBbXVxuXHRcdGNvbnN0IHJlZnJlc2hBZnRlckNvbW1hbmQgPSBzY2hlbWEucmVmcmVzaEFmdGVyQ29tbWFuZCA/PyB0cnVlXG5cblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRNb2RlbChtb2RlbCwgYWN0aW9ucywgcmVmcmVzaEFmdGVyQ29tbWFuZClcblx0XHRpZiAoYWN0aW9ucy5sZW5ndGggPT09IDApIHtcblx0XHRcdGxvZ2dlci53YXJuKGBObyBhY3Rpb25zIGZvdW5kIGZvciBtb2RlbCBcIiR7bW9kZWx9XCIgXHUyMDE0IHNldHRpbmdzIGRlY29kaW5nIHdpbGwgdXNlIHJhdyBJRHNgKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdGBMb2FkZWQgJHthY3Rpb25zLmxlbmd0aH0gYWN0aW9ucyBmb3IgbW9kZWwgXCIke21vZGVsfVwiLCBzZWN0aW9uZWQ9JHtzY2hlbWEuc2VjdGlvbmVkfSwgcmVmcmVzaEFmdGVyQ29tbWFuZD0ke3JlZnJlc2hBZnRlckNvbW1hbmR9YCxcblx0XHRcdClcblx0XHR9XG5cdH1cblxuXHRnZXRDb25maWdGaWVsZHMoKTogU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkW10ge1xuXHRcdHJldHVybiBHZXRDb25maWdGaWVsZHModGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0fVxuXG5cdC8qKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgaG9zdCBJUCwgcHJlZmVycmluZyB0aGUgZGlzY292ZXJlZCBkZXZpY2Ugc2VsZWN0aW9uLiAqL1xuXHRnZXQgaG9zdCgpOiBzdHJpbmcge1xuXHRcdHJldHVybiByZXNvbHZlSG9zdCh0aGlzLmNvbmZpZylcblx0fVxuXG5cdC8qKiBSZXR1cm5zIGRpc2NvdmVyZWQgZGV2aWNlcyBmb3IgdXNlIGluIGFjdGlvbnMvY29uZmlnICovXG5cdGdldCBkZXZpY2VzKCk6IERldmljZUluZm9bXSB7XG5cdFx0cmV0dXJuIHRoaXMuZGlzY292ZXJlZERldmljZXNcblx0fVxuXG5cdHVwZGF0ZUFjdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlQWN0aW9ucyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlRmVlZGJhY2tzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZUZlZWRiYWNrcyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZVZhbHVlcygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZVZhbHVlcyh0aGlzKVxuXHR9XG59XG5cbmV4cG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH1cbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7O0FBa0JBLElBQU0scUJBQWtDLENBQUMsUUFBUSxPQUFPLFlBQVc7QUFFbEUsVUFBUSxJQUFJLElBQUksTUFBTSxZQUFXLENBQUUsSUFBSSxTQUFTLEtBQUssTUFBTSxNQUFNLEVBQUUsSUFBSSxPQUFPLEVBQUU7QUFDakY7QUFFQSxTQUFTLFVBQVUsUUFBNEIsT0FBaUIsU0FBZTtBQUM5RSxRQUFNLE9BQU8sT0FBTyxPQUFPLHFCQUFxQixhQUFhLE9BQU8sbUJBQW1CO0FBQ3ZGLE9BQUssUUFBUSxPQUFPLE9BQU87QUFDNUI7QUFPTSxTQUFVLG1CQUFtQixRQUFlO0FBQ2pELFNBQU87SUFDTixPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTztJQUM5RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTzs7QUFFaEU7OztBQ1RNLFNBQVUsWUFBWSxNQUFXO0FBRXZDOzs7QUNoQ0EsU0FBUyxvQkFBb0I7QUEyRXZCLElBQU8sc0JBQVAsY0FBbUMsYUFBbUM7RUFDbEU7RUFDQTtFQUVULElBQVcsV0FBUTtBQUNsQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUNBLElBQVcsYUFBVTtBQUNwQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUVBLElBQVksYUFBVTtBQUNyQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0FBQ25ELGFBQU8sS0FBSztJQUNiLE9BQU87QUFDTixhQUFPO0lBQ1I7RUFDRDtFQUVBLFNBQXVFO0VBRXZFLFlBQVksU0FBeUMsU0FBK0I7QUFDbkYsVUFBSztBQUVMLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVcsRUFBRSxHQUFHLFFBQU87RUFDN0I7RUFFQSxLQUFLLE1BQWMsVUFBbUIsVUFBcUI7QUFDMUQsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSx5QkFBeUI7QUFDN0YsWUFBUSxLQUFLLFFBQVE7TUFDcEIsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG9DQUFvQztNQUNyRCxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0seUJBQXlCO01BQzFDLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxtQkFBbUI7TUFDcEMsS0FBSztBQUNKO01BQ0Q7QUFDQyxvQkFBWSxLQUFLLE1BQU07QUFDdkIsY0FBTSxJQUFJLE1BQU0sc0JBQXNCO0lBQ3hDO0FBRUEsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxhQUFhLFFBQVE7QUFFM0MsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixRQUFRLEtBQUssU0FBUztNQUN0QixZQUFZOztLQUVaLEVBQ0EsS0FDQSxDQUFDLGFBQVk7QUFDWixXQUFLLFNBQVMsRUFBRSxZQUFZLE1BQU0sU0FBUTtBQUMxQyxXQUFLLFNBQVMsd0JBQXdCLElBQUksVUFBVSxJQUFJO0FBQ3hELFdBQUssS0FBSyxXQUFXO0lBQ3RCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTO0FBQ2QsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxNQUFNLFVBQXFCO0FBQzFCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7SUFFcEQsT0FBTztBQUNOLGNBQVEsS0FBSyxRQUFRO1FBQ3BCLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0NBQW9DO1FBQ3JELEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQkFBb0I7UUFDckM7QUFDQyxzQkFBWSxLQUFLLE1BQU07QUFDdkIsZ0JBQU0sSUFBSSxNQUFNLHNCQUFzQjtNQUN4QztJQUNEO0FBRUEsVUFBTSxXQUFXLEtBQUssT0FBTztBQUM3QixTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLFNBQVMsUUFBUTtBQUV2QyxTQUFLLFNBQ0gscUJBQXFCO01BQ3JCO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssT0FBTztJQUNsQixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBV0EsS0FDQyxjQUNBLGNBQ0EsaUJBQ0EsZ0JBQ0EsU0FDQSxVQUFxQjtBQUVyQixRQUFJLE9BQU8saUJBQWlCO0FBQVUsWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ3pFLFFBQUksT0FBTyxvQkFBb0IsVUFBVTtBQUN4QyxVQUFJLE9BQU8sbUJBQW1CLFlBQVksT0FBTyxZQUFZO0FBQVUsY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQzFHLFVBQUksYUFBYSxVQUFhLE9BQU8sYUFBYTtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUVqRyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsY0FBYyxlQUFlO0FBQzlFLFdBQUssV0FBVyxRQUFRLGdCQUFnQixTQUFTLFFBQVE7SUFDMUQsV0FBVyxPQUFPLG9CQUFvQixVQUFVO0FBQy9DLFVBQUksbUJBQW1CLFVBQWEsT0FBTyxtQkFBbUI7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFN0csWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLEdBQUcsTUFBUztBQUM3RCxXQUFLLFdBQVcsUUFBUSxjQUFjLGlCQUFpQixjQUFjO0lBQ3RFLE9BQU87QUFDTixZQUFNLElBQUksTUFBTSxtQkFBbUI7SUFDcEM7RUFDRDtFQUVBLGVBQ0MsY0FDQSxRQUNBLFFBQTBCO0FBRTFCLFFBQUk7QUFDSixRQUFJLE9BQU8saUJBQWlCLFVBQVU7QUFDckMsZUFBUyxPQUFPLEtBQUssY0FBYyxPQUFPO0lBQzNDLFdBQVcsT0FBTyxTQUFTLFlBQVksR0FBRztBQUN6QyxlQUFTO0lBQ1YsV0FBVyxNQUFNLFFBQVEsWUFBWSxHQUFHO0FBRXZDLGFBQU8sT0FBTyxLQUFLLFlBQVk7SUFDaEMsT0FBTztBQUNOLGVBQVMsT0FBTyxLQUFLLGFBQWEsUUFBUSxhQUFhLFlBQVksYUFBYSxVQUFVO0lBQzNGO0FBRUEsV0FBTyxPQUFPLFNBQVMsUUFBUSxXQUFXLFNBQVksU0FBUyxTQUFTLE1BQVM7RUFDbEY7RUFFQSxXQUFXLFFBQWdCLE1BQWMsU0FBaUIsVUFBcUI7QUFDOUUsUUFBSSxDQUFDLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUV6RixTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFVBQVUsS0FBSyxPQUFPO01BQ3RCLFNBQVM7TUFFVDtNQUNBO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixpQkFBVTtJQUNYLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxxQkFBcUIsU0FBK0I7QUFDbkQsUUFBSTtBQUNILFdBQUssS0FBSyxXQUFXLFFBQVEsU0FBUyxRQUFRLE1BQU07SUFDckQsU0FBUyxJQUFJO0lBRWI7RUFDRDtFQUNBLG1CQUFtQixPQUFZO0FBQzlCLFNBQUssU0FBUztBQUVkLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFFBQUk7QUFBWSxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sV0FBVyxRQUFRO0FBRWhGLFFBQUk7QUFDSCxXQUFLLEtBQUssU0FBUyxLQUFLO0lBQ3pCLFNBQVMsSUFBSTtJQUViO0VBQ0Q7Ozs7QUM5UEssU0FBVSxrQkFBbUQsS0FBWTtBQUM5RSxRQUFNLE9BQU87QUFDYixTQUFPLENBQUMsQ0FBQyxRQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSyxPQUFPLFlBQVksS0FBSyx1QkFBdUI7QUFDekc7OztBQzZCTSxJQUFnQixlQUFoQixNQUE0QjtFQUN4QjtFQUNBO0VBRUE7RUFFVCxJQUFXLEtBQUU7QUFDWixXQUFPLEtBQUssU0FBUztFQUN0QjtFQUVBLElBQVcsa0JBQWU7QUFDekIsV0FBTyxLQUFLO0VBQ2I7Ozs7O0VBTUEsSUFBVyxRQUFLO0FBQ2YsV0FBTyxLQUFLLFNBQVM7RUFDdEI7Ozs7RUFLQSxZQUFZLFVBQWlCO0FBQzVCLFFBQUksQ0FBQyxrQkFBNkIsUUFBUSxLQUFLLENBQUMsU0FBUztBQUN4RCxZQUFNLElBQUksTUFDVCxtR0FBbUc7QUFHckcsU0FBSyxXQUFXO0FBRWhCLFNBQUssVUFBVSxtQkFBa0I7QUFFakMsU0FBSyx3QkFBd0IsS0FBSyxzQkFBc0IsS0FBSyxJQUFJO0FBRWpFLFNBQUssV0FBVztNQUNmLDJCQUEyQjtNQUMzQix3QkFBd0I7O0FBR3pCLFNBQUssSUFBSSxTQUFTLGNBQWM7RUFDakM7RUErQkEsV0FBVyxXQUE0QyxZQUFpQztBQUN2RixTQUFLLFNBQVMsV0FBVyxXQUFXLFVBQVU7RUFDL0M7Ozs7O0VBdUJBLHFCQUFxQixTQUF5RDtBQUM3RSxTQUFLLFNBQVMscUJBQXFCLE9BQU87RUFDM0M7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7O0VBT0EscUJBQ0MsV0FDQSxTQUE4QztBQUU5QyxTQUFLLFNBQVMscUJBQXFCLFdBQVcsT0FBTztFQUN0RDs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsUUFBSSxNQUFNLFFBQVEsU0FBUztBQUFHLFlBQU0sSUFBSSxNQUFNLHdEQUF3RDtBQUV0RyxTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7O0VBTUEsa0JBQWtCLFFBQXVDO0FBQ3hELFNBQUssU0FBUyxrQkFBa0IsTUFBTTtFQUN2Qzs7Ozs7O0VBT0EsaUJBQW1DLFlBQWE7QUFDL0MsV0FBTyxLQUFLLFNBQVMsaUJBQWlCLFVBQVU7RUFDakQ7Ozs7RUFLQSxvQkFBaUI7QUFDaEIsU0FBSyxTQUFTLGtCQUFpQjtFQUNoQzs7Ozs7OztFQVFBLGVBQ0MsaUJBQ0csZUFBbUQ7QUFFdEQsU0FBSyxTQUFTLGVBQWUsQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO0VBQzlEOzs7OztFQU1BLHNCQUFzQixhQUFxQjtBQUMxQyxTQUFLLFNBQVMsbUJBQW1CLFdBQVc7RUFDN0M7Ozs7OztFQU9BLG9CQUFvQixXQUFtQjtBQUN0QyxTQUFLLFNBQVMsaUJBQWlCLFNBQVM7RUFDekM7Ozs7OztFQU1BLHNCQUFzQixXQUFtQjtBQUN4QyxTQUFLLFNBQVMsbUJBQW1CLFNBQVM7RUFDM0M7Ozs7OztFQU9BLHdCQUF3QixhQUFxQjtBQUM1QyxTQUFLLFNBQVMscUJBQXFCLFdBQVc7RUFDL0M7Ozs7OztFQU9BLGFBQWEsUUFBaUMsY0FBcUI7QUFDbEUsU0FBSyxTQUFTLGFBQWEsUUFBUSxZQUFZO0VBQ2hEOzs7Ozs7OztFQVNBLFFBQVEsTUFBYyxNQUFjQSxPQUFjLE1BQXNCO0FBQ3ZFLFNBQUssU0FBUyxRQUFRLE1BQU0sTUFBTUEsT0FBTSxJQUFJO0VBQzdDOzs7Ozs7Ozs7OztFQVlBLGFBQWEsUUFBd0IsU0FBdUI7QUFDM0QsU0FBSyxTQUFTLGFBQWEsUUFBUSxXQUFXLElBQUk7RUFDbkQ7Ozs7OztFQU9BLElBQUksT0FBaUIsU0FBZTtBQUNuQyxZQUFRLE9BQU87TUFDZCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNEO0FBQ0Msb0JBQVksS0FBSztBQUNqQixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO0lBQ0Y7RUFDRDtFQVlBLHNCQUNDLGVBQ0EsVUFBeUM7QUFFekMsVUFBTSxVQUFrQyxPQUFPLGtCQUFrQixXQUFXLEVBQUUsTUFBTSxjQUFhLElBQUs7QUFFdEcsVUFBTSxTQUFTLElBQUksb0JBQW9CLEtBQUssVUFBVSxPQUFPO0FBQzdELFFBQUk7QUFBVSxhQUFPLEdBQUcsV0FBVyxRQUFRO0FBRTNDLFdBQU87RUFDUjs7OztBQy9VRCxJQUFZO0NBQVosU0FBWUMsaUJBQWM7QUFDekIsRUFBQUEsZ0JBQUEsSUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsWUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsbUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFdBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGdCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx1QkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEseUJBQUEsSUFBQTtBQUNELEdBVlksbUJBQUEsaUJBQWMsQ0FBQSxFQUFBO0FBYXBCLElBQVc7Q0FBakIsU0FBaUJDLFFBQUs7QUFFUixFQUFBQSxPQUFBLEtBQUs7QUFDTCxFQUFBQSxPQUFBLFdBQ1o7QUFDWSxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLE9BQ1o7QUFDWSxFQUFBQSxPQUFBLGNBQWM7QUFDZCxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLFFBQVE7QUFDUixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLFNBQVM7QUFDVCxFQUFBQSxPQUFBLGdCQUFnQjtBQUNoQixFQUFBQSxPQUFBLFlBQVk7QUFDWixFQUFBQSxPQUFBLFdBQ1o7QUFDRixHQWxCaUIsVUFBQSxRQUFLLENBQUEsRUFBQTs7O0FDakJ0QixPQUFPLFFBQVE7QUFDZixPQUFPLFVBQVU7QUFJakIsSUFBTSxTQUFTLG1CQUFtQixRQUFRO0FBcUIxQyxTQUFTLHVCQUFvQjtBQUM1QixRQUFNLGNBQWMsS0FBSyxLQUFLLFlBQVksU0FBUyxZQUFZO0FBQy9ELFFBQU0sZUFBZSxLQUFLLEtBQUssWUFBWSxTQUFTLFdBQVc7QUFHL0QsTUFBSSxHQUFHLFdBQVcsV0FBVyxHQUFHO0FBQy9CLFdBQU8sTUFBTSx5QkFBeUIsV0FBVyxFQUFFO0FBQ25ELFdBQU87RUFDUjtBQUdBLE1BQUksR0FBRyxXQUFXLFlBQVksR0FBRztBQUNoQyxXQUFPLEtBQUsscURBQXFELFlBQVksRUFBRTtBQUMvRSxXQUFPO0VBQ1I7QUFHQSxRQUFNLFdBQVc7O01BQTBDLFdBQVc7TUFBUyxZQUFZOztBQUMzRixTQUFPLE1BQU0sUUFBUTtBQUNyQixRQUFNLElBQUksTUFBTSxRQUFRO0FBQ3pCO0FBR0EsSUFBTSxnQkFBZ0IscUJBQW9CO0FBRzFDLElBQUkscUJBQWlEO0FBTS9DLFNBQVUsbUJBQWdCO0FBQy9CLFNBQU87QUFDUjtBQU1BLFNBQVMsb0JBQWlCO0FBQ3pCLFFBQU0sVUFBK0IsQ0FBQTtBQUNyQyxNQUFJO0FBQ0gsVUFBTSxRQUFRLEdBQUcsWUFBWSxhQUFhLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLE9BQU8sQ0FBQztBQUU3RSxlQUFXLEtBQUssT0FBTztBQUN0QixZQUFNLFdBQVcsS0FBSyxLQUFLLGVBQWUsQ0FBQztBQUMzQyxZQUFNLE9BQU8sS0FBSyxNQUFNLEdBQUcsYUFBYSxVQUFVLE1BQU0sQ0FBQztBQUN6RCxVQUFJLE1BQU0sT0FBTztBQUNoQixnQkFBUSxPQUFPLEtBQUssS0FBSyxDQUFDLElBQUk7TUFDL0I7SUFDRDtBQUVBLFdBQU8sTUFBTSxVQUFVLE9BQU8sS0FBSyxPQUFPLEVBQUUsTUFBTSw0QkFBNEI7RUFDL0UsU0FBUyxHQUFHO0FBQ1gsV0FBTyxNQUFNLGtDQUFrQyxDQUFDLEVBQUU7RUFDbkQ7QUFDQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLG1CQUFnQjtBQUMvQixNQUFJLENBQUMsb0JBQW9CO0FBQ3hCLHlCQUFxQixrQkFBaUI7RUFDdkM7QUFDQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLGdCQUFnQixPQUFhO0FBQzVDLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsU0FBTyxRQUFRLEtBQUs7QUFDckI7QUFNTSxTQUFVLHNCQUFtQjtBQUNsQyxTQUFPLEtBQUssdUNBQXVDO0FBQ25ELHVCQUFxQixrQkFBaUI7QUFDdkM7QUFLQSxTQUFTLHNCQUFtQjtBQUMzQixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFNBQU8sT0FBTyxLQUFLLE9BQU8sRUFBRSxLQUFJO0FBQ2pDO0FBRU0sU0FBVSxnQkFBZ0Isb0JBQWtDLENBQUEsR0FBRTtBQUNuRSxRQUFNLFNBQVMsb0JBQW1CO0FBS2xDLFFBQU0sZ0JBQWdCO0lBQ3JCLEVBQUUsSUFBSSxJQUFJLE9BQU8sU0FBUTtJQUN6QixHQUFHLGtCQUFrQixJQUFJLENBQUMsT0FBTztNQUNoQyxJQUFJLEVBQUU7TUFDTixPQUFPLFNBQVMsRUFBRSxLQUFLLEtBQUssRUFBRSxFQUFFO01BQy9COztBQUdILFNBQU87Ozs7SUFJTjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsU0FBUztNQUNULFNBQVM7Ozs7O0lBTVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULE9BQU8sTUFBTTtNQUNiLHFCQUFxQjtNQUNyQixTQUFTOzs7OztJQU1WO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVMsT0FBTyxDQUFDLEtBQUs7TUFDdEIsU0FBUyxPQUFPLElBQUksQ0FBQyxXQUFXO1FBQy9CLElBQUk7UUFDSixPQUFPLFNBQVMsS0FBSztRQUNwQjtNQUNGLHFCQUFxQjtNQUNyQixTQUFTOzs7QUFHWjtBQU1NLFNBQVUsWUFBWSxRQUFvQjtBQUMvQyxTQUFPLE9BQU8sa0JBQWtCLE9BQU87QUFDeEM7QUFPTSxTQUFVLGFBQWEsUUFBc0IsbUJBQStCO0FBQ2pGLE1BQUksT0FBTyxnQkFBZ0I7QUFDMUIsVUFBTSxTQUFTLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxjQUFjO0FBQzNFLFdBQU8sTUFBTSxpQ0FBaUMsT0FBTyxjQUFjLG9CQUFvQixRQUFRLFNBQVMsTUFBTSxFQUFFO0FBQ2hILFFBQUksUUFBUSxPQUFPO0FBQ2xCLGFBQU8sT0FBTztJQUNmO0FBRUEsUUFBSSxrQkFBa0IsV0FBVyxHQUFHO0FBQ25DLGFBQU8sS0FBSyw2REFBNkQ7QUFDekUsYUFBTztJQUNSO0VBQ0Q7QUFDQSxTQUFPLE1BQU0sOENBQThDLE9BQU8sV0FBVyxHQUFHO0FBQ2hGLFNBQU8sT0FBTztBQUNmOzs7QUM5TU0sU0FBVSwwQkFBMEIsTUFBb0I7QUFDN0QsT0FBSyx1QkFBdUI7SUFDM0IsT0FBTyxFQUFFLE1BQU0sc0JBQXFCO0lBQ3BDLFdBQVcsRUFBRSxNQUFNLHVDQUFzQztJQUN6RCxjQUFjLEVBQUUsTUFBTSxzQkFBcUI7SUFDM0MsVUFBVSxFQUFFLE1BQU0sMEJBQXlCO0lBQzNDLFNBQVMsRUFBRSxNQUFNLGdDQUErQjtJQUNoRCxLQUFLLEVBQUUsTUFBTSxxQkFBb0I7SUFDakMsSUFBSSxFQUFFLE1BQU0sb0JBQW1CO0dBQy9CO0FBQ0Y7QUFFQSxJQUFNLG9CQUFvQjtFQUN6QixPQUFPO0VBQ1AsV0FBVztFQUNYLGNBQWM7RUFDZCxVQUFVO0VBQ1YsU0FBUztFQUNULEtBQUs7RUFDTCxJQUFJOztBQVFDLFNBQVUscUJBQXFCLE1BQW9CO0FBQ3hELFFBQU0sY0FBYyxLQUFLO0FBR3pCLE1BQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxhQUFhLG1CQUFtQixXQUFXLEdBQUc7QUFDdkUsU0FBSyxrQkFBa0IsaUJBQWlCO0FBQ3hDO0VBQ0Q7QUFFQSxRQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxXQUFXO0FBQzVELE1BQUksUUFBUTtBQUNYLFNBQUssa0JBQWtCO01BQ3RCLE9BQU8sT0FBTyxTQUFTO01BQ3ZCLFdBQVcsT0FBTyxhQUFhO01BQy9CLGNBQWMsT0FBTyxnQkFBZ0I7TUFDckMsVUFBVSxPQUFPLGdCQUFnQjtNQUNqQyxTQUFTLE9BQU8saUJBQWlCO01BQ2pDLEtBQUssT0FBTyxPQUFPO01BQ25CLElBQUksT0FBTztLQUNYO0VBQ0YsT0FBTztBQUdOLFNBQUssa0JBQWtCO01BQ3RCLEdBQUc7TUFDSCxJQUFJO0tBQ0o7RUFDRjtBQUNEOzs7QUMxRE8sSUFBTSxpQkFBK0Q7Ozs7Ozs7Ozs7Ozs7OztBQ3FCckUsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sY0FBYztBQUNwQixJQUFNLGdCQUFnQjtBQUN0QixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGFBQWE7QUFDbkIsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxvQkFBb0I7QUFDMUIsSUFBTSxlQUFlO0FBQ3JCLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sY0FBYztBQUdyQixTQUFVLGVBQWUsT0FBYTtBQUMzQyxVQUFRLE9BQU87SUFDZCxLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSO0FBQ0MsYUFBTyxTQUFTLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztFQUNyRDtBQUNEO0FBUU0sU0FBVSxjQUNmLE9BQ0EsT0FDQSxXQUNBLE9BQXVCO0FBRXZCLFFBQU0sTUFBTSxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzdELFFBQU0sS0FBSyxPQUFPLGNBQWMsV0FBVyxVQUFVLFNBQVMsRUFBRSxJQUFJO0FBRXBFLE1BQUksVUFBVSxRQUFXO0FBQ3hCLFVBQU0sS0FBSyxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzVELFdBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFO0VBQ25DO0FBRUEsU0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRTtBQUM3QjtBQVNNLFNBQVUsTUFBTSxPQUFlLFlBQVksR0FBQztBQUNqRCxTQUFPLEtBQUssTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLFdBQVcsR0FBRyxDQUFDO0FBQ3hEO0FBT00sU0FBVSxXQUFXLE9BQXdCO0FBQ2xELFNBQU8sS0FBSyxNQUFNLEtBQUssS0FBSyxFQUMxQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLENBQUM7QUFDWDtBQVNNLFNBQVUsZUFBZSxHQUFXLEdBQVcsR0FBUztBQUM3RCxTQUFPLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUNqQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLEVBQ1AsWUFBVyxDQUFFO0FBQ2hCO0FBUU0sU0FBVSxlQUFlLElBQVU7QUFDeEMsUUFBTSxDQUFDLE9BQU8sVUFBVSxLQUFLLElBQUksR0FBRyxNQUFNLEdBQUc7QUFDN0MsU0FBTztJQUNOO0lBQ0EsT0FBTyxTQUFTLFVBQVUsRUFBRTtJQUM1QixRQUFRLFNBQVMsT0FBTyxFQUFFOztBQUU1QjtBQVVNLFNBQVUsY0FBYyxRQUFnQixRQUFjO0FBQzNELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELE1BQUksT0FBTyxNQUFNLEVBQUUsS0FBSyxPQUFPLE1BQU0sRUFBRTtBQUFHLFdBQU87QUFDakQsU0FBTyxLQUFLLElBQUksS0FBSyxFQUFFO0FBQ3hCO0FBU00sU0FBVSxxQkFDZixZQUErQjtBQUUvQixRQUFNLGFBQWtFLENBQUE7QUFDeEUsYUFBVyxDQUFDLE9BQU8sSUFBSSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDdkQsZUFBVyxLQUFLLElBQUk7TUFDbkIsT0FBTyxLQUFLO01BQ1osV0FBVyxNQUFNLFFBQVEsS0FBSyxTQUFTLElBQUksS0FBSyxZQUFZLENBQUE7O0VBRTlEO0FBQ0EsU0FBTztBQUNSO0FBWU0sU0FBVSxxQkFDZixTQUNBLE9BQ0EsT0FDQSxXQUFpQjtBQUVqQixRQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLE1BQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxRQUFRLE9BQU8sU0FBUztBQUFHLFdBQU87QUFHeEQsTUFBSSxTQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUd2RixNQUFJLENBQUMsUUFBUTtBQUNaLGFBQVMsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFVO0FBQ3pDLFVBQUksRUFBRSxXQUFXO0FBQU8sZUFBTztBQUMvQixZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLFNBQVMsWUFBWSxFQUFFO0FBQzdCLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0lBQzVELENBQUM7RUFDRjtBQUVBLFNBQU87QUFDUjs7O0FDdE1BLFNBQVMsWUFBWSxHQUFNO0FBQzFCLFFBQU0sT0FBTztJQUNaLE1BQU0sRUFBRTtJQUNSLElBQUksRUFBRTtJQUNOLE9BQU8sRUFBRTtJQUNULFNBQVMsRUFBRTtJQUNYLFNBQVMsRUFBRTs7QUFHWixVQUFRLEVBQUUsTUFBTTtJQUNmLEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLENBQUEsRUFBRTtJQUUzQyxLQUFLO0FBQ0osYUFBTztRQUNOLEdBQUc7UUFDSCxLQUFLLEVBQUU7UUFDUCxLQUFLLEVBQUU7UUFDUCxNQUFNLEVBQUUsUUFBUTtRQUNoQixPQUFPOztJQUdULEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLE1BQUs7SUFFOUMsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0w7QUFDQyxhQUFPO0VBQ1Q7QUFDRDtBQU1NLFNBQVUsZUFBWTtBQUMzQixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sVUFBc0MsQ0FBQTtBQUU1QyxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLEtBQUssV0FBVztBQUMxQixZQUFNLFdBQVcsY0FBYyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7QUFFcEQsWUFBTSxXQUFXLEVBQUUsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRWpELFlBQU0sU0FBb0M7UUFDekMsTUFBTSxTQUFTLEtBQUssS0FBSyxFQUFFLElBQUk7UUFDL0I7UUFDQSxVQUFVLFlBQVc7UUFFckI7O0FBR0QsY0FBUSxRQUFRLElBQUk7SUFDckI7RUFDRDtBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsaUJBQWM7QUFDN0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxRQUFNLFlBQTBDLENBQUE7QUFFaEQsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxXQUFXLFdBQVc7QUFDaEMsWUFBTSxpQkFBaUIsY0FBYyxPQUFPLFFBQVEsUUFBUSxRQUFRLEVBQUU7QUFHdEUsWUFBTSxjQUFjLFFBQVEsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRzFELFlBQU0sZUFBZSxXQUFXLE9BQU8sQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBR3ZFLG1CQUFhLEtBQUs7UUFDakIsTUFBTTtRQUNOLElBQUk7UUFDSixPQUFPO1FBQ1AsU0FBUztRQUNULFNBQVM7T0FDVDtBQUdELFlBQU0sZ0JBQXFCO1FBQzFCLE1BQU07UUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtRQUNyQyxTQUFTO1FBQ1QsVUFBVSxNQUFLO0FBRWQsaUJBQU87UUFDUjs7QUFHRCxnQkFBVSxjQUFjLElBQUk7SUFDN0I7RUFDRDtBQUVBLFNBQU87QUFDUjs7O0FDNUhBLE9BQU9DLFdBQVU7OztBQ0xqQixPQUFPQyxTQUFRO0FBZ0JmLElBQU1DLFVBQVMsbUJBQW1CLGdCQUFnQjtBQXlDbEQsU0FBUyxlQUFlLE9BQWE7QUFDcEMsUUFBTSxTQUFTLG9CQUFJLElBQUc7QUFDdEIsTUFBSSxZQUFZO0FBRWhCLE1BQUk7QUFFSCxVQUFNLE9BQU8sZ0JBQWdCLEtBQUs7QUFDbEMsUUFBSSxDQUFDLE1BQU07QUFFVixhQUFPLEVBQUUsV0FBVyxPQUFNO0lBQzNCO0FBR0EsZ0JBQVksS0FBSyxhQUFhO0FBRzlCLGVBQVcsVUFBVSxLQUFLLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0saUJBQWlCLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBd0IsSUFBSSxTQUFTLGFBQWE7QUFDL0YsVUFBSSxnQkFBZ0I7QUFFbkIsZUFBTyxJQUFJLE9BQU8sRUFBRTtBQUdwQixjQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLE9BQU8sT0FBTztBQUNwRixZQUFJLGFBQWEsU0FBUztBQUN6QixxQkFBVyxVQUFVLFlBQVksU0FBUztBQUN6QyxnQkFBSSxPQUFPLE9BQU8sT0FBTyxVQUFVO0FBQ2xDLHFCQUFPLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRTtZQUNqQztVQUNEO1FBQ0Q7TUFDRDtJQUNEO0VBQ0QsU0FBUyxNQUFNO0VBRWY7QUFFQSxTQUFPLEVBQUUsV0FBVyxPQUFNO0FBQzNCO0FBTUEsU0FBUyxzQkFBc0IsS0FBVztBQUN6QyxRQUFNLFdBQVcsSUFBSSxRQUFRLE9BQU8sS0FBSyxVQUFVLENBQUM7QUFDcEQsTUFBSSxXQUFXO0FBQUcsVUFBTSxJQUFJLE1BQU0saUNBQWlDO0FBRW5FLFFBQU0sZUFBZSxXQUFXO0FBQ2hDLE1BQUksSUFBSSxZQUFZLE1BQU0sSUFBTTtBQUMvQixVQUFNLElBQUksTUFBTSx1Q0FBdUMsSUFBSSxZQUFZLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRTtFQUN4RjtBQUVBLFNBQU87QUFDUjtBQU1BLFNBQVMsdUJBQXVCLE9BQWUsU0FBc0Isb0JBQUksSUFBRyxHQUFFO0FBQzdFLE1BQUksSUFBSTtBQUNSLFFBQU0sTUFBdUIsQ0FBQTtBQUU3QixTQUFPLElBQUksTUFBTSxRQUFRO0FBQ3hCLFVBQU0sS0FBSyxNQUFNLENBQUM7QUFDbEIsUUFBSSxJQUFJLEtBQUssTUFBTTtBQUFRO0FBRzNCLFFBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTSxRQUFRO0FBQzNDLFVBQUksS0FBSztRQUNSLFFBQVE7UUFDUjtRQUNBLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQztPQUNyRDtBQUNELFdBQUs7QUFDTDtJQUNEO0FBRUEsUUFBSSxLQUFLLEVBQUUsUUFBUSxjQUFjLElBQUksWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFFO0FBQ2pFLFNBQUs7RUFDTjtBQUVBLFNBQU87QUFDUjtBQUVNLFNBQVUseUJBQXlCLEtBQWEsT0FBYTtBQUNsRSxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSw0QkFBNEI7RUFDN0M7QUFFQSxRQUFNLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFDNUIsUUFBTSxRQUFRLE1BQU07QUFDcEIsUUFBTSxNQUFNLFFBQVE7QUFDcEIsTUFBSSxNQUFNLElBQUk7QUFBUSxVQUFNLElBQUksTUFBTSxzQkFBc0I7QUFFNUQsUUFBTSxFQUFFLE9BQU0sSUFBSyxlQUFlLEtBQUs7QUFDdkMsU0FBTyx1QkFBdUIsSUFBSSxTQUFTLE9BQU8sR0FBRyxHQUFHLE1BQU07QUFDL0Q7QUFNTSxTQUFVLDhCQUE4QixLQUFhLE9BQWE7QUFDdkUsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0sNEJBQTRCO0VBQzdDO0FBR0EsTUFBSSxJQUFJLFVBQVUsdUJBQXVCLE1BQU0sSUFBSSxNQUFNO0FBQ3pELFFBQU0sTUFBTSxJQUFJLFNBQVM7QUFDekIsUUFBTSxNQUF1QixDQUFBO0FBRzdCLFFBQU0sRUFBRSxPQUFNLElBQUssZUFBZSxLQUFLO0FBR3ZDLFFBQU0sb0JBQW9CLENBQUMsYUFBYSxpQkFBaUIsV0FBVztBQUVwRSxTQUFPLElBQUksSUFBSSxLQUFLO0FBQ25CLFVBQU0sU0FBUyxJQUFJLENBQUM7QUFDcEIsVUFBTSxlQUFlLElBQUksSUFBSSxDQUFDO0FBRTlCLFVBQU0sYUFBYSxJQUFJLElBQUk7QUFDM0IsUUFBSSxhQUFhO0FBQUs7QUFHdEIsVUFBTSxXQUFXLGtCQUFrQixTQUFTLFlBQVk7QUFFeEQsUUFBSTtBQUNKLFFBQUk7QUFDSixRQUFJO0FBRUosUUFBSSxVQUFVO0FBRWIsY0FBUSxJQUFJLElBQUksQ0FBQztBQUNqQixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVCxPQUFPO0FBRU4sZ0JBQVUsSUFBSSxJQUFJLENBQUM7QUFDbkIsVUFBSSxJQUFJO0lBQ1Q7QUFFQSxVQUFNLE9BQU8sSUFBSTtBQUVqQixXQUFPLElBQUksSUFBSSxNQUFNO0FBQ3BCLFlBQU0sS0FBSyxJQUFJLENBQUM7QUFDaEIsVUFBSTtBQUdKLFVBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTTtBQUNuQyxxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ2hELGFBQUs7TUFDTixPQUFPO0FBQ04scUJBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ3hCLGFBQUs7TUFDTjtBQUVBLFlBQU0sVUFBeUI7UUFDOUIsUUFBUTtRQUNSO1FBQ0E7O0FBRUQsVUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQVEsUUFBUTtNQUNqQjtBQUNBLFVBQUksS0FBSyxPQUFPO0lBQ2pCO0FBRUEsUUFBSTtFQUNMO0FBRUEsU0FBTztBQUNSO0FBV00sU0FBVSxzQkFBc0IsT0FBZSxLQUFXO0FBQy9ELFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLGlDQUFpQyxNQUFNLFNBQVMsRUFBRSxDQUFDLEdBQUc7RUFDdkU7QUFDQSxRQUFNLEVBQUUsVUFBUyxJQUFLLGVBQWUsS0FBSztBQUMxQyxTQUFPLFlBQVksOEJBQThCLEtBQUssS0FBSyxJQUFJLHlCQUF5QixLQUFLLEtBQUs7QUFDbkc7QUFNTSxTQUFVLG9CQUFvQixTQUF3QixTQUFtQjtBQUU5RSxNQUFJLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsUUFBUSxVQUFVLEVBQUUsT0FBTyxRQUFRLEVBQUU7QUFLbkYsTUFBSSxDQUFDLFFBQVE7QUFDWixVQUFNLGFBQWEsUUFBUSxLQUFLLENBQUMsTUFBSztBQUNyQyxVQUFJLEVBQUUsV0FBVyxRQUFRO0FBQVEsZUFBTztBQUV4QyxZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQy9ELFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLGdCQUFnQixRQUFRLEtBQUssRUFBRTtBQUNyQyxhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtJQUM5RCxDQUFDO0FBQ0QsUUFBSSxZQUFZO0FBQ2YsZUFBUztJQUNWO0VBQ0Q7QUFFQSxRQUFNLFNBQVMsTUFBTSxRQUFRLE1BQU07QUFDbkMsUUFBTSxRQUFRLE1BQU0sUUFBUSxFQUFFO0FBQzlCLFFBQU0sU0FBUyxXQUFXLFFBQVEsVUFBVTtBQUM1QyxRQUFNLFNBQ0wsUUFBUSxXQUFXLFdBQVcsSUFDM0IsZUFBZSxRQUFRLFdBQVcsQ0FBQyxHQUFHLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsQ0FBQyxJQUNsRixRQUFRLFdBQVcsV0FBVyxJQUM3QixRQUFRLFdBQVcsQ0FBQyxJQUNwQixRQUFRLFdBQVcsS0FBSyxHQUFHO0FBR2hDLFFBQU0sV0FBVyxRQUFRLFVBQVUsU0FBWSxPQUFPLFFBQVEsS0FBSyxLQUFLO0FBQ3hFLFFBQU0sU0FBUyxPQUFPLE1BQU0sR0FBRyxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU07QUFHakUsTUFBSSxRQUFRO0FBQ1gsUUFBSSxPQUFPLE9BQU87QUFHbEIsUUFBSSxRQUFRLFVBQVUsUUFBVztBQUNoQyxhQUFPLEdBQUcsSUFBSSxNQUFNLFFBQVEsUUFBUSxDQUFDO0lBQ3RDLE9BRUs7QUFDSixZQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksYUFBYSxTQUFTO0FBQ3pCLGNBQU0sZ0JBQWdCLFFBQVEsS0FBSyxPQUFPO0FBQzFDLGNBQU0sY0FBYyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGFBQWE7QUFDMUUsWUFBSSxhQUFhO0FBQ2hCLGlCQUFPLEdBQUcsSUFBSSxJQUFJLFlBQVksS0FBSztRQUNwQztNQUNEO0lBQ0Q7QUFHQSxVQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFFBQUksYUFBYSxXQUFXLFFBQVEsV0FBVyxXQUFXLEdBQUc7QUFDNUQsWUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxXQUFXLENBQUMsQ0FBQztBQUM3RSxVQUFJLFFBQVE7QUFDWCxlQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNO01BQ3ZEO0lBQ0Q7QUFDQSxXQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxNQUFNO0VBQ3RDO0FBR0EsU0FBTyxHQUFHLE1BQU07QUFDakI7QUFpQk0sU0FBVSxpQ0FDZixPQUNBLEtBQVc7QUFFWCxRQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsUUFBTSxvQkFBb0IsUUFBUTtBQUdsQyxNQUFJLHNCQUFzQixRQUFXO0FBQ3BDLFVBQU0sV0FBVyxvQkFDZCw4QkFBOEIsS0FBSyxLQUFLLElBQ3hDLHlCQUF5QixLQUFLLEtBQUs7QUFDdEMsV0FBTyxFQUFFLFVBQVUsbUJBQW1CLEtBQUk7RUFDM0M7QUFHQSxNQUFJLGVBQWdDLENBQUE7QUFDcEMsTUFBSSxvQkFBcUMsQ0FBQTtBQUV6QyxNQUFJO0FBQ0gsbUJBQWUseUJBQXlCLEtBQUssS0FBSztFQUNuRCxTQUFTLEdBQUc7QUFDWCxJQUFBQSxRQUFPLE1BQU0sdUJBQXVCLENBQUMsRUFBRTtFQUN4QztBQUVBLE1BQUk7QUFDSCx3QkFBb0IsOEJBQThCLEtBQUssS0FBSztFQUM3RCxTQUFTLEdBQUc7QUFDWCxJQUFBQSxRQUFPLE1BQU0sNEJBQTRCLENBQUMsRUFBRTtFQUM3QztBQUdBLE1BQUksa0JBQWtCLFNBQVMsYUFBYSxRQUFRO0FBQ25ELElBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsa0JBQWtCLE1BQU0sWUFBWSxhQUFhLE1BQU0sR0FBRztBQUNuSCxXQUFPLEVBQUUsVUFBVSxtQkFBbUIsbUJBQW1CLEtBQUk7RUFDOUQsV0FBVyxhQUFhLFNBQVMsR0FBRztBQUNuQyxJQUFBQSxRQUFPLEtBQUssbUNBQW1DLGFBQWEsTUFBTSxpQkFBaUIsa0JBQWtCLE1BQU0sR0FBRztBQUM5RyxXQUFPLEVBQUUsVUFBVSxjQUFjLG1CQUFtQixNQUFLO0VBQzFELE9BQU87QUFFTixJQUFBQSxRQUFPLEtBQUssdURBQXVELEtBQUssRUFBRTtBQUMxRSxXQUFPLEVBQUUsVUFBVSxDQUFBLEdBQUksbUJBQW1CLEtBQUk7RUFDL0M7QUFDRDtBQUVNLFNBQVUsNEJBQTRCLE9BQWUsS0FBVztBQUNyRSxRQUFNLEVBQUUsVUFBUyxJQUFLLGVBQWUsS0FBSztBQUMxQyxTQUFPLFlBQVksOEJBQThCLEtBQUssS0FBSyxJQUFJLHlCQUF5QixLQUFLLEtBQUs7QUFDbkc7QUFTQSxTQUFTLG1CQUFtQixZQUFvQjtBQUMvQyxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFdBQU8sRUFBRSxJQUFJLFNBQVMsT0FBTyxTQUFTLE1BQU0sVUFBVSxTQUFTLFdBQVcsQ0FBQyxFQUFDO0VBQzdFO0FBRUEsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUM1QixVQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsSUFBSTtBQUNsQixXQUFPO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxNQUFNO01BQ04sU0FBUyxlQUFlLEdBQUcsR0FBRyxDQUFDOztFQUVqQztBQUVBLFNBQU8sRUFBRSxJQUFJLFNBQVMsT0FBTyxTQUFTLE1BQU0sT0FBTyxTQUFTLENBQUMsR0FBRyxVQUFVLEVBQUM7QUFDNUU7QUFNTSxTQUFVLDRCQUNmLFdBQ0EsUUFDQSxXQUFzQztBQUV0QyxRQUFNLE1BQU0sZ0JBQWdCLFNBQVM7QUFHckMsTUFBSSxDQUFDLElBQUksV0FBVztBQUNuQixRQUFJLFlBQVksQ0FBQTtFQUNqQjtBQUdBLFFBQU0sYUFBYSxPQUFPLE9BQU8sU0FBUyxFQUN4QyxPQUFPLENBQUMsTUFBTSxFQUFFLFVBQVUsVUFBVSxLQUFLLEVBQ3pDLEtBQUssQ0FBQyxHQUFHLE1BQU0sY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLElBQUksY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLENBQUM7QUFFbEcsRUFBQUMsUUFBTyxLQUFLLG1CQUFtQixVQUFVLEtBQUssRUFBRTtBQUNoRCxFQUFBQSxRQUFPLE1BQU0sNkJBQTZCLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxJQUFJLENBQUMsRUFBRTtBQUVyRixhQUFXLEVBQUUsUUFBUSxJQUFJLFdBQVUsS0FBTSxRQUFRO0FBQ2hELFFBQUksU0FBUyxJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFFekUsUUFBSSxDQUFDLFFBQVE7QUFFWixpQkFBVyxLQUFLLFlBQVk7QUFDM0IsY0FBTSxRQUFRLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUN6RSxZQUFJLE9BQU87QUFDVixtQkFBUyxnQkFBZ0IsS0FBSztBQUM5QixpQkFBTyxPQUFPLEdBQUcsTUFBTSxJQUFJLHlCQUF5QixFQUFFLEtBQUs7QUFDM0QsVUFBQUEsUUFBTyxLQUFLLG9CQUFvQixNQUFNLEVBQUUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxFQUFFO0FBQ2pFO1FBQ0Q7TUFDRDtJQUNEO0FBRUEsUUFBSSxDQUFDLFFBQVE7QUFDWixlQUFTO1FBQ1I7UUFDQTtRQUNBLE1BQU0sbUJBQW1CLE1BQU0sRUFBRSxFQUFFLFlBQVcsQ0FBRTtRQUNoRCxTQUFTLENBQUMsbUJBQW1CLFVBQVUsQ0FBQzs7QUFFekMsTUFBQUEsUUFBTyxLQUFLLDJCQUEyQixNQUFNLEVBQUUsQ0FBQyxFQUFFO0lBQ25ELE9BQU87QUFDTixZQUFNLE1BQU0sT0FBTyxVQUFVLENBQUM7QUFDOUIsVUFBSTtBQUFLLFlBQUksVUFBVSxtQkFBbUIsVUFBVSxFQUFFO0lBQ3ZEO0FBR0EsVUFBTSxTQUFTLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsT0FBTyxVQUFVLEVBQUUsT0FBTyxPQUFPLEVBQUU7QUFDekYsUUFBSSxDQUFDO0FBQVEsVUFBSSxVQUFVLEtBQUssTUFBTTtFQUN2QztBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsb0JBQW9CLFVBQWtCLFNBQW9CO0FBQ3pFLE1BQUk7QUFFSCxVQUFNLGFBQWtCLEVBQUUsT0FBTyxRQUFRLE1BQUs7QUFHOUMsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRO0lBQ2hDO0FBR0EsUUFBSSx5QkFBeUIsU0FBUztBQUNyQyxpQkFBVyxzQkFBc0IsUUFBUTtJQUMxQztBQUNBLFFBQUksZUFBZSxTQUFTO0FBQzNCLGlCQUFXLFlBQVksUUFBUTtJQUNoQztBQUVBLGVBQVcsT0FBTyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3ZDLFVBQUksRUFBRSxPQUFPLGFBQWE7QUFDekIsbUJBQVcsR0FBRyxJQUFLLFFBQWdCLEdBQUc7TUFDdkM7SUFDRDtBQUdBLFFBQUksT0FBTyxLQUFLLFVBQVUsWUFBWSxNQUFNLENBQUM7QUFLN0MsV0FBTyxLQUFLLFFBQVEsMERBQTBELDZCQUE2QjtBQUUzRyxJQUFBQyxJQUFHLGNBQWMsVUFBVSxPQUFPLE1BQU0sTUFBTTtFQUMvQyxTQUFTLEdBQUc7QUFDWCxJQUFBRCxRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtFQUN0QztBQUNEOzs7QURsZ0JBLElBQU1FLFVBQVMsbUJBQW1CLFNBQVM7QUFFckMsU0FBVSxjQUFjLE1BQW9CO0FBQ2pELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxhQUFhLGFBQVk7QUFDL0IsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0sZUFBb0IsQ0FBQTtBQUcxQixRQUFNLGNBQWMsYUFBYSxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQzFELEVBQUFBLFFBQU8sS0FDTiwrQkFBK0IsV0FBVyxzQkFBc0IsS0FBSyxPQUFPLGNBQWMsb0JBQW9CLEtBQUssUUFBUSxNQUFNLEVBQUU7QUFRcEksTUFBSSxLQUFLLGFBQWEsbUJBQW1CLEtBQUssSUFBSSxHQUFHO0FBQ3BELGlCQUFhLHVCQUF1QixJQUFJO01BQ3ZDLE1BQU07TUFDTixTQUFTLENBQUE7TUFDVCxVQUFVLFlBQVc7QUFDcEIsY0FBTSxRQUFRO0FBQ2QsY0FBTSxLQUFLLEtBQUs7QUFFaEIsY0FBTSxNQUFNLE1BQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFO0FBR3pELFlBQUksWUFBWSxnQkFBZ0IsS0FBSztBQUNyQyxZQUFJLENBQUMsV0FBVztBQUNmLFVBQUFBLFFBQU8sTUFBTSxTQUFTLEtBQUssNEJBQTRCO0FBQ3ZEO1FBQ0Q7QUFHQSxjQUFNLEVBQUUsVUFBVSxRQUFRLGtCQUFpQixJQUFLLGlDQUFpQyxPQUFPLEdBQUc7QUFDM0YsUUFBQUEsUUFBTyxNQUFNLGlCQUFpQixLQUFLLFVBQVUsTUFBTSxDQUFDLEVBQUU7QUFHdEQsWUFBSSxzQkFBc0IsTUFBTTtBQUMvQixVQUFBQSxRQUFPLEtBQUssMkJBQTJCLGlCQUFpQix3QkFBd0I7QUFDaEYsc0JBQVksRUFBRSxHQUFHLFdBQVcsV0FBVyxrQkFBaUI7UUFDekQ7QUFFQSxjQUFNLFVBQVUsNEJBQTRCLFdBQVcsUUFBUSxPQUFPO0FBQ3RFLFFBQUFBLFFBQU8sTUFBTSxxQkFBcUIsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLENBQUMsRUFBRTtBQUdwRSxjQUFNQyxpQkFBZ0IsaUJBQWdCO0FBQ3RDLGNBQU0sYUFBYUMsTUFBSyxLQUFLRCxnQkFBZSxRQUFRLEtBQUssT0FBTztBQUNoRSw0QkFBb0IsWUFBWSxPQUFPO0FBR3ZDLDRCQUFtQjtBQUVuQixRQUFBRCxRQUFPLEtBQUssU0FBUyxLQUFLLHdDQUF3QztNQUNuRTs7RUFFRjtBQU1BLGFBQVcsQ0FBQyxVQUFVLE1BQU0sS0FBSyxPQUFPLFFBQVEsVUFBVSxHQUFHO0FBQzVELFVBQU0sRUFBRSxPQUFPLE9BQU8sT0FBTSxJQUFLLGVBQWUsUUFBUTtBQUd4RCxRQUFJLFVBQVU7QUFBYTtBQUczQixVQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLFVBQU0sWUFBWSxRQUFRLFdBQVcsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLE1BQU07QUFFM0YsaUJBQWEsUUFBUSxJQUFJO01BQ3hCLEdBQUc7TUFDSCxVQUFVLE9BQU8sVUFBYztBQUM5QixjQUFNLEtBQUssS0FBSztBQUNoQixjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFZLE1BQU0sUUFBUSxPQUFPLElBQUksV0FBVztBQUN6RixjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU87QUFDbkMsY0FBTSxRQUFRLE1BQU0sUUFBUSxPQUFPLEtBQUs7QUFDeEMsY0FBTSxZQUFZLFNBQVM7QUFFM0IsY0FBTSxLQUFLLGFBQWEsYUFBYSxhQUFhLE9BQU8sT0FBTyxXQUFXLE9BQU8sRUFBRTtNQUNyRjs7RUFFRjtBQUtBLFFBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsTUFBSSxjQUFjO0FBQ2pCLFVBQU0sbUJBQW1CLGFBQWEsYUFBYSxDQUFBLEdBQUksS0FBSyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBRS9GLFFBQUksaUJBQWlCO0FBQ3BCLFlBQU0sV0FBVyxHQUFHLFdBQVc7QUFFL0IsbUJBQWEsUUFBUSxJQUFJO1FBQ3hCLE1BQU0sU0FBUyxXQUFXO1FBQzFCLFNBQVMsQ0FBQTtRQUNULFVBQVUsWUFBVztBQUNwQixnQkFBTSxLQUFLLEtBQUs7QUFDaEIsVUFBQUEsUUFBTyxLQUFLLHlCQUFvQixXQUFXLE1BQU0sRUFBRSxFQUFFO0FBQ3JELGdCQUFNLEtBQUssYUFBYSxjQUFjLGFBQWEsRUFBRTtRQUN0RDs7SUFFRjtFQUNEO0FBRUEsT0FBSyxxQkFBcUIsWUFBWTtBQUV0QyxFQUFBQSxRQUFPLEtBQUssaUNBQWlDLE9BQU8sS0FBSyxZQUFZLEVBQUUsTUFBTSxFQUFFO0FBQ2hGOzs7QUV0SEEsSUFBTUcsVUFBUyxtQkFBbUIsV0FBVztBQUs3QyxTQUFTLGlCQUNSLFNBQ0EsT0FDQSxPQUNBLFdBQ0EsT0FBYTtBQUViLFFBQU0sVUFBVSxxQkFBcUIsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUNyRSxNQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sUUFBUSxRQUFRLE9BQU87QUFBRyxXQUFPO0FBR3hELFFBQU0sY0FBYyxRQUFRLFFBQVEsS0FBSyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFDekUsTUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLFFBQVEsWUFBWSxPQUFPO0FBQUcsV0FBTztBQUdoRSxRQUFNLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxLQUFLO0FBQ2xFLFNBQU8sUUFBUSxTQUFTO0FBQ3pCO0FBTU0sU0FBVSxnQkFBZ0IsTUFBb0I7QUFDbkQsUUFBTSxhQUFhLGlCQUFnQjtBQUNuQyxRQUFNLGVBQWUsZUFBYztBQUNuQyxRQUFNLFVBQVUscUJBQXFCLFVBQVU7QUFDL0MsUUFBTSxpQkFBc0IsQ0FBQTtBQUc1QixRQUFNLGNBQWMsYUFBYSxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQzFELEVBQUFBLFFBQU8sS0FDTixpQ0FBaUMsV0FBVyxzQkFBc0IsS0FBSyxPQUFPLGNBQWMsb0JBQW9CLEtBQUssUUFBUSxNQUFNLEVBQUU7QUFPdEksYUFBVyxDQUFDLFlBQVksUUFBUSxLQUFLLE9BQU8sUUFBUSxZQUFZLEdBQUc7QUFDbEUsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxVQUFVO0FBRzFELFFBQUksVUFBVTtBQUFhO0FBRzNCLG1CQUFlLFVBQVUsSUFBSTtNQUM1QixHQUFHO01BQ0gsVUFBVSxDQUFDLGtCQUFzQjtBQUNoQyxjQUFNLEtBQUssS0FBSztBQUNoQixjQUFNLFFBQVEsY0FBYyxRQUFRLE9BQU87QUFDM0MsY0FBTSxRQUFRLGNBQWMsUUFBUSxPQUFPLEtBQUs7QUFDaEQsY0FBTSxZQUFZLFNBQVM7QUFDM0IsY0FBTSxVQUFVLEtBQUssYUFBYSxnQkFBZ0IsSUFBSSxPQUFPLFdBQVcsS0FBSztBQUc3RSxjQUFNLFlBQVksY0FBYyxRQUFRLFdBQVcsS0FBSztBQUV4RCxZQUFJLGFBQWEsWUFBWSxRQUFXO0FBRXZDLGlCQUFPLGlCQUFpQixTQUFTLE9BQU8sT0FBTyxXQUFXLE9BQU87UUFDbEU7QUFHQSxlQUFPLFdBQVc7TUFDbkI7O0VBRUY7QUFFQSxPQUFLLHVCQUF1QixjQUFjO0FBRTFDLEVBQUFBLFFBQU8sS0FBSyxxQ0FBcUMsT0FBTyxLQUFLLGNBQWMsRUFBRSxNQUFNLEVBQUU7QUFDdEY7OztBQ25GQSxPQUFPQyxZQUFXOzs7QUNBbEIsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sUUFBUTtBQUlmLElBQU1DLFVBQVMsbUJBQW1CLE9BQU87QUFLbEMsSUFBTSx5QkFBeUI7QUFFL0IsSUFBTSwwQkFBMEI7QUFnQmhDLElBQU0scUJBQXFCLE1BQU87QUFpQm5DLFNBQVUsd0JBQXFCO0FBQ3BDLFFBQU0sTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQzlCLFFBQU0sTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssS0FBTTtBQUU3QyxNQUFJLGNBQWMsT0FBUSxDQUFDO0FBQzNCLE1BQUksY0FBYyx3QkFBd0IsQ0FBQztBQUMzQyxNQUFJLGNBQWMsS0FBSyxDQUFDO0FBRXhCLFFBQU0sTUFBTSxpQkFBZ0I7QUFDNUIsTUFBSSxLQUFLLEtBQUssQ0FBQztBQUVmLFNBQU8sS0FBSyxZQUFZLE9BQU8sRUFBRSxLQUFLLEtBQUssRUFBRTtBQUM3QyxNQUFJLGNBQWMsTUFBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFRLEVBQUU7QUFDNUIsTUFBSSxjQUFjLEtBQVksRUFBRTtBQUVoQyxTQUFPO0FBQ1I7QUFHTSxTQUFVLG1CQUFnQjtBQUMvQixNQUFJO0FBQ0gsVUFBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLGVBQVcsUUFBUSxPQUFPLEtBQUssTUFBTSxHQUFHO0FBQ3ZDLGlCQUFXLFFBQVEsT0FBTyxJQUFJLEtBQUssQ0FBQSxHQUFJO0FBQ3RDLFlBQUksQ0FBQyxLQUFLLFlBQVksS0FBSyxXQUFXLFVBQVUsS0FBSyxPQUFPLEtBQUssUUFBUSxxQkFBcUI7QUFDN0YsaUJBQU8sT0FBTyxLQUFLLEtBQUssSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBYyxTQUFTLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDM0U7TUFDRDtJQUNEO0VBQ0QsUUFBUTtFQUVSO0FBQ0EsU0FBTyxPQUFPLE1BQU0sR0FBRyxDQUFDO0FBQ3pCO0FBaUJNLFNBQVUsdUJBQXVCLEtBQWEsT0FBYTtBQUNoRSxNQUFJLElBQUksU0FBUztBQUFvQixXQUFPO0FBQzVDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRLFdBQU87QUFDM0MsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQXlCLFdBQU87QUFDNUQsTUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWSxXQUFPO0FBRWxFLFFBQU0sVUFBVSxDQUFDLFFBQWdCLFFBQ2hDLElBQ0UsU0FBUyxRQUFRLFNBQVMsR0FBRyxFQUM3QixTQUFTLE9BQU8sRUFDaEIsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUNiLEtBQUk7QUFFUCxRQUFNLFFBQVEsSUFBSSxTQUFTLEdBQUcsRUFBRTtBQUNoQyxRQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztBQUM1RSxRQUFNLE1BQU0sU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUc7QUFFekUsUUFBTSxPQUFPLFFBQVEsSUFBTSxFQUFFO0FBQzdCLFFBQU0sZUFBZSxRQUFRLElBQU0sRUFBRTtBQUNyQyxRQUFNLFdBQVcsUUFBUSxLQUFNLEVBQUU7QUFDakMsUUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEVBQUksQ0FBQyxJQUFJLElBQUksRUFBSSxDQUFDO0FBRS9DLE1BQUksQ0FBQztBQUFVLFdBQU87QUFJdEIsUUFBTSxRQUFRLFNBQ1osUUFBUSxjQUFjLEVBQUUsRUFDeEIsS0FBSSxFQUNKLE1BQU0sS0FBSyxFQUFFLENBQUM7QUFFaEIsU0FBTztJQUNOLElBQUk7SUFDSjtJQUNBO0lBQ0E7SUFDQSxXQUFXOztJQUNYO0lBQ0E7O0FBRUY7QUFPQSxlQUFzQixxQkFBcUIsUUFBYztBQUN4RCxTQUFPLElBQUksUUFBa0IsQ0FBQyxTQUFTLFdBQVU7QUFDaEQsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLE1BQUs7QUFDVCxhQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztJQUM3QyxDQUFDO0FBRUQsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksTUFBSztBQUVULGNBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxtQkFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMscUJBQVcsU0FBUyxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdkMsZ0JBQ0MsTUFBTSxXQUFXLFVBQ2pCLE1BQU0sWUFBWSxhQUNsQixNQUFNLE9BQ04sTUFBTSxRQUFRLHFCQUNiO0FBQ0QscUJBQU8sUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSSxHQUFJLENBQUM7WUFDdkU7VUFDRDtRQUNEO0FBQ0EsZUFBTyxJQUFJLE1BQU0sd0NBQXdDLFNBQVMsRUFBRSxDQUFDO01BQ3RFLFNBQVMsSUFBSTtBQUNaLGVBQU8sSUFBSSxNQUFNLE9BQU8sRUFBRSxDQUFDLENBQUM7TUFDN0I7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBTUEsZUFBc0IsOEJBQThCLFFBQWM7QUFDakUsU0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFVBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUVyQyxRQUFJLFdBQVc7QUFDZixRQUFJLEtBQUssU0FBUyxDQUFDLFFBQU87QUFDekIsVUFBSSxDQUFDLFVBQVU7QUFDZCxtQkFBVztBQUNYLFlBQUksTUFBSztBQUNULGVBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzdDO0lBQ0QsQ0FBQztBQUdELFFBQUksUUFBUSxHQUFHLFFBQVEsTUFBSztBQUMzQixVQUFJO0FBQ0gsY0FBTSxPQUFPLElBQUksUUFBTztBQUN4QixjQUFNLFlBQVksS0FBSztBQUN2QixZQUFJLENBQUMsVUFBVTtBQUNkLHFCQUFXO0FBQ1gsY0FBSSxNQUFLO0FBQ1Qsa0JBQVEsU0FBUztRQUNsQjtNQUNELFNBQVMsSUFBSTtBQUNaLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxpQkFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM3QjtNQUNEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQWdCQSxlQUFzQixnQkFDckIsVUFDQSxnQkFDQSxrQkFDQSxZQUFZLEtBQUk7QUFFaEIsUUFBTSx1QkFBdUI7QUFDN0IsUUFBTSxzQkFBc0I7QUFDNUIsUUFBTSxlQUFlO0FBRXJCLFFBQU0sUUFBUSxvQkFBSSxJQUFHO0FBQ3JCLFFBQU0sYUFBYSxvQkFBSSxJQUFHO0FBRTFCLFNBQU8sSUFBSSxRQUFzQixDQUFDLFlBQVc7QUFLNUMsVUFBTSxpQkFBaUIsTUFBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBRTNFLFVBQU0sVUFBVSxNQUFLO0FBQ3BCLFVBQUk7QUFDSCx1QkFBZSxlQUFlLG9CQUFvQjtNQUNuRCxRQUFRO01BRVI7QUFDQSxVQUFJO0FBQ0gsdUJBQWUsTUFBSztNQUNyQixRQUFRO01BRVI7QUFDQSxjQUFRLE1BQU0sS0FBSyxNQUFNLE9BQU0sQ0FBRSxDQUFDO0lBQ25DO0FBRUEsVUFBTSxRQUFRLFdBQVcsU0FBUyxTQUFTO0FBQzNDLFVBQU0sUUFBTztBQUViLG1CQUFlLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDbEMsTUFBQUEsUUFBTyxLQUFLLDBCQUEwQixJQUFJLE9BQU8sRUFBRTtJQUNwRCxDQUFDO0FBRUQsbUJBQWUsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzNDLFlBQU0sUUFBUSxNQUFNO0FBRXBCLFVBQUksSUFBSSxTQUFTO0FBQUk7QUFDckIsVUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVE7QUFDcEMsVUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWTtBQUUzRCxVQUFJLFdBQVcsSUFBSSxLQUFLO0FBQUc7QUFDM0IsaUJBQVcsSUFBSSxLQUFLO0FBQ3BCLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSywrQkFBMEI7QUFLN0QsdUJBQWlCLEtBQUssRUFDcEIsS0FBSyxNQUFLO0FBQ1YsY0FBTSxRQUFRLHNCQUFxQjtBQUNuQyxpQkFBUyxLQUFLLE9BQU8sY0FBYyxPQUFPLENBQUMsUUFBTztBQUNqRCxjQUFJO0FBQUssWUFBQUEsUUFBTyxLQUFLLG9CQUFvQixLQUFLLFlBQVksSUFBSSxPQUFPLEVBQUU7UUFDeEUsQ0FBQztNQUNGLENBQUMsRUFDQSxNQUFNLENBQUMsUUFBUUEsUUFBTyxLQUFLLHVCQUF1QixHQUFHLEVBQUUsQ0FBQztJQUMzRCxDQUFDO0FBRUQsbUJBQWUsS0FBSyxxQkFBcUIsTUFBSztBQUM3QyxVQUFJO0FBQ0gsdUJBQWUsY0FBYyxvQkFBb0I7QUFDakQsUUFBQUEsUUFBTyxLQUFLLG9DQUFvQyxvQkFBb0IsSUFBSSxtQkFBbUIsRUFBRTtNQUM5RixTQUFTLEtBQUs7QUFDYixRQUFBQSxRQUFPLEtBQUssNENBQTRDLEdBQUcsRUFBRTtNQUM5RDtJQUNELENBQUM7RUFHRixDQUFDO0FBQ0Y7OztBRGxSQSxJQUFNQyxVQUFTLG1CQUFtQixjQUFjO0FBRTFDLElBQU8sZUFBUCxNQUFPLGNBQVk7RUFDUCxjQUFzQjtFQUN0QixpQkFBaUI7RUFDakIsU0FBUztFQUVsQjtFQUNBOztFQUNBO0VBSUEsbUJBQWdDLG9CQUFJLElBQUc7OztFQUd2QyxZQUEyQixRQUFRLFFBQU87O0VBRzFDLHNCQUFzQjs7RUFHdEI7O0VBR0EsUUFBZ0I7RUFDaEIsVUFBc0IsQ0FBQTtFQUN0QixzQkFBK0I7Ozs7Ozs7O0VBUS9CLGNBQWdELG9CQUFJLElBQUc7Ozs7Ozs7RUFRdkQsZ0JBQTZCLG9CQUFJLElBQUc7O0VBR3BDLHFCQUFnRSxvQkFBSSxJQUFHOztFQUd2RTtFQUVSLGNBQUE7QUFDQyxJQUFBQSxRQUFPLEtBQUssMEJBQTBCO0FBRXRDLFNBQUssY0FBYyxvQkFBSSxJQUFHO0FBSTFCLFNBQUssV0FBV0MsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ3BFLFNBQUssVUFBVSxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQzVDLFdBQUssU0FBUyxLQUFLLEdBQUcsTUFBSztBQUMxQixRQUFBRCxRQUFPLE1BQU0sMkJBQTRCLEtBQUssU0FBUyxRQUFPLEVBQXdCLElBQUksRUFBRTtBQUM1RixnQkFBTztNQUNSLENBQUM7SUFDRixDQUFDO0FBQ0QsU0FBSyxTQUFTLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDakMsTUFBQUEsUUFBTyxNQUFNLG9CQUFvQixHQUFHLEVBQUU7SUFDdkMsQ0FBQztBQUdELFNBQUssV0FBV0MsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBRXBFLFNBQUssU0FBUyxHQUFHLGFBQWEsTUFBSztBQUNsQyxZQUFNLE9BQU8sS0FBSyxTQUFTLFFBQU87QUFDbEMsTUFBQUQsUUFBTyxNQUFNLDBCQUEwQixLQUFLLFVBQVUsSUFBSSxDQUFDLEVBQUU7QUFDN0QsVUFBSTtBQUNILGFBQUssU0FBUyxxQkFBcUIsSUFBSTtNQUN4QyxTQUFTLElBQUk7TUFFYjtJQUNELENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBRUQsU0FBSyxTQUFTLEdBQUcsV0FBVyxDQUFDLEtBQUssVUFBUztBQUMxQyxVQUFJO0FBQ0gsYUFBSyxlQUFlLEtBQUssTUFBTSxPQUFPO01BQ3ZDLFNBQVMsSUFBSTtBQUNaLFFBQUFBLFFBQU8sTUFBTSxvQ0FBb0MsRUFBRSxFQUFFO01BQ3REO0lBQ0QsQ0FBQztBQUdELFNBQUssU0FBUyxLQUFLLEVBQUUsU0FBUyxXQUFXLE1BQU0sS0FBSyxPQUFNLEdBQUksTUFBSztBQUNsRSxNQUFBQSxRQUFPLE1BQU0sOEJBQThCLEtBQUssTUFBTSxFQUFFO0lBQ3pELENBQUM7RUFDRjtFQUVPLFFBQUs7QUFDWCxRQUFJO0FBQ0gsaUJBQVcsYUFBYSxNQUFNLEtBQUssS0FBSyxnQkFBZ0IsR0FBRztBQUMxRCxZQUFJO0FBQ0gsZUFBSyxTQUFTLGVBQWUsS0FBSyxnQkFBZ0IsU0FBUztRQUM1RCxRQUFRO1FBRVI7TUFDRDtJQUNELFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7QUFDQSxRQUFJO0FBQ0gsV0FBSyxTQUFTLE1BQUs7SUFDcEIsUUFBUTtJQUVSO0VBQ0Q7Ozs7O0VBTU8sU0FBUyxPQUFlLFNBQXFCLHNCQUErQixNQUFJO0FBQ3RGLFNBQUssUUFBUTtBQUNiLFNBQUssVUFBVTtBQUNmLFNBQUssc0JBQXNCO0VBQzVCOzs7OztFQU1PLG9CQUFvQixVQUFzQztBQUNoRSxTQUFLLG1CQUFtQjtFQUN6Qjs7RUFHTyxtQkFBbUIsSUFBVTtBQUNuQyxXQUFPLEtBQUssY0FBYyxJQUFJLEVBQUU7RUFDakM7O0VBR08sZ0JBQWdCLElBQVU7QUFDaEMsU0FBSyxjQUFjLElBQUksRUFBRTtBQUN6QixJQUFBQSxRQUFPLE1BQU0sd0JBQXdCLEVBQUUsRUFBRTtFQUMxQzs7RUFHTyxhQUFhLElBQVU7QUFDN0IsU0FBSyxjQUFjLE9BQU8sRUFBRTtBQUM1QixTQUFLLFlBQVksT0FBTyxFQUFFO0FBQzFCLElBQUFBLFFBQU8sTUFBTSxxQkFBcUIsRUFBRSxFQUFFO0VBQ3ZDOzs7Ozs7O0VBUU8sTUFBTSxZQUFZLElBQVksWUFBWSxLQUFJO0FBQ3BELFdBQU8sSUFBSSxRQUEyQixDQUFDLFlBQVc7QUFDakQsWUFBTSxNQUFNLFdBQVcsRUFBRTtBQUN6QixVQUFJLFdBQVc7QUFFZixZQUFNLFNBQVMsQ0FBQyxXQUE2QjtBQUM1QyxZQUFJO0FBQVU7QUFDZCxtQkFBVztBQUNYLGFBQUssbUJBQW1CLE9BQU8sR0FBRztBQUNsQyxnQkFBUSxNQUFNO01BQ2Y7QUFFQSxXQUFLLG1CQUFtQixJQUFJLEtBQUssQ0FBQyxXQUFzQjtBQUN2RCxZQUFJLE9BQU8sT0FBTztBQUFJLGlCQUFPLE1BQU07TUFDcEMsQ0FBQztBQUVELFlBQU0sUUFBUSxXQUFXLE1BQU0sT0FBTyxJQUFJLEdBQUcsU0FBUztBQUN0RCxZQUFNLFFBQU87QUFFYixXQUFLLG9CQUFvQixFQUFFLEVBQ3pCLEtBQUssWUFBWSxLQUFLLE9BQU8sRUFDN0IsS0FBSyxNQUFLO0FBQ1YsY0FBTSxRQUFRLHNCQUFxQjtBQUNuQyxhQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssYUFBYSxJQUFJLENBQUMsUUFBTztBQUN2RCxjQUFJLEtBQUs7QUFDUixZQUFBQSxRQUFPLEtBQUssWUFBWSxFQUFFLFlBQVksSUFBSSxPQUFPLEVBQUU7QUFDbkQseUJBQWEsS0FBSztBQUNsQixtQkFBTyxJQUFJO1VBQ1o7UUFDRCxDQUFDO01BQ0YsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxNQUFLO0FBQ1osUUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxFQUFFO0FBQ3RELHFCQUFhLEtBQUs7QUFDbEIsZUFBTyxJQUFJO01BQ1osQ0FBQztJQUNILENBQUM7RUFDRjs7Ozs7RUFNTyxNQUFNLG1CQUFtQixVQUFnQjtBQUMvQyxJQUFBQSxRQUFPLEtBQUssZ0NBQWdDLFFBQVEsRUFBRTtBQUN0RCxVQUFNLFdBQVcsTUFBTSxLQUFLLGFBQzNCLEtBQUssT0FDTCxzQkFDQSxRQUNBLFFBQ0EsUUFDQSxVQUNBLEtBQUs7QUFHTixXQUFPO0VBQ1I7O0VBR08sZUFBZSxVQUFnQjtBQUNyQyxXQUFPLEtBQUssWUFBWSxJQUFJLFFBQVEsS0FBSyxvQkFBSSxJQUFHO0VBQ2pEOzs7Ozs7Ozs7OztFQVlPLE1BQU0sZ0JBQWdCLFlBQVksS0FBSTtBQUU1QyxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLGVBQTZCLENBQUE7QUFFbkMsVUFBTSxnQkFBZ0IsQ0FBQyxXQUFzQjtBQUM1QyxtQkFBYSxLQUFLLE1BQU07SUFDekI7QUFHQSxTQUFLLG1CQUFtQixJQUFJLGVBQWUsYUFBYTtBQUV4RCxRQUFJO0FBQ0gsWUFBTSxLQUFLO0FBR1gsWUFBTTtRQUNMLEtBQUs7UUFDTDs7UUFDQSxPQUFPLFdBQVcsS0FBSyxvQkFBb0IsTUFBTTtRQUNqRDtNQUFTO0FBRVYsYUFBTztJQUNSO0FBQ0MsV0FBSyxtQkFBbUIsT0FBTyxhQUFhO0lBQzdDO0VBQ0Q7Ozs7O0VBTU8sTUFBTSx1QkFBdUIsVUFBZ0I7QUFDbkQsSUFBQUEsUUFBTyxLQUFLLG9DQUFvQyxRQUFRLEVBQUU7QUFDMUQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUMzQixLQUFLLE9BQ0wsa0JBQ0EsUUFDQSxRQUNBLFFBQ0EsVUFDQSxLQUFLO0FBS04sVUFBTSxZQUFZO0FBRWxCLFFBQUksU0FBUyxTQUFTLFlBQVksR0FBRztBQUNwQyxNQUFBQSxRQUFPLEtBQUssZ0NBQWdDLFNBQVMsTUFBTSxRQUFRO0FBQ25FLGFBQU87SUFDUjtBQUdBLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUNwQyxVQUFNLFFBQVEsU0FBUyxZQUFZLENBQUM7QUFFcEMsUUFBSTtBQUNKLFFBQUksVUFBVSxHQUFHO0FBQ2hCLGlCQUFXO0lBQ1osV0FBVyxRQUFRLElBQUk7QUFDdEIsaUJBQVcsTUFBTSxTQUFRLEVBQUcsU0FBUyxHQUFHLEdBQUc7SUFDNUMsT0FBTztBQUNOLGlCQUFXLE1BQU0sU0FBUTtJQUMxQjtBQUVBLFVBQU0sV0FBVyxHQUFHLEtBQUssSUFBSSxRQUFRO0FBRXJDLElBQUFBLFFBQU8sS0FBSyxxQkFBcUIsUUFBUSxFQUFFO0FBQzNDLFdBQU87RUFDUjs7Ozs7RUFNUSxNQUFNLG9CQUFvQixRQUFjO0FBQy9DLFFBQUk7QUFDSCxZQUFNLFlBQVksTUFBTSw4QkFBOEIsTUFBTTtBQUM1RCxVQUFJLENBQUMsV0FBVztBQUNmLFFBQUFBLFFBQU8sS0FBSyxxREFBcUQsTUFBTSxFQUFFO0FBQ3pFO01BQ0Q7QUFFQSxVQUFJLEtBQUssaUJBQWlCLElBQUksU0FBUyxHQUFHO0FBRXpDO01BQ0Q7QUFFQSxVQUFJO0FBQ0gsYUFBSyxTQUFTLGNBQWMsS0FBSyxnQkFBZ0IsU0FBUztBQUMxRCxhQUFLLGlCQUFpQixJQUFJLFNBQVM7QUFDbkMsUUFBQUEsUUFBTyxLQUFLLG9CQUFvQixLQUFLLGNBQWMsT0FBTyxTQUFTLEVBQUU7TUFDdEUsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxLQUFLLCtCQUErQixTQUFTLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRTtNQUN0RTtJQUNELFNBQVMsSUFBSTtBQUNaLE1BQUFBLFFBQU8sS0FBSywrQkFBK0IsRUFBRSxFQUFFO0lBQ2hEO0VBQ0Q7RUFFTyxNQUFNLGFBQ1osT0FDQSxPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUFJO0FBRWIsU0FBSztBQUNMLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxXQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssWUFDcEMsS0FBSyxjQUFjLE9BQU8sT0FBTyxPQUFPLFdBQVcsT0FBTyxRQUFRLE1BQU0sRUFDdEUsS0FBSyxDQUFDLFFBQU87QUFDYixhQUFLO0FBRUwsWUFBSSxLQUFLLHdCQUF3QixLQUFLLEtBQUssdUJBQXVCLGNBQWMsUUFBVztBQUMxRixlQUFLLG1CQUFtQixNQUFNLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDN0MsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGO0FBQ0EsZ0JBQVEsR0FBRztNQUNaLENBQUMsRUFDQSxNQUFNLENBQUMsUUFBTztBQUNkLGFBQUs7QUFDTCxlQUFPLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzNELENBQUMsQ0FBQztJQUVMLENBQUM7RUFDRjtFQUVRLE1BQU0sY0FDYixPQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQ0EsUUFDQSxTQUFTLE1BQUk7QUFFYixVQUFNLFlBQVk7QUFJbEIsUUFBSSxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sR0FBRztBQUNwQyxZQUFNLElBQUksTUFBTSxhQUFhLE1BQU0saUZBQTRFO0lBQ2hIO0FBR0EsVUFBTSxLQUFLLG9CQUFvQixNQUFNO0FBRXJDLFVBQU0sWUFBc0IsQ0FBQTtBQUM1QixRQUFJLGNBQWM7QUFBVyxnQkFBVSxLQUFLLFlBQVksR0FBSTtBQUM1RCxRQUFJLFVBQVU7QUFBVyxnQkFBVSxLQUFLLEdBQUcsY0FBYSxnQkFBZ0IsS0FBSyxDQUFDO0FBRTlFLFVBQU0sY0FBd0IsQ0FBQyxJQUFNLFFBQVEsR0FBSTtBQUVqRCxRQUFJLFVBQVU7QUFBVyxrQkFBWSxLQUFLLFFBQVEsR0FBSTtBQUN0RCxRQUFJO0FBQVEsa0JBQVksS0FBSyxVQUFVLE1BQU07QUFFN0MsUUFBSSxVQUFVLFNBQVM7QUFBRyxrQkFBWSxLQUFLLEdBQUcsU0FBUztBQUV2RCxVQUFNLE1BQU0sY0FBYSxVQUFVLFdBQVc7QUFDOUMsVUFBTSxpQkFBaUIsT0FBTyxLQUFLLENBQUMsR0FBRyxhQUFhLEdBQUcsQ0FBQztBQUV4RCxVQUFNLFdBQVcsS0FBSyxlQUFlO0FBQ3JDLFVBQU0sU0FBUyxNQUFNLGNBQWEsWUFBWSxVQUFVLE1BQU07QUFDOUQsVUFBTSxTQUFTLE9BQU8sT0FBTyxDQUFDLFFBQVEsY0FBYyxDQUFDO0FBR3JELFVBQU0sVUFBVSxlQUFlLEtBQUs7QUFDcEMsUUFBSSxjQUFjLFVBQWEsVUFBVSxRQUFXO0FBRW5ELFVBQUksU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFHOUUsVUFBSSxDQUFDLFFBQVE7QUFDWixpQkFBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQUs7QUFDaEMsY0FBSSxFQUFFLFdBQVc7QUFBTyxtQkFBTztBQUMvQixnQkFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUM1RCxjQUFJLENBQUM7QUFBVSxtQkFBTztBQUN0QixpQkFBTyxhQUFhLEVBQUUsTUFBTSxZQUFZLEVBQUUsS0FBSztRQUNoRCxDQUFDO01BQ0Y7QUFFQSxVQUFJLGNBQWMsUUFBUSxRQUFRO0FBR2xDLFVBQUksUUFBUTtBQUNYLGNBQU0sV0FBVyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDakUsWUFBSSxZQUFZLGNBQWMsT0FBTyxJQUFJO0FBQ3hDLGdCQUFNLGdCQUFnQixZQUFZLE9BQU87QUFDekMsd0JBQWMsR0FBRyxXQUFXLE1BQU0sZ0JBQWdCLENBQUM7UUFDcEQ7TUFDRDtBQUdBLFlBQU0sY0FBYyxRQUFRLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDckUsWUFBTSxVQUFVLGFBQWE7QUFDN0IsWUFBTSxhQUFhLGNBQWEsZ0JBQWdCLEtBQUs7QUFDckQsWUFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELFlBQU0sY0FBYyxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUV4RyxZQUFNLFNBQVMsTUFBTSxLQUFLO0FBQzFCLFlBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsWUFBTSxTQUFTLFdBQVcsVUFBVTtBQUNwQyxZQUFNLFNBQVMsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUksV0FBVyxLQUFLLEdBQUc7QUFFNUUsWUFBTSxTQUFTLE9BQU8sTUFBTSxPQUFPLEtBQUssUUFBUSxNQUFNO0FBQ3RELFlBQU0sU0FBUyxjQUFjLEdBQUcsV0FBVyxLQUFLLFdBQVcsS0FBSyxNQUFNLE1BQU0sR0FBRyxXQUFXLEtBQUssTUFBTTtBQUVyRyxNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sRUFBRTtJQUNuRCxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLE1BQU0sTUFBTSxNQUFNLE9BQU8sRUFBRTtJQUN4QztBQUNBLElBQUFBLFFBQU8sTUFBTSxxQkFBcUIsTUFBTSxLQUFLLE9BQU8sU0FBUyxLQUFLLENBQUMsRUFBRTtBQUVyRSxVQUFNLEtBQUs7QUFFWCxVQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksS0FBSztBQUU5QixXQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsWUFBTSxRQUFRLFdBQVcsTUFBSztBQUM3QixhQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLGVBQU8sSUFBSSxNQUFNLHFDQUFxQyxLQUFLLE9BQU8sTUFBTSxPQUFPLENBQUM7TUFDakYsR0FBRyxTQUFTO0FBRVosV0FBSyxZQUFZLElBQUksS0FBSztRQUN6QixTQUFTLENBQUMsUUFBTztBQUNoQix1QkFBYSxLQUFLO0FBQ2xCLGtCQUFRLEdBQUc7UUFDWjtRQUNBLFFBQVEsQ0FBQyxRQUFPO0FBQ2YsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxHQUFHO1FBQ1g7UUFDQTtPQUNBO0FBRUQsV0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLGFBQWEsUUFBUSxDQUFDLFFBQU87QUFDNUQsWUFBSSxLQUFLO0FBQ1IsZUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUM3QztNQUNELENBQUM7SUFDRixDQUFDO0VBQ0Y7RUFFUSxlQUFlLEtBQWEsT0FBYTtBQUNoRCxRQUFJLElBQUksU0FBUztBQUFHO0FBQ3BCLFFBQUksSUFBSSxDQUFDLE1BQU0sT0FBUSxJQUFJLENBQUMsTUFBTTtBQUFNO0FBRXhDLFVBQU0sVUFBVSxJQUFJLGFBQWEsQ0FBQztBQUtsQyxRQUFJLFlBQVksMkJBQTJCLEtBQUssbUJBQW1CLE9BQU8sR0FBRztBQUM1RSxZQUFNLFNBQVMsdUJBQXVCLEtBQUssS0FBSztBQUNoRCxVQUFJLFFBQVE7QUFDWCxRQUFBQSxRQUFPLE1BQ04sNEJBQTRCLEtBQUssZUFDbkIsT0FBTyxJQUFJLGFBQ2QsT0FBTyxLQUFLLGlCQUNSLE9BQU8sU0FBUyxvQkFDYixPQUFPLFlBQVksR0FBRztBQUl6QyxZQUFJLE9BQU8sU0FBUyxZQUFZO0FBQy9CLHFCQUFXLE1BQU0sS0FBSyxtQkFBbUIsT0FBTSxHQUFJO0FBQ2xELGdCQUFJO0FBQ0gsaUJBQUcsTUFBTTtZQUNWLFFBQVE7WUFFUjtVQUNEO1FBQ0QsT0FBTztBQUNOLFVBQUFBLFFBQU8sTUFBTSxzREFBc0QsT0FBTyxJQUFJLE9BQU8sS0FBSyxFQUFFO1FBQzdGO01BQ0Q7QUFDQTtJQUNEO0FBRUEsUUFBSSxJQUFJLFNBQVM7QUFBSTtBQUdyQixVQUFNLE1BQU0sSUFBSSxTQUFTLElBQUksRUFBRTtBQUMvQixRQUFJLElBQUksU0FBUyxPQUFPLE1BQU07QUFBWTtBQUkxQyxVQUFNLFlBQVksSUFBSSxTQUFTLEVBQUU7QUFDakMsUUFBSSxVQUFVLFNBQVM7QUFBRztBQUMxQixRQUFJLFVBQVUsQ0FBQyxNQUFNO0FBQU07QUFHM0IsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLGNBQWMsWUFBWSxTQUFVO0FBQzFDLFVBQU0sZ0JBQWdCLFlBQVk7QUFHbEMsU0FBSyxhQUFhLE9BQU8sZUFBZSxLQUFLLFdBQVcsVUFBVTtBQUdsRSxRQUFJLFlBQVk7QUFDZixZQUFNLE1BQU0sR0FBRyxLQUFLLElBQUksYUFBYTtBQUNyQyxZQUFNLFVBQVUsS0FBSyxZQUFZLElBQUksR0FBRztBQUN4QyxVQUFJLFNBQVM7QUFDWixhQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLGdCQUFRLFFBQVEsR0FBRztNQUNwQjtJQUNEO0VBRUQ7Ozs7Ozs7Ozs7OztFQWFRLGFBQWEsT0FBZSxPQUFlLEtBQWEsV0FBbUIsYUFBYSxNQUFJO0FBQ25HLFVBQU0sVUFBVSxPQUFPLE1BQU0sS0FBSyxDQUFDO0FBQ25DLFVBQU0sT0FBTyxVQUFVLFNBQVMsR0FBRyxVQUFVLFNBQVMsQ0FBQztBQUd2RCxVQUFNLFFBQVEsVUFBVSxDQUFDO0FBQ3pCLFVBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsVUFBTSxNQUFNLFVBQVUsVUFBVSxTQUFTLENBQUM7QUFDMUMsVUFBTSxnQkFBZ0IsVUFBVSxNQUFNLEtBQUssQ0FBQyxRQUFRLE1BQU0sU0FBUyxDQUFDLFNBQVMsS0FBSyxTQUFTLEtBQUssQ0FBQyxRQUFRLE1BQU0sR0FBRyxDQUFDO0FBR25ILFVBQU0sWUFBWSxhQUFhLE9BQU87QUFLdEMsUUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFJLENBQUMsS0FBSyxPQUFPO0FBQ2hCLFFBQUFBLFFBQU8sS0FBSyxHQUFHLFNBQVMsSUFBSSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsRUFBRTtBQUNuRTtNQUNEO0FBQ0EsVUFBSTtBQUNILGNBQU0sV0FDTCxVQUFVLG9CQUNQLHNCQUFzQixLQUFLLE9BQU8sR0FBRyxJQUNyQyw0QkFBNEIsS0FBSyxPQUFPLEdBQUc7QUFFL0MsY0FBTSxZQUFZLEtBQUssWUFBWSxJQUFJLEtBQUssS0FBSyxvQkFBSSxJQUFHO0FBQ3hELGNBQU0sV0FBVyxJQUFJLElBQW9CLFNBQVM7QUFFbEQsbUJBQVcsS0FBSyxVQUFVO0FBQ3pCLGdCQUFNLFdBQVcsY0FBYyxLQUFLLE9BQU8sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUs7QUFFbEUsZ0JBQU0sV0FDTCxFQUFFLFdBQVcsV0FBVyxJQUNwQixFQUFFLFdBQVcsQ0FBQyxLQUFLLEtBQU8sRUFBRSxXQUFXLENBQUMsS0FBSyxJQUFLLEVBQUUsV0FBVyxDQUFDLElBQ2hFLEVBQUUsV0FBVyxDQUFDLEtBQUs7QUFDeEIsZ0JBQU0sWUFBWSxVQUFVLElBQUksUUFBUTtBQUN4QyxnQkFBTSxVQUFVLGNBQWMsVUFBYSxjQUFjO0FBRXpELG1CQUFTLElBQUksVUFBVSxRQUFRO0FBRS9CLGdCQUFNLFlBQVksb0JBQW9CLEdBQUcsS0FBSyxPQUFPO0FBQ3JELGNBQUksU0FBUztBQUNaLFlBQUFBLFFBQU8sS0FBSyxHQUFHLFNBQVMsSUFBSSxLQUFLLE1BQU0sU0FBUyxFQUFFO0FBRWxELGdCQUFJLEtBQUssa0JBQWtCO0FBQzFCLG9CQUFNLGtCQUFrQixjQUFjLEtBQUssT0FBTyxFQUFFLFFBQVEsRUFBRSxFQUFFO0FBRWhFLG1CQUFLLGlCQUFpQixlQUFlO1lBQ3RDLE9BQU87QUFDTixjQUFBQSxRQUFPLEtBQUssZ0VBQTJELFFBQVEsRUFBRTtZQUNsRjtVQUNELE9BQU87QUFDTixZQUFBQSxRQUFPLE1BQU0sR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLFNBQVMsRUFBRTtVQUNwRDtRQUNEO0FBQ0EsYUFBSyxZQUFZLElBQUksT0FBTyxRQUFRO01BQ3JDLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxHQUFHLFNBQVMsSUFBSSxLQUFLLE1BQU0sT0FBTyxvQkFBb0IsQ0FBQyxNQUFNLGFBQWEsRUFBRTtNQUN6RjtBQUNBO0lBQ0Q7QUFHQSxVQUFNLFVBQVUsS0FBSyxhQUFhLE9BQU8sSUFBSTtBQUM3QyxRQUFJLFNBQVM7QUFDWixNQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLE1BQU0sT0FBTyxFQUFFO0lBQ2pGLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7SUFDcEU7RUFDRDs7Ozs7Ozs7RUFTUSxhQUFhLE9BQWUsTUFBWTtBQUMvQyxRQUFJLEtBQUssV0FBVztBQUFHLGFBQU87QUFHOUIsUUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixVQUFJLEtBQUssQ0FBQyxNQUFNLEdBQU07QUFDckIsZUFBTztNQUNSLE9BQU87QUFDTixlQUFPLFNBQVMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO01BQy9CO0lBQ0Q7QUFFQSxZQUFRLE9BQU87Ozs7O01BS2QsS0FBSyxjQUFjO0FBQ2xCLFlBQUksS0FBSyxXQUFXLEdBQUc7QUFDdEIsaUJBQU8sS0FBSyxDQUFDLE1BQU0sSUFBTyxXQUFXLFdBQVcsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQy9EO0FBQ0EsWUFBSSxLQUFLLFVBQVUsR0FBRztBQUNyQixnQkFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixnQkFBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixnQkFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO0FBQ2xDLGdCQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBQ2hGLGdCQUFNLGNBQWMsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLENBQUM7QUFDL0QsZ0JBQU0sVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0FBQ3RDLGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGNBQWMsR0FBRyxXQUFXLEtBQUssTUFBTSxRQUFTLENBQUMsTUFBTSxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUM7QUFDekcsZ0JBQU0sU0FBUyxJQUFJLE1BQU0sS0FBSyxDQUFDLElBQUksTUFBTSxTQUFTLENBQUMsS0FBSyxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUMsQ0FBQztBQUMxRixpQkFBTyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUSxJQUFJLE1BQU07UUFDaEU7QUFDQSxlQUFPLFFBQVEsS0FBSyxTQUFTLEtBQUssQ0FBQztNQUNwQzs7TUFHQSxLQUFLLGlCQUFpQjtBQUVyQixZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLFVBQVUsUUFBUSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEdBQUc7QUFDaEUsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGVBQWUsS0FBSyxXQUFXLFNBQVMsS0FBSyxDQUFDO0FBQy9ELGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRO1FBQ3REO0FBQ0EsZUFBTztNQUNSOztNQUdBLEtBQUs7TUFDTCxLQUFLLGFBQWE7QUFDakIsWUFBSSxLQUFLLFNBQVM7QUFBRyxpQkFBTztBQUM1QixjQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGNBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsY0FBTSxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQzdCLGVBQU8sTUFBTSxLQUFLLFlBQVksTUFBTSxTQUFTLENBQUMsVUFBVSxNQUFNLFNBQVMsS0FBSyxDQUFDO01BQzlFO01BRUE7QUFDQyxlQUFPO0lBQ1Q7RUFDRDtFQUVRLE9BQU8sZ0JBQWdCLE9BQWM7QUFDNUMsUUFBSSxPQUFPLFVBQVU7QUFBVyxhQUFPLENBQUMsUUFBUSxJQUFJLENBQUM7QUFDckQsUUFBSSxNQUFNLFFBQVEsS0FBSztBQUFHLGFBQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxPQUFPLENBQUMsSUFBSSxHQUFJO0FBQ2xFLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDOUIsVUFBSSxRQUFRO0FBQU0sZUFBTyxDQUFFLFNBQVMsS0FBTSxLQUFPLFNBQVMsSUFBSyxLQUFNLFFBQVEsR0FBSTtBQUNqRixhQUFPLENBQUMsUUFBUSxHQUFJO0lBQ3JCO0FBQ0EsVUFBTSxJQUFJLE1BQU0sNENBQTRDLEtBQUssRUFBRTtFQUNwRTtFQUVRLGFBQWEsWUFBWSxVQUFrQixRQUFjO0FBQ2hFLFVBQU0sTUFBTSxNQUFNLHFCQUFxQixNQUFNO0FBRTdDLFdBQU8sT0FBTyxPQUFPO01BQ3BCLE9BQU8sS0FBSyxDQUFDLEtBQU0sS0FBTSxHQUFNLFdBQVcsS0FBTSxHQUFNLEtBQU0sR0FBTSxHQUFNLEdBQUcsS0FBSyxHQUFNLENBQUksQ0FBQztNQUMzRixPQUFPLEtBQUssWUFBWSxNQUFNO0tBQzlCO0VBQ0Y7RUFFUSxPQUFPLFVBQVUsTUFBYztBQUN0QyxRQUFJLE1BQU07QUFDVixlQUFXLEtBQUssTUFBTTtBQUNyQixhQUFPO0FBQ1AsZUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDM0IsZUFBTyxNQUFNLFNBQVUsS0FBTSxPQUFPLElBQUssT0FBUSxNQUFRLE9BQU8sSUFBSztNQUN0RTtJQUNEO0FBQ0EsV0FBTztFQUNSOzs7Ozs7Ozs7O0VBV08sZ0JBQWdCLElBQVksT0FBZSxXQUFtQixPQUFjO0FBQ2xGLFVBQU0sTUFBTSxjQUFjLEtBQUssT0FBTyxPQUFPLFdBQVcsS0FBSztBQUM3RCxXQUFPLEtBQUssWUFBWSxJQUFJLEVBQUUsR0FBRyxJQUFJLEdBQUc7RUFDekM7RUFFTyxNQUFNLFlBQVksT0FBZSxRQUFjO0FBQ3JELFdBQU8sS0FBSyxhQUFhLE9BQU8sa0JBQWtCLFFBQVcsR0FBTSxRQUFXLFFBQVEsS0FBSztFQUM1RjtFQUVPLE1BQU0sY0FBYyxPQUFlLFFBQWM7QUFDdkQsV0FBTyxLQUFLLGFBQWEsT0FBTyxxQkFBcUIsUUFBVyxRQUFXLFFBQVcsUUFBUSxLQUFLO0VBQ3BHOzs7O0FFcHhCRCxJQUFNRSxVQUFTLG1CQUFtQixnQkFBZ0I7QUFNbEQsSUFBcUIsaUJBQXJCLGNBQTRDLGFBQXlCO0VBQ3BFOztFQUNBOzs7RUFJUSxvQkFBa0MsQ0FBQTtFQUUxQyxZQUFZLFVBQWlCO0FBQzVCLFVBQU0sUUFBUTtFQUNmO0VBRUEsTUFBTSxLQUFLLFFBQW9CO0FBQzlCLFNBQUssU0FBUztBQUNkLFFBQUksQ0FBQyxLQUFLLGNBQWM7QUFDdkIsV0FBSyxlQUFlLElBQUksYUFBWTtJQUNyQztBQUNBLFNBQUssYUFBYSxlQUFlLEVBQUU7QUFHbkMsU0FBSyxhQUFhLG9CQUFvQixDQUFDLGVBQXNCO0FBQzVELFdBQUssZUFBZSxVQUFVO0lBQy9CLENBQUM7QUFJRCxTQUFLLGFBQVksRUFBRyxNQUFNLENBQUMsTUFBSztBQUMvQixNQUFBQSxRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtJQUN0QyxDQUFDO0VBQ0Y7Ozs7Ozs7RUFRUSxNQUFNLGVBQVk7QUFDekIsSUFBQUEsUUFBTyxLQUFLLDhCQUE4QjtBQUUxQyxTQUFLLG9CQUFvQixNQUFNLEtBQUssYUFBYSxnQkFBZTtBQUdoRSxRQUFJO0FBQ0osUUFBSSxLQUFLLGtCQUFrQixXQUFXLEdBQUc7QUFDeEMsWUFBTSxjQUFjLEtBQUssT0FBTztBQUNoQyxVQUFJLENBQUMsS0FBSyxPQUFPLFFBQVEsQ0FBQyxhQUFhO0FBQ3RDLFFBQUFBLFFBQU8sS0FBSyx5REFBeUQ7QUFDckU7TUFDRDtBQUNBLE1BQUFBLFFBQU8sS0FBSyx3RUFBbUU7QUFDL0UsdUJBQWlCO0lBQ2xCLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssY0FBYyxLQUFLLGtCQUFrQixNQUFNLGFBQWE7QUFDcEUsaUJBQVcsS0FBSyxLQUFLLG1CQUFtQjtBQUN2QyxRQUFBQSxRQUFPLEtBQUssYUFBYSxFQUFFLEtBQUssSUFBSSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUU7TUFDckU7QUFLQSxpQkFBVyxVQUFVLEtBQUssbUJBQW1CO0FBQzVDLGFBQUssYUFBYSxnQkFBZ0IsT0FBTyxFQUFFO01BQzVDO0FBR0EsaUJBQVcsVUFBVSxLQUFLLG1CQUFtQjtBQUM1QyxZQUFJO0FBQ0gsZ0JBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSx1QkFBdUIsT0FBTyxFQUFFO0FBQ3pFLGlCQUFPLGVBQWU7QUFDdEIsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLGNBQWMsUUFBUSxXQUFXLE9BQU8sYUFBYSxFQUFFO1FBQ3BGLFNBQVMsR0FBRztBQUNYLFVBQUFBLFFBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSw2QkFBNkIsQ0FBQyxFQUFFO0FBQzVELGlCQUFPLGVBQWU7UUFDdkI7TUFDRDtBQUVBLHVCQUFpQixhQUFhLEtBQUssUUFBUSxLQUFLLGlCQUFpQjtJQUNsRTtBQUdBLFNBQUssVUFBVSxjQUFjO0FBSTdCLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFVBQU0sS0FBSyxvQkFBb0IsSUFBSSxVQUFVO0FBRzdDLFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0FBRXpCLElBQUFBLFFBQU8sS0FBSywyQkFBMkI7RUFDeEM7O0VBR0EsTUFBTSxVQUFPO0FBQ1osU0FBSyxjQUFjLE1BQUs7QUFDeEIsSUFBQUEsUUFBTyxNQUFNLFNBQVM7RUFDdkI7RUFFQSxNQUFNLGNBQWMsUUFBb0I7QUFDdkMsVUFBTSxlQUFlLEtBQUs7QUFDMUIsU0FBSyxTQUFTO0FBQ2QsVUFBTSxpQkFBaUIsYUFBYSxRQUFRLEtBQUssaUJBQWlCO0FBQ2xFLFNBQUssVUFBVSxjQUFjO0FBSTdCLFNBQUsscUJBQW9CO0FBRXpCLFVBQU0sVUFBVSxLQUFLO0FBSXJCLFVBQU0sS0FBSyxvQkFBb0IsY0FBYyxPQUFPO0FBR3BELFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0VBQzFCOzs7Ozs7Ozs7Ozs7RUFhUSxNQUFNLG9CQUFvQixjQUFzQixTQUFlO0FBQ3RFLFFBQUksQ0FBQyxTQUFTO0FBQ2IsVUFBSTtBQUFjLGFBQUssYUFBYSxhQUFhLFlBQVk7QUFDN0Q7SUFDRDtBQUVBLFFBQUksS0FBSyxPQUFPLGdCQUFnQjtBQUcvQixVQUFJLGdCQUFnQixpQkFBaUIsU0FBUztBQUM3QyxhQUFLLGFBQWEsYUFBYSxZQUFZO01BQzVDO0FBQ0EsWUFBTSxnQkFBZ0IsS0FBSyxhQUFhLG1CQUFtQixPQUFPO0FBQ2xFLFVBQUksQ0FBQyxlQUFlO0FBQ25CLGFBQUssYUFBYSxnQkFBZ0IsT0FBTztNQUMxQztBQUVBLFVBQUksWUFBWSxnQkFBZ0IsQ0FBQyxlQUFlO0FBQy9DLFlBQUk7QUFDSCxnQkFBTSxLQUFLLGFBQWEsbUJBQW1CLE9BQU87UUFDbkQsU0FBUyxHQUFHO0FBQ1gsVUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxPQUFPLEtBQUssQ0FBQyxFQUFFO1FBQy9EO01BQ0Q7QUFDQTtJQUNEO0FBR0EsVUFBTSxjQUFjLEtBQUssT0FBTztBQUNoQyxVQUFNLGlCQUFpQixLQUFLLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUUxRSxRQUFJLGdCQUFnQjtBQUVuQixVQUFJLGVBQWUsVUFBVSxhQUFhO0FBQ3pDLFlBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLGVBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsY0FBTSxnQkFBZ0IsS0FBSyxhQUFhLG1CQUFtQixPQUFPO0FBQ2xFLFlBQUksQ0FBQyxlQUFlO0FBQ25CLGVBQUssYUFBYSxnQkFBZ0IsT0FBTztRQUMxQztBQUNBLFlBQUksWUFBWSxnQkFBZ0IsQ0FBQyxlQUFlO0FBQy9DLGNBQUk7QUFDSCxrQkFBTSxLQUFLLGFBQWEsbUJBQW1CLE9BQU87VUFDbkQsU0FBUyxHQUFHO0FBQ1gsWUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxPQUFPLEtBQUssQ0FBQyxFQUFFO1VBQy9EO1FBQ0Q7TUFDRCxPQUFPO0FBRU4sUUFBQUEsUUFBTyxNQUNOLDBCQUEwQixXQUFXLDJDQUEyQyxlQUFlLEtBQUssUUFBUSxPQUFPLDBCQUFxQjtBQUV6SSxhQUFLLGFBQWEsYUFBYSxPQUFPO01BQ3ZDO0FBQ0E7SUFDRDtBQUdBLElBQUFBLFFBQU8sS0FBSyxHQUFHLE9BQU8sd0NBQW1DO0FBQ3pELFFBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLFdBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsU0FBSyxhQUFhLGFBQWEsT0FBTztBQUV0QyxVQUFNLFNBQVMsTUFBTSxLQUFLLGFBQWEsWUFBWSxPQUFPO0FBQzFELFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxNQUFNLDBCQUEwQixPQUFPLDBCQUFxQjtJQUNwRSxXQUFXLE9BQU8sVUFBVSxhQUFhO0FBQ3hDLE1BQUFBLFFBQU8sTUFDTiwwQkFBMEIsV0FBVywyQ0FBMkMsT0FBTyxLQUFLLFFBQVEsT0FBTywwQkFBcUI7SUFFbEksT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxrQkFBa0IsT0FBTyxLQUFLLE9BQU8sT0FBTyxFQUFFO0FBQzFELFdBQUssYUFBYSxnQkFBZ0IsT0FBTztBQUN6QyxVQUFJO0FBQ0gsY0FBTSxLQUFLLGFBQWEsbUJBQW1CLE9BQU87TUFDbkQsU0FBUyxHQUFHO0FBQ1gsUUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxPQUFPLEtBQUssQ0FBQyxFQUFFO01BQy9EO0lBQ0Q7RUFDRDs7RUFHUSxVQUFVLE9BQWE7QUFDOUIsVUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxLQUFLLFVBQVUsS0FBSywrQkFBK0I7QUFDMUQsV0FBSyxhQUFhLFNBQVMsT0FBTyxDQUFBLEdBQUksSUFBSTtBQUMxQztJQUNEO0FBRUEsVUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSSxPQUFPLFlBQVksQ0FBQTtBQUNyRSxVQUFNLHNCQUFzQixPQUFPLHVCQUF1QjtBQUUxRCxTQUFLLGFBQWEsU0FBUyxPQUFPLFNBQVMsbUJBQW1CO0FBQzlELFFBQUksUUFBUSxXQUFXLEdBQUc7QUFDekIsTUFBQUEsUUFBTyxLQUFLLCtCQUErQixLQUFLLDZDQUF3QztJQUN6RixPQUFPO0FBQ04sTUFBQUEsUUFBTyxNQUNOLFVBQVUsUUFBUSxNQUFNLHVCQUF1QixLQUFLLGdCQUFnQixPQUFPLFNBQVMseUJBQXlCLG1CQUFtQixFQUFFO0lBRXBJO0VBQ0Q7RUFFQSxrQkFBZTtBQUNkLFdBQU8sZ0JBQWdCLEtBQUssaUJBQWlCO0VBQzlDOztFQUdBLElBQUksT0FBSTtBQUNQLFdBQU8sWUFBWSxLQUFLLE1BQU07RUFDL0I7O0VBR0EsSUFBSSxVQUFPO0FBQ1YsV0FBTyxLQUFLO0VBQ2I7RUFFQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSxrQkFBZTtBQUNkLG9CQUFnQixJQUFJO0VBQ3JCO0VBRUEsNEJBQXlCO0FBQ3hCLDhCQUEwQixJQUFJO0VBQy9CO0VBRUEsdUJBQW9CO0FBQ25CLHlCQUFxQixJQUFJO0VBQzFCOzsiLAogICJuYW1lcyI6IFsicGF0aCIsICJJbnN0YW5jZVN0YXR1cyIsICJSZWdleCIsICJwYXRoIiwgImZzIiwgImxvZ2dlciIsICJsb2dnZXIiLCAiZnMiLCAibG9nZ2VyIiwgImRldmljZXNGb2xkZXIiLCAicGF0aCIsICJsb2dnZXIiLCAiZGdyYW0iLCAibG9nZ2VyIiwgImxvZ2dlciIsICJkZ3JhbSIsICJsb2dnZXIiXQp9Cg==
