import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual (enter IP + model below)" },
    ...discoveredDevices.map((d) => ({
      id: d.mac ?? "",
      label: `Model ${d.model} [${d.mac}] @ ${d.ip}`
    }))
  ];
  return [
    // ── Device selection dropdown ────────────────────────────────────────
    // Stores the MAC so re-discovery with a changed IP still matches.
    {
      type: "dropdown",
      id: "deviceMac",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry — only visible in manual mode ────────────────────
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Manual model selector — only visible in manual mode ──────────────
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Select which Studio Technologies model is active for actions and feedbacks."
    }
  ];
}
function resolveHost(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    return device?.ip ?? "";
  }
  return String(config.host ?? "");
}
function resolveModel(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    logger.debug(`resolveModel: deviceMac="${config.deviceMac}", found device: ${device?.model ?? "none"}`);
    return device?.model ?? "";
  }
  logger.debug(`resolveModel: manual mode, activeModel="${config.activeModel}"`);
  return String(config.activeModel ?? "");
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_MIC_PRE = 2;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_MIC_PRE:
      return "Mic Preamp";
    case CMD_BUS_GET:
      return "Heartbeat";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "static-text":
      return { ...base, value: o.value ?? "" };
    case "textinput":
    case "colorpicker":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  const commandsRawValue = [CMD_MIC_PRE];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    const isRawValue = commandsRawValue.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (isRawValue) {
      busCh = buf[p + 2];
      const rawBytes = buf.subarray(p + 3, sectionEnd);
      for (let i = 0; i < rawBytes.length; i++) {
        out.push({ cmd_id: sectionCmdId, id: i, busCh, valueBytes: [rawBytes[i]] });
      }
      p = sectionEnd;
      continue;
    } else if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    const qStart = q;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    if (q === qStart && sectionEnd > p + 3) {
      let pos = hasBusCh ? p + 3 : p + 2;
      let posId = 0;
      while (pos < sectionEnd) {
        const setting = { cmd_id: sectionCmdId, id: posId++, valueBytes: [buf[pos++]] };
        if (busCh !== void 0)
          setting.busCh = busCh;
        out.push(setting);
      }
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  const idAddDeferRanges = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    for (const baseEntry of c.cmdSchema ?? []) {
      const idAddOpt = baseEntry.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        continue;
      const baseId = baseEntry.id;
      const cmdId = baseEntry.cmd_id;
      const key = `${cmdId}_${baseId}`;
      if (idAddDeferRanges.has(key))
        continue;
      const parsedOffsets = parsed.filter((p) => p.cmd_id === cmdId && p.id > baseId).map((p) => p.id - baseId).sort((a, b) => a - b);
      let maxSeq = 0;
      for (const off of parsedOffsets) {
        if (off === maxSeq + 1)
          maxSeq = off;
        else if (off > maxSeq + 1)
          break;
      }
      if (maxSeq > 0) {
        idAddDeferRanges.set(key, maxSeq);
        logger2.debug(`idAdd defer range for cmd_id=${toHex(cmdId)} base_id=${toHex(baseId)}: offsets 1\u2013${maxSeq}`);
      }
    }
  }
  const busChSeen = /* @__PURE__ */ new Map();
  for (const { cmd_id, id, busCh } of parsed) {
    if (busCh === void 0)
      continue;
    const key = `${cmd_id}_${id}`;
    if (!busChSeen.has(key))
      busChSeen.set(key, /* @__PURE__ */ new Set());
    busChSeen.get(key).add(busCh);
  }
  for (const { cmd_id, id, busCh, valueBytes } of parsed) {
    const existingExact = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (existingExact) {
      const opt = existingExact.options?.find((o) => o.id === "value");
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
      continue;
    }
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt = a.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        return false;
      if (id <= a.id)
        return false;
      const offset = id - a.id;
      return candidates.some((c) => {
        const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === a.id);
        const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
        return refIdAdd?.choices?.some((ch) => ch.id === offset);
      });
    });
    if (idAddBase) {
      const offset = id - idAddBase.id;
      const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
      if (idAddOpt?.choices && !idAddOpt.choices.some((c) => c.id === offset)) {
        let label = `Channel ${offset + 1}`;
        for (const c of candidates) {
          const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
          const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
          const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
          if (refChoice) {
            label = refChoice.label;
            break;
          }
        }
        idAddOpt.choices.push({ id: offset, label });
        logger2.info(`Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
      }
      continue;
    }
    let action;
    for (const c of candidates) {
      const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
      if (match) {
        action = structuredClone(match);
        const baseName = match.name.replace(/\s*\(inferred from Model [^)]+\)/g, "").trim();
        action.name = `${baseName} (inferred from Model ${c.model})`;
        logger2.info(`Inferred cmd_id=${toHex(cmd_id)} id=${toHex(id)} from Model ${c.model} (exact)`);
        break;
      }
    }
    if (!action) {
      let shouldDefer = false;
      for (const c of candidates) {
        const baseEntry = c.cmdSchema?.find((a) => {
          if (a.cmd_id !== cmd_id)
            return false;
          const idAddOpt = a.options?.find((o) => o.id === "idAdd");
          if (!idAddOpt?.choices)
            return false;
          if (id <= a.id)
            return false;
          const offset = id - a.id;
          const maxSeq = idAddDeferRanges.get(`${cmd_id}_${a.id}`) ?? 0;
          return offset <= maxSeq;
        });
        if (baseEntry) {
          shouldDefer = true;
          logger2.debug(`cmd_id=${toHex(cmd_id)} id=${toHex(id)} is an idAdd offset of candidate base id=${toHex(baseEntry.id)} \u2014 deferring to pass 2`);
          break;
        }
      }
      if (shouldDefer)
        continue;
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown cmd:${toHex(cmd_id)} id:${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      if (busCh !== void 0)
        action.busCh = busCh;
      logger2.warn(`Could not infer cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
    } else {
      action.options = action.options?.filter((o) => o.id !== "busCh") ?? [];
      delete action.busCh;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        if (maxBusCh === 0) {
          action.busCh = 0;
        } else {
          const busChChoices = Array.from({ length: maxBusCh + 1 }, (_, i) => ({
            id: i,
            label: `Channel ${i + 1}`
          }));
          action.options.unshift({
            id: "busCh",
            label: "Channel",
            type: "dropdown",
            choices: busChChoices,
            default: 0
          });
        }
      }
      const observedDefault = valueBytesToOption(valueBytes).default;
      const valueOpt = action.options?.find((o) => o.id === "value");
      if (valueOpt) {
        if (valueOpt.choices && Array.isArray(valueOpt.choices)) {
          const inChoices = valueOpt.choices.some((c) => c.id === observedDefault);
          if (!inChoices) {
            logger2.warn(`Inferred choices for cmd_id=${toHex(cmd_id)} id=${toHex(id)} don't contain observed value ${observedDefault} \u2014 discarding inherited choices`);
            valueOpt.type = "number";
            delete valueOpt.choices;
          }
        }
        valueOpt.default = observedDefault;
      }
    }
    out.cmdSchema.push(action);
  }
  for (const { cmd_id, id } of parsed) {
    const alreadyTopLevel = out.cmdSchema.some((a) => a.cmd_id === cmd_id && a.id === id);
    if (alreadyTopLevel)
      continue;
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt2 = a.options?.find((o) => o.id === "idAdd");
      return !!idAddOpt2?.choices && id > a.id;
    });
    if (!idAddBase)
      continue;
    const offset = id - idAddBase.id;
    const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
    if (!idAddOpt?.choices || idAddOpt.choices.some((c) => c.id === offset))
      continue;
    const refHasOffset = candidates.some((c) => {
      const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      return refIdAdd?.choices?.some((ch) => ch.id === offset);
    });
    const existingOffsets = idAddOpt.choices.map((c) => c.id).sort((a, b) => a - b);
    const isSequential = existingOffsets.length > 0 && offset === existingOffsets[existingOffsets.length - 1] + 1;
    if (!refHasOffset && !isSequential)
      continue;
    let label = `Channel ${offset + 1}`;
    for (const c of candidates) {
      const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
      if (refChoice) {
        label = refChoice.label;
        break;
      }
    }
    idAddOpt.choices.push({ id: offset, label });
    logger2.info(`Pass 2: Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("refreshAfterCommand" in jsonObj) {
      orderedObj.refreshAfterCommand = jsonObj.refreshAfterCommand;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema.map((entry) => {
        const orderedEntry = {};
        if ("cmd_id" in entry)
          orderedEntry.cmd_id = entry.cmd_id;
        if ("id" in entry)
          orderedEntry.id = entry.id;
        if ("busCh" in entry)
          orderedEntry.busCh = entry.busCh;
        if ("name" in entry)
          orderedEntry.name = entry.name;
        if ("options" in entry)
          orderedEntry.options = entry.options;
        for (const key of Object.keys(entry)) {
          if (!(key in orderedEntry))
            orderedEntry[key] = entry[key];
        }
        return orderedEntry;
      });
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  wiredActions["global_getAllSettings"] = {
    name: "GLOBAL: Get All Settings (Auto-Update JSON)",
    options: [],
    callback: async () => {
      const model = activeModel;
      const ip = self.host;
      const buf = await self.stController.requestAllSettings(ip);
      let modelJson = getDeviceSchema(model);
      const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
      logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
      if (!modelJson) {
        logger3.info(`Model ${model} has no schema \u2014 creating new JSON from settings`);
        modelJson = {
          model,
          sectioned: detectedSectioned ?? false,
          refreshAfterCommand: true,
          cmdSchema: []
        };
      } else if (detectedSectioned !== null) {
        logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
        modelJson = { ...modelJson, sectioned: detectedSectioned };
      }
      const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
      logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
      const devicesFolder2 = getDevicesFolder();
      const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
      saveModelJsonPretty(schemaPath, updated);
      reloadDeviceSchemas();
      logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
    }
  };
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Mic"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
          await self.stController.requestAllSettings(ip).catch((err) => {
            logger3.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
}

// dist/feedbacks.js
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        let busCh = feedbackEvent.options["busCh"];
        if (busCh === void 0) {
          const schemaAction = findActionForSetting(schemas, model, cmdId, settingId);
          if (schemaAction?.busCh !== void 0) {
            busCh = schemaAction.busCh;
          }
        }
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
}

// dist/stcontroller.js
import dgram2 from "dgram";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger4 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger4.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger4.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger4.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger4.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger4.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger4.warn(`Could not join announce multicast group: ${err}`);
      }
    });
  });
}

// dist/stcontroller.js
var logger5 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  constructor() {
    logger5.info("StController initialized");
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger5.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger5.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger5.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger5.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger5.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger5.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger5.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    logger5.debug(`Revoked device at ${ip}`);
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    return new Promise((resolve) => {
      const key = `__probe_${ip}__`;
      let resolved = false;
      const finish = (result) => {
        if (resolved)
          return;
        resolved = true;
        this.discoveryListeners.delete(key);
        resolve(result);
      };
      this.discoveryListeners.set(key, (device) => {
        if (device.ip === ip)
          finish(device);
      });
      const timer = setTimeout(() => finish(null), timeoutMs);
      timer.unref?.();
      const run = async () => {
        await this.ensureMembershipFor(ip);
        await this.txReady;
        const query = buildDanteInfoRequest();
        this.txSocket.send(query, this.defaultPort, ip, (err) => {
          if (err) {
            logger5.warn(`Probe to ${ip} failed: ${err.message}`);
            clearTimeout(timer);
            finish(null);
          }
        });
      };
      run().catch((e) => {
        logger5.warn(`probeDevice setup failed for ${ip}: ${e}`);
        clearTimeout(timer);
        finish(null);
      });
    });
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger5.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger5.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger5.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger5.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger5.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger5.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger5.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger5.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && this.refreshAfterCommand && value !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger5.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (cmdId === CMD_MIC_PRE && busCh !== void 0 && settingId !== void 0 && value !== void 0) {
      if (!this.deviceState.has(destIp))
        this.deviceState.set(destIp, /* @__PURE__ */ new Map());
      const ipState = this.deviceState.get(destIp);
      const numPositions = 3;
      const positions = [];
      for (let i = 0; i < numPositions; i++) {
        const stateKey = makeSettingId(this.model, CMD_MIC_PRE, i, busCh);
        const val = i === settingId ? Number(value) : ipState.get(stateKey) ?? 0;
        positions.push(val);
        ipState.set(stateKey, val);
      }
      payloadBody.push(busCh & 255, ...positions);
    } else {
      if (busCh !== void 0)
        payloadBody.push(busCh & 255);
      if (addLen)
        payloadBody.push(dataBlock.length);
      if (dataBlock.length > 0)
        payloadBody.push(...dataBlock);
    }
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger5.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger5.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    if (!this.authorizedIps.has(destIp)) {
      logger5.debug(`Packet (not sent \u2014 device not authorized) to ${destIp}: ${payloadWithCrc.toString("hex")}`);
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    await this.ensureMembershipFor(destIp);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    logger5.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger5.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger5.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse && originalCmdId === CMD_GET_ALL_SETTINGS) {
      logger5.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
    }
    this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger5.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger5.info(`RX ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, s.id);
              this.feedbackCallback(baseFeedbackKey);
            } else {
              logger5.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger5.debug(`RX ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger5.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    const logFn = cmdId === CMD_BUS_GET ? logger5.debug.bind(logger5) : logger5.info.bind(logger5);
    if (decoded) {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_MIC_PRE (0x02): raw preamp echo — positional bytes, no setting IDs ──
      // Device echoes [busCh][val0][val1]... confirming the applied values.
      case CMD_MIC_PRE: {
        const busCh = data[0];
        const vals = Array.from(data.subarray(1)).map((b, i) => `[${i}]=0x${b.toString(16).padStart(2, "0")}(${b})`).join(" ");
        return `ch=${busCh} ${vals}`;
      }
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger6 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Connecting, "Discovering devices...");
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger6.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger6.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      if (this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found during discovery \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger6.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger6.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger6.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger6.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger6.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger6.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
      if (!effectiveModel && this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found among discovered devices \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    this.updateStatus(InstanceStatus.Ok);
    logger6.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger6.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current config is authorized to send commands.
   *
   * Auto mode (deviceMac set):
   *   - Find the discovered device with matching MAC → get its current IP
   *   - Revoke the previous IP, authorize the new IP
   *   - If MAC not found in discovery, revoke and block
   *
   * Manual mode (deviceMac empty):
   *   - Check discovered list by IP+model match, or probe directly
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.deviceMac) {
      const device = this.discoveredDevices.find((d) => d.mac === this.config.deviceMac);
      if (!device) {
        logger6.warn(`Device MAC "${this.config.deviceMac}" not found in current discovery \u2014 not authorizing`);
        if (previousHost)
          this.stController.revokeDevice(previousHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        await this.fetchSettingsAndEnsureSchema(device.model, newHost);
      }
      return;
    }
    const manualModel = String(this.config.activeModel ?? "");
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
      } else {
        logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
        this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${discoveredAtIp.model}`);
      }
      return;
    }
    logger6.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger6.error(`No device responded at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.UnknownWarning, `Device offline: ${newHost}`);
    } else if (probed.model !== manualModel) {
      logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${probed.model}`);
    } else {
      logger6.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
      this.updateStatus(InstanceStatus.Ok);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger6.warn(`No schema found for Model ${model} \u2014 run "GLOBAL: Get All Settings" to create one`);
        return;
      }
    } catch (e) {
      logger6.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger6.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, [], true);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    const refreshAfterCommand = schema.refreshAfterCommand ?? true;
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger6.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger6.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}, refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, resolved from MAC→IP via discoveredDevices (auto) or config.host (manual). */
  get host() {
    return resolveHost(this.config, this.discoveredDevices);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0LyoqIE1BQyBvZiB0aGUgc2VsZWN0ZWQgZGlzY292ZXJlZCBkZXZpY2UgKGUuZy4gXCIwMDoxZDpjMTo5YjphNjpjZFwiKSwgb3IgJycgZm9yIG1hbnVhbCBtb2RlICovXG5cdGRldmljZU1hYzogc3RyaW5nXG5cdC8qKiBNYW51YWwgSVAgYWRkcmVzcyBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGhvc3Q6IHN0cmluZ1xuXHQvKiogTWFudWFsIG1vZGVsIHNlbGVjdGlvbiBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcbn1cblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQ0VOVFJBTElaRUQgREVWSUNFIFNDSEVNQSBDQUNIRVxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQWxsIGRldmljZSBKU09OIGZpbGVzIGFyZSBsb2FkZWQgb25jZSBpbnRvIG1lbW9yeSBoZXJlLiBPdGhlciBtb2R1bGVzIHNob3VsZFxuLy8gdXNlIGdldERldmljZXNGb2xkZXIoKSwgZ2V0RGV2aWNlU2NoZW1hcygpLCBhbmQgZ2V0RGV2aWNlU2NoZW1hKCkgaW5zdGVhZCBvZlxuLy8gcmVhZGluZyBmaWxlcyBkaXJlY3RseS4gQ2FsbCByZWxvYWREZXZpY2VTY2hlbWFzKCkgYWZ0ZXIgd3JpdGluZyB0byBhIGZpbGUuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB0aGUgY29ycmVjdCBkZXZpY2VzIGZvbGRlciBwYXRoIHdpdGggZmFsbGJhY2sgc3VwcG9ydC5cbiAqIENoZWNrcyBwcmltYXJ5IHBhdGggZmlyc3QsIHRoZW4gZmFsbGJhY2ssIHRoZW4gdGhyb3dzIGVycm9yIGlmIG5laXRoZXIgZXhpc3RzLlxuICovXG5mdW5jdGlvbiByZXNvbHZlRGV2aWNlc0ZvbGRlcigpOiBzdHJpbmcge1xuXHRjb25zdCBwcmltYXJ5UGF0aCA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi4vZGV2aWNlcycpXG5cdGNvbnN0IGZhbGxiYWNrUGF0aCA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi9kZXZpY2VzJylcblxuXHQvLyBDaGVjayBwcmltYXJ5IHBhdGhcblx0aWYgKGZzLmV4aXN0c1N5bmMocHJpbWFyeVBhdGgpKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBVc2luZyBkZXZpY2VzIGZvbGRlcjogJHtwcmltYXJ5UGF0aH1gKVxuXHRcdHJldHVybiBwcmltYXJ5UGF0aFxuXHR9XG5cblx0Ly8gQ2hlY2sgZmFsbGJhY2sgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhmYWxsYmFja1BhdGgpKSB7XG5cdFx0bG9nZ2VyLndhcm4oYFByaW1hcnkgZGV2aWNlcyBmb2xkZXIgbm90IGZvdW5kLCB1c2luZyBmYWxsYmFjazogJHtmYWxsYmFja1BhdGh9YClcblx0XHRyZXR1cm4gZmFsbGJhY2tQYXRoXG5cdH1cblxuXHQvLyBOZWl0aGVyIHBhdGggZXhpc3RzIC0gZmF0YWwgZXJyb3Jcblx0Y29uc3QgZXJyb3JNc2cgPSBgRGV2aWNlcyBmb2xkZXIgbm90IGZvdW5kIVxcblRyaWVkOlxcbiAgLSAke3ByaW1hcnlQYXRofVxcbiAgLSAke2ZhbGxiYWNrUGF0aH1cXG5Nb2R1bGUgY2Fubm90IGNvbnRpbnVlIHdpdGhvdXQgZGV2aWNlIHNjaGVtYXMuYFxuXHRsb2dnZXIuZXJyb3IoZXJyb3JNc2cpXG5cdHRocm93IG5ldyBFcnJvcihlcnJvck1zZylcbn1cblxuLy8gUmVzb2x2ZSB0aGUgZGV2aWNlcyBmb2xkZXIgcGF0aCAod2l0aCBleGlzdGVuY2UgY2hlY2sgYW5kIGZhbGxiYWNrKVxuY29uc3QgZGV2aWNlc0ZvbGRlciA9IHJlc29sdmVEZXZpY2VzRm9sZGVyKClcblxuLy8gSW4tbWVtb3J5IGNhY2hlIG9mIGFsbCBkZXZpY2Ugc2NoZW1hcywga2V5ZWQgYnkgbW9kZWwgbnVtYmVyXG5sZXQgZGV2aWNlU2NoZW1hc0NhY2hlOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgbnVsbCA9IG51bGxcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBhYnNvbHV0ZSBwYXRoIHRvIHRoZSBkZXZpY2VzIGZvbGRlci5cbiAqIFVzZSB0aGlzIGluc3RlYWQgb2YgcmVkZWZpbmluZyB0aGUgcGF0aCBpbiBldmVyeSBmaWxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlc0ZvbGRlcigpOiBzdHJpbmcge1xuXHRyZXR1cm4gZGV2aWNlc0ZvbGRlclxufVxuXG4vKipcbiAqIExvYWRzIGFsbCBkZXZpY2UgSlNPTiBmaWxlcyBmcm9tIHRoZSBkZXZpY2VzIGZvbGRlciBpbnRvIG1lbW9yeS5cbiAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uY2UgYXQgaW5pdGlhbGl6YXRpb24sIG9yIGFmdGVyIGEgZmlsZSBpcyB3cml0dGVuLlxuICovXG5mdW5jdGlvbiBsb2FkRGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0Y29uc3Qgc2NoZW1hczogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9XG5cdHRyeSB7XG5cdFx0Y29uc3QgZmlsZXMgPSBmcy5yZWFkZGlyU3luYyhkZXZpY2VzRm9sZGVyKS5maWx0ZXIoKGYpID0+IGYuZW5kc1dpdGgoJy5qc29uJykpXG5cblx0XHRmb3IgKGNvbnN0IGYgb2YgZmlsZXMpIHtcblx0XHRcdGNvbnN0IGZ1bGxQYXRoID0gcGF0aC5qb2luKGRldmljZXNGb2xkZXIsIGYpXG5cdFx0XHRjb25zdCBqc29uID0gSlNPTi5wYXJzZShmcy5yZWFkRmlsZVN5bmMoZnVsbFBhdGgsICd1dGY4JykpXG5cdFx0XHRpZiAoanNvbj8ubW9kZWwpIHtcblx0XHRcdFx0c2NoZW1hc1tTdHJpbmcoanNvbi5tb2RlbCldID0ganNvblxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGxvZ2dlci5kZWJ1ZyhgTG9hZGVkICR7T2JqZWN0LmtleXMoc2NoZW1hcykubGVuZ3RofSBkZXZpY2Ugc2NoZW1hcyBpbnRvIGNhY2hlYClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmFpbGVkIHRvIGxvYWQgZGV2aWNlIHNjaGVtYXM6ICR7ZX1gKVxuXHR9XG5cdHJldHVybiBzY2hlbWFzXG59XG5cbi8qKlxuICogUmV0dXJucyBhbGwgZGV2aWNlIHNjaGVtYXMgZnJvbSB0aGUgY2FjaGUuXG4gKiBJbml0aWFsaXplcyB0aGUgY2FjaGUgb24gZmlyc3QgY2FsbC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZVNjaGVtYXMoKTogUmVjb3JkPHN0cmluZywgYW55PiB7XG5cdGlmICghZGV2aWNlU2NoZW1hc0NhY2hlKSB7XG5cdFx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxuXHR9XG5cdHJldHVybiBkZXZpY2VTY2hlbWFzQ2FjaGVcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgc3BlY2lmaWMgZGV2aWNlIHNjaGVtYSBieSBtb2RlbCBudW1iZXIuXG4gKiBSZXR1cm5zIHVuZGVmaW5lZCBpZiB0aGUgbW9kZWwgZG9lc24ndCBleGlzdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZVNjaGVtYShtb2RlbDogc3RyaW5nKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRyZXR1cm4gc2NoZW1hc1ttb2RlbF1cbn1cblxuLyoqXG4gKiBSZWxvYWRzIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIGRpc2suXG4gKiBDYWxsIHRoaXMgYWZ0ZXIgd3JpdGluZyB0byBhIGRldmljZSBKU09OIGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZWxvYWREZXZpY2VTY2hlbWFzKCk6IHZvaWQge1xuXHRsb2dnZXIuaW5mbygnUmVsb2FkaW5nIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay4uLicpXG5cdGRldmljZVNjaGVtYXNDYWNoZSA9IGxvYWREZXZpY2VTY2hlbWFzKClcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgbGlzdCBvZiBhdmFpbGFibGUgbW9kZWwgbnVtYmVycywgc29ydGVkLlxuICovXG5mdW5jdGlvbiBsb2FkQXZhaWxhYmxlTW9kZWxzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRyZXR1cm4gT2JqZWN0LmtleXMoc2NoZW1hcykuc29ydCgpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBHZXRDb25maWdGaWVsZHMoZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSA9IFtdKTogU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkW10ge1xuXHRjb25zdCBtb2RlbHMgPSBsb2FkQXZhaWxhYmxlTW9kZWxzKClcblxuXHQvLyBEcm9wZG93biBpZCBpcyB0aGUgZGV2aWNlIE1BQyBcdTIwMTQgc3RhYmxlIGFjcm9zcyBJUCBjaGFuZ2VzLlxuXHQvLyBFbXB0eSBpZCA9IE1hbnVhbCBtb2RlLlxuXHRjb25zdCBkZXZpY2VDaG9pY2VzID0gW1xuXHRcdHsgaWQ6ICcnLCBsYWJlbDogJ01hbnVhbCAoZW50ZXIgSVAgKyBtb2RlbCBiZWxvdyknIH0sXG5cdFx0Li4uZGlzY292ZXJlZERldmljZXMubWFwKChkKSA9PiAoe1xuXHRcdFx0aWQ6IGQubWFjID8/ICcnLFxuXHRcdFx0bGFiZWw6IGBNb2RlbCAke2QubW9kZWx9IFske2QubWFjfV0gQCAke2QuaXB9YCxcblx0XHR9KSksXG5cdF1cblxuXHRyZXR1cm4gW1xuXHRcdC8vIFx1MjUwMFx1MjUwMCBEZXZpY2Ugc2VsZWN0aW9uIGRyb3Bkb3duIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFN0b3JlcyB0aGUgTUFDIHNvIHJlLWRpc2NvdmVyeSB3aXRoIGEgY2hhbmdlZCBJUCBzdGlsbCBtYXRjaGVzLlxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2RldmljZU1hYycsXG5cdFx0XHRsYWJlbDogJ0RldmljZScsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0Y2hvaWNlczogZGV2aWNlQ2hvaWNlcyxcblx0XHRcdHRvb2x0aXA6ICdTZWxlY3QgYW4gYXV0by1kaXNjb3ZlcmVkIFN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlLCBvciBjaG9vc2UgTWFudWFsIHRvIGVudGVyIGFuIElQIGFkZHJlc3MuJyxcblx0XHR9LFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIE1hbnVhbCBJUCBlbnRyeSBcdTIwMTQgb25seSB2aXNpYmxlIGluIG1hbnVhbCBtb2RlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdHtcblx0XHRcdHR5cGU6ICd0ZXh0aW5wdXQnLFxuXHRcdFx0aWQ6ICdob3N0Jyxcblx0XHRcdGxhYmVsOiAnVGFyZ2V0IElQJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRyZWdleDogUmVnZXguSVAsXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkZXZpY2VNYWMpYCxcblx0XHRcdHRvb2x0aXA6ICdFbnRlciB0aGUgSVAgYWRkcmVzcyBvZiB0aGUgZGV2aWNlIG1hbnVhbGx5LicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNYW51YWwgbW9kZWwgc2VsZWN0b3IgXHUyMDE0IG9ubHkgdmlzaWJsZSBpbiBtYW51YWwgbW9kZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHR7XG5cdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0aWQ6ICdhY3RpdmVNb2RlbCcsXG5cdFx0XHRsYWJlbDogJ0FjdGl2ZSBEZXZpY2UgTW9kZWwnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiBtb2RlbHNbMF0gPz8gJycsXG5cdFx0XHRjaG9pY2VzOiBtb2RlbHMubWFwKChtb2RlbCkgPT4gKHtcblx0XHRcdFx0aWQ6IG1vZGVsLFxuXHRcdFx0XHRsYWJlbDogYE1vZGVsICR7bW9kZWx9YCxcblx0XHRcdH0pKSxcblx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246IGAhJChvcHRpb25zOmRldmljZU1hYylgLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCB3aGljaCBTdHVkaW8gVGVjaG5vbG9naWVzIG1vZGVsIGlzIGFjdGl2ZSBmb3IgYWN0aW9ucyBhbmQgZmVlZGJhY2tzLicsXG5cdFx0fSxcblx0XVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLlxuICogQXV0byBtb2RlIChkZXZpY2VNYWMgc2V0KTogZmluZHMgdGhlIGN1cnJlbnQgSVAgb2YgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIHdpdGggdGhhdCBNQUMuXG4gKiBNYW51YWwgbW9kZSAoZGV2aWNlTWFjIGVtcHR5KTogcmV0dXJucyB0aGUgbWFudWFsbHkgZW50ZXJlZCBob3N0IElQLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUhvc3QoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRldmljZU1hYykge1xuXHRcdGNvbnN0IGRldmljZSA9IGRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQubWFjID09PSBjb25maWcuZGV2aWNlTWFjKVxuXHRcdHJldHVybiBkZXZpY2U/LmlwID8/ICcnXG5cdH1cblx0cmV0dXJuIFN0cmluZyhjb25maWcuaG9zdCA/PyAnJylcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgbW9kZWwuXG4gKiBBdXRvIG1vZGU6IHVzZXMgdGhlIG1vZGVsIGZyb20gdGhlIGRpc2NvdmVyZWQgZGV2aWNlIG1hdGNoaW5nIHRoZSBzdG9yZWQgTUFDLlxuICogTWFudWFsIG1vZGU6IHVzZXMgdGhlIG1hbnVhbGx5IHNlbGVjdGVkIGFjdGl2ZU1vZGVsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZU1vZGVsKGNvbmZpZzogTW9kdWxlQ29uZmlnLCBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdKTogc3RyaW5nIHtcblx0aWYgKGNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRjb25zdCBkZXZpY2UgPSBkaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gY29uZmlnLmRldmljZU1hYylcblx0XHRsb2dnZXIuZGVidWcoYHJlc29sdmVNb2RlbDogZGV2aWNlTWFjPVwiJHtjb25maWcuZGV2aWNlTWFjfVwiLCBmb3VuZCBkZXZpY2U6ICR7ZGV2aWNlPy5tb2RlbCA/PyAnbm9uZSd9YClcblx0XHRyZXR1cm4gZGV2aWNlPy5tb2RlbCA/PyAnJ1xuXHR9XG5cdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBtYW51YWwgbW9kZSwgYWN0aXZlTW9kZWw9XCIke2NvbmZpZy5hY3RpdmVNb2RlbH1cImApXG5cdHJldHVybiBTdHJpbmcoY29uZmlnLmFjdGl2ZU1vZGVsID8/ICcnKVxufVxuIiwgImltcG9ydCB0eXBlIE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcblxuLyoqXG4gKiBEZWZpbmUgQ29tcGFuaW9uIHZhcmlhYmxlcyBmb3IgdGhpcyBtb2R1bGUuXG4gKiBWYXJpYWJsZXMgY2FuIGJlIHVzZWQgdG8gZGlzcGxheSBkeW5hbWljIHN0YXRlIGluIGJ1dHRvbiBsYWJlbHMsIHRyaWdnZXJzLCBldGMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh7XG5cdFx0bW9kZWw6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOdW1iZXInIH0sXG5cdFx0bW9kZWxOYW1lOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTmFtZSAoRnVsbCBEZXNjcmlwdGlvbiknIH0sXG5cdFx0bWFudWZhY3R1cmVyOiB7IG5hbWU6ICdEZXZpY2UgTWFudWZhY3R1cmVyJyB9LFxuXHRcdGZpcm13YXJlOiB7IG5hbWU6ICdEZXZpY2UgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRkYW50ZUZXOiB7IG5hbWU6ICdEYW50ZSBNb2R1bGUgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRtYWM6IHsgbmFtZTogJ0RldmljZSBNQUMgQWRkcmVzcycgfSxcblx0XHRpcDogeyBuYW1lOiAnRGV2aWNlIElQIEFkZHJlc3MnIH0sXG5cdH0pXG59XG5cbmNvbnN0IENMRUFSRURfVkFSSUFCTEVTID0ge1xuXHRtb2RlbDogJycsXG5cdG1vZGVsTmFtZTogJycsXG5cdG1hbnVmYWN0dXJlcjogJycsXG5cdGZpcm13YXJlOiAnJyxcblx0ZGFudGVGVzogJycsXG5cdG1hYzogJycsXG5cdGlwOiAnJyxcbn1cblxuLyoqXG4gKiBVcGRhdGUgdmFyaWFibGUgdmFsdWVzIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaW5mb3JtYXRpb24uXG4gKiBPbmx5IHBvcHVsYXRlcyB2YXJpYWJsZXMgd2hlbiB0aGUgY3VycmVudCBob3N0IGlzIGF1dGhvcml6ZWQuXG4gKiBDbGVhcnMgYWxsIHZhcmlhYmxlcyBpZiB0aGUgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkIG9yIG5vdCBmb3VuZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IGN1cnJlbnRIb3N0ID0gc2VsZi5ob3N0XG5cblx0Ly8gQ2xlYXIgdmFyaWFibGVzIGlmIG5vIGhvc3QgY29uZmlndXJlZCBvciBkZXZpY2UgaXMgbm90IGF1dGhvcml6ZWRcblx0aWYgKCFjdXJyZW50SG9zdCB8fCAhc2VsZi5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKGN1cnJlbnRIb3N0KSkge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoQ0xFQVJFRF9WQVJJQUJMRVMpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBkZXZpY2UgPSBzZWxmLmRldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY3VycmVudEhvc3QpXG5cdGlmIChkZXZpY2UpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdG1vZGVsOiBkZXZpY2UubW9kZWwgfHwgJycsXG5cdFx0XHRtb2RlbE5hbWU6IGRldmljZS5tb2RlbE5hbWUgfHwgJycsXG5cdFx0XHRtYW51ZmFjdHVyZXI6IGRldmljZS5tYW51ZmFjdHVyZXIgfHwgJycsXG5cdFx0XHRmaXJtd2FyZTogZGV2aWNlLmZpcm13YXJlTWFpbiB8fCAnJyxcblx0XHRcdGRhbnRlRlc6IGRldmljZS5kYW50ZUZpcm13YXJlIHx8ICcnLFxuXHRcdFx0bWFjOiBkZXZpY2UubWFjIHx8ICcnLFxuXHRcdFx0aXA6IGRldmljZS5pcCxcblx0XHR9KVxuXHR9IGVsc2Uge1xuXHRcdC8vIEF1dGhvcml6ZWQgYnV0IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgKG1hbnVhbCBJUCB0aGF0IHByb2JlZCBzdWNjZXNzZnVsbHkpXG5cdFx0Ly8gV2Uga25vdyBpdCdzIHRoZSByaWdodCBkZXZpY2UgYnV0IGRvbid0IGhhdmUgZnVsbCBpbmZvIHlldFxuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0Li4uQ0xFQVJFRF9WQVJJQUJMRVMsXG5cdFx0XHRpcDogY3VycmVudEhvc3QsXG5cdFx0fSlcblx0fVxufVxuIiwgImltcG9ydCB0eXBlIHsgQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG5leHBvcnQgY29uc3QgVXBncmFkZVNjcmlwdHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQ8TW9kdWxlQ29uZmlnPltdID0gW1xuXHQvKlxuXHQgKiBQbGFjZSB5b3VyIHVwZ3JhZGUgc2NyaXB0cyBoZXJlXG5cdCAqIFJlbWVtYmVyIHRoYXQgb25jZSBpdCBoYXMgYmVlbiBhZGRlZCBpdCBjYW5ub3QgYmUgcmVtb3ZlZCFcblx0ICovXG5cdC8vIGZ1bmN0aW9uIChjb250ZXh0LCBwcm9wcykge1xuXHQvLyBcdHJldHVybiB7XG5cdC8vIFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHQvLyBcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHQvLyBcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdC8vIFx0fVxuXHQvLyB9LFxuXVxuIiwgImV4cG9ydCB0eXBlIENvbXBhbmlvbklucHV0Q2hvaWNlID0ge1xuXHRpZDogc3RyaW5nIHwgbnVtYmVyXG5cdGxhYmVsOiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgRGV2aWNlU2V0dGluZyA9IHtcblx0dHlwZTogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVmYXVsdDogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhblxuXHRjaG9pY2VzPzogQ29tcGFuaW9uSW5wdXRDaG9pY2VbXVxufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFID0gMHgwMiAvLyBNaWMgcHJlYW1wIHJhdyBzZXQgKGdhaW4sIHBoYW50b20pIFx1MjAxNCBwb3NpdGlvbmFsIGJ5dGVzLCBubyBzZXR0aW5nIElEc1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBIZWFydGJlYXQgLyBrZWVwYWxpdmUgcGluZ1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfU0VUID0gMHgwNCAvLyBTZXQgc2V0dGluZyBvbiBzcGVjaWZpYyBidXMvY2hhbm5lbFxuZXhwb3J0IGNvbnN0IENNRF9IRUFEUEhPTkUgPSAweDA1IC8vIEhlYWRwaG9uZSBjb250cm9sc1xuZXhwb3J0IGNvbnN0IENNRF9CVVRUT05fTU9ERSA9IDB4MDcgLy8gQnV0dG9uIG1vZGUgY29uZmlndXJhdGlvblxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kc1xuZXhwb3J0IGNvbnN0IENNRF9HRVRfQUxMX1NFVFRJTkdTID0gMHgwYSAvLyBSZXF1ZXN0IGFsbCBjdXJyZW50IHNldHRpbmdzIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX1NFVFRJTkdTX1BVU0ggPSAweDBiIC8vIFVuc29saWNpdGVkIHNldHRpbmdzIHVwZGF0ZSBmcm9tIGRldmljZVxuZXhwb3J0IGNvbnN0IENNRF9ERVZfU1BFQyA9IDB4MGQgLy8gRGV2aWNlLXNwZWNpZmljIHNldHRpbmcgZ2V0L3NldCB3aXRoIEFDS1xuZXhwb3J0IGNvbnN0IENNRF9SRVNFVF9ERVZJQ0UgPSAweDBlIC8vIEZhY3RvcnkgcmVzZXQgY29tbWFuZFxuZXhwb3J0IGNvbnN0IENNRF9HTE9CQUxfTUlDX0tJTEwgPSAweDEwIC8vIEVtZXJnZW5jeSBtaWMga2lsbCAoYWxsIGNoYW5uZWxzKVxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFX0JVUyA9IDB4MTIgLy8gTWljL3ByZWFtcCBzZXR0aW5ncyBwZXIgYnVzIChnYWluLCBwaGFudG9tLCBldGMpXG5leHBvcnQgY29uc3QgQ01EX0NIQU5ORUwgPSAweDE0IC8vIENoYW5uZWwtc3BlY2lmaWMgY29udHJvbHNcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIENvbW1hbmQgTmFtZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29tbWFuZE5hbWUoY21kSWQ6IG51bWJlcik6IHN0cmluZyB7XG5cdHN3aXRjaCAoY21kSWQpIHtcblx0XHRjYXNlIENNRF9HRVRfRklSTVdBUkU6XG5cdFx0XHRyZXR1cm4gJ0dldCBGaXJtd2FyZSBWZXJzaW9uJ1xuXHRcdGNhc2UgQ01EX01JQ19QUkU6XG5cdFx0XHRyZXR1cm4gJ01pYyBQcmVhbXAnXG5cdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdHJldHVybiAnSGVhcnRiZWF0J1xuXHRcdGNhc2UgQ01EX0JVU19TRVQ6XG5cdFx0XHRyZXR1cm4gJ1NldCBCdXMgU2V0dGluZydcblx0XHRjYXNlIENNRF9IRUFEUEhPTkU6XG5cdFx0XHRyZXR1cm4gJ0hlYWRwaG9uZSBDb250cm9sJ1xuXHRcdGNhc2UgQ01EX0JVVFRPTl9NT0RFOlxuXHRcdFx0cmV0dXJuICdCdXR0b24gTW9kZSdcblx0XHRjYXNlIENNRF9TWVNURU06XG5cdFx0XHRyZXR1cm4gJ1N5c3RlbSBDb21tYW5kJ1xuXHRcdGNhc2UgQ01EX0dFVF9BTExfU0VUVElOR1M6XG5cdFx0XHRyZXR1cm4gJ1JlcXVlc3QgQWxsIFNldHRpbmdzJ1xuXHRcdGNhc2UgQ01EX1NFVFRJTkdTX1BVU0g6XG5cdFx0XHRyZXR1cm4gJ1NldHRpbmdzIFB1c2gnXG5cdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6XG5cdFx0XHRyZXR1cm4gJ01pYy9QcmUgQnVzJ1xuXHRcdGNhc2UgQ01EX0RFVl9TUEVDOlxuXHRcdFx0cmV0dXJuICdEZXZpY2UgU2V0dGluZydcblx0XHRjYXNlIENNRF9DSEFOTkVMOlxuXHRcdFx0cmV0dXJuICdDaGFubmVsIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfUkVTRVRfREVWSUNFOlxuXHRcdFx0cmV0dXJuICdSZXNldCBEZXZpY2UnXG5cdFx0Y2FzZSBDTURfR0xPQkFMX01JQ19LSUxMOlxuXHRcdFx0cmV0dXJuICdHbG9iYWwgTWljIEtpbGwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgY21kXzB4JHtjbWRJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIEdlbmVyYXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDcmVhdGVzIGEgY29uc2lzdGVudCBJRCBmb3IgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgc3RhdGUga2V5cy5cbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2J1c0NofV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKGUuZy4sIFwiNTMwNF8xNF8wXzBcIilcbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGhvdXQgYnVzQ2ggKGUuZy4sIFwiNTMwNF8xMl9kXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWtlU2V0dGluZ0lkKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRzZXR0aW5nSWQ6IG51bWJlciB8IHN0cmluZyxcblx0YnVzQ2g/OiBudW1iZXIgfCBzdHJpbmcsXG4pOiBzdHJpbmcge1xuXHRjb25zdCBjbWQgPSB0eXBlb2YgY21kSWQgPT09ICdudW1iZXInID8gY21kSWQudG9TdHJpbmcoMTYpIDogY21kSWRcblx0Y29uc3QgaWQgPSB0eXBlb2Ygc2V0dGluZ0lkID09PSAnbnVtYmVyJyA/IHNldHRpbmdJZC50b1N0cmluZygxNikgOiBzZXR0aW5nSWRcblxuXHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IGNoID0gdHlwZW9mIGJ1c0NoID09PSAnbnVtYmVyJyA/IGJ1c0NoLnRvU3RyaW5nKDE2KSA6IGJ1c0NoXG5cdFx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtjaH1fJHtpZH1gXG5cdH1cblxuXHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2lkfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEhleCBGb3JtYXR0aW5nIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENvbnZlcnRzIGEgbnVtYmVyIHRvIGEgaGV4IHN0cmluZyB3aXRoIDB4IHByZWZpeCBhbmQgcGFkZGluZy5cbiAqIEBwYXJhbSB2YWx1ZSAtIFRoZSBudW1iZXIgdG8gY29udmVydFxuICogQHBhcmFtIHBhZExlbmd0aCAtIE51bWJlciBvZiBoZXggZGlnaXRzIHRvIHBhZCB0byAoZGVmYXVsdDogMilcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGRcIiwgXCIweGZmXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0hleCh2YWx1ZTogbnVtYmVyLCBwYWRMZW5ndGggPSAyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAweCR7dmFsdWUudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KHBhZExlbmd0aCwgJzAnKX1gXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gYXJyYXkgb2YgYnl0ZXMgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4LlxuICogQHBhcmFtIGJ5dGVzIC0gQXJyYXkgb2YgYnl0ZXMgb3IgQnVmZmVyXG4gKiBAcmV0dXJucyBGb3JtYXR0ZWQgaGV4IHN0cmluZyAoZS5nLiwgXCIweDBhZmYxMlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnl0ZXNUb0hleChieXRlczogbnVtYmVyW10gfCBCdWZmZXIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHtBcnJheS5mcm9tKGJ5dGVzKVxuXHRcdC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0LmpvaW4oJycpfWBcbn1cblxuLyoqXG4gKiBGb3JtYXRzIFJHQiBjb2xvciBieXRlcyBhcyBhIENTUyBoZXggY29sb3Igc3RyaW5nLlxuICogQHBhcmFtIHIgLSBSZWQgY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBnIC0gR3JlZW4gY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBiIC0gQmx1ZSBjb21wb25lbnQgKDAtMjU1KVxuICogQHJldHVybnMgQ1NTIGhleCBjb2xvciBzdHJpbmcgKGUuZy4sIFwiI0ZGMDBBQlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UmdiQ29sb3IocjogbnVtYmVyLCBnOiBudW1iZXIsIGI6IG51bWJlcik6IHN0cmluZyB7XG5cdHJldHVybiBgIyR7W3IsIGcsIGJdXG5cdFx0Lm1hcCgodikgPT4gdi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJylcblx0XHQudG9VcHBlckNhc2UoKX1gXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBJRCBQYXJzaW5nIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogUGFyc2VzIGEgc2V0dGluZyBJRCBzdHJpbmcgaW50byBpdHMgY29tcG9uZW50cy5cbiAqIEBwYXJhbSBpZCAtIFNldHRpbmcgSUQgc3RyaW5nIChlLmcuLCBcIjM5MV9kXzBcIiBvciBcIjUzMDRfMTRfMF8xXCIpXG4gKiBAcmV0dXJucyBQYXJzZWQgY29tcG9uZW50cyB3aXRoIGhleCBzdHJpbmdzIGNvbnZlcnRlZCB0byBudW1iZXJzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdJZChpZDogc3RyaW5nKTogeyBtb2RlbDogc3RyaW5nOyBjbWRJZDogbnVtYmVyOyBiYXNlSWQ6IG51bWJlciB9IHtcblx0Y29uc3QgW21vZGVsLCBjbWRJZFN0ciwgaWRTdHJdID0gaWQuc3BsaXQoJ18nKVxuXHRyZXR1cm4ge1xuXHRcdG1vZGVsLFxuXHRcdGNtZElkOiBwYXJzZUludChjbWRJZFN0ciwgMTYpLFxuXHRcdGJhc2VJZDogcGFyc2VJbnQoaWRTdHIsIDE2KSxcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgTW9kZWwgRGlzdGFuY2UgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDYWxjdWxhdGVzIG51bWVyaWMgZGlzdGFuY2UgYmV0d2VlbiB0d28gbW9kZWwgbnVtYmVycy5cbiAqIFVzZWQgZm9yIGZpbmRpbmcgc2ltaWxhciBtb2RlbHMgZm9yIHNldHRpbmcgaW5mZXJlbmNlLlxuICogQHBhcmFtIG1vZGVsQSAtIEZpcnN0IG1vZGVsIG51bWJlciAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBtb2RlbEIgLSBTZWNvbmQgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MlwiKVxuICogQHJldHVybnMgTnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIG1vZGVscywgb3IgSW5maW5pdHkgaWYgZWl0aGVyIGlzIG5vbi1udW1lcmljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb2RlbERpc3RhbmNlKG1vZGVsQTogc3RyaW5nLCBtb2RlbEI6IHN0cmluZyk6IG51bWJlciB7XG5cdGNvbnN0IG5hID0gcGFyc2VJbnQobW9kZWxBLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRjb25zdCBuYiA9IHBhcnNlSW50KG1vZGVsQi5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0aWYgKE51bWJlci5pc05hTihuYSkgfHwgTnVtYmVyLmlzTmFOKG5iKSkgcmV0dXJuIEluZmluaXR5XG5cdHJldHVybiBNYXRoLmFicyhuYSAtIG5iKVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU2NoZW1hIE5vcm1hbGl6YXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBOb3JtYWxpemVzIGRldmljZSBzY2hlbWFzIHRvIGVuc3VyZSBjbWRTY2hlbWEgaXMgYWx3YXlzIGFuIGFycmF5LlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgc2NoZW1hIHRyYW5zZm9ybWF0aW9uIGNvZGUuXG4gKiBAcGFyYW0gc2NoZW1hc1JhdyAtIFJhdyBzY2hlbWFzIGZyb20gZ2V0RGV2aWNlU2NoZW1hcygpXG4gKiBAcmV0dXJucyBOb3JtYWxpemVkIHNjaGVtYXMgd2l0aCBndWFyYW50ZWVkIGNtZFNjaGVtYSBhcnJheXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldE5vcm1hbGl6ZWRTY2hlbWFzKFxuXHRzY2hlbWFzUmF3OiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuKTogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+IHtcblx0Y29uc3Qgbm9ybWFsaXplZDogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+ID0ge31cblx0Zm9yIChjb25zdCBbbW9kZWwsIGpzb25dIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXNSYXcpKSB7XG5cdFx0bm9ybWFsaXplZFttb2RlbF0gPSB7XG5cdFx0XHRtb2RlbDoganNvbi5tb2RlbCxcblx0XHRcdGNtZFNjaGVtYTogQXJyYXkuaXNBcnJheShqc29uLmNtZFNjaGVtYSkgPyBqc29uLmNtZFNjaGVtYSA6IFtdLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4gbm9ybWFsaXplZFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQWN0aW9uIExvb2t1cCBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIEZpbmRzIGFuIGFjdGlvbi9zZXR0aW5nIGluIHRoZSBzY2hlbWEsIHN1cHBvcnRpbmcgYm90aCBleGFjdCBtYXRjaGVzIGFuZCBpZEFkZCBvZmZzZXRzLlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgYWN0aW9uIGxvb2t1cCBsb2dpYyBhY3Jvc3MgbXVsdGlwbGUgZmlsZXMuXG4gKiBAcGFyYW0gc2NoZW1hcyAtIE5vcm1hbGl6ZWQgZGV2aWNlIHNjaGVtYXNcbiAqIEBwYXJhbSBtb2RlbCAtIERldmljZSBtb2RlbCAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBjbWRJZCAtIENvbW1hbmQgSURcbiAqIEBwYXJhbSBzZXR0aW5nSWQgLSBTZXR0aW5nIElEIChtYXkgaW5jbHVkZSBpZEFkZCBvZmZzZXQpXG4gKiBAcmV0dXJucyBNYXRjaGluZyBhY3Rpb24vc2V0dGluZyBvciB1bmRlZmluZWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmRBY3Rpb25Gb3JTZXR0aW5nKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0aWYgKCFzY2hlbWEgfHwgIUFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkpIHJldHVybiB1bmRlZmluZWRcblxuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IHNjaGVtYS5jbWRTY2hlbWEuZmluZCgoczogYW55KSA9PiBzLmNtZF9pZCA9PT0gY21kSWQgJiYgcy5pZCA9PT0gc2V0dGluZ0lkKVxuXG5cdC8vIElmIG5vIGV4YWN0IG1hdGNoLCB0cnkgdG8gZmluZCBiYXNlIGFjdGlvbiB3aXRoIGlkQWRkXG5cdGlmICghYWN0aW9uKSB7XG5cdFx0YWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHtcblx0XHRcdGlmIChzLmNtZF9pZCAhPT0gY21kSWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBzLm9wdGlvbnM/LmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHNldHRpbmdJZCBtYXRjaGVzIGJhc2UgKyBhbnkgaWRBZGQgb2Zmc2V0XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBzZXR0aW5nSWQgLSBzLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvblxufVxuIiwgIi8qKlxuICogYnVpbGQtY29tbWFuZHMudHNcbiAqIC0gVXNlcyBjZW50cmFsaXplZCBkZXZpY2Ugc2NoZW1hIGNhY2hlIGZyb20gY29uZmlnLnRzXG4gKiAtIFByb2R1Y2VzIENvbXBhbmlvbiBhY3Rpb24gZGVmaW5pdGlvbnMgYW5kIGZlZWRiYWNrc1xuICovXG5cbmltcG9ydCB7XG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zLFxuXHRDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uLFxuXHRDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgbWFrZVNldHRpbmdJZCB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0gT3B0aW9uIEJ1aWxkZXIgLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZnVuY3Rpb24gYnVpbGRPcHRpb24obzogYW55KTogYW55IHtcblx0Y29uc3QgYmFzZSA9IHtcblx0XHR0eXBlOiBvLnR5cGUsXG5cdFx0aWQ6IG8uaWQsXG5cdFx0bGFiZWw6IG8ubGFiZWwsXG5cdFx0ZGVmYXVsdDogby5kZWZhdWx0LFxuXHRcdHRvb2x0aXA6IG8udG9vbHRpcCxcblx0fVxuXG5cdHN3aXRjaCAoby50eXBlKSB7XG5cdFx0Y2FzZSAnZHJvcGRvd24nOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgY2hvaWNlczogby5jaG9pY2VzID8/IFtdIH1cblxuXHRcdGNhc2UgJ251bWJlcic6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5iYXNlLFxuXHRcdFx0XHRtaW46IG8ubWluLFxuXHRcdFx0XHRtYXg6IG8ubWF4LFxuXHRcdFx0XHRzdGVwOiBvLnN0ZXAgPz8gMSxcblx0XHRcdFx0cmFuZ2U6IHRydWUsXG5cdFx0XHR9XG5cblx0XHRjYXNlICdjaGVja2JveCc6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBkZWZhdWx0OiBvLmRlZmF1bHQgPz8gZmFsc2UgfVxuXG5cdFx0Y2FzZSAnc3RhdGljLXRleHQnOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgdmFsdWU6IG8udmFsdWUgPz8gJycgfVxuXG5cdFx0Y2FzZSAndGV4dGlucHV0Jzpcblx0XHRjYXNlICdjb2xvcnBpY2tlcic6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIGEuY21kX2lkLCBhLmlkKVxuXG5cdFx0XHRjb25zdCBvcHRpb25zID0gKGEub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHRjb25zdCBhY3Rpb246IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHthLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVBY3Rpb25zICovXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGFjdGlvbnNbYWN0aW9uSWRdID0gYWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvbnNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBGZWVkYmFja3MgLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGZWVkYmFja3MoKTogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgZmVlZGJhY2tzOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3Qgc2V0dGluZyBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0lkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgc2V0dGluZy5jbWRfaWQsIHNldHRpbmcuaWQpXG5cblx0XHRcdC8vIEJ1aWxkIG9wdGlvbnNcblx0XHRcdGNvbnN0IGFsbE9wdGlvbnMgPSAoc2V0dGluZy5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdC8vIEZpbHRlciBvdXQgJ3ZhbHVlJyBvcHRpb24gZm9yIHZhbHVlIGZlZWRiYWNrIChrZWVwIG9ubHkgYnVzQ2gvaWRBZGQpXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbnMgPSBhbGxPcHRpb25zLmZpbHRlcigob3B0OiBhbnkpID0+IG9wdC5pZCAhPT0gJ3ZhbHVlJylcblxuXHRcdFx0Ly8gQWRkIGEgY2hlY2tib3ggb3B0aW9uIHRvIHJldHVybiBsYWJlbCBpbnN0ZWFkIG9mIHZhbHVlXG5cdFx0XHR2YWx1ZU9wdGlvbnMucHVzaCh7XG5cdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0bGFiZWw6ICdTaG93IExhYmVsJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHR9KVxuXG5cdFx0XHQvLyBWYWx1ZSBmZWVkYmFjayBmb3IgYWxsIHNldHRpbmdzIChhcHBlYXJzIGluIFZhcmlhYmxlcyBsaXN0KVxuXHRcdFx0Y29uc3QgdmFsdWVGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHR0eXBlOiAndmFsdWUnLFxuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnM6IHZhbHVlT3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRyZXR1cm4gMFxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRmZWVkYmFja3NbYmFzZUZlZWRiYWNrSWRdID0gdmFsdWVGZWVkYmFja1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IGdldERldmljZXNGb2xkZXIsIGdldERldmljZVNjaGVtYSwgZ2V0RGV2aWNlU2NoZW1hcywgcmVsb2FkRGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuXG5pbXBvcnQgeyBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbiwgc2F2ZU1vZGVsSnNvblByZXR0eSwgdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzIH0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdBY3Rpb25zJylcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUFjdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdBY3Rpb25zID0gYnVpbGRBY3Rpb25zKClcblx0Y29uc3Qgc2NoZW1hcyA9IGdldE5vcm1hbGl6ZWRTY2hlbWFzKHNjaGVtYXNSYXcpXG5cdGNvbnN0IHdpcmVkQWN0aW9uczogYW55ID0ge31cblxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEdMT0JBTDogR0VUIEFMTCBTRVRUSU5HUyAoQVVUTyBKU09OIFVQREFURSlcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0d2lyZWRBY3Rpb25zWydnbG9iYWxfZ2V0QWxsU2V0dGluZ3MnXSA9IHtcblx0XHRuYW1lOiAnR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzIChBdXRvLVVwZGF0ZSBKU09OKScsXG5cdFx0b3B0aW9uczogW10sXG5cdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdGNvbnN0IG1vZGVsID0gYWN0aXZlTW9kZWxcblx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cblx0XHRcdGNvbnN0IGJ1ZiA9IGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIHRvIGdldCB0aGUgc2NoZW1hIChtYXkgYmUgbnVsbCBmb3IgbmV3L3Vua25vd24gZGV2aWNlcylcblx0XHRcdGxldCBtb2RlbEpzb24gPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cblx0XHRcdC8vIFBhcnNlIHdpdGggYXV0by1kZXRlY3Rpb25cblx0XHRcdGNvbnN0IHsgc2V0dGluZ3M6IHBhcnNlZCwgZGV0ZWN0ZWRTZWN0aW9uZWQgfSA9IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uKG1vZGVsLCBidWYpXG5cdFx0XHRsb2dnZXIuZGVidWcoYHBhcnNlZCByZXBseTogJHtKU09OLnN0cmluZ2lmeShwYXJzZWQpfWApXG5cblx0XHRcdGlmICghbW9kZWxKc29uKSB7XG5cdFx0XHRcdC8vIE5vIHNjaGVtYSB5ZXQgXHUyMDE0IGNyZWF0ZSBhIG1pbmltYWwgb25lIGZyb20gdGhlIHBhcnNlZCBzZXR0aW5nc1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gaGFzIG5vIHNjaGVtYSBcdTIwMTQgY3JlYXRpbmcgbmV3IEpTT04gZnJvbSBzZXR0aW5nc2ApXG5cdFx0XHRcdG1vZGVsSnNvbiA9IHtcblx0XHRcdFx0XHRtb2RlbCxcblx0XHRcdFx0XHRzZWN0aW9uZWQ6IGRldGVjdGVkU2VjdGlvbmVkID8/IGZhbHNlLFxuXHRcdFx0XHRcdHJlZnJlc2hBZnRlckNvbW1hbmQ6IHRydWUsXG5cdFx0XHRcdFx0Y21kU2NoZW1hOiBbXSxcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIGlmIChkZXRlY3RlZFNlY3Rpb25lZCAhPT0gbnVsbCkge1xuXHRcdFx0XHQvLyBJZiB3ZSBhdXRvLWRldGVjdGVkIHRoZSBmb3JtYXQsIGFkZCBpdCB0byB0aGUgSlNPTlxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBzZWN0aW9uZWQ9JHtkZXRlY3RlZFNlY3Rpb25lZH0sIGFkZGluZyB0byBtb2RlbCBKU09OYClcblx0XHRcdFx0bW9kZWxKc29uID0geyAuLi5tb2RlbEpzb24sIHNlY3Rpb25lZDogZGV0ZWN0ZWRTZWN0aW9uZWQgfVxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCB1cGRhdGVkID0gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKG1vZGVsSnNvbiwgcGFyc2VkLCBzY2hlbWFzKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBuZXcgQWN0aW9ucyBqc29uOiAke0pTT04uc3RyaW5naWZ5KHVwZGF0ZWQsIG51bGwsIDIpfWApXG5cblx0XHRcdC8vIFNhdmUgdGhlIHVwZGF0ZWQgSlNPTiB0byBkaXNrXG5cdFx0XHRjb25zdCBkZXZpY2VzRm9sZGVyID0gZ2V0RGV2aWNlc0ZvbGRlcigpXG5cdFx0XHRjb25zdCBzY2hlbWFQYXRoID0gcGF0aC5qb2luKGRldmljZXNGb2xkZXIsIGBNb2RlbCR7bW9kZWx9Lmpzb25gKVxuXHRcdFx0c2F2ZU1vZGVsSnNvblByZXR0eShzY2hlbWFQYXRoLCB1cGRhdGVkKVxuXG5cdFx0XHQvLyBSZWxvYWQgdGhlIGNhY2hlIGFmdGVyIHdyaXRpbmcgdG8gZmlsZVxuXHRcdFx0cmVsb2FkRGV2aWNlU2NoZW1hcygpXG5cblx0XHRcdGxvZ2dlci5pbmZvKGBNb2RlbCAke21vZGVsfSBKU09OIGF1dG8tdXBkYXRlZCBmcm9tIGdldEFsbFNldHRpbmdzYClcblx0XHR9LFxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBCVUlMRCBQRVItU0VUVElORyBBQ1RJT05TIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2FjdGlvbklkLCBhY3Rpb25dIG9mIE9iamVjdC5lbnRyaWVzKHJhd0FjdGlvbnMpKSB7XG5cdFx0Y29uc3QgeyBtb2RlbCwgY21kSWQsIGJhc2VJZCB9ID0gcGFyc2VTZXR0aW5nSWQoYWN0aW9uSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgYWN0aW9ucyBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgbW9kZWxcblx0XHRpZiAobW9kZWwgIT09IGFjdGl2ZU1vZGVsKSBjb250aW51ZVxuXG5cdFx0Ly8gR2V0IHRoZSByYXcgYWN0aW9uIHNjaGVtYSB0byBhY2Nlc3MgZml4ZWQgYnVzQ2ggdmFsdWVcblx0XHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRcdGNvbnN0IHJhd0FjdGlvbiA9IHNjaGVtYT8uY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBiYXNlSWQpXG5cblx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0Li4uYWN0aW9uLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jIChldmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSAhPT0gdW5kZWZpbmVkID8gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSA6IHJhd0FjdGlvbj8uYnVzQ2hcblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBldmVudC5vcHRpb25zWyd2YWx1ZSddXG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cblx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIuc2VuZEF3YWl0QWNrKGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgaXApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgTUlDIEtJTEwgKE9OTFkgSUYgQUNUSVZFIE1PREVMIFNVUFBPUlRTIElUKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Y29uc3QgYWN0aXZlU2NoZW1hID0gc2NoZW1hc1thY3RpdmVNb2RlbF1cblx0aWYgKGFjdGl2ZVNjaGVtYSkge1xuXHRcdGNvbnN0IHN1cHBvcnRzTWljS2lsbCA9IChhY3RpdmVTY2hlbWEuY21kU2NoZW1hID8/IFtdKS5zb21lKChhOiBhbnkpID0+IGEubmFtZS5pbmNsdWRlcygnTWljJykpXG5cblx0XHRpZiAoc3VwcG9ydHNNaWNLaWxsKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IGAke2FjdGl2ZU1vZGVsfV9taWNLaWxsYFxuXG5cdFx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHthY3RpdmVNb2RlbH1dIE1pYyBLaWxsYCxcblx0XHRcdFx0b3B0aW9uczogW10sXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgTWljIEtpbGwgXHUyMTkyIE1vZGVsICR7YWN0aXZlTW9kZWx9IEAgJHtpcH1gKVxuXHRcdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLmdsb2JhbE1pY0tpbGwoaXApXG5cdFx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKGlwKS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdHNlbGYuc2V0QWN0aW9uRGVmaW5pdGlvbnMod2lyZWRBY3Rpb25zKVxuXG5cdC8vY29uc29sZS5sb2coJ0FjdGlvbnM6XFxuJywgSlNPTi5zdHJpbmdpZnkod2lyZWRBY3Rpb25zLCBudWxsLCAyKSlcbn1cbiIsICJpbXBvcnQgZnMgZnJvbSAnZnMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWEgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQge1xuXHRDTURfTUlDX1BSRSxcblx0Q01EX0JVU19TRVQsXG5cdENNRF9DSEFOTkVMLFxuXHRDTURfREVWX1NQRUMsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHR0b0hleCxcblx0Ynl0ZXNUb0hleCxcblx0Zm9ybWF0UmdiQ29sb3IsXG5cdG1vZGVsRGlzdGFuY2UsXG59IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU2V0dGluZ3NQYXJzZXInKVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBUWVBFU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgdHlwZSBQYXJzZWRTZXR0aW5nID0ge1xuXHRjbWRfaWQ6IG51bWJlclxuXHRpZDogbnVtYmVyXG5cdGJ1c0NoPzogbnVtYmVyIC8vIE9wdGlvbmFsOiBvbmx5IHByZXNlbnQgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKDB4MDQsIDB4MTIsIDB4MTQpXG5cdHZhbHVlQnl0ZXM6IG51bWJlcltdXG59XG5cbmV4cG9ydCB0eXBlIFN0QWN0aW9uT3B0aW9uID0ge1xuXHRpZD86IHN0cmluZ1xuXHRsYWJlbDogc3RyaW5nXG5cdHR5cGU6IHN0cmluZ1xuXHRkZWZhdWx0OiB1bmtub3duXG5cdHRvb2x0aXA/OiBzdHJpbmdcblx0Y2hvaWNlcz86IEFycmF5PHsgaWQ6IG51bWJlcjsgbGFiZWw6IHN0cmluZyB9PlxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbiA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRuYW1lOiBzdHJpbmdcblx0b3B0aW9uczogU3RBY3Rpb25PcHRpb25bXVxuXHRidXNDaD86IG51bWJlciAvLyBGaXhlZCBjaGFubmVsIHZhbHVlIGZvciBhY3Rpb25zIHRoYXQgZG9uJ3QgaGF2ZSBhIGNoYW5uZWwgb3B0aW9uXG59XG5cbmV4cG9ydCB0eXBlIFN0TW9kZWxKc29uID0ge1xuXHRtb2RlbDogc3RyaW5nXG5cdHNlY3Rpb25lZD86IGJvb2xlYW5cblx0cmVmcmVzaEFmdGVyQ29tbWFuZD86IGJvb2xlYW5cblx0Y21kU2NoZW1hOiBTdEFjdGlvbltdXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZPUk1BVCBIRUxQRVJTXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIGdldE1vZGVsQ29uZmlnKG1vZGVsOiBzdHJpbmcpOiB7IHNlY3Rpb25lZDogYm9vbGVhbjsgcmdiSWRzOiBTZXQ8bnVtYmVyPiB9IHtcblx0Y29uc3QgcmdiSWRzID0gbmV3IFNldDxudW1iZXI+KClcblx0bGV0IHNlY3Rpb25lZCA9IGZhbHNlXG5cblx0dHJ5IHtcblx0XHQvLyBVc2UgY2VudHJhbGl6ZWQgY2FjaGUgaW5zdGVhZCBvZiByZWFkaW5nIGZyb20gZGlza1xuXHRcdGNvbnN0IGpzb24gPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0aWYgKCFqc29uKSB7XG5cdFx0XHQvLyBJZiB3ZSBjYW4ndCBsb2FkIHRoZSBzY2hlbWEsIHJldHVybiBkZWZhdWx0c1xuXHRcdFx0cmV0dXJuIHsgc2VjdGlvbmVkLCByZ2JJZHMgfVxuXHRcdH1cblxuXHRcdC8vIFJlYWQgc2VjdGlvbmVkIHByb3BlcnR5IChkZWZhdWx0IHRvIGZhbHNlIGlmIG5vdCBzcGVjaWZpZWQpXG5cdFx0c2VjdGlvbmVkID0ganNvbi5zZWN0aW9uZWQgPz8gZmFsc2VcblxuXHRcdC8vIEJ1aWxkIFJHQiBJRHMgc2V0XG5cdFx0Zm9yIChjb25zdCBhY3Rpb24gb2YganNvbi5jbWRTY2hlbWEgfHwgW10pIHtcblx0XHRcdGNvbnN0IGhhc0NvbG9ycGlja2VyID0gYWN0aW9uLm9wdGlvbnM/LnNvbWUoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC50eXBlID09PSAnY29sb3JwaWNrZXInKVxuXHRcdFx0aWYgKGhhc0NvbG9ycGlja2VyKSB7XG5cdFx0XHRcdC8vIEFkZCB0aGUgYmFzZSBJRFxuXHRcdFx0XHRyZ2JJZHMuYWRkKGFjdGlvbi5pZClcblxuXHRcdFx0XHQvLyBJZiB0aGlzIGFjdGlvbiBoYXMgaWRBZGQgY2hvaWNlcywgYWRkIGFsbCB0aGUgb2Zmc2V0IElEcyB0b29cblx0XHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0OiBTdEFjdGlvbk9wdGlvbikgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRpZiAoaWRBZGRPcHRpb24/LmNob2ljZXMpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGNob2ljZSBvZiBpZEFkZE9wdGlvbi5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0XHRpZiAodHlwZW9mIGNob2ljZS5pZCA9PT0gJ251bWJlcicpIHtcblx0XHRcdFx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQgKyBjaG9pY2UuaWQpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIChfZXJyKSB7XG5cdFx0Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgc2NoZW1hLCByZXR1cm4gZGVmYXVsdHNcblx0fVxuXG5cdHJldHVybiB7IHNlY3Rpb25lZCwgcmdiSWRzIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRklORCBUSEUgUkVBTCA1QSBQQVlMT0FEIElOREVYXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIGV4dHJhY3RTdFBheWxvYWRJbmRleChidWY6IEJ1ZmZlcik6IG51bWJlciB7XG5cdGNvbnN0IHNpZ0luZGV4ID0gYnVmLmluZGV4T2YoQnVmZmVyLmZyb20oJ1N0dWRpby1UJykpXG5cdGlmIChzaWdJbmRleCA8IDApIHRocm93IG5ldyBFcnJvcignTm8gU3R1ZGlvLVQgc2lnbmF0dXJlIGluIHBhY2tldCcpXG5cblx0Y29uc3QgcGF5bG9hZEluZGV4ID0gc2lnSW5kZXggKyA4XG5cdGlmIChidWZbcGF5bG9hZEluZGV4XSAhPT0gMHg1YSkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgMHg1QSBhZnRlciBTdHVkaW8tVCwgZm91bmQgJHtidWZbcGF5bG9hZEluZGV4XS50b1N0cmluZygxNil9YClcblx0fVxuXG5cdHJldHVybiBwYXlsb2FkSW5kZXhcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRkxBVCBQQVJTRVJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gcGFyc2VGbGF0SWRWYWxTZXF1ZW5jZShibG9jazogQnVmZmVyLCByZ2JJZHM6IFNldDxudW1iZXI+ID0gbmV3IFNldCgpKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0bGV0IHAgPSAwXG5cdGNvbnN0IG91dDogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHR3aGlsZSAocCA8IGJsb2NrLmxlbmd0aCkge1xuXHRcdGNvbnN0IGlkID0gYmxvY2tbcF1cblx0XHRpZiAocCArIDEgPj0gYmxvY2subGVuZ3RoKSBicmVha1xuXG5cdFx0Ly8gUkdCIGNhc2UgLSBjaGVjayBpZiB0aGlzIElEIGlzIGEga25vd24gY29sb3JwaWNrZXJcblx0XHRpZiAocmdiSWRzLmhhcyhpZCkgJiYgcCArIDMgPCBibG9jay5sZW5ndGgpIHtcblx0XHRcdG91dC5wdXNoKHtcblx0XHRcdFx0Y21kX2lkOiBDTURfREVWX1NQRUMsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHR2YWx1ZUJ5dGVzOiBbYmxvY2tbcCArIDFdLCBibG9ja1twICsgMl0sIGJsb2NrW3AgKyAzXV0sXG5cdFx0XHR9KVxuXHRcdFx0cCArPSA0XG5cdFx0XHRjb250aW51ZVxuXHRcdH1cblxuXHRcdG91dC5wdXNoKHsgY21kX2lkOiBDTURfREVWX1NQRUMsIGlkLCB2YWx1ZUJ5dGVzOiBbYmxvY2tbcCArIDFdXSB9KVxuXHRcdHAgKz0gMlxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZjogQnVmZmVyLCBtb2RlbDogc3RyaW5nKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgYSBnZXRBbGxTZXR0aW5ncyByZXBseScpXG5cdH1cblxuXHRjb25zdCBibG9ja0xlbiA9IGJ1ZltpZHggKyAyXVxuXHRjb25zdCBzdGFydCA9IGlkeCArIDNcblx0Y29uc3QgZW5kID0gc3RhcnQgKyBibG9ja0xlblxuXHRpZiAoZW5kID4gYnVmLmxlbmd0aCkgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGJsb2NrIGxlbmd0aCcpXG5cblx0Y29uc3QgeyByZ2JJZHMgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gcGFyc2VGbGF0SWRWYWxTZXF1ZW5jZShidWYuc3ViYXJyYXkoc3RhcnQsIGVuZCksIHJnYklkcylcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0VDVElPTkVEIFBBUlNFUlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmOiBCdWZmZXIsIG1vZGVsOiBzdHJpbmcpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ05vdCBhIGdldEFsbFNldHRpbmdzIHJlcGx5Jylcblx0fVxuXG5cdC8vIENNRF9HRVRfQUxMX1NFVFRJTkdTIGhhcyBhIHRvdGFsLWxlbmd0aCBieXRlIGF0IGlkeCsyIGJlZm9yZSB0aGUgc2VjdGlvbnM7IENNRF9TRVRUSU5HU19QVVNIIGRvZXMgbm90LlxuXHRsZXQgcCA9IGNtZElkID09PSBDTURfR0VUX0FMTF9TRVRUSU5HUyA/IGlkeCArIDMgOiBpZHggKyAyXG5cdGNvbnN0IGVuZCA9IGJ1Zi5sZW5ndGggLSAxXG5cdGNvbnN0IG91dDogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHQvLyBHZXQgUkdCIElEcyBmb3IgdGhpcyBtb2RlbFxuXHRjb25zdCB7IHJnYklkcyB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cblx0Ly8gQ29tbWFuZCBJRHMgdGhhdCBpbmNsdWRlIGEgYnVzQ2ggYnl0ZSBpbiB0aGVpciBzZWN0aW9uIHN0cnVjdHVyZSxcblx0Ly8gZm9sbG93ZWQgYnkgYSBkYXRhTGVuIGJ5dGUgYW5kIHRoZW4gaWQ6dmFsIHBhaXJzLlxuXHRjb25zdCBjb21tYW5kc1dpdGhCdXNDaCA9IFtDTURfQlVTX1NFVCwgQ01EX01JQ19QUkVfQlVTLCBDTURfQ0hBTk5FTF1cblxuXHQvLyBDb21tYW5kIElEcyB0aGF0IGluY2x1ZGUgYSBidXNDaCBieXRlIGJ1dCBzdG9yZSByYXcgcG9zaXRpb25hbCB2YWx1ZSBieXRlc1xuXHQvLyByYXRoZXIgdGhhbiBpZDp2YWwgcGFpcnMgKG5vIGRhdGFMZW4gYnl0ZSwgbm8gc2V0dGluZyBJRHMpLlxuXHQvLyBGb3JtYXQ6IFtjbWRMZW5dIFtjbWRJZF0gW2J1c0NoXSBbdmFsMF0gW3ZhbDFdIC4uLlxuXHRjb25zdCBjb21tYW5kc1Jhd1ZhbHVlID0gW0NNRF9NSUNfUFJFXSAvLyBjbWQ9MHgwMlxuXG5cdHdoaWxlIChwICsgMiA8IGVuZCkge1xuXHRcdGNvbnN0IGNtZExlbiA9IGJ1ZltwXVxuXHRcdGNvbnN0IHNlY3Rpb25DbWRJZCA9IGJ1ZltwICsgMV1cblxuXHRcdGNvbnN0IHNlY3Rpb25FbmQgPSBwICsgMSArIGNtZExlblxuXHRcdGlmIChzZWN0aW9uRW5kID4gZW5kKSBicmVha1xuXG5cdFx0Y29uc3QgaGFzQnVzQ2ggPSBjb21tYW5kc1dpdGhCdXNDaC5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cdFx0Y29uc3QgaXNSYXdWYWx1ZSA9IGNvbW1hbmRzUmF3VmFsdWUuaW5jbHVkZXMoc2VjdGlvbkNtZElkKVxuXG5cdFx0bGV0IGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWRcblx0XHRsZXQgZGF0YUxlbjogbnVtYmVyXG5cdFx0bGV0IHE6IG51bWJlclxuXG5cdFx0aWYgKGlzUmF3VmFsdWUpIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gLi4uXG5cdFx0XHQvLyBFbWl0IGVhY2ggdmFsdWUgYnl0ZSBhcyBhIHNlcGFyYXRlIFBhcnNlZFNldHRpbmcgd2l0aCBwb3NpdGlvbmFsIGlkLlxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRjb25zdCByYXdCeXRlcyA9IGJ1Zi5zdWJhcnJheShwICsgMywgc2VjdGlvbkVuZClcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgcmF3Qnl0ZXMubGVuZ3RoOyBpKyspIHtcblx0XHRcdFx0b3V0LnB1c2goeyBjbWRfaWQ6IHNlY3Rpb25DbWRJZCwgaWQ6IGksIGJ1c0NoLCB2YWx1ZUJ5dGVzOiBbcmF3Qnl0ZXNbaV1dIH0pXG5cdFx0XHR9XG5cdFx0XHRwID0gc2VjdGlvbkVuZFxuXHRcdFx0Y29udGludWVcblx0XHR9IGVsc2UgaWYgKGhhc0J1c0NoKSB7XG5cdFx0XHQvLyBTdHJ1Y3R1cmU6IFtjbWRMZW5dIFtjbWRJZF0gW2J1c0NoXSBbZGF0YUxlbl0gW2lkOnZhbCBwYWlyc11cblx0XHRcdGJ1c0NoID0gYnVmW3AgKyAyXVxuXHRcdFx0ZGF0YUxlbiA9IGJ1ZltwICsgM11cblx0XHRcdHEgPSBwICsgNFxuXHRcdH0gZWxzZSB7XG5cdFx0XHQvLyBTdHJ1Y3R1cmU6IFtjbWRMZW5dIFtjbWRJZF0gW2RhdGFMZW5dIFtpZDp2YWwgcGFpcnNdXG5cdFx0XHRkYXRhTGVuID0gYnVmW3AgKyAyXVxuXHRcdFx0cSA9IHAgKyAzXG5cdFx0fVxuXG5cdFx0Y29uc3QgcUVuZCA9IHEgKyBkYXRhTGVuXG5cdFx0Y29uc3QgcVN0YXJ0ID0gcVxuXG5cdFx0d2hpbGUgKHEgKyAxIDwgcUVuZCkge1xuXHRcdFx0Y29uc3QgaWQgPSBidWZbcV1cblx0XHRcdGxldCB2YWx1ZUJ5dGVzOiBudW1iZXJbXVxuXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIElEIGlzIGFuIFJHQiBjb2xvcnBpY2tlciAobmVlZHMgMyBieXRlcylcblx0XHRcdGlmIChyZ2JJZHMuaGFzKGlkKSAmJiBxICsgMyA8IHFFbmQpIHtcblx0XHRcdFx0dmFsdWVCeXRlcyA9IFtidWZbcSArIDFdLCBidWZbcSArIDJdLCBidWZbcSArIDNdXVxuXHRcdFx0XHRxICs9IDRcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXV1cblx0XHRcdFx0cSArPSAyXG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHNldHRpbmc6IFBhcnNlZFNldHRpbmcgPSB7XG5cdFx0XHRcdGNtZF9pZDogc2VjdGlvbkNtZElkLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdHNldHRpbmcuYnVzQ2ggPSBidXNDaFxuXHRcdFx0fVxuXHRcdFx0b3V0LnB1c2goc2V0dGluZylcblx0XHR9XG5cblx0XHQvLyBQb3NpdGlvbmFsIGZhbGxiYWNrOiBpZiB0aGUgYnl0ZSB3ZSByZWFkIGFzIGRhdGFMZW4gd2FzIDB4MDAgYnV0IHRoZSBzZWN0aW9uXG5cdFx0Ly8gc3RpbGwgY29udGFpbnMgZGF0YSBieXRlcywgdGhpcyBzZWN0aW9uIGxpa2VseSB1c2VzIGEgbm8tZGF0YUxlbiBmb3JtYXQgd2hlcmVcblx0XHQvLyBlYWNoIGJ5dGUgYWZ0ZXIgY21kSWQgaXMgYSByYXcgdmFsdWUgYXQgYSBmaXhlZCBwb3NpdGlvbiAocG9zaXRpb24gPSBpZCkuXG5cdFx0Ly8gUmUtcGFyc2UgZnJvbSBwKzIgKHJpZ2h0IGFmdGVyIGNtZElkKSwgdHJlYXRpbmcgdGhlIFwiZGF0YUxlblwiIGJ5dGUgYXMgaWQ9MC5cblx0XHQvLyBPbmx5IGZpcmUgaWYgbm8gYnl0ZXMgd2VyZSBjb25zdW1lZCBieSB0aGUgbWFpbiBsb29wIChxID09PSBxU3RhcnQpLCB0byBhdm9pZFxuXHRcdC8vIHJlLXBhcnNpbmcgYnl0ZXMgdGhhdCB3ZXJlIGFscmVhZHkgc3VjY2Vzc2Z1bGx5IHBhcnNlZC5cblx0XHRpZiAocSA9PT0gcVN0YXJ0ICYmIHNlY3Rpb25FbmQgPiBwICsgMykge1xuXHRcdFx0bGV0IHBvcyA9IGhhc0J1c0NoID8gcCArIDMgOiBwICsgMiAvLyBza2lwIGNtZElkIChhbmQgYnVzQ2ggaWYgcHJlc2VudClcblx0XHRcdGxldCBwb3NJZCA9IDBcblx0XHRcdHdoaWxlIChwb3MgPCBzZWN0aW9uRW5kKSB7XG5cdFx0XHRcdGNvbnN0IHNldHRpbmc6IFBhcnNlZFNldHRpbmcgPSB7IGNtZF9pZDogc2VjdGlvbkNtZElkLCBpZDogcG9zSWQrKywgdmFsdWVCeXRlczogW2J1Zltwb3MrK11dIH1cblx0XHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHNldHRpbmcuYnVzQ2ggPSBidXNDaFxuXHRcdFx0XHRvdXQucHVzaChzZXR0aW5nKVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHAgPSBzZWN0aW9uRW5kXG5cdH1cblxuXHRyZXR1cm4gb3V0XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEdFTkVSSUMgU0VUVElOR1MgUkVTUE9OU0UgUEFSU0VSICgweDBhIGdldC1hbGwgKyAweDBiIHVuc29saWNpdGVkIHB1c2gpXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogUGFyc2VzIGFueSBmdWxsIHNldHRpbmdzIGJsb2NrIHJlZ2FyZGxlc3Mgb2Ygd2hldGhlciB0aGUgY21kSWQgaXMgMHgwYVxuICogKHJlc3BvbnNlIHRvIEdldCBBbGwgU2V0dGluZ3MpIG9yIDB4MGIgKHVuc29saWNpdGVkIHB1c2ggYWZ0ZXIgYSBzZXQpLlxuICogQm90aCB1c2UgdGhlIHNhbWUgc2VjdGlvbmVkIG9yIGZsYXQgYmxvY2sgbGF5b3V0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VTZXR0aW5nc1Jlc3BvbnNlKG1vZGVsOiBzdHJpbmcsIGJ1ZjogQnVmZmVyKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKGBOb3QgYSBzZXR0aW5ncyBibG9jayAoY21kSWQ9MHgke2NtZElkLnRvU3RyaW5nKDE2KX0pYClcblx0fVxuXHRjb25zdCB7IHNlY3Rpb25lZCB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cdHJldHVybiBzZWN0aW9uZWQgPyBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKSA6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxufVxuXG4vKipcbiAqIEZvcm1hdHMgYSBzaW5nbGUgcGFyc2VkIHNldHRpbmcgaW50byBhIGh1bWFuLXJlYWRhYmxlIHN0cmluZyB1c2luZyBhY3Rpb25cbiAqIGRlZmluaXRpb25zIGZyb20gdGhlIGRldmljZSBKU09OLiBGYWxscyBiYWNrIHRvIGhleCBJRHMgd2hlbiB1bmtub3duLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UGFyc2VkU2V0dGluZyhzZXR0aW5nOiBQYXJzZWRTZXR0aW5nLCBhY3Rpb25zOiBTdEFjdGlvbltdKTogc3RyaW5nIHtcblx0Ly8gVHJ5IGV4YWN0IG1hdGNoIGZpcnN0XG5cdGxldCBhY3Rpb24gPSBhY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBzZXR0aW5nLmNtZF9pZCAmJiBhLmlkID09PSBzZXR0aW5nLmlkKVxuXG5cdC8vIElmIG5vIGV4YWN0IG1hdGNoIGFuZCBpZCA+IGJhc2UgaWQsIHRyeSB0byBmaW5kIGFjdGlvbiB3aXRoIGlkQWRkIG9wdGlvblxuXHQvLyBUaGlzIGhhbmRsZXMgY2FzZXMgbGlrZSBDTURfSEVBRFBIT05FICgweDA1LCBlLmcuIFBob25lcyBSb3V0aW5nKSBhbmRcblx0Ly8gQ01EX0JVVFRPTl9NT0RFICgweDA3LCBlLmcuIEJ1dHRvbnMpIHdoZXJlIGlkIDAtMyByZXByZXNlbnRzIGNoYW5uZWxzIDEtNFxuXHRpZiAoIWFjdGlvbikge1xuXHRcdGNvbnN0IGJhc2VBY3Rpb24gPSBhY3Rpb25zLmZpbmQoKGEpID0+IHtcblx0XHRcdGlmIChhLmNtZF9pZCAhPT0gc2V0dGluZy5jbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBhY3Rpb24gaGFzIGFuIGlkQWRkIG9wdGlvbiAoaW5kaWNhdGluZyBjaGFubmVsIHNlbGVjdGlvbilcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYS5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhlIHNldHRpbmcuaWQgb2Zmc2V0IG1hdGNoZXMgb25lIG9mIHRoZSBpZEFkZCBjaG9pY2UgSURzXG5cdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZy5pZCAtIGEuaWRcblx0XHRcdHJldHVybiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGMpID0+IGMuaWQgPT09IGNoYW5uZWxPZmZzZXQpXG5cdFx0fSlcblx0XHRpZiAoYmFzZUFjdGlvbikge1xuXHRcdFx0YWN0aW9uID0gYmFzZUFjdGlvblxuXHRcdH1cblx0fVxuXG5cdGNvbnN0IGNtZEhleCA9IHRvSGV4KHNldHRpbmcuY21kX2lkKVxuXHRjb25zdCBpZEhleCA9IHRvSGV4KHNldHRpbmcuaWQpXG5cdGNvbnN0IHZhbEhleCA9IGJ5dGVzVG9IZXgoc2V0dGluZy52YWx1ZUJ5dGVzKVxuXHRjb25zdCB2YWxEZWMgPVxuXHRcdHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdD8gZm9ybWF0UmdiQ29sb3Ioc2V0dGluZy52YWx1ZUJ5dGVzWzBdLCBzZXR0aW5nLnZhbHVlQnl0ZXNbMV0sIHNldHRpbmcudmFsdWVCeXRlc1syXSlcblx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMVxuXHRcdFx0XHQ/IHNldHRpbmcudmFsdWVCeXRlc1swXVxuXHRcdFx0XHQ6IHNldHRpbmcudmFsdWVCeXRlcy5qb2luKCcsJylcblxuXHQvLyBCdWlsZCB0aGUgcHJlZml4OiBjbWQ6MHgxMiBjaDowIGlkOjB4MDEgdmFsOjB4MTQgKGNoIG9ubHkgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2gpXG5cdGNvbnN0IGJ1c0NoU3RyID0gc2V0dGluZy5idXNDaCAhPT0gdW5kZWZpbmVkID8gYCBjaDoke3NldHRpbmcuYnVzQ2h9YCA6ICcnXG5cdGNvbnN0IHByZWZpeCA9IGBjbWQ6JHtjbWRIZXh9JHtidXNDaFN0cn0gaWQ6JHtpZEhleH0gdmFsOiR7dmFsSGV4fWBcblxuXHQvLyBJZiB3ZSBoYXZlIGFuIGFjdGlvbiB3aXRoIGEgbmFtZSBhbmQgY2hvaWNlIGxhYmVsLCB1c2UgaXRcblx0aWYgKGFjdGlvbikge1xuXHRcdGxldCBuYW1lID0gYWN0aW9uLm5hbWVcblxuXHRcdC8vIElmIHNldHRpbmcgaGFzIGJ1c0NoLCBhZGQgY2hhbm5lbCBpbmZvIHRvIG5hbWVcblx0XHRpZiAoc2V0dGluZy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRuYW1lID0gYCR7bmFtZX0gQ2gke3NldHRpbmcuYnVzQ2ggKyAxfWBcblx0XHR9XG5cdFx0Ly8gT3RoZXJ3aXNlLCBpZiB0aGlzIGFjdGlvbiBoYXMgaWRBZGQsIGluY2x1ZGUgdGhlIGlkQWRkIGxhYmVsXG5cdFx0ZWxzZSB7XG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmIChpZEFkZE9wdGlvbj8uY2hvaWNlcykge1xuXHRcdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZy5pZCAtIGFjdGlvbi5pZFxuXHRcdFx0XHRjb25zdCBpZEFkZENob2ljZSA9IGlkQWRkT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHRcdFx0aWYgKGlkQWRkQ2hvaWNlKSB7XG5cdFx0XHRcdFx0bmFtZSA9IGAke25hbWV9ICR7aWRBZGRDaG9pY2UubGFiZWx9YFxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gTG9vayBmb3IgdGhlIHZhbHVlIG9wdGlvbiAobm90IGJ1c0NoIG9yIGlkQWRkKVxuXHRcdGNvbnN0IHZhbHVlT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAndmFsdWUnKVxuXHRcdGlmICh2YWx1ZU9wdGlvbj8uY2hvaWNlcyAmJiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRjb25zdCBjaG9pY2UgPSB2YWx1ZU9wdGlvbi5jaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHNldHRpbmcudmFsdWVCeXRlc1swXSlcblx0XHRcdGlmIChjaG9pY2UpIHtcblx0XHRcdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke2Nob2ljZS5sYWJlbH0gKCR7dmFsRGVjfSlgXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBgJHtwcmVmaXh9IHwgJHtuYW1lfTogJHt2YWxEZWN9YFxuXHR9XG5cblx0Ly8gTm8gYWN0aW9uIGZvdW5kIC0ganVzdCBzaG93IHRoZSByYXcgdmFsdWVzXG5cdHJldHVybiBgJHtwcmVmaXh9IHwgVW5rbm93biBTZXR0aW5nYFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBQQVJTRVIgRElTUEFUQ0ggV0lUSCBBVVRPLURFVEVDVElPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBnZXRBbGxTZXR0aW5ncyByZXNwb25zZSB3aXRoIGF1dG9tYXRpYyBmb3JtYXQgZGV0ZWN0aW9uLlxuICpcbiAqIFN0cmF0ZWd5OlxuICogMS4gSWYgbW9kZWwgaGFzIGV4cGxpY2l0IFwic2VjdGlvbmVkXCIgcHJvcGVydHksIHVzZSB0aGF0XG4gKiAyLiBPdGhlcndpc2UsIHRyeSBGTEFUIHBhcnNlciBmaXJzdCAoaXQncyBzaW1wbGVyKVxuICogMy4gSWYgRkxBVCByZXR1cm5zIDAgc2V0dGluZ3MsIHRyeSBTRUNUSU9ORUQgcGFyc2VyXG4gKiA0LiBVc2Ugd2hpY2hldmVyIHBhcnNlciByZXR1cm5zIG1vcmUgc2V0dGluZ3NcbiAqXG4gKiBAcmV0dXJucyB7c2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGJvb2xlYW4gfCBudWxsfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24oXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGJ1ZjogQnVmZmVyLFxuKTogeyBzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdOyBkZXRlY3RlZFNlY3Rpb25lZDogYm9vbGVhbiB8IG51bGwgfSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0Y29uc3QgZGVjbGFyZWRTZWN0aW9uZWQgPSBzY2hlbWE/LnNlY3Rpb25lZFxuXG5cdC8vIElmIGV4cGxpY2l0bHkgZGVjbGFyZWQgaW4gSlNPTiwgdXNlIHRoYXRcblx0aWYgKGRlY2xhcmVkU2VjdGlvbmVkICE9PSB1bmRlZmluZWQpIHtcblx0XHRjb25zdCBzZXR0aW5ncyA9IGRlY2xhcmVkU2VjdGlvbmVkXG5cdFx0XHQ/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG5cdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxuXHRcdHJldHVybiB7IHNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9IC8vIG51bGwgPSB1c2VkIGRlY2xhcmVkIHZhbHVlXG5cdH1cblxuXHQvLyBObyBkZWNsYXJhdGlvbiAtIHRyeSBib3RoIHBhcnNlcnMgYW5kIHBpY2sgdGhlIGJlc3Qgb25lXG5cdGxldCBmbGF0U2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cdGxldCBzZWN0aW9uZWRTZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHR0cnkge1xuXHRcdGZsYXRTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBGbGF0IHBhcnNlciBmYWlsZWQ6ICR7ZX1gKVxuXHR9XG5cblx0dHJ5IHtcblx0XHRzZWN0aW9uZWRTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZGVidWcoYFNlY3Rpb25lZCBwYXJzZXIgZmFpbGVkOiAke2V9YClcblx0fVxuXG5cdC8vIFBpY2sgdGhlIHBhcnNlciB0aGF0IHJldHVybmVkIG1vcmUgc2V0dGluZ3Ncblx0aWYgKHNlY3Rpb25lZFNldHRpbmdzLmxlbmd0aCA+IGZsYXRTZXR0aW5ncy5sZW5ndGgpIHtcblx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBTRUNUSU9ORUQgZm9ybWF0IChzZWN0aW9uZWQ9JHtzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGh9IHZzIGZsYXQ9JHtmbGF0U2V0dGluZ3MubGVuZ3RofSlgKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBzZWN0aW9uZWRTZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IHRydWUgfVxuXHR9IGVsc2UgaWYgKGZsYXRTZXR0aW5ncy5sZW5ndGggPiAwKSB7XG5cdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgRkxBVCBmb3JtYXQgKGZsYXQ9JHtmbGF0U2V0dGluZ3MubGVuZ3RofSB2cyBzZWN0aW9uZWQ9JHtzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGh9KWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IGZsYXRTZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGZhbHNlIH1cblx0fSBlbHNlIHtcblx0XHQvLyBCb3RoIHBhcnNlcnMgcmV0dXJuZWQgMCBzZXR0aW5nc1xuXHRcdGxvZ2dlci53YXJuKGBXYXJuaW5nOiBCb3RoIHBhcnNlcnMgcmV0dXJuZWQgMCBzZXR0aW5ncyBmb3IgbW9kZWwgJHttb2RlbH1gKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfVxuXHR9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwobW9kZWw6IHN0cmluZywgYnVmOiBCdWZmZXIpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCB7IHNlY3Rpb25lZCB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cdHJldHVybiBzZWN0aW9uZWQgPyBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKSA6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxufVxuXG4vKiBcdTI3MDUgYmFja3dhcmQtY29tcGF0aWJsZSBleHBvcnQgKi9cbmV4cG9ydCBjb25zdCBwYXJzZUdldEFsbFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFZBTFVFIFx1MjE5MiBPUFRJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXM6IG51bWJlcltdKTogU3RBY3Rpb25PcHRpb24ge1xuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdudW1iZXInLCBkZWZhdWx0OiB2YWx1ZUJ5dGVzWzBdIH1cblx0fVxuXG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMykge1xuXHRcdGNvbnN0IFtyLCBnLCBiXSA9IHZhbHVlQnl0ZXNcblx0XHRyZXR1cm4ge1xuXHRcdFx0aWQ6ICd2YWx1ZScsXG5cdFx0XHRsYWJlbDogJ0NvbG9yJyxcblx0XHRcdHR5cGU6ICdjb2xvcnBpY2tlcicsXG5cdFx0XHRkZWZhdWx0OiBmb3JtYXRSZ2JDb2xvcihyLCBnLCBiKSxcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdyYXcnLCBkZWZhdWx0OiBbLi4udmFsdWVCeXRlc10gfVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTTUFSVCBKU09OIFVQREFURVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKFxuXHRtb2RlbEpzb246IFN0TW9kZWxKc29uLFxuXHRwYXJzZWQ6IFBhcnNlZFNldHRpbmdbXSxcblx0YWxsTW9kZWxzOiBSZWNvcmQ8c3RyaW5nLCBTdE1vZGVsSnNvbj4sXG4pOiBTdE1vZGVsSnNvbiB7XG5cdGNvbnN0IG91dCA9IHN0cnVjdHVyZWRDbG9uZShtb2RlbEpzb24pXG5cblx0Ly8gRW5zdXJlIGNtZFNjaGVtYSBhcnJheSBleGlzdHNcblx0aWYgKCFvdXQuY21kU2NoZW1hKSB7XG5cdFx0b3V0LmNtZFNjaGVtYSA9IFtdXG5cdH1cblxuXHQvLyBTb3J0IG90aGVyIG1vZGVscyBieSBudW1lcmljIGRpc3RhbmNlIHRvIGN1cnJlbnQgbW9kZWxcblx0Y29uc3QgY2FuZGlkYXRlcyA9IE9iamVjdC52YWx1ZXMoYWxsTW9kZWxzKVxuXHRcdC5maWx0ZXIoKG0pID0+IG0ubW9kZWwgIT09IG1vZGVsSnNvbi5tb2RlbCkgLy8gZXhjbHVkZSBzZWxmXG5cdFx0LnNvcnQoKGEsIGIpID0+IG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBhLm1vZGVsKSAtIG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBiLm1vZGVsKSlcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRpbmcgbW9kZWw6ICR7bW9kZWxKc29uLm1vZGVsfWApXG5cdGxvZ2dlci5kZWJ1ZyhgQ2FuZGlkYXRlcyBmb3IgaW5mZXJlbmNlOiAke2NhbmRpZGF0ZXMubWFwKChjKSA9PiBjLm1vZGVsKS5qb2luKCcsICcpfWApXG5cblx0Ly8gUHJlLXNjYW46IGZvciBlYWNoIGNhbmRpZGF0ZSBpZEFkZCBiYXNlIGVudHJ5LCBmaW5kIHRoZSBtYXhpbXVtIHNlcXVlbnRpYWxcblx0Ly8gb2Zmc2V0IHRoZSBwYWNrZXQgY29udGFpbnMgKGV2ZW4gYmV5b25kIHdoYXQgdGhlIHJlZmVyZW5jZSBtb2RlbCBrbm93cykuXG5cdC8vIEtleTogYCR7Y21kX2lkfV8ke2Jhc2VfaWR9YCwgdmFsdWU6IG1heCBzZXF1ZW50aWFsIG9mZnNldCBzZWVuIGluIHBhcnNlZCBkYXRhLlxuXHRjb25zdCBpZEFkZERlZmVyUmFuZ2VzID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKVxuXHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdGZvciAoY29uc3QgYmFzZUVudHJ5IG9mIGMuY21kU2NoZW1hID8/IFtdKSB7XG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGJhc2VFbnRyeS5vcHRpb25zPy5maW5kKChvOiBhbnkpID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzKSBjb250aW51ZVxuXHRcdFx0Y29uc3QgYmFzZUlkID0gYmFzZUVudHJ5LmlkXG5cdFx0XHRjb25zdCBjbWRJZCA9IGJhc2VFbnRyeS5jbWRfaWRcblx0XHRcdGNvbnN0IGtleSA9IGAke2NtZElkfV8ke2Jhc2VJZH1gXG5cdFx0XHRpZiAoaWRBZGREZWZlclJhbmdlcy5oYXMoa2V5KSkgY29udGludWVcblx0XHRcdC8vIEZpbmQgdGhlIG1heCBzZXF1ZW50aWFsIG9mZnNldCBwcmVzZW50IGluIHRoZSBwYXJzZWQgcGFja2V0IGZvciB0aGlzIGJhc2Vcblx0XHRcdGNvbnN0IHBhcnNlZE9mZnNldHMgPSBwYXJzZWRcblx0XHRcdFx0LmZpbHRlcigocCkgPT4gcC5jbWRfaWQgPT09IGNtZElkICYmIHAuaWQgPiBiYXNlSWQpXG5cdFx0XHRcdC5tYXAoKHApID0+IHAuaWQgLSBiYXNlSWQpXG5cdFx0XHRcdC5zb3J0KChhLCBiKSA9PiBhIC0gYilcblx0XHRcdC8vIFdhbGsgZnJvbSAxIHVwd2FyZCBcdTIwMTQgc3RvcCBhdCBmaXJzdCBnYXBcblx0XHRcdGxldCBtYXhTZXEgPSAwXG5cdFx0XHRmb3IgKGNvbnN0IG9mZiBvZiBwYXJzZWRPZmZzZXRzKSB7XG5cdFx0XHRcdGlmIChvZmYgPT09IG1heFNlcSArIDEpIG1heFNlcSA9IG9mZlxuXHRcdFx0XHRlbHNlIGlmIChvZmYgPiBtYXhTZXEgKyAxKSBicmVha1xuXHRcdFx0fVxuXHRcdFx0aWYgKG1heFNlcSA+IDApIHtcblx0XHRcdFx0aWRBZGREZWZlclJhbmdlcy5zZXQoa2V5LCBtYXhTZXEpXG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgaWRBZGQgZGVmZXIgcmFuZ2UgZm9yIGNtZF9pZD0ke3RvSGV4KGNtZElkKX0gYmFzZV9pZD0ke3RvSGV4KGJhc2VJZCl9OiBvZmZzZXRzIDFcdTIwMTMke21heFNlcX1gKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdC8vIFByZS1jb21wdXRlIHRoZSBzZXQgb2YgYWxsIGJ1c0NoIHZhbHVlcyBzZWVuIHBlciAoY21kX2lkLCBpZCkgcGFpciBhY3Jvc3MgdGhlIGZ1bGxcblx0Ly8gcGFyc2VkIHJlc3BvbnNlIFx1MjAxNCB1c2VkIGxhdGVyIHRvIGRlY2lkZSBmaXhlZCB2cy4gc2VsZWN0YWJsZSBidXNDaC5cblx0Y29uc3QgYnVzQ2hTZWVuID0gbmV3IE1hcDxzdHJpbmcsIFNldDxudW1iZXI+PigpXG5cdGZvciAoY29uc3QgeyBjbWRfaWQsIGlkLCBidXNDaCB9IG9mIHBhcnNlZCkge1xuXHRcdGlmIChidXNDaCA9PT0gdW5kZWZpbmVkKSBjb250aW51ZVxuXHRcdGNvbnN0IGtleSA9IGAke2NtZF9pZH1fJHtpZH1gXG5cdFx0aWYgKCFidXNDaFNlZW4uaGFzKGtleSkpIGJ1c0NoU2Vlbi5zZXQoa2V5LCBuZXcgU2V0KCkpXG5cdFx0YnVzQ2hTZWVuLmdldChrZXkpIS5hZGQoYnVzQ2gpXG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFBBU1MgMTogcmVzb2x2ZSBlYWNoIHBhcnNlZCBlbnRyeSBcdTIwMTQgZXhhY3QgbWF0Y2gsIGluZmVycmVkLFxuXHQvLyBpZEFkZC1mb2xkIChvZmZzZXQgaW50byBhbiBhbHJlYWR5LWFkZGVkIGJhc2UgZW50cnkpLCBvciB1bmtub3duXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQsIGJ1c0NoLCB2YWx1ZUJ5dGVzIH0gb2YgcGFyc2VkKSB7XG5cdFx0Ly8gMWEuIEV4YWN0IG1hdGNoIGFscmVhZHkgaW4gb3V0cHV0IHNjaGVtYSBcdTIwMTQganVzdCByZWZyZXNoIHRoZSBkZWZhdWx0XG5cdFx0Y29uc3QgZXhpc3RpbmdFeGFjdCA9IG91dC5jbWRTY2hlbWEuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZClcblx0XHRpZiAoZXhpc3RpbmdFeGFjdCkge1xuXHRcdFx0Y29uc3Qgb3B0ID0gZXhpc3RpbmdFeGFjdC5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKVxuXHRcdFx0aWYgKG9wdCkgb3B0LmRlZmF1bHQgPSB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcykuZGVmYXVsdFxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHQvLyAxYi4gQ2hlY2sgaWYgdGhpcyBpZCBmb2xkcyBpbnRvIGFuIGFscmVhZHktYWRkZWQgYmFzZSBlbnRyeSB2aWEgaWRBZGQuXG5cdFx0Ly8gICAgIEdhdGU6IHRoZSBvZmZzZXQgbXVzdCBhY3R1YWxseSBleGlzdCBpbiB0aGUgcmVmZXJlbmNlIG1vZGVsJ3MgaWRBZGQgY2hvaWNlc1xuXHRcdC8vICAgICB0byBhdm9pZCBzd2FsbG93aW5nIHVucmVsYXRlZCBzYW1lLWNtZF9pZCBlbnRyaWVzIChlLmcuIFNpZGV0b25lIGF0IGlkPTIxKS5cblx0XHRjb25zdCBpZEFkZEJhc2UgPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IHtcblx0XHRcdGlmIChhLmNtZF9pZCAhPT0gY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gYS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHRpZiAoaWQgPD0gYS5pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGEuaWRcblx0XHRcdC8vIE9ubHkgZm9sZCBpZiBhIHJlZmVyZW5jZSBtb2RlbCBleHBsaWNpdGx5IGxpc3RzIHRoaXMgb2Zmc2V0IGluIGl0cyBpZEFkZCBjaG9pY2VzXG5cdFx0XHRyZXR1cm4gY2FuZGlkYXRlcy5zb21lKChjKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKHIpID0+IHIuY21kX2lkID09PSBjbWRfaWQgJiYgci5pZCA9PT0gYS5pZClcblx0XHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0cmV0dXJuIHJlZklkQWRkPy5jaG9pY2VzPy5zb21lKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdGlmIChpZEFkZEJhc2UpIHtcblx0XHRcdGNvbnN0IG9mZnNldCA9IGlkIC0gaWRBZGRCYXNlLmlkXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGlkQWRkQmFzZS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0Py5jaG9pY2VzICYmICFpZEFkZE9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KSkge1xuXHRcdFx0XHRsZXQgbGFiZWwgPSBgQ2hhbm5lbCAke29mZnNldCArIDF9YFxuXHRcdFx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWRBZGRCYXNlLmlkKVxuXHRcdFx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdFx0Y29uc3QgcmVmQ2hvaWNlID0gcmVmSWRBZGQ/LmNob2ljZXM/LmZpbmQoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0XHRcdFx0aWYgKHJlZkNob2ljZSkge1xuXHRcdFx0XHRcdFx0bGFiZWwgPSByZWZDaG9pY2UubGFiZWxcblx0XHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdGlkQWRkT3B0LmNob2ljZXMucHVzaCh7IGlkOiBvZmZzZXQsIGxhYmVsIH0pXG5cdFx0XHRcdGxvZ2dlci5pbmZvKFxuXHRcdFx0XHRcdGBGb2xkZWQgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGludG8gaWRBZGQgYmFzZSBpZD0ke3RvSGV4KGlkQWRkQmFzZS5pZCl9IGFzIG9mZnNldCAke29mZnNldH0gKFwiJHtsYWJlbH1cIilgLFxuXHRcdFx0XHQpXG5cdFx0XHR9XG5cdFx0XHRjb250aW51ZVxuXHRcdH1cblxuXHRcdC8vIDFjLiBObyBleGFjdCBtYXRjaCBcdTIwMTQgdHJ5IGluZmVyZW5jZSBmcm9tIGNhbmRpZGF0ZSBtb2RlbHNcblx0XHRsZXQgYWN0aW9uOiBTdEFjdGlvbiB8IHVuZGVmaW5lZFxuXG5cdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdGNvbnN0IG1hdGNoID0gYy5jbWRTY2hlbWE/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0XHRpZiAobWF0Y2gpIHtcblx0XHRcdFx0YWN0aW9uID0gc3RydWN0dXJlZENsb25lKG1hdGNoKVxuXHRcdFx0XHQvLyBTdHJpcCBhbnkgZXhpc3RpbmcgXCIoaW5mZXJyZWQgZnJvbSBNb2RlbCBYKVwiIHN1ZmZpeGVzIGJlZm9yZSBhZGRpbmcgb3VyIG93blxuXHRcdFx0XHRjb25zdCBiYXNlTmFtZSA9IG1hdGNoLm5hbWUucmVwbGFjZSgvXFxzKlxcKGluZmVycmVkIGZyb20gTW9kZWwgW14pXStcXCkvZywgJycpLnRyaW0oKVxuXHRcdFx0XHRhY3Rpb24ubmFtZSA9IGAke2Jhc2VOYW1lfSAoaW5mZXJyZWQgZnJvbSBNb2RlbCAke2MubW9kZWx9KWBcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEluZmVycmVkIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBmcm9tIE1vZGVsICR7Yy5tb2RlbH0gKGV4YWN0KWApXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ2hlY2sgaWYgdGhpcyBpZCBzaG91bGQgYmUgZGVmZXJyZWQgdG8gcGFzcyAyIFx1MjAxNFxuXHRcdC8vIGl0J3MgYSBzZXF1ZW50aWFsIGlkQWRkIG9mZnNldCBvZiBhIGtub3duIGNhbmRpZGF0ZSBiYXNlIGVudHJ5LlxuXHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRsZXQgc2hvdWxkRGVmZXIgPSBmYWxzZVxuXHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0Y29uc3QgYmFzZUVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4ge1xuXHRcdFx0XHRcdGlmIChhLmNtZF9pZCAhPT0gY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobzogYW55KSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdGlmIChpZCA8PSBhLmlkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGEuaWRcblx0XHRcdFx0XHRjb25zdCBtYXhTZXEgPSBpZEFkZERlZmVyUmFuZ2VzLmdldChgJHtjbWRfaWR9XyR7YS5pZH1gKSA/PyAwXG5cdFx0XHRcdFx0cmV0dXJuIG9mZnNldCA8PSBtYXhTZXFcblx0XHRcdFx0fSlcblx0XHRcdFx0aWYgKGJhc2VFbnRyeSkge1xuXHRcdFx0XHRcdHNob3VsZERlZmVyID0gdHJ1ZVxuXHRcdFx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0XHRcdGBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gaXMgYW4gaWRBZGQgb2Zmc2V0IG9mIGNhbmRpZGF0ZSBiYXNlIGlkPSR7dG9IZXgoYmFzZUVudHJ5LmlkKX0gXHUyMDE0IGRlZmVycmluZyB0byBwYXNzIDJgLFxuXHRcdFx0XHRcdClcblx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoc2hvdWxkRGVmZXIpIGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0Ly8gRmFsbGJhY2s6IHVua25vd24gc2V0dGluZ1xuXHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSB7XG5cdFx0XHRcdGNtZF9pZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdG5hbWU6IGBVbmtub3duIGNtZDoke3RvSGV4KGNtZF9pZCl9IGlkOiR7dG9IZXgoaWQpLnRvVXBwZXJDYXNlKCl9YCxcblx0XHRcdFx0b3B0aW9uczogW3ZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKV0sXG5cdFx0XHR9XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgYWN0aW9uLmJ1c0NoID0gYnVzQ2hcblx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgaW5mZXIgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEZpeCAxOiBidXNDaCBoYW5kbGluZyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIFN0cmlwIGFueSBpbmhlcml0ZWQgYnVzQ2ggb3B0aW9uIGZyb20gdGhlIGNhbmRpZGF0ZSBcdTIwMTQgd2UnbGwgcmUtZGVyaXZlXG5cdFx0XHQvLyBpdCBmcm9tIHdoYXQgdGhlIHBhY2tldCBhY3R1YWxseSByZXBvcnRlZCBmb3IgdGhpcyBkZXZpY2UuXG5cdFx0XHRhY3Rpb24ub3B0aW9ucyA9IGFjdGlvbi5vcHRpb25zPy5maWx0ZXIoKG8pID0+IG8uaWQgIT09ICdidXNDaCcpID8/IFtdXG5cdFx0XHRkZWxldGUgYWN0aW9uLmJ1c0NoXG5cblx0XHRcdGNvbnN0IHNlZW5CdXNDaFZhbHVlcyA9IGJ1c0NoU2Vlbi5nZXQoYCR7Y21kX2lkfV8ke2lkfWApXG5cdFx0XHRpZiAoc2VlbkJ1c0NoVmFsdWVzICYmIHNlZW5CdXNDaFZhbHVlcy5zaXplID4gMCkge1xuXHRcdFx0XHRjb25zdCBtYXhCdXNDaCA9IE1hdGgubWF4KC4uLnNlZW5CdXNDaFZhbHVlcylcblx0XHRcdFx0aWYgKG1heEJ1c0NoID09PSAwKSB7XG5cdFx0XHRcdFx0Ly8gT25seSBldmVyIHNhdyBidXNDaD0wIFx1MjE5MiBmaXhlZCBwcm9wZXJ0eSwgbm90IGFuIG9wdGlvblxuXHRcdFx0XHRcdGFjdGlvbi5idXNDaCA9IDBcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHQvLyBNdWx0aXBsZSBjaGFubmVscyBvYnNlcnZlZCBcdTIxOTIgc2VsZWN0YWJsZSBvcHRpb25cblx0XHRcdFx0XHRjb25zdCBidXNDaENob2ljZXMgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBtYXhCdXNDaCArIDEgfSwgKF8sIGkpID0+ICh7XG5cdFx0XHRcdFx0XHRpZDogaSxcblx0XHRcdFx0XHRcdGxhYmVsOiBgQ2hhbm5lbCAke2kgKyAxfWAsXG5cdFx0XHRcdFx0fSkpXG5cdFx0XHRcdFx0YWN0aW9uLm9wdGlvbnMudW5zaGlmdCh7XG5cdFx0XHRcdFx0XHRpZDogJ2J1c0NoJyxcblx0XHRcdFx0XHRcdGxhYmVsOiAnQ2hhbm5lbCcsXG5cdFx0XHRcdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0XHRcdFx0Y2hvaWNlczogYnVzQ2hDaG9pY2VzLFxuXHRcdFx0XHRcdFx0ZGVmYXVsdDogMCxcblx0XHRcdFx0XHR9IGFzIGFueSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgRml4IDI6IGRlZmF1bHQgbXVzdCBleGlzdCBpbiBjaG9pY2VzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gU2V0IHRoZSBkZWZhdWx0IHRvIHRoZSBvYnNlcnZlZCB2YWx1ZS4gSWYgdGhhdCB2YWx1ZSBpc24ndCBpbiB0aGVcblx0XHRcdC8vIGluaGVyaXRlZCBjaG9pY2VzIGxpc3QsIHRoZSBjaG9pY2VzIGFyZSBmcm9tIGEgc3RydWN0dXJhbGx5IGRpZmZlcmVudFxuXHRcdFx0Ly8gbW9kZWwgYW5kIGNhbid0IGJlIHRydXN0ZWQgXHUyMDE0IGRpc2NhcmQgdGhlbSBhbmQgZmFsbCBiYWNrIHRvIGEgcGxhaW4gbnVtYmVyLlxuXHRcdFx0Y29uc3Qgb2JzZXJ2ZWREZWZhdWx0ID0gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpLmRlZmF1bHRcblx0XHRcdGNvbnN0IHZhbHVlT3B0ID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdFx0XHRpZiAodmFsdWVPcHQpIHtcblx0XHRcdFx0aWYgKHZhbHVlT3B0LmNob2ljZXMgJiYgQXJyYXkuaXNBcnJheSh2YWx1ZU9wdC5jaG9pY2VzKSkge1xuXHRcdFx0XHRcdGNvbnN0IGluQ2hvaWNlcyA9IHZhbHVlT3B0LmNob2ljZXMuc29tZSgoYzogYW55KSA9PiBjLmlkID09PSBvYnNlcnZlZERlZmF1bHQpXG5cdFx0XHRcdFx0aWYgKCFpbkNob2ljZXMpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKFxuXHRcdFx0XHRcdFx0XHRgSW5mZXJyZWQgY2hvaWNlcyBmb3IgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGRvbid0IGNvbnRhaW4gb2JzZXJ2ZWQgdmFsdWUgJHtvYnNlcnZlZERlZmF1bHR9IFx1MjAxNCBkaXNjYXJkaW5nIGluaGVyaXRlZCBjaG9pY2VzYCxcblx0XHRcdFx0XHRcdClcblx0XHRcdFx0XHRcdC8vIEtlZXAgbGFiZWwvdG9vbHRpcCBidXQgZHJvcCBjaG9pY2VzLCBzd2l0Y2ggdG8gcGxhaW4gbnVtYmVyXG5cdFx0XHRcdFx0XHR2YWx1ZU9wdC50eXBlID0gJ251bWJlcidcblx0XHRcdFx0XHRcdGRlbGV0ZSAodmFsdWVPcHQgYXMgYW55KS5jaG9pY2VzXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHZhbHVlT3B0LmRlZmF1bHQgPSBvYnNlcnZlZERlZmF1bHRcblx0XHRcdH1cblx0XHR9XG5cblx0XHRvdXQuY21kU2NoZW1hLnB1c2goYWN0aW9uKVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBQQVNTIDI6IGZvbGQgYW55IGRlZmVycmVkIGlkQWRkIG9mZnNldHMgd2hvc2UgYmFzZSBlbnRyeVxuXHQvLyBpcyBub3cgcHJlc2VudCBpbiB0aGUgb3V0cHV0IHNjaGVtYS5cblx0Ly8gR2F0ZTogdGhlIG9mZnNldCBtdXN0IGVpdGhlciBleGlzdCBpbiBhIHJlZmVyZW5jZSBtb2RlbCdzIGNob2ljZXMsXG5cdC8vIE9SIHRoZSBiYXNlIGVudHJ5IGl0c2VsZiB3YXMgaW5mZXJyZWQgKGhhcyBpZEFkZCkgYW5kIHRoZSBvZmZzZXRcblx0Ly8gY29udGludWVzIHNlcXVlbnRpYWxseSBiZXlvbmQgdGhlIHJlZmVyZW5jZSBtb2RlbCdzIGtub3duIHJhbmdlLlxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdGZvciAoY29uc3QgeyBjbWRfaWQsIGlkIH0gb2YgcGFyc2VkKSB7XG5cdFx0Y29uc3QgYWxyZWFkeVRvcExldmVsID0gb3V0LmNtZFNjaGVtYS5zb21lKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdGlmIChhbHJlYWR5VG9wTGV2ZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBGaW5kIGEgYmFzZSBlbnRyeSBpbiB0aGUgb3V0cHV0IHRoYXQgaGFzIGlkQWRkIGFuZCB3aG9zZSBpZCA8IHRoaXMgaWRcblx0XHRjb25zdCBpZEFkZEJhc2UgPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IHtcblx0XHRcdGlmIChhLmNtZF9pZCAhPT0gY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gYS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0cmV0dXJuICEhaWRBZGRPcHQ/LmNob2ljZXMgJiYgaWQgPiBhLmlkXG5cdFx0fSlcblx0XHRpZiAoIWlkQWRkQmFzZSkgY29udGludWVcblxuXHRcdGNvbnN0IG9mZnNldCA9IGlkIC0gaWRBZGRCYXNlLmlkXG5cdFx0Y29uc3QgaWRBZGRPcHQgPSBpZEFkZEJhc2Uub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzIHx8IGlkQWRkT3B0LmNob2ljZXMuc29tZSgoYzogYW55KSA9PiBjLmlkID09PSBvZmZzZXQpKSBjb250aW51ZVxuXG5cdFx0Ly8gQWNjZXB0IHRoZSBmb2xkIGlmOiBhIHJlZmVyZW5jZSBtb2RlbCBleHBsaWNpdGx5IGhhcyB0aGlzIG9mZnNldCxcblx0XHQvLyBPUiB0aGUgb2Zmc2V0cyBhcmUgc3RyaWN0bHkgc2VxdWVudGlhbCBmcm9tIDAgKGRldmljZSBoYXMgbW9yZSBjaGFubmVscyB0aGFuIHJlZmVyZW5jZSlcblx0XHRjb25zdCByZWZIYXNPZmZzZXQgPSBjYW5kaWRhdGVzLnNvbWUoKGMpID0+IHtcblx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKHIpID0+IHIuY21kX2lkID09PSBjbWRfaWQgJiYgci5pZCA9PT0gaWRBZGRCYXNlLmlkKVxuXHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdHJldHVybiByZWZJZEFkZD8uY2hvaWNlcz8uc29tZSgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHR9KVxuXHRcdGNvbnN0IGV4aXN0aW5nT2Zmc2V0cyA9IGlkQWRkT3B0LmNob2ljZXMubWFwKChjOiBhbnkpID0+IGMuaWQgYXMgbnVtYmVyKS5zb3J0KChhLCBiKSA9PiBhIC0gYilcblx0XHRjb25zdCBpc1NlcXVlbnRpYWwgPSBleGlzdGluZ09mZnNldHMubGVuZ3RoID4gMCAmJiBvZmZzZXQgPT09IGV4aXN0aW5nT2Zmc2V0c1tleGlzdGluZ09mZnNldHMubGVuZ3RoIC0gMV0gKyAxXG5cblx0XHRpZiAoIXJlZkhhc09mZnNldCAmJiAhaXNTZXF1ZW50aWFsKSBjb250aW51ZVxuXG5cdFx0Ly8gSW5oZXJpdCBsYWJlbCBmcm9tIHJlZmVyZW5jZSBtb2RlbCBpZiBhdmFpbGFibGUsIG90aGVyd2lzZSBnZW5lcmF0ZSBvbmVcblx0XHRsZXQgbGFiZWwgPSBgQ2hhbm5lbCAke29mZnNldCArIDF9YFxuXHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRjb25zdCByZWZDaG9pY2UgPSByZWZJZEFkZD8uY2hvaWNlcz8uZmluZCgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHRcdGlmIChyZWZDaG9pY2UpIHtcblx0XHRcdFx0bGFiZWwgPSByZWZDaG9pY2UubGFiZWxcblx0XHRcdFx0YnJlYWtcblx0XHRcdH1cblx0XHR9XG5cblx0XHRpZEFkZE9wdC5jaG9pY2VzLnB1c2goeyBpZDogb2Zmc2V0LCBsYWJlbCB9KVxuXHRcdGxvZ2dlci5pbmZvKFxuXHRcdFx0YFBhc3MgMjogRm9sZGVkIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBpbnRvIGlkQWRkIGJhc2UgaWQ9JHt0b0hleChpZEFkZEJhc2UuaWQpfSBhcyBvZmZzZXQgJHtvZmZzZXR9IChcIiR7bGFiZWx9XCIpYCxcblx0XHQpXG5cdH1cblxuXHRyZXR1cm4gb3V0XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNBVkVcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHNhdmVNb2RlbEpzb25QcmV0dHkoZmlsZVBhdGg6IHN0cmluZywganNvbk9iajogU3RNb2RlbEpzb24pOiB2b2lkIHtcblx0dHJ5IHtcblx0XHQvLyBFbnN1cmUgcHJvcGVyIGtleSBvcmRlcmluZzogbW9kZWwsIHNlY3Rpb25lZCAoaWYgcHJlc2VudCksIHJlZnJlc2hBZnRlckNvbW1hbmQsIGNtZFNjaGVtYVxuXHRcdGNvbnN0IG9yZGVyZWRPYmo6IGFueSA9IHsgbW9kZWw6IGpzb25PYmoubW9kZWwgfVxuXG5cdFx0Ly8gQWRkIHNlY3Rpb25lZCBrZXkgaWYgcHJlc2VudCAocmlnaHQgYWZ0ZXIgbW9kZWwpXG5cdFx0aWYgKCdzZWN0aW9uZWQnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmouc2VjdGlvbmVkID0ganNvbk9iai5zZWN0aW9uZWRcblx0XHR9XG5cblx0XHQvLyBBZGQgb3RoZXIga2V5cyBpbiBvcmRlclxuXHRcdGlmICgncmVmcmVzaEFmdGVyQ29tbWFuZCcgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5yZWZyZXNoQWZ0ZXJDb21tYW5kID0ganNvbk9iai5yZWZyZXNoQWZ0ZXJDb21tYW5kXG5cdFx0fVxuXHRcdGlmICgnY21kU2NoZW1hJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLmNtZFNjaGVtYSA9IGpzb25PYmouY21kU2NoZW1hLm1hcCgoZW50cnk6IGFueSkgPT4ge1xuXHRcdFx0XHQvLyBFbmZvcmNlIGtleSBvcmRlciB3aXRoaW4gZWFjaCBzY2hlbWEgZW50cnk6IGNtZF9pZCwgaWQsIGJ1c0NoLCBuYW1lLCBvcHRpb25zXG5cdFx0XHRcdGNvbnN0IG9yZGVyZWRFbnRyeTogYW55ID0ge31cblx0XHRcdFx0aWYgKCdjbWRfaWQnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkuY21kX2lkID0gZW50cnkuY21kX2lkXG5cdFx0XHRcdGlmICgnaWQnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkuaWQgPSBlbnRyeS5pZFxuXHRcdFx0XHRpZiAoJ2J1c0NoJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmJ1c0NoID0gZW50cnkuYnVzQ2hcblx0XHRcdFx0aWYgKCduYW1lJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5Lm5hbWUgPSBlbnRyeS5uYW1lXG5cdFx0XHRcdGlmICgnb3B0aW9ucycgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5vcHRpb25zID0gZW50cnkub3B0aW9uc1xuXHRcdFx0XHQvLyBDb3B5IGFueSByZW1haW5pbmcga2V5c1xuXHRcdFx0XHRmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhlbnRyeSkpIHtcblx0XHRcdFx0XHRpZiAoIShrZXkgaW4gb3JkZXJlZEVudHJ5KSkgb3JkZXJlZEVudHJ5W2tleV0gPSBlbnRyeVtrZXldXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIG9yZGVyZWRFbnRyeVxuXHRcdFx0fSlcblx0XHR9XG5cdFx0Ly8gQ29weSBhbnkgb3RoZXIga2V5cyB0aGF0IG1pZ2h0IGV4aXN0XG5cdFx0Zm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoanNvbk9iaikpIHtcblx0XHRcdGlmICghKGtleSBpbiBvcmRlcmVkT2JqKSkge1xuXHRcdFx0XHRvcmRlcmVkT2JqW2tleV0gPSAoanNvbk9iaiBhcyBhbnkpW2tleV1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBDdXN0b20gZm9ybWF0dGVyOiBrZWVwIGNob2ljZSBvYmplY3RzIGNvbXBhY3Qgb24gb25lIGxpbmVcblx0XHRsZXQganNvbiA9IEpTT04uc3RyaW5naWZ5KG9yZGVyZWRPYmosIG51bGwsIDIpXG5cblx0XHQvLyBSZXBsYWNlIGV4cGFuZGVkIGNob2ljZSBvYmplY3RzIHdpdGggY29tcGFjdCBzaW5nbGUtbGluZSBmb3JtYXRcblx0XHQvLyBNYXRjaGVzOiB7XFxuICAgICAgICAgICAgXCJpZFwiOiBYLFxcbiAgICAgICAgICAgIFwibGFiZWxcIjogXCJZXCJcXG4gICAgICAgICAgfVxuXHRcdC8vIFJlcGxhY2VzIHdpdGg6IHsgXCJpZFwiOiBYLCBcImxhYmVsXCI6IFwiWVwiIH1cblx0XHRqc29uID0ganNvbi5yZXBsYWNlKC9cXHtcXG5cXHMrXCJpZFwiOlxccyooXFxkKyksXFxuXFxzK1wibGFiZWxcIjpcXHMqXCIoW15cIl0qKVwiXFxuXFxzK1xcfS9nLCAneyBcImlkXCI6ICQxLCBcImxhYmVsXCI6IFwiJDJcIiB9JylcblxuXHRcdGZzLndyaXRlRmlsZVN5bmMoZmlsZVBhdGgsIGpzb24gKyAnXFxuJywgJ3V0ZjgnKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmVycm9yKGBGaWxlIFdyaXRlIEVycm9yOiAke2V9YClcblx0fVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBMT0FEIERFVklDRSBKU09OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogTG9hZHMgdGhlIGFjdGlvbnMgYXJyYXkgZm9yIGEgZ2l2ZW4gbW9kZWwgZnJvbSB0aGUgY2VudHJhbGl6ZWQgY2FjaGUuXG4gKiBSZXR1cm5zIGFuIGVtcHR5IGFycmF5IGlmIHRoZSBtb2RlbCBpcyBub3QgZm91bmQuXG4gKiBAZGVwcmVjYXRlZCAtIFRoaXMgZnVuY3Rpb24gaXMgbm8gbG9uZ2VyIG5lZWRlZC4gVXNlIGdldERldmljZVNjaGVtYSgpIGZyb20gY29uZmlnLnRzIGluc3RlYWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsb2FkQWN0aW9uc0Zvck1vZGVsKF9kZXZpY2VzRm9sZGVyOiBzdHJpbmcsIG1vZGVsOiBzdHJpbmcpOiBTdEFjdGlvbltdIHtcblx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRyZXR1cm4gc2NoZW1hPy5jbWRTY2hlbWEgPz8gW11cbn1cblxuLyoqXG4gKiBMb2FkcyB0aGUgbW9kZWwgY29uZmlndXJhdGlvbiBmcm9tIHRoZSBjZW50cmFsaXplZCBjYWNoZS5cbiAqIEBkZXByZWNhdGVkIC0gVGhpcyBmdW5jdGlvbiBpcyBubyBsb25nZXIgbmVlZGVkLiBVc2UgZ2V0RGV2aWNlU2NoZW1hKCkgZnJvbSBjb25maWcudHMgaW5zdGVhZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxvYWRNb2RlbENvbmZpZyhcblx0X2RldmljZXNGb2xkZXI6IHN0cmluZyxcblx0bW9kZWw6IHN0cmluZyxcbik6IHsgYWN0aW9uczogU3RBY3Rpb25bXTsgcmVmcmVzaEFmdGVyQ29tbWFuZDogYm9vbGVhbiB9IHtcblx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRyZXR1cm4ge1xuXHRcdGFjdGlvbnM6IHNjaGVtYT8uY21kU2NoZW1hID8/IFtdLFxuXHRcdHJlZnJlc2hBZnRlckNvbW1hbmQ6IHNjaGVtYT8ucmVmcmVzaEFmdGVyQ29tbWFuZCA/PyB0cnVlLCAvLyBEZWZhdWx0IHRvIHRydWUgaWYgbm90IHNwZWNpZmllZFxuXHR9XG59XG4iLCAiaW1wb3J0IE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcbmltcG9ydCB7IGJ1aWxkRmVlZGJhY2tzIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IHBhcnNlU2V0dGluZ0lkLCBnZXROb3JtYWxpemVkU2NoZW1hcywgZmluZEFjdGlvbkZvclNldHRpbmcgfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG4vKipcbiAqIEhlbHBlciBmdW5jdGlvbiB0byBnZXQgbGFiZWwgZnJvbSBjaG9pY2VzIGJhc2VkIG9uIHZhbHVlXG4gKi9cbmZ1bmN0aW9uIGdldExhYmVsRm9yVmFsdWUoXG5cdHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9Pixcblx0bW9kZWw6IHN0cmluZyxcblx0Y21kSWQ6IG51bWJlcixcblx0c2V0dGluZ0lkOiBudW1iZXIsXG5cdHZhbHVlOiBudW1iZXIsXG4pOiBzdHJpbmcgfCBudW1iZXIge1xuXHRjb25zdCBzZXR0aW5nID0gZmluZEFjdGlvbkZvclNldHRpbmcoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQpXG5cdGlmICghc2V0dGluZyB8fCAhQXJyYXkuaXNBcnJheShzZXR0aW5nLm9wdGlvbnMpKSByZXR1cm4gdmFsdWVcblxuXHQvLyBGaW5kIHRoZSAndmFsdWUnIG9wdGlvbiB3aGljaCBjb250YWlucyB0aGUgY2hvaWNlc1xuXHRjb25zdCB2YWx1ZU9wdGlvbiA9IHNldHRpbmcub3B0aW9ucy5maW5kKChvcHQ6IGFueSkgPT4gb3B0LmlkID09PSAndmFsdWUnKVxuXHRpZiAoIXZhbHVlT3B0aW9uIHx8ICFBcnJheS5pc0FycmF5KHZhbHVlT3B0aW9uLmNob2ljZXMpKSByZXR1cm4gdmFsdWVcblxuXHQvLyBGaW5kIHRoZSBjaG9pY2Ugd2l0aCBtYXRjaGluZyBpZFxuXHRjb25zdCBjaG9pY2UgPSB2YWx1ZU9wdGlvbi5jaG9pY2VzLmZpbmQoKGM6IGFueSkgPT4gYy5pZCA9PT0gdmFsdWUpXG5cdHJldHVybiBjaG9pY2U/LmxhYmVsID8/IHZhbHVlXG59XG5cbi8qKlxuICogQnVpbGQgYW5kIHdpcmUgQ29tcGFuaW9uIGZlZWRiYWNrIGRlZmluaXRpb25zXG4gKiBQYXR0ZXJuIG1hdGNoZXMgYWN0aW9ucy50cyAtIGZpbHRlcnMgYnkgYWN0aXZlIG1vZGVsIGFuZCB3aXJlcyBjYWxsYmFja3NcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUZlZWRiYWNrcyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBzY2hlbWFzUmF3ID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IHJhd0ZlZWRiYWNrcyA9IGJ1aWxkRmVlZGJhY2tzKClcblx0Y29uc3Qgc2NoZW1hcyA9IGdldE5vcm1hbGl6ZWRTY2hlbWFzKHNjaGVtYXNSYXcpXG5cdGNvbnN0IHdpcmVkRmVlZGJhY2tzOiBhbnkgPSB7fVxuXG5cdC8vIEdldCB0aGUgYWN0aXZlIG1vZGVsIGZyb20gdGhlIGNhY2hlZCB2YWx1ZSBzZXQgYnkgc3luY01vZGVsKClcblx0Y29uc3QgYWN0aXZlTW9kZWwgPSBzZWxmLmFjdGl2ZU1vZGVsXG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBCVUlMRCBQRVItU0VUVElORyBGRUVEQkFDS1MgKEZJTFRFUkVEIEJZIEFDVElWRSBNT0RFTClcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0Zm9yIChjb25zdCBbZmVlZGJhY2tJZCwgZmVlZGJhY2tdIG9mIE9iamVjdC5lbnRyaWVzKHJhd0ZlZWRiYWNrcykpIHtcblx0XHRjb25zdCB7IG1vZGVsLCBjbWRJZCwgYmFzZUlkIH0gPSBwYXJzZVNldHRpbmdJZChmZWVkYmFja0lkKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGZlZWRiYWNrcyBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgbW9kZWxcblx0XHRpZiAobW9kZWwgIT09IGFjdGl2ZU1vZGVsKSBjb250aW51ZVxuXG5cdFx0Ly8gVkFMVUUgRkVFREJBQ0s6IFJldHVybnMgY3VycmVudCB2YWx1ZSBmb3IgbG9jYWwgdmFyaWFibGVcblx0XHR3aXJlZEZlZWRiYWNrc1tmZWVkYmFja0lkXSA9IHtcblx0XHRcdC4uLmZlZWRiYWNrLFxuXHRcdFx0Y2FsbGJhY2s6IChmZWVkYmFja0V2ZW50OiBhbnkpID0+IHtcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ2lkQWRkJ10gPz8gMFxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBiYXNlSWQgKyBpZEFkZFxuXG5cdFx0XHRcdC8vIGJ1c0NoIGZyb20gb3B0aW9ucyB0YWtlcyBwcmlvcml0eTsgZmFsbCBiYWNrIHRvIGZpeGVkIGJ1c0NoIGluIHNjaGVtYVxuXHRcdFx0XHRsZXQgYnVzQ2ggPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ2J1c0NoJ11cblx0XHRcdFx0aWYgKGJ1c0NoID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRjb25zdCBzY2hlbWFBY3Rpb24gPSBmaW5kQWN0aW9uRm9yU2V0dGluZyhzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZClcblx0XHRcdFx0XHRpZiAoc2NoZW1hQWN0aW9uPy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRidXNDaCA9IHNjaGVtYUFjdGlvbi5idXNDaFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IGN1cnJlbnQgPSBzZWxmLnN0Q29udHJvbGxlci5nZXRTZXR0aW5nVmFsdWUoaXAsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXG5cdFx0XHRcdC8vIENoZWNrIGlmIHVzZXIgd2FudHMgbGFiZWwgaW5zdGVhZCBvZiBudW1lcmljIHZhbHVlXG5cdFx0XHRcdGNvbnN0IHNob3dMYWJlbCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snc2hvd0xhYmVsJ10gPz8gZmFsc2VcblxuXHRcdFx0XHRpZiAoc2hvd0xhYmVsICYmIGN1cnJlbnQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdC8vIFJldHVybiB0aGUgbGFiZWwgZnJvbSBjaG9pY2VzXG5cdFx0XHRcdFx0cmV0dXJuIGdldExhYmVsRm9yVmFsdWUoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQsIGN1cnJlbnQpXG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBSZXR1cm4gbnVtZXJpYyB2YWx1ZSBkaXJlY3RseSBmb3IgbG9jYWwgdmFyaWFibGUgKHR5cGU6ICd2YWx1ZScpXG5cdFx0XHRcdHJldHVybiBjdXJyZW50ID8/IDBcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0c2VsZi5zZXRGZWVkYmFja0RlZmluaXRpb25zKHdpcmVkRmVlZGJhY2tzKVxuXG5cdC8vY29uc29sZS5sb2coJ0ZlZWRiYWNrczpcXG4nLCBKU09OLnN0cmluZ2lmeSh3aXJlZEZlZWRiYWNrcywgbnVsbCwgMikpXG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9CVVNfR0VULFxuXHRDTURfQlVTX1NFVCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX0dFVF9GSVJNV0FSRSxcblx0Q01EX0dMT0JBTF9NSUNfS0lMTCxcblx0Q01EX01JQ19QUkUsXG5cdENNRF9NSUNfUFJFX0JVUyxcblx0Q01EX1JFU0VUX0RFVklDRSxcblx0Q01EX1NFVFRJTkdTX1BVU0gsXG5cdGdldENvbW1hbmROYW1lLFxuXHRtYWtlU2V0dGluZ0lkLFxuXHR0b0hleCxcblx0Ynl0ZXNUb0hleCxcblx0dHlwZSBEZXZpY2VJbmZvLFxufSBmcm9tICcuL3R5cGVzLmpzJ1xuaW1wb3J0IHtcblx0cGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsLFxuXHRwYXJzZVNldHRpbmdzUmVzcG9uc2UsXG5cdGZvcm1hdFBhcnNlZFNldHRpbmcsXG5cdHR5cGUgU3RBY3Rpb24sXG5cdHR5cGUgUGFyc2VkU2V0dGluZyxcbn0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcbmltcG9ydCB7XG5cdERBTlRFX01TR19JTkZPX1JFU1BPTlNFLFxuXHRwYXJzZURhbnRlSW5mb1Jlc3BvbnNlLFxuXHRkaXNjb3ZlckRldmljZXMsXG5cdGJ1aWxkRGFudGVJbmZvUmVxdWVzdCxcblx0Z2V0TWFjRm9yRGVzdGluYXRpb24sXG5cdGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uLFxufSBmcm9tICcuL2RhbnRlLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1N0Q29udHJvbGxlcicpXG5cbmV4cG9ydCBjbGFzcyBTdENvbnRyb2xsZXIge1xuXHRwcml2YXRlIHJlYWRvbmx5IGRlZmF1bHRQb3J0OiBudW1iZXIgPSA4NzAwXG5cdHByaXZhdGUgcmVhZG9ubHkgbXVsdGljYXN0R3JvdXAgPSAnMjI0LjAuMC4yMzEnXG5cdHByaXZhdGUgcmVhZG9ubHkgcnhQb3J0ID0gODcwMlxuXG5cdHByaXZhdGUgdHhTb2NrZXQ6IGRncmFtLlNvY2tldFxuXHRwcml2YXRlIHJ4U29ja2V0OiBkZ3JhbS5Tb2NrZXQgLy8gZm9yIHJlY2VpdmluZyByZXNwb25zZXMgKDg3MDIpXG5cdHByaXZhdGUgcGVuZGluZ0Fja3M6IE1hcDxcblx0XHRzdHJpbmcsXG5cdFx0eyByZXNvbHZlOiAoYnVmOiBCdWZmZXIpID0+IHZvaWQ7IHJlamVjdDogKGU6IEVycm9yKSA9PiB2b2lkOyB0aW1lcjogTm9kZUpTLlRpbWVvdXQgfVxuXHQ+ID0gbmV3IE1hcCgpXG5cdHByaXZhdGUgam9pbmVkSW50ZXJmYWNlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KCkgLy8gbG9jYWwgSVBzIHdlJ3ZlIGpvaW5lZCBtdWx0aWNhc3Qgb25cblxuXHQvKiogU2VyaWFsaXplcyBvdXRnb2luZyBjb21tYW5kcyBzbyBlYWNoIHdhaXRzIGZvciBBQ0sgYmVmb3JlIHRoZSBuZXh0IGlzIHNlbnQgKi9cblx0cHJpdmF0ZSBzZW5kUXVldWU6IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKVxuXG5cdC8qKiBUcmFja3MgaG93IG1hbnkgY29tbWFuZHMgYXJlIHF1ZXVlZC9pbi1mbGlnaHQsIHRvIGRlZmVyIHJlcXVlc3RBbGxTZXR0aW5ncyAqL1xuXHRwcml2YXRlIHBlbmRpbmdDb21tYW5kQ291bnQgPSAwXG5cblx0LyoqIFJlc29sdmVzIG9uY2UgdHhTb2NrZXQgaXMgYm91bmQgYW5kIHJlYWR5IHRvIHNlbmQgKi9cblx0cHJpdmF0ZSB0eFJlYWR5OiBQcm9taXNlPHZvaWQ+XG5cblx0LyoqIEFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBmb3Igc2V0dGluZ3MgZGVjb2RpbmcgKi9cblx0cHJpdmF0ZSBtb2RlbDogc3RyaW5nID0gJydcblx0cHJpdmF0ZSBhY3Rpb25zOiBTdEFjdGlvbltdID0gW11cblx0cHJpdmF0ZSByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuID0gdHJ1ZSAvLyBEZWZhdWx0IHRvIHRydWUgKG1vc3QgZGV2aWNlcyBuZWVkIGl0KVxuXG5cdC8qKlxuXHQgKiBLbm93biBzdGF0ZSBvZiBldmVyeSBzZXR0aW5nIHBlciBkZXZpY2UgSVAuXG5cdCAqIEtleWVkIGJ5IElQIFx1MjE5MiBNYXAgb2YgXCIke2NtZElkfS8ke3NldHRpbmdJZH1cIiBcdTIxOTIgY3VycmVudCB2YWx1ZSBieXRlLlxuXHQgKiBQb3B1bGF0ZWQgb24gY29ubmVjdCB2aWEgcmVxdWVzdEFsbFNldHRpbmdzKCksIHVwZGF0ZWQgb24gZXZlcnkgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpLlxuXHQgKiBVc2VkIHRvIGRpZmYgaW5jb21pbmcgcHVzaGVzIChjaGFuZ2VkID0gaW5mbywgdW5jaGFuZ2VkID0gZGVidWcpIGFuZCBmb3IgZmVlZGJhY2tzLlxuXHQgKi9cblx0cHJpdmF0ZSBkZXZpY2VTdGF0ZTogTWFwPHN0cmluZywgTWFwPHN0cmluZywgbnVtYmVyPj4gPSBuZXcgTWFwKClcblxuXHQvKipcblx0ICogSVBzIHRoYXQgaGF2ZSBiZWVuIHZlcmlmaWVkIGFnYWluc3QgdGhlIGNvbmZpZ3VyZWQgbW9kZWwgYW5kIGFyZSBhbGxvd2VkXG5cdCAqIHRvIHJlY2VpdmUgU3R1ZGlvLVQgY29tbWFuZHMuIFBvcHVsYXRlZCBieSBhdXRob3JpemVEZXZpY2UoKSBhZnRlciBhXG5cdCAqIHN1Y2Nlc3NmdWwgcHJvYmVEZXZpY2UoKSBtb2RlbCBtYXRjaCwgb3IgYWZ0ZXIgbXVsdGljYXN0IGRpc2NvdmVyeS5cblx0ICogX3NlbmRBd2FpdEFjaygpIHJlamVjdHMgYW55IGRlc3RJcCBub3QgaW4gdGhpcyBzZXQuXG5cdCAqL1xuXHRwcml2YXRlIGF1dGhvcml6ZWRJcHM6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpXG5cblx0LyoqIENhbGxiYWNrcyByZWdpc3RlcmVkIGJ5IGRpc2NvdmVyRGV2aWNlcygpIFx1MjAxNCBrZXllZCBieSBzb3VyY2UgSVAgKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcnlMaXN0ZW5lcnM6IE1hcDxzdHJpbmcsIChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQ+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrIHRvIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlcyB3aGVuIHN0YXRlIGNoYW5nZXMgKi9cblx0cHJpdmF0ZSBmZWVkYmFja0NhbGxiYWNrPzogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZFxuXG5cdC8qKiBDYWNoZSBvZiBsb2NhbCBpbnRlcmZhY2UgTUFDIGJ5dGVzIHBlciBkZXN0aW5hdGlvbiBJUCwgdG8gYXZvaWQgcmVwZWF0ZWQgT1MgbG9va3VwcyAqL1xuXHRwcml2YXRlIG1hY0NhY2hlOiBNYXA8c3RyaW5nLCBudW1iZXJbXT4gPSBuZXcgTWFwKClcblxuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRsb2dnZXIuaW5mbygnU3RDb250cm9sbGVyIGluaXRpYWxpemVkJylcblxuXHRcdC8vIFNlbmQgc29ja2V0IFx1MjAxNCBiaW5kIHRvIGVwaGVtZXJhbCBwb3J0LiBSZXNwb25zZXMgYWx3YXlzIGdvIHRvIHJ4U29ja2V0IG9uXG5cdFx0Ly8gcG9ydCA4NzAyIChEYW50ZSBoYXJkY29kZXMgdGhlIHJlc3BvbnNlIGRlc3RpbmF0aW9uIHBvcnQgdG8gODcwMikuXG5cdFx0dGhpcy50eFNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cdFx0dGhpcy50eFJlYWR5ID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuYmluZCgwLCAoKSA9PiB7XG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgVFggc29ja2V0IGJvdW5kIHRvIHBvcnQgJHsodGhpcy50eFNvY2tldC5hZGRyZXNzKCkgYXMgeyBwb3J0OiBudW1iZXIgfSkucG9ydH1gKVxuXHRcdFx0XHRyZXNvbHZlKClcblx0XHRcdH0pXG5cdFx0fSlcblx0XHR0aGlzLnR4U29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgVFggc29ja2V0IGVycm9yOiAke2Vycn1gKVxuXHRcdH0pXG5cblx0XHQvLyBSZWNlaXZlIHNvY2tldCAtIGJpbmQgdG8gYWxsIGFkZHJlc3NlcyBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHNcblx0XHR0aGlzLnJ4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2xpc3RlbmluZycsICgpID0+IHtcblx0XHRcdGNvbnN0IGFkZHIgPSB0aGlzLnJ4U29ja2V0LmFkZHJlc3MoKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgbGlzdGVuaW5nIG9uICR7SlNPTi5zdHJpbmdpZnkoYWRkcil9YClcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMucnhTb2NrZXQuc2V0TXVsdGljYXN0TG9vcGJhY2sodHJ1ZSlcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgUlggc29ja2V0IGVycm9yOiAke2Vycn1gKVxuXHRcdH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdtZXNzYWdlJywgKG1zZywgcmluZm8pID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMuaGFuZGxlSW5jb21pbmcobXNnLCByaW5mby5hZGRyZXNzKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLmVycm9yKGBFcnJvciBoYW5kbGluZyBpbmNvbWluZyBtZXNzYWdlOiAke19lfWApXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIEJpbmQgdG8gd2lsZGNhcmQgc28ga2VybmVsIGNhbiBkZWxpdmVyIG11bHRpY2FzdCBwYWNrZXRzIGZvciBqb2luZWQgaW50ZXJmYWNlc1xuXHRcdHRoaXMucnhTb2NrZXQuYmluZCh7IGFkZHJlc3M6ICcwLjAuMC4wJywgcG9ydDogdGhpcy5yeFBvcnQgfSwgKCkgPT4ge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgYm91bmQgdG8gMC4wLjAuMDoke3RoaXMucnhQb3J0fWApXG5cdFx0fSlcblx0fVxuXG5cdHB1YmxpYyBjbG9zZSgpOiB2b2lkIHtcblx0XHR0cnkge1xuXHRcdFx0Zm9yIChjb25zdCBsb2NhbEFkZHIgb2YgQXJyYXkuZnJvbSh0aGlzLmpvaW5lZEludGVyZmFjZXMpKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0dGhpcy5yeFNvY2tldC5kcm9wTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBsb2NhbEFkZHIpXG5cdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMucnhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnR4U29ja2V0LmNsb3NlKClcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBQcm92aWRlIHRoZSBhY3RpdmUgZGV2aWNlIG1vZGVsIGFuZCBhY3Rpb24gZGVmaW5pdGlvbnMgc28gaW5jb21pbmcgbWVzc2FnZXNcblx0ICogY2FuIGJlIGRlY29kZWQgaW50byBodW1hbi1yZWFkYWJsZSBuYW1lcy4gQ2FsbCBmcm9tIG1haW4udHMgYWZ0ZXIgY29uZmlnIGxvYWQuXG5cdCAqL1xuXHRwdWJsaWMgc2V0TW9kZWwobW9kZWw6IHN0cmluZywgYWN0aW9uczogU3RBY3Rpb25bXSwgcmVmcmVzaEFmdGVyQ29tbWFuZDogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcblx0XHR0aGlzLm1vZGVsID0gbW9kZWxcblx0XHR0aGlzLmFjdGlvbnMgPSBhY3Rpb25zXG5cdFx0dGhpcy5yZWZyZXNoQWZ0ZXJDb21tYW5kID0gcmVmcmVzaEFmdGVyQ29tbWFuZFxuXHR9XG5cblx0LyoqXG5cdCAqIFNldCBjYWxsYmFjayB0byB0cmlnZ2VyIHdoZW4gZGV2aWNlIHN0YXRlIGNoYW5nZXMgKGZvciBmZWVkYmFja3MpLlxuXHQgKiBDYWxsIGZyb20gbWFpbi50cyB0byB3aXJlIHVwIGNoZWNrRmVlZGJhY2tzLlxuXHQgKi9cblx0cHVibGljIHNldEZlZWRiYWNrQ2FsbGJhY2soY2FsbGJhY2s6IChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHZvaWQpOiB2b2lkIHtcblx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2sgPSBjYWxsYmFja1xuXHR9XG5cblx0LyoqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZGV2aWNlIGF0IHRoZSBnaXZlbiBJUCBoYXMgYmVlbiBhdXRob3JpemVkIHRvIHJlY2VpdmUgY29tbWFuZHMuICovXG5cdHB1YmxpYyBpc0RldmljZUF1dGhvcml6ZWQoaXA6IHN0cmluZyk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLmF1dGhvcml6ZWRJcHMuaGFzKGlwKVxuXHR9XG5cblx0LyoqIE1hcmsgYW4gSVAgYXMgdmVyaWZpZWQgYW5kIGFsbG93ZWQgdG8gcmVjZWl2ZSBTdHVkaW8tVCBjb21tYW5kcy4gKi9cblx0cHVibGljIGF1dGhvcml6ZURldmljZShpcDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hdXRob3JpemVkSXBzLmFkZChpcClcblx0XHRsb2dnZXIuZGVidWcoYEF1dGhvcml6ZWQgZGV2aWNlIGF0ICR7aXB9YClcblx0fVxuXG5cdC8qKiBSZW1vdmUgYXV0aG9yaXphdGlvbiBmb3IgYW4gSVAgKGUuZy4gb24gY29uZmlnIGNoYW5nZSBvciBtb2RlbCBtaXNtYXRjaCkuICovXG5cdHB1YmxpYyByZXZva2VEZXZpY2UoaXA6IHN0cmluZyk6IHZvaWQge1xuXHRcdHRoaXMuYXV0aG9yaXplZElwcy5kZWxldGUoaXApXG5cdFx0dGhpcy5kZXZpY2VTdGF0ZS5kZWxldGUoaXApXG5cdFx0dGhpcy5tYWNDYWNoZS5kZWxldGUoaXApXG5cdFx0bG9nZ2VyLmRlYnVnKGBSZXZva2VkIGRldmljZSBhdCAke2lwfWApXG5cdH1cblxuXHQvKipcblx0ICogU2VuZHMgYSB1bmljYXN0IERhbnRlIGluZm8gcmVxdWVzdCB0byBhIHNwZWNpZmljIElQIGFuZCB3YWl0cyBmb3IgdGhlXG5cdCAqIGRldmljZSBpbmZvIHJlc3BvbnNlLiBSZXR1cm5zIHRoZSBEZXZpY2VJbmZvIGlmIHRoZSBkZXZpY2UgcmVzcG9uZHMgd2l0aGluXG5cdCAqIHRpbWVvdXRNcywgb3IgbnVsbCBpZiBubyByZXNwb25zZS4gVXNlZCB0byB2ZXJpZnkgYSBtYW51YWxseSBjb25maWd1cmVkIElQLlxuXHQgKiBEb2VzIE5PVCByZXF1aXJlIGF1dGhvcml6YXRpb24gXHUyMDE0IHRoaXMgaXMgaG93IGF1dGhvcml6YXRpb24gaXMgZXN0YWJsaXNoZWQuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcHJvYmVEZXZpY2UoaXA6IHN0cmluZywgdGltZW91dE1zID0gMzAwMCk6IFByb21pc2U8RGV2aWNlSW5mbyB8IG51bGw+IHtcblx0XHRyZXR1cm4gbmV3IFByb21pc2U8RGV2aWNlSW5mbyB8IG51bGw+KChyZXNvbHZlKSA9PiB7XG5cdFx0XHRjb25zdCBrZXkgPSBgX19wcm9iZV8ke2lwfV9fYFxuXHRcdFx0bGV0IHJlc29sdmVkID0gZmFsc2VcblxuXHRcdFx0Y29uc3QgZmluaXNoID0gKHJlc3VsdDogRGV2aWNlSW5mbyB8IG51bGwpID0+IHtcblx0XHRcdFx0aWYgKHJlc29sdmVkKSByZXR1cm5cblx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHJlc29sdmUocmVzdWx0KVxuXHRcdFx0fVxuXG5cdFx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5zZXQoa2V5LCAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB7XG5cdFx0XHRcdGlmIChkZXZpY2UuaXAgPT09IGlwKSBmaW5pc2goZGV2aWNlKVxuXHRcdFx0fSlcblxuXHRcdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IGZpbmlzaChudWxsKSwgdGltZW91dE1zKVxuXHRcdFx0dGltZXIudW5yZWY/LigpXG5cblx0XHRcdGNvbnN0IHJ1biA9IGFzeW5jICgpID0+IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGlwKVxuXHRcdFx0XHRhd2FpdCB0aGlzLnR4UmVhZHlcblx0XHRcdFx0Y29uc3QgcXVlcnkgPSBidWlsZERhbnRlSW5mb1JlcXVlc3QoKVxuXHRcdFx0XHR0aGlzLnR4U29ja2V0LnNlbmQocXVlcnksIHRoaXMuZGVmYXVsdFBvcnQsIGlwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYFByb2JlIHRvICR7aXB9IGZhaWxlZDogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdFx0ZmluaXNoKG51bGwpXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KVxuXHRcdFx0fVxuXG5cdFx0XHRydW4oKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0XHRsb2dnZXIud2FybihgcHJvYmVEZXZpY2Ugc2V0dXAgZmFpbGVkIGZvciAke2lwfTogJHtlfWApXG5cdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0ZmluaXNoKG51bGwpXG5cdFx0XHR9KVxuXHRcdH0pXG5cdH1cblxuXHQvKipcblx0ICogU2VuZCBhIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSByZXF1ZXN0IHRvIHRoZSBkZXZpY2UgYW5kIHN0b3JlIHRoZSByZXNwb25zZVxuXHQgKiBpbiBkZXZpY2VTdGF0ZS4gUmV0dXJucyB0aGUgcmF3IHJlc3BvbnNlIGJ1ZmZlciBmb3IgcGFyc2luZy5cblx0ICovXG5cdHB1YmxpYyBhc3luYyByZXF1ZXN0QWxsU2V0dGluZ3MoZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgYWxsIHNldHRpbmdzIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soQ01EX0dFVF9BTExfU0VUVElOR1MsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRldmljZUlwLCBmYWxzZSlcblx0XHQvLyBkZXZpY2VTdGF0ZSBpcyBwb3B1bGF0ZWQgYnkgbG9nU3RQYXlsb2FkIHdoZW4gdGhlIENNRF9HRVRfQUxMX1NFVFRJTkdTIHJlc3BvbnNlIGFycml2ZXNcblx0XHRyZXR1cm4gcmVzcG9uc2Vcblx0fVxuXG5cdC8qKlxuXHQgKiBEaXNjb3ZlcnMgU3R1ZGlvIFRlY2hub2xvZ2llcyBEYW50ZSBkZXZpY2VzIG9uIHRoZSBsb2NhbCBuZXR3b3JrLlxuXHQgKlxuXHQgKiBTdHJhdGVneTpcblx0ICogIERhbnRlIGRldmljZXMgYnJvYWRjYXN0IGEgMS1zZWNvbmQgYW5ub3VuY2UgdG8gbXVsdGljYXN0IDIyNC4wLjAuMjMzOjg3MDguXG5cdCAqICBXZSBsaXN0ZW4gb24gdGhhdCBncm91cCwgY29sbGVjdCBzb3VyY2UgSVBzLCB0aGVuIHNlbmQgYSB1bmljYXN0IGRldmljZSBpbmZvXG5cdCAqICByZXF1ZXN0ICgweDAwMjApIHRvIGVhY2ggbmV3IElQIG9uIHBvcnQgODcwMC4gVGhlIGRldmljZSByZXNwb25kcyB0byBvdXIgSVBcblx0ICogIG9uIHBvcnQgODcwMiAocnhTb2NrZXQpLCB3aGVyZSBoYW5kbGVJbmNvbWluZygpIHBpY2tzIGl0IHVwIGFuZCBmaXJlcyB0aGVcblx0ICogIGRpc2NvdmVyeUxpc3RlbmVycyBjYWxsYmFjay5cblx0ICovXG5cdHB1YmxpYyBhc3luYyBkaXNjb3ZlckRldmljZXModGltZW91dE1zID0gNTAwMCk6IFByb21pc2U8RGV2aWNlSW5mb1tdPiB7XG5cdFx0Ly8gUmVnaXN0ZXIgbGlzdGVuZXIgXHUyMDE0IGhhbmRsZUluY29taW5nKCkgZmlyZXMgdGhpcyBmb3IgZWFjaCAweDAxNzAgcmVzcG9uc2Vcblx0XHRjb25zdCBESVNDT1ZFUllfS0VZID0gJ19fZGlzY292ZXJ5X18nXG5cdFx0Y29uc3QgZm91bmREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXVxuXG5cdFx0Y29uc3Qgb25EZXZpY2VGb3VuZCA9IChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdGlmICghZm91bmREZXZpY2VzLnNvbWUoKGQpID0+IGQuaXAgPT09IGRldmljZS5pcCkpIHtcblx0XHRcdFx0Zm91bmREZXZpY2VzLnB1c2goZGV2aWNlKVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIFJlZ2lzdGVyIHRoZSBjYWxsYmFjayBzbyBoYW5kbGVJbmNvbWluZygpIGNhbiBpbnZva2UgaXQgd2hlbiAweDAxNzAgYXJyaXZlc1xuXHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChESVNDT1ZFUllfS0VZLCBvbkRldmljZUZvdW5kKVxuXG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHRoaXMudHhSZWFkeVxuXHRcdFx0Ly8gZGlzY292ZXJEZXZpY2VzKCkgaW4gZGFudGUudHMgaGFuZGxlcyB0aGUgYW5ub3VuY2UgbGlzdGVuaW5nIGFuZCBxdWVyeSBzZW5kaW5nLlxuXHRcdFx0Ly8gUmVzcG9uc2VzIGNvbWUgYmFjayB0byByeFNvY2tldCBcdTIxOTIgaGFuZGxlSW5jb21pbmcoKSBcdTIxOTIgZGlzY292ZXJ5TGlzdGVuZXJzLlxuXHRcdFx0YXdhaXQgZGlzY292ZXJEZXZpY2VzKHRoaXMudHhTb2NrZXQsIGFzeW5jIChkZXN0SXApID0+IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApLCB0aW1lb3V0TXMpXG5cdFx0XHRyZXR1cm4gZm91bmREZXZpY2VzXG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLmRlbGV0ZShESVNDT1ZFUllfS0VZKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBSZXF1ZXN0cyBkZXZpY2UgZmlybXdhcmUgdmVyc2lvbiB2aWEgU3R1ZGlvLVQgcHJvdG9jb2wgKENNRF9HRVRfRklSTVdBUkUpLlxuXHQgKiBSZXR1cm5zIHRoZSBmaXJtd2FyZSB2ZXJzaW9uIHN0cmluZyAoZS5nLiwgXCIzLjAxXCIsIFwiMi4yXCIsIFwiMS4wNVwiKS5cblx0ICovXG5cdHB1YmxpYyBhc3luYyByZXF1ZXN0RmlybXdhcmVWZXJzaW9uKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRcdGxvZ2dlci5pbmZvKGBSZXF1ZXN0aW5nIGZpcm13YXJlIHZlcnNpb24gZnJvbSAke2RldmljZUlwfWApXG5cdFx0Y29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0VUX0ZJUk1XQVJFLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXZpY2VJcCwgZmFsc2UpXG5cblx0XHQvLyBSZXNwb25zZSBzdHJ1Y3R1cmU6IFtoZWFkZXJdIDB4NWEgMHg4MCBbZmlybXdhcmVfZGF0YV0gQ1JDXG5cdFx0Ly8gRmlybXdhcmUgZGF0YSBzdGFydHMgYXQgYnl0ZSAyNiAoMjQtYnl0ZSBoZWFkZXIgKyAweDVhICsgMHg4MClcblx0XHRjb25zdCBkYXRhU3RhcnQgPSAyNlxuXG5cdFx0aWYgKHJlc3BvbnNlLmxlbmd0aCA8IGRhdGFTdGFydCArIDMpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBGaXJtd2FyZSByZXNwb25zZSB0b28gc2hvcnQ6ICR7cmVzcG9uc2UubGVuZ3RofSBieXRlc2ApXG5cdFx0XHRyZXR1cm4gJ1Vua25vd24nXG5cdFx0fVxuXG5cdFx0Ly8gRmlybXdhcmUgZm9ybWF0OiBbdW5rbm93bl9ieXRlLCBtYWpvciwgbWlub3JdXG5cdFx0Y29uc3QgbWFqb3IgPSByZXNwb25zZVtkYXRhU3RhcnQgKyAxXVxuXHRcdGNvbnN0IG1pbm9yID0gcmVzcG9uc2VbZGF0YVN0YXJ0ICsgMl1cblxuXHRcdGNvbnN0IG1pbm9yU3RyID1cblx0XHRcdG1pbm9yIDwgMTBcblx0XHRcdFx0PyBtaW5vci50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJykgLy8gZS5nLiAxIFx1MjE5MiBcIjAxXCIsIDUgXHUyMTkyIFwiMDVcIlxuXHRcdFx0XHQ6IG1pbm9yLnRvU3RyaW5nKCkgLy8gZS5nLiAxMCBcdTIxOTIgXCIxMFwiXG5cblx0XHRjb25zdCBmaXJtd2FyZSA9IGAke21ham9yfS4ke21pbm9yU3RyfWBcblxuXHRcdGxvZ2dlci5pbmZvKGBGaXJtd2FyZSB2ZXJzaW9uOiAke2Zpcm13YXJlfWApXG5cdFx0cmV0dXJuIGZpcm13YXJlXG5cdH1cblxuXHQvKipcblx0ICogSm9pbnMgdGhlIG11bHRpY2FzdCByZXNwb25zZSBncm91cCBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIGRlc3RJcC5cblx0ICogT25seSBqb2lucyB0aGUgc3BlY2lmaWMgaW50ZXJmYWNlIHVzZWQgdG8gcmVhY2ggdGhlIGRldmljZSwgYW5kIG9ubHkgb25jZSBwZXIgaW50ZXJmYWNlLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBlbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGF3YWl0IGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblx0XHRcdGlmICghbG9jYWxBZGRyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgZGV0ZXJtaW5lIGxvY2FsIGFkZHJlc3MgZm9yIGRlc3RpbmF0aW9uICR7ZGVzdElwfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAodGhpcy5qb2luZWRJbnRlcmZhY2VzLmhhcyhsb2NhbEFkZHIpKSB7XG5cdFx0XHRcdC8vIGFscmVhZHkgam9pbmVkXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLnJ4U29ja2V0LmFkZE1lbWJlcnNoaXAodGhpcy5tdWx0aWNhc3RHcm91cCwgbG9jYWxBZGRyKVxuXHRcdFx0XHR0aGlzLmpvaW5lZEludGVyZmFjZXMuYWRkKGxvY2FsQWRkcilcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEpvaW5lZCBtdWx0aWNhc3QgJHt0aGlzLm11bHRpY2FzdEdyb3VwfSBvbiAke2xvY2FsQWRkcn1gKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBqb2luIG11bHRpY2FzdCBvbiAke2xvY2FsQWRkcn06ICR7U3RyaW5nKF9lKX1gKVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRsb2dnZXIud2FybihgZW5zdXJlTWVtYmVyc2hpcEZvciBmYWlsZWQ6ICR7X2V9YClcblx0XHR9XG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgc2VuZEF3YWl0QWNrKFxuXHRcdGNtZElkOiBudW1iZXIsXG5cdFx0YnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHRzZXR0aW5nSWQ6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHR2YWx1ZTogdW5rbm93bixcblx0XHRkZXN0SXA6IHN0cmluZyxcblx0XHRhZGRMZW4gPSB0cnVlLFxuXHQpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudCsrXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPEJ1ZmZlcj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0dGhpcy5zZW5kUXVldWUgPSB0aGlzLnNlbmRRdWV1ZS50aGVuKGFzeW5jICgpID0+XG5cdFx0XHRcdHRoaXMuX3NlbmRBd2FpdEFjayhjbWRJZCwgYnVzQ2gsIHNldHRpbmdJZCwgdmFsdWUsIGRlc3RJcCwgYWRkTGVuKVxuXHRcdFx0XHRcdC50aGVuKChidWYpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHQvLyBPbmx5IHRyaWdnZXIgcmVxdWVzdEFsbFNldHRpbmdzIGFmdGVyIGEgd3JpdGUgKFNFVCkgY29tbWFuZCwgbm90IGEgcmVhZC9wb2xsLlxuXHRcdFx0XHRcdFx0Ly8gQSB3cml0ZSBhbHdheXMgaGFzIGEgdmFsdWU7IHJlYWRzIChHRVQsIEJVU19HRVQpIG5ldmVyIGRvLlxuXHRcdFx0XHRcdFx0aWYgKHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudCA9PT0gMCAmJiB0aGlzLnJlZnJlc2hBZnRlckNvbW1hbmQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdFx0XHR0aGlzLnJlcXVlc3RBbGxTZXR0aW5ncyhkZXN0SXApLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0LmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHRyZWplY3QoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIgOiBuZXcgRXJyb3IoU3RyaW5nKGVycikpKVxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIF9zZW5kQXdhaXRBY2soXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0Y29uc3QgdGltZW91dE1zID0gMjAwMFxuXG5cdFx0Y29uc3QgZGF0YUJsb2NrOiBudW1iZXJbXSA9IFtdXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkKSBkYXRhQmxvY2sucHVzaChzZXR0aW5nSWQgJiAweGZmKVxuXHRcdGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSBkYXRhQmxvY2sucHVzaCguLi5TdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKSlcblxuXHRcdGNvbnN0IHBheWxvYWRCb2R5OiBudW1iZXJbXSA9IFsweDVhLCBjbWRJZCAmIDB4ZmZdXG5cblx0XHRpZiAoY21kSWQgPT09IENNRF9NSUNfUFJFICYmIGJ1c0NoICE9PSB1bmRlZmluZWQgJiYgc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Ly8gUG9zaXRpb25hbCBmb3JtYXQ6IFsweDVhXSBbMHgwMl0gW2J1c0NoXSBbdmFsMF0gW3ZhbDFdIFt2YWwyXSAuLi5cblx0XHRcdC8vIFJlYWQgYWxsIHBvc2l0aW9ucyBmcm9tIGRldmljZVN0YXRlLCBvdmVycmlkZSB0aGUgdGFyZ2V0IHBvc2l0aW9uIHdpdGggbmV3IHZhbHVlLlxuXHRcdFx0Ly8gQWxzbyB1cGRhdGUgZGV2aWNlU3RhdGUgb3B0aW1pc3RpY2FsbHkgc28gY29uc2VjdXRpdmUgQ01EX01JQ19QUkUgY29tbWFuZHMgY2hhaW4gY29ycmVjdGx5LlxuXHRcdFx0aWYgKCF0aGlzLmRldmljZVN0YXRlLmhhcyhkZXN0SXApKSB0aGlzLmRldmljZVN0YXRlLnNldChkZXN0SXAsIG5ldyBNYXAoKSlcblx0XHRcdGNvbnN0IGlwU3RhdGUgPSB0aGlzLmRldmljZVN0YXRlLmdldChkZXN0SXApIVxuXHRcdFx0Y29uc3QgbnVtUG9zaXRpb25zID0gMyAvLyBnYWluLCBlbGVjdHJldC9waGFudG9tLCB1bmtub3duXG5cdFx0XHRjb25zdCBwb3NpdGlvbnM6IG51bWJlcltdID0gW11cblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgbnVtUG9zaXRpb25zOyBpKyspIHtcblx0XHRcdFx0Y29uc3Qgc3RhdGVLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIENNRF9NSUNfUFJFLCBpLCBidXNDaClcblx0XHRcdFx0Y29uc3QgdmFsID0gaSA9PT0gc2V0dGluZ0lkID8gTnVtYmVyKHZhbHVlKSA6IChpcFN0YXRlLmdldChzdGF0ZUtleSkgPz8gMClcblx0XHRcdFx0cG9zaXRpb25zLnB1c2godmFsKVxuXHRcdFx0XHRpcFN0YXRlLnNldChzdGF0ZUtleSwgdmFsKSAvLyBvcHRpbWlzdGljIHVwZGF0ZVxuXHRcdFx0fVxuXHRcdFx0cGF5bG9hZEJvZHkucHVzaChidXNDaCAmIDB4ZmYsIC4uLnBvc2l0aW9ucylcblx0XHR9IGVsc2Uge1xuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHBheWxvYWRCb2R5LnB1c2goYnVzQ2ggJiAweGZmKVxuXHRcdFx0aWYgKGFkZExlbikgcGF5bG9hZEJvZHkucHVzaChkYXRhQmxvY2subGVuZ3RoKVxuXHRcdFx0aWYgKGRhdGFCbG9jay5sZW5ndGggPiAwKSBwYXlsb2FkQm9keS5wdXNoKC4uLmRhdGFCbG9jaylcblx0XHR9XG5cblx0XHRjb25zdCBjcmMgPSBTdENvbnRyb2xsZXIuY3JjOER2YlMyKHBheWxvYWRCb2R5KVxuXHRcdGNvbnN0IHBheWxvYWRXaXRoQ3JjID0gQnVmZmVyLmZyb20oWy4uLnBheWxvYWRCb2R5LCBjcmNdKVxuXG5cdFx0Ly8gSHVtYW4tcmVhZGFibGUgaW5mbyBsb2cgZm9yIHRoZSBvdXRnb2luZyBjb21tYW5kXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkICYmIHZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBTdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKVxuXHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHtcblx0XHRcdFx0Y21kX2lkOiBjbWRJZCxcblx0XHRcdFx0aWQ6IHNldHRpbmdJZCxcblx0XHRcdFx0YnVzQ2gsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmcsIHRoaXMuYWN0aW9ucyl9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFRYICR7ZGVzdElwfSB8ICR7Z2V0Q29tbWFuZE5hbWUoY21kSWQpfWApXG5cdFx0fVxuXG5cdFx0Ly8gUmVqZWN0IGNvbW1hbmRzIHRvIHVudmVyaWZpZWQgZGV2aWNlcyBcdTIwMTQgbG9nIHRoZSB3b3VsZC1iZSBwYWNrZXQgZmlyc3QgYXQgZGVidWdcblx0XHQvLyBzbyB0aGUgYnl0ZXMgYXJlIHZpc2libGUgZXZlbiB3aGVuIHRoZSBkZXZpY2UgaXMgb2ZmbGluZS5cblx0XHRpZiAoIXRoaXMuYXV0aG9yaXplZElwcy5oYXMoZGVzdElwKSkge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBQYWNrZXQgKG5vdCBzZW50IFx1MjAxNCBkZXZpY2Ugbm90IGF1dGhvcml6ZWQpIHRvICR7ZGVzdElwfTogJHtwYXlsb2FkV2l0aENyYy50b1N0cmluZygnaGV4Jyl9YClcblx0XHRcdHRocm93IG5ldyBFcnJvcihgRGV2aWNlIGF0ICR7ZGVzdElwfSBpcyBub3QgYXV0aG9yaXplZCBcdTIwMTQgdmVyaWZ5IHRoZSBJUCBhbmQgbW9kZWwgbWF0Y2ggYmVmb3JlIHNlbmRpbmcgY29tbWFuZHNgKVxuXHRcdH1cblxuXHRcdC8vIEVuc3VyZSB3ZSBhcmUgbGlzdGVuaW5nIGZvciByZXBsaWVzIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCB3aWxsIHJlY2VpdmUgdGhlbVxuXHRcdGF3YWl0IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApXG5cblx0XHRjb25zdCB0b3RhbExlbiA9IDI0ICsgcGF5bG9hZFdpdGhDcmMubGVuZ3RoXG5cdFx0Y29uc3QgaGVhZGVyID0gYXdhaXQgdGhpcy5idWlsZEhlYWRlcih0b3RhbExlbiwgZGVzdElwKVxuXHRcdGNvbnN0IHBhY2tldCA9IEJ1ZmZlci5jb25jYXQoW2hlYWRlciwgcGF5bG9hZFdpdGhDcmNdKVxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBTZW5kaW5nIHBhY2tldCB0byAke2Rlc3RJcH06ICR7cGFja2V0LnRvU3RyaW5nKCdoZXgnKX1gKVxuXG5cdFx0Y29uc3Qga2V5ID0gYCR7ZGVzdElwfToke2NtZElkfWBcblxuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgVGltZW91dCB3YWl0aW5nIGZvciBBQ0sgZnJvbSBNb2RlbCAke3RoaXMubW9kZWx9IGF0ICR7ZGVzdElwfTo4NzAwYCkpXG5cdFx0XHR9LCB0aW1lb3V0TXMpXG5cblx0XHRcdHRoaXMucGVuZGluZ0Fja3Muc2V0KGtleSwge1xuXHRcdFx0XHRyZXNvbHZlOiAoYnVmKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHRyZWplY3Q6IChlcnIpID0+IHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KGVycilcblx0XHRcdFx0fSxcblx0XHRcdFx0dGltZXIsXG5cdFx0XHR9KVxuXG5cdFx0XHR0aGlzLnR4U29ja2V0LnNlbmQocGFja2V0LCB0aGlzLmRlZmF1bHRQb3J0LCBkZXN0SXAsIChlcnIpID0+IHtcblx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgaGFuZGxlSW5jb21pbmcobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpIHtcblx0XHRpZiAobXNnLmxlbmd0aCA8IDQpIHJldHVyblxuXHRcdGlmIChtc2dbMF0gIT09IDB4ZmYgfHwgbXNnWzFdICE9PSAweGZmKSByZXR1cm5cblxuXHRcdGNvbnN0IG1zZ1R5cGUgPSBtc2cucmVhZFVJbnQxNkJFKDIpXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgKDB4MDE3MCkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gVGhlc2UgaGF2ZSBcIkF1ZGluYXRlXCIgYXQgb2Zmc2V0IDE2LCBub3QgXCJTdHVkaW8tVFwiIFx1MjAxNCBoYW5kbGUgYmVmb3JlXG5cdFx0Ly8gdGhlIFN0dWRpby1UIHNpZ25hdHVyZSBjaGVjayBiZWxvdy5cblx0XHRpZiAobXNnVHlwZSA9PT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgJiYgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2l6ZSA+IDApIHtcblx0XHRcdGNvbnN0IGRldmljZSA9IHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnLCBzcmNJcClcblx0XHRcdGlmIChkZXZpY2UpIHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKFxuXHRcdFx0XHRcdGBEYW50ZSBpbmZvIHJlc3BvbnNlIGZyb20gJHtzcmNJcH06IGAgK1xuXHRcdFx0XHRcdFx0YERldmljZUlEPVwiJHtkZXZpY2UubmFtZX1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTW9kZWw9XCIke2RldmljZS5tb2RlbH1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTW9kZWxOYW1lPVwiJHtkZXZpY2UubW9kZWxOYW1lfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNYW51ZmFjdHVyZXI9XCIke2RldmljZS5tYW51ZmFjdHVyZXJ9XCJgLFxuXHRcdFx0XHQpXG5cblx0XHRcdFx0Ly8gT25seSBhY2NlcHQgU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2VzIChpZGVudGlmaWVkIGJ5IERldmljZUlEIFwiU3R1ZGlvLVRcIilcblx0XHRcdFx0aWYgKGRldmljZS5uYW1lID09PSAnU3R1ZGlvLVQnKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjYiBvZiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy52YWx1ZXMoKSkge1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0Y2IoZGV2aWNlKVxuXHRcdFx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYElnbm9yaW5nIG5vbi1TdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZTogRGV2aWNlSUQ9XCIke2RldmljZS5uYW1lfVwiIEAgJHtzcmNJcH1gKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAobXNnLmxlbmd0aCA8IDI1KSByZXR1cm5cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBTdHVkaW8tVCBjb250cm9sIHByb3RvY29sIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGNvbnN0IHNpZyA9IG1zZy5zdWJhcnJheSgxNiwgMjQpXG5cdFx0aWYgKHNpZy50b1N0cmluZygnYXNjaWknKSAhPT0gJ1N0dWRpby1UJykgcmV0dXJuXG5cblx0XHQvLyBQYXlsb2FkIHN0YXJ0cyBhdCBvZmZzZXQgMjRcblx0XHQvLyBMYXlvdXQ6IFsweDVhXSBbY21kSWR8MHg4MF0gW2RhdGEuLi5dIFtjcmNdXG5cdFx0Y29uc3Qgc3RQYXlsb2FkID0gbXNnLnN1YmFycmF5KDI0KVxuXHRcdGlmIChzdFBheWxvYWQubGVuZ3RoIDwgMikgcmV0dXJuXG5cdFx0aWYgKHN0UGF5bG9hZFswXSAhPT0gMHg1YSkgcmV0dXJuXG5cblx0XHQvLyBEZXZpY2UgcmVwbGllcyB3aXRoIGNtZCB8IDB4ODBcblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBpc1Jlc3BvbnNlID0gKHJlc3BDbWRJZCAmIDB4ODApICE9PSAwXG5cdFx0Y29uc3Qgb3JpZ2luYWxDbWRJZCA9IHJlc3BDbWRJZCAmIDB4N2YgLy8gc3RyaXAgdGhlIHJlc3BvbnNlIGZsYWdcblxuXHRcdC8vIExvZyByYXcgcGFja2V0IGZvciBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgcmVzcG9uc2VzIGJlZm9yZSBwYXJzaW5nXG5cdFx0aWYgKGlzUmVzcG9uc2UgJiYgb3JpZ2luYWxDbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MpIHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUmVjZWl2ZWQgcGFja2V0IGZyb20gJHtzcmNJcH06ICR7bXNnLnRvU3RyaW5nKCdoZXgnKX1gKVxuXHRcdH1cblxuXHRcdC8vIExvZyB0aGUgcGF5bG9hZCAod29ya3MgZm9yIGJvdGggcmVxdWVzdHMgYW5kIHJlc3BvbnNlcylcblx0XHR0aGlzLmxvZ1N0UGF5bG9hZChzcmNJcCwgb3JpZ2luYWxDbWRJZCwgbXNnLCBzdFBheWxvYWQpXG5cblx0XHQvLyBPbmx5IHByb2Nlc3MgYXMgQUNLIGlmIHRoaXMgaXMgYSByZXNwb25zZSB0byBvdXIgcmVxdWVzdFxuXHRcdGlmIChpc1Jlc3BvbnNlKSB7XG5cdFx0XHRjb25zdCBrZXkgPSBgJHtzcmNJcH06JHtvcmlnaW5hbENtZElkfWBcblx0XHRcdGNvbnN0IHBlbmRpbmcgPSB0aGlzLnBlbmRpbmdBY2tzLmdldChrZXkpXG5cdFx0XHRpZiAocGVuZGluZykge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHBlbmRpbmcucmVzb2x2ZShtc2cpXG5cdFx0XHR9XG5cdFx0fVxuXHRcdC8vIFVuc29saWNpdGVkIG1lc3NhZ2VzIGFuZCByZXF1ZXN0cyBmcm9tIG90aGVyIHNvdXJjZXMgYXJlIGxvZ2dlZCBhYm92ZVxuXHR9XG5cblx0LyoqXG5cdCAqIERlY29kZXMgYW5kIGxvZ3MgYSBTdHVkaW8tVCByZXNwb25zZSBwYXlsb2FkLlxuXHQgKiBSZWNlaXZlcyBib3RoIHRoZSBmdWxsIG1zZyAoZm9yIHBhcnNlcnMgdGhhdCBuZWVkIHRoZSBTdHVkaW8tVCBoZWFkZXIpXG5cdCAqIGFuZCBzdFBheWxvYWQgKG1zZy5zdWJhcnJheSgyNCksIGZvciBkaXJlY3QgYnl0ZSBhY2Nlc3MpLlxuXHQgKlxuXHQgKiBzdFBheWxvYWQgbGF5b3V0OlxuXHQgKiAgIFswXSAgICAgIDB4NWEgIG1hZ2ljXG5cdCAqICAgWzFdICAgICAgY21kSWQgfCAweDgwXG5cdCAqICAgWzIuLi0yXSAgZGF0YSBieXRlc1xuXHQgKiAgIFstMV0gICAgIENSQy04L0RWQi1TMlxuXHQgKi9cblx0cHJpdmF0ZSBsb2dTdFBheWxvYWQoc3JjSXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgbXNnOiBCdWZmZXIsIHN0UGF5bG9hZDogQnVmZmVyKTogdm9pZCB7XG5cdFx0Y29uc3QgY21kTmFtZSA9IGdldENvbW1hbmROYW1lKGNtZElkKVxuXHRcdGNvbnN0IGRhdGEgPSBzdFBheWxvYWQuc3ViYXJyYXkoMiwgc3RQYXlsb2FkLmxlbmd0aCAtIDEpIC8vIHN0cmlwIG1hZ2ljK2NtZElkIGhlYWRlciBhbmQgQ1JDXG5cblx0XHQvLyBQYXlsb2FkIHN0cnVjdHVyZTogW2NtZDoweDhkXSBbZGF0YSBieXRlcy4uLl0gW2NyY11cblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBjcmMgPSBzdFBheWxvYWRbc3RQYXlsb2FkLmxlbmd0aCAtIDFdXG5cdFx0Y29uc3QgZnVsbFN0cnVjdHVyZSA9IGBbY21kOiR7dG9IZXgocmVzcENtZElkKX0gZGF0YToke2RhdGEudG9TdHJpbmcoJ2hleCcpfSBjcmM6JHt0b0hleChjcmMpfV1gXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIGFuZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gUGFyc2UgYWxsIHNldHRpbmdzLCBkaWZmIGFnYWluc3QgZGV2aWNlU3RhdGUsIGxvZyBjaGFuZ2VkIGF0IGluZm8gLyB1bmNoYW5nZWQgYXQgZGVidWcsXG5cdFx0Ly8gdGhlbiB1cGRhdGUgZGV2aWNlU3RhdGUuIENNRF9HRVRfQUxMX1NFVFRJTkdTIGFsc28gc2VydmVzIGFzIHRoZSBpbml0aWFsIHN0YXRlIHBvcHVsYXRpb24gb24gY29ubmVjdC5cblx0XHRpZiAoY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTIHx8IGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0aWYgKCF0aGlzLm1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5ncyA9XG5cdFx0XHRcdFx0Y21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIXG5cdFx0XHRcdFx0XHQ/IHBhcnNlU2V0dGluZ3NSZXNwb25zZSh0aGlzLm1vZGVsLCBtc2cpXG5cdFx0XHRcdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCh0aGlzLm1vZGVsLCBtc2cpXG5cblx0XHRcdFx0Y29uc3QgcHJldlN0YXRlID0gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoc3JjSXApID8/IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0XHRcdFx0Y29uc3QgbmV3U3RhdGUgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPihwcmV2U3RhdGUpIC8vIGNvcHkgXHUyMDE0IHVwZGF0ZSBpbiBwbGFjZVxuXG5cdFx0XHRcdGZvciAoY29uc3QgcyBvZiBzZXR0aW5ncykge1xuXHRcdFx0XHRcdGNvbnN0IHN0YXRlS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgcy5pZCwgcy5idXNDaClcblx0XHRcdFx0XHQvLyBGb3IgUkdCIGNvbG9ycyAoMyBieXRlcyksIHBhY2sgaW50byBzaW5nbGUgbnVtYmVyOiAoUiA8PCAxNikgfCAoRyA8PCA4KSB8IEJcblx0XHRcdFx0XHRjb25zdCBuZXdWYWx1ZSA9XG5cdFx0XHRcdFx0XHRzLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHRcdFx0XHRcdD8gKHMudmFsdWVCeXRlc1swXSA8PCAxNikgfCAocy52YWx1ZUJ5dGVzWzFdIDw8IDgpIHwgcy52YWx1ZUJ5dGVzWzJdXG5cdFx0XHRcdFx0XHRcdDogKHMudmFsdWVCeXRlc1swXSA/PyAwKVxuXHRcdFx0XHRcdGNvbnN0IHByZXZWYWx1ZSA9IHByZXZTdGF0ZS5nZXQoc3RhdGVLZXkpXG5cdFx0XHRcdFx0Y29uc3QgY2hhbmdlZCA9IHByZXZWYWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHByZXZWYWx1ZSAhPT0gbmV3VmFsdWVcblxuXHRcdFx0XHRcdG5ld1N0YXRlLnNldChzdGF0ZUtleSwgbmV3VmFsdWUpXG5cblx0XHRcdFx0XHRjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXRQYXJzZWRTZXR0aW5nKHMsIHRoaXMuYWN0aW9ucylcblx0XHRcdFx0XHRpZiAoY2hhbmdlZCkge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmluZm8oYFJYICR7c3JjSXB9IHwgJHtmb3JtYXR0ZWR9YClcblx0XHRcdFx0XHRcdC8vIFRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlIFx1MjAxNCB1c2UgYmFzZSBrZXkgd2l0aG91dCBidXNDaCBzbyBpdCBtYXRjaGVzIHRoZSBmZWVkYmFjayBkZWZpbml0aW9uIElEXG5cdFx0XHRcdFx0XHRpZiAodGhpcy5mZWVkYmFja0NhbGxiYWNrKSB7XG5cdFx0XHRcdFx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0tleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgcy5jbWRfaWQsIHMuaWQpXG5cdFx0XHRcdFx0XHRcdC8vbG9nZ2VyLmRlYnVnKGBUcmlnZ2VyaW5nIGZlZWRiYWNrIHVwZGF0ZSBmb3Iga2V5OiAke2Jhc2VGZWVkYmFja0tleX1gKVxuXHRcdFx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soYmFzZUZlZWRiYWNrS2V5KVxuXHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYGZlZWRiYWNrQ2FsbGJhY2sgbm90IHNldCBcdTIwMTQgc2tpcHBpbmcgZmVlZGJhY2sgdXBkYXRlIGZvciAke3N0YXRlS2V5fWApXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLmRldmljZVN0YXRlLnNldChzcmNJcCwgbmV3U3RhdGUpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCBwYXJzZSBmYWlsZWQ6ICR7ZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBBbGwgb3RoZXIgY29tbWFuZHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Y29uc3QgZGVjb2RlZCA9IHRoaXMuZGVjb2RlU3REYXRhKGNtZElkLCBkYXRhKVxuXHRcdC8vIENNRF9CVVNfR0VUIChrZWVwYWxpdmUpIGlzIGhpZ2gtZnJlcXVlbmN5IG5vaXNlIFx1MjAxNCBsb2cgYXQgZGVidWcgb25seVxuXHRcdGNvbnN0IGxvZ0ZuID0gY21kSWQgPT09IENNRF9CVVNfR0VUID8gbG9nZ2VyLmRlYnVnLmJpbmQobG9nZ2VyKSA6IGxvZ2dlci5pbmZvLmJpbmQobG9nZ2VyKVxuXHRcdGlmIChkZWNvZGVkKSB7XG5cdFx0XHRsb2dGbihgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfSB8ICR7ZGVjb2RlZH1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dGbihgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEF0dGVtcHRzIHRvIGRlY29kZSB0aGUgZGF0YSBieXRlcyBvZiBhIFN0dWRpby1UIHJlc3BvbnNlIGludG8gYVxuXHQgKiBodW1hbi1yZWFkYWJsZSBzdHJpbmcuIFJldHVybnMgbnVsbCB0byBmYWxsIGJhY2sgdG8gcmF3IGhleC5cblx0ICovXG5cdHByaXZhdGUgZGVjb2RlU3REYXRhKGNtZElkOiBudW1iZXIsIGRhdGE6IEJ1ZmZlcik6IHN0cmluZyB8IG51bGwge1xuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMCkgcmV0dXJuICdBQ0snXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ2hlY2sgZm9yIHNpbmdsZS1ieXRlIHJlc3BvbnNlcyAoQUNLIG9yIGVycm9yKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdGlmIChkYXRhWzBdID09PSAweDAwKSB7XG5cdFx0XHRcdHJldHVybiAnQUNLIG9rJ1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0cmV0dXJuIGBFUlJPUiAke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdH1cblx0XHR9XG5cblx0XHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX01JQ19QUkUgKDB4MDIpOiByYXcgcHJlYW1wIGVjaG8gXHUyMDE0IHBvc2l0aW9uYWwgYnl0ZXMsIG5vIHNldHRpbmcgSURzIFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gRGV2aWNlIGVjaG9lcyBbYnVzQ2hdW3ZhbDBdW3ZhbDFdLi4uIGNvbmZpcm1pbmcgdGhlIGFwcGxpZWQgdmFsdWVzLlxuXHRcdFx0Y2FzZSBDTURfTUlDX1BSRToge1xuXHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0Y29uc3QgdmFscyA9IEFycmF5LmZyb20oZGF0YS5zdWJhcnJheSgxKSlcblx0XHRcdFx0XHQubWFwKChiLCBpKSA9PiBgWyR7aX1dPTB4JHtiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfSgke2J9KWApXG5cdFx0XHRcdFx0LmpvaW4oJyAnKVxuXHRcdFx0XHRyZXR1cm4gYGNoPSR7YnVzQ2h9ICR7dmFsc31gXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfREVWX1NQRUMgKDB4MGQpOiBzaW5nbGUtYnl0ZSBBQ0sgb3IgZWNobyBvZiBhcHBsaWVkIHNldHRpbmcgXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBEZXZpY2Ugc2VuZHMgdHdvIENNRF9ERVZfU1BFQyBwYWNrZXRzIGluIHJlc3BvbnNlIHRvIGEgc2V0OlxuXHRcdFx0Ly8gICAxLiBBQ0s6ICBbc3RhdHVzXSAgICAgICAgICAgICAgICgxIGJ5dGUsIDB4MDAgPSBvaylcblx0XHRcdC8vICAgMi4gRWNobzogW2J1c0NoXSBbc2V0dGluZ0lkXSBbdmFsdWUuLi5dICAoY29uZmlybWluZyB3aGF0IHdhcyBhcHBsaWVkKVxuXHRcdFx0Y2FzZSBDTURfREVWX1NQRUM6IHtcblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGRhdGFbMF0gPT09IDB4MDAgPyAnQUNLIG9rJyA6IGBBQ0sgZXJyPSR7dG9IZXgoZGF0YVswXSl9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfWBcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VzID0gYWN0aW9uPy5vcHRpb25zPy5bMF0/LmNob2ljZXNcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID1cblx0XHRcdFx0XHRcdGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlU3RyID0gY2hvaWNlTGFiZWwgPyBgJHtjaG9pY2VMYWJlbH0gKCR7dG9IZXgodmFsdWVOdW0hKX0pYCA6IGJ5dGVzVG9IZXgoQXJyYXkuZnJvbSh2YWx1ZUJ5dGVzKSlcblx0XHRcdFx0XHRjb25zdCByYXdUYWcgPSBgWyR7dG9IZXgoY21kSWQpfS8ke3RvSGV4KHNldHRpbmdJZCl9XT0ke2J5dGVzVG9IZXgoQXJyYXkuZnJvbSh2YWx1ZUJ5dGVzKSl9YFxuXHRcdFx0XHRcdHJldHVybiBgZWNobyBjaD0ke2J1c0NofSB8ICR7c2V0dGluZ05hbWV9OiAke3ZhbHVlU3RyfSAke3Jhd1RhZ31gXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGByYXc6ICR7ZGF0YS50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0fVxuXG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX01JQ19QUkVfQlVTICgweDEyKTogTXVsdGktYnl0ZSBlY2hvIHJlc3BvbnNlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdGNhc2UgQ01EX01JQ19QUkVfQlVTOiB7XG5cdFx0XHRcdC8vIEFscmVhZHkgaGFuZGxlZCBzaW5nbGUtYnl0ZSBhYm92ZSwgc28gbXVsdGktYnl0ZSBtdXN0IGJlIGVjaG9cblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID49IDMpIHtcblx0XHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0XHRjb25zdCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyBgc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9YFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlTnVtID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlcyA9IGFjdGlvbj8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJyk/LmNob2ljZXNcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9XG5cdFx0XHRcdFx0XHRjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVN0ciA9IGNob2ljZUxhYmVsID8/IGAweCR7dmFsdWVCeXRlcy50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0XHRcdHJldHVybiBgZWNobyBjaD0ke2J1c0NofSB8ICR7c2V0dGluZ05hbWV9OiAke3ZhbHVlU3RyfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gbnVsbFxuXHRcdFx0fVxuXG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQnVzLXNjb3BlZCBnZXQvc2V0IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdGNhc2UgQ01EX0JVU19TRVQ6IHtcblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoIDwgMikgcmV0dXJuIG51bGxcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdHJldHVybiBgY2g9JHtidXNDaH0gc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9IHZhbHVlPSR7dmFsdWUudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0cmV0dXJuIG51bGwgLy8gZmFsbCB0aHJvdWdoIHRvIHJhdyBoZXhcblx0XHR9XG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBidWlsZFZhbHVlQnl0ZXModmFsdWU6IHVua25vd24pOiBudW1iZXJbXSB7XG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gW3ZhbHVlID8gMSA6IDBdXG5cdFx0aWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSByZXR1cm4gdmFsdWUubWFwKCh2KSA9PiBOdW1iZXIodikgJiAweGZmKVxuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG5cdFx0XHRpZiAodmFsdWUgPiAweGZmKSByZXR1cm4gWyh2YWx1ZSA+PiAxNikgJiAweGZmLCAodmFsdWUgPj4gOCkgJiAweGZmLCB2YWx1ZSAmIDB4ZmZdXG5cdFx0XHRyZXR1cm4gW3ZhbHVlICYgMHhmZl1cblx0XHR9XG5cdFx0dGhyb3cgbmV3IEVycm9yKGBVbnN1cHBvcnRlZCB2YWx1ZSB0eXBlIGZvciBTVGNvbnRyb2xsZXI6ICR7dmFsdWV9YClcblx0fVxuXG5cdHByaXZhdGUgYXN5bmMgYnVpbGRIZWFkZXIodG90YWxMZW46IG51bWJlciwgZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGxldCBtYWMgPSB0aGlzLm1hY0NhY2hlLmdldChkZXN0SXApXG5cdFx0aWYgKCFtYWMpIHtcblx0XHRcdG1hYyA9IGF3YWl0IGdldE1hY0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblx0XHRcdHRoaXMubWFjQ2FjaGUuc2V0KGRlc3RJcCwgbWFjKVxuXHRcdH1cblxuXHRcdHJldHVybiBCdWZmZXIuY29uY2F0KFtcblx0XHRcdEJ1ZmZlci5mcm9tKFsweGZmLCAweGZmLCAweDAwLCB0b3RhbExlbiAmIDB4ZmYsIDB4MDcsIDB4ZTEsIDB4MDAsIDB4MDAsIC4uLm1hYywgMHgwMCwgMHgwMF0pLFxuXHRcdFx0QnVmZmVyLmZyb20oJ1N0dWRpby1UJywgJ3V0ZjgnKSxcblx0XHRdKVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgY3JjOER2YlMyKGRhdGE6IG51bWJlcltdKTogbnVtYmVyIHtcblx0XHRsZXQgY3JjID0gMFxuXHRcdGZvciAoY29uc3QgYiBvZiBkYXRhKSB7XG5cdFx0XHRjcmMgXj0gYlxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCA4OyBpKyspIHtcblx0XHRcdFx0Y3JjID0gKGNyYyAmIDB4ODApICE9PSAwID8gKChjcmMgPDwgMSkgXiAweGQ1KSAmIDB4ZmYgOiAoY3JjIDw8IDEpICYgMHhmZlxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gY3JjXG5cdH1cblxuXHQvKipcblx0ICogUmV0dXJucyB0aGUgY3VycmVudCBrbm93biB2YWx1ZSBmb3IgYSBzZXR0aW5nIG9uIGEgZGV2aWNlLCBvciB1bmRlZmluZWQgaWYgdW5rbm93bi5cblx0ICogVXNlIGZvciBmZWVkYmFja3MgXHUyMDE0IHZhbHVlIGlzIHVwZGF0ZWQgb24gZXZlcnkgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpIGZyb20gdGhlIGRldmljZS5cblx0ICpcblx0ICogQHBhcmFtIGlwICAgICAgICBEZXZpY2UgSVAgYWRkcmVzc1xuXHQgKiBAcGFyYW0gY21kSWQgICAgIENvbW1hbmQgSUQgKGUuZy4gQ01EX0RFVl9TUEVDKVxuXHQgKiBAcGFyYW0gc2V0dGluZ0lkIFNldHRpbmcgSUQgKGUuZy4gMHgwMiBmb3IgQ29udHJvbCBTb3VyY2UpXG5cdCAqIEBwYXJhbSBidXNDaCAgICAgT3B0aW9uYWwgYnVzL2NoYW5uZWwgSUQgZm9yIG11bHRpLWNoYW5uZWwgY29tbWFuZHNcblx0ICovXG5cdHB1YmxpYyBnZXRTZXR0aW5nVmFsdWUoaXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgc2V0dGluZ0lkOiBudW1iZXIsIGJ1c0NoPzogbnVtYmVyKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcblx0XHRjb25zdCBrZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXHRcdHJldHVybiB0aGlzLmRldmljZVN0YXRlLmdldChpcCk/LmdldChrZXkpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgcmVzZXREZXZpY2UoZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHJldHVybiB0aGlzLnNlbmRBd2FpdEFjayhDTURfUkVTRVRfREVWSUNFLCB1bmRlZmluZWQsIDB4MDAsIHVuZGVmaW5lZCwgZGVzdElwLCBmYWxzZSlcblx0fVxuXG5cdHB1YmxpYyBhc3luYyBnbG9iYWxNaWNLaWxsKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5zZW5kQXdhaXRBY2soQ01EX0dMT0JBTF9NSUNfS0lMTCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGVzdElwLCBmYWxzZSlcblx0fVxufVxuIiwgImltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSdcbmltcG9ydCBvcyBmcm9tICdvcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IERldmljZUluZm8gfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ0RhbnRlJylcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIERhbnRlIGRpc2NvdmVyeSBjb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKiBEYW50ZSBkZXZpY2UgaW5mbyByZXF1ZXN0IG1lc3NhZ2UgdHlwZSAoc2VudCB0byBwb3J0IDg3MDApICovXG5leHBvcnQgY29uc3QgREFOVEVfTVNHX0lORk9fUkVRVUVTVCA9IDB4MDAyMFxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlIG1lc3NhZ2UgdHlwZSAocmVjZWl2ZWQgb24gcG9ydCA4NzAyKSAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX01TR19JTkZPX1JFU1BPTlNFID0gMHgwMTcwXG5cbi8qKlxuICogRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgbGF5b3V0IChhbGwgb2Zmc2V0cyBhcmUgaW50byB0aGUgVURQIHBheWxvYWQpOlxuICogICAweDAwICB1aW50MTZCRSAgTWFnaWMgKDB4ZmZmZilcbiAqICAgMHgwMiAgdWludDE2QkUgIE1lc3NhZ2UgdHlwZSAoMHgwMTcwKVxuICogICAweDA0ICB1aW50MTZCRSAgU2VxdWVuY2UgbnVtYmVyXG4gKiAgIDB4MDYgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MDggIDggYnl0ZXMgICBFVUktNjQgKHNvdXJjZSBNQUMgd2l0aCBmZjpmZSBpbnNlcnRlZCBtaWQpXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgQVNDSUkgaWRlbnRpZmllclxuICogICAweDE4ICAyIGJ5dGVzICAgRGFudGUgbW9kdWxlIGZpcm13YXJlIHZlcnNpb24gKG1ham9yLCBtaW5vcilcbiAqICAgMHgyMCAgMzEgYnl0ZXMgIERldmljZSBuYW1lLCBudWxsLXBhZGRlZCBBU0NJSSAobWF4IDMxIGNoYXJzIHBlciBEYW50ZSBzcGVjKVxuICogICAweDJlICB1aW50MTZCRSAgUHJvZHVjdCBJRFxuICogICAweDRjICA2NCBieXRlcyAgTWFudWZhY3R1cmVyIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqICAgMHhjYyAgNjQgYnl0ZXMgIE1vZGVsIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX0lORk9fTUlOX0xFTiA9IDB4Y2MgKyA2NCAvLyAyNjggYnl0ZXMgXHUyMDE0IG5lZWQgZnVsbCBtb2RlbCBmaWVsZFxuXG4vKipcbiAqIEJ1aWxkcyBhIERhbnRlIGRldmljZSBpbmZvIHJlcXVlc3QgcGFja2V0ICh0eXBlIDB4MDAyMCkuXG4gKlxuICogUGFja2V0IGxheW91dCAoMzIgYnl0ZXMpIFx1MjAxNCBkZXJpdmVkIGZyb20gbGl2ZSBjYXB0dXJlIGFuYWx5c2lzOlxuICogICAweDAwICB1aW50MTZCRSAgTWFnaWMgKDB4ZmZmZilcbiAqICAgMHgwMiAgdWludDE2QkUgIE1lc3NhZ2UgdHlwZSAoMHgwMDIwID0gZGV2aWNlIGluZm8gcmVxdWVzdClcbiAqICAgMHgwNCAgdWludDE2QkUgIFNlcXVlbmNlIG51bWJlciAocmFuZG9tKVxuICogICAweDA2ICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDA4ICA2IGJ5dGVzICAgU291cmNlIE1BQ1xuICogICAweDBlICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIEFTQ0lJIGlkZW50aWZpZXJcbiAqICAgMHgxOCAgMiBieXRlcyAgIFByb3RvY29sIHZlcnNpb24gKDB4MDczOSlcbiAqICAgMHgxYSAgMiBieXRlcyAgIFN1Yi10eXBlICgweDAwYzEpXG4gKiAgIDB4MWMgIHVpbnQzMkJFICBDYXBhYmlsaXR5IG1hc2sgKDB4MDAwZjQyNDApXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidWlsZERhbnRlSW5mb1JlcXVlc3QoKTogQnVmZmVyIHtcblx0Y29uc3QgYnVmID0gQnVmZmVyLmFsbG9jKDMyLCAwKVxuXHRjb25zdCBzZXEgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAweGZmZmYpXG5cblx0YnVmLndyaXRlVUludDE2QkUoMHhmZmZmLCAwKVxuXHRidWYud3JpdGVVSW50MTZCRShEQU5URV9NU0dfSU5GT19SRVFVRVNULCAyKVxuXHRidWYud3JpdGVVSW50MTZCRShzZXEsIDQpXG5cblx0Y29uc3QgbWFjID0gZ2V0Rmlyc3RMb2NhbE1hYygpXG5cdG1hYy5jb3B5KGJ1ZiwgOClcblxuXHRCdWZmZXIuZnJvbSgnQXVkaW5hdGUnLCAnYXNjaWknKS5jb3B5KGJ1ZiwgMTYpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4MDczOSwgMjQpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4MDBjMSwgMjYpXG5cdGJ1Zi53cml0ZVVJbnQzMkJFKDB4MDAwZjQyNDAsIDI4KVxuXG5cdHJldHVybiBidWZcbn1cblxuLyoqIFJldHVybnMgdGhlIGZpcnN0IG5vbi1sb29wYmFjayBNQUMgYXMgYSA2LWJ5dGUgQnVmZmVyLCBvciB6ZXJvcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRGaXJzdExvY2FsTWFjKCk6IEJ1ZmZlciB7XG5cdHRyeSB7XG5cdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRmb3IgKGNvbnN0IGFkZHIgb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdGlmICghYWRkci5pbnRlcm5hbCAmJiBhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmIGFkZHIubWFjICYmIGFkZHIubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnKSB7XG5cdFx0XHRcdFx0cmV0dXJuIEJ1ZmZlci5mcm9tKGFkZHIubWFjLnNwbGl0KCc6JykubWFwKChoOiBzdHJpbmcpID0+IHBhcnNlSW50KGgsIDE2KSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH0gY2F0Y2gge1xuXHRcdC8qIGlnbm9yZSAqL1xuXHR9XG5cdHJldHVybiBCdWZmZXIuYWxsb2MoNiwgMClcbn1cblxuLyoqXG4gKiBQYXJzZXMgYSBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSAodHlwZSAweDAxNzApIGludG8gYSBEZXZpY2VJbmZvLlxuICpcbiAqIFJlc3BvbnNlIGxheW91dCAoa2V5IG9mZnNldHMpOlxuICogICAweDA4ICA4IGJ5dGVzICAgRVVJLTY0IFx1MjAxNCBjb252ZXJ0IHRvIE1BQyBieSBkcm9wcGluZyBieXRlcyBbM10gYW5kIFs0XSAoZmY6ZmUpXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgaWRlbnRpZmllciAodXNlZCB0byB2ZXJpZnkgdGhpcyBpcyBhIHJlYWwgcmVzcG9uc2UpXG4gKiAgIDB4MTggIDEgYnl0ZSAgICBEYW50ZSBGVyBtYWpvclxuICogICAweDE5ICAxIGJ5dGUgICAgRGFudGUgRlcgbWlub3JcbiAqICAgMHgyMCAgMzEgYnl0ZXMgIERldmljZSBuYW1lIChEYW50ZSBsYWJlbCksIG51bGwtcGFkZGVkIEFTQ0lJIChtYXggMzEgY2hhcnMpXG4gKiAgIDB4MmUgIHVpbnQxNkJFICBQcm9kdWN0IElEXG4gKiAgIDB4NGMgIDY0IGJ5dGVzICBNYW51ZmFjdHVyZXIsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKiAgIDB4Y2MgIDY0IGJ5dGVzICBNb2RlbCBzdHJpbmcsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKlxuICogUmV0dXJucyBudWxsIGlmIGJ1ZmZlciBpcyB0b28gc2hvcnQsIHdyb25nIG1hZ2ljLCBvciBtaXNzaW5nIG1vZGVsIHN0cmluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpOiBEZXZpY2VJbmZvIHwgbnVsbCB7XG5cdGlmIChtc2cubGVuZ3RoIDwgREFOVEVfSU5GT19NSU5fTEVOKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgwKSAhPT0gMHhmZmZmKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgyKSAhPT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UpIHJldHVybiBudWxsXG5cdGlmIChtc2cuc3ViYXJyYXkoMTYsIDI0KS50b1N0cmluZygnYXNjaWknKSAhPT0gJ0F1ZGluYXRlJykgcmV0dXJuIG51bGxcblxuXHRjb25zdCByZWFkU3RyID0gKG9mZnNldDogbnVtYmVyLCBsZW46IG51bWJlcik6IHN0cmluZyA9PlxuXHRcdG1zZ1xuXHRcdFx0LnN1YmFycmF5KG9mZnNldCwgb2Zmc2V0ICsgbGVuKVxuXHRcdFx0LnRvU3RyaW5nKCdhc2NpaScpXG5cdFx0XHQuc3BsaXQoJ1xcMCcpWzBdXG5cdFx0XHQudHJpbSgpXG5cblx0Y29uc3QgZXVpNjQgPSBtc2cuc3ViYXJyYXkoOCwgMTYpXG5cdGNvbnN0IG1hY0J5dGVzID0gW2V1aTY0WzBdLCBldWk2NFsxXSwgZXVpNjRbMl0sIGV1aTY0WzVdLCBldWk2NFs2XSwgZXVpNjRbN11dXG5cdGNvbnN0IG1hYyA9IG1hY0J5dGVzLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSkuam9pbignOicpXG5cblx0Y29uc3QgbmFtZSA9IHJlYWRTdHIoMHgyMCwgMzEpIC8vIERhbnRlIGRldmljZSBsYWJlbCAoY2FuIGJlIHVwIHRvIDMxIGNoYXJzIHBlciBEYW50ZSBzcGVjKVxuXHRjb25zdCBtYW51ZmFjdHVyZXIgPSByZWFkU3RyKDB4NGMsIDY0KSAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGNvbnN0IG1vZGVsUmF3ID0gcmVhZFN0cigweGNjLCA2NClcblx0Y29uc3QgZGFudGVGaXJtd2FyZSA9IGAke21zZ1sweDE4XX0uJHttc2dbMHgxOV19YFxuXG5cdGlmICghbW9kZWxSYXcpIHJldHVybiBudWxsXG5cblx0Ly8gRXh0cmFjdCBqdXN0IHRoZSBtb2RlbCBudW1iZXIvY29kZSAoZS5nLiBcIk1vZGVsIDM5MSBBbGVydGluZyBVbml0XCIgXHUyMTkyIFwiMzkxXCIpXG5cdC8vIFN0cmlwIFwiTW9kZWwgXCIgcHJlZml4LCB0aGVuIHRha2Ugb25seSB0aGUgZmlyc3Qgd29yZCAodGhlIG1vZGVsIG51bWJlcilcblx0Y29uc3QgbW9kZWwgPSBtb2RlbFJhd1xuXHRcdC5yZXBsYWNlKC9eTW9kZWxcXHMrL2ksICcnKVxuXHRcdC50cmltKClcblx0XHQuc3BsaXQoL1xccysvKVswXVxuXG5cdHJldHVybiB7XG5cdFx0aXA6IHNyY0lwLFxuXHRcdG5hbWUsXG5cdFx0bWFudWZhY3R1cmVyLFxuXHRcdG1vZGVsLFxuXHRcdG1vZGVsTmFtZTogbW9kZWxSYXcsIC8vIEZ1bGwgbW9kZWwgZGVzY3JpcHRpb25cblx0XHRtYWMsXG5cdFx0ZGFudGVGaXJtd2FyZSxcblx0fVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIE1BQyBhZGRyZXNzIGJ5dGVzIG9mIHRoZSBsb2NhbCBpbnRlcmZhY2UgdXNlZCB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBjb25uZWN0IHRvIGxldCB0aGUgT1Mgc2VsZWN0IHRoZSBvdXRnb2luZyBpbnRlcmZhY2UsXG4gKiB0aGVuIGZpbmRzIHRoZSBtYXRjaGluZyBNQUMgZnJvbSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPG51bWJlcltdPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTxudW1iZXJbXT4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHR0bXAub25jZSgnZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0fSlcblxuXHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgYWRkciA9IHRtcC5hZGRyZXNzKCkgYXMgeyBhZGRyZXNzOiBzdHJpbmcgfVxuXHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3Ncblx0XHRcdFx0dG1wLmNsb3NlKClcblxuXHRcdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0XHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBpZmFjZSBvZiBpZmFjZXNbbmFtZV0gPz8gW10pIHtcblx0XHRcdFx0XHRcdGlmIChcblx0XHRcdFx0XHRcdFx0aWZhY2UuZmFtaWx5ID09PSAnSVB2NCcgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UuYWRkcmVzcyA9PT0gbG9jYWxBZGRyICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCdcblx0XHRcdFx0XHRcdCkge1xuXHRcdFx0XHRcdFx0XHRyZXR1cm4gcmVzb2x2ZShpZmFjZS5tYWMuc3BsaXQoJzonKS5tYXAoKGIpID0+IHBhcnNlSW50KGIsIDE2KSAmIDB4ZmYpKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGBObyBpbnRlcmZhY2UgZm91bmQgZm9yIGxvY2FsIGFkZHJlc3MgJHtsb2NhbEFkZHJ9YCkpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgbG9jYWwgSVAgYWRkcmVzcyB1c2VkIGJ5IHRoZSBPUyB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBzb2NrZXQgY29ubmVjdCB0byBsZXQgdGhlIE9TIHNlbGVjdCB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8c3RyaW5nPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdGxldCByZXNvbHZlZCA9IGZhbHNlXG5cdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIFVzZSBhbiBhcmJpdHJhcnkgcG9ydCBmb3IgY29ubmVjdDsgd2Ugb25seSBuZWVkIHRoZSBrZXJuZWwgdG8gYXNzaWduIGEgbG9jYWwgYWRkcmVzcy5cblx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cdFx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRcdHJlc29sdmUobG9jYWxBZGRyKVxuXHRcdFx0XHR9XG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cblxuLyoqXG4gKiBMaXN0ZW5zIGZvciBEYW50ZSBkZXZpY2UgYW5ub3VuY2VzIG9uIHRoZSBsb2NhbCBuZXR3b3JrIGFuZCBzZW5kcyB1bmljYXN0XG4gKiBpbmZvIHJlcXVlc3RzIHRvIGVhY2ggZGlzY292ZXJlZCBJUC4gUmVzcG9uc2VzIGFycml2ZSBvbiB0aGUgY2FsbGVyJ3MgcnhTb2NrZXRcbiAqIHZpYSBoYW5kbGVJbmNvbWluZygpIFx1MjE5MiBkaXNjb3ZlcnlMaXN0ZW5lcnMuXG4gKlxuICogQHBhcmFtIHR4U29ja2V0IC0gVGhlIHNvY2tldCB0byB1c2UgZm9yIHNlbmRpbmcgZGlzY292ZXJ5IHJlcXVlc3RzXG4gKiBAcGFyYW0gZW5zdXJlTWVtYmVyc2hpcCAtIENhbGxiYWNrIHRvIGVuc3VyZSBtdWx0aWNhc3QgbWVtYmVyc2hpcCBiZWZvcmUgcXVlcnlpbmdcbiAqIEBwYXJhbSB0aW1lb3V0TXMgLSBIb3cgbG9uZyB0byBsaXN0ZW4gZm9yIGFubm91bmNlcyBiZWZvcmUgcmVzb2x2aW5nXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkaXNjb3ZlckRldmljZXMoXG5cdHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXQsXG5cdGVuc3VyZU1lbWJlcnNoaXA6IChkZXN0SXA6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPixcblx0dGltZW91dE1zID0gNTAwMCxcbik6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBEQU5URV9BTk5PVU5DRV9HUk9VUCA9ICcyMjQuMC4wLjIzMydcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfUE9SVCA9IDg3MDhcblx0Y29uc3QgREVGQVVMVF9QT1JUID0gODcwMFxuXG5cdGNvbnN0IHF1ZXJpZWRJcHMgPSBuZXcgU2V0PHN0cmluZz4oKVxuXG5cdHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdGNvbnN0IGFubm91bmNlU29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblxuXHRcdGNvbnN0IGNsZWFudXAgPSAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhbm5vdW5jZVNvY2tldC5kcm9wTWVtYmVyc2hpcChEQU5URV9BTk5PVU5DRV9HUk9VUClcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmNsb3NlKClcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHRcdHJlc29sdmUoKVxuXHRcdH1cblxuXHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dChjbGVhbnVwLCB0aW1lb3V0TXMpXG5cdFx0dGltZXIudW5yZWY/LigpXG5cblx0XHRhbm5vdW5jZVNvY2tldC5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIud2FybihgQW5ub3VuY2Ugc29ja2V0IGVycm9yOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0fSlcblxuXHRcdGFubm91bmNlU29ja2V0Lm9uKCdtZXNzYWdlJywgKG1zZywgcmluZm8pID0+IHtcblx0XHRcdGNvbnN0IHNyY0lwID0gcmluZm8uYWRkcmVzc1xuXHRcdFx0Ly8gVmFsaWRhdGUgaXQncyBhIERhbnRlIGFubm91bmNlIChtYWdpYyAweGZmZmUgKyBcIkF1ZGluYXRlXCIgYXQgb2Zmc2V0IDE2KVxuXHRcdFx0aWYgKG1zZy5sZW5ndGggPCAyNCkgcmV0dXJuXG5cdFx0XHRpZiAobXNnLnJlYWRVSW50MTZCRSgwKSAhPT0gMHhmZmZlKSByZXR1cm5cblx0XHRcdGlmIChtc2cuc3ViYXJyYXkoMTYsIDI0KS50b1N0cmluZygnYXNjaWknKSAhPT0gJ0F1ZGluYXRlJykgcmV0dXJuXG5cblx0XHRcdGlmIChxdWVyaWVkSXBzLmhhcyhzcmNJcCkpIHJldHVyblxuXHRcdFx0cXVlcmllZElwcy5hZGQoc3JjSXApXG5cdFx0XHRsb2dnZXIuZGVidWcoYEFubm91bmNlIGZyb20gJHtzcmNJcH0gXHUyMDE0IHNlbmRpbmcgdW5pY2FzdCBxdWVyeWApXG5cblx0XHRcdC8vIEpvaW4gMjI0LjAuMC4yMzEgb24gdGhlIGludGVyZmFjZSB0aGF0IHJvdXRlcyB0byB0aGlzIGRldmljZSBCRUZPUkUgc2VuZGluZ1xuXHRcdFx0Ly8gdGhlIHF1ZXJ5LiBUaGUgZGV2aWNlIG11bHRpY2FzdHMgaXRzIDB4MDE3MCByZXNwb25zZSB0byAyMjQuMC4wLjIzMTo4NzAyXG5cdFx0XHQvLyBpbiBhZGRpdGlvbiB0byB1bmljYXN0aW5nIGl0IFx1MjAxNCByeFNvY2tldCBtdXN0IGJlIGEgbWVtYmVyIHRvIHJlY2VpdmUgaXQuXG5cdFx0XHRjb25zdCBzZW5kUXVlcnkgPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdGF3YWl0IGVuc3VyZU1lbWJlcnNoaXAoc3JjSXApXG5cdFx0XHRcdGNvbnN0IHF1ZXJ5ID0gYnVpbGREYW50ZUluZm9SZXF1ZXN0KClcblx0XHRcdFx0dHhTb2NrZXQuc2VuZChxdWVyeSwgREVGQVVMVF9QT1JULCBzcmNJcCwgKGVycikgPT4ge1xuXHRcdFx0XHRcdGlmIChlcnIpIGxvZ2dlci53YXJuKGBVbmljYXN0IHF1ZXJ5IHRvICR7c3JjSXB9IGZhaWxlZDogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0XHR9KVxuXHRcdFx0fVxuXHRcdFx0c2VuZFF1ZXJ5KCkuY2F0Y2goKGVycikgPT4gbG9nZ2VyLndhcm4oYFF1ZXJ5IHNldHVwIGZhaWxlZDogJHtlcnJ9YCkpXG5cdFx0fSlcblxuXHRcdGFubm91bmNlU29ja2V0LmJpbmQoREFOVEVfQU5OT1VOQ0VfUE9SVCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuYWRkTWVtYmVyc2hpcChEQU5URV9BTk5PVU5DRV9HUk9VUClcblx0XHRcdFx0bG9nZ2VyLmluZm8oYExpc3RlbmluZyBmb3IgRGFudGUgYW5ub3VuY2VzIG9uICR7REFOVEVfQU5OT1VOQ0VfR1JPVVB9OiR7REFOVEVfQU5OT1VOQ0VfUE9SVH1gKVxuXHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3Qgam9pbiBhbm5vdW5jZSBtdWx0aWNhc3QgZ3JvdXA6ICR7ZXJyfWApXG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cbiIsICJpbXBvcnQge1xuXHRJbnN0YW5jZVR5cGVzLFxuXHRJbnN0YW5jZUJhc2UsXG5cdEluc3RhbmNlU3RhdHVzLFxuXHRTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsXG5cdGNyZWF0ZU1vZHVsZUxvZ2dlcixcbn0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7IEdldENvbmZpZ0ZpZWxkcywgcmVzb2x2ZUhvc3QsIHJlc29sdmVNb2RlbCwgZ2V0RGV2aWNlU2NoZW1hLCB0eXBlIE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucywgVXBkYXRlVmFyaWFibGVWYWx1ZXMgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcbmltcG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH0gZnJvbSAnLi91cGdyYWRlcy5qcydcbmltcG9ydCB7IFVwZGF0ZUFjdGlvbnMgfSBmcm9tICcuL2FjdGlvbnMuanMnXG5pbXBvcnQgeyBVcGRhdGVGZWVkYmFja3MgfSBmcm9tICcuL2ZlZWRiYWNrcy5qcydcbmltcG9ydCB7IFN0Q29udHJvbGxlciB9IGZyb20gJy4vc3Rjb250cm9sbGVyLmpzJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdNb2R1bGVJbnN0YW5jZScpXG5cbmV4cG9ydCB0eXBlIE1vZHVsZVR5cGVzID0gSW5zdGFuY2VUeXBlcyAmIHtcblx0Y29uZmlnOiBNb2R1bGVDb25maWdcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTW9kdWxlSW5zdGFuY2UgZXh0ZW5kcyBJbnN0YW5jZUJhc2U8TW9kdWxlVHlwZXM+IHtcblx0Y29uZmlnITogTW9kdWxlQ29uZmlnIC8vIFNldHVwIGluIGluaXQoKVxuXHRzdENvbnRyb2xsZXIhOiBTdENvbnRyb2xsZXJcblxuXHQvKiogQ2FjaGVkIGRpc2NvdmVyeSByZXN1bHRzIFx1MjAxNCBwYXNzZWQgaW50byBnZXRDb25maWdGaWVsZHMoKSBzbyB0aGUgVUlcblx0ICogIGNhbiBzaG93IHRoZSBkaXNjb3ZlcmVkIGRldmljZSBkcm9wZG93biBvbiBzdWJzZXF1ZW50IGNvbmZpZyBvcGVucy4gKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHQvKiogQ3VycmVudGx5IGFjdGl2ZSBtb2RlbCBcdTIwMTQgcmVzb2x2ZWQgb25jZSBpbiBzeW5jTW9kZWwoKSBhbmQgY2FjaGVkIGhlcmVcblx0ICogIHNvIFVwZGF0ZUFjdGlvbnMsIFVwZGF0ZUZlZWRiYWNrcyBldGMuIGRvbid0IGVhY2ggY2FsbCByZXNvbHZlTW9kZWwgaW5kZXBlbmRlbnRseS4gKi9cblx0YWN0aXZlTW9kZWw6IHN0cmluZyA9ICcnXG5cblx0Y29uc3RydWN0b3IoaW50ZXJuYWw6IHVua25vd24pIHtcblx0XHRzdXBlcihpbnRlcm5hbClcblx0fVxuXG5cdGFzeW5jIGluaXQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGlmICghdGhpcy5zdENvbnRyb2xsZXIpIHtcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyID0gbmV3IFN0Q29udHJvbGxlcigpXG5cdFx0fVxuXHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkNvbm5lY3RpbmcsICdEaXNjb3ZlcmluZyBkZXZpY2VzLi4uJylcblxuXHRcdC8vIFdpcmUgZmVlZGJhY2sgY2FsbGJhY2sgc28gc3RDb250cm9sbGVyIGNhbiB0cmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZXNcblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRGZWVkYmFja0NhbGxiYWNrKChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHtcblx0XHRcdHRoaXMuY2hlY2tGZWVkYmFja3MoZmVlZGJhY2tJZClcblx0XHR9KVxuXG5cdFx0Ly8gU3RhcnQgZGlzY292ZXJ5IGluIHRoZSBiYWNrZ3JvdW5kIFx1MjAxNCBhbGwgbW9kZWwgcmVzb2x1dGlvbiwgc2NoZW1hIHN5bmMsXG5cdFx0Ly8gYW5kIFVJIHVwZGF0ZXMgaGFwcGVuIGluc2lkZSBydW5EaXNjb3ZlcnkoKSBvbmNlIHRoZSBkZXZpY2UgbGlzdCBpcyBrbm93bi5cblx0XHR0aGlzLnJ1bkRpc2NvdmVyeSgpLmNhdGNoKChlKSA9PiB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYERpc2NvdmVyeSBmYWlsZWQ6ICR7ZX1gKVxuXHRcdH0pXG5cdH1cblxuXHQvKipcblx0ICogUnVuIGRldmljZSBkaXNjb3ZlcnksIHRoZW4gcmVzb2x2ZSB0aGUgbW9kZWwgYW5kIHVwZGF0ZSBhbGwgVUkuXG5cdCAqIC0gSWYgZGlzY292ZXJ5IGZpbmRzIGRldmljZXMsIHJlc29sdmVNb2RlbCBwaWNrcyBmcm9tIHRob3NlLlxuXHQgKiAtIE9ubHkgaWYgdGhlIGxpc3QgaXMgZW1wdHkgZG8gd2UgZmFsbCBiYWNrIHRvIHRoZSBtYW51YWwgY29uZmlnIHNlbGVjdGlvbi5cblx0ICogQWxsIGFjdGlvbnMvZmVlZGJhY2tzL3ZhcmlhYmxlcyBhcmUgYnVpbHQgYWZ0ZXIgdGhlIG1vZGVsIGlzIGtub3duLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBydW5EaXNjb3ZlcnkoKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0bG9nZ2VyLmluZm8oJ1N0YXJ0aW5nIGRldmljZSBkaXNjb3ZlcnkuLi4nKVxuXG5cdFx0dGhpcy5kaXNjb3ZlcmVkRGV2aWNlcyA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLmRpc2NvdmVyRGV2aWNlcygpXG5cblx0XHQvLyBEZXRlcm1pbmUgZWZmZWN0aXZlIG1vZGVsIFx1MjAxNCBmcm9tIGRpc2NvdmVyZWQgZGV2aWNlcyBmaXJzdCwgbWFudWFsIGNvbmZpZyBvbmx5IGFzIGZhbGxiYWNrXG5cdFx0bGV0IGVmZmVjdGl2ZU1vZGVsOiBzdHJpbmdcblx0XHRpZiAodGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGggPT09IDApIHtcblx0XHRcdC8vIElmIGEgc3BlY2lmaWMgZGV2aWNlIE1BQyB3YXMgc2F2ZWQgaW4gY29uZmlnLCBpdCB3YXNuJ3QgZm91bmQgXHUyMDE0IHN0b3AgaGVyZS5cblx0XHRcdGlmICh0aGlzLmNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRcdFx0Y29uc3QgbW9kZWxMYWJlbCA9IHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsID8gYE1vZGVsICR7dGhpcy5jb25maWcuYWN0aXZlTW9kZWx9IGAgOiAnJ1xuXHRcdFx0XHRsb2dnZXIud2FybihgU2F2ZWQgZGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBkdXJpbmcgZGlzY292ZXJ5IFx1MjAxNCBzdG9wcGluZ2ApXG5cdFx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLCBgJHttb2RlbExhYmVsfVske3RoaXMuY29uZmlnLmRldmljZU1hY31dIG5vdCBmb3VuZGApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0Y29uc3QgbWFudWFsTW9kZWwgPSB0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbFxuXHRcdFx0aWYgKCF0aGlzLmNvbmZpZy5ob3N0IHx8ICFtYW51YWxNb2RlbCkge1xuXHRcdFx0XHRsb2dnZXIud2FybignTm8gZGV2aWNlcyBkaXNjb3ZlcmVkIGFuZCBubyBtYW51YWwgSVAvbW9kZWwgY29uZmlndXJlZCcpXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0bG9nZ2VyLmluZm8oJ05vIGRldmljZXMgZGlzY292ZXJlZCBcdTIwMTQgd2lsbCBwcm9iZSBtYW51YWwgSVAgZHVyaW5nIGF1dGhvcml6YXRpb24nKVxuXHRcdFx0ZWZmZWN0aXZlTW9kZWwgPSBtYW51YWxNb2RlbFxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgRGlzY292ZXJlZCAke3RoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RofSBkZXZpY2Uocyk6YClcblx0XHRcdGZvciAoY29uc3QgZCBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGAgIC0gTW9kZWwgJHtkLm1vZGVsfSAke2QubWFudWZhY3R1cmVyID8/ICcnfSBAICR7ZC5pcH1gKVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBBdXRob3JpemUgYWxsIGRpc2NvdmVyZWQgZGV2aWNlcyBzbyBmaXJtd2FyZSByZXF1ZXN0cyBjYW4gcHJvY2VlZC5cblx0XHRcdC8vIHZlcmlmeUF1dGhvcml6YXRpb24gKGNhbGxlZCBiZWxvdykgd2lsbCByZXZva2UgYW55IHRoYXQgZG9uJ3QgbWF0Y2hcblx0XHRcdC8vIHRoZSBjdXJyZW50IGNvbmZpZyBzZWxlY3Rpb24uXG5cdFx0XHRmb3IgKGNvbnN0IGRldmljZSBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShkZXZpY2UuaXApXG5cdFx0XHR9XG5cblx0XHRcdC8vIFJlcXVlc3QgZmlybXdhcmUgdmVyc2lvbiBmcm9tIGVhY2ggZGlzY292ZXJlZCBkZXZpY2Vcblx0XHRcdGZvciAoY29uc3QgZGV2aWNlIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRjb25zdCBmaXJtd2FyZSA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RGaXJtd2FyZVZlcnNpb24oZGV2aWNlLmlwKVxuXHRcdFx0XHRcdGRldmljZS5maXJtd2FyZU1haW4gPSBmaXJtd2FyZVxuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGAgIC0gJHtkZXZpY2UuaXB9OiBGaXJtd2FyZSAke2Zpcm13YXJlfSwgRGFudGUgJHtkZXZpY2UuZGFudGVGaXJtd2FyZX1gKVxuXHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLndhcm4oYCAgLSAke2RldmljZS5pcH06IEZhaWxlZCB0byBnZXQgZmlybXdhcmU6ICR7ZX1gKVxuXHRcdFx0XHRcdGRldmljZS5maXJtd2FyZU1haW4gPSAnVW5rbm93bidcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblxuXHRcdFx0Ly8gSWYgYSBzcGVjaWZpYyBNQUMgd2FzIHNhdmVkIGJ1dCBpc24ndCBpbiB0aGUgZGlzY292ZXJlZCBsaXN0LCBzdG9wLlxuXHRcdFx0aWYgKCFlZmZlY3RpdmVNb2RlbCAmJiB0aGlzLmNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRcdFx0Y29uc3QgbW9kZWxMYWJlbCA9IHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsID8gYE1vZGVsICR7dGhpcy5jb25maWcuYWN0aXZlTW9kZWx9IGAgOiAnJ1xuXHRcdFx0XHRsb2dnZXIud2FybihgU2F2ZWQgZGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBhbW9uZyBkaXNjb3ZlcmVkIGRldmljZXMgXHUyMDE0IHN0b3BwaW5nYClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsIGAke21vZGVsTGFiZWx9WyR7dGhpcy5jb25maWcuZGV2aWNlTWFjfV0gbm90IGZvdW5kYClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gU3luYyBtb2RlbCBzY2hlbWEgdG8gY29udHJvbGxlclxuXHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXG5cdFx0Ly8gVmVyaWZ5IHRoYXQgdGhlIGN1cnJlbnRseSBjb25maWd1cmVkIGhvc3QrbW9kZWwgaXMgdmFsaWQgbm93IHRoYXRcblx0XHQvLyBkaXNjb3ZlcnkgcmVzdWx0cyBhcmUga25vd24uIFRoaXMgaXMgdGhlIHNhbWUgY2hlY2sgY29uZmlnVXBkYXRlZCB1c2VzLlxuXHRcdGNvbnN0IHRhcmdldEhvc3QgPSB0aGlzLmhvc3Rcblx0XHRhd2FpdCB0aGlzLnZlcmlmeUF1dGhvcml6YXRpb24oJycsIHRhcmdldEhvc3QpXG5cblx0XHQvLyBCdWlsZCBhbGwgVUkgbm93IHRoYXQgbW9kZWwgYW5kIGF1dGhvcml6YXRpb24gc3RhdGUgYXJlIGtub3duXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblxuXHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLk9rKVxuXHRcdGxvZ2dlci5pbmZvKCdEZXZpY2UgZGlzY292ZXJ5IGNvbXBsZXRlJylcblx0fVxuXG5cdC8vIFdoZW4gbW9kdWxlIGdldHMgZGVsZXRlZFxuXHRhc3luYyBkZXN0cm95KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuc3RDb250cm9sbGVyPy5jbG9zZSgpXG5cdFx0bG9nZ2VyLmRlYnVnKCdkZXN0cm95Jylcblx0fVxuXG5cdGFzeW5jIGNvbmZpZ1VwZGF0ZWQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRjb25zdCBwcmV2aW91c0hvc3QgPSB0aGlzLmhvc3Rcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGNvbnN0IGVmZmVjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKGNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIENsZWFyIHZhcmlhYmxlcyBpbW1lZGlhdGVseSBcdTIwMTQgdGhlIG5ldyBzZWxlY3Rpb24gaXNuJ3QgYXV0aG9yaXplZCB5ZXQuXG5cdFx0Ly8gVGhleSdsbCBiZSByZXBvcHVsYXRlZCBiZWxvdyBvbmNlIHZlcmlmeUF1dGhvcml6YXRpb24gY29tcGxldGVzLlxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXG5cdFx0Y29uc3QgbmV3SG9zdCA9IHRoaXMuaG9zdFxuXG5cdFx0Ly8gUmUtdmVyaWZ5IGF1dGhvcml6YXRpb24gb24gZXZlcnkgY29uZmlnIGNoYW5nZSAobW9kZWwgb3IgSVApLlxuXHRcdC8vIFRoaXMgaGFuZGxlcyBzd2l0Y2hpbmcgZnJvbSBhIHZhbGlkIGRldmljZSB0byBhbiBpbnZhbGlkIG9uZSBhbmQgYmFjay5cblx0XHRhd2FpdCB0aGlzLnZlcmlmeUF1dGhvcml6YXRpb24ocHJldmlvdXNIb3N0LCBuZXdIb3N0KVxuXG5cdFx0Ly8gUmVidWlsZCBVSSBhZnRlciBhdXRob3JpemF0aW9uIHN0YXRlIGlzIHNldHRsZWRcblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXHR9XG5cblx0LyoqXG5cdCAqIFJlLWV2YWx1YXRlcyB3aGV0aGVyIHRoZSBjdXJyZW50IGNvbmZpZyBpcyBhdXRob3JpemVkIHRvIHNlbmQgY29tbWFuZHMuXG5cdCAqXG5cdCAqIEF1dG8gbW9kZSAoZGV2aWNlTWFjIHNldCk6XG5cdCAqICAgLSBGaW5kIHRoZSBkaXNjb3ZlcmVkIGRldmljZSB3aXRoIG1hdGNoaW5nIE1BQyBcdTIxOTIgZ2V0IGl0cyBjdXJyZW50IElQXG5cdCAqICAgLSBSZXZva2UgdGhlIHByZXZpb3VzIElQLCBhdXRob3JpemUgdGhlIG5ldyBJUFxuXHQgKiAgIC0gSWYgTUFDIG5vdCBmb3VuZCBpbiBkaXNjb3ZlcnksIHJldm9rZSBhbmQgYmxvY2tcblx0ICpcblx0ICogTWFudWFsIG1vZGUgKGRldmljZU1hYyBlbXB0eSk6XG5cdCAqICAgLSBDaGVjayBkaXNjb3ZlcmVkIGxpc3QgYnkgSVArbW9kZWwgbWF0Y2gsIG9yIHByb2JlIGRpcmVjdGx5XG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIHZlcmlmeUF1dGhvcml6YXRpb24ocHJldmlvdXNIb3N0OiBzdHJpbmcsIG5ld0hvc3Q6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGlmICghbmV3SG9zdCkge1xuXHRcdFx0aWYgKHByZXZpb3VzSG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRcdC8vIEF1dG8gbW9kZSBcdTIwMTQgbWF0Y2ggYnkgTUFDLCB1c2Ugd2hhdGV2ZXIgSVAgZGlzY292ZXJ5IGZvdW5kIGl0IGF0XG5cdFx0XHRjb25zdCBkZXZpY2UgPSB0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQubWFjID09PSB0aGlzLmNvbmZpZy5kZXZpY2VNYWMpXG5cdFx0XHRpZiAoIWRldmljZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgRGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBpbiBjdXJyZW50IGRpc2NvdmVyeSBcdTIwMTQgbm90IGF1dGhvcml6aW5nYClcblx0XHRcdFx0aWYgKHByZXZpb3VzSG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRjb25zdCB3YXNBdXRob3JpemVkID0gdGhpcy5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKG5ld0hvc3QpXG5cdFx0XHRpZiAoIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRpZiAobmV3SG9zdCAhPT0gcHJldmlvdXNIb3N0IHx8ICF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMuZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShkZXZpY2UubW9kZWwsIG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBNYW51YWwgbW9kZSBcdTIwMTQgY29uZmlnLmhvc3QgKyBjb25maWcuYWN0aXZlTW9kZWwgbXVzdCBtYXRjaFxuXHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gU3RyaW5nKHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsID8/ICcnKVxuXHRcdGNvbnN0IGRpc2NvdmVyZWRBdElwID0gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLmlwID09PSBuZXdIb3N0KVxuXG5cdFx0aWYgKGRpc2NvdmVyZWRBdElwKSB7XG5cdFx0XHRpZiAoZGlzY292ZXJlZEF0SXAubW9kZWwgPT09IG1hbnVhbE1vZGVsKSB7XG5cdFx0XHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0XHRjb25zdCB3YXNBdXRob3JpemVkID0gdGhpcy5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKG5ld0hvc3QpXG5cdFx0XHRcdGlmICghd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChuZXdIb3N0ICE9PSBwcmV2aW91c0hvc3QgfHwgIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobWFudWFsTW9kZWwsIG5ld0hvc3QpXG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGxvZ2dlci5lcnJvcihcblx0XHRcdFx0XHRgRGV2aWNlIHNlbGVjdGVkIChNb2RlbCAke21hbnVhbE1vZGVsfSkgZG9lcyBub3QgbWF0Y2ggZGV0ZWN0ZWQgZGV2aWNlIChNb2RlbCAke2Rpc2NvdmVyZWRBdElwLm1vZGVsfSkgYXQgJHtuZXdIb3N0fSBcdTIwMTQgY29tbWFuZHMgYmxvY2tlZGAsXG5cdFx0XHRcdClcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKFxuXHRcdFx0XHRcdEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLFxuXHRcdFx0XHRcdGBNb2RlbCBtaXNtYXRjaDogZXhwZWN0ZWQgJHttYW51YWxNb2RlbH0sIGdvdCAke2Rpc2NvdmVyZWRBdElwLm1vZGVsfWAsXG5cdFx0XHRcdClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIElQIG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgXHUyMDE0IHByb2JlIGl0IGRpcmVjdGx5IHZpYSBEYW50ZVxuXHRcdGxvZ2dlci5pbmZvKGAke25ld0hvc3R9IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgXHUyMDE0IHByb2JpbmdgKVxuXHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KVxuXG5cdFx0Y29uc3QgcHJvYmVkID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucHJvYmVEZXZpY2UobmV3SG9zdClcblx0XHRpZiAoIXByb2JlZCkge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBObyBkZXZpY2UgcmVzcG9uZGVkIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgKVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuVW5rbm93bldhcm5pbmcsIGBEZXZpY2Ugb2ZmbGluZTogJHtuZXdIb3N0fWApXG5cdFx0fSBlbHNlIGlmIChwcm9iZWQubW9kZWwgIT09IG1hbnVhbE1vZGVsKSB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdGBEZXZpY2Ugc2VsZWN0ZWQgKE1vZGVsICR7bWFudWFsTW9kZWx9KSBkb2VzIG5vdCBtYXRjaCBkZXRlY3RlZCBkZXZpY2UgKE1vZGVsICR7cHJvYmVkLm1vZGVsfSkgYXQgJHtuZXdIb3N0fSBcdTIwMTQgY29tbWFuZHMgYmxvY2tlZGAsXG5cdFx0XHQpXG5cdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhcblx0XHRcdFx0SW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsXG5cdFx0XHRcdGBNb2RlbCBtaXNtYXRjaDogZXhwZWN0ZWQgJHttYW51YWxNb2RlbH0sIGdvdCAke3Byb2JlZC5tb2RlbH1gLFxuXHRcdFx0KVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgVmVyaWZpZWQgTW9kZWwgJHtwcm9iZWQubW9kZWx9IGF0ICR7bmV3SG9zdH1gKVxuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobWFudWFsTW9kZWwsIG5ld0hvc3QpXG5cdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Paylcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogRmV0Y2hlcyBhbGwgc2V0dGluZ3MgZnJvbSB0aGUgZGV2aWNlLiBJZiBubyBzY2hlbWEgZXhpc3RzIGZvciB0aGUgbW9kZWwsXG5cdCAqIGNyZWF0ZXMgb25lIGZyb20gdGhlIHJlc3BvbnNlIGFuZCByZWxvYWRzIHRoZSBzY2hlbWEgY2FjaGUuXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIGZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobW9kZWw6IHN0cmluZywgaXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApXG5cblx0XHRcdGlmICghZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKSkge1xuXHRcdFx0XHQvLyBObyBzY2hlbWEgZXhpc3RzIFx1MjAxNCBkbyBOT1QgYXV0by1jcmVhdGUgb25lIGhlcmUuXG5cdFx0XHRcdC8vIFRoZSB1c2VyIG11c3QgcnVuIFwiR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzXCIgdG8gY3JlYXRlIGl0LlxuXHRcdFx0XHRsb2dnZXIud2FybihgTm8gc2NoZW1hIGZvdW5kIGZvciBNb2RlbCAke21vZGVsfSBcdTIwMTQgcnVuIFwiR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzXCIgdG8gY3JlYXRlIG9uZWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZmV0Y2ggc2V0dGluZ3MgZnJvbSAke2lwfTogJHtlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqIExvYWRzIHRoZSBkZXZpY2UgSlNPTiBmb3IgdGhlIGdpdmVuIG1vZGVsLCBjYWNoZXMgaXQgYXMgYWN0aXZlTW9kZWwsIGFuZCBwdXNoZXMgaXQgdG8gdGhlIGNvbnRyb2xsZXIuICovXG5cdHByaXZhdGUgc3luY01vZGVsKG1vZGVsOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmFjdGl2ZU1vZGVsID0gbW9kZWxcblx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0aWYgKCFzY2hlbWEpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBNb2RlbCBcIiR7bW9kZWx9XCIgbm90IGZvdW5kIGluIGRldmljZSBzY2hlbWFzYClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBbXSwgdHJ1ZSlcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGNvbnN0IGFjdGlvbnMgPSBBcnJheS5pc0FycmF5KHNjaGVtYS5jbWRTY2hlbWEpID8gc2NoZW1hLmNtZFNjaGVtYSA6IFtdXG5cdFx0Y29uc3QgcmVmcmVzaEFmdGVyQ29tbWFuZCA9IHNjaGVtYS5yZWZyZXNoQWZ0ZXJDb21tYW5kID8/IHRydWVcblxuXHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBhY3Rpb25zLCByZWZyZXNoQWZ0ZXJDb21tYW5kKVxuXHRcdGlmIChhY3Rpb25zLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYE5vIGFjdGlvbnMgZm91bmQgZm9yIG1vZGVsIFwiJHttb2RlbH1cIiBcdTIwMTQgc2V0dGluZ3MgZGVjb2Rpbmcgd2lsbCB1c2UgcmF3IElEc2ApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0YExvYWRlZCAke2FjdGlvbnMubGVuZ3RofSBhY3Rpb25zIGZvciBtb2RlbCBcIiR7bW9kZWx9XCIsIHNlY3Rpb25lZD0ke3NjaGVtYS5zZWN0aW9uZWR9LCByZWZyZXNoQWZ0ZXJDb21tYW5kPSR7cmVmcmVzaEFmdGVyQ29tbWFuZH1gLFxuXHRcdFx0KVxuXHRcdH1cblx0fVxuXG5cdGdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdFx0cmV0dXJuIEdldENvbmZpZ0ZpZWxkcyh0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLCByZXNvbHZlZCBmcm9tIE1BQ1x1MjE5MklQIHZpYSBkaXNjb3ZlcmVkRGV2aWNlcyAoYXV0bykgb3IgY29uZmlnLmhvc3QgKG1hbnVhbCkuICovXG5cdGdldCBob3N0KCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIHJlc29sdmVIb3N0KHRoaXMuY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgZGlzY292ZXJlZCBkZXZpY2VzIGZvciB1c2UgaW4gYWN0aW9ucy9jb25maWcgKi9cblx0Z2V0IGRldmljZXMoKTogRGV2aWNlSW5mb1tdIHtcblx0XHRyZXR1cm4gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlc1xuXHR9XG5cblx0dXBkYXRlQWN0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVBY3Rpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVGZWVkYmFja3MoKTogdm9pZCB7XG5cdFx0VXBkYXRlRmVlZGJhY2tzKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlVmFsdWVzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHRoaXMpXG5cdH1cbn1cblxuZXhwb3J0IHsgVXBncmFkZVNjcmlwdHMgfVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7QUFrQkEsSUFBTSxxQkFBa0MsQ0FBQyxRQUFRLE9BQU8sWUFBVztBQUVsRSxVQUFRLElBQUksSUFBSSxNQUFNLFlBQVcsQ0FBRSxJQUFJLFNBQVMsS0FBSyxNQUFNLE1BQU0sRUFBRSxJQUFJLE9BQU8sRUFBRTtBQUNqRjtBQUVBLFNBQVMsVUFBVSxRQUE0QixPQUFpQixTQUFlO0FBQzlFLFFBQU0sT0FBTyxPQUFPLE9BQU8scUJBQXFCLGFBQWEsT0FBTyxtQkFBbUI7QUFDdkYsT0FBSyxRQUFRLE9BQU8sT0FBTztBQUM1QjtBQU9NLFNBQVUsbUJBQW1CLFFBQWU7QUFDakQsU0FBTztJQUNOLE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPO0lBQzlELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPOztBQUVoRTs7O0FDVE0sU0FBVSxZQUFZLE1BQVc7QUFFdkM7OztBQ2hDQSxTQUFTLG9CQUFvQjtBQTJFdkIsSUFBTyxzQkFBUCxjQUFtQyxhQUFtQztFQUNsRTtFQUNBO0VBRVQsSUFBVyxXQUFRO0FBQ2xCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBQ0EsSUFBVyxhQUFVO0FBQ3BCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBRUEsSUFBWSxhQUFVO0FBQ3JCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7QUFDbkQsYUFBTyxLQUFLO0lBQ2IsT0FBTztBQUNOLGFBQU87SUFDUjtFQUNEO0VBRUEsU0FBdUU7RUFFdkUsWUFBWSxTQUF5QyxTQUErQjtBQUNuRixVQUFLO0FBRUwsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVyxFQUFFLEdBQUcsUUFBTztFQUM3QjtFQUVBLEtBQUssTUFBYyxVQUFtQixVQUFxQjtBQUMxRCxRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLHlCQUF5QjtBQUM3RixZQUFRLEtBQUssUUFBUTtNQUNwQixLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sb0NBQW9DO01BQ3JELEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSx5QkFBeUI7TUFDMUMsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtNQUNwQyxLQUFLO0FBQ0o7TUFDRDtBQUNDLG9CQUFZLEtBQUssTUFBTTtBQUN2QixjQUFNLElBQUksTUFBTSxzQkFBc0I7SUFDeEM7QUFFQSxTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLGFBQWEsUUFBUTtBQUUzQyxTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFFBQVEsS0FBSyxTQUFTO01BQ3RCLFlBQVk7O0tBRVosRUFDQSxLQUNBLENBQUMsYUFBWTtBQUNaLFdBQUssU0FBUyxFQUFFLFlBQVksTUFBTSxTQUFRO0FBQzFDLFdBQUssU0FBUyx3QkFBd0IsSUFBSSxVQUFVLElBQUk7QUFDeEQsV0FBSyxLQUFLLFdBQVc7SUFDdEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVM7QUFDZCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLE1BQU0sVUFBcUI7QUFDMUIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtJQUVwRCxPQUFPO0FBQ04sY0FBUSxLQUFLLFFBQVE7UUFDcEIsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQ0FBb0M7UUFDckQsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9CQUFvQjtRQUNyQztBQUNDLHNCQUFZLEtBQUssTUFBTTtBQUN2QixnQkFBTSxJQUFJLE1BQU0sc0JBQXNCO01BQ3hDO0lBQ0Q7QUFFQSxVQUFNLFdBQVcsS0FBSyxPQUFPO0FBQzdCLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsU0FBUyxRQUFRO0FBRXZDLFNBQUssU0FDSCxxQkFBcUI7TUFDckI7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxPQUFPO0lBQ2xCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFXQSxLQUNDLGNBQ0EsY0FDQSxpQkFDQSxnQkFDQSxTQUNBLFVBQXFCO0FBRXJCLFFBQUksT0FBTyxpQkFBaUI7QUFBVSxZQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDekUsUUFBSSxPQUFPLG9CQUFvQixVQUFVO0FBQ3hDLFVBQUksT0FBTyxtQkFBbUIsWUFBWSxPQUFPLFlBQVk7QUFBVSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDMUcsVUFBSSxhQUFhLFVBQWEsT0FBTyxhQUFhO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRWpHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxjQUFjLGVBQWU7QUFDOUUsV0FBSyxXQUFXLFFBQVEsZ0JBQWdCLFNBQVMsUUFBUTtJQUMxRCxXQUFXLE9BQU8sb0JBQW9CLFVBQVU7QUFDL0MsVUFBSSxtQkFBbUIsVUFBYSxPQUFPLG1CQUFtQjtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUU3RyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsR0FBRyxNQUFTO0FBQzdELFdBQUssV0FBVyxRQUFRLGNBQWMsaUJBQWlCLGNBQWM7SUFDdEUsT0FBTztBQUNOLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtJQUNwQztFQUNEO0VBRUEsZUFDQyxjQUNBLFFBQ0EsUUFBMEI7QUFFMUIsUUFBSTtBQUNKLFFBQUksT0FBTyxpQkFBaUIsVUFBVTtBQUNyQyxlQUFTLE9BQU8sS0FBSyxjQUFjLE9BQU87SUFDM0MsV0FBVyxPQUFPLFNBQVMsWUFBWSxHQUFHO0FBQ3pDLGVBQVM7SUFDVixXQUFXLE1BQU0sUUFBUSxZQUFZLEdBQUc7QUFFdkMsYUFBTyxPQUFPLEtBQUssWUFBWTtJQUNoQyxPQUFPO0FBQ04sZUFBUyxPQUFPLEtBQUssYUFBYSxRQUFRLGFBQWEsWUFBWSxhQUFhLFVBQVU7SUFDM0Y7QUFFQSxXQUFPLE9BQU8sU0FBUyxRQUFRLFdBQVcsU0FBWSxTQUFTLFNBQVMsTUFBUztFQUNsRjtFQUVBLFdBQVcsUUFBZ0IsTUFBYyxTQUFpQixVQUFxQjtBQUM5RSxRQUFJLENBQUMsS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0sb0JBQW9CO0FBRXpGLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsVUFBVSxLQUFLLE9BQU87TUFDdEIsU0FBUztNQUVUO01BQ0E7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLGlCQUFVO0lBQ1gsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLHFCQUFxQixTQUErQjtBQUNuRCxRQUFJO0FBQ0gsV0FBSyxLQUFLLFdBQVcsUUFBUSxTQUFTLFFBQVEsTUFBTTtJQUNyRCxTQUFTLElBQUk7SUFFYjtFQUNEO0VBQ0EsbUJBQW1CLE9BQVk7QUFDOUIsU0FBSyxTQUFTO0FBRWQsVUFBTSxhQUFhLEtBQUs7QUFDeEIsUUFBSTtBQUFZLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxXQUFXLFFBQVE7QUFFaEYsUUFBSTtBQUNILFdBQUssS0FBSyxTQUFTLEtBQUs7SUFDekIsU0FBUyxJQUFJO0lBRWI7RUFDRDs7OztBQzlQSyxTQUFVLGtCQUFtRCxLQUFZO0FBQzlFLFFBQU0sT0FBTztBQUNiLFNBQU8sQ0FBQyxDQUFDLFFBQVEsT0FBTyxTQUFTLFlBQVksT0FBTyxLQUFLLE9BQU8sWUFBWSxLQUFLLHVCQUF1QjtBQUN6Rzs7O0FDNkJNLElBQWdCLGVBQWhCLE1BQTRCO0VBQ3hCO0VBQ0E7RUFFQTtFQUVULElBQVcsS0FBRTtBQUNaLFdBQU8sS0FBSyxTQUFTO0VBQ3RCO0VBRUEsSUFBVyxrQkFBZTtBQUN6QixXQUFPLEtBQUs7RUFDYjs7Ozs7RUFNQSxJQUFXLFFBQUs7QUFDZixXQUFPLEtBQUssU0FBUztFQUN0Qjs7OztFQUtBLFlBQVksVUFBaUI7QUFDNUIsUUFBSSxDQUFDLGtCQUE2QixRQUFRLEtBQUssQ0FBQyxTQUFTO0FBQ3hELFlBQU0sSUFBSSxNQUNULG1HQUFtRztBQUdyRyxTQUFLLFdBQVc7QUFFaEIsU0FBSyxVQUFVLG1CQUFrQjtBQUVqQyxTQUFLLHdCQUF3QixLQUFLLHNCQUFzQixLQUFLLElBQUk7QUFFakUsU0FBSyxXQUFXO01BQ2YsMkJBQTJCO01BQzNCLHdCQUF3Qjs7QUFHekIsU0FBSyxJQUFJLFNBQVMsY0FBYztFQUNqQztFQStCQSxXQUFXLFdBQTRDLFlBQWlDO0FBQ3ZGLFNBQUssU0FBUyxXQUFXLFdBQVcsVUFBVTtFQUMvQzs7Ozs7RUF1QkEscUJBQXFCLFNBQXlEO0FBQzdFLFNBQUssU0FBUyxxQkFBcUIsT0FBTztFQUMzQzs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7Ozs7RUFPQSxxQkFDQyxXQUNBLFNBQThDO0FBRTlDLFNBQUssU0FBUyxxQkFBcUIsV0FBVyxPQUFPO0VBQ3REOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixRQUFJLE1BQU0sUUFBUSxTQUFTO0FBQUcsWUFBTSxJQUFJLE1BQU0sd0RBQXdEO0FBRXRHLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7RUFNQSxrQkFBa0IsUUFBdUM7QUFDeEQsU0FBSyxTQUFTLGtCQUFrQixNQUFNO0VBQ3ZDOzs7Ozs7RUFPQSxpQkFBbUMsWUFBYTtBQUMvQyxXQUFPLEtBQUssU0FBUyxpQkFBaUIsVUFBVTtFQUNqRDs7OztFQUtBLG9CQUFpQjtBQUNoQixTQUFLLFNBQVMsa0JBQWlCO0VBQ2hDOzs7Ozs7O0VBUUEsZUFDQyxpQkFDRyxlQUFtRDtBQUV0RCxTQUFLLFNBQVMsZUFBZSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUM7RUFDOUQ7Ozs7O0VBTUEsc0JBQXNCLGFBQXFCO0FBQzFDLFNBQUssU0FBUyxtQkFBbUIsV0FBVztFQUM3Qzs7Ozs7O0VBT0Esb0JBQW9CLFdBQW1CO0FBQ3RDLFNBQUssU0FBUyxpQkFBaUIsU0FBUztFQUN6Qzs7Ozs7O0VBTUEsc0JBQXNCLFdBQW1CO0FBQ3hDLFNBQUssU0FBUyxtQkFBbUIsU0FBUztFQUMzQzs7Ozs7O0VBT0Esd0JBQXdCLGFBQXFCO0FBQzVDLFNBQUssU0FBUyxxQkFBcUIsV0FBVztFQUMvQzs7Ozs7O0VBT0EsYUFBYSxRQUFpQyxjQUFxQjtBQUNsRSxTQUFLLFNBQVMsYUFBYSxRQUFRLFlBQVk7RUFDaEQ7Ozs7Ozs7O0VBU0EsUUFBUSxNQUFjLE1BQWNBLE9BQWMsTUFBc0I7QUFDdkUsU0FBSyxTQUFTLFFBQVEsTUFBTSxNQUFNQSxPQUFNLElBQUk7RUFDN0M7Ozs7Ozs7Ozs7O0VBWUEsYUFBYSxRQUF3QixTQUF1QjtBQUMzRCxTQUFLLFNBQVMsYUFBYSxRQUFRLFdBQVcsSUFBSTtFQUNuRDs7Ozs7O0VBT0EsSUFBSSxPQUFpQixTQUFlO0FBQ25DLFlBQVEsT0FBTztNQUNkLEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0Q7QUFDQyxvQkFBWSxLQUFLO0FBQ2pCLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7SUFDRjtFQUNEO0VBWUEsc0JBQ0MsZUFDQSxVQUF5QztBQUV6QyxVQUFNLFVBQWtDLE9BQU8sa0JBQWtCLFdBQVcsRUFBRSxNQUFNLGNBQWEsSUFBSztBQUV0RyxVQUFNLFNBQVMsSUFBSSxvQkFBb0IsS0FBSyxVQUFVLE9BQU87QUFDN0QsUUFBSTtBQUFVLGFBQU8sR0FBRyxXQUFXLFFBQVE7QUFFM0MsV0FBTztFQUNSOzs7O0FDL1VELElBQVk7Q0FBWixTQUFZQyxpQkFBYztBQUN6QixFQUFBQSxnQkFBQSxJQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxZQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxtQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsV0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsZ0JBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHVCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx5QkFBQSxJQUFBO0FBQ0QsR0FWWSxtQkFBQSxpQkFBYyxDQUFBLEVBQUE7QUFhcEIsSUFBVztDQUFqQixTQUFpQkMsUUFBSztBQUVSLEVBQUFBLE9BQUEsS0FBSztBQUNMLEVBQUFBLE9BQUEsV0FDWjtBQUNZLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsT0FDWjtBQUNZLEVBQUFBLE9BQUEsY0FBYztBQUNkLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsUUFBUTtBQUNSLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsU0FBUztBQUNULEVBQUFBLE9BQUEsZ0JBQWdCO0FBQ2hCLEVBQUFBLE9BQUEsWUFBWTtBQUNaLEVBQUFBLE9BQUEsV0FDWjtBQUNGLEdBbEJpQixVQUFBLFFBQUssQ0FBQSxFQUFBOzs7QUNqQnRCLE9BQU8sUUFBUTtBQUNmLE9BQU8sVUFBVTtBQUlqQixJQUFNLFNBQVMsbUJBQW1CLFFBQVE7QUF1QjFDLFNBQVMsdUJBQW9CO0FBQzVCLFFBQU0sY0FBYyxLQUFLLEtBQUssWUFBWSxTQUFTLFlBQVk7QUFDL0QsUUFBTSxlQUFlLEtBQUssS0FBSyxZQUFZLFNBQVMsV0FBVztBQUcvRCxNQUFJLEdBQUcsV0FBVyxXQUFXLEdBQUc7QUFDL0IsV0FBTyxNQUFNLHlCQUF5QixXQUFXLEVBQUU7QUFDbkQsV0FBTztFQUNSO0FBR0EsTUFBSSxHQUFHLFdBQVcsWUFBWSxHQUFHO0FBQ2hDLFdBQU8sS0FBSyxxREFBcUQsWUFBWSxFQUFFO0FBQy9FLFdBQU87RUFDUjtBQUdBLFFBQU0sV0FBVzs7TUFBMEMsV0FBVztNQUFTLFlBQVk7O0FBQzNGLFNBQU8sTUFBTSxRQUFRO0FBQ3JCLFFBQU0sSUFBSSxNQUFNLFFBQVE7QUFDekI7QUFHQSxJQUFNLGdCQUFnQixxQkFBb0I7QUFHMUMsSUFBSSxxQkFBaUQ7QUFNL0MsU0FBVSxtQkFBZ0I7QUFDL0IsU0FBTztBQUNSO0FBTUEsU0FBUyxvQkFBaUI7QUFDekIsUUFBTSxVQUErQixDQUFBO0FBQ3JDLE1BQUk7QUFDSCxVQUFNLFFBQVEsR0FBRyxZQUFZLGFBQWEsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsT0FBTyxDQUFDO0FBRTdFLGVBQVcsS0FBSyxPQUFPO0FBQ3RCLFlBQU0sV0FBVyxLQUFLLEtBQUssZUFBZSxDQUFDO0FBQzNDLFlBQU0sT0FBTyxLQUFLLE1BQU0sR0FBRyxhQUFhLFVBQVUsTUFBTSxDQUFDO0FBQ3pELFVBQUksTUFBTSxPQUFPO0FBQ2hCLGdCQUFRLE9BQU8sS0FBSyxLQUFLLENBQUMsSUFBSTtNQUMvQjtJQUNEO0FBRUEsV0FBTyxNQUFNLFVBQVUsT0FBTyxLQUFLLE9BQU8sRUFBRSxNQUFNLDRCQUE0QjtFQUMvRSxTQUFTLEdBQUc7QUFDWCxXQUFPLE1BQU0sa0NBQWtDLENBQUMsRUFBRTtFQUNuRDtBQUNBLFNBQU87QUFDUjtBQU1NLFNBQVUsbUJBQWdCO0FBQy9CLE1BQUksQ0FBQyxvQkFBb0I7QUFDeEIseUJBQXFCLGtCQUFpQjtFQUN2QztBQUNBLFNBQU87QUFDUjtBQU1NLFNBQVUsZ0JBQWdCLE9BQWE7QUFDNUMsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxTQUFPLFFBQVEsS0FBSztBQUNyQjtBQU1NLFNBQVUsc0JBQW1CO0FBQ2xDLFNBQU8sS0FBSyx1Q0FBdUM7QUFDbkQsdUJBQXFCLGtCQUFpQjtBQUN2QztBQUtBLFNBQVMsc0JBQW1CO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsU0FBTyxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUk7QUFDakM7QUFFTSxTQUFVLGdCQUFnQixvQkFBa0MsQ0FBQSxHQUFFO0FBQ25FLFFBQU0sU0FBUyxvQkFBbUI7QUFJbEMsUUFBTSxnQkFBZ0I7SUFDckIsRUFBRSxJQUFJLElBQUksT0FBTyxrQ0FBaUM7SUFDbEQsR0FBRyxrQkFBa0IsSUFBSSxDQUFDLE9BQU87TUFDaEMsSUFBSSxFQUFFLE9BQU87TUFDYixPQUFPLFNBQVMsRUFBRSxLQUFLLEtBQUssRUFBRSxHQUFHLE9BQU8sRUFBRSxFQUFFO01BQzNDOztBQUdILFNBQU87OztJQUdOO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxTQUFTO01BQ1QsU0FBUzs7O0lBSVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULE9BQU8sTUFBTTtNQUNiLHFCQUFxQjtNQUNyQixTQUFTOzs7SUFJVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTLE9BQU8sQ0FBQyxLQUFLO01BQ3RCLFNBQVMsT0FBTyxJQUFJLENBQUMsV0FBVztRQUMvQixJQUFJO1FBQ0osT0FBTyxTQUFTLEtBQUs7UUFDcEI7TUFDRixxQkFBcUI7TUFDckIsU0FBUzs7O0FBR1o7QUFPTSxTQUFVLFlBQVksUUFBc0IsbUJBQStCO0FBQ2hGLE1BQUksT0FBTyxXQUFXO0FBQ3JCLFVBQU0sU0FBUyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE9BQU8sU0FBUztBQUN2RSxXQUFPLFFBQVEsTUFBTTtFQUN0QjtBQUNBLFNBQU8sT0FBTyxPQUFPLFFBQVEsRUFBRTtBQUNoQztBQU9NLFNBQVUsYUFBYSxRQUFzQixtQkFBK0I7QUFDakYsTUFBSSxPQUFPLFdBQVc7QUFDckIsVUFBTSxTQUFTLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsT0FBTyxTQUFTO0FBQ3ZFLFdBQU8sTUFBTSw0QkFBNEIsT0FBTyxTQUFTLG9CQUFvQixRQUFRLFNBQVMsTUFBTSxFQUFFO0FBQ3RHLFdBQU8sUUFBUSxTQUFTO0VBQ3pCO0FBQ0EsU0FBTyxNQUFNLDJDQUEyQyxPQUFPLFdBQVcsR0FBRztBQUM3RSxTQUFPLE9BQU8sT0FBTyxlQUFlLEVBQUU7QUFDdkM7OztBQ3hNTSxTQUFVLDBCQUEwQixNQUFvQjtBQUM3RCxPQUFLLHVCQUF1QjtJQUMzQixPQUFPLEVBQUUsTUFBTSxzQkFBcUI7SUFDcEMsV0FBVyxFQUFFLE1BQU0sdUNBQXNDO0lBQ3pELGNBQWMsRUFBRSxNQUFNLHNCQUFxQjtJQUMzQyxVQUFVLEVBQUUsTUFBTSwwQkFBeUI7SUFDM0MsU0FBUyxFQUFFLE1BQU0sZ0NBQStCO0lBQ2hELEtBQUssRUFBRSxNQUFNLHFCQUFvQjtJQUNqQyxJQUFJLEVBQUUsTUFBTSxvQkFBbUI7R0FDL0I7QUFDRjtBQUVBLElBQU0sb0JBQW9CO0VBQ3pCLE9BQU87RUFDUCxXQUFXO0VBQ1gsY0FBYztFQUNkLFVBQVU7RUFDVixTQUFTO0VBQ1QsS0FBSztFQUNMLElBQUk7O0FBUUMsU0FBVSxxQkFBcUIsTUFBb0I7QUFDeEQsUUFBTSxjQUFjLEtBQUs7QUFHekIsTUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLGFBQWEsbUJBQW1CLFdBQVcsR0FBRztBQUN2RSxTQUFLLGtCQUFrQixpQkFBaUI7QUFDeEM7RUFDRDtBQUVBLFFBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFdBQVc7QUFDNUQsTUFBSSxRQUFRO0FBQ1gsU0FBSyxrQkFBa0I7TUFDdEIsT0FBTyxPQUFPLFNBQVM7TUFDdkIsV0FBVyxPQUFPLGFBQWE7TUFDL0IsY0FBYyxPQUFPLGdCQUFnQjtNQUNyQyxVQUFVLE9BQU8sZ0JBQWdCO01BQ2pDLFNBQVMsT0FBTyxpQkFBaUI7TUFDakMsS0FBSyxPQUFPLE9BQU87TUFDbkIsSUFBSSxPQUFPO0tBQ1g7RUFDRixPQUFPO0FBR04sU0FBSyxrQkFBa0I7TUFDdEIsR0FBRztNQUNILElBQUk7S0FDSjtFQUNGO0FBQ0Q7OztBQzFETyxJQUFNLGlCQUErRDs7Ozs7Ozs7Ozs7Ozs7O0FDcUJyRSxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGNBQWM7QUFDcEIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sY0FBYztBQUNwQixJQUFNLGdCQUFnQjtBQUN0QixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGFBQWE7QUFDbkIsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxvQkFBb0I7QUFDMUIsSUFBTSxlQUFlO0FBQ3JCLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sY0FBYztBQUdyQixTQUFVLGVBQWUsT0FBYTtBQUMzQyxVQUFRLE9BQU87SUFDZCxLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1I7QUFDQyxhQUFPLFNBQVMsTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDO0VBQ3JEO0FBQ0Q7QUFRTSxTQUFVLGNBQ2YsT0FDQSxPQUNBLFdBQ0EsT0FBdUI7QUFFdkIsUUFBTSxNQUFNLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUyxFQUFFLElBQUk7QUFDN0QsUUFBTSxLQUFLLE9BQU8sY0FBYyxXQUFXLFVBQVUsU0FBUyxFQUFFLElBQUk7QUFFcEUsTUFBSSxVQUFVLFFBQVc7QUFDeEIsVUFBTSxLQUFLLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUyxFQUFFLElBQUk7QUFDNUQsV0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRSxJQUFJLEVBQUU7RUFDbkM7QUFFQSxTQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxFQUFFO0FBQzdCO0FBU00sU0FBVSxNQUFNLE9BQWUsWUFBWSxHQUFDO0FBQ2pELFNBQU8sS0FBSyxNQUFNLFNBQVMsRUFBRSxFQUFFLFNBQVMsV0FBVyxHQUFHLENBQUM7QUFDeEQ7QUFPTSxTQUFVLFdBQVcsT0FBd0I7QUFDbEQsU0FBTyxLQUFLLE1BQU0sS0FBSyxLQUFLLEVBQzFCLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUUsQ0FBQztBQUNYO0FBU00sU0FBVSxlQUFlLEdBQVcsR0FBVyxHQUFTO0FBQzdELFNBQU8sSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQ2pCLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUUsRUFDUCxZQUFXLENBQUU7QUFDaEI7QUFRTSxTQUFVLGVBQWUsSUFBVTtBQUN4QyxRQUFNLENBQUMsT0FBTyxVQUFVLEtBQUssSUFBSSxHQUFHLE1BQU0sR0FBRztBQUM3QyxTQUFPO0lBQ047SUFDQSxPQUFPLFNBQVMsVUFBVSxFQUFFO0lBQzVCLFFBQVEsU0FBUyxPQUFPLEVBQUU7O0FBRTVCO0FBVU0sU0FBVSxjQUFjLFFBQWdCLFFBQWM7QUFDM0QsUUFBTSxLQUFLLFNBQVMsT0FBTyxRQUFRLE9BQU8sRUFBRSxHQUFHLEVBQUU7QUFDakQsUUFBTSxLQUFLLFNBQVMsT0FBTyxRQUFRLE9BQU8sRUFBRSxHQUFHLEVBQUU7QUFDakQsTUFBSSxPQUFPLE1BQU0sRUFBRSxLQUFLLE9BQU8sTUFBTSxFQUFFO0FBQUcsV0FBTztBQUNqRCxTQUFPLEtBQUssSUFBSSxLQUFLLEVBQUU7QUFDeEI7QUFTTSxTQUFVLHFCQUNmLFlBQStCO0FBRS9CLFFBQU0sYUFBa0UsQ0FBQTtBQUN4RSxhQUFXLENBQUMsT0FBTyxJQUFJLEtBQUssT0FBTyxRQUFRLFVBQVUsR0FBRztBQUN2RCxlQUFXLEtBQUssSUFBSTtNQUNuQixPQUFPLEtBQUs7TUFDWixXQUFXLE1BQU0sUUFBUSxLQUFLLFNBQVMsSUFBSSxLQUFLLFlBQVksQ0FBQTs7RUFFOUQ7QUFDQSxTQUFPO0FBQ1I7QUFZTSxTQUFVLHFCQUNmLFNBQ0EsT0FDQSxPQUNBLFdBQWlCO0FBRWpCLFFBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsTUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLFFBQVEsT0FBTyxTQUFTO0FBQUcsV0FBTztBQUd4RCxNQUFJLFNBQVMsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFXLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBR3ZGLE1BQUksQ0FBQyxRQUFRO0FBQ1osYUFBUyxPQUFPLFVBQVUsS0FBSyxDQUFDLE1BQVU7QUFDekMsVUFBSSxFQUFFLFdBQVc7QUFBTyxlQUFPO0FBQy9CLFlBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFDcEUsVUFBSSxDQUFDLGFBQWE7QUFBUyxlQUFPO0FBRWxDLFlBQU0sU0FBUyxZQUFZLEVBQUU7QUFDN0IsYUFBTyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU07SUFDNUQsQ0FBQztFQUNGO0FBRUEsU0FBTztBQUNSOzs7QUN6TUEsU0FBUyxZQUFZLEdBQU07QUFDMUIsUUFBTSxPQUFPO0lBQ1osTUFBTSxFQUFFO0lBQ1IsSUFBSSxFQUFFO0lBQ04sT0FBTyxFQUFFO0lBQ1QsU0FBUyxFQUFFO0lBQ1gsU0FBUyxFQUFFOztBQUdaLFVBQVEsRUFBRSxNQUFNO0lBQ2YsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sU0FBUyxFQUFFLFdBQVcsQ0FBQSxFQUFFO0lBRTNDLEtBQUs7QUFDSixhQUFPO1FBQ04sR0FBRztRQUNILEtBQUssRUFBRTtRQUNQLEtBQUssRUFBRTtRQUNQLE1BQU0sRUFBRSxRQUFRO1FBQ2hCLE9BQU87O0lBR1QsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sU0FBUyxFQUFFLFdBQVcsTUFBSztJQUU5QyxLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxPQUFPLEVBQUUsU0FBUyxHQUFFO0lBRXZDLEtBQUs7SUFDTCxLQUFLO0lBQ0w7QUFDQyxhQUFPO0VBQ1Q7QUFDRDtBQU1NLFNBQVUsZUFBWTtBQUMzQixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sVUFBc0MsQ0FBQTtBQUU1QyxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLEtBQUssV0FBVztBQUMxQixZQUFNLFdBQVcsY0FBYyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7QUFFcEQsWUFBTSxXQUFXLEVBQUUsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRWpELFlBQU0sU0FBb0M7UUFDekMsTUFBTSxTQUFTLEtBQUssS0FBSyxFQUFFLElBQUk7UUFDL0I7UUFDQSxVQUFVLFlBQVc7UUFFckI7O0FBR0QsY0FBUSxRQUFRLElBQUk7SUFDckI7RUFDRDtBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsaUJBQWM7QUFDN0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxRQUFNLFlBQTBDLENBQUE7QUFFaEQsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxXQUFXLFdBQVc7QUFDaEMsWUFBTSxpQkFBaUIsY0FBYyxPQUFPLFFBQVEsUUFBUSxRQUFRLEVBQUU7QUFHdEUsWUFBTSxjQUFjLFFBQVEsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRzFELFlBQU0sZUFBZSxXQUFXLE9BQU8sQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBR3ZFLG1CQUFhLEtBQUs7UUFDakIsTUFBTTtRQUNOLElBQUk7UUFDSixPQUFPO1FBQ1AsU0FBUztRQUNULFNBQVM7T0FDVDtBQUdELFlBQU0sZ0JBQXFCO1FBQzFCLE1BQU07UUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtRQUNyQyxTQUFTO1FBQ1QsVUFBVSxNQUFLO0FBRWQsaUJBQU87UUFDUjs7QUFHRCxnQkFBVSxjQUFjLElBQUk7SUFDN0I7RUFDRDtBQUVBLFNBQU87QUFDUjs7O0FDOUhBLE9BQU9DLFdBQVU7OztBQ0xqQixPQUFPQyxTQUFRO0FBaUJmLElBQU1DLFVBQVMsbUJBQW1CLGdCQUFnQjtBQXlDbEQsU0FBUyxlQUFlLE9BQWE7QUFDcEMsUUFBTSxTQUFTLG9CQUFJLElBQUc7QUFDdEIsTUFBSSxZQUFZO0FBRWhCLE1BQUk7QUFFSCxVQUFNLE9BQU8sZ0JBQWdCLEtBQUs7QUFDbEMsUUFBSSxDQUFDLE1BQU07QUFFVixhQUFPLEVBQUUsV0FBVyxPQUFNO0lBQzNCO0FBR0EsZ0JBQVksS0FBSyxhQUFhO0FBRzlCLGVBQVcsVUFBVSxLQUFLLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0saUJBQWlCLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBd0IsSUFBSSxTQUFTLGFBQWE7QUFDL0YsVUFBSSxnQkFBZ0I7QUFFbkIsZUFBTyxJQUFJLE9BQU8sRUFBRTtBQUdwQixjQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLE9BQU8sT0FBTztBQUNwRixZQUFJLGFBQWEsU0FBUztBQUN6QixxQkFBVyxVQUFVLFlBQVksU0FBUztBQUN6QyxnQkFBSSxPQUFPLE9BQU8sT0FBTyxVQUFVO0FBQ2xDLHFCQUFPLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRTtZQUNqQztVQUNEO1FBQ0Q7TUFDRDtJQUNEO0VBQ0QsU0FBUyxNQUFNO0VBRWY7QUFFQSxTQUFPLEVBQUUsV0FBVyxPQUFNO0FBQzNCO0FBTUEsU0FBUyxzQkFBc0IsS0FBVztBQUN6QyxRQUFNLFdBQVcsSUFBSSxRQUFRLE9BQU8sS0FBSyxVQUFVLENBQUM7QUFDcEQsTUFBSSxXQUFXO0FBQUcsVUFBTSxJQUFJLE1BQU0saUNBQWlDO0FBRW5FLFFBQU0sZUFBZSxXQUFXO0FBQ2hDLE1BQUksSUFBSSxZQUFZLE1BQU0sSUFBTTtBQUMvQixVQUFNLElBQUksTUFBTSx1Q0FBdUMsSUFBSSxZQUFZLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRTtFQUN4RjtBQUVBLFNBQU87QUFDUjtBQU1BLFNBQVMsdUJBQXVCLE9BQWUsU0FBc0Isb0JBQUksSUFBRyxHQUFFO0FBQzdFLE1BQUksSUFBSTtBQUNSLFFBQU0sTUFBdUIsQ0FBQTtBQUU3QixTQUFPLElBQUksTUFBTSxRQUFRO0FBQ3hCLFVBQU0sS0FBSyxNQUFNLENBQUM7QUFDbEIsUUFBSSxJQUFJLEtBQUssTUFBTTtBQUFRO0FBRzNCLFFBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTSxRQUFRO0FBQzNDLFVBQUksS0FBSztRQUNSLFFBQVE7UUFDUjtRQUNBLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQztPQUNyRDtBQUNELFdBQUs7QUFDTDtJQUNEO0FBRUEsUUFBSSxLQUFLLEVBQUUsUUFBUSxjQUFjLElBQUksWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFFO0FBQ2pFLFNBQUs7RUFDTjtBQUVBLFNBQU87QUFDUjtBQUVNLFNBQVUseUJBQXlCLEtBQWEsT0FBYTtBQUNsRSxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSw0QkFBNEI7RUFDN0M7QUFFQSxRQUFNLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFDNUIsUUFBTSxRQUFRLE1BQU07QUFDcEIsUUFBTSxNQUFNLFFBQVE7QUFDcEIsTUFBSSxNQUFNLElBQUk7QUFBUSxVQUFNLElBQUksTUFBTSxzQkFBc0I7QUFFNUQsUUFBTSxFQUFFLE9BQU0sSUFBSyxlQUFlLEtBQUs7QUFDdkMsU0FBTyx1QkFBdUIsSUFBSSxTQUFTLE9BQU8sR0FBRyxHQUFHLE1BQU07QUFDL0Q7QUFNTSxTQUFVLDhCQUE4QixLQUFhLE9BQWE7QUFDdkUsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0sNEJBQTRCO0VBQzdDO0FBR0EsTUFBSSxJQUFJLFVBQVUsdUJBQXVCLE1BQU0sSUFBSSxNQUFNO0FBQ3pELFFBQU0sTUFBTSxJQUFJLFNBQVM7QUFDekIsUUFBTSxNQUF1QixDQUFBO0FBRzdCLFFBQU0sRUFBRSxPQUFNLElBQUssZUFBZSxLQUFLO0FBSXZDLFFBQU0sb0JBQW9CLENBQUMsYUFBYSxpQkFBaUIsV0FBVztBQUtwRSxRQUFNLG1CQUFtQixDQUFDLFdBQVc7QUFFckMsU0FBTyxJQUFJLElBQUksS0FBSztBQUNuQixVQUFNLFNBQVMsSUFBSSxDQUFDO0FBQ3BCLFVBQU0sZUFBZSxJQUFJLElBQUksQ0FBQztBQUU5QixVQUFNLGFBQWEsSUFBSSxJQUFJO0FBQzNCLFFBQUksYUFBYTtBQUFLO0FBRXRCLFVBQU0sV0FBVyxrQkFBa0IsU0FBUyxZQUFZO0FBQ3hELFVBQU0sYUFBYSxpQkFBaUIsU0FBUyxZQUFZO0FBRXpELFFBQUk7QUFDSixRQUFJO0FBQ0osUUFBSTtBQUVKLFFBQUksWUFBWTtBQUdmLGNBQVEsSUFBSSxJQUFJLENBQUM7QUFDakIsWUFBTSxXQUFXLElBQUksU0FBUyxJQUFJLEdBQUcsVUFBVTtBQUMvQyxlQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQ3pDLFlBQUksS0FBSyxFQUFFLFFBQVEsY0FBYyxJQUFJLEdBQUcsT0FBTyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBQyxDQUFFO01BQzNFO0FBQ0EsVUFBSTtBQUNKO0lBQ0QsV0FBVyxVQUFVO0FBRXBCLGNBQVEsSUFBSSxJQUFJLENBQUM7QUFDakIsZ0JBQVUsSUFBSSxJQUFJLENBQUM7QUFDbkIsVUFBSSxJQUFJO0lBQ1QsT0FBTztBQUVOLGdCQUFVLElBQUksSUFBSSxDQUFDO0FBQ25CLFVBQUksSUFBSTtJQUNUO0FBRUEsVUFBTSxPQUFPLElBQUk7QUFDakIsVUFBTSxTQUFTO0FBRWYsV0FBTyxJQUFJLElBQUksTUFBTTtBQUNwQixZQUFNLEtBQUssSUFBSSxDQUFDO0FBQ2hCLFVBQUk7QUFHSixVQUFJLE9BQU8sSUFBSSxFQUFFLEtBQUssSUFBSSxJQUFJLE1BQU07QUFDbkMscUJBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQztBQUNoRCxhQUFLO01BQ04sT0FBTztBQUNOLHFCQUFhLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQztBQUN4QixhQUFLO01BQ047QUFFQSxZQUFNLFVBQXlCO1FBQzlCLFFBQVE7UUFDUjtRQUNBOztBQUVELFVBQUksVUFBVSxRQUFXO0FBQ3hCLGdCQUFRLFFBQVE7TUFDakI7QUFDQSxVQUFJLEtBQUssT0FBTztJQUNqQjtBQVFBLFFBQUksTUFBTSxVQUFVLGFBQWEsSUFBSSxHQUFHO0FBQ3ZDLFVBQUksTUFBTSxXQUFXLElBQUksSUFBSSxJQUFJO0FBQ2pDLFVBQUksUUFBUTtBQUNaLGFBQU8sTUFBTSxZQUFZO0FBQ3hCLGNBQU0sVUFBeUIsRUFBRSxRQUFRLGNBQWMsSUFBSSxTQUFTLFlBQVksQ0FBQyxJQUFJLEtBQUssQ0FBQyxFQUFDO0FBQzVGLFlBQUksVUFBVTtBQUFXLGtCQUFRLFFBQVE7QUFDekMsWUFBSSxLQUFLLE9BQU87TUFDakI7SUFDRDtBQUVBLFFBQUk7RUFDTDtBQUVBLFNBQU87QUFDUjtBQVdNLFNBQVUsc0JBQXNCLE9BQWUsS0FBVztBQUMvRCxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSxpQ0FBaUMsTUFBTSxTQUFTLEVBQUUsQ0FBQyxHQUFHO0VBQ3ZFO0FBQ0EsUUFBTSxFQUFFLFVBQVMsSUFBSyxlQUFlLEtBQUs7QUFDMUMsU0FBTyxZQUFZLDhCQUE4QixLQUFLLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxLQUFLO0FBQ25HO0FBTU0sU0FBVSxvQkFBb0IsU0FBd0IsU0FBbUI7QUFFOUUsTUFBSSxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFFBQVEsVUFBVSxFQUFFLE9BQU8sUUFBUSxFQUFFO0FBS25GLE1BQUksQ0FBQyxRQUFRO0FBQ1osVUFBTSxhQUFhLFFBQVEsS0FBSyxDQUFDLE1BQUs7QUFDckMsVUFBSSxFQUFFLFdBQVcsUUFBUTtBQUFRLGVBQU87QUFFeEMsWUFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUMvRCxVQUFJLENBQUMsYUFBYTtBQUFTLGVBQU87QUFFbEMsWUFBTSxnQkFBZ0IsUUFBUSxLQUFLLEVBQUU7QUFDckMsYUFBTyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGFBQWE7SUFDOUQsQ0FBQztBQUNELFFBQUksWUFBWTtBQUNmLGVBQVM7SUFDVjtFQUNEO0FBRUEsUUFBTSxTQUFTLE1BQU0sUUFBUSxNQUFNO0FBQ25DLFFBQU0sUUFBUSxNQUFNLFFBQVEsRUFBRTtBQUM5QixRQUFNLFNBQVMsV0FBVyxRQUFRLFVBQVU7QUFDNUMsUUFBTSxTQUNMLFFBQVEsV0FBVyxXQUFXLElBQzNCLGVBQWUsUUFBUSxXQUFXLENBQUMsR0FBRyxRQUFRLFdBQVcsQ0FBQyxHQUFHLFFBQVEsV0FBVyxDQUFDLENBQUMsSUFDbEYsUUFBUSxXQUFXLFdBQVcsSUFDN0IsUUFBUSxXQUFXLENBQUMsSUFDcEIsUUFBUSxXQUFXLEtBQUssR0FBRztBQUdoQyxRQUFNLFdBQVcsUUFBUSxVQUFVLFNBQVksT0FBTyxRQUFRLEtBQUssS0FBSztBQUN4RSxRQUFNLFNBQVMsT0FBTyxNQUFNLEdBQUcsUUFBUSxPQUFPLEtBQUssUUFBUSxNQUFNO0FBR2pFLE1BQUksUUFBUTtBQUNYLFFBQUksT0FBTyxPQUFPO0FBR2xCLFFBQUksUUFBUSxVQUFVLFFBQVc7QUFDaEMsYUFBTyxHQUFHLElBQUksTUFBTSxRQUFRLFFBQVEsQ0FBQztJQUN0QyxPQUVLO0FBQ0osWUFBTSxjQUFjLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUNwRSxVQUFJLGFBQWEsU0FBUztBQUN6QixjQUFNLGdCQUFnQixRQUFRLEtBQUssT0FBTztBQUMxQyxjQUFNLGNBQWMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxhQUFhO0FBQzFFLFlBQUksYUFBYTtBQUNoQixpQkFBTyxHQUFHLElBQUksSUFBSSxZQUFZLEtBQUs7UUFDcEM7TUFDRDtJQUNEO0FBR0EsVUFBTSxjQUFjLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUNwRSxRQUFJLGFBQWEsV0FBVyxRQUFRLFdBQVcsV0FBVyxHQUFHO0FBQzVELFlBQU0sU0FBUyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsV0FBVyxDQUFDLENBQUM7QUFDN0UsVUFBSSxRQUFRO0FBQ1gsZUFBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssT0FBTyxLQUFLLEtBQUssTUFBTTtNQUN2RDtJQUNEO0FBQ0EsV0FBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssTUFBTTtFQUN0QztBQUdBLFNBQU8sR0FBRyxNQUFNO0FBQ2pCO0FBaUJNLFNBQVUsaUNBQ2YsT0FDQSxLQUFXO0FBRVgsUUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQU0sb0JBQW9CLFFBQVE7QUFHbEMsTUFBSSxzQkFBc0IsUUFBVztBQUNwQyxVQUFNLFdBQVcsb0JBQ2QsOEJBQThCLEtBQUssS0FBSyxJQUN4Qyx5QkFBeUIsS0FBSyxLQUFLO0FBQ3RDLFdBQU8sRUFBRSxVQUFVLG1CQUFtQixLQUFJO0VBQzNDO0FBR0EsTUFBSSxlQUFnQyxDQUFBO0FBQ3BDLE1BQUksb0JBQXFDLENBQUE7QUFFekMsTUFBSTtBQUNILG1CQUFlLHlCQUF5QixLQUFLLEtBQUs7RUFDbkQsU0FBUyxHQUFHO0FBQ1gsSUFBQUEsUUFBTyxNQUFNLHVCQUF1QixDQUFDLEVBQUU7RUFDeEM7QUFFQSxNQUFJO0FBQ0gsd0JBQW9CLDhCQUE4QixLQUFLLEtBQUs7RUFDN0QsU0FBUyxHQUFHO0FBQ1gsSUFBQUEsUUFBTyxNQUFNLDRCQUE0QixDQUFDLEVBQUU7RUFDN0M7QUFHQSxNQUFJLGtCQUFrQixTQUFTLGFBQWEsUUFBUTtBQUNuRCxJQUFBQSxRQUFPLEtBQUssNkNBQTZDLGtCQUFrQixNQUFNLFlBQVksYUFBYSxNQUFNLEdBQUc7QUFDbkgsV0FBTyxFQUFFLFVBQVUsbUJBQW1CLG1CQUFtQixLQUFJO0VBQzlELFdBQVcsYUFBYSxTQUFTLEdBQUc7QUFDbkMsSUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxhQUFhLE1BQU0saUJBQWlCLGtCQUFrQixNQUFNLEdBQUc7QUFDOUcsV0FBTyxFQUFFLFVBQVUsY0FBYyxtQkFBbUIsTUFBSztFQUMxRCxPQUFPO0FBRU4sSUFBQUEsUUFBTyxLQUFLLHVEQUF1RCxLQUFLLEVBQUU7QUFDMUUsV0FBTyxFQUFFLFVBQVUsQ0FBQSxHQUFJLG1CQUFtQixLQUFJO0VBQy9DO0FBQ0Q7QUFFTSxTQUFVLDRCQUE0QixPQUFlLEtBQVc7QUFDckUsUUFBTSxFQUFFLFVBQVMsSUFBSyxlQUFlLEtBQUs7QUFDMUMsU0FBTyxZQUFZLDhCQUE4QixLQUFLLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxLQUFLO0FBQ25HO0FBU0EsU0FBUyxtQkFBbUIsWUFBb0I7QUFDL0MsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUM1QixXQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLFVBQVUsU0FBUyxXQUFXLENBQUMsRUFBQztFQUM3RTtBQUVBLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsVUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLElBQUk7QUFDbEIsV0FBTztNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsTUFBTTtNQUNOLFNBQVMsZUFBZSxHQUFHLEdBQUcsQ0FBQzs7RUFFakM7QUFFQSxTQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLE9BQU8sU0FBUyxDQUFDLEdBQUcsVUFBVSxFQUFDO0FBQzVFO0FBTU0sU0FBVSw0QkFDZixXQUNBLFFBQ0EsV0FBc0M7QUFFdEMsUUFBTSxNQUFNLGdCQUFnQixTQUFTO0FBR3JDLE1BQUksQ0FBQyxJQUFJLFdBQVc7QUFDbkIsUUFBSSxZQUFZLENBQUE7RUFDakI7QUFHQSxRQUFNLGFBQWEsT0FBTyxPQUFPLFNBQVMsRUFDeEMsT0FBTyxDQUFDLE1BQU0sRUFBRSxVQUFVLFVBQVUsS0FBSyxFQUN6QyxLQUFLLENBQUMsR0FBRyxNQUFNLGNBQWMsVUFBVSxPQUFPLEVBQUUsS0FBSyxJQUFJLGNBQWMsVUFBVSxPQUFPLEVBQUUsS0FBSyxDQUFDO0FBRWxHLEVBQUFDLFFBQU8sS0FBSyxtQkFBbUIsVUFBVSxLQUFLLEVBQUU7QUFDaEQsRUFBQUEsUUFBTyxNQUFNLDZCQUE2QixXQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssSUFBSSxDQUFDLEVBQUU7QUFLckYsUUFBTSxtQkFBbUIsb0JBQUksSUFBRztBQUNoQyxhQUFXLEtBQUssWUFBWTtBQUMzQixlQUFXLGFBQWEsRUFBRSxhQUFhLENBQUEsR0FBSTtBQUMxQyxZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxPQUFPO0FBQ3JFLFVBQUksQ0FBQyxVQUFVO0FBQVM7QUFDeEIsWUFBTSxTQUFTLFVBQVU7QUFDekIsWUFBTSxRQUFRLFVBQVU7QUFDeEIsWUFBTSxNQUFNLEdBQUcsS0FBSyxJQUFJLE1BQU07QUFDOUIsVUFBSSxpQkFBaUIsSUFBSSxHQUFHO0FBQUc7QUFFL0IsWUFBTSxnQkFBZ0IsT0FDcEIsT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxLQUFLLE1BQU0sRUFDakQsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLE1BQU0sRUFDeEIsS0FBSyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFFdEIsVUFBSSxTQUFTO0FBQ2IsaUJBQVcsT0FBTyxlQUFlO0FBQ2hDLFlBQUksUUFBUSxTQUFTO0FBQUcsbUJBQVM7aUJBQ3hCLE1BQU0sU0FBUztBQUFHO01BQzVCO0FBQ0EsVUFBSSxTQUFTLEdBQUc7QUFDZix5QkFBaUIsSUFBSSxLQUFLLE1BQU07QUFDaEMsUUFBQUEsUUFBTyxNQUFNLGdDQUFnQyxNQUFNLEtBQUssQ0FBQyxZQUFZLE1BQU0sTUFBTSxDQUFDLG9CQUFlLE1BQU0sRUFBRTtNQUMxRztJQUNEO0VBQ0Q7QUFJQSxRQUFNLFlBQVksb0JBQUksSUFBRztBQUN6QixhQUFXLEVBQUUsUUFBUSxJQUFJLE1BQUssS0FBTSxRQUFRO0FBQzNDLFFBQUksVUFBVTtBQUFXO0FBQ3pCLFVBQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxFQUFFO0FBQzNCLFFBQUksQ0FBQyxVQUFVLElBQUksR0FBRztBQUFHLGdCQUFVLElBQUksS0FBSyxvQkFBSSxJQUFHLENBQUU7QUFDckQsY0FBVSxJQUFJLEdBQUcsRUFBRyxJQUFJLEtBQUs7RUFDOUI7QUFNQSxhQUFXLEVBQUUsUUFBUSxJQUFJLE9BQU8sV0FBVSxLQUFNLFFBQVE7QUFFdkQsVUFBTSxnQkFBZ0IsSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ2xGLFFBQUksZUFBZTtBQUNsQixZQUFNLE1BQU0sY0FBYyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQy9ELFVBQUk7QUFBSyxZQUFJLFVBQVUsbUJBQW1CLFVBQVUsRUFBRTtBQUN0RDtJQUNEO0FBS0EsVUFBTSxZQUFZLElBQUksVUFBVSxLQUFLLENBQUMsTUFBSztBQUMxQyxVQUFJLEVBQUUsV0FBVztBQUFRLGVBQU87QUFDaEMsWUFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUN4RCxVQUFJLENBQUMsVUFBVTtBQUFTLGVBQU87QUFDL0IsVUFBSSxNQUFNLEVBQUU7QUFBSSxlQUFPO0FBQ3ZCLFlBQU0sU0FBUyxLQUFLLEVBQUU7QUFFdEIsYUFBTyxXQUFXLEtBQUssQ0FBQyxNQUFLO0FBQzVCLGNBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUUsRUFBRTtBQUM5RSxjQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLGVBQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO01BQzdELENBQUM7SUFDRixDQUFDO0FBQ0QsUUFBSSxXQUFXO0FBQ2QsWUFBTSxTQUFTLEtBQUssVUFBVTtBQUM5QixZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFVBQUksVUFBVSxXQUFXLENBQUMsU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNLEdBQUc7QUFDN0UsWUFBSSxRQUFRLFdBQVcsU0FBUyxDQUFDO0FBQ2pDLG1CQUFXLEtBQUssWUFBWTtBQUMzQixnQkFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLGdCQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLGdCQUFNLFlBQVksVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO0FBQ3ZFLGNBQUksV0FBVztBQUNkLG9CQUFRLFVBQVU7QUFDbEI7VUFDRDtRQUNEO0FBQ0EsaUJBQVMsUUFBUSxLQUFLLEVBQUUsSUFBSSxRQUFRLE1BQUssQ0FBRTtBQUMzQyxRQUFBQSxRQUFPLEtBQ04saUJBQWlCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsdUJBQXVCLE1BQU0sVUFBVSxFQUFFLENBQUMsY0FBYyxNQUFNLE1BQU0sS0FBSyxJQUFJO01BRTdIO0FBQ0E7SUFDRDtBQUdBLFFBQUk7QUFFSixlQUFXLEtBQUssWUFBWTtBQUMzQixZQUFNLFFBQVEsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ3pFLFVBQUksT0FBTztBQUNWLGlCQUFTLGdCQUFnQixLQUFLO0FBRTlCLGNBQU0sV0FBVyxNQUFNLEtBQUssUUFBUSxxQ0FBcUMsRUFBRSxFQUFFLEtBQUk7QUFDakYsZUFBTyxPQUFPLEdBQUcsUUFBUSx5QkFBeUIsRUFBRSxLQUFLO0FBQ3pELFFBQUFBLFFBQU8sS0FBSyxtQkFBbUIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxVQUFVO0FBQzVGO01BQ0Q7SUFDRDtBQUlBLFFBQUksQ0FBQyxRQUFRO0FBQ1osVUFBSSxjQUFjO0FBQ2xCLGlCQUFXLEtBQUssWUFBWTtBQUMzQixjQUFNLFlBQVksRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFVO0FBQzlDLGNBQUksRUFBRSxXQUFXO0FBQVEsbUJBQU87QUFDaEMsZ0JBQU0sV0FBVyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE9BQU87QUFDN0QsY0FBSSxDQUFDLFVBQVU7QUFBUyxtQkFBTztBQUMvQixjQUFJLE1BQU0sRUFBRTtBQUFJLG1CQUFPO0FBQ3ZCLGdCQUFNLFNBQVMsS0FBSyxFQUFFO0FBQ3RCLGdCQUFNLFNBQVMsaUJBQWlCLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSztBQUM1RCxpQkFBTyxVQUFVO1FBQ2xCLENBQUM7QUFDRCxZQUFJLFdBQVc7QUFDZCx3QkFBYztBQUNkLFVBQUFBLFFBQU8sTUFDTixVQUFVLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsNENBQTRDLE1BQU0sVUFBVSxFQUFFLENBQUMsNkJBQXdCO0FBRS9IO1FBQ0Q7TUFDRDtBQUNBLFVBQUk7QUFBYTtJQUNsQjtBQUdBLFFBQUksQ0FBQyxRQUFRO0FBQ1osZUFBUztRQUNSO1FBQ0E7UUFDQSxNQUFNLGVBQWUsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsRUFBRSxZQUFXLENBQUU7UUFDaEUsU0FBUyxDQUFDLG1CQUFtQixVQUFVLENBQUM7O0FBRXpDLFVBQUksVUFBVTtBQUFXLGVBQU8sUUFBUTtBQUN4QyxNQUFBQSxRQUFPLEtBQUssMEJBQTBCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsRUFBRTtJQUN0RSxPQUFPO0FBSU4sYUFBTyxVQUFVLE9BQU8sU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxLQUFLLENBQUE7QUFDcEUsYUFBTyxPQUFPO0FBRWQsWUFBTSxrQkFBa0IsVUFBVSxJQUFJLEdBQUcsTUFBTSxJQUFJLEVBQUUsRUFBRTtBQUN2RCxVQUFJLG1CQUFtQixnQkFBZ0IsT0FBTyxHQUFHO0FBQ2hELGNBQU0sV0FBVyxLQUFLLElBQUksR0FBRyxlQUFlO0FBQzVDLFlBQUksYUFBYSxHQUFHO0FBRW5CLGlCQUFPLFFBQVE7UUFDaEIsT0FBTztBQUVOLGdCQUFNLGVBQWUsTUFBTSxLQUFLLEVBQUUsUUFBUSxXQUFXLEVBQUMsR0FBSSxDQUFDLEdBQUcsT0FBTztZQUNwRSxJQUFJO1lBQ0osT0FBTyxXQUFXLElBQUksQ0FBQztZQUN0QjtBQUNGLGlCQUFPLFFBQVEsUUFBUTtZQUN0QixJQUFJO1lBQ0osT0FBTztZQUNQLE1BQU07WUFDTixTQUFTO1lBQ1QsU0FBUztXQUNGO1FBQ1Q7TUFDRDtBQU1BLFlBQU0sa0JBQWtCLG1CQUFtQixVQUFVLEVBQUU7QUFDdkQsWUFBTSxXQUFXLE9BQU8sU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUM3RCxVQUFJLFVBQVU7QUFDYixZQUFJLFNBQVMsV0FBVyxNQUFNLFFBQVEsU0FBUyxPQUFPLEdBQUc7QUFDeEQsZ0JBQU0sWUFBWSxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLGVBQWU7QUFDNUUsY0FBSSxDQUFDLFdBQVc7QUFDZixZQUFBQSxRQUFPLEtBQ04sK0JBQStCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsaUNBQWlDLGVBQWUsc0NBQWlDO0FBRzlJLHFCQUFTLE9BQU87QUFDaEIsbUJBQVEsU0FBaUI7VUFDMUI7UUFDRDtBQUNBLGlCQUFTLFVBQVU7TUFDcEI7SUFDRDtBQUVBLFFBQUksVUFBVSxLQUFLLE1BQU07RUFDMUI7QUFTQSxhQUFXLEVBQUUsUUFBUSxHQUFFLEtBQU0sUUFBUTtBQUNwQyxVQUFNLGtCQUFrQixJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDcEYsUUFBSTtBQUFpQjtBQUdyQixVQUFNLFlBQVksSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFLO0FBQzFDLFVBQUksRUFBRSxXQUFXO0FBQVEsZUFBTztBQUNoQyxZQUFNQyxZQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUN4RCxhQUFPLENBQUMsQ0FBQ0EsV0FBVSxXQUFXLEtBQUssRUFBRTtJQUN0QyxDQUFDO0FBQ0QsUUFBSSxDQUFDO0FBQVc7QUFFaEIsVUFBTSxTQUFTLEtBQUssVUFBVTtBQUM5QixVQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFFBQUksQ0FBQyxVQUFVLFdBQVcsU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0FBQUc7QUFJOUUsVUFBTSxlQUFlLFdBQVcsS0FBSyxDQUFDLE1BQUs7QUFDMUMsWUFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsYUFBTyxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07SUFDN0QsQ0FBQztBQUNELFVBQU0sa0JBQWtCLFNBQVMsUUFBUSxJQUFJLENBQUMsTUFBVyxFQUFFLEVBQVksRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUM3RixVQUFNLGVBQWUsZ0JBQWdCLFNBQVMsS0FBSyxXQUFXLGdCQUFnQixnQkFBZ0IsU0FBUyxDQUFDLElBQUk7QUFFNUcsUUFBSSxDQUFDLGdCQUFnQixDQUFDO0FBQWM7QUFHcEMsUUFBSSxRQUFRLFdBQVcsU0FBUyxDQUFDO0FBQ2pDLGVBQVcsS0FBSyxZQUFZO0FBQzNCLFlBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLFVBQVUsRUFBRTtBQUN0RixZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFlBQU0sWUFBWSxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07QUFDdkUsVUFBSSxXQUFXO0FBQ2QsZ0JBQVEsVUFBVTtBQUNsQjtNQUNEO0lBQ0Q7QUFFQSxhQUFTLFFBQVEsS0FBSyxFQUFFLElBQUksUUFBUSxNQUFLLENBQUU7QUFDM0MsSUFBQUQsUUFBTyxLQUNOLHlCQUF5QixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLHVCQUF1QixNQUFNLFVBQVUsRUFBRSxDQUFDLGNBQWMsTUFBTSxNQUFNLEtBQUssSUFBSTtFQUVySTtBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsb0JBQW9CLFVBQWtCLFNBQW9CO0FBQ3pFLE1BQUk7QUFFSCxVQUFNLGFBQWtCLEVBQUUsT0FBTyxRQUFRLE1BQUs7QUFHOUMsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRO0lBQ2hDO0FBR0EsUUFBSSx5QkFBeUIsU0FBUztBQUNyQyxpQkFBVyxzQkFBc0IsUUFBUTtJQUMxQztBQUNBLFFBQUksZUFBZSxTQUFTO0FBQzNCLGlCQUFXLFlBQVksUUFBUSxVQUFVLElBQUksQ0FBQyxVQUFjO0FBRTNELGNBQU0sZUFBb0IsQ0FBQTtBQUMxQixZQUFJLFlBQVk7QUFBTyx1QkFBYSxTQUFTLE1BQU07QUFDbkQsWUFBSSxRQUFRO0FBQU8sdUJBQWEsS0FBSyxNQUFNO0FBQzNDLFlBQUksV0FBVztBQUFPLHVCQUFhLFFBQVEsTUFBTTtBQUNqRCxZQUFJLFVBQVU7QUFBTyx1QkFBYSxPQUFPLE1BQU07QUFDL0MsWUFBSSxhQUFhO0FBQU8sdUJBQWEsVUFBVSxNQUFNO0FBRXJELG1CQUFXLE9BQU8sT0FBTyxLQUFLLEtBQUssR0FBRztBQUNyQyxjQUFJLEVBQUUsT0FBTztBQUFlLHlCQUFhLEdBQUcsSUFBSSxNQUFNLEdBQUc7UUFDMUQ7QUFDQSxlQUFPO01BQ1IsQ0FBQztJQUNGO0FBRUEsZUFBVyxPQUFPLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDdkMsVUFBSSxFQUFFLE9BQU8sYUFBYTtBQUN6QixtQkFBVyxHQUFHLElBQUssUUFBZ0IsR0FBRztNQUN2QztJQUNEO0FBR0EsUUFBSSxPQUFPLEtBQUssVUFBVSxZQUFZLE1BQU0sQ0FBQztBQUs3QyxXQUFPLEtBQUssUUFBUSwwREFBMEQsNkJBQTZCO0FBRTNHLElBQUFFLElBQUcsY0FBYyxVQUFVLE9BQU8sTUFBTSxNQUFNO0VBQy9DLFNBQVMsR0FBRztBQUNYLElBQUFGLFFBQU8sTUFBTSxxQkFBcUIsQ0FBQyxFQUFFO0VBQ3RDO0FBQ0Q7OztBRHZ3QkEsSUFBTUcsVUFBUyxtQkFBbUIsU0FBUztBQUVyQyxTQUFVLGNBQWMsTUFBb0I7QUFDakQsUUFBTSxhQUFhLGlCQUFnQjtBQUNuQyxRQUFNLGFBQWEsYUFBWTtBQUMvQixRQUFNLFVBQVUscUJBQXFCLFVBQVU7QUFDL0MsUUFBTSxlQUFvQixDQUFBO0FBRTFCLFFBQU0sY0FBYyxLQUFLO0FBTXpCLGVBQWEsdUJBQXVCLElBQUk7SUFDdkMsTUFBTTtJQUNOLFNBQVMsQ0FBQTtJQUNULFVBQVUsWUFBVztBQUNwQixZQUFNLFFBQVE7QUFDZCxZQUFNLEtBQUssS0FBSztBQUVoQixZQUFNLE1BQU0sTUFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUU7QUFHekQsVUFBSSxZQUFZLGdCQUFnQixLQUFLO0FBR3JDLFlBQU0sRUFBRSxVQUFVLFFBQVEsa0JBQWlCLElBQUssaUNBQWlDLE9BQU8sR0FBRztBQUMzRixNQUFBQSxRQUFPLE1BQU0saUJBQWlCLEtBQUssVUFBVSxNQUFNLENBQUMsRUFBRTtBQUV0RCxVQUFJLENBQUMsV0FBVztBQUVmLFFBQUFBLFFBQU8sS0FBSyxTQUFTLEtBQUssdURBQWtEO0FBQzVFLG9CQUFZO1VBQ1g7VUFDQSxXQUFXLHFCQUFxQjtVQUNoQyxxQkFBcUI7VUFDckIsV0FBVyxDQUFBOztNQUViLFdBQVcsc0JBQXNCLE1BQU07QUFFdEMsUUFBQUEsUUFBTyxLQUFLLDJCQUEyQixpQkFBaUIsd0JBQXdCO0FBQ2hGLG9CQUFZLEVBQUUsR0FBRyxXQUFXLFdBQVcsa0JBQWlCO01BQ3pEO0FBRUEsWUFBTSxVQUFVLDRCQUE0QixXQUFXLFFBQVEsT0FBTztBQUN0RSxNQUFBQSxRQUFPLE1BQU0scUJBQXFCLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxDQUFDLEVBQUU7QUFHcEUsWUFBTUMsaUJBQWdCLGlCQUFnQjtBQUN0QyxZQUFNLGFBQWFDLE1BQUssS0FBS0QsZ0JBQWUsUUFBUSxLQUFLLE9BQU87QUFDaEUsMEJBQW9CLFlBQVksT0FBTztBQUd2QywwQkFBbUI7QUFFbkIsTUFBQUQsUUFBTyxLQUFLLFNBQVMsS0FBSyx3Q0FBd0M7SUFDbkU7O0FBT0QsYUFBVyxDQUFDLFVBQVUsTUFBTSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDNUQsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxRQUFRO0FBR3hELFFBQUksVUFBVTtBQUFhO0FBRzNCLFVBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsVUFBTSxZQUFZLFFBQVEsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sTUFBTTtBQUUzRixpQkFBYSxRQUFRLElBQUk7TUFDeEIsR0FBRztNQUNILFVBQVUsT0FBTyxVQUFjO0FBQzlCLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBQ3pGLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTztBQUNuQyxjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxjQUFNLFlBQVksU0FBUztBQUUzQixjQUFNLEtBQUssYUFBYSxhQUFhLE9BQU8sT0FBTyxXQUFXLE9BQU8sRUFBRTtNQUN4RTs7RUFFRjtBQUtBLFFBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsTUFBSSxjQUFjO0FBQ2pCLFVBQU0sbUJBQW1CLGFBQWEsYUFBYSxDQUFBLEdBQUksS0FBSyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsS0FBSyxDQUFDO0FBRTlGLFFBQUksaUJBQWlCO0FBQ3BCLFlBQU0sV0FBVyxHQUFHLFdBQVc7QUFFL0IsbUJBQWEsUUFBUSxJQUFJO1FBQ3hCLE1BQU0sU0FBUyxXQUFXO1FBQzFCLFNBQVMsQ0FBQTtRQUNULFVBQVUsWUFBVztBQUNwQixnQkFBTSxLQUFLLEtBQUs7QUFDaEIsVUFBQUEsUUFBTyxLQUFLLHlCQUFvQixXQUFXLE1BQU0sRUFBRSxFQUFFO0FBQ3JELGdCQUFNLEtBQUssYUFBYSxjQUFjLEVBQUU7QUFDeEMsZ0JBQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDNUQsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGOztJQUVGO0VBQ0Q7QUFFQSxPQUFLLHFCQUFxQixZQUFZO0FBR3ZDOzs7QUVySEEsU0FBUyxpQkFDUixTQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQWE7QUFFYixRQUFNLFVBQVUscUJBQXFCLFNBQVMsT0FBTyxPQUFPLFNBQVM7QUFDckUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLFFBQVEsUUFBUSxPQUFPO0FBQUcsV0FBTztBQUd4RCxRQUFNLGNBQWMsUUFBUSxRQUFRLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3pFLE1BQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxRQUFRLFlBQVksT0FBTztBQUFHLFdBQU87QUFHaEUsUUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sS0FBSztBQUNsRSxTQUFPLFFBQVEsU0FBUztBQUN6QjtBQU1NLFNBQVUsZ0JBQWdCLE1BQW9CO0FBQ25ELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxlQUFlLGVBQWM7QUFDbkMsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0saUJBQXNCLENBQUE7QUFHNUIsUUFBTSxjQUFjLEtBQUs7QUFNekIsYUFBVyxDQUFDLFlBQVksUUFBUSxLQUFLLE9BQU8sUUFBUSxZQUFZLEdBQUc7QUFDbEUsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxVQUFVO0FBRzFELFFBQUksVUFBVTtBQUFhO0FBRzNCLG1CQUFlLFVBQVUsSUFBSTtNQUM1QixHQUFHO01BQ0gsVUFBVSxDQUFDLGtCQUFzQjtBQUNoQyxjQUFNLEtBQUssS0FBSztBQUNoQixjQUFNLFFBQVEsY0FBYyxRQUFRLE9BQU8sS0FBSztBQUNoRCxjQUFNLFlBQVksU0FBUztBQUczQixZQUFJLFFBQVEsY0FBYyxRQUFRLE9BQU87QUFDekMsWUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQU0sZUFBZSxxQkFBcUIsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUMxRSxjQUFJLGNBQWMsVUFBVSxRQUFXO0FBQ3RDLG9CQUFRLGFBQWE7VUFDdEI7UUFDRDtBQUVBLGNBQU0sVUFBVSxLQUFLLGFBQWEsZ0JBQWdCLElBQUksT0FBTyxXQUFXLEtBQUs7QUFHN0UsY0FBTSxZQUFZLGNBQWMsUUFBUSxXQUFXLEtBQUs7QUFFeEQsWUFBSSxhQUFhLFlBQVksUUFBVztBQUV2QyxpQkFBTyxpQkFBaUIsU0FBUyxPQUFPLE9BQU8sV0FBVyxPQUFPO1FBQ2xFO0FBR0EsZUFBTyxXQUFXO01BQ25COztFQUVGO0FBRUEsT0FBSyx1QkFBdUIsY0FBYztBQUczQzs7O0FDdEZBLE9BQU9HLFlBQVc7OztBQ0FsQixPQUFPLFdBQVc7QUFDbEIsT0FBTyxRQUFRO0FBSWYsSUFBTUMsVUFBUyxtQkFBbUIsT0FBTztBQUtsQyxJQUFNLHlCQUF5QjtBQUUvQixJQUFNLDBCQUEwQjtBQWdCaEMsSUFBTSxxQkFBcUIsTUFBTztBQWlCbkMsU0FBVSx3QkFBcUI7QUFDcEMsUUFBTSxNQUFNLE9BQU8sTUFBTSxJQUFJLENBQUM7QUFDOUIsUUFBTSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU0sSUFBSyxLQUFNO0FBRTdDLE1BQUksY0FBYyxPQUFRLENBQUM7QUFDM0IsTUFBSSxjQUFjLHdCQUF3QixDQUFDO0FBQzNDLE1BQUksY0FBYyxLQUFLLENBQUM7QUFFeEIsUUFBTSxNQUFNLGlCQUFnQjtBQUM1QixNQUFJLEtBQUssS0FBSyxDQUFDO0FBRWYsU0FBTyxLQUFLLFlBQVksT0FBTyxFQUFFLEtBQUssS0FBSyxFQUFFO0FBQzdDLE1BQUksY0FBYyxNQUFRLEVBQUU7QUFDNUIsTUFBSSxjQUFjLEtBQVEsRUFBRTtBQUM1QixNQUFJLGNBQWMsS0FBWSxFQUFFO0FBRWhDLFNBQU87QUFDUjtBQUdNLFNBQVUsbUJBQWdCO0FBQy9CLE1BQUk7QUFDSCxVQUFNLFNBQVMsR0FBRyxrQkFBaUI7QUFDbkMsZUFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMsaUJBQVcsUUFBUSxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdEMsWUFBSSxDQUFDLEtBQUssWUFBWSxLQUFLLFdBQVcsVUFBVSxLQUFLLE9BQU8sS0FBSyxRQUFRLHFCQUFxQjtBQUM3RixpQkFBTyxPQUFPLEtBQUssS0FBSyxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFjLFNBQVMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUMzRTtNQUNEO0lBQ0Q7RUFDRCxRQUFRO0VBRVI7QUFDQSxTQUFPLE9BQU8sTUFBTSxHQUFHLENBQUM7QUFDekI7QUFpQk0sU0FBVSx1QkFBdUIsS0FBYSxPQUFhO0FBQ2hFLE1BQUksSUFBSSxTQUFTO0FBQW9CLFdBQU87QUFDNUMsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVEsV0FBTztBQUMzQyxNQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBeUIsV0FBTztBQUM1RCxNQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZLFdBQU87QUFFbEUsUUFBTSxVQUFVLENBQUMsUUFBZ0IsUUFDaEMsSUFDRSxTQUFTLFFBQVEsU0FBUyxHQUFHLEVBQzdCLFNBQVMsT0FBTyxFQUNoQixNQUFNLElBQUksRUFBRSxDQUFDLEVBQ2IsS0FBSTtBQUVQLFFBQU0sUUFBUSxJQUFJLFNBQVMsR0FBRyxFQUFFO0FBQ2hDLFFBQU0sV0FBVyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQzVFLFFBQU0sTUFBTSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUV6RSxRQUFNLE9BQU8sUUFBUSxJQUFNLEVBQUU7QUFDN0IsUUFBTSxlQUFlLFFBQVEsSUFBTSxFQUFFO0FBQ3JDLFFBQU0sV0FBVyxRQUFRLEtBQU0sRUFBRTtBQUNqQyxRQUFNLGdCQUFnQixHQUFHLElBQUksRUFBSSxDQUFDLElBQUksSUFBSSxFQUFJLENBQUM7QUFFL0MsTUFBSSxDQUFDO0FBQVUsV0FBTztBQUl0QixRQUFNLFFBQVEsU0FDWixRQUFRLGNBQWMsRUFBRSxFQUN4QixLQUFJLEVBQ0osTUFBTSxLQUFLLEVBQUUsQ0FBQztBQUVoQixTQUFPO0lBQ04sSUFBSTtJQUNKO0lBQ0E7SUFDQTtJQUNBLFdBQVc7O0lBQ1g7SUFDQTs7QUFFRjtBQU9BLGVBQXNCLHFCQUFxQixRQUFjO0FBQ3hELFNBQU8sSUFBSSxRQUFrQixDQUFDLFNBQVMsV0FBVTtBQUNoRCxVQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFFckMsUUFBSSxLQUFLLFNBQVMsQ0FBQyxRQUFPO0FBQ3pCLFVBQUksTUFBSztBQUNULGFBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQzdDLENBQUM7QUFFRCxRQUFJLFFBQVEsR0FBRyxRQUFRLE1BQUs7QUFDM0IsVUFBSTtBQUNILGNBQU0sT0FBTyxJQUFJLFFBQU87QUFDeEIsY0FBTSxZQUFZLEtBQUs7QUFDdkIsWUFBSSxNQUFLO0FBRVQsY0FBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLG1CQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxxQkFBVyxTQUFTLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN2QyxnQkFDQyxNQUFNLFdBQVcsVUFDakIsTUFBTSxZQUFZLGFBQ2xCLE1BQU0sT0FDTixNQUFNLFFBQVEscUJBQ2I7QUFDRCxxQkFBTyxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxTQUFTLEdBQUcsRUFBRSxJQUFJLEdBQUksQ0FBQztZQUN2RTtVQUNEO1FBQ0Q7QUFDQSxlQUFPLElBQUksTUFBTSx3Q0FBd0MsU0FBUyxFQUFFLENBQUM7TUFDdEUsU0FBUyxJQUFJO0FBQ1osZUFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztNQUM3QjtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7QUFNQSxlQUFzQiw4QkFBOEIsUUFBYztBQUNqRSxTQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksV0FBVztBQUNmLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLENBQUMsVUFBVTtBQUNkLG1CQUFXO0FBQ1gsWUFBSSxNQUFLO0FBQ1QsZUFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDN0M7SUFDRCxDQUFDO0FBR0QsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxrQkFBUSxTQUFTO1FBQ2xCO01BQ0QsU0FBUyxJQUFJO0FBQ1osWUFBSSxDQUFDLFVBQVU7QUFDZCxxQkFBVztBQUNYLGNBQUksTUFBSztBQUNULGlCQUFPLElBQUksTUFBTSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQzdCO01BQ0Q7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBV0EsZUFBc0IsZ0JBQ3JCLFVBQ0Esa0JBQ0EsWUFBWSxLQUFJO0FBRWhCLFFBQU0sdUJBQXVCO0FBQzdCLFFBQU0sc0JBQXNCO0FBQzVCLFFBQU0sZUFBZTtBQUVyQixRQUFNLGFBQWEsb0JBQUksSUFBRztBQUUxQixTQUFPLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDcEMsVUFBTSxpQkFBaUIsTUFBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBRTNFLFVBQU0sVUFBVSxNQUFLO0FBQ3BCLFVBQUk7QUFDSCx1QkFBZSxlQUFlLG9CQUFvQjtNQUNuRCxRQUFRO01BRVI7QUFDQSxVQUFJO0FBQ0gsdUJBQWUsTUFBSztNQUNyQixRQUFRO01BRVI7QUFDQSxjQUFPO0lBQ1I7QUFFQSxVQUFNLFFBQVEsV0FBVyxTQUFTLFNBQVM7QUFDM0MsVUFBTSxRQUFPO0FBRWIsbUJBQWUsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNsQyxNQUFBQSxRQUFPLEtBQUssMEJBQTBCLElBQUksT0FBTyxFQUFFO0lBQ3BELENBQUM7QUFFRCxtQkFBZSxHQUFHLFdBQVcsQ0FBQyxLQUFLLFVBQVM7QUFDM0MsWUFBTSxRQUFRLE1BQU07QUFFcEIsVUFBSSxJQUFJLFNBQVM7QUFBSTtBQUNyQixVQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBUTtBQUNwQyxVQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBRTNELFVBQUksV0FBVyxJQUFJLEtBQUs7QUFBRztBQUMzQixpQkFBVyxJQUFJLEtBQUs7QUFDcEIsTUFBQUEsUUFBTyxNQUFNLGlCQUFpQixLQUFLLCtCQUEwQjtBQUs3RCxZQUFNLFlBQVksWUFBVztBQUM1QixjQUFNLGlCQUFpQixLQUFLO0FBQzVCLGNBQU0sUUFBUSxzQkFBcUI7QUFDbkMsaUJBQVMsS0FBSyxPQUFPLGNBQWMsT0FBTyxDQUFDLFFBQU87QUFDakQsY0FBSTtBQUFLLFlBQUFBLFFBQU8sS0FBSyxvQkFBb0IsS0FBSyxZQUFZLElBQUksT0FBTyxFQUFFO1FBQ3hFLENBQUM7TUFDRjtBQUNBLGdCQUFTLEVBQUcsTUFBTSxDQUFDLFFBQVFBLFFBQU8sS0FBSyx1QkFBdUIsR0FBRyxFQUFFLENBQUM7SUFDckUsQ0FBQztBQUVELG1CQUFlLEtBQUsscUJBQXFCLE1BQUs7QUFDN0MsVUFBSTtBQUNILHVCQUFlLGNBQWMsb0JBQW9CO0FBQ2pELFFBQUFBLFFBQU8sS0FBSyxvQ0FBb0Msb0JBQW9CLElBQUksbUJBQW1CLEVBQUU7TUFDOUYsU0FBUyxLQUFLO0FBQ2IsUUFBQUEsUUFBTyxLQUFLLDRDQUE0QyxHQUFHLEVBQUU7TUFDOUQ7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGOzs7QURuUUEsSUFBTUMsVUFBUyxtQkFBbUIsY0FBYztBQUUxQyxJQUFPLGVBQVAsTUFBTyxjQUFZO0VBQ1AsY0FBc0I7RUFDdEIsaUJBQWlCO0VBQ2pCLFNBQVM7RUFFbEI7RUFDQTs7RUFDQSxjQUdKLG9CQUFJLElBQUc7RUFDSCxtQkFBZ0Msb0JBQUksSUFBRzs7O0VBR3ZDLFlBQTJCLFFBQVEsUUFBTzs7RUFHMUMsc0JBQXNCOztFQUd0Qjs7RUFHQSxRQUFnQjtFQUNoQixVQUFzQixDQUFBO0VBQ3RCLHNCQUErQjs7Ozs7Ozs7RUFRL0IsY0FBZ0Qsb0JBQUksSUFBRzs7Ozs7OztFQVF2RCxnQkFBNkIsb0JBQUksSUFBRzs7RUFHcEMscUJBQWdFLG9CQUFJLElBQUc7O0VBR3ZFOztFQUdBLFdBQWtDLG9CQUFJLElBQUc7RUFFakQsY0FBQTtBQUNDLElBQUFBLFFBQU8sS0FBSywwQkFBMEI7QUFJdEMsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDcEUsU0FBSyxVQUFVLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDNUMsV0FBSyxTQUFTLEtBQUssR0FBRyxNQUFLO0FBQzFCLFFBQUFELFFBQU8sTUFBTSwyQkFBNEIsS0FBSyxTQUFTLFFBQU8sRUFBd0IsSUFBSSxFQUFFO0FBQzVGLGdCQUFPO01BQ1IsQ0FBQztJQUNGLENBQUM7QUFDRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBR0QsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFcEUsU0FBSyxTQUFTLEdBQUcsYUFBYSxNQUFLO0FBQ2xDLFlBQU0sT0FBTyxLQUFLLFNBQVMsUUFBTztBQUNsQyxNQUFBRCxRQUFPLE1BQU0sMEJBQTBCLEtBQUssVUFBVSxJQUFJLENBQUMsRUFBRTtBQUM3RCxVQUFJO0FBQ0gsYUFBSyxTQUFTLHFCQUFxQixJQUFJO01BQ3hDLFNBQVMsSUFBSTtNQUViO0lBQ0QsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzFDLFVBQUk7QUFDSCxhQUFLLGVBQWUsS0FBSyxNQUFNLE9BQU87TUFDdkMsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxFQUFFLEVBQUU7TUFDdEQ7SUFDRCxDQUFDO0FBR0QsU0FBSyxTQUFTLEtBQUssRUFBRSxTQUFTLFdBQVcsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2xFLE1BQUFBLFFBQU8sTUFBTSw4QkFBOEIsS0FBSyxNQUFNLEVBQUU7SUFDekQsQ0FBQztFQUNGO0VBRU8sUUFBSztBQUNYLFFBQUk7QUFDSCxpQkFBVyxhQUFhLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixHQUFHO0FBQzFELFlBQUk7QUFDSCxlQUFLLFNBQVMsZUFBZSxLQUFLLGdCQUFnQixTQUFTO1FBQzVELFFBQVE7UUFFUjtNQUNEO0lBQ0QsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7RUFDRDs7Ozs7RUFNTyxTQUFTLE9BQWUsU0FBcUIsc0JBQStCLE1BQUk7QUFDdEYsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVO0FBQ2YsU0FBSyxzQkFBc0I7RUFDNUI7Ozs7O0VBTU8sb0JBQW9CLFVBQXNDO0FBQ2hFLFNBQUssbUJBQW1CO0VBQ3pCOztFQUdPLG1CQUFtQixJQUFVO0FBQ25DLFdBQU8sS0FBSyxjQUFjLElBQUksRUFBRTtFQUNqQzs7RUFHTyxnQkFBZ0IsSUFBVTtBQUNoQyxTQUFLLGNBQWMsSUFBSSxFQUFFO0FBQ3pCLElBQUFBLFFBQU8sTUFBTSx3QkFBd0IsRUFBRSxFQUFFO0VBQzFDOztFQUdPLGFBQWEsSUFBVTtBQUM3QixTQUFLLGNBQWMsT0FBTyxFQUFFO0FBQzVCLFNBQUssWUFBWSxPQUFPLEVBQUU7QUFDMUIsU0FBSyxTQUFTLE9BQU8sRUFBRTtBQUN2QixJQUFBQSxRQUFPLE1BQU0scUJBQXFCLEVBQUUsRUFBRTtFQUN2Qzs7Ozs7OztFQVFPLE1BQU0sWUFBWSxJQUFZLFlBQVksS0FBSTtBQUNwRCxXQUFPLElBQUksUUFBMkIsQ0FBQyxZQUFXO0FBQ2pELFlBQU0sTUFBTSxXQUFXLEVBQUU7QUFDekIsVUFBSSxXQUFXO0FBRWYsWUFBTSxTQUFTLENBQUMsV0FBNkI7QUFDNUMsWUFBSTtBQUFVO0FBQ2QsbUJBQVc7QUFDWCxhQUFLLG1CQUFtQixPQUFPLEdBQUc7QUFDbEMsZ0JBQVEsTUFBTTtNQUNmO0FBRUEsV0FBSyxtQkFBbUIsSUFBSSxLQUFLLENBQUMsV0FBc0I7QUFDdkQsWUFBSSxPQUFPLE9BQU87QUFBSSxpQkFBTyxNQUFNO01BQ3BDLENBQUM7QUFFRCxZQUFNLFFBQVEsV0FBVyxNQUFNLE9BQU8sSUFBSSxHQUFHLFNBQVM7QUFDdEQsWUFBTSxRQUFPO0FBRWIsWUFBTSxNQUFNLFlBQVc7QUFDdEIsY0FBTSxLQUFLLG9CQUFvQixFQUFFO0FBQ2pDLGNBQU0sS0FBSztBQUNYLGNBQU0sUUFBUSxzQkFBcUI7QUFDbkMsYUFBSyxTQUFTLEtBQUssT0FBTyxLQUFLLGFBQWEsSUFBSSxDQUFDLFFBQU87QUFDdkQsY0FBSSxLQUFLO0FBQ1IsWUFBQUEsUUFBTyxLQUFLLFlBQVksRUFBRSxZQUFZLElBQUksT0FBTyxFQUFFO0FBQ25ELHlCQUFhLEtBQUs7QUFDbEIsbUJBQU8sSUFBSTtVQUNaO1FBQ0QsQ0FBQztNQUNGO0FBRUEsVUFBRyxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQ2pCLFFBQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsRUFBRTtBQUN0RCxxQkFBYSxLQUFLO0FBQ2xCLGVBQU8sSUFBSTtNQUNaLENBQUM7SUFDRixDQUFDO0VBQ0Y7Ozs7O0VBTU8sTUFBTSxtQkFBbUIsVUFBZ0I7QUFDL0MsSUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxRQUFRLEVBQUU7QUFDdEQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLHNCQUFzQixRQUFXLFFBQVcsUUFBVyxVQUFVLEtBQUs7QUFFL0csV0FBTztFQUNSOzs7Ozs7Ozs7OztFQVlPLE1BQU0sZ0JBQWdCLFlBQVksS0FBSTtBQUU1QyxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLGVBQTZCLENBQUE7QUFFbkMsVUFBTSxnQkFBZ0IsQ0FBQyxXQUFzQjtBQUM1QyxVQUFJLENBQUMsYUFBYSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxFQUFFLEdBQUc7QUFDbEQscUJBQWEsS0FBSyxNQUFNO01BQ3pCO0lBQ0Q7QUFHQSxTQUFLLG1CQUFtQixJQUFJLGVBQWUsYUFBYTtBQUV4RCxRQUFJO0FBQ0gsWUFBTSxLQUFLO0FBR1gsWUFBTSxnQkFBZ0IsS0FBSyxVQUFVLE9BQU8sV0FBVyxLQUFLLG9CQUFvQixNQUFNLEdBQUcsU0FBUztBQUNsRyxhQUFPO0lBQ1I7QUFDQyxXQUFLLG1CQUFtQixPQUFPLGFBQWE7SUFDN0M7RUFDRDs7Ozs7RUFNTyxNQUFNLHVCQUF1QixVQUFnQjtBQUNuRCxJQUFBQSxRQUFPLEtBQUssb0NBQW9DLFFBQVEsRUFBRTtBQUMxRCxVQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsa0JBQWtCLFFBQVcsUUFBVyxRQUFXLFVBQVUsS0FBSztBQUkzRyxVQUFNLFlBQVk7QUFFbEIsUUFBSSxTQUFTLFNBQVMsWUFBWSxHQUFHO0FBQ3BDLE1BQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsU0FBUyxNQUFNLFFBQVE7QUFDbkUsYUFBTztJQUNSO0FBR0EsVUFBTSxRQUFRLFNBQVMsWUFBWSxDQUFDO0FBQ3BDLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUVwQyxVQUFNLFdBQ0wsUUFBUSxLQUNMLE1BQU0sU0FBUSxFQUFHLFNBQVMsR0FBRyxHQUFHLElBQ2hDLE1BQU0sU0FBUTtBQUVsQixVQUFNLFdBQVcsR0FBRyxLQUFLLElBQUksUUFBUTtBQUVyQyxJQUFBQSxRQUFPLEtBQUsscUJBQXFCLFFBQVEsRUFBRTtBQUMzQyxXQUFPO0VBQ1I7Ozs7O0VBTVEsTUFBTSxvQkFBb0IsUUFBYztBQUMvQyxRQUFJO0FBQ0gsWUFBTSxZQUFZLE1BQU0sOEJBQThCLE1BQU07QUFDNUQsVUFBSSxDQUFDLFdBQVc7QUFDZixRQUFBQSxRQUFPLEtBQUsscURBQXFELE1BQU0sRUFBRTtBQUN6RTtNQUNEO0FBRUEsVUFBSSxLQUFLLGlCQUFpQixJQUFJLFNBQVMsR0FBRztBQUV6QztNQUNEO0FBRUEsVUFBSTtBQUNILGFBQUssU0FBUyxjQUFjLEtBQUssZ0JBQWdCLFNBQVM7QUFDMUQsYUFBSyxpQkFBaUIsSUFBSSxTQUFTO0FBQ25DLFFBQUFBLFFBQU8sS0FBSyxvQkFBb0IsS0FBSyxjQUFjLE9BQU8sU0FBUyxFQUFFO01BQ3RFLFNBQVMsSUFBSTtBQUNaLFFBQUFBLFFBQU8sS0FBSywrQkFBK0IsU0FBUyxLQUFLLE9BQU8sRUFBRSxDQUFDLEVBQUU7TUFDdEU7SUFDRCxTQUFTLElBQUk7QUFDWixNQUFBQSxRQUFPLEtBQUssK0JBQStCLEVBQUUsRUFBRTtJQUNoRDtFQUNEO0VBRU8sTUFBTSxhQUNaLE9BQ0EsT0FDQSxXQUNBLE9BQ0EsUUFDQSxTQUFTLE1BQUk7QUFFYixTQUFLO0FBQ0wsV0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFdBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxZQUNwQyxLQUFLLGNBQWMsT0FBTyxPQUFPLFdBQVcsT0FBTyxRQUFRLE1BQU0sRUFDL0QsS0FBSyxDQUFDLFFBQU87QUFDYixhQUFLO0FBR0wsWUFBSSxLQUFLLHdCQUF3QixLQUFLLEtBQUssdUJBQXVCLFVBQVUsUUFBVztBQUN0RixlQUFLLG1CQUFtQixNQUFNLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDN0MsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGO0FBQ0EsZ0JBQVEsR0FBRztNQUNaLENBQUMsRUFDQSxNQUFNLENBQUMsUUFBTztBQUNkLGFBQUs7QUFDTCxlQUFPLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzNELENBQUMsQ0FBQztJQUVMLENBQUM7RUFDRjtFQUVRLE1BQU0sY0FDYixPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUFJO0FBRWIsVUFBTSxZQUFZO0FBRWxCLFVBQU0sWUFBc0IsQ0FBQTtBQUM1QixRQUFJLGNBQWM7QUFBVyxnQkFBVSxLQUFLLFlBQVksR0FBSTtBQUM1RCxRQUFJLFVBQVU7QUFBVyxnQkFBVSxLQUFLLEdBQUcsY0FBYSxnQkFBZ0IsS0FBSyxDQUFDO0FBRTlFLFVBQU0sY0FBd0IsQ0FBQyxJQUFNLFFBQVEsR0FBSTtBQUVqRCxRQUFJLFVBQVUsZUFBZSxVQUFVLFVBQWEsY0FBYyxVQUFhLFVBQVUsUUFBVztBQUluRyxVQUFJLENBQUMsS0FBSyxZQUFZLElBQUksTUFBTTtBQUFHLGFBQUssWUFBWSxJQUFJLFFBQVEsb0JBQUksSUFBRyxDQUFFO0FBQ3pFLFlBQU0sVUFBVSxLQUFLLFlBQVksSUFBSSxNQUFNO0FBQzNDLFlBQU0sZUFBZTtBQUNyQixZQUFNLFlBQXNCLENBQUE7QUFDNUIsZUFBUyxJQUFJLEdBQUcsSUFBSSxjQUFjLEtBQUs7QUFDdEMsY0FBTSxXQUFXLGNBQWMsS0FBSyxPQUFPLGFBQWEsR0FBRyxLQUFLO0FBQ2hFLGNBQU0sTUFBTSxNQUFNLFlBQVksT0FBTyxLQUFLLElBQUssUUFBUSxJQUFJLFFBQVEsS0FBSztBQUN4RSxrQkFBVSxLQUFLLEdBQUc7QUFDbEIsZ0JBQVEsSUFBSSxVQUFVLEdBQUc7TUFDMUI7QUFDQSxrQkFBWSxLQUFLLFFBQVEsS0FBTSxHQUFHLFNBQVM7SUFDNUMsT0FBTztBQUNOLFVBQUksVUFBVTtBQUFXLG9CQUFZLEtBQUssUUFBUSxHQUFJO0FBQ3RELFVBQUk7QUFBUSxvQkFBWSxLQUFLLFVBQVUsTUFBTTtBQUM3QyxVQUFJLFVBQVUsU0FBUztBQUFHLG9CQUFZLEtBQUssR0FBRyxTQUFTO0lBQ3hEO0FBRUEsVUFBTSxNQUFNLGNBQWEsVUFBVSxXQUFXO0FBQzlDLFVBQU0saUJBQWlCLE9BQU8sS0FBSyxDQUFDLEdBQUcsYUFBYSxHQUFHLENBQUM7QUFHeEQsUUFBSSxjQUFjLFVBQWEsVUFBVSxRQUFXO0FBQ25ELFlBQU0sYUFBYSxjQUFhLGdCQUFnQixLQUFLO0FBQ3JELFlBQU0sVUFBeUI7UUFDOUIsUUFBUTtRQUNSLElBQUk7UUFDSjtRQUNBOztBQUVELE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxvQkFBb0IsU0FBUyxLQUFLLE9BQU8sQ0FBQyxFQUFFO0lBQzNFLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sZUFBZSxLQUFLLENBQUMsRUFBRTtJQUN0RDtBQUlBLFFBQUksQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEdBQUc7QUFDcEMsTUFBQUEsUUFBTyxNQUFNLHFEQUFnRCxNQUFNLEtBQUssZUFBZSxTQUFTLEtBQUssQ0FBQyxFQUFFO0FBQ3hHLFlBQU0sSUFBSSxNQUFNLGFBQWEsTUFBTSxpRkFBNEU7SUFDaEg7QUFHQSxVQUFNLEtBQUssb0JBQW9CLE1BQU07QUFFckMsVUFBTSxXQUFXLEtBQUssZUFBZTtBQUNyQyxVQUFNLFNBQVMsTUFBTSxLQUFLLFlBQVksVUFBVSxNQUFNO0FBQ3RELFVBQU0sU0FBUyxPQUFPLE9BQU8sQ0FBQyxRQUFRLGNBQWMsQ0FBQztBQUVyRCxJQUFBQSxRQUFPLE1BQU0scUJBQXFCLE1BQU0sS0FBSyxPQUFPLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFFckUsVUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLEtBQUs7QUFFOUIsV0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFlBQU0sUUFBUSxXQUFXLE1BQUs7QUFDN0IsYUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQixlQUFPLElBQUksTUFBTSxzQ0FBc0MsS0FBSyxLQUFLLE9BQU8sTUFBTSxPQUFPLENBQUM7TUFDdkYsR0FBRyxTQUFTO0FBRVosV0FBSyxZQUFZLElBQUksS0FBSztRQUN6QixTQUFTLENBQUMsUUFBTztBQUNoQix1QkFBYSxLQUFLO0FBQ2xCLGtCQUFRLEdBQUc7UUFDWjtRQUNBLFFBQVEsQ0FBQyxRQUFPO0FBQ2YsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxHQUFHO1FBQ1g7UUFDQTtPQUNBO0FBRUQsV0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLGFBQWEsUUFBUSxDQUFDLFFBQU87QUFDNUQsWUFBSSxLQUFLO0FBQ1IsZUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUM3QztNQUNELENBQUM7SUFDRixDQUFDO0VBQ0Y7RUFFUSxlQUFlLEtBQWEsT0FBYTtBQUNoRCxRQUFJLElBQUksU0FBUztBQUFHO0FBQ3BCLFFBQUksSUFBSSxDQUFDLE1BQU0sT0FBUSxJQUFJLENBQUMsTUFBTTtBQUFNO0FBRXhDLFVBQU0sVUFBVSxJQUFJLGFBQWEsQ0FBQztBQUtsQyxRQUFJLFlBQVksMkJBQTJCLEtBQUssbUJBQW1CLE9BQU8sR0FBRztBQUM1RSxZQUFNLFNBQVMsdUJBQXVCLEtBQUssS0FBSztBQUNoRCxVQUFJLFFBQVE7QUFDWCxRQUFBQSxRQUFPLE1BQ04sNEJBQTRCLEtBQUssZUFDbkIsT0FBTyxJQUFJLGFBQ2QsT0FBTyxLQUFLLGlCQUNSLE9BQU8sU0FBUyxvQkFDYixPQUFPLFlBQVksR0FBRztBQUl6QyxZQUFJLE9BQU8sU0FBUyxZQUFZO0FBQy9CLHFCQUFXLE1BQU0sS0FBSyxtQkFBbUIsT0FBTSxHQUFJO0FBQ2xELGdCQUFJO0FBQ0gsaUJBQUcsTUFBTTtZQUNWLFFBQVE7WUFFUjtVQUNEO1FBQ0QsT0FBTztBQUNOLFVBQUFBLFFBQU8sTUFBTSxzREFBc0QsT0FBTyxJQUFJLE9BQU8sS0FBSyxFQUFFO1FBQzdGO01BQ0Q7QUFDQTtJQUNEO0FBRUEsUUFBSSxJQUFJLFNBQVM7QUFBSTtBQUdyQixVQUFNLE1BQU0sSUFBSSxTQUFTLElBQUksRUFBRTtBQUMvQixRQUFJLElBQUksU0FBUyxPQUFPLE1BQU07QUFBWTtBQUkxQyxVQUFNLFlBQVksSUFBSSxTQUFTLEVBQUU7QUFDakMsUUFBSSxVQUFVLFNBQVM7QUFBRztBQUMxQixRQUFJLFVBQVUsQ0FBQyxNQUFNO0FBQU07QUFHM0IsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLGNBQWMsWUFBWSxTQUFVO0FBQzFDLFVBQU0sZ0JBQWdCLFlBQVk7QUFHbEMsUUFBSSxjQUFjLGtCQUFrQixzQkFBc0I7QUFDekQsTUFBQUEsUUFBTyxNQUFNLHdCQUF3QixLQUFLLEtBQUssSUFBSSxTQUFTLEtBQUssQ0FBQyxFQUFFO0lBQ3JFO0FBR0EsU0FBSyxhQUFhLE9BQU8sZUFBZSxLQUFLLFNBQVM7QUFHdEQsUUFBSSxZQUFZO0FBQ2YsWUFBTSxNQUFNLEdBQUcsS0FBSyxJQUFJLGFBQWE7QUFDckMsWUFBTSxVQUFVLEtBQUssWUFBWSxJQUFJLEdBQUc7QUFDeEMsVUFBSSxTQUFTO0FBQ1osYUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQixnQkFBUSxRQUFRLEdBQUc7TUFDcEI7SUFDRDtFQUVEOzs7Ozs7Ozs7Ozs7RUFhUSxhQUFhLE9BQWUsT0FBZSxLQUFhLFdBQWlCO0FBQ2hGLFVBQU0sVUFBVSxlQUFlLEtBQUs7QUFDcEMsVUFBTSxPQUFPLFVBQVUsU0FBUyxHQUFHLFVBQVUsU0FBUyxDQUFDO0FBR3ZELFVBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsVUFBTSxNQUFNLFVBQVUsVUFBVSxTQUFTLENBQUM7QUFDMUMsVUFBTSxnQkFBZ0IsUUFBUSxNQUFNLFNBQVMsQ0FBQyxTQUFTLEtBQUssU0FBUyxLQUFLLENBQUMsUUFBUSxNQUFNLEdBQUcsQ0FBQztBQUs3RixRQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQUksQ0FBQyxLQUFLLE9BQU87QUFDaEIsUUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7QUFDekQ7TUFDRDtBQUNBLFVBQUk7QUFDSCxjQUFNLFdBQ0wsVUFBVSxvQkFDUCxzQkFBc0IsS0FBSyxPQUFPLEdBQUcsSUFDckMsNEJBQTRCLEtBQUssT0FBTyxHQUFHO0FBRS9DLGNBQU0sWUFBWSxLQUFLLFlBQVksSUFBSSxLQUFLLEtBQUssb0JBQUksSUFBRztBQUN4RCxjQUFNLFdBQVcsSUFBSSxJQUFvQixTQUFTO0FBRWxELG1CQUFXLEtBQUssVUFBVTtBQUN6QixnQkFBTSxXQUFXLGNBQWMsS0FBSyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLO0FBRWxFLGdCQUFNLFdBQ0wsRUFBRSxXQUFXLFdBQVcsSUFDcEIsRUFBRSxXQUFXLENBQUMsS0FBSyxLQUFPLEVBQUUsV0FBVyxDQUFDLEtBQUssSUFBSyxFQUFFLFdBQVcsQ0FBQyxJQUNoRSxFQUFFLFdBQVcsQ0FBQyxLQUFLO0FBQ3hCLGdCQUFNLFlBQVksVUFBVSxJQUFJLFFBQVE7QUFDeEMsZ0JBQU0sVUFBVSxjQUFjLFVBQWEsY0FBYztBQUV6RCxtQkFBUyxJQUFJLFVBQVUsUUFBUTtBQUUvQixnQkFBTSxZQUFZLG9CQUFvQixHQUFHLEtBQUssT0FBTztBQUNyRCxjQUFJLFNBQVM7QUFDWixZQUFBQSxRQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUyxFQUFFO0FBRXhDLGdCQUFJLEtBQUssa0JBQWtCO0FBQzFCLG9CQUFNLGtCQUFrQixjQUFjLEtBQUssT0FBTyxFQUFFLFFBQVEsRUFBRSxFQUFFO0FBRWhFLG1CQUFLLGlCQUFpQixlQUFlO1lBQ3RDLE9BQU87QUFDTixjQUFBQSxRQUFPLEtBQUssZ0VBQTJELFFBQVEsRUFBRTtZQUNsRjtVQUNELE9BQU87QUFDTixZQUFBQSxRQUFPLE1BQU0sTUFBTSxLQUFLLE1BQU0sU0FBUyxFQUFFO1VBQzFDO1FBQ0Q7QUFDQSxhQUFLLFlBQVksSUFBSSxPQUFPLFFBQVE7TUFDckMsU0FBUyxHQUFHO0FBQ1gsUUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLE9BQU8sb0JBQW9CLENBQUMsTUFBTSxhQUFhLEVBQUU7TUFDL0U7QUFDQTtJQUNEO0FBR0EsVUFBTSxVQUFVLEtBQUssYUFBYSxPQUFPLElBQUk7QUFFN0MsVUFBTSxRQUFRLFVBQVUsY0FBY0EsUUFBTyxNQUFNLEtBQUtBLE9BQU0sSUFBSUEsUUFBTyxLQUFLLEtBQUtBLE9BQU07QUFDekYsUUFBSSxTQUFTO0FBQ1osWUFBTSxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxNQUFNLE9BQU8sRUFBRTtJQUNqRSxPQUFPO0FBQ04sWUFBTSxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxFQUFFO0lBQ3BEO0VBQ0Q7Ozs7O0VBTVEsYUFBYSxPQUFlLE1BQVk7QUFDL0MsUUFBSSxLQUFLLFdBQVc7QUFBRyxhQUFPO0FBRzlCLFFBQUksS0FBSyxXQUFXLEdBQUc7QUFDdEIsVUFBSSxLQUFLLENBQUMsTUFBTSxHQUFNO0FBQ3JCLGVBQU87TUFDUixPQUFPO0FBQ04sZUFBTyxTQUFTLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQztNQUMvQjtJQUNEO0FBRUEsWUFBUSxPQUFPOzs7TUFHZCxLQUFLLGFBQWE7QUFDakIsY0FBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixjQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsRUFDdEMsSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFDakUsS0FBSyxHQUFHO0FBQ1YsZUFBTyxNQUFNLEtBQUssSUFBSSxJQUFJO01BQzNCOzs7OztNQU1BLEtBQUssY0FBYztBQUNsQixZQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLGlCQUFPLEtBQUssQ0FBQyxNQUFNLElBQU8sV0FBVyxXQUFXLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQztRQUMvRDtBQUNBLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDckIsZ0JBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsZ0JBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsZ0JBQU0sYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNsQyxnQkFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUNoRixnQkFBTSxjQUFjLFFBQVEsUUFBUSxXQUFXLE1BQU0sU0FBUyxDQUFDO0FBQy9ELGdCQUFNLFVBQVUsUUFBUSxVQUFVLENBQUMsR0FBRztBQUN0QyxnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLGNBQ0wsV0FBVyxhQUFhLFNBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7QUFDckYsZ0JBQU0sV0FBVyxjQUFjLEdBQUcsV0FBVyxLQUFLLE1BQU0sUUFBUyxDQUFDLE1BQU0sV0FBVyxNQUFNLEtBQUssVUFBVSxDQUFDO0FBQ3pHLGdCQUFNLFNBQVMsSUFBSSxNQUFNLEtBQUssQ0FBQyxJQUFJLE1BQU0sU0FBUyxDQUFDLEtBQUssV0FBVyxNQUFNLEtBQUssVUFBVSxDQUFDLENBQUM7QUFDMUYsaUJBQU8sV0FBVyxLQUFLLE1BQU0sV0FBVyxLQUFLLFFBQVEsSUFBSSxNQUFNO1FBQ2hFO0FBQ0EsZUFBTyxRQUFRLEtBQUssU0FBUyxLQUFLLENBQUM7TUFDcEM7O01BR0EsS0FBSyxpQkFBaUI7QUFFckIsWUFBSSxLQUFLLFVBQVUsR0FBRztBQUNyQixnQkFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixnQkFBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixnQkFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO0FBQ2xDLGdCQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBQ2hGLGdCQUFNLGNBQWMsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLENBQUM7QUFDL0QsZ0JBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxnQkFBTSxVQUFVLFFBQVEsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxHQUFHO0FBQ2hFLGdCQUFNLGNBQ0wsV0FBVyxhQUFhLFNBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7QUFDckYsZ0JBQU0sV0FBVyxlQUFlLEtBQUssV0FBVyxTQUFTLEtBQUssQ0FBQztBQUMvRCxpQkFBTyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUTtRQUN0RDtBQUNBLGVBQU87TUFDUjs7TUFHQSxLQUFLO01BQ0wsS0FBSyxhQUFhO0FBQ2pCLFlBQUksS0FBSyxTQUFTO0FBQUcsaUJBQU87QUFDNUIsY0FBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixjQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGNBQU0sUUFBUSxLQUFLLFNBQVMsQ0FBQztBQUM3QixlQUFPLE1BQU0sS0FBSyxZQUFZLE1BQU0sU0FBUyxDQUFDLFVBQVUsTUFBTSxTQUFTLEtBQUssQ0FBQztNQUM5RTtNQUVBO0FBQ0MsZUFBTztJQUNUO0VBQ0Q7RUFFUSxPQUFPLGdCQUFnQixPQUFjO0FBQzVDLFFBQUksT0FBTyxVQUFVO0FBQVcsYUFBTyxDQUFDLFFBQVEsSUFBSSxDQUFDO0FBQ3JELFFBQUksTUFBTSxRQUFRLEtBQUs7QUFBRyxhQUFPLE1BQU0sSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDLElBQUksR0FBSTtBQUNsRSxRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzlCLFVBQUksUUFBUTtBQUFNLGVBQU8sQ0FBRSxTQUFTLEtBQU0sS0FBTyxTQUFTLElBQUssS0FBTSxRQUFRLEdBQUk7QUFDakYsYUFBTyxDQUFDLFFBQVEsR0FBSTtJQUNyQjtBQUNBLFVBQU0sSUFBSSxNQUFNLDRDQUE0QyxLQUFLLEVBQUU7RUFDcEU7RUFFUSxNQUFNLFlBQVksVUFBa0IsUUFBYztBQUN6RCxRQUFJLE1BQU0sS0FBSyxTQUFTLElBQUksTUFBTTtBQUNsQyxRQUFJLENBQUMsS0FBSztBQUNULFlBQU0sTUFBTSxxQkFBcUIsTUFBTTtBQUN2QyxXQUFLLFNBQVMsSUFBSSxRQUFRLEdBQUc7SUFDOUI7QUFFQSxXQUFPLE9BQU8sT0FBTztNQUNwQixPQUFPLEtBQUssQ0FBQyxLQUFNLEtBQU0sR0FBTSxXQUFXLEtBQU0sR0FBTSxLQUFNLEdBQU0sR0FBTSxHQUFHLEtBQUssR0FBTSxDQUFJLENBQUM7TUFDM0YsT0FBTyxLQUFLLFlBQVksTUFBTTtLQUM5QjtFQUNGO0VBRVEsT0FBTyxVQUFVLE1BQWM7QUFDdEMsUUFBSSxNQUFNO0FBQ1YsZUFBVyxLQUFLLE1BQU07QUFDckIsYUFBTztBQUNQLGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0FBQzNCLGVBQU8sTUFBTSxTQUFVLEtBQU0sT0FBTyxJQUFLLE9BQVEsTUFBUSxPQUFPLElBQUs7TUFDdEU7SUFDRDtBQUNBLFdBQU87RUFDUjs7Ozs7Ozs7OztFQVdPLGdCQUFnQixJQUFZLE9BQWUsV0FBbUIsT0FBYztBQUNsRixVQUFNLE1BQU0sY0FBYyxLQUFLLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDN0QsV0FBTyxLQUFLLFlBQVksSUFBSSxFQUFFLEdBQUcsSUFBSSxHQUFHO0VBQ3pDO0VBRU8sTUFBTSxZQUFZLFFBQWM7QUFDdEMsV0FBTyxLQUFLLGFBQWEsa0JBQWtCLFFBQVcsR0FBTSxRQUFXLFFBQVEsS0FBSztFQUNyRjtFQUVPLE1BQU0sY0FBYyxRQUFjO0FBQ3hDLFdBQU8sS0FBSyxhQUFhLHFCQUFxQixRQUFXLFFBQVcsUUFBVyxRQUFRLEtBQUs7RUFDN0Y7Ozs7QUV6dkJELElBQU1FLFVBQVMsbUJBQW1CLGdCQUFnQjtBQU1sRCxJQUFxQixpQkFBckIsY0FBNEMsYUFBeUI7RUFDcEU7O0VBQ0E7OztFQUlRLG9CQUFrQyxDQUFBOzs7RUFJMUMsY0FBc0I7RUFFdEIsWUFBWSxVQUFpQjtBQUM1QixVQUFNLFFBQVE7RUFDZjtFQUVBLE1BQU0sS0FBSyxRQUFvQjtBQUM5QixTQUFLLFNBQVM7QUFDZCxRQUFJLENBQUMsS0FBSyxjQUFjO0FBQ3ZCLFdBQUssZUFBZSxJQUFJLGFBQVk7SUFDckM7QUFDQSxTQUFLLGFBQWEsZUFBZSxZQUFZLHdCQUF3QjtBQUdyRSxTQUFLLGFBQWEsb0JBQW9CLENBQUMsZUFBc0I7QUFDNUQsV0FBSyxlQUFlLFVBQVU7SUFDL0IsQ0FBQztBQUlELFNBQUssYUFBWSxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQy9CLE1BQUFBLFFBQU8sTUFBTSxxQkFBcUIsQ0FBQyxFQUFFO0lBQ3RDLENBQUM7RUFDRjs7Ozs7OztFQVFRLE1BQU0sZUFBWTtBQUN6QixJQUFBQSxRQUFPLEtBQUssOEJBQThCO0FBRTFDLFNBQUssb0JBQW9CLE1BQU0sS0FBSyxhQUFhLGdCQUFlO0FBR2hFLFFBQUk7QUFDSixRQUFJLEtBQUssa0JBQWtCLFdBQVcsR0FBRztBQUV4QyxVQUFJLEtBQUssT0FBTyxXQUFXO0FBQzFCLGNBQU0sYUFBYSxLQUFLLE9BQU8sY0FBYyxTQUFTLEtBQUssT0FBTyxXQUFXLE1BQU07QUFDbkYsUUFBQUEsUUFBTyxLQUFLLHFCQUFxQixLQUFLLE9BQU8sU0FBUyw4Q0FBeUM7QUFDL0YsYUFBSyxhQUFhLGVBQWUsbUJBQW1CLEdBQUcsVUFBVSxJQUFJLEtBQUssT0FBTyxTQUFTLGFBQWE7QUFDdkc7TUFDRDtBQUNBLFlBQU0sY0FBYyxLQUFLLE9BQU87QUFDaEMsVUFBSSxDQUFDLEtBQUssT0FBTyxRQUFRLENBQUMsYUFBYTtBQUN0QyxRQUFBQSxRQUFPLEtBQUsseURBQXlEO0FBQ3JFO01BQ0Q7QUFDQSxNQUFBQSxRQUFPLEtBQUssd0VBQW1FO0FBQy9FLHVCQUFpQjtJQUNsQixPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGNBQWMsS0FBSyxrQkFBa0IsTUFBTSxhQUFhO0FBQ3BFLGlCQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdkMsUUFBQUEsUUFBTyxLQUFLLGFBQWEsRUFBRSxLQUFLLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFO01BQ3JFO0FBS0EsaUJBQVcsVUFBVSxLQUFLLG1CQUFtQjtBQUM1QyxhQUFLLGFBQWEsZ0JBQWdCLE9BQU8sRUFBRTtNQUM1QztBQUdBLGlCQUFXLFVBQVUsS0FBSyxtQkFBbUI7QUFDNUMsWUFBSTtBQUNILGdCQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsdUJBQXVCLE9BQU8sRUFBRTtBQUN6RSxpQkFBTyxlQUFlO0FBQ3RCLFVBQUFBLFFBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSxjQUFjLFFBQVEsV0FBVyxPQUFPLGFBQWEsRUFBRTtRQUNwRixTQUFTLEdBQUc7QUFDWCxVQUFBQSxRQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsNkJBQTZCLENBQUMsRUFBRTtBQUM1RCxpQkFBTyxlQUFlO1FBQ3ZCO01BQ0Q7QUFFQSx1QkFBaUIsYUFBYSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7QUFHakUsVUFBSSxDQUFDLGtCQUFrQixLQUFLLE9BQU8sV0FBVztBQUM3QyxjQUFNLGFBQWEsS0FBSyxPQUFPLGNBQWMsU0FBUyxLQUFLLE9BQU8sV0FBVyxNQUFNO0FBQ25GLFFBQUFBLFFBQU8sS0FBSyxxQkFBcUIsS0FBSyxPQUFPLFNBQVMsc0RBQWlEO0FBQ3ZHLGFBQUssYUFBYSxlQUFlLG1CQUFtQixHQUFHLFVBQVUsSUFBSSxLQUFLLE9BQU8sU0FBUyxhQUFhO0FBQ3ZHO01BQ0Q7SUFDRDtBQUdBLFNBQUssVUFBVSxjQUFjO0FBSTdCLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFVBQU0sS0FBSyxvQkFBb0IsSUFBSSxVQUFVO0FBRzdDLFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0FBRXpCLFNBQUssYUFBYSxlQUFlLEVBQUU7QUFDbkMsSUFBQUEsUUFBTyxLQUFLLDJCQUEyQjtFQUN4Qzs7RUFHQSxNQUFNLFVBQU87QUFDWixTQUFLLGNBQWMsTUFBSztBQUN4QixJQUFBQSxRQUFPLE1BQU0sU0FBUztFQUN2QjtFQUVBLE1BQU0sY0FBYyxRQUFvQjtBQUN2QyxVQUFNLGVBQWUsS0FBSztBQUMxQixTQUFLLFNBQVM7QUFDZCxVQUFNLGlCQUFpQixhQUFhLFFBQVEsS0FBSyxpQkFBaUI7QUFDbEUsU0FBSyxVQUFVLGNBQWM7QUFJN0IsU0FBSyxxQkFBb0I7QUFFekIsVUFBTSxVQUFVLEtBQUs7QUFJckIsVUFBTSxLQUFLLG9CQUFvQixjQUFjLE9BQU87QUFHcEQsU0FBSyxjQUFhO0FBQ2xCLFNBQUssZ0JBQWU7QUFDcEIsU0FBSywwQkFBeUI7QUFDOUIsU0FBSyxxQkFBb0I7RUFDMUI7Ozs7Ozs7Ozs7OztFQWFRLE1BQU0sb0JBQW9CLGNBQXNCLFNBQWU7QUFDdEUsUUFBSSxDQUFDLFNBQVM7QUFDYixVQUFJO0FBQWMsYUFBSyxhQUFhLGFBQWEsWUFBWTtBQUM3RDtJQUNEO0FBRUEsUUFBSSxLQUFLLE9BQU8sV0FBVztBQUUxQixZQUFNLFNBQVMsS0FBSyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLEtBQUssT0FBTyxTQUFTO0FBQ2pGLFVBQUksQ0FBQyxRQUFRO0FBQ1osUUFBQUEsUUFBTyxLQUFLLGVBQWUsS0FBSyxPQUFPLFNBQVMseURBQW9EO0FBQ3BHLFlBQUk7QUFBYyxlQUFLLGFBQWEsYUFBYSxZQUFZO0FBQzdEO01BQ0Q7QUFFQSxVQUFJLGdCQUFnQixpQkFBaUIsU0FBUztBQUM3QyxhQUFLLGFBQWEsYUFBYSxZQUFZO01BQzVDO0FBQ0EsWUFBTSxnQkFBZ0IsS0FBSyxhQUFhLG1CQUFtQixPQUFPO0FBQ2xFLFVBQUksQ0FBQyxlQUFlO0FBQ25CLGFBQUssYUFBYSxnQkFBZ0IsT0FBTztNQUMxQztBQUNBLFVBQUksWUFBWSxnQkFBZ0IsQ0FBQyxlQUFlO0FBQy9DLGNBQU0sS0FBSyw2QkFBNkIsT0FBTyxPQUFPLE9BQU87TUFDOUQ7QUFDQTtJQUNEO0FBR0EsVUFBTSxjQUFjLE9BQU8sS0FBSyxPQUFPLGVBQWUsRUFBRTtBQUN4RCxVQUFNLGlCQUFpQixLQUFLLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUUxRSxRQUFJLGdCQUFnQjtBQUNuQixVQUFJLGVBQWUsVUFBVSxhQUFhO0FBQ3pDLFlBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLGVBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsY0FBTSxnQkFBZ0IsS0FBSyxhQUFhLG1CQUFtQixPQUFPO0FBQ2xFLFlBQUksQ0FBQyxlQUFlO0FBQ25CLGVBQUssYUFBYSxnQkFBZ0IsT0FBTztRQUMxQztBQUNBLFlBQUksWUFBWSxnQkFBZ0IsQ0FBQyxlQUFlO0FBQy9DLGdCQUFNLEtBQUssNkJBQTZCLGFBQWEsT0FBTztRQUM3RDtNQUNELE9BQU87QUFDTixRQUFBQSxRQUFPLE1BQ04sMEJBQTBCLFdBQVcsMkNBQTJDLGVBQWUsS0FBSyxRQUFRLE9BQU8sMEJBQXFCO0FBRXpJLGFBQUssYUFBYSxhQUFhLE9BQU87QUFDdEMsYUFBSyxhQUNKLGVBQWUsbUJBQ2YsNEJBQTRCLFdBQVcsU0FBUyxlQUFlLEtBQUssRUFBRTtNQUV4RTtBQUNBO0lBQ0Q7QUFHQSxJQUFBQSxRQUFPLEtBQUssR0FBRyxPQUFPLHdDQUFtQztBQUN6RCxRQUFJLGdCQUFnQixpQkFBaUI7QUFBUyxXQUFLLGFBQWEsYUFBYSxZQUFZO0FBQ3pGLFNBQUssYUFBYSxhQUFhLE9BQU87QUFFdEMsVUFBTSxTQUFTLE1BQU0sS0FBSyxhQUFhLFlBQVksT0FBTztBQUMxRCxRQUFJLENBQUMsUUFBUTtBQUNaLE1BQUFBLFFBQU8sTUFBTSwwQkFBMEIsT0FBTywwQkFBcUI7QUFDbkUsV0FBSyxhQUFhLGVBQWUsZ0JBQWdCLG1CQUFtQixPQUFPLEVBQUU7SUFDOUUsV0FBVyxPQUFPLFVBQVUsYUFBYTtBQUN4QyxNQUFBQSxRQUFPLE1BQ04sMEJBQTBCLFdBQVcsMkNBQTJDLE9BQU8sS0FBSyxRQUFRLE9BQU8sMEJBQXFCO0FBRWpJLFdBQUssYUFDSixlQUFlLG1CQUNmLDRCQUE0QixXQUFXLFNBQVMsT0FBTyxLQUFLLEVBQUU7SUFFaEUsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxrQkFBa0IsT0FBTyxLQUFLLE9BQU8sT0FBTyxFQUFFO0FBQzFELFdBQUssYUFBYSxnQkFBZ0IsT0FBTztBQUN6QyxZQUFNLEtBQUssNkJBQTZCLGFBQWEsT0FBTztBQUM1RCxXQUFLLGFBQWEsZUFBZSxFQUFFO0lBQ3BDO0VBQ0Q7Ozs7O0VBTVEsTUFBTSw2QkFBNkIsT0FBZSxJQUFVO0FBQ25FLFFBQUk7QUFDSCxZQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUU3QyxVQUFJLENBQUMsZ0JBQWdCLEtBQUssR0FBRztBQUc1QixRQUFBQSxRQUFPLEtBQUssNkJBQTZCLEtBQUssc0RBQWlEO0FBQy9GO01BQ0Q7SUFDRCxTQUFTLEdBQUc7QUFDWCxNQUFBQSxRQUFPLEtBQUssaUNBQWlDLEVBQUUsS0FBSyxDQUFDLEVBQUU7SUFDeEQ7RUFDRDs7RUFHUSxVQUFVLE9BQWE7QUFDOUIsU0FBSyxjQUFjO0FBQ25CLFVBQU0sU0FBUyxnQkFBZ0IsS0FBSztBQUNwQyxRQUFJLENBQUMsUUFBUTtBQUNaLE1BQUFBLFFBQU8sS0FBSyxVQUFVLEtBQUssK0JBQStCO0FBQzFELFdBQUssYUFBYSxTQUFTLE9BQU8sQ0FBQSxHQUFJLElBQUk7QUFDMUM7SUFDRDtBQUVBLFVBQU0sVUFBVSxNQUFNLFFBQVEsT0FBTyxTQUFTLElBQUksT0FBTyxZQUFZLENBQUE7QUFDckUsVUFBTSxzQkFBc0IsT0FBTyx1QkFBdUI7QUFFMUQsU0FBSyxhQUFhLFNBQVMsT0FBTyxTQUFTLG1CQUFtQjtBQUM5RCxRQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3pCLE1BQUFBLFFBQU8sS0FBSywrQkFBK0IsS0FBSyw2Q0FBd0M7SUFDekYsT0FBTztBQUNOLE1BQUFBLFFBQU8sTUFDTixVQUFVLFFBQVEsTUFBTSx1QkFBdUIsS0FBSyxnQkFBZ0IsT0FBTyxTQUFTLHlCQUF5QixtQkFBbUIsRUFBRTtJQUVwSTtFQUNEO0VBRUEsa0JBQWU7QUFDZCxXQUFPLGdCQUFnQixLQUFLLGlCQUFpQjtFQUM5Qzs7RUFHQSxJQUFJLE9BQUk7QUFDUCxXQUFPLFlBQVksS0FBSyxRQUFRLEtBQUssaUJBQWlCO0VBQ3ZEOztFQUdBLElBQUksVUFBTztBQUNWLFdBQU8sS0FBSztFQUNiO0VBRUEsZ0JBQWE7QUFDWixrQkFBYyxJQUFJO0VBQ25CO0VBRUEsa0JBQWU7QUFDZCxvQkFBZ0IsSUFBSTtFQUNyQjtFQUVBLDRCQUF5QjtBQUN4Qiw4QkFBMEIsSUFBSTtFQUMvQjtFQUVBLHVCQUFvQjtBQUNuQix5QkFBcUIsSUFBSTtFQUMxQjs7IiwKICAibmFtZXMiOiBbInBhdGgiLCAiSW5zdGFuY2VTdGF0dXMiLCAiUmVnZXgiLCAicGF0aCIsICJmcyIsICJsb2dnZXIiLCAibG9nZ2VyIiwgImlkQWRkT3B0IiwgImZzIiwgImxvZ2dlciIsICJkZXZpY2VzRm9sZGVyIiwgInBhdGgiLCAiZGdyYW0iLCAibG9nZ2VyIiwgImxvZ2dlciIsICJkZ3JhbSIsICJsb2dnZXIiXQp9Cg==
