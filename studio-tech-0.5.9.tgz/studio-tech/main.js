import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual (enter IP + model below)" },
    ...discoveredDevices.map((d) => ({
      id: d.mac ?? "",
      label: `Model ${d.model} [${d.mac}] @ ${d.ip}`
    }))
  ];
  return [
    // ── Device selection dropdown ────────────────────────────────────────
    // Stores the MAC so re-discovery with a changed IP still matches.
    {
      type: "dropdown",
      id: "deviceMac",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry — only visible in manual mode ────────────────────
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Manual model selector — only visible in manual mode ──────────────
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Select which Studio Technologies model is active for actions and feedbacks."
    }
  ];
}
function resolveHost(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    return device?.ip ?? "";
  }
  return String(config.host ?? "");
}
function resolveModel(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    logger.debug(`resolveModel: deviceMac="${config.deviceMac}", found device: ${device?.model ?? "none"}`);
    return device?.model ?? "";
  }
  logger.debug(`resolveModel: manual mode, activeModel="${config.activeModel}"`);
  return String(config.activeModel ?? "");
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_MIC_PRE = 2;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_MIC_PRE:
      return "Mic Preamp";
    case CMD_BUS_GET:
      return "Heartbeat";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "static-text":
      return { ...base, value: o.value ?? "" };
    case "textinput":
    case "colorpicker":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  const commandsRawValue = [CMD_MIC_PRE];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    const isRawValue = commandsRawValue.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (isRawValue) {
      busCh = buf[p + 2];
      const rawBytes = buf.subarray(p + 3, sectionEnd);
      const micPreRemap = [1, 2];
      for (let i = 0; i < rawBytes.length; i++) {
        if (sectionCmdId === CMD_MIC_PRE) {
          const remappedId = i < micPreRemap.length ? micPreRemap[i] : null;
          if (remappedId !== null) {
            out.push({ cmd_id: CMD_MIC_PRE_BUS, id: remappedId, busCh, valueBytes: [rawBytes[i]] });
          }
        } else {
          out.push({ cmd_id: sectionCmdId, id: i, busCh, valueBytes: [rawBytes[i]] });
        }
      }
      p = sectionEnd;
      continue;
    } else if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    const qStart = q;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    if (q === qStart && sectionEnd > p + 3) {
      let pos = hasBusCh ? p + 3 : p + 2;
      let posId = 0;
      while (pos < sectionEnd) {
        const setting = { cmd_id: sectionCmdId, id: posId++, valueBytes: [buf[pos++]] };
        if (busCh !== void 0)
          setting.busCh = busCh;
        out.push(setting);
      }
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  const idAddDeferRanges = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    for (const baseEntry of c.cmdSchema ?? []) {
      const idAddOpt = baseEntry.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        continue;
      const baseId = baseEntry.id;
      const cmdId = baseEntry.cmd_id;
      const key = `${cmdId}_${baseId}`;
      if (idAddDeferRanges.has(key))
        continue;
      const parsedOffsets = parsed.filter((p) => p.cmd_id === cmdId && p.id > baseId).map((p) => p.id - baseId).sort((a, b) => a - b);
      let maxSeq = 0;
      for (const off of parsedOffsets) {
        if (off === maxSeq + 1)
          maxSeq = off;
        else if (off > maxSeq + 1)
          break;
      }
      if (maxSeq > 0) {
        idAddDeferRanges.set(key, maxSeq);
        logger2.debug(`idAdd defer range for cmd_id=${toHex(cmdId)} base_id=${toHex(baseId)}: offsets 1\u2013${maxSeq}`);
      }
    }
  }
  const busChSeen = /* @__PURE__ */ new Map();
  for (const { cmd_id, id, busCh } of parsed) {
    if (busCh === void 0)
      continue;
    const key = `${cmd_id}_${id}`;
    if (!busChSeen.has(key))
      busChSeen.set(key, /* @__PURE__ */ new Set());
    busChSeen.get(key).add(busCh);
  }
  for (const { cmd_id, id, busCh, valueBytes } of parsed) {
    const existingExact = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (existingExact) {
      const opt = existingExact.options?.find((o) => o.id === "value");
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
      continue;
    }
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt = a.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        return false;
      if (id <= a.id)
        return false;
      const offset = id - a.id;
      return candidates.some((c) => {
        const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === a.id);
        const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
        return refIdAdd?.choices?.some((ch) => ch.id === offset);
      });
    });
    if (idAddBase) {
      const offset = id - idAddBase.id;
      const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
      if (idAddOpt?.choices && !idAddOpt.choices.some((c) => c.id === offset)) {
        let label = `Channel ${offset + 1}`;
        for (const c of candidates) {
          const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
          const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
          const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
          if (refChoice) {
            label = refChoice.label;
            break;
          }
        }
        idAddOpt.choices.push({ id: offset, label });
        logger2.info(`Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
      }
      continue;
    }
    let action;
    for (const c of candidates) {
      const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
      if (match) {
        action = structuredClone(match);
        const baseName = match.name.replace(/\s*\(inferred from Model [^)]+\)/g, "").trim();
        action.name = `${baseName} (inferred from Model ${c.model})`;
        logger2.info(`Inferred cmd_id=${toHex(cmd_id)} id=${toHex(id)} from Model ${c.model} (exact)`);
        break;
      }
    }
    if (!action) {
      let shouldDefer = false;
      for (const c of candidates) {
        const baseEntry = c.cmdSchema?.find((a) => {
          if (a.cmd_id !== cmd_id)
            return false;
          const idAddOpt = a.options?.find((o) => o.id === "idAdd");
          if (!idAddOpt?.choices)
            return false;
          if (id <= a.id)
            return false;
          const offset = id - a.id;
          const maxSeq = idAddDeferRanges.get(`${cmd_id}_${a.id}`) ?? 0;
          return offset <= maxSeq;
        });
        if (baseEntry) {
          shouldDefer = true;
          logger2.debug(`cmd_id=${toHex(cmd_id)} id=${toHex(id)} is an idAdd offset of candidate base id=${toHex(baseEntry.id)} \u2014 deferring to pass 2`);
          break;
        }
      }
      if (shouldDefer)
        continue;
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown cmd:${toHex(cmd_id)} id:${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      if (busCh !== void 0)
        action.busCh = busCh;
      logger2.warn(`Could not infer cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
    } else {
      action.options = action.options?.filter((o) => o.id !== "busCh") ?? [];
      delete action.busCh;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        if (maxBusCh === 0) {
          action.busCh = 0;
        } else {
          const busChChoices = Array.from({ length: maxBusCh + 1 }, (_, i) => ({
            id: i,
            label: `Channel ${i + 1}`
          }));
          action.options.unshift({
            id: "busCh",
            label: "Channel",
            type: "dropdown",
            choices: busChChoices,
            default: 0
          });
        }
      }
      const observedDefault = valueBytesToOption(valueBytes).default;
      const valueOpt = action.options?.find((o) => o.id === "value");
      if (valueOpt) {
        if (valueOpt.choices && Array.isArray(valueOpt.choices)) {
          const inChoices = valueOpt.choices.some((c) => c.id === observedDefault);
          if (!inChoices) {
            logger2.warn(`Inferred choices for cmd_id=${toHex(cmd_id)} id=${toHex(id)} don't contain observed value ${observedDefault} \u2014 discarding inherited choices`);
            valueOpt.type = "number";
            delete valueOpt.choices;
          }
        }
        valueOpt.default = observedDefault;
      }
    }
    out.cmdSchema.push(action);
  }
  for (const { cmd_id, id } of parsed) {
    const alreadyTopLevel = out.cmdSchema.some((a) => a.cmd_id === cmd_id && a.id === id);
    if (alreadyTopLevel)
      continue;
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt2 = a.options?.find((o) => o.id === "idAdd");
      return !!idAddOpt2?.choices && id > a.id;
    });
    if (!idAddBase)
      continue;
    const offset = id - idAddBase.id;
    const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
    if (!idAddOpt?.choices || idAddOpt.choices.some((c) => c.id === offset))
      continue;
    const refHasOffset = candidates.some((c) => {
      const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      return refIdAdd?.choices?.some((ch) => ch.id === offset);
    });
    const existingOffsets = idAddOpt.choices.map((c) => c.id).sort((a, b) => a - b);
    const isSequential = existingOffsets.length > 0 && offset === existingOffsets[existingOffsets.length - 1] + 1;
    if (!refHasOffset && !isSequential)
      continue;
    let label = `Channel ${offset + 1}`;
    for (const c of candidates) {
      const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
      if (refChoice) {
        label = refChoice.label;
        break;
      }
    }
    idAddOpt.choices.push({ id: offset, label });
    logger2.info(`Pass 2: Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("refreshAfterCommand" in jsonObj) {
      orderedObj.refreshAfterCommand = jsonObj.refreshAfterCommand;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema.map((entry) => {
        const orderedEntry = {};
        if ("cmd_id" in entry)
          orderedEntry.cmd_id = entry.cmd_id;
        if ("id" in entry)
          orderedEntry.id = entry.id;
        if ("busCh" in entry)
          orderedEntry.busCh = entry.busCh;
        if ("name" in entry)
          orderedEntry.name = entry.name;
        if ("options" in entry)
          orderedEntry.options = entry.options;
        for (const key of Object.keys(entry)) {
          if (!(key in orderedEntry))
            orderedEntry[key] = entry[key];
        }
        return orderedEntry;
      });
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  wiredActions["global_getAllSettings"] = {
    name: "GLOBAL: Get All Settings (Auto-Update JSON)",
    options: [],
    callback: async () => {
      const model = activeModel;
      const ip = self.host;
      const buf = await self.stController.requestAllSettings(ip);
      let modelJson = getDeviceSchema(model);
      const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
      logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
      if (!modelJson) {
        logger3.info(`Model ${model} has no schema \u2014 creating new JSON from settings`);
        modelJson = {
          model,
          sectioned: detectedSectioned ?? false,
          refreshAfterCommand: true,
          cmdSchema: []
        };
      } else if (detectedSectioned !== null) {
        logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
        modelJson = { ...modelJson, sectioned: detectedSectioned };
      }
      const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
      logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
      const devicesFolder2 = getDevicesFolder();
      const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
      saveModelJsonPretty(schemaPath, updated);
      reloadDeviceSchemas();
      logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
    }
  };
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
          await self.stController.requestAllSettings(ip).catch((err) => {
            logger3.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
}

// dist/feedbacks.js
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        let busCh = feedbackEvent.options["busCh"];
        if (busCh === void 0) {
          const schemaAction = findActionForSetting(schemas, model, cmdId, settingId);
          if (schemaAction?.busCh !== void 0) {
            busCh = schemaAction.busCh;
          }
        }
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
}

// dist/stcontroller.js
import dgram2 from "dgram";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger4 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger4.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger4.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger4.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger4.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger4.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger4.warn(`Could not join announce multicast group: ${err}`);
      }
    });
  });
}

// dist/stcontroller.js
var logger5 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  constructor() {
    logger5.info("StController initialized");
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger5.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger5.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger5.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger5.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger5.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger5.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger5.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    logger5.debug(`Revoked device at ${ip}`);
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    return new Promise((resolve) => {
      const key = `__probe_${ip}__`;
      let resolved = false;
      const finish = (result) => {
        if (resolved)
          return;
        resolved = true;
        this.discoveryListeners.delete(key);
        resolve(result);
      };
      this.discoveryListeners.set(key, (device) => {
        if (device.ip === ip)
          finish(device);
      });
      const timer = setTimeout(() => finish(null), timeoutMs);
      timer.unref?.();
      const run = async () => {
        await this.ensureMembershipFor(ip);
        await this.txReady;
        const query = buildDanteInfoRequest();
        this.txSocket.send(query, this.defaultPort, ip, (err) => {
          if (err) {
            logger5.warn(`Probe to ${ip} failed: ${err.message}`);
            clearTimeout(timer);
            finish(null);
          }
        });
      };
      run().catch((e) => {
        logger5.warn(`probeDevice setup failed for ${ip}: ${e}`);
        clearTimeout(timer);
        finish(null);
      });
    });
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger5.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger5.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger5.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger5.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger5.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger5.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger5.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger5.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && this.refreshAfterCommand && value !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger5.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (cmdId === CMD_MIC_PRE && busCh !== void 0 && settingId !== void 0 && value !== void 0) {
      if (!this.deviceState.has(destIp))
        this.deviceState.set(destIp, /* @__PURE__ */ new Map());
      const ipState = this.deviceState.get(destIp);
      const numPositions = 3;
      const positions = [];
      for (let i = 0; i < numPositions; i++) {
        const stateKey = makeSettingId(this.model, CMD_MIC_PRE, i, busCh);
        const val = i === settingId ? Number(value) : ipState.get(stateKey) ?? 0;
        positions.push(val);
        ipState.set(stateKey, val);
      }
      payloadBody.push(busCh & 255, ...positions);
    } else {
      if (busCh !== void 0)
        payloadBody.push(busCh & 255);
      if (addLen)
        payloadBody.push(dataBlock.length);
      if (dataBlock.length > 0)
        payloadBody.push(...dataBlock);
    }
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger5.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger5.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    if (!this.authorizedIps.has(destIp)) {
      logger5.debug(`Packet (not sent \u2014 device not authorized) to ${destIp}: ${payloadWithCrc.toString("hex")}`);
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    await this.ensureMembershipFor(destIp);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    logger5.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger5.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger5.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse && originalCmdId === CMD_GET_ALL_SETTINGS) {
      logger5.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
    }
    this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger5.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger5.info(`RX ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, s.id);
              this.feedbackCallback(baseFeedbackKey);
            } else {
              logger5.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger5.debug(`RX ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger5.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    const logFn = cmdId === CMD_BUS_GET ? logger5.debug.bind(logger5) : logger5.info.bind(logger5);
    if (decoded) {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_MIC_PRE (0x02): raw preamp echo — positional bytes, no setting IDs ──
      // Device echoes [busCh][val0][val1]... confirming the applied values.
      case CMD_MIC_PRE: {
        const busCh = data[0];
        const vals = Array.from(data.subarray(1)).map((b, i) => `[${i}]=0x${b.toString(16).padStart(2, "0")}(${b})`).join(" ");
        return `ch=${busCh} ${vals}`;
      }
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger6 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Connecting, "Discovering devices...");
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger6.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger6.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      if (this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found during discovery \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger6.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger6.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger6.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger6.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger6.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger6.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
      if (!effectiveModel && this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found among discovered devices \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    this.updateStatus(InstanceStatus.Ok);
    logger6.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger6.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current config is authorized to send commands.
   *
   * Auto mode (deviceMac set):
   *   - Find the discovered device with matching MAC → get its current IP
   *   - Revoke the previous IP, authorize the new IP
   *   - If MAC not found in discovery, revoke and block
   *
   * Manual mode (deviceMac empty):
   *   - Check discovered list by IP+model match, or probe directly
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.deviceMac) {
      const device = this.discoveredDevices.find((d) => d.mac === this.config.deviceMac);
      if (!device) {
        logger6.warn(`Device MAC "${this.config.deviceMac}" not found in current discovery \u2014 not authorizing`);
        if (previousHost)
          this.stController.revokeDevice(previousHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        await this.fetchSettingsAndEnsureSchema(device.model, newHost);
      }
      return;
    }
    const manualModel = String(this.config.activeModel ?? "");
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
      } else {
        logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
        this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${discoveredAtIp.model}`);
      }
      return;
    }
    logger6.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger6.error(`No device responded at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.UnknownWarning, `Device offline: ${newHost}`);
    } else if (probed.model !== manualModel) {
      logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${probed.model}`);
    } else {
      logger6.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
      this.updateStatus(InstanceStatus.Ok);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger6.warn(`No schema found for Model ${model} \u2014 run "GLOBAL: Get All Settings" to create one`);
        return;
      }
    } catch (e) {
      logger6.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger6.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, [], true);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    const refreshAfterCommand = schema.refreshAfterCommand ?? true;
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger6.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger6.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}, refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, resolved from MAC→IP via discoveredDevices (auto) or config.host (manual). */
  get host() {
    return resolveHost(this.config, this.discoveredDevices);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0LyoqIE1BQyBvZiB0aGUgc2VsZWN0ZWQgZGlzY292ZXJlZCBkZXZpY2UgKGUuZy4gXCIwMDoxZDpjMTo5YjphNjpjZFwiKSwgb3IgJycgZm9yIG1hbnVhbCBtb2RlICovXG5cdGRldmljZU1hYzogc3RyaW5nXG5cdC8qKiBNYW51YWwgSVAgYWRkcmVzcyBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGhvc3Q6IHN0cmluZ1xuXHQvKiogTWFudWFsIG1vZGVsIHNlbGVjdGlvbiBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcbn1cblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQ0VOVFJBTElaRUQgREVWSUNFIFNDSEVNQSBDQUNIRVxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQWxsIGRldmljZSBKU09OIGZpbGVzIGFyZSBsb2FkZWQgb25jZSBpbnRvIG1lbW9yeSBoZXJlLiBPdGhlciBtb2R1bGVzIHNob3VsZFxuLy8gdXNlIGdldERldmljZXNGb2xkZXIoKSwgZ2V0RGV2aWNlU2NoZW1hcygpLCBhbmQgZ2V0RGV2aWNlU2NoZW1hKCkgaW5zdGVhZCBvZlxuLy8gcmVhZGluZyBmaWxlcyBkaXJlY3RseS4gQ2FsbCByZWxvYWREZXZpY2VTY2hlbWFzKCkgYWZ0ZXIgd3JpdGluZyB0byBhIGZpbGUuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB0aGUgY29ycmVjdCBkZXZpY2VzIGZvbGRlciBwYXRoIHdpdGggZmFsbGJhY2sgc3VwcG9ydC5cbiAqIENoZWNrcyBwcmltYXJ5IHBhdGggZmlyc3QsIHRoZW4gZmFsbGJhY2ssIHRoZW4gdGhyb3dzIGVycm9yIGlmIG5laXRoZXIgZXhpc3RzLlxuICovXG5mdW5jdGlvbiByZXNvbHZlRGV2aWNlc0ZvbGRlcigpOiBzdHJpbmcge1xuXHRjb25zdCBwcmltYXJ5UGF0aCA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi4vZGV2aWNlcycpXG5cdGNvbnN0IGZhbGxiYWNrUGF0aCA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi9kZXZpY2VzJylcblxuXHQvLyBDaGVjayBwcmltYXJ5IHBhdGhcblx0aWYgKGZzLmV4aXN0c1N5bmMocHJpbWFyeVBhdGgpKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBVc2luZyBkZXZpY2VzIGZvbGRlcjogJHtwcmltYXJ5UGF0aH1gKVxuXHRcdHJldHVybiBwcmltYXJ5UGF0aFxuXHR9XG5cblx0Ly8gQ2hlY2sgZmFsbGJhY2sgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhmYWxsYmFja1BhdGgpKSB7XG5cdFx0bG9nZ2VyLndhcm4oYFByaW1hcnkgZGV2aWNlcyBmb2xkZXIgbm90IGZvdW5kLCB1c2luZyBmYWxsYmFjazogJHtmYWxsYmFja1BhdGh9YClcblx0XHRyZXR1cm4gZmFsbGJhY2tQYXRoXG5cdH1cblxuXHQvLyBOZWl0aGVyIHBhdGggZXhpc3RzIC0gZmF0YWwgZXJyb3Jcblx0Y29uc3QgZXJyb3JNc2cgPSBgRGV2aWNlcyBmb2xkZXIgbm90IGZvdW5kIVxcblRyaWVkOlxcbiAgLSAke3ByaW1hcnlQYXRofVxcbiAgLSAke2ZhbGxiYWNrUGF0aH1cXG5Nb2R1bGUgY2Fubm90IGNvbnRpbnVlIHdpdGhvdXQgZGV2aWNlIHNjaGVtYXMuYFxuXHRsb2dnZXIuZXJyb3IoZXJyb3JNc2cpXG5cdHRocm93IG5ldyBFcnJvcihlcnJvck1zZylcbn1cblxuLy8gUmVzb2x2ZSB0aGUgZGV2aWNlcyBmb2xkZXIgcGF0aCAod2l0aCBleGlzdGVuY2UgY2hlY2sgYW5kIGZhbGxiYWNrKVxuY29uc3QgZGV2aWNlc0ZvbGRlciA9IHJlc29sdmVEZXZpY2VzRm9sZGVyKClcblxuLy8gSW4tbWVtb3J5IGNhY2hlIG9mIGFsbCBkZXZpY2Ugc2NoZW1hcywga2V5ZWQgYnkgbW9kZWwgbnVtYmVyXG5sZXQgZGV2aWNlU2NoZW1hc0NhY2hlOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgbnVsbCA9IG51bGxcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBhYnNvbHV0ZSBwYXRoIHRvIHRoZSBkZXZpY2VzIGZvbGRlci5cbiAqIFVzZSB0aGlzIGluc3RlYWQgb2YgcmVkZWZpbmluZyB0aGUgcGF0aCBpbiBldmVyeSBmaWxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlc0ZvbGRlcigpOiBzdHJpbmcge1xuXHRyZXR1cm4gZGV2aWNlc0ZvbGRlclxufVxuXG4vKipcbiAqIExvYWRzIGFsbCBkZXZpY2UgSlNPTiBmaWxlcyBmcm9tIHRoZSBkZXZpY2VzIGZvbGRlciBpbnRvIG1lbW9yeS5cbiAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uY2UgYXQgaW5pdGlhbGl6YXRpb24sIG9yIGFmdGVyIGEgZmlsZSBpcyB3cml0dGVuLlxuICovXG5mdW5jdGlvbiBsb2FkRGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0Y29uc3Qgc2NoZW1hczogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9XG5cdHRyeSB7XG5cdFx0Y29uc3QgZmlsZXMgPSBmcy5yZWFkZGlyU3luYyhkZXZpY2VzRm9sZGVyKS5maWx0ZXIoKGYpID0+IGYuZW5kc1dpdGgoJy5qc29uJykpXG5cblx0XHRmb3IgKGNvbnN0IGYgb2YgZmlsZXMpIHtcblx0XHRcdGNvbnN0IGZ1bGxQYXRoID0gcGF0aC5qb2luKGRldmljZXNGb2xkZXIsIGYpXG5cdFx0XHRjb25zdCBqc29uID0gSlNPTi5wYXJzZShmcy5yZWFkRmlsZVN5bmMoZnVsbFBhdGgsICd1dGY4JykpXG5cdFx0XHRpZiAoanNvbj8ubW9kZWwpIHtcblx0XHRcdFx0c2NoZW1hc1tTdHJpbmcoanNvbi5tb2RlbCldID0ganNvblxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGxvZ2dlci5kZWJ1ZyhgTG9hZGVkICR7T2JqZWN0LmtleXMoc2NoZW1hcykubGVuZ3RofSBkZXZpY2Ugc2NoZW1hcyBpbnRvIGNhY2hlYClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmFpbGVkIHRvIGxvYWQgZGV2aWNlIHNjaGVtYXM6ICR7ZX1gKVxuXHR9XG5cdHJldHVybiBzY2hlbWFzXG59XG5cbi8qKlxuICogUmV0dXJucyBhbGwgZGV2aWNlIHNjaGVtYXMgZnJvbSB0aGUgY2FjaGUuXG4gKiBJbml0aWFsaXplcyB0aGUgY2FjaGUgb24gZmlyc3QgY2FsbC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZVNjaGVtYXMoKTogUmVjb3JkPHN0cmluZywgYW55PiB7XG5cdGlmICghZGV2aWNlU2NoZW1hc0NhY2hlKSB7XG5cdFx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxuXHR9XG5cdHJldHVybiBkZXZpY2VTY2hlbWFzQ2FjaGVcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgc3BlY2lmaWMgZGV2aWNlIHNjaGVtYSBieSBtb2RlbCBudW1iZXIuXG4gKiBSZXR1cm5zIHVuZGVmaW5lZCBpZiB0aGUgbW9kZWwgZG9lc24ndCBleGlzdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZVNjaGVtYShtb2RlbDogc3RyaW5nKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRyZXR1cm4gc2NoZW1hc1ttb2RlbF1cbn1cblxuLyoqXG4gKiBSZWxvYWRzIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIGRpc2suXG4gKiBDYWxsIHRoaXMgYWZ0ZXIgd3JpdGluZyB0byBhIGRldmljZSBKU09OIGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZWxvYWREZXZpY2VTY2hlbWFzKCk6IHZvaWQge1xuXHRsb2dnZXIuaW5mbygnUmVsb2FkaW5nIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay4uLicpXG5cdGRldmljZVNjaGVtYXNDYWNoZSA9IGxvYWREZXZpY2VTY2hlbWFzKClcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgbGlzdCBvZiBhdmFpbGFibGUgbW9kZWwgbnVtYmVycywgc29ydGVkLlxuICovXG5mdW5jdGlvbiBsb2FkQXZhaWxhYmxlTW9kZWxzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRyZXR1cm4gT2JqZWN0LmtleXMoc2NoZW1hcykuc29ydCgpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBHZXRDb25maWdGaWVsZHMoZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSA9IFtdKTogU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkW10ge1xuXHRjb25zdCBtb2RlbHMgPSBsb2FkQXZhaWxhYmxlTW9kZWxzKClcblxuXHQvLyBEcm9wZG93biBpZCBpcyB0aGUgZGV2aWNlIE1BQyBcdTIwMTQgc3RhYmxlIGFjcm9zcyBJUCBjaGFuZ2VzLlxuXHQvLyBFbXB0eSBpZCA9IE1hbnVhbCBtb2RlLlxuXHRjb25zdCBkZXZpY2VDaG9pY2VzID0gW1xuXHRcdHsgaWQ6ICcnLCBsYWJlbDogJ01hbnVhbCAoZW50ZXIgSVAgKyBtb2RlbCBiZWxvdyknIH0sXG5cdFx0Li4uZGlzY292ZXJlZERldmljZXMubWFwKChkKSA9PiAoe1xuXHRcdFx0aWQ6IGQubWFjID8/ICcnLFxuXHRcdFx0bGFiZWw6IGBNb2RlbCAke2QubW9kZWx9IFske2QubWFjfV0gQCAke2QuaXB9YCxcblx0XHR9KSksXG5cdF1cblxuXHRyZXR1cm4gW1xuXHRcdC8vIFx1MjUwMFx1MjUwMCBEZXZpY2Ugc2VsZWN0aW9uIGRyb3Bkb3duIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFN0b3JlcyB0aGUgTUFDIHNvIHJlLWRpc2NvdmVyeSB3aXRoIGEgY2hhbmdlZCBJUCBzdGlsbCBtYXRjaGVzLlxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2RldmljZU1hYycsXG5cdFx0XHRsYWJlbDogJ0RldmljZScsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0Y2hvaWNlczogZGV2aWNlQ2hvaWNlcyxcblx0XHRcdHRvb2x0aXA6ICdTZWxlY3QgYW4gYXV0by1kaXNjb3ZlcmVkIFN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlLCBvciBjaG9vc2UgTWFudWFsIHRvIGVudGVyIGFuIElQIGFkZHJlc3MuJyxcblx0XHR9LFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIE1hbnVhbCBJUCBlbnRyeSBcdTIwMTQgb25seSB2aXNpYmxlIGluIG1hbnVhbCBtb2RlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdHtcblx0XHRcdHR5cGU6ICd0ZXh0aW5wdXQnLFxuXHRcdFx0aWQ6ICdob3N0Jyxcblx0XHRcdGxhYmVsOiAnVGFyZ2V0IElQJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRyZWdleDogUmVnZXguSVAsXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkZXZpY2VNYWMpYCxcblx0XHRcdHRvb2x0aXA6ICdFbnRlciB0aGUgSVAgYWRkcmVzcyBvZiB0aGUgZGV2aWNlIG1hbnVhbGx5LicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNYW51YWwgbW9kZWwgc2VsZWN0b3IgXHUyMDE0IG9ubHkgdmlzaWJsZSBpbiBtYW51YWwgbW9kZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHR7XG5cdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0aWQ6ICdhY3RpdmVNb2RlbCcsXG5cdFx0XHRsYWJlbDogJ0FjdGl2ZSBEZXZpY2UgTW9kZWwnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiBtb2RlbHNbMF0gPz8gJycsXG5cdFx0XHRjaG9pY2VzOiBtb2RlbHMubWFwKChtb2RlbCkgPT4gKHtcblx0XHRcdFx0aWQ6IG1vZGVsLFxuXHRcdFx0XHRsYWJlbDogYE1vZGVsICR7bW9kZWx9YCxcblx0XHRcdH0pKSxcblx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246IGAhJChvcHRpb25zOmRldmljZU1hYylgLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCB3aGljaCBTdHVkaW8gVGVjaG5vbG9naWVzIG1vZGVsIGlzIGFjdGl2ZSBmb3IgYWN0aW9ucyBhbmQgZmVlZGJhY2tzLicsXG5cdFx0fSxcblx0XVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLlxuICogQXV0byBtb2RlIChkZXZpY2VNYWMgc2V0KTogZmluZHMgdGhlIGN1cnJlbnQgSVAgb2YgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIHdpdGggdGhhdCBNQUMuXG4gKiBNYW51YWwgbW9kZSAoZGV2aWNlTWFjIGVtcHR5KTogcmV0dXJucyB0aGUgbWFudWFsbHkgZW50ZXJlZCBob3N0IElQLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUhvc3QoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRldmljZU1hYykge1xuXHRcdGNvbnN0IGRldmljZSA9IGRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQubWFjID09PSBjb25maWcuZGV2aWNlTWFjKVxuXHRcdHJldHVybiBkZXZpY2U/LmlwID8/ICcnXG5cdH1cblx0cmV0dXJuIFN0cmluZyhjb25maWcuaG9zdCA/PyAnJylcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgbW9kZWwuXG4gKiBBdXRvIG1vZGU6IHVzZXMgdGhlIG1vZGVsIGZyb20gdGhlIGRpc2NvdmVyZWQgZGV2aWNlIG1hdGNoaW5nIHRoZSBzdG9yZWQgTUFDLlxuICogTWFudWFsIG1vZGU6IHVzZXMgdGhlIG1hbnVhbGx5IHNlbGVjdGVkIGFjdGl2ZU1vZGVsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZU1vZGVsKGNvbmZpZzogTW9kdWxlQ29uZmlnLCBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdKTogc3RyaW5nIHtcblx0aWYgKGNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRjb25zdCBkZXZpY2UgPSBkaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gY29uZmlnLmRldmljZU1hYylcblx0XHRsb2dnZXIuZGVidWcoYHJlc29sdmVNb2RlbDogZGV2aWNlTWFjPVwiJHtjb25maWcuZGV2aWNlTWFjfVwiLCBmb3VuZCBkZXZpY2U6ICR7ZGV2aWNlPy5tb2RlbCA/PyAnbm9uZSd9YClcblx0XHRyZXR1cm4gZGV2aWNlPy5tb2RlbCA/PyAnJ1xuXHR9XG5cdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBtYW51YWwgbW9kZSwgYWN0aXZlTW9kZWw9XCIke2NvbmZpZy5hY3RpdmVNb2RlbH1cImApXG5cdHJldHVybiBTdHJpbmcoY29uZmlnLmFjdGl2ZU1vZGVsID8/ICcnKVxufVxuIiwgImltcG9ydCB0eXBlIE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcblxuLyoqXG4gKiBEZWZpbmUgQ29tcGFuaW9uIHZhcmlhYmxlcyBmb3IgdGhpcyBtb2R1bGUuXG4gKiBWYXJpYWJsZXMgY2FuIGJlIHVzZWQgdG8gZGlzcGxheSBkeW5hbWljIHN0YXRlIGluIGJ1dHRvbiBsYWJlbHMsIHRyaWdnZXJzLCBldGMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh7XG5cdFx0bW9kZWw6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOdW1iZXInIH0sXG5cdFx0bW9kZWxOYW1lOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTmFtZSAoRnVsbCBEZXNjcmlwdGlvbiknIH0sXG5cdFx0bWFudWZhY3R1cmVyOiB7IG5hbWU6ICdEZXZpY2UgTWFudWZhY3R1cmVyJyB9LFxuXHRcdGZpcm13YXJlOiB7IG5hbWU6ICdEZXZpY2UgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRkYW50ZUZXOiB7IG5hbWU6ICdEYW50ZSBNb2R1bGUgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRtYWM6IHsgbmFtZTogJ0RldmljZSBNQUMgQWRkcmVzcycgfSxcblx0XHRpcDogeyBuYW1lOiAnRGV2aWNlIElQIEFkZHJlc3MnIH0sXG5cdH0pXG59XG5cbmNvbnN0IENMRUFSRURfVkFSSUFCTEVTID0ge1xuXHRtb2RlbDogJycsXG5cdG1vZGVsTmFtZTogJycsXG5cdG1hbnVmYWN0dXJlcjogJycsXG5cdGZpcm13YXJlOiAnJyxcblx0ZGFudGVGVzogJycsXG5cdG1hYzogJycsXG5cdGlwOiAnJyxcbn1cblxuLyoqXG4gKiBVcGRhdGUgdmFyaWFibGUgdmFsdWVzIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaW5mb3JtYXRpb24uXG4gKiBPbmx5IHBvcHVsYXRlcyB2YXJpYWJsZXMgd2hlbiB0aGUgY3VycmVudCBob3N0IGlzIGF1dGhvcml6ZWQuXG4gKiBDbGVhcnMgYWxsIHZhcmlhYmxlcyBpZiB0aGUgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkIG9yIG5vdCBmb3VuZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IGN1cnJlbnRIb3N0ID0gc2VsZi5ob3N0XG5cblx0Ly8gQ2xlYXIgdmFyaWFibGVzIGlmIG5vIGhvc3QgY29uZmlndXJlZCBvciBkZXZpY2UgaXMgbm90IGF1dGhvcml6ZWRcblx0aWYgKCFjdXJyZW50SG9zdCB8fCAhc2VsZi5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKGN1cnJlbnRIb3N0KSkge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoQ0xFQVJFRF9WQVJJQUJMRVMpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBkZXZpY2UgPSBzZWxmLmRldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY3VycmVudEhvc3QpXG5cdGlmIChkZXZpY2UpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdG1vZGVsOiBkZXZpY2UubW9kZWwgfHwgJycsXG5cdFx0XHRtb2RlbE5hbWU6IGRldmljZS5tb2RlbE5hbWUgfHwgJycsXG5cdFx0XHRtYW51ZmFjdHVyZXI6IGRldmljZS5tYW51ZmFjdHVyZXIgfHwgJycsXG5cdFx0XHRmaXJtd2FyZTogZGV2aWNlLmZpcm13YXJlTWFpbiB8fCAnJyxcblx0XHRcdGRhbnRlRlc6IGRldmljZS5kYW50ZUZpcm13YXJlIHx8ICcnLFxuXHRcdFx0bWFjOiBkZXZpY2UubWFjIHx8ICcnLFxuXHRcdFx0aXA6IGRldmljZS5pcCxcblx0XHR9KVxuXHR9IGVsc2Uge1xuXHRcdC8vIEF1dGhvcml6ZWQgYnV0IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgKG1hbnVhbCBJUCB0aGF0IHByb2JlZCBzdWNjZXNzZnVsbHkpXG5cdFx0Ly8gV2Uga25vdyBpdCdzIHRoZSByaWdodCBkZXZpY2UgYnV0IGRvbid0IGhhdmUgZnVsbCBpbmZvIHlldFxuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0Li4uQ0xFQVJFRF9WQVJJQUJMRVMsXG5cdFx0XHRpcDogY3VycmVudEhvc3QsXG5cdFx0fSlcblx0fVxufVxuIiwgImltcG9ydCB0eXBlIHsgQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG5leHBvcnQgY29uc3QgVXBncmFkZVNjcmlwdHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQ8TW9kdWxlQ29uZmlnPltdID0gW1xuXHQvKlxuXHQgKiBQbGFjZSB5b3VyIHVwZ3JhZGUgc2NyaXB0cyBoZXJlXG5cdCAqIFJlbWVtYmVyIHRoYXQgb25jZSBpdCBoYXMgYmVlbiBhZGRlZCBpdCBjYW5ub3QgYmUgcmVtb3ZlZCFcblx0ICovXG5cdC8vIGZ1bmN0aW9uIChjb250ZXh0LCBwcm9wcykge1xuXHQvLyBcdHJldHVybiB7XG5cdC8vIFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHQvLyBcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHQvLyBcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdC8vIFx0fVxuXHQvLyB9LFxuXVxuIiwgImV4cG9ydCB0eXBlIENvbXBhbmlvbklucHV0Q2hvaWNlID0ge1xuXHRpZDogc3RyaW5nIHwgbnVtYmVyXG5cdGxhYmVsOiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgRGV2aWNlU2V0dGluZyA9IHtcblx0dHlwZTogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVmYXVsdDogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhblxuXHRjaG9pY2VzPzogQ29tcGFuaW9uSW5wdXRDaG9pY2VbXVxufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFID0gMHgwMiAvLyBNaWMgcHJlYW1wIHJhdyBzZXQgKGdhaW4sIHBoYW50b20pIFx1MjAxNCBwb3NpdGlvbmFsIGJ5dGVzLCBubyBzZXR0aW5nIElEc1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBIZWFydGJlYXQgLyBrZWVwYWxpdmUgcGluZ1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfU0VUID0gMHgwNCAvLyBTZXQgc2V0dGluZyBvbiBzcGVjaWZpYyBidXMvY2hhbm5lbFxuZXhwb3J0IGNvbnN0IENNRF9IRUFEUEhPTkUgPSAweDA1IC8vIEhlYWRwaG9uZSBjb250cm9sc1xuZXhwb3J0IGNvbnN0IENNRF9CVVRUT05fTU9ERSA9IDB4MDcgLy8gQnV0dG9uIG1vZGUgY29uZmlndXJhdGlvblxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kc1xuZXhwb3J0IGNvbnN0IENNRF9HRVRfQUxMX1NFVFRJTkdTID0gMHgwYSAvLyBSZXF1ZXN0IGFsbCBjdXJyZW50IHNldHRpbmdzIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX1NFVFRJTkdTX1BVU0ggPSAweDBiIC8vIFVuc29saWNpdGVkIHNldHRpbmdzIHVwZGF0ZSBmcm9tIGRldmljZVxuZXhwb3J0IGNvbnN0IENNRF9ERVZfU1BFQyA9IDB4MGQgLy8gRGV2aWNlLXNwZWNpZmljIHNldHRpbmcgZ2V0L3NldCB3aXRoIEFDS1xuZXhwb3J0IGNvbnN0IENNRF9SRVNFVF9ERVZJQ0UgPSAweDBlIC8vIEZhY3RvcnkgcmVzZXQgY29tbWFuZFxuZXhwb3J0IGNvbnN0IENNRF9HTE9CQUxfTUlDX0tJTEwgPSAweDEwIC8vIEVtZXJnZW5jeSBtaWMga2lsbCAoYWxsIGNoYW5uZWxzKVxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFX0JVUyA9IDB4MTIgLy8gTWljL3ByZWFtcCBzZXR0aW5ncyBwZXIgYnVzIChnYWluLCBwaGFudG9tLCBldGMpXG5leHBvcnQgY29uc3QgQ01EX0NIQU5ORUwgPSAweDE0IC8vIENoYW5uZWwtc3BlY2lmaWMgY29udHJvbHNcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIENvbW1hbmQgTmFtZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29tbWFuZE5hbWUoY21kSWQ6IG51bWJlcik6IHN0cmluZyB7XG5cdHN3aXRjaCAoY21kSWQpIHtcblx0XHRjYXNlIENNRF9HRVRfRklSTVdBUkU6XG5cdFx0XHRyZXR1cm4gJ0dldCBGaXJtd2FyZSBWZXJzaW9uJ1xuXHRcdGNhc2UgQ01EX01JQ19QUkU6XG5cdFx0XHRyZXR1cm4gJ01pYyBQcmVhbXAnXG5cdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdHJldHVybiAnSGVhcnRiZWF0J1xuXHRcdGNhc2UgQ01EX0JVU19TRVQ6XG5cdFx0XHRyZXR1cm4gJ1NldCBCdXMgU2V0dGluZydcblx0XHRjYXNlIENNRF9IRUFEUEhPTkU6XG5cdFx0XHRyZXR1cm4gJ0hlYWRwaG9uZSBDb250cm9sJ1xuXHRcdGNhc2UgQ01EX0JVVFRPTl9NT0RFOlxuXHRcdFx0cmV0dXJuICdCdXR0b24gTW9kZSdcblx0XHRjYXNlIENNRF9TWVNURU06XG5cdFx0XHRyZXR1cm4gJ1N5c3RlbSBDb21tYW5kJ1xuXHRcdGNhc2UgQ01EX0dFVF9BTExfU0VUVElOR1M6XG5cdFx0XHRyZXR1cm4gJ1JlcXVlc3QgQWxsIFNldHRpbmdzJ1xuXHRcdGNhc2UgQ01EX1NFVFRJTkdTX1BVU0g6XG5cdFx0XHRyZXR1cm4gJ1NldHRpbmdzIFB1c2gnXG5cdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6XG5cdFx0XHRyZXR1cm4gJ01pYy9QcmUgQnVzJ1xuXHRcdGNhc2UgQ01EX0RFVl9TUEVDOlxuXHRcdFx0cmV0dXJuICdEZXZpY2UgU2V0dGluZydcblx0XHRjYXNlIENNRF9DSEFOTkVMOlxuXHRcdFx0cmV0dXJuICdDaGFubmVsIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfUkVTRVRfREVWSUNFOlxuXHRcdFx0cmV0dXJuICdSZXNldCBEZXZpY2UnXG5cdFx0Y2FzZSBDTURfR0xPQkFMX01JQ19LSUxMOlxuXHRcdFx0cmV0dXJuICdHbG9iYWwgTWljIEtpbGwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgY21kXzB4JHtjbWRJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIEdlbmVyYXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDcmVhdGVzIGEgY29uc2lzdGVudCBJRCBmb3IgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgc3RhdGUga2V5cy5cbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2J1c0NofV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKGUuZy4sIFwiNTMwNF8xNF8wXzBcIilcbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGhvdXQgYnVzQ2ggKGUuZy4sIFwiNTMwNF8xMl9kXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWtlU2V0dGluZ0lkKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRzZXR0aW5nSWQ6IG51bWJlciB8IHN0cmluZyxcblx0YnVzQ2g/OiBudW1iZXIgfCBzdHJpbmcsXG4pOiBzdHJpbmcge1xuXHRjb25zdCBjbWQgPSB0eXBlb2YgY21kSWQgPT09ICdudW1iZXInID8gY21kSWQudG9TdHJpbmcoMTYpIDogY21kSWRcblx0Y29uc3QgaWQgPSB0eXBlb2Ygc2V0dGluZ0lkID09PSAnbnVtYmVyJyA/IHNldHRpbmdJZC50b1N0cmluZygxNikgOiBzZXR0aW5nSWRcblxuXHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IGNoID0gdHlwZW9mIGJ1c0NoID09PSAnbnVtYmVyJyA/IGJ1c0NoLnRvU3RyaW5nKDE2KSA6IGJ1c0NoXG5cdFx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtjaH1fJHtpZH1gXG5cdH1cblxuXHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2lkfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEhleCBGb3JtYXR0aW5nIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENvbnZlcnRzIGEgbnVtYmVyIHRvIGEgaGV4IHN0cmluZyB3aXRoIDB4IHByZWZpeCBhbmQgcGFkZGluZy5cbiAqIEBwYXJhbSB2YWx1ZSAtIFRoZSBudW1iZXIgdG8gY29udmVydFxuICogQHBhcmFtIHBhZExlbmd0aCAtIE51bWJlciBvZiBoZXggZGlnaXRzIHRvIHBhZCB0byAoZGVmYXVsdDogMilcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGRcIiwgXCIweGZmXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0hleCh2YWx1ZTogbnVtYmVyLCBwYWRMZW5ndGggPSAyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAweCR7dmFsdWUudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KHBhZExlbmd0aCwgJzAnKX1gXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gYXJyYXkgb2YgYnl0ZXMgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4LlxuICogQHBhcmFtIGJ5dGVzIC0gQXJyYXkgb2YgYnl0ZXMgb3IgQnVmZmVyXG4gKiBAcmV0dXJucyBGb3JtYXR0ZWQgaGV4IHN0cmluZyAoZS5nLiwgXCIweDBhZmYxMlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnl0ZXNUb0hleChieXRlczogbnVtYmVyW10gfCBCdWZmZXIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHtBcnJheS5mcm9tKGJ5dGVzKVxuXHRcdC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0LmpvaW4oJycpfWBcbn1cblxuLyoqXG4gKiBGb3JtYXRzIFJHQiBjb2xvciBieXRlcyBhcyBhIENTUyBoZXggY29sb3Igc3RyaW5nLlxuICogQHBhcmFtIHIgLSBSZWQgY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBnIC0gR3JlZW4gY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBiIC0gQmx1ZSBjb21wb25lbnQgKDAtMjU1KVxuICogQHJldHVybnMgQ1NTIGhleCBjb2xvciBzdHJpbmcgKGUuZy4sIFwiI0ZGMDBBQlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UmdiQ29sb3IocjogbnVtYmVyLCBnOiBudW1iZXIsIGI6IG51bWJlcik6IHN0cmluZyB7XG5cdHJldHVybiBgIyR7W3IsIGcsIGJdXG5cdFx0Lm1hcCgodikgPT4gdi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJylcblx0XHQudG9VcHBlckNhc2UoKX1gXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBJRCBQYXJzaW5nIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogUGFyc2VzIGEgc2V0dGluZyBJRCBzdHJpbmcgaW50byBpdHMgY29tcG9uZW50cy5cbiAqIEBwYXJhbSBpZCAtIFNldHRpbmcgSUQgc3RyaW5nIChlLmcuLCBcIjM5MV9kXzBcIiBvciBcIjUzMDRfMTRfMF8xXCIpXG4gKiBAcmV0dXJucyBQYXJzZWQgY29tcG9uZW50cyB3aXRoIGhleCBzdHJpbmdzIGNvbnZlcnRlZCB0byBudW1iZXJzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdJZChpZDogc3RyaW5nKTogeyBtb2RlbDogc3RyaW5nOyBjbWRJZDogbnVtYmVyOyBiYXNlSWQ6IG51bWJlciB9IHtcblx0Y29uc3QgW21vZGVsLCBjbWRJZFN0ciwgaWRTdHJdID0gaWQuc3BsaXQoJ18nKVxuXHRyZXR1cm4ge1xuXHRcdG1vZGVsLFxuXHRcdGNtZElkOiBwYXJzZUludChjbWRJZFN0ciwgMTYpLFxuXHRcdGJhc2VJZDogcGFyc2VJbnQoaWRTdHIsIDE2KSxcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgTW9kZWwgRGlzdGFuY2UgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDYWxjdWxhdGVzIG51bWVyaWMgZGlzdGFuY2UgYmV0d2VlbiB0d28gbW9kZWwgbnVtYmVycy5cbiAqIFVzZWQgZm9yIGZpbmRpbmcgc2ltaWxhciBtb2RlbHMgZm9yIHNldHRpbmcgaW5mZXJlbmNlLlxuICogQHBhcmFtIG1vZGVsQSAtIEZpcnN0IG1vZGVsIG51bWJlciAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBtb2RlbEIgLSBTZWNvbmQgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MlwiKVxuICogQHJldHVybnMgTnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIG1vZGVscywgb3IgSW5maW5pdHkgaWYgZWl0aGVyIGlzIG5vbi1udW1lcmljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb2RlbERpc3RhbmNlKG1vZGVsQTogc3RyaW5nLCBtb2RlbEI6IHN0cmluZyk6IG51bWJlciB7XG5cdGNvbnN0IG5hID0gcGFyc2VJbnQobW9kZWxBLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRjb25zdCBuYiA9IHBhcnNlSW50KG1vZGVsQi5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0aWYgKE51bWJlci5pc05hTihuYSkgfHwgTnVtYmVyLmlzTmFOKG5iKSkgcmV0dXJuIEluZmluaXR5XG5cdHJldHVybiBNYXRoLmFicyhuYSAtIG5iKVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU2NoZW1hIE5vcm1hbGl6YXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBOb3JtYWxpemVzIGRldmljZSBzY2hlbWFzIHRvIGVuc3VyZSBjbWRTY2hlbWEgaXMgYWx3YXlzIGFuIGFycmF5LlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgc2NoZW1hIHRyYW5zZm9ybWF0aW9uIGNvZGUuXG4gKiBAcGFyYW0gc2NoZW1hc1JhdyAtIFJhdyBzY2hlbWFzIGZyb20gZ2V0RGV2aWNlU2NoZW1hcygpXG4gKiBAcmV0dXJucyBOb3JtYWxpemVkIHNjaGVtYXMgd2l0aCBndWFyYW50ZWVkIGNtZFNjaGVtYSBhcnJheXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldE5vcm1hbGl6ZWRTY2hlbWFzKFxuXHRzY2hlbWFzUmF3OiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuKTogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+IHtcblx0Y29uc3Qgbm9ybWFsaXplZDogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+ID0ge31cblx0Zm9yIChjb25zdCBbbW9kZWwsIGpzb25dIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXNSYXcpKSB7XG5cdFx0bm9ybWFsaXplZFttb2RlbF0gPSB7XG5cdFx0XHRtb2RlbDoganNvbi5tb2RlbCxcblx0XHRcdGNtZFNjaGVtYTogQXJyYXkuaXNBcnJheShqc29uLmNtZFNjaGVtYSkgPyBqc29uLmNtZFNjaGVtYSA6IFtdLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4gbm9ybWFsaXplZFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQWN0aW9uIExvb2t1cCBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIEZpbmRzIGFuIGFjdGlvbi9zZXR0aW5nIGluIHRoZSBzY2hlbWEsIHN1cHBvcnRpbmcgYm90aCBleGFjdCBtYXRjaGVzIGFuZCBpZEFkZCBvZmZzZXRzLlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgYWN0aW9uIGxvb2t1cCBsb2dpYyBhY3Jvc3MgbXVsdGlwbGUgZmlsZXMuXG4gKiBAcGFyYW0gc2NoZW1hcyAtIE5vcm1hbGl6ZWQgZGV2aWNlIHNjaGVtYXNcbiAqIEBwYXJhbSBtb2RlbCAtIERldmljZSBtb2RlbCAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBjbWRJZCAtIENvbW1hbmQgSURcbiAqIEBwYXJhbSBzZXR0aW5nSWQgLSBTZXR0aW5nIElEIChtYXkgaW5jbHVkZSBpZEFkZCBvZmZzZXQpXG4gKiBAcmV0dXJucyBNYXRjaGluZyBhY3Rpb24vc2V0dGluZyBvciB1bmRlZmluZWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmRBY3Rpb25Gb3JTZXR0aW5nKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0aWYgKCFzY2hlbWEgfHwgIUFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkpIHJldHVybiB1bmRlZmluZWRcblxuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IHNjaGVtYS5jbWRTY2hlbWEuZmluZCgoczogYW55KSA9PiBzLmNtZF9pZCA9PT0gY21kSWQgJiYgcy5pZCA9PT0gc2V0dGluZ0lkKVxuXG5cdC8vIElmIG5vIGV4YWN0IG1hdGNoLCB0cnkgdG8gZmluZCBiYXNlIGFjdGlvbiB3aXRoIGlkQWRkXG5cdGlmICghYWN0aW9uKSB7XG5cdFx0YWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHtcblx0XHRcdGlmIChzLmNtZF9pZCAhPT0gY21kSWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBzLm9wdGlvbnM/LmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHNldHRpbmdJZCBtYXRjaGVzIGJhc2UgKyBhbnkgaWRBZGQgb2Zmc2V0XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBzZXR0aW5nSWQgLSBzLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvblxufVxuIiwgIi8qKlxuICogYnVpbGQtY29tbWFuZHMudHNcbiAqIC0gVXNlcyBjZW50cmFsaXplZCBkZXZpY2Ugc2NoZW1hIGNhY2hlIGZyb20gY29uZmlnLnRzXG4gKiAtIFByb2R1Y2VzIENvbXBhbmlvbiBhY3Rpb24gZGVmaW5pdGlvbnMgYW5kIGZlZWRiYWNrc1xuICovXG5cbmltcG9ydCB7XG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zLFxuXHRDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uLFxuXHRDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgbWFrZVNldHRpbmdJZCB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0gT3B0aW9uIEJ1aWxkZXIgLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZnVuY3Rpb24gYnVpbGRPcHRpb24obzogYW55KTogYW55IHtcblx0Y29uc3QgYmFzZSA9IHtcblx0XHR0eXBlOiBvLnR5cGUsXG5cdFx0aWQ6IG8uaWQsXG5cdFx0bGFiZWw6IG8ubGFiZWwsXG5cdFx0ZGVmYXVsdDogby5kZWZhdWx0LFxuXHRcdHRvb2x0aXA6IG8udG9vbHRpcCxcblx0fVxuXG5cdHN3aXRjaCAoby50eXBlKSB7XG5cdFx0Y2FzZSAnZHJvcGRvd24nOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgY2hvaWNlczogby5jaG9pY2VzID8/IFtdIH1cblxuXHRcdGNhc2UgJ251bWJlcic6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5iYXNlLFxuXHRcdFx0XHRtaW46IG8ubWluLFxuXHRcdFx0XHRtYXg6IG8ubWF4LFxuXHRcdFx0XHRzdGVwOiBvLnN0ZXAgPz8gMSxcblx0XHRcdFx0cmFuZ2U6IHRydWUsXG5cdFx0XHR9XG5cblx0XHRjYXNlICdjaGVja2JveCc6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBkZWZhdWx0OiBvLmRlZmF1bHQgPz8gZmFsc2UgfVxuXG5cdFx0Y2FzZSAnc3RhdGljLXRleHQnOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgdmFsdWU6IG8udmFsdWUgPz8gJycgfVxuXG5cdFx0Y2FzZSAndGV4dGlucHV0Jzpcblx0XHRjYXNlICdjb2xvcnBpY2tlcic6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIGEuY21kX2lkLCBhLmlkKVxuXG5cdFx0XHRjb25zdCBvcHRpb25zID0gKGEub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHRjb25zdCBhY3Rpb246IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHthLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVBY3Rpb25zICovXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGFjdGlvbnNbYWN0aW9uSWRdID0gYWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvbnNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBGZWVkYmFja3MgLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGZWVkYmFja3MoKTogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgZmVlZGJhY2tzOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3Qgc2V0dGluZyBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0lkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgc2V0dGluZy5jbWRfaWQsIHNldHRpbmcuaWQpXG5cblx0XHRcdC8vIEJ1aWxkIG9wdGlvbnNcblx0XHRcdGNvbnN0IGFsbE9wdGlvbnMgPSAoc2V0dGluZy5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdC8vIEZpbHRlciBvdXQgJ3ZhbHVlJyBvcHRpb24gZm9yIHZhbHVlIGZlZWRiYWNrIChrZWVwIG9ubHkgYnVzQ2gvaWRBZGQpXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbnMgPSBhbGxPcHRpb25zLmZpbHRlcigob3B0OiBhbnkpID0+IG9wdC5pZCAhPT0gJ3ZhbHVlJylcblxuXHRcdFx0Ly8gQWRkIGEgY2hlY2tib3ggb3B0aW9uIHRvIHJldHVybiBsYWJlbCBpbnN0ZWFkIG9mIHZhbHVlXG5cdFx0XHR2YWx1ZU9wdGlvbnMucHVzaCh7XG5cdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0bGFiZWw6ICdTaG93IExhYmVsJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHR9KVxuXG5cdFx0XHQvLyBWYWx1ZSBmZWVkYmFjayBmb3IgYWxsIHNldHRpbmdzIChhcHBlYXJzIGluIFZhcmlhYmxlcyBsaXN0KVxuXHRcdFx0Y29uc3QgdmFsdWVGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHR0eXBlOiAndmFsdWUnLFxuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnM6IHZhbHVlT3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRyZXR1cm4gMFxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRmZWVkYmFja3NbYmFzZUZlZWRiYWNrSWRdID0gdmFsdWVGZWVkYmFja1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IGdldERldmljZXNGb2xkZXIsIGdldERldmljZVNjaGVtYSwgZ2V0RGV2aWNlU2NoZW1hcywgcmVsb2FkRGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuXG5pbXBvcnQgeyBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbiwgc2F2ZU1vZGVsSnNvblByZXR0eSwgdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzIH0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdBY3Rpb25zJylcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUFjdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdBY3Rpb25zID0gYnVpbGRBY3Rpb25zKClcblx0Y29uc3Qgc2NoZW1hcyA9IGdldE5vcm1hbGl6ZWRTY2hlbWFzKHNjaGVtYXNSYXcpXG5cdGNvbnN0IHdpcmVkQWN0aW9uczogYW55ID0ge31cblxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEdMT0JBTDogR0VUIEFMTCBTRVRUSU5HUyAoQVVUTyBKU09OIFVQREFURSlcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0d2lyZWRBY3Rpb25zWydnbG9iYWxfZ2V0QWxsU2V0dGluZ3MnXSA9IHtcblx0XHRuYW1lOiAnR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzIChBdXRvLVVwZGF0ZSBKU09OKScsXG5cdFx0b3B0aW9uczogW10sXG5cdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdGNvbnN0IG1vZGVsID0gYWN0aXZlTW9kZWxcblx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cblx0XHRcdGNvbnN0IGJ1ZiA9IGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIHRvIGdldCB0aGUgc2NoZW1hIChtYXkgYmUgbnVsbCBmb3IgbmV3L3Vua25vd24gZGV2aWNlcylcblx0XHRcdGxldCBtb2RlbEpzb24gPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cblx0XHRcdC8vIFBhcnNlIHdpdGggYXV0by1kZXRlY3Rpb25cblx0XHRcdGNvbnN0IHsgc2V0dGluZ3M6IHBhcnNlZCwgZGV0ZWN0ZWRTZWN0aW9uZWQgfSA9IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uKG1vZGVsLCBidWYpXG5cdFx0XHRsb2dnZXIuZGVidWcoYHBhcnNlZCByZXBseTogJHtKU09OLnN0cmluZ2lmeShwYXJzZWQpfWApXG5cblx0XHRcdGlmICghbW9kZWxKc29uKSB7XG5cdFx0XHRcdC8vIE5vIHNjaGVtYSB5ZXQgXHUyMDE0IGNyZWF0ZSBhIG1pbmltYWwgb25lIGZyb20gdGhlIHBhcnNlZCBzZXR0aW5nc1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gaGFzIG5vIHNjaGVtYSBcdTIwMTQgY3JlYXRpbmcgbmV3IEpTT04gZnJvbSBzZXR0aW5nc2ApXG5cdFx0XHRcdG1vZGVsSnNvbiA9IHtcblx0XHRcdFx0XHRtb2RlbCxcblx0XHRcdFx0XHRzZWN0aW9uZWQ6IGRldGVjdGVkU2VjdGlvbmVkID8/IGZhbHNlLFxuXHRcdFx0XHRcdHJlZnJlc2hBZnRlckNvbW1hbmQ6IHRydWUsXG5cdFx0XHRcdFx0Y21kU2NoZW1hOiBbXSxcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIGlmIChkZXRlY3RlZFNlY3Rpb25lZCAhPT0gbnVsbCkge1xuXHRcdFx0XHQvLyBJZiB3ZSBhdXRvLWRldGVjdGVkIHRoZSBmb3JtYXQsIGFkZCBpdCB0byB0aGUgSlNPTlxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBzZWN0aW9uZWQ9JHtkZXRlY3RlZFNlY3Rpb25lZH0sIGFkZGluZyB0byBtb2RlbCBKU09OYClcblx0XHRcdFx0bW9kZWxKc29uID0geyAuLi5tb2RlbEpzb24sIHNlY3Rpb25lZDogZGV0ZWN0ZWRTZWN0aW9uZWQgfVxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCB1cGRhdGVkID0gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKG1vZGVsSnNvbiwgcGFyc2VkLCBzY2hlbWFzKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBuZXcgQWN0aW9ucyBqc29uOiAke0pTT04uc3RyaW5naWZ5KHVwZGF0ZWQsIG51bGwsIDIpfWApXG5cblx0XHRcdC8vIFNhdmUgdGhlIHVwZGF0ZWQgSlNPTiB0byBkaXNrXG5cdFx0XHRjb25zdCBkZXZpY2VzRm9sZGVyID0gZ2V0RGV2aWNlc0ZvbGRlcigpXG5cdFx0XHRjb25zdCBzY2hlbWFQYXRoID0gcGF0aC5qb2luKGRldmljZXNGb2xkZXIsIGBNb2RlbCR7bW9kZWx9Lmpzb25gKVxuXHRcdFx0c2F2ZU1vZGVsSnNvblByZXR0eShzY2hlbWFQYXRoLCB1cGRhdGVkKVxuXG5cdFx0XHQvLyBSZWxvYWQgdGhlIGNhY2hlIGFmdGVyIHdyaXRpbmcgdG8gZmlsZVxuXHRcdFx0cmVsb2FkRGV2aWNlU2NoZW1hcygpXG5cblx0XHRcdGxvZ2dlci5pbmZvKGBNb2RlbCAke21vZGVsfSBKU09OIGF1dG8tdXBkYXRlZCBmcm9tIGdldEFsbFNldHRpbmdzYClcblx0XHR9LFxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBCVUlMRCBQRVItU0VUVElORyBBQ1RJT05TIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2FjdGlvbklkLCBhY3Rpb25dIG9mIE9iamVjdC5lbnRyaWVzKHJhd0FjdGlvbnMpKSB7XG5cdFx0Y29uc3QgeyBtb2RlbCwgY21kSWQsIGJhc2VJZCB9ID0gcGFyc2VTZXR0aW5nSWQoYWN0aW9uSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgYWN0aW9ucyBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgbW9kZWxcblx0XHRpZiAobW9kZWwgIT09IGFjdGl2ZU1vZGVsKSBjb250aW51ZVxuXG5cdFx0Ly8gR2V0IHRoZSByYXcgYWN0aW9uIHNjaGVtYSB0byBhY2Nlc3MgZml4ZWQgYnVzQ2ggdmFsdWVcblx0XHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRcdGNvbnN0IHJhd0FjdGlvbiA9IHNjaGVtYT8uY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBiYXNlSWQpXG5cblx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0Li4uYWN0aW9uLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jIChldmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSAhPT0gdW5kZWZpbmVkID8gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSA6IHJhd0FjdGlvbj8uYnVzQ2hcblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBldmVudC5vcHRpb25zWyd2YWx1ZSddXG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cblx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIuc2VuZEF3YWl0QWNrKGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgaXApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgTUlDIEtJTEwgKE9OTFkgSUYgQUNUSVZFIE1PREVMIFNVUFBPUlRTIElUKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Y29uc3QgYWN0aXZlU2NoZW1hID0gc2NoZW1hc1thY3RpdmVNb2RlbF1cblx0aWYgKGFjdGl2ZVNjaGVtYSkge1xuXHRcdGNvbnN0IHN1cHBvcnRzTWljS2lsbCA9IChhY3RpdmVTY2hlbWEuY21kU2NoZW1hID8/IFtdKS5zb21lKChhOiBhbnkpID0+IGEubmFtZS5pbmNsdWRlcygnS2lsbCcpKVxuXG5cdFx0aWYgKHN1cHBvcnRzTWljS2lsbCkge1xuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBgJHthY3RpdmVNb2RlbH1fbWljS2lsbGBcblxuXHRcdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7YWN0aXZlTW9kZWx9XSBNaWMgS2lsbGAsXG5cdFx0XHRcdG9wdGlvbnM6IFtdLFxuXHRcdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYE1pYyBLaWxsIFx1MjE5MiBNb2RlbCAke2FjdGl2ZU1vZGVsfSBAICR7aXB9YClcblx0XHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5nbG9iYWxNaWNLaWxsKGlwKVxuXHRcdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcCkuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byByZWZyZXNoIHNldHRpbmdzIGFmdGVyIGNvbW1hbmQ6ICR7ZXJyfWApXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSxcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEFjdGlvbkRlZmluaXRpb25zKHdpcmVkQWN0aW9ucylcblxuXHQvL2NvbnNvbGUubG9nKCdBY3Rpb25zOlxcbicsIEpTT04uc3RyaW5naWZ5KHdpcmVkQWN0aW9ucywgbnVsbCwgMikpXG59XG4iLCAiaW1wb3J0IGZzIGZyb20gJ2ZzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHtcblx0Q01EX01JQ19QUkUsXG5cdENNRF9CVVNfU0VULFxuXHRDTURfQ0hBTk5FTCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdGZvcm1hdFJnYkNvbG9yLFxuXHRtb2RlbERpc3RhbmNlLFxufSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1NldHRpbmdzUGFyc2VyJylcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVFlQRVNcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IHR5cGUgUGFyc2VkU2V0dGluZyA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRidXNDaD86IG51bWJlciAvLyBPcHRpb25hbDogb25seSBwcmVzZW50IGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoICgweDA0LCAweDEyLCAweDE0KVxuXHR2YWx1ZUJ5dGVzOiBudW1iZXJbXVxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbk9wdGlvbiA9IHtcblx0aWQ/OiBzdHJpbmdcblx0bGFiZWw6IHN0cmluZ1xuXHR0eXBlOiBzdHJpbmdcblx0ZGVmYXVsdDogdW5rbm93blxuXHR0b29sdGlwPzogc3RyaW5nXG5cdGNob2ljZXM/OiBBcnJheTx7IGlkOiBudW1iZXI7IGxhYmVsOiBzdHJpbmcgfT5cbn1cblxuZXhwb3J0IHR5cGUgU3RBY3Rpb24gPSB7XG5cdGNtZF9pZDogbnVtYmVyXG5cdGlkOiBudW1iZXJcblx0bmFtZTogc3RyaW5nXG5cdG9wdGlvbnM6IFN0QWN0aW9uT3B0aW9uW11cblx0YnVzQ2g/OiBudW1iZXIgLy8gRml4ZWQgY2hhbm5lbCB2YWx1ZSBmb3IgYWN0aW9ucyB0aGF0IGRvbid0IGhhdmUgYSBjaGFubmVsIG9wdGlvblxufVxuXG5leHBvcnQgdHlwZSBTdE1vZGVsSnNvbiA9IHtcblx0bW9kZWw6IHN0cmluZ1xuXHRzZWN0aW9uZWQ/OiBib29sZWFuXG5cdHJlZnJlc2hBZnRlckNvbW1hbmQ/OiBib29sZWFuXG5cdGNtZFNjaGVtYTogU3RBY3Rpb25bXVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGT1JNQVQgSEVMUEVSU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBnZXRNb2RlbENvbmZpZyhtb2RlbDogc3RyaW5nKTogeyBzZWN0aW9uZWQ6IGJvb2xlYW47IHJnYklkczogU2V0PG51bWJlcj4gfSB7XG5cdGNvbnN0IHJnYklkcyA9IG5ldyBTZXQ8bnVtYmVyPigpXG5cdGxldCBzZWN0aW9uZWQgPSBmYWxzZVxuXG5cdHRyeSB7XG5cdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIGluc3RlYWQgb2YgcmVhZGluZyBmcm9tIGRpc2tcblx0XHRjb25zdCBqc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghanNvbikge1xuXHRcdFx0Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgc2NoZW1hLCByZXR1cm4gZGVmYXVsdHNcblx0XHRcdHJldHVybiB7IHNlY3Rpb25lZCwgcmdiSWRzIH1cblx0XHR9XG5cblx0XHQvLyBSZWFkIHNlY3Rpb25lZCBwcm9wZXJ0eSAoZGVmYXVsdCB0byBmYWxzZSBpZiBub3Qgc3BlY2lmaWVkKVxuXHRcdHNlY3Rpb25lZCA9IGpzb24uc2VjdGlvbmVkID8/IGZhbHNlXG5cblx0XHQvLyBCdWlsZCBSR0IgSURzIHNldFxuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHQvLyBBZGQgdGhlIGJhc2UgSURcblx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQpXG5cblx0XHRcdFx0Ly8gSWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkIGNob2ljZXMsIGFkZCBhbGwgdGhlIG9mZnNldCBJRHMgdG9vXG5cdFx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjaG9pY2Ugb2YgaWRBZGRPcHRpb24uY2hvaWNlcykge1xuXHRcdFx0XHRcdFx0aWYgKHR5cGVvZiBjaG9pY2UuaWQgPT09ICdudW1iZXInKSB7XG5cdFx0XHRcdFx0XHRcdHJnYklkcy5hZGQoYWN0aW9uLmlkICsgY2hvaWNlLmlkKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCAoX2Vycikge1xuXHRcdC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHNjaGVtYSwgcmV0dXJuIGRlZmF1bHRzXG5cdH1cblxuXHRyZXR1cm4geyBzZWN0aW9uZWQsIHJnYklkcyB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZJTkQgVEhFIFJFQUwgNUEgUEFZTE9BRCBJTkRFWFxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmOiBCdWZmZXIpOiBudW1iZXIge1xuXHRjb25zdCBzaWdJbmRleCA9IGJ1Zi5pbmRleE9mKEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcpKVxuXHRpZiAoc2lnSW5kZXggPCAwKSB0aHJvdyBuZXcgRXJyb3IoJ05vIFN0dWRpby1UIHNpZ25hdHVyZSBpbiBwYWNrZXQnKVxuXG5cdGNvbnN0IHBheWxvYWRJbmRleCA9IHNpZ0luZGV4ICsgOFxuXHRpZiAoYnVmW3BheWxvYWRJbmRleF0gIT09IDB4NWEpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIDB4NUEgYWZ0ZXIgU3R1ZGlvLVQsIGZvdW5kICR7YnVmW3BheWxvYWRJbmRleF0udG9TdHJpbmcoMTYpfWApXG5cdH1cblxuXHRyZXR1cm4gcGF5bG9hZEluZGV4XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZMQVQgUEFSU0VSXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYmxvY2s6IEJ1ZmZlciwgcmdiSWRzOiBTZXQ8bnVtYmVyPiA9IG5ldyBTZXQoKSk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGxldCBwID0gMFxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0d2hpbGUgKHAgPCBibG9jay5sZW5ndGgpIHtcblx0XHRjb25zdCBpZCA9IGJsb2NrW3BdXG5cdFx0aWYgKHAgKyAxID49IGJsb2NrLmxlbmd0aCkgYnJlYWtcblxuXHRcdC8vIFJHQiBjYXNlIC0gY2hlY2sgaWYgdGhpcyBJRCBpcyBhIGtub3duIGNvbG9ycGlja2VyXG5cdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHAgKyAzIDwgYmxvY2subGVuZ3RoKSB7XG5cdFx0XHRvdXQucHVzaCh7XG5cdFx0XHRcdGNtZF9pZDogQ01EX0RFVl9TUEVDLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXSwgYmxvY2tbcCArIDJdLCBibG9ja1twICsgM11dLFxuXHRcdFx0fSlcblx0XHRcdHAgKz0gNFxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHRvdXQucHVzaCh7IGNtZF9pZDogQ01EX0RFVl9TUEVDLCBpZCwgdmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXV0gfSlcblx0XHRwICs9IDJcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Y29uc3QgYmxvY2tMZW4gPSBidWZbaWR4ICsgMl1cblx0Y29uc3Qgc3RhcnQgPSBpZHggKyAzXG5cdGNvbnN0IGVuZCA9IHN0YXJ0ICsgYmxvY2tMZW5cblx0aWYgKGVuZCA+IGJ1Zi5sZW5ndGgpIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBibG9jayBsZW5ndGgnKVxuXG5cdGNvbnN0IHsgcmdiSWRzIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYnVmLnN1YmFycmF5KHN0YXJ0LCBlbmQpLCByZ2JJZHMpXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNFQ1RJT05FRCBQQVJTRVJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZjogQnVmZmVyLCBtb2RlbDogc3RyaW5nKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgYSBnZXRBbGxTZXR0aW5ncyByZXBseScpXG5cdH1cblxuXHQvLyBDTURfR0VUX0FMTF9TRVRUSU5HUyBoYXMgYSB0b3RhbC1sZW5ndGggYnl0ZSBhdCBpZHgrMiBiZWZvcmUgdGhlIHNlY3Rpb25zOyBDTURfU0VUVElOR1NfUFVTSCBkb2VzIG5vdC5cblx0bGV0IHAgPSBjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgPyBpZHggKyAzIDogaWR4ICsgMlxuXHRjb25zdCBlbmQgPSBidWYubGVuZ3RoIC0gMVxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0Ly8gR2V0IFJHQiBJRHMgZm9yIHRoaXMgbW9kZWxcblx0Y29uc3QgeyByZ2JJZHMgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgaW4gdGhlaXIgc2VjdGlvbiBzdHJ1Y3R1cmUsXG5cdC8vIGZvbGxvd2VkIGJ5IGEgZGF0YUxlbiBieXRlIGFuZCB0aGVuIGlkOnZhbCBwYWlycy5cblx0Y29uc3QgY29tbWFuZHNXaXRoQnVzQ2ggPSBbQ01EX0JVU19TRVQsIENNRF9NSUNfUFJFX0JVUywgQ01EX0NIQU5ORUxdXG5cblx0Ly8gQ29tbWFuZCBJRHMgdGhhdCBpbmNsdWRlIGEgYnVzQ2ggYnl0ZSBidXQgc3RvcmUgcmF3IHBvc2l0aW9uYWwgdmFsdWUgYnl0ZXNcblx0Ly8gcmF0aGVyIHRoYW4gaWQ6dmFsIHBhaXJzIChubyBkYXRhTGVuIGJ5dGUsIG5vIHNldHRpbmcgSURzKS5cblx0Ly8gRm9ybWF0OiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW3ZhbDBdIFt2YWwxXSAuLi5cblx0Y29uc3QgY29tbWFuZHNSYXdWYWx1ZSA9IFtDTURfTUlDX1BSRV0gLy8gY21kPTB4MDJcblxuXHR3aGlsZSAocCArIDIgPCBlbmQpIHtcblx0XHRjb25zdCBjbWRMZW4gPSBidWZbcF1cblx0XHRjb25zdCBzZWN0aW9uQ21kSWQgPSBidWZbcCArIDFdXG5cblx0XHRjb25zdCBzZWN0aW9uRW5kID0gcCArIDEgKyBjbWRMZW5cblx0XHRpZiAoc2VjdGlvbkVuZCA+IGVuZCkgYnJlYWtcblxuXHRcdGNvbnN0IGhhc0J1c0NoID0gY29tbWFuZHNXaXRoQnVzQ2guaW5jbHVkZXMoc2VjdGlvbkNtZElkKVxuXHRcdGNvbnN0IGlzUmF3VmFsdWUgPSBjb21tYW5kc1Jhd1ZhbHVlLmluY2x1ZGVzKHNlY3Rpb25DbWRJZClcblxuXHRcdGxldCBidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkXG5cdFx0bGV0IGRhdGFMZW46IG51bWJlclxuXHRcdGxldCBxOiBudW1iZXJcblxuXHRcdGlmIChpc1Jhd1ZhbHVlKSB7XG5cdFx0XHQvLyBTdHJ1Y3R1cmU6IFtjbWRMZW5dIFtjbWRJZF0gW2J1c0NoXSBbdmFsMF0gW3ZhbDFdIC4uLlxuXHRcdFx0Ly8gRW1pdCBlYWNoIHZhbHVlIGJ5dGUgYXMgYSBzZXBhcmF0ZSBQYXJzZWRTZXR0aW5nIHdpdGggcG9zaXRpb25hbCBpZC5cblx0XHRcdC8vIENNRF9NSUNfUFJFICgweDAyKSBwb3NpdGlvbmFsIHNsb3RzIGFyZSByZW1hcHBlZCB0byBDTURfTUlDX1BSRV9CVVMgKDB4MTIpXG5cdFx0XHQvLyBpZDp2YWwgZm9ybWF0IHNvIHRoYXQgc3RhdGUga2V5cyBtYXRjaCB0aGUgU0VUIGNvbW1hbmQgc3RydWN0dXJlIHVzZWQgYnlcblx0XHRcdC8vIGZlZWRiYWNrcyBhbmQgYWN0aW9ucy4gTWFwcGluZzogcG9zMFx1MjE5MmlkMSAoZ2FpbiksIHBvczFcdTIxOTJpZDIgKHBoYW50b20vZWxlY3RyZXQpLFxuXHRcdFx0Ly8gcG9zMisgYXJlIHVua25vd24vdW51c2VkIGFuZCBkcm9wcGVkLlxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRjb25zdCByYXdCeXRlcyA9IGJ1Zi5zdWJhcnJheShwICsgMywgc2VjdGlvbkVuZClcblx0XHRcdGNvbnN0IG1pY1ByZVJlbWFwOiBBcnJheTxudW1iZXIgfCBudWxsPiA9IFsxLCAyXSAvLyBwb3MwXHUyMTkyaWQxLCBwb3MxXHUyMTkyaWQyLCBwb3MyK1x1MjE5MmRyb3Bcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgcmF3Qnl0ZXMubGVuZ3RoOyBpKyspIHtcblx0XHRcdFx0aWYgKHNlY3Rpb25DbWRJZCA9PT0gQ01EX01JQ19QUkUpIHtcblx0XHRcdFx0XHRjb25zdCByZW1hcHBlZElkID0gaSA8IG1pY1ByZVJlbWFwLmxlbmd0aCA/IG1pY1ByZVJlbWFwW2ldIDogbnVsbFxuXHRcdFx0XHRcdGlmIChyZW1hcHBlZElkICE9PSBudWxsKSB7XG5cdFx0XHRcdFx0XHRvdXQucHVzaCh7IGNtZF9pZDogQ01EX01JQ19QUkVfQlVTLCBpZDogcmVtYXBwZWRJZCwgYnVzQ2gsIHZhbHVlQnl0ZXM6IFtyYXdCeXRlc1tpXV0gfSlcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0b3V0LnB1c2goeyBjbWRfaWQ6IHNlY3Rpb25DbWRJZCwgaWQ6IGksIGJ1c0NoLCB2YWx1ZUJ5dGVzOiBbcmF3Qnl0ZXNbaV1dIH0pXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHAgPSBzZWN0aW9uRW5kXG5cdFx0XHRjb250aW51ZVxuXHRcdH0gZWxzZSBpZiAoaGFzQnVzQ2gpIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRkYXRhTGVuID0gYnVmW3AgKyAzXVxuXHRcdFx0cSA9IHAgKyA0XG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbZGF0YUxlbl0gW2lkOnZhbCBwYWlyc11cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDJdXG5cdFx0XHRxID0gcCArIDNcblx0XHR9XG5cblx0XHRjb25zdCBxRW5kID0gcSArIGRhdGFMZW5cblx0XHRjb25zdCBxU3RhcnQgPSBxXG5cblx0XHR3aGlsZSAocSArIDEgPCBxRW5kKSB7XG5cdFx0XHRjb25zdCBpZCA9IGJ1ZltxXVxuXHRcdFx0bGV0IHZhbHVlQnl0ZXM6IG51bWJlcltdXG5cblx0XHRcdC8vIENoZWNrIGlmIHRoaXMgSUQgaXMgYW4gUkdCIGNvbG9ycGlja2VyIChuZWVkcyAzIGJ5dGVzKVxuXHRcdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHEgKyAzIDwgcUVuZCkge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV0sIGJ1ZltxICsgMl0sIGJ1ZltxICsgM11dXG5cdFx0XHRcdHEgKz0gNFxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0dmFsdWVCeXRlcyA9IFtidWZbcSArIDFdXVxuXHRcdFx0XHRxICs9IDJcblx0XHRcdH1cblxuXHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHtcblx0XHRcdFx0Y21kX2lkOiBzZWN0aW9uQ21kSWQsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHR2YWx1ZUJ5dGVzLFxuXHRcdFx0fVxuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0c2V0dGluZy5idXNDaCA9IGJ1c0NoXG5cdFx0XHR9XG5cdFx0XHRvdXQucHVzaChzZXR0aW5nKVxuXHRcdH1cblxuXHRcdC8vIFBvc2l0aW9uYWwgZmFsbGJhY2s6IGlmIHRoZSBieXRlIHdlIHJlYWQgYXMgZGF0YUxlbiB3YXMgMHgwMCBidXQgdGhlIHNlY3Rpb25cblx0XHQvLyBzdGlsbCBjb250YWlucyBkYXRhIGJ5dGVzLCB0aGlzIHNlY3Rpb24gbGlrZWx5IHVzZXMgYSBuby1kYXRhTGVuIGZvcm1hdCB3aGVyZVxuXHRcdC8vIGVhY2ggYnl0ZSBhZnRlciBjbWRJZCBpcyBhIHJhdyB2YWx1ZSBhdCBhIGZpeGVkIHBvc2l0aW9uIChwb3NpdGlvbiA9IGlkKS5cblx0XHQvLyBSZS1wYXJzZSBmcm9tIHArMiAocmlnaHQgYWZ0ZXIgY21kSWQpLCB0cmVhdGluZyB0aGUgXCJkYXRhTGVuXCIgYnl0ZSBhcyBpZD0wLlxuXHRcdC8vIE9ubHkgZmlyZSBpZiBubyBieXRlcyB3ZXJlIGNvbnN1bWVkIGJ5IHRoZSBtYWluIGxvb3AgKHEgPT09IHFTdGFydCksIHRvIGF2b2lkXG5cdFx0Ly8gcmUtcGFyc2luZyBieXRlcyB0aGF0IHdlcmUgYWxyZWFkeSBzdWNjZXNzZnVsbHkgcGFyc2VkLlxuXHRcdGlmIChxID09PSBxU3RhcnQgJiYgc2VjdGlvbkVuZCA+IHAgKyAzKSB7XG5cdFx0XHRsZXQgcG9zID0gaGFzQnVzQ2ggPyBwICsgMyA6IHAgKyAyIC8vIHNraXAgY21kSWQgKGFuZCBidXNDaCBpZiBwcmVzZW50KVxuXHRcdFx0bGV0IHBvc0lkID0gMFxuXHRcdFx0d2hpbGUgKHBvcyA8IHNlY3Rpb25FbmQpIHtcblx0XHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHsgY21kX2lkOiBzZWN0aW9uQ21kSWQsIGlkOiBwb3NJZCsrLCB2YWx1ZUJ5dGVzOiBbYnVmW3BvcysrXV0gfVxuXHRcdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgc2V0dGluZy5idXNDaCA9IGJ1c0NoXG5cdFx0XHRcdG91dC5wdXNoKHNldHRpbmcpXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cCA9IHNlY3Rpb25FbmRcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgR0VORVJJQyBTRVRUSU5HUyBSRVNQT05TRSBQQVJTRVIgKDB4MGEgZ2V0LWFsbCArIDB4MGIgdW5zb2xpY2l0ZWQgcHVzaClcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBQYXJzZXMgYW55IGZ1bGwgc2V0dGluZ3MgYmxvY2sgcmVnYXJkbGVzcyBvZiB3aGV0aGVyIHRoZSBjbWRJZCBpcyAweDBhXG4gKiAocmVzcG9uc2UgdG8gR2V0IEFsbCBTZXR0aW5ncykgb3IgMHgwYiAodW5zb2xpY2l0ZWQgcHVzaCBhZnRlciBhIHNldCkuXG4gKiBCb3RoIHVzZSB0aGUgc2FtZSBzZWN0aW9uZWQgb3IgZmxhdCBibG9jayBsYXlvdXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdzUmVzcG9uc2UobW9kZWw6IHN0cmluZywgYnVmOiBCdWZmZXIpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYE5vdCBhIHNldHRpbmdzIGJsb2NrIChjbWRJZD0weCR7Y21kSWQudG9TdHJpbmcoMTYpfSlgKVxuXHR9XG5cdGNvbnN0IHsgc2VjdGlvbmVkIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHNlY3Rpb25lZCA/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpIDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG59XG5cbi8qKlxuICogRm9ybWF0cyBhIHNpbmdsZSBwYXJzZWQgc2V0dGluZyBpbnRvIGEgaHVtYW4tcmVhZGFibGUgc3RyaW5nIHVzaW5nIGFjdGlvblxuICogZGVmaW5pdGlvbnMgZnJvbSB0aGUgZGV2aWNlIEpTT04uIEZhbGxzIGJhY2sgdG8gaGV4IElEcyB3aGVuIHVua25vd24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmc6IFBhcnNlZFNldHRpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiBzdHJpbmcge1xuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IHNldHRpbmcuY21kX2lkICYmIGEuaWQgPT09IHNldHRpbmcuaWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2ggYW5kIGlkID4gYmFzZSBpZCwgdHJ5IHRvIGZpbmQgYWN0aW9uIHdpdGggaWRBZGQgb3B0aW9uXG5cdC8vIFRoaXMgaGFuZGxlcyBjYXNlcyBsaWtlIENNRF9IRUFEUEhPTkUgKDB4MDUsIGUuZy4gUGhvbmVzIFJvdXRpbmcpIGFuZFxuXHQvLyBDTURfQlVUVE9OX01PREUgKDB4MDcsIGUuZy4gQnV0dG9ucykgd2hlcmUgaWQgMC0zIHJlcHJlc2VudHMgY2hhbm5lbHMgMS00XG5cdGlmICghYWN0aW9uKSB7XG5cdFx0Y29uc3QgYmFzZUFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBzZXR0aW5nLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIGFjdGlvbiBoYXMgYW4gaWRBZGQgb3B0aW9uIChpbmRpY2F0aW5nIGNoYW5uZWwgc2VsZWN0aW9uKVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGUgc2V0dGluZy5pZCBvZmZzZXQgbWF0Y2hlcyBvbmUgb2YgdGhlIGlkQWRkIGNob2ljZSBJRHNcblx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYS5pZFxuXHRcdFx0cmV0dXJuIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHR9KVxuXHRcdGlmIChiYXNlQWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSBiYXNlQWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0Y29uc3QgY21kSGV4ID0gdG9IZXgoc2V0dGluZy5jbWRfaWQpXG5cdGNvbnN0IGlkSGV4ID0gdG9IZXgoc2V0dGluZy5pZClcblx0Y29uc3QgdmFsSGV4ID0gYnl0ZXNUb0hleChzZXR0aW5nLnZhbHVlQnl0ZXMpXG5cdGNvbnN0IHZhbERlYyA9XG5cdFx0c2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0PyBmb3JtYXRSZ2JDb2xvcihzZXR0aW5nLnZhbHVlQnl0ZXNbMF0sIHNldHRpbmcudmFsdWVCeXRlc1sxXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzJdKVxuXHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxXG5cdFx0XHRcdD8gc2V0dGluZy52YWx1ZUJ5dGVzWzBdXG5cdFx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmpvaW4oJywnKVxuXG5cdC8vIEJ1aWxkIHRoZSBwcmVmaXg6IGNtZDoweDEyIGNoOjAgaWQ6MHgwMSB2YWw6MHgxNCAoY2ggb25seSBmb3IgY29tbWFuZHMgd2l0aCBidXNDaClcblx0Y29uc3QgYnVzQ2hTdHIgPSBzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQgPyBgIGNoOiR7c2V0dGluZy5idXNDaH1gIDogJydcblx0Y29uc3QgcHJlZml4ID0gYGNtZDoke2NtZEhleH0ke2J1c0NoU3RyfSBpZDoke2lkSGV4fSB2YWw6JHt2YWxIZXh9YFxuXG5cdC8vIElmIHdlIGhhdmUgYW4gYWN0aW9uIHdpdGggYSBuYW1lIGFuZCBjaG9pY2UgbGFiZWwsIHVzZSBpdFxuXHRpZiAoYWN0aW9uKSB7XG5cdFx0bGV0IG5hbWUgPSBhY3Rpb24ubmFtZVxuXG5cdFx0Ly8gSWYgc2V0dGluZyBoYXMgYnVzQ2gsIGFkZCBjaGFubmVsIGluZm8gdG8gbmFtZVxuXHRcdGlmIChzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdG5hbWUgPSBgJHtuYW1lfSBDaCR7c2V0dGluZy5idXNDaCArIDF9YFxuXHRcdH1cblx0XHQvLyBPdGhlcndpc2UsIGlmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCwgaW5jbHVkZSB0aGUgaWRBZGQgbGFiZWxcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYWN0aW9uLmlkXG5cdFx0XHRcdGNvbnN0IGlkQWRkQ2hvaWNlID0gaWRBZGRPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdFx0XHRpZiAoaWRBZGRDaG9pY2UpIHtcblx0XHRcdFx0XHRuYW1lID0gYCR7bmFtZX0gJHtpZEFkZENob2ljZS5sYWJlbH1gXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBMb29rIGZvciB0aGUgdmFsdWUgb3B0aW9uIChub3QgYnVzQ2ggb3IgaWRBZGQpXG5cdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdFx0aWYgKHZhbHVlT3B0aW9uPy5jaG9pY2VzICYmIHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRcdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gc2V0dGluZy52YWx1ZUJ5dGVzWzBdKVxuXHRcdFx0aWYgKGNob2ljZSkge1xuXHRcdFx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7Y2hvaWNlLmxhYmVsfSAoJHt2YWxEZWN9KWBcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke3ZhbERlY31gXG5cdH1cblxuXHQvLyBObyBhY3Rpb24gZm91bmQgLSBqdXN0IHNob3cgdGhlIHJhdyB2YWx1ZXNcblx0cmV0dXJuIGAke3ByZWZpeH0gfCBVbmtub3duIFNldHRpbmdgXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFBBUlNFUiBESVNQQVRDSCBXSVRIIEFVVE8tREVURUNUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogUGFyc2VzIGdldEFsbFNldHRpbmdzIHJlc3BvbnNlIHdpdGggYXV0b21hdGljIGZvcm1hdCBkZXRlY3Rpb24uXG4gKlxuICogU3RyYXRlZ3k6XG4gKiAxLiBJZiBtb2RlbCBoYXMgZXhwbGljaXQgXCJzZWN0aW9uZWRcIiBwcm9wZXJ0eSwgdXNlIHRoYXRcbiAqIDIuIE90aGVyd2lzZSwgdHJ5IEZMQVQgcGFyc2VyIGZpcnN0IChpdCdzIHNpbXBsZXIpXG4gKiAzLiBJZiBGTEFUIHJldHVybnMgMCBzZXR0aW5ncywgdHJ5IFNFQ1RJT05FRCBwYXJzZXJcbiAqIDQuIFVzZSB3aGljaGV2ZXIgcGFyc2VyIHJldHVybnMgbW9yZSBzZXR0aW5nc1xuICpcbiAqIEByZXR1cm5zIHtzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdLCBkZXRlY3RlZFNlY3Rpb25lZDogYm9vbGVhbiB8IG51bGx9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbihcblx0bW9kZWw6IHN0cmluZyxcblx0YnVmOiBCdWZmZXIsXG4pOiB7IHNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW107IGRldGVjdGVkU2VjdGlvbmVkOiBib29sZWFuIHwgbnVsbCB9IHtcblx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRjb25zdCBkZWNsYXJlZFNlY3Rpb25lZCA9IHNjaGVtYT8uc2VjdGlvbmVkXG5cblx0Ly8gSWYgZXhwbGljaXRseSBkZWNsYXJlZCBpbiBKU09OLCB1c2UgdGhhdFxuXHRpZiAoZGVjbGFyZWRTZWN0aW9uZWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IHNldHRpbmdzID0gZGVjbGFyZWRTZWN0aW9uZWRcblx0XHRcdD8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbClcblx0XHRcdDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiBudWxsIH0gLy8gbnVsbCA9IHVzZWQgZGVjbGFyZWQgdmFsdWVcblx0fVxuXG5cdC8vIE5vIGRlY2xhcmF0aW9uIC0gdHJ5IGJvdGggcGFyc2VycyBhbmQgcGljayB0aGUgYmVzdCBvbmVcblx0bGV0IGZsYXRTZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdID0gW11cblx0bGV0IHNlY3Rpb25lZFNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdHRyeSB7XG5cdFx0ZmxhdFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZGVidWcoYEZsYXQgcGFyc2VyIGZhaWxlZDogJHtlfWApXG5cdH1cblxuXHR0cnkge1xuXHRcdHNlY3Rpb25lZFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5kZWJ1ZyhgU2VjdGlvbmVkIHBhcnNlciBmYWlsZWQ6ICR7ZX1gKVxuXHR9XG5cblx0Ly8gUGljayB0aGUgcGFyc2VyIHRoYXQgcmV0dXJuZWQgbW9yZSBzZXR0aW5nc1xuXHRpZiAoc2VjdGlvbmVkU2V0dGluZ3MubGVuZ3RoID4gZmxhdFNldHRpbmdzLmxlbmd0aCkge1xuXHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIFNFQ1RJT05FRCBmb3JtYXQgKHNlY3Rpb25lZD0ke3NlY3Rpb25lZFNldHRpbmdzLmxlbmd0aH0gdnMgZmxhdD0ke2ZsYXRTZXR0aW5ncy5sZW5ndGh9KWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IHNlY3Rpb25lZFNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogdHJ1ZSB9XG5cdH0gZWxzZSBpZiAoZmxhdFNldHRpbmdzLmxlbmd0aCA+IDApIHtcblx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBGTEFUIGZvcm1hdCAoZmxhdD0ke2ZsYXRTZXR0aW5ncy5sZW5ndGh9IHZzIHNlY3Rpb25lZD0ke3NlY3Rpb25lZFNldHRpbmdzLmxlbmd0aH0pYClcblx0XHRyZXR1cm4geyBzZXR0aW5nczogZmxhdFNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogZmFsc2UgfVxuXHR9IGVsc2Uge1xuXHRcdC8vIEJvdGggcGFyc2VycyByZXR1cm5lZCAwIHNldHRpbmdzXG5cdFx0bG9nZ2VyLndhcm4oYFdhcm5pbmc6IEJvdGggcGFyc2VycyByZXR1cm5lZCAwIHNldHRpbmdzIGZvciBtb2RlbCAke21vZGVsfWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IFtdLCBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9XG5cdH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbChtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IHsgc2VjdGlvbmVkIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHNlY3Rpb25lZCA/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpIDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG59XG5cbi8qIFx1MjcwNSBiYWNrd2FyZC1jb21wYXRpYmxlIGV4cG9ydCAqL1xuZXhwb3J0IGNvbnN0IHBhcnNlR2V0QWxsU2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWxcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVkFMVUUgXHUyMTkyIE9QVElPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlczogbnVtYmVyW10pOiBTdEFjdGlvbk9wdGlvbiB7XG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdHJldHVybiB7IGlkOiAndmFsdWUnLCBsYWJlbDogJ1ZhbHVlJywgdHlwZTogJ251bWJlcicsIGRlZmF1bHQ6IHZhbHVlQnl0ZXNbMF0gfVxuXHR9XG5cblx0aWYgKHZhbHVlQnl0ZXMubGVuZ3RoID09PSAzKSB7XG5cdFx0Y29uc3QgW3IsIGcsIGJdID0gdmFsdWVCeXRlc1xuXHRcdHJldHVybiB7XG5cdFx0XHRpZDogJ3ZhbHVlJyxcblx0XHRcdGxhYmVsOiAnQ29sb3InLFxuXHRcdFx0dHlwZTogJ2NvbG9ycGlja2VyJyxcblx0XHRcdGRlZmF1bHQ6IGZvcm1hdFJnYkNvbG9yKHIsIGcsIGIpLFxuXHRcdH1cblx0fVxuXG5cdHJldHVybiB7IGlkOiAndmFsdWUnLCBsYWJlbDogJ1ZhbHVlJywgdHlwZTogJ3JhdycsIGRlZmF1bHQ6IFsuLi52YWx1ZUJ5dGVzXSB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNNQVJUIEpTT04gVVBEQVRFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MoXG5cdG1vZGVsSnNvbjogU3RNb2RlbEpzb24sXG5cdHBhcnNlZDogUGFyc2VkU2V0dGluZ1tdLFxuXHRhbGxNb2RlbHM6IFJlY29yZDxzdHJpbmcsIFN0TW9kZWxKc29uPixcbik6IFN0TW9kZWxKc29uIHtcblx0Y29uc3Qgb3V0ID0gc3RydWN0dXJlZENsb25lKG1vZGVsSnNvbilcblxuXHQvLyBFbnN1cmUgY21kU2NoZW1hIGFycmF5IGV4aXN0c1xuXHRpZiAoIW91dC5jbWRTY2hlbWEpIHtcblx0XHRvdXQuY21kU2NoZW1hID0gW11cblx0fVxuXG5cdC8vIFNvcnQgb3RoZXIgbW9kZWxzIGJ5IG51bWVyaWMgZGlzdGFuY2UgdG8gY3VycmVudCBtb2RlbFxuXHRjb25zdCBjYW5kaWRhdGVzID0gT2JqZWN0LnZhbHVlcyhhbGxNb2RlbHMpXG5cdFx0LmZpbHRlcigobSkgPT4gbS5tb2RlbCAhPT0gbW9kZWxKc29uLm1vZGVsKSAvLyBleGNsdWRlIHNlbGZcblx0XHQuc29ydCgoYSwgYikgPT4gbW9kZWxEaXN0YW5jZShtb2RlbEpzb24ubW9kZWwsIGEubW9kZWwpIC0gbW9kZWxEaXN0YW5jZShtb2RlbEpzb24ubW9kZWwsIGIubW9kZWwpKVxuXG5cdGxvZ2dlci5pbmZvKGBVcGRhdGluZyBtb2RlbDogJHttb2RlbEpzb24ubW9kZWx9YClcblx0bG9nZ2VyLmRlYnVnKGBDYW5kaWRhdGVzIGZvciBpbmZlcmVuY2U6ICR7Y2FuZGlkYXRlcy5tYXAoKGMpID0+IGMubW9kZWwpLmpvaW4oJywgJyl9YClcblxuXHQvLyBQcmUtc2NhbjogZm9yIGVhY2ggY2FuZGlkYXRlIGlkQWRkIGJhc2UgZW50cnksIGZpbmQgdGhlIG1heGltdW0gc2VxdWVudGlhbFxuXHQvLyBvZmZzZXQgdGhlIHBhY2tldCBjb250YWlucyAoZXZlbiBiZXlvbmQgd2hhdCB0aGUgcmVmZXJlbmNlIG1vZGVsIGtub3dzKS5cblx0Ly8gS2V5OiBgJHtjbWRfaWR9XyR7YmFzZV9pZH1gLCB2YWx1ZTogbWF4IHNlcXVlbnRpYWwgb2Zmc2V0IHNlZW4gaW4gcGFyc2VkIGRhdGEuXG5cdGNvbnN0IGlkQWRkRGVmZXJSYW5nZXMgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpXG5cdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0Zm9yIChjb25zdCBiYXNlRW50cnkgb2YgYy5jbWRTY2hlbWEgPz8gW10pIHtcblx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gYmFzZUVudHJ5Lm9wdGlvbnM/LmZpbmQoKG86IGFueSkgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMpIGNvbnRpbnVlXG5cdFx0XHRjb25zdCBiYXNlSWQgPSBiYXNlRW50cnkuaWRcblx0XHRcdGNvbnN0IGNtZElkID0gYmFzZUVudHJ5LmNtZF9pZFxuXHRcdFx0Y29uc3Qga2V5ID0gYCR7Y21kSWR9XyR7YmFzZUlkfWBcblx0XHRcdGlmIChpZEFkZERlZmVyUmFuZ2VzLmhhcyhrZXkpKSBjb250aW51ZVxuXHRcdFx0Ly8gRmluZCB0aGUgbWF4IHNlcXVlbnRpYWwgb2Zmc2V0IHByZXNlbnQgaW4gdGhlIHBhcnNlZCBwYWNrZXQgZm9yIHRoaXMgYmFzZVxuXHRcdFx0Y29uc3QgcGFyc2VkT2Zmc2V0cyA9IHBhcnNlZFxuXHRcdFx0XHQuZmlsdGVyKChwKSA9PiBwLmNtZF9pZCA9PT0gY21kSWQgJiYgcC5pZCA+IGJhc2VJZClcblx0XHRcdFx0Lm1hcCgocCkgPT4gcC5pZCAtIGJhc2VJZClcblx0XHRcdFx0LnNvcnQoKGEsIGIpID0+IGEgLSBiKVxuXHRcdFx0Ly8gV2FsayBmcm9tIDEgdXB3YXJkIFx1MjAxNCBzdG9wIGF0IGZpcnN0IGdhcFxuXHRcdFx0bGV0IG1heFNlcSA9IDBcblx0XHRcdGZvciAoY29uc3Qgb2ZmIG9mIHBhcnNlZE9mZnNldHMpIHtcblx0XHRcdFx0aWYgKG9mZiA9PT0gbWF4U2VxICsgMSkgbWF4U2VxID0gb2ZmXG5cdFx0XHRcdGVsc2UgaWYgKG9mZiA+IG1heFNlcSArIDEpIGJyZWFrXG5cdFx0XHR9XG5cdFx0XHRpZiAobWF4U2VxID4gMCkge1xuXHRcdFx0XHRpZEFkZERlZmVyUmFuZ2VzLnNldChrZXksIG1heFNlcSlcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBpZEFkZCBkZWZlciByYW5nZSBmb3IgY21kX2lkPSR7dG9IZXgoY21kSWQpfSBiYXNlX2lkPSR7dG9IZXgoYmFzZUlkKX06IG9mZnNldHMgMVx1MjAxMyR7bWF4U2VxfWApXG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0Ly8gUHJlLWNvbXB1dGUgdGhlIHNldCBvZiBhbGwgYnVzQ2ggdmFsdWVzIHNlZW4gcGVyIChjbWRfaWQsIGlkKSBwYWlyIGFjcm9zcyB0aGUgZnVsbFxuXHQvLyBwYXJzZWQgcmVzcG9uc2UgXHUyMDE0IHVzZWQgbGF0ZXIgdG8gZGVjaWRlIGZpeGVkIHZzLiBzZWxlY3RhYmxlIGJ1c0NoLlxuXHRjb25zdCBidXNDaFNlZW4gPSBuZXcgTWFwPHN0cmluZywgU2V0PG51bWJlcj4+KClcblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQsIGJ1c0NoIH0gb2YgcGFyc2VkKSB7XG5cdFx0aWYgKGJ1c0NoID09PSB1bmRlZmluZWQpIGNvbnRpbnVlXG5cdFx0Y29uc3Qga2V5ID0gYCR7Y21kX2lkfV8ke2lkfWBcblx0XHRpZiAoIWJ1c0NoU2Vlbi5oYXMoa2V5KSkgYnVzQ2hTZWVuLnNldChrZXksIG5ldyBTZXQoKSlcblx0XHRidXNDaFNlZW4uZ2V0KGtleSkhLmFkZChidXNDaClcblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gUEFTUyAxOiByZXNvbHZlIGVhY2ggcGFyc2VkIGVudHJ5IFx1MjAxNCBleGFjdCBtYXRjaCwgaW5mZXJyZWQsXG5cdC8vIGlkQWRkLWZvbGQgKG9mZnNldCBpbnRvIGFuIGFscmVhZHktYWRkZWQgYmFzZSBlbnRyeSksIG9yIHVua25vd25cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCwgYnVzQ2gsIHZhbHVlQnl0ZXMgfSBvZiBwYXJzZWQpIHtcblx0XHQvLyAxYS4gRXhhY3QgbWF0Y2ggYWxyZWFkeSBpbiBvdXRwdXQgc2NoZW1hIFx1MjAxNCBqdXN0IHJlZnJlc2ggdGhlIGRlZmF1bHRcblx0XHRjb25zdCBleGlzdGluZ0V4YWN0ID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdGlmIChleGlzdGluZ0V4YWN0KSB7XG5cdFx0XHRjb25zdCBvcHQgPSBleGlzdGluZ0V4YWN0Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdFx0XHRpZiAob3B0KSBvcHQuZGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cdFx0XHRjb250aW51ZVxuXHRcdH1cblxuXHRcdC8vIDFiLiBDaGVjayBpZiB0aGlzIGlkIGZvbGRzIGludG8gYW4gYWxyZWFkeS1hZGRlZCBiYXNlIGVudHJ5IHZpYSBpZEFkZC5cblx0XHQvLyAgICAgR2F0ZTogdGhlIG9mZnNldCBtdXN0IGFjdHVhbGx5IGV4aXN0IGluIHRoZSByZWZlcmVuY2UgbW9kZWwncyBpZEFkZCBjaG9pY2VzXG5cdFx0Ly8gICAgIHRvIGF2b2lkIHN3YWxsb3dpbmcgdW5yZWxhdGVkIHNhbWUtY21kX2lkIGVudHJpZXMgKGUuZy4gU2lkZXRvbmUgYXQgaWQ9MjEpLlxuXHRcdGNvbnN0IGlkQWRkQmFzZSA9IG91dC5jbWRTY2hlbWEuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBjbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdGlmIChpZCA8PSBhLmlkKSByZXR1cm4gZmFsc2Vcblx0XHRcdGNvbnN0IG9mZnNldCA9IGlkIC0gYS5pZFxuXHRcdFx0Ly8gT25seSBmb2xkIGlmIGEgcmVmZXJlbmNlIG1vZGVsIGV4cGxpY2l0bHkgbGlzdHMgdGhpcyBvZmZzZXQgaW4gaXRzIGlkQWRkIGNob2ljZXNcblx0XHRcdHJldHVybiBjYW5kaWRhdGVzLnNvbWUoKGMpID0+IHtcblx0XHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgocikgPT4gci5jbWRfaWQgPT09IGNtZF9pZCAmJiByLmlkID09PSBhLmlkKVxuXHRcdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRyZXR1cm4gcmVmSWRBZGQ/LmNob2ljZXM/LnNvbWUoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0XHR9KVxuXHRcdH0pXG5cdFx0aWYgKGlkQWRkQmFzZSkge1xuXHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBpZEFkZEJhc2UuaWRcblx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gaWRBZGRCYXNlLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoaWRBZGRPcHQ/LmNob2ljZXMgJiYgIWlkQWRkT3B0LmNob2ljZXMuc29tZSgoYzogYW55KSA9PiBjLmlkID09PSBvZmZzZXQpKSB7XG5cdFx0XHRcdGxldCBsYWJlbCA9IGBDaGFubmVsICR7b2Zmc2V0ICsgMX1gXG5cdFx0XHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZEFkZEJhc2UuaWQpXG5cdFx0XHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRjb25zdCByZWZDaG9pY2UgPSByZWZJZEFkZD8uY2hvaWNlcz8uZmluZCgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHRcdFx0XHRpZiAocmVmQ2hvaWNlKSB7XG5cdFx0XHRcdFx0XHRsYWJlbCA9IHJlZkNob2ljZS5sYWJlbFxuXHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0aWRBZGRPcHQuY2hvaWNlcy5wdXNoKHsgaWQ6IG9mZnNldCwgbGFiZWwgfSlcblx0XHRcdFx0bG9nZ2VyLmluZm8oXG5cdFx0XHRcdFx0YEZvbGRlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gaW50byBpZEFkZCBiYXNlIGlkPSR7dG9IZXgoaWRBZGRCYXNlLmlkKX0gYXMgb2Zmc2V0ICR7b2Zmc2V0fSAoXCIke2xhYmVsfVwiKWAsXG5cdFx0XHRcdClcblx0XHRcdH1cblx0XHRcdGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0Ly8gMWMuIE5vIGV4YWN0IG1hdGNoIFx1MjAxNCB0cnkgaW5mZXJlbmNlIGZyb20gY2FuZGlkYXRlIG1vZGVsc1xuXHRcdGxldCBhY3Rpb246IFN0QWN0aW9uIHwgdW5kZWZpbmVkXG5cblx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0Y29uc3QgbWF0Y2ggPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZClcblx0XHRcdGlmIChtYXRjaCkge1xuXHRcdFx0XHRhY3Rpb24gPSBzdHJ1Y3R1cmVkQ2xvbmUobWF0Y2gpXG5cdFx0XHRcdC8vIFN0cmlwIGFueSBleGlzdGluZyBcIihpbmZlcnJlZCBmcm9tIE1vZGVsIFgpXCIgc3VmZml4ZXMgYmVmb3JlIGFkZGluZyBvdXIgb3duXG5cdFx0XHRcdGNvbnN0IGJhc2VOYW1lID0gbWF0Y2gubmFtZS5yZXBsYWNlKC9cXHMqXFwoaW5mZXJyZWQgZnJvbSBNb2RlbCBbXildK1xcKS9nLCAnJykudHJpbSgpXG5cdFx0XHRcdGFjdGlvbi5uYW1lID0gYCR7YmFzZU5hbWV9IChpbmZlcnJlZCBmcm9tIE1vZGVsICR7Yy5tb2RlbH0pYFxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgSW5mZXJyZWQgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGZyb20gTW9kZWwgJHtjLm1vZGVsfSAoZXhhY3QpYClcblx0XHRcdFx0YnJlYWtcblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBDaGVjayBpZiB0aGlzIGlkIHNob3VsZCBiZSBkZWZlcnJlZCB0byBwYXNzIDIgXHUyMDE0XG5cdFx0Ly8gaXQncyBhIHNlcXVlbnRpYWwgaWRBZGQgb2Zmc2V0IG9mIGEga25vd24gY2FuZGlkYXRlIGJhc2UgZW50cnkuXG5cdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdGxldCBzaG91bGREZWZlciA9IGZhbHNlXG5cdFx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0XHRjb25zdCBiYXNlRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgoYTogYW55KSA9PiB7XG5cdFx0XHRcdFx0aWYgKGEuY21kX2lkICE9PSBjbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gYS5vcHRpb25zPy5maW5kKChvOiBhbnkpID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0aWYgKGlkIDw9IGEuaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdGNvbnN0IG9mZnNldCA9IGlkIC0gYS5pZFxuXHRcdFx0XHRcdGNvbnN0IG1heFNlcSA9IGlkQWRkRGVmZXJSYW5nZXMuZ2V0KGAke2NtZF9pZH1fJHthLmlkfWApID8/IDBcblx0XHRcdFx0XHRyZXR1cm4gb2Zmc2V0IDw9IG1heFNlcVxuXHRcdFx0XHR9KVxuXHRcdFx0XHRpZiAoYmFzZUVudHJ5KSB7XG5cdFx0XHRcdFx0c2hvdWxkRGVmZXIgPSB0cnVlXG5cdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKFxuXHRcdFx0XHRcdFx0YGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBpcyBhbiBpZEFkZCBvZmZzZXQgb2YgY2FuZGlkYXRlIGJhc2UgaWQ9JHt0b0hleChiYXNlRW50cnkuaWQpfSBcdTIwMTQgZGVmZXJyaW5nIHRvIHBhc3MgMmAsXG5cdFx0XHRcdFx0KVxuXHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmIChzaG91bGREZWZlcikgY29udGludWVcblx0XHR9XG5cblx0XHQvLyBGYWxsYmFjazogdW5rbm93biBzZXR0aW5nXG5cdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdGFjdGlvbiA9IHtcblx0XHRcdFx0Y21kX2lkLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0bmFtZTogYFVua25vd24gY21kOiR7dG9IZXgoY21kX2lkKX0gaWQ6JHt0b0hleChpZCkudG9VcHBlckNhc2UoKX1gLFxuXHRcdFx0XHRvcHRpb25zOiBbdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpXSxcblx0XHRcdH1cblx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBhY3Rpb24uYnVzQ2ggPSBidXNDaFxuXHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBpbmZlciBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgRml4IDE6IGJ1c0NoIGhhbmRsaW5nIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gU3RyaXAgYW55IGluaGVyaXRlZCBidXNDaCBvcHRpb24gZnJvbSB0aGUgY2FuZGlkYXRlIFx1MjAxNCB3ZSdsbCByZS1kZXJpdmVcblx0XHRcdC8vIGl0IGZyb20gd2hhdCB0aGUgcGFja2V0IGFjdHVhbGx5IHJlcG9ydGVkIGZvciB0aGlzIGRldmljZS5cblx0XHRcdGFjdGlvbi5vcHRpb25zID0gYWN0aW9uLm9wdGlvbnM/LmZpbHRlcigobykgPT4gby5pZCAhPT0gJ2J1c0NoJykgPz8gW11cblx0XHRcdGRlbGV0ZSBhY3Rpb24uYnVzQ2hcblxuXHRcdFx0Y29uc3Qgc2VlbkJ1c0NoVmFsdWVzID0gYnVzQ2hTZWVuLmdldChgJHtjbWRfaWR9XyR7aWR9YClcblx0XHRcdGlmIChzZWVuQnVzQ2hWYWx1ZXMgJiYgc2VlbkJ1c0NoVmFsdWVzLnNpemUgPiAwKSB7XG5cdFx0XHRcdGNvbnN0IG1heEJ1c0NoID0gTWF0aC5tYXgoLi4uc2VlbkJ1c0NoVmFsdWVzKVxuXHRcdFx0XHRpZiAobWF4QnVzQ2ggPT09IDApIHtcblx0XHRcdFx0XHQvLyBPbmx5IGV2ZXIgc2F3IGJ1c0NoPTAgXHUyMTkyIGZpeGVkIHByb3BlcnR5LCBub3QgYW4gb3B0aW9uXG5cdFx0XHRcdFx0YWN0aW9uLmJ1c0NoID0gMFxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdC8vIE11bHRpcGxlIGNoYW5uZWxzIG9ic2VydmVkIFx1MjE5MiBzZWxlY3RhYmxlIG9wdGlvblxuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoQ2hvaWNlcyA9IEFycmF5LmZyb20oeyBsZW5ndGg6IG1heEJ1c0NoICsgMSB9LCAoXywgaSkgPT4gKHtcblx0XHRcdFx0XHRcdGlkOiBpLFxuXHRcdFx0XHRcdFx0bGFiZWw6IGBDaGFubmVsICR7aSArIDF9YCxcblx0XHRcdFx0XHR9KSlcblx0XHRcdFx0XHRhY3Rpb24ub3B0aW9ucy51bnNoaWZ0KHtcblx0XHRcdFx0XHRcdGlkOiAnYnVzQ2gnLFxuXHRcdFx0XHRcdFx0bGFiZWw6ICdDaGFubmVsJyxcblx0XHRcdFx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRcdFx0XHRjaG9pY2VzOiBidXNDaENob2ljZXMsXG5cdFx0XHRcdFx0XHRkZWZhdWx0OiAwLFxuXHRcdFx0XHRcdH0gYXMgYW55KVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBGaXggMjogZGVmYXVsdCBtdXN0IGV4aXN0IGluIGNob2ljZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBTZXQgdGhlIGRlZmF1bHQgdG8gdGhlIG9ic2VydmVkIHZhbHVlLiBJZiB0aGF0IHZhbHVlIGlzbid0IGluIHRoZVxuXHRcdFx0Ly8gaW5oZXJpdGVkIGNob2ljZXMgbGlzdCwgdGhlIGNob2ljZXMgYXJlIGZyb20gYSBzdHJ1Y3R1cmFsbHkgZGlmZmVyZW50XG5cdFx0XHQvLyBtb2RlbCBhbmQgY2FuJ3QgYmUgdHJ1c3RlZCBcdTIwMTQgZGlzY2FyZCB0aGVtIGFuZCBmYWxsIGJhY2sgdG8gYSBwbGFpbiBudW1iZXIuXG5cdFx0XHRjb25zdCBvYnNlcnZlZERlZmF1bHQgPSB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcykuZGVmYXVsdFxuXHRcdFx0Y29uc3QgdmFsdWVPcHQgPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJylcblx0XHRcdGlmICh2YWx1ZU9wdCkge1xuXHRcdFx0XHRpZiAodmFsdWVPcHQuY2hvaWNlcyAmJiBBcnJheS5pc0FycmF5KHZhbHVlT3B0LmNob2ljZXMpKSB7XG5cdFx0XHRcdFx0Y29uc3QgaW5DaG9pY2VzID0gdmFsdWVPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9ic2VydmVkRGVmYXVsdClcblx0XHRcdFx0XHRpZiAoIWluQ2hvaWNlcykge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oXG5cdFx0XHRcdFx0XHRcdGBJbmZlcnJlZCBjaG9pY2VzIGZvciBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gZG9uJ3QgY29udGFpbiBvYnNlcnZlZCB2YWx1ZSAke29ic2VydmVkRGVmYXVsdH0gXHUyMDE0IGRpc2NhcmRpbmcgaW5oZXJpdGVkIGNob2ljZXNgLFxuXHRcdFx0XHRcdFx0KVxuXHRcdFx0XHRcdFx0Ly8gS2VlcCBsYWJlbC90b29sdGlwIGJ1dCBkcm9wIGNob2ljZXMsIHN3aXRjaCB0byBwbGFpbiBudW1iZXJcblx0XHRcdFx0XHRcdHZhbHVlT3B0LnR5cGUgPSAnbnVtYmVyJ1xuXHRcdFx0XHRcdFx0ZGVsZXRlICh2YWx1ZU9wdCBhcyBhbnkpLmNob2ljZXNcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0dmFsdWVPcHQuZGVmYXVsdCA9IG9ic2VydmVkRGVmYXVsdFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdG91dC5jbWRTY2hlbWEucHVzaChhY3Rpb24pXG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFBBU1MgMjogZm9sZCBhbnkgZGVmZXJyZWQgaWRBZGQgb2Zmc2V0cyB3aG9zZSBiYXNlIGVudHJ5XG5cdC8vIGlzIG5vdyBwcmVzZW50IGluIHRoZSBvdXRwdXQgc2NoZW1hLlxuXHQvLyBHYXRlOiB0aGUgb2Zmc2V0IG11c3QgZWl0aGVyIGV4aXN0IGluIGEgcmVmZXJlbmNlIG1vZGVsJ3MgY2hvaWNlcyxcblx0Ly8gT1IgdGhlIGJhc2UgZW50cnkgaXRzZWxmIHdhcyBpbmZlcnJlZCAoaGFzIGlkQWRkKSBhbmQgdGhlIG9mZnNldFxuXHQvLyBjb250aW51ZXMgc2VxdWVudGlhbGx5IGJleW9uZCB0aGUgcmVmZXJlbmNlIG1vZGVsJ3Mga25vd24gcmFuZ2UuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQgfSBvZiBwYXJzZWQpIHtcblx0XHRjb25zdCBhbHJlYWR5VG9wTGV2ZWwgPSBvdXQuY21kU2NoZW1hLnNvbWUoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0aWYgKGFscmVhZHlUb3BMZXZlbCkgY29udGludWVcblxuXHRcdC8vIEZpbmQgYSBiYXNlIGVudHJ5IGluIHRoZSBvdXRwdXQgdGhhdCBoYXMgaWRBZGQgYW5kIHdob3NlIGlkIDwgdGhpcyBpZFxuXHRcdGNvbnN0IGlkQWRkQmFzZSA9IG91dC5jbWRTY2hlbWEuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBjbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRyZXR1cm4gISFpZEFkZE9wdD8uY2hvaWNlcyAmJiBpZCA+IGEuaWRcblx0XHR9KVxuXHRcdGlmICghaWRBZGRCYXNlKSBjb250aW51ZVxuXG5cdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBpZEFkZEJhc2UuaWRcblx0XHRjb25zdCBpZEFkZE9wdCA9IGlkQWRkQmFzZS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMgfHwgaWRBZGRPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldCkpIGNvbnRpbnVlXG5cblx0XHQvLyBBY2NlcHQgdGhlIGZvbGQgaWY6IGEgcmVmZXJlbmNlIG1vZGVsIGV4cGxpY2l0bHkgaGFzIHRoaXMgb2Zmc2V0LFxuXHRcdC8vIE9SIHRoZSBvZmZzZXRzIGFyZSBzdHJpY3RseSBzZXF1ZW50aWFsIGZyb20gMCAoZGV2aWNlIGhhcyBtb3JlIGNoYW5uZWxzIHRoYW4gcmVmZXJlbmNlKVxuXHRcdGNvbnN0IHJlZkhhc09mZnNldCA9IGNhbmRpZGF0ZXMuc29tZSgoYykgPT4ge1xuXHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgocikgPT4gci5jbWRfaWQgPT09IGNtZF9pZCAmJiByLmlkID09PSBpZEFkZEJhc2UuaWQpXG5cdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0cmV0dXJuIHJlZklkQWRkPy5jaG9pY2VzPy5zb21lKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdH0pXG5cdFx0Y29uc3QgZXhpc3RpbmdPZmZzZXRzID0gaWRBZGRPcHQuY2hvaWNlcy5tYXAoKGM6IGFueSkgPT4gYy5pZCBhcyBudW1iZXIpLnNvcnQoKGEsIGIpID0+IGEgLSBiKVxuXHRcdGNvbnN0IGlzU2VxdWVudGlhbCA9IGV4aXN0aW5nT2Zmc2V0cy5sZW5ndGggPiAwICYmIG9mZnNldCA9PT0gZXhpc3RpbmdPZmZzZXRzW2V4aXN0aW5nT2Zmc2V0cy5sZW5ndGggLSAxXSArIDFcblxuXHRcdGlmICghcmVmSGFzT2Zmc2V0ICYmICFpc1NlcXVlbnRpYWwpIGNvbnRpbnVlXG5cblx0XHQvLyBJbmhlcml0IGxhYmVsIGZyb20gcmVmZXJlbmNlIG1vZGVsIGlmIGF2YWlsYWJsZSwgb3RoZXJ3aXNlIGdlbmVyYXRlIG9uZVxuXHRcdGxldCBsYWJlbCA9IGBDaGFubmVsICR7b2Zmc2V0ICsgMX1gXG5cdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWRBZGRCYXNlLmlkKVxuXHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGNvbnN0IHJlZkNob2ljZSA9IHJlZklkQWRkPy5jaG9pY2VzPy5maW5kKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0aWYgKHJlZkNob2ljZSkge1xuXHRcdFx0XHRsYWJlbCA9IHJlZkNob2ljZS5sYWJlbFxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlkQWRkT3B0LmNob2ljZXMucHVzaCh7IGlkOiBvZmZzZXQsIGxhYmVsIH0pXG5cdFx0bG9nZ2VyLmluZm8oXG5cdFx0XHRgUGFzcyAyOiBGb2xkZWQgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGludG8gaWRBZGQgYmFzZSBpZD0ke3RvSGV4KGlkQWRkQmFzZS5pZCl9IGFzIG9mZnNldCAke29mZnNldH0gKFwiJHtsYWJlbH1cIilgLFxuXHRcdClcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0FWRVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gc2F2ZU1vZGVsSnNvblByZXR0eShmaWxlUGF0aDogc3RyaW5nLCBqc29uT2JqOiBTdE1vZGVsSnNvbik6IHZvaWQge1xuXHR0cnkge1xuXHRcdC8vIEVuc3VyZSBwcm9wZXIga2V5IG9yZGVyaW5nOiBtb2RlbCwgc2VjdGlvbmVkIChpZiBwcmVzZW50KSwgcmVmcmVzaEFmdGVyQ29tbWFuZCwgY21kU2NoZW1hXG5cdFx0Y29uc3Qgb3JkZXJlZE9iajogYW55ID0geyBtb2RlbDoganNvbk9iai5tb2RlbCB9XG5cblx0XHQvLyBBZGQgc2VjdGlvbmVkIGtleSBpZiBwcmVzZW50IChyaWdodCBhZnRlciBtb2RlbClcblx0XHRpZiAoJ3NlY3Rpb25lZCcgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5zZWN0aW9uZWQgPSBqc29uT2JqLnNlY3Rpb25lZFxuXHRcdH1cblxuXHRcdC8vIEFkZCBvdGhlciBrZXlzIGluIG9yZGVyXG5cdFx0aWYgKCdyZWZyZXNoQWZ0ZXJDb21tYW5kJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLnJlZnJlc2hBZnRlckNvbW1hbmQgPSBqc29uT2JqLnJlZnJlc2hBZnRlckNvbW1hbmRcblx0XHR9XG5cdFx0aWYgKCdjbWRTY2hlbWEnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmouY21kU2NoZW1hID0ganNvbk9iai5jbWRTY2hlbWEubWFwKChlbnRyeTogYW55KSA9PiB7XG5cdFx0XHRcdC8vIEVuZm9yY2Uga2V5IG9yZGVyIHdpdGhpbiBlYWNoIHNjaGVtYSBlbnRyeTogY21kX2lkLCBpZCwgYnVzQ2gsIG5hbWUsIG9wdGlvbnNcblx0XHRcdFx0Y29uc3Qgb3JkZXJlZEVudHJ5OiBhbnkgPSB7fVxuXHRcdFx0XHRpZiAoJ2NtZF9pZCcgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5jbWRfaWQgPSBlbnRyeS5jbWRfaWRcblx0XHRcdFx0aWYgKCdpZCcgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5pZCA9IGVudHJ5LmlkXG5cdFx0XHRcdGlmICgnYnVzQ2gnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkuYnVzQ2ggPSBlbnRyeS5idXNDaFxuXHRcdFx0XHRpZiAoJ25hbWUnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkubmFtZSA9IGVudHJ5Lm5hbWVcblx0XHRcdFx0aWYgKCdvcHRpb25zJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5Lm9wdGlvbnMgPSBlbnRyeS5vcHRpb25zXG5cdFx0XHRcdC8vIENvcHkgYW55IHJlbWFpbmluZyBrZXlzXG5cdFx0XHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGVudHJ5KSkge1xuXHRcdFx0XHRcdGlmICghKGtleSBpbiBvcmRlcmVkRW50cnkpKSBvcmRlcmVkRW50cnlba2V5XSA9IGVudHJ5W2tleV1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gb3JkZXJlZEVudHJ5XG5cdFx0XHR9KVxuXHRcdH1cblx0XHQvLyBDb3B5IGFueSBvdGhlciBrZXlzIHRoYXQgbWlnaHQgZXhpc3Rcblx0XHRmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhqc29uT2JqKSkge1xuXHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRPYmopKSB7XG5cdFx0XHRcdG9yZGVyZWRPYmpba2V5XSA9IChqc29uT2JqIGFzIGFueSlba2V5XVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIEN1c3RvbSBmb3JtYXR0ZXI6IGtlZXAgY2hvaWNlIG9iamVjdHMgY29tcGFjdCBvbiBvbmUgbGluZVxuXHRcdGxldCBqc29uID0gSlNPTi5zdHJpbmdpZnkob3JkZXJlZE9iaiwgbnVsbCwgMilcblxuXHRcdC8vIFJlcGxhY2UgZXhwYW5kZWQgY2hvaWNlIG9iamVjdHMgd2l0aCBjb21wYWN0IHNpbmdsZS1saW5lIGZvcm1hdFxuXHRcdC8vIE1hdGNoZXM6IHtcXG4gICAgICAgICAgICBcImlkXCI6IFgsXFxuICAgICAgICAgICAgXCJsYWJlbFwiOiBcIllcIlxcbiAgICAgICAgICB9XG5cdFx0Ly8gUmVwbGFjZXMgd2l0aDogeyBcImlkXCI6IFgsIFwibGFiZWxcIjogXCJZXCIgfVxuXHRcdGpzb24gPSBqc29uLnJlcGxhY2UoL1xce1xcblxccytcImlkXCI6XFxzKihcXGQrKSxcXG5cXHMrXCJsYWJlbFwiOlxccypcIihbXlwiXSopXCJcXG5cXHMrXFx9L2csICd7IFwiaWRcIjogJDEsIFwibGFiZWxcIjogXCIkMlwiIH0nKVxuXG5cdFx0ZnMud3JpdGVGaWxlU3luYyhmaWxlUGF0aCwganNvbiArICdcXG4nLCAndXRmOCcpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZXJyb3IoYEZpbGUgV3JpdGUgRXJyb3I6ICR7ZX1gKVxuXHR9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIExPQUQgREVWSUNFIEpTT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBMb2FkcyB0aGUgYWN0aW9ucyBhcnJheSBmb3IgYSBnaXZlbiBtb2RlbCBmcm9tIHRoZSBjZW50cmFsaXplZCBjYWNoZS5cbiAqIFJldHVybnMgYW4gZW1wdHkgYXJyYXkgaWYgdGhlIG1vZGVsIGlzIG5vdCBmb3VuZC5cbiAqIEBkZXByZWNhdGVkIC0gVGhpcyBmdW5jdGlvbiBpcyBubyBsb25nZXIgbmVlZGVkLiBVc2UgZ2V0RGV2aWNlU2NoZW1hKCkgZnJvbSBjb25maWcudHMgaW5zdGVhZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxvYWRBY3Rpb25zRm9yTW9kZWwoX2RldmljZXNGb2xkZXI6IHN0cmluZywgbW9kZWw6IHN0cmluZyk6IFN0QWN0aW9uW10ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdHJldHVybiBzY2hlbWE/LmNtZFNjaGVtYSA/PyBbXVxufVxuXG4vKipcbiAqIExvYWRzIHRoZSBtb2RlbCBjb25maWd1cmF0aW9uIGZyb20gdGhlIGNlbnRyYWxpemVkIGNhY2hlLlxuICogQGRlcHJlY2F0ZWQgLSBUaGlzIGZ1bmN0aW9uIGlzIG5vIGxvbmdlciBuZWVkZWQuIFVzZSBnZXREZXZpY2VTY2hlbWEoKSBmcm9tIGNvbmZpZy50cyBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZE1vZGVsQ29uZmlnKFxuXHRfZGV2aWNlc0ZvbGRlcjogc3RyaW5nLFxuXHRtb2RlbDogc3RyaW5nLFxuKTogeyBhY3Rpb25zOiBTdEFjdGlvbltdOyByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuIH0ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdHJldHVybiB7XG5cdFx0YWN0aW9uczogc2NoZW1hPy5jbWRTY2hlbWEgPz8gW10sXG5cdFx0cmVmcmVzaEFmdGVyQ29tbWFuZDogc2NoZW1hPy5yZWZyZXNoQWZ0ZXJDb21tYW5kID8/IHRydWUsIC8vIERlZmF1bHQgdG8gdHJ1ZSBpZiBub3Qgc3BlY2lmaWVkXG5cdH1cbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRGZWVkYmFja3MgfSBmcm9tICcuL2J1aWxkLWNvbW1hbmRzLmpzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzLCBmaW5kQWN0aW9uRm9yU2V0dGluZyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbi8qKlxuICogSGVscGVyIGZ1bmN0aW9uIHRvIGdldCBsYWJlbCBmcm9tIGNob2ljZXMgYmFzZWQgb24gdmFsdWVcbiAqL1xuZnVuY3Rpb24gZ2V0TGFiZWxGb3JWYWx1ZShcblx0c2NoZW1hczogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+LFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyLFxuXHRzZXR0aW5nSWQ6IG51bWJlcixcblx0dmFsdWU6IG51bWJlcixcbik6IHN0cmluZyB8IG51bWJlciB7XG5cdGNvbnN0IHNldHRpbmcgPSBmaW5kQWN0aW9uRm9yU2V0dGluZyhzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZClcblx0aWYgKCFzZXR0aW5nIHx8ICFBcnJheS5pc0FycmF5KHNldHRpbmcub3B0aW9ucykpIHJldHVybiB2YWx1ZVxuXG5cdC8vIEZpbmQgdGhlICd2YWx1ZScgb3B0aW9uIHdoaWNoIGNvbnRhaW5zIHRoZSBjaG9pY2VzXG5cdGNvbnN0IHZhbHVlT3B0aW9uID0gc2V0dGluZy5vcHRpb25zLmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdGlmICghdmFsdWVPcHRpb24gfHwgIUFycmF5LmlzQXJyYXkodmFsdWVPcHRpb24uY2hvaWNlcykpIHJldHVybiB2YWx1ZVxuXG5cdC8vIEZpbmQgdGhlIGNob2ljZSB3aXRoIG1hdGNoaW5nIGlkXG5cdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYzogYW55KSA9PiBjLmlkID09PSB2YWx1ZSlcblx0cmV0dXJuIGNob2ljZT8ubGFiZWwgPz8gdmFsdWVcbn1cblxuLyoqXG4gKiBCdWlsZCBhbmQgd2lyZSBDb21wYW5pb24gZmVlZGJhY2sgZGVmaW5pdGlvbnNcbiAqIFBhdHRlcm4gbWF0Y2hlcyBhY3Rpb25zLnRzIC0gZmlsdGVycyBieSBhY3RpdmUgbW9kZWwgYW5kIHdpcmVzIGNhbGxiYWNrc1xuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlRmVlZGJhY2tzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IHNjaGVtYXNSYXcgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgcmF3RmVlZGJhY2tzID0gYnVpbGRGZWVkYmFja3MoKVxuXHRjb25zdCBzY2hlbWFzID0gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoc2NoZW1hc1Jhdylcblx0Y29uc3Qgd2lyZWRGZWVkYmFja3M6IGFueSA9IHt9XG5cblx0Ly8gR2V0IHRoZSBhY3RpdmUgbW9kZWwgZnJvbSB0aGUgY2FjaGVkIHZhbHVlIHNldCBieSBzeW5jTW9kZWwoKVxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEZFRURCQUNLUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFtmZWVkYmFja0lkLCBmZWVkYmFja10gb2YgT2JqZWN0LmVudHJpZXMocmF3RmVlZGJhY2tzKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGZlZWRiYWNrSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgZmVlZGJhY2tzIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBtb2RlbFxuXHRcdGlmIChtb2RlbCAhPT0gYWN0aXZlTW9kZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBWQUxVRSBGRUVEQkFDSzogUmV0dXJucyBjdXJyZW50IHZhbHVlIGZvciBsb2NhbCB2YXJpYWJsZVxuXHRcdHdpcmVkRmVlZGJhY2tzW2ZlZWRiYWNrSWRdID0ge1xuXHRcdFx0Li4uZmVlZGJhY2ssXG5cdFx0XHRjYWxsYmFjazogKGZlZWRiYWNrRXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cblx0XHRcdFx0Ly8gYnVzQ2ggZnJvbSBvcHRpb25zIHRha2VzIHByaW9yaXR5OyBmYWxsIGJhY2sgdG8gZml4ZWQgYnVzQ2ggaW4gc2NoZW1hXG5cdFx0XHRcdGxldCBidXNDaCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snYnVzQ2gnXVxuXHRcdFx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdGNvbnN0IHNjaGVtYUFjdGlvbiA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGlmIChzY2hlbWFBY3Rpb24/LmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdGJ1c0NoID0gc2NoZW1hQWN0aW9uLmJ1c0NoXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Y29uc3QgY3VycmVudCA9IHNlbGYuc3RDb250cm9sbGVyLmdldFNldHRpbmdWYWx1ZShpcCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cblx0XHRcdFx0Ly8gQ2hlY2sgaWYgdXNlciB3YW50cyBsYWJlbCBpbnN0ZWFkIG9mIG51bWVyaWMgdmFsdWVcblx0XHRcdFx0Y29uc3Qgc2hvd0xhYmVsID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydzaG93TGFiZWwnXSA/PyBmYWxzZVxuXG5cdFx0XHRcdGlmIChzaG93TGFiZWwgJiYgY3VycmVudCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Ly8gUmV0dXJuIHRoZSBsYWJlbCBmcm9tIGNob2ljZXNcblx0XHRcdFx0XHRyZXR1cm4gZ2V0TGFiZWxGb3JWYWx1ZShzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgY3VycmVudClcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFJldHVybiBudW1lcmljIHZhbHVlIGRpcmVjdGx5IGZvciBsb2NhbCB2YXJpYWJsZSAodHlwZTogJ3ZhbHVlJylcblx0XHRcdFx0cmV0dXJuIGN1cnJlbnQgPz8gMFxuXHRcdFx0fSxcblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEZlZWRiYWNrRGVmaW5pdGlvbnMod2lyZWRGZWVkYmFja3MpXG5cblx0Ly9jb25zb2xlLmxvZygnRmVlZGJhY2tzOlxcbicsIEpTT04uc3RyaW5naWZ5KHdpcmVkRmVlZGJhY2tzLCBudWxsLCAyKSlcbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHtcblx0Q01EX0JVU19HRVQsXG5cdENNRF9CVVNfU0VULFxuXHRDTURfREVWX1NQRUMsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfR0VUX0ZJUk1XQVJFLFxuXHRDTURfR0xPQkFMX01JQ19LSUxMLFxuXHRDTURfTUlDX1BSRSxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfUkVTRVRfREVWSUNFLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0Z2V0Q29tbWFuZE5hbWUsXG5cdG1ha2VTZXR0aW5nSWQsXG5cdHRvSGV4LFxuXHRieXRlc1RvSGV4LFxuXHR0eXBlIERldmljZUluZm8sXG59IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQge1xuXHRwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwsXG5cdHBhcnNlU2V0dGluZ3NSZXNwb25zZSxcblx0Zm9ybWF0UGFyc2VkU2V0dGluZyxcblx0dHlwZSBTdEFjdGlvbixcblx0dHlwZSBQYXJzZWRTZXR0aW5nLFxufSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuaW1wb3J0IHtcblx0REFOVEVfTVNHX0lORk9fUkVTUE9OU0UsXG5cdHBhcnNlRGFudGVJbmZvUmVzcG9uc2UsXG5cdGRpc2NvdmVyRGV2aWNlcyxcblx0YnVpbGREYW50ZUluZm9SZXF1ZXN0LFxuXHRnZXRNYWNGb3JEZXN0aW5hdGlvbixcblx0Z2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24sXG59IGZyb20gJy4vZGFudGUuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU3RDb250cm9sbGVyJylcblxuZXhwb3J0IGNsYXNzIFN0Q29udHJvbGxlciB7XG5cdHByaXZhdGUgcmVhZG9ubHkgZGVmYXVsdFBvcnQ6IG51bWJlciA9IDg3MDBcblx0cHJpdmF0ZSByZWFkb25seSBtdWx0aWNhc3RHcm91cCA9ICcyMjQuMC4wLjIzMSdcblx0cHJpdmF0ZSByZWFkb25seSByeFBvcnQgPSA4NzAyXG5cblx0cHJpdmF0ZSB0eFNvY2tldDogZGdyYW0uU29ja2V0XG5cdHByaXZhdGUgcnhTb2NrZXQ6IGRncmFtLlNvY2tldCAvLyBmb3IgcmVjZWl2aW5nIHJlc3BvbnNlcyAoODcwMilcblx0cHJpdmF0ZSBwZW5kaW5nQWNrczogTWFwPFxuXHRcdHN0cmluZyxcblx0XHR7IHJlc29sdmU6IChidWY6IEJ1ZmZlcikgPT4gdm9pZDsgcmVqZWN0OiAoZTogRXJyb3IpID0+IHZvaWQ7IHRpbWVyOiBOb2RlSlMuVGltZW91dCB9XG5cdD4gPSBuZXcgTWFwKClcblx0cHJpdmF0ZSBqb2luZWRJbnRlcmZhY2VzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKSAvLyBsb2NhbCBJUHMgd2UndmUgam9pbmVkIG11bHRpY2FzdCBvblxuXG5cdC8qKiBTZXJpYWxpemVzIG91dGdvaW5nIGNvbW1hbmRzIHNvIGVhY2ggd2FpdHMgZm9yIEFDSyBiZWZvcmUgdGhlIG5leHQgaXMgc2VudCAqL1xuXHRwcml2YXRlIHNlbmRRdWV1ZTogUHJvbWlzZTx2b2lkPiA9IFByb21pc2UucmVzb2x2ZSgpXG5cblx0LyoqIFRyYWNrcyBob3cgbWFueSBjb21tYW5kcyBhcmUgcXVldWVkL2luLWZsaWdodCwgdG8gZGVmZXIgcmVxdWVzdEFsbFNldHRpbmdzICovXG5cdHByaXZhdGUgcGVuZGluZ0NvbW1hbmRDb3VudCA9IDBcblxuXHQvKiogUmVzb2x2ZXMgb25jZSB0eFNvY2tldCBpcyBib3VuZCBhbmQgcmVhZHkgdG8gc2VuZCAqL1xuXHRwcml2YXRlIHR4UmVhZHk6IFByb21pc2U8dm9pZD5cblxuXHQvKiogQWN0aXZlIGRldmljZSBtb2RlbCBhbmQgYWN0aW9uIGRlZmluaXRpb25zIGZvciBzZXR0aW5ncyBkZWNvZGluZyAqL1xuXHRwcml2YXRlIG1vZGVsOiBzdHJpbmcgPSAnJ1xuXHRwcml2YXRlIGFjdGlvbnM6IFN0QWN0aW9uW10gPSBbXVxuXHRwcml2YXRlIHJlZnJlc2hBZnRlckNvbW1hbmQ6IGJvb2xlYW4gPSB0cnVlIC8vIERlZmF1bHQgdG8gdHJ1ZSAobW9zdCBkZXZpY2VzIG5lZWQgaXQpXG5cblx0LyoqXG5cdCAqIEtub3duIHN0YXRlIG9mIGV2ZXJ5IHNldHRpbmcgcGVyIGRldmljZSBJUC5cblx0ICogS2V5ZWQgYnkgSVAgXHUyMTkyIE1hcCBvZiBcIiR7Y21kSWR9LyR7c2V0dGluZ0lkfVwiIFx1MjE5MiBjdXJyZW50IHZhbHVlIGJ5dGUuXG5cdCAqIFBvcHVsYXRlZCBvbiBjb25uZWN0IHZpYSByZXF1ZXN0QWxsU2V0dGluZ3MoKSwgdXBkYXRlZCBvbiBldmVyeSBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikuXG5cdCAqIFVzZWQgdG8gZGlmZiBpbmNvbWluZyBwdXNoZXMgKGNoYW5nZWQgPSBpbmZvLCB1bmNoYW5nZWQgPSBkZWJ1ZykgYW5kIGZvciBmZWVkYmFja3MuXG5cdCAqL1xuXHRwcml2YXRlIGRldmljZVN0YXRlOiBNYXA8c3RyaW5nLCBNYXA8c3RyaW5nLCBudW1iZXI+PiA9IG5ldyBNYXAoKVxuXG5cdC8qKlxuXHQgKiBJUHMgdGhhdCBoYXZlIGJlZW4gdmVyaWZpZWQgYWdhaW5zdCB0aGUgY29uZmlndXJlZCBtb2RlbCBhbmQgYXJlIGFsbG93ZWRcblx0ICogdG8gcmVjZWl2ZSBTdHVkaW8tVCBjb21tYW5kcy4gUG9wdWxhdGVkIGJ5IGF1dGhvcml6ZURldmljZSgpIGFmdGVyIGFcblx0ICogc3VjY2Vzc2Z1bCBwcm9iZURldmljZSgpIG1vZGVsIG1hdGNoLCBvciBhZnRlciBtdWx0aWNhc3QgZGlzY292ZXJ5LlxuXHQgKiBfc2VuZEF3YWl0QWNrKCkgcmVqZWN0cyBhbnkgZGVzdElwIG5vdCBpbiB0aGlzIHNldC5cblx0ICovXG5cdHByaXZhdGUgYXV0aG9yaXplZElwczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KClcblxuXHQvKiogQ2FsbGJhY2tzIHJlZ2lzdGVyZWQgYnkgZGlzY292ZXJEZXZpY2VzKCkgXHUyMDE0IGtleWVkIGJ5IHNvdXJjZSBJUCAqL1xuXHRwcml2YXRlIGRpc2NvdmVyeUxpc3RlbmVyczogTWFwPHN0cmluZywgKGRldmljZTogRGV2aWNlSW5mbykgPT4gdm9pZD4gPSBuZXcgTWFwKClcblxuXHQvKiogQ2FsbGJhY2sgdG8gdHJpZ2dlciBmZWVkYmFjayB1cGRhdGVzIHdoZW4gc3RhdGUgY2hhbmdlcyAqL1xuXHRwcml2YXRlIGZlZWRiYWNrQ2FsbGJhY2s/OiAoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB2b2lkXG5cblx0LyoqIENhY2hlIG9mIGxvY2FsIGludGVyZmFjZSBNQUMgYnl0ZXMgcGVyIGRlc3RpbmF0aW9uIElQLCB0byBhdm9pZCByZXBlYXRlZCBPUyBsb29rdXBzICovXG5cdHByaXZhdGUgbWFjQ2FjaGU6IE1hcDxzdHJpbmcsIG51bWJlcltdPiA9IG5ldyBNYXAoKVxuXG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdGxvZ2dlci5pbmZvKCdTdENvbnRyb2xsZXIgaW5pdGlhbGl6ZWQnKVxuXG5cdFx0Ly8gU2VuZCBzb2NrZXQgXHUyMDE0IGJpbmQgdG8gZXBoZW1lcmFsIHBvcnQuIFJlc3BvbnNlcyBhbHdheXMgZ28gdG8gcnhTb2NrZXQgb25cblx0XHQvLyBwb3J0IDg3MDIgKERhbnRlIGhhcmRjb2RlcyB0aGUgcmVzcG9uc2UgZGVzdGluYXRpb24gcG9ydCB0byA4NzAyKS5cblx0XHR0aGlzLnR4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnR4UmVhZHkgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0dGhpcy50eFNvY2tldC5iaW5kKDAsICgpID0+IHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBUWCBzb2NrZXQgYm91bmQgdG8gcG9ydCAkeyh0aGlzLnR4U29ja2V0LmFkZHJlc3MoKSBhcyB7IHBvcnQ6IG51bWJlciB9KS5wb3J0fWApXG5cdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdHRoaXMudHhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBUWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdC8vIFJlY2VpdmUgc29ja2V0IC0gYmluZCB0byBhbGwgYWRkcmVzc2VzIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0c1xuXHRcdHRoaXMucnhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbGlzdGVuaW5nJywgKCkgPT4ge1xuXHRcdFx0Y29uc3QgYWRkciA9IHRoaXMucnhTb2NrZXQuYWRkcmVzcygpXG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBsaXN0ZW5pbmcgb24gJHtKU09OLnN0cmluZ2lmeShhZGRyKX1gKVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5zZXRNdWx0aWNhc3RMb29wYmFjayh0cnVlKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBSWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5oYW5kbGVJbmNvbWluZyhtc2csIHJpbmZvLmFkZHJlc3MpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoYEVycm9yIGhhbmRsaW5nIGluY29taW5nIG1lc3NhZ2U6ICR7X2V9YClcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gQmluZCB0byB3aWxkY2FyZCBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHMgZm9yIGpvaW5lZCBpbnRlcmZhY2VzXG5cdFx0dGhpcy5yeFNvY2tldC5iaW5kKHsgYWRkcmVzczogJzAuMC4wLjAnLCBwb3J0OiB0aGlzLnJ4UG9ydCB9LCAoKSA9PiB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBib3VuZCB0byAwLjAuMC4wOiR7dGhpcy5yeFBvcnR9YClcblx0XHR9KVxuXHR9XG5cblx0cHVibGljIGNsb3NlKCk6IHZvaWQge1xuXHRcdHRyeSB7XG5cdFx0XHRmb3IgKGNvbnN0IGxvY2FsQWRkciBvZiBBcnJheS5mcm9tKHRoaXMuam9pbmVkSW50ZXJmYWNlcykpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR0aGlzLnJ4U29ja2V0LmRyb3BNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy5yeFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFByb3ZpZGUgdGhlIGFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBzbyBpbmNvbWluZyBtZXNzYWdlc1xuXHQgKiBjYW4gYmUgZGVjb2RlZCBpbnRvIGh1bWFuLXJlYWRhYmxlIG5hbWVzLiBDYWxsIGZyb20gbWFpbi50cyBhZnRlciBjb25maWcgbG9hZC5cblx0ICovXG5cdHB1YmxpYyBzZXRNb2RlbChtb2RlbDogc3RyaW5nLCBhY3Rpb25zOiBTdEFjdGlvbltdLCByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xuXHRcdHRoaXMubW9kZWwgPSBtb2RlbFxuXHRcdHRoaXMuYWN0aW9ucyA9IGFjdGlvbnNcblx0XHR0aGlzLnJlZnJlc2hBZnRlckNvbW1hbmQgPSByZWZyZXNoQWZ0ZXJDb21tYW5kXG5cdH1cblxuXHQvKipcblx0ICogU2V0IGNhbGxiYWNrIHRvIHRyaWdnZXIgd2hlbiBkZXZpY2Ugc3RhdGUgY2hhbmdlcyAoZm9yIGZlZWRiYWNrcykuXG5cdCAqIENhbGwgZnJvbSBtYWluLnRzIHRvIHdpcmUgdXAgY2hlY2tGZWVkYmFja3MuXG5cdCAqL1xuXHRwdWJsaWMgc2V0RmVlZGJhY2tDYWxsYmFjayhjYWxsYmFjazogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZCk6IHZvaWQge1xuXHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayA9IGNhbGxiYWNrXG5cdH1cblxuXHQvKiogUmV0dXJucyB0cnVlIGlmIHRoZSBkZXZpY2UgYXQgdGhlIGdpdmVuIElQIGhhcyBiZWVuIGF1dGhvcml6ZWQgdG8gcmVjZWl2ZSBjb21tYW5kcy4gKi9cblx0cHVibGljIGlzRGV2aWNlQXV0aG9yaXplZChpcDogc3RyaW5nKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuYXV0aG9yaXplZElwcy5oYXMoaXApXG5cdH1cblxuXHQvKiogTWFyayBhbiBJUCBhcyB2ZXJpZmllZCBhbmQgYWxsb3dlZCB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgYXV0aG9yaXplRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuYWRkKGlwKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgQXV0aG9yaXplZCBkZXZpY2UgYXQgJHtpcH1gKVxuXHR9XG5cblx0LyoqIFJlbW92ZSBhdXRob3JpemF0aW9uIGZvciBhbiBJUCAoZS5nLiBvbiBjb25maWcgY2hhbmdlIG9yIG1vZGVsIG1pc21hdGNoKS4gKi9cblx0cHVibGljIHJldm9rZURldmljZShpcDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hdXRob3JpemVkSXBzLmRlbGV0ZShpcClcblx0XHR0aGlzLmRldmljZVN0YXRlLmRlbGV0ZShpcClcblx0XHR0aGlzLm1hY0NhY2hlLmRlbGV0ZShpcClcblx0XHRsb2dnZXIuZGVidWcoYFJldm9rZWQgZGV2aWNlIGF0ICR7aXB9YClcblx0fVxuXG5cdC8qKlxuXHQgKiBTZW5kcyBhIHVuaWNhc3QgRGFudGUgaW5mbyByZXF1ZXN0IHRvIGEgc3BlY2lmaWMgSVAgYW5kIHdhaXRzIGZvciB0aGVcblx0ICogZGV2aWNlIGluZm8gcmVzcG9uc2UuIFJldHVybnMgdGhlIERldmljZUluZm8gaWYgdGhlIGRldmljZSByZXNwb25kcyB3aXRoaW5cblx0ICogdGltZW91dE1zLCBvciBudWxsIGlmIG5vIHJlc3BvbnNlLiBVc2VkIHRvIHZlcmlmeSBhIG1hbnVhbGx5IGNvbmZpZ3VyZWQgSVAuXG5cdCAqIERvZXMgTk9UIHJlcXVpcmUgYXV0aG9yaXphdGlvbiBcdTIwMTQgdGhpcyBpcyBob3cgYXV0aG9yaXphdGlvbiBpcyBlc3RhYmxpc2hlZC5cblx0ICovXG5cdHB1YmxpYyBhc3luYyBwcm9iZURldmljZShpcDogc3RyaW5nLCB0aW1lb3V0TXMgPSAzMDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4oKHJlc29sdmUpID0+IHtcblx0XHRcdGNvbnN0IGtleSA9IGBfX3Byb2JlXyR7aXB9X19gXG5cdFx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXG5cdFx0XHRjb25zdCBmaW5pc2ggPSAocmVzdWx0OiBEZXZpY2VJbmZvIHwgbnVsbCkgPT4ge1xuXHRcdFx0XHRpZiAocmVzb2x2ZWQpIHJldHVyblxuXHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKGtleSlcblx0XHRcdFx0cmVzb2x2ZShyZXN1bHQpXG5cdFx0XHR9XG5cblx0XHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChrZXksIChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdFx0aWYgKGRldmljZS5pcCA9PT0gaXApIGZpbmlzaChkZXZpY2UpXG5cdFx0XHR9KVxuXG5cdFx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gZmluaXNoKG51bGwpLCB0aW1lb3V0TXMpXG5cdFx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdFx0Y29uc3QgcnVuID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRhd2FpdCB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoaXApXG5cdFx0XHRcdGF3YWl0IHRoaXMudHhSZWFkeVxuXHRcdFx0XHRjb25zdCBxdWVyeSA9IGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpXG5cdFx0XHRcdHRoaXMudHhTb2NrZXQuc2VuZChxdWVyeSwgdGhpcy5kZWZhdWx0UG9ydCwgaXAsIChlcnIpID0+IHtcblx0XHRcdFx0XHRpZiAoZXJyKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2FybihgUHJvYmUgdG8gJHtpcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0XHRmaW5pc2gobnVsbClcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cblx0XHRcdHJ1bigpLmNhdGNoKChlKSA9PiB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBwcm9iZURldmljZSBzZXR1cCBmYWlsZWQgZm9yICR7aXB9OiAke2V9YClcblx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRmaW5pc2gobnVsbClcblx0XHRcdH0pXG5cdFx0fSlcblx0fVxuXG5cdC8qKlxuXHQgKiBTZW5kIGEgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIHJlcXVlc3QgdG8gdGhlIGRldmljZSBhbmQgc3RvcmUgdGhlIHJlc3BvbnNlXG5cdCAqIGluIGRldmljZVN0YXRlLiBSZXR1cm5zIHRoZSByYXcgcmVzcG9uc2UgYnVmZmVyIGZvciBwYXJzaW5nLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHJlcXVlc3RBbGxTZXR0aW5ncyhkZXZpY2VJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRsb2dnZXIuaW5mbyhgUmVxdWVzdGluZyBhbGwgc2V0dGluZ3MgZnJvbSAke2RldmljZUlwfWApXG5cdFx0Y29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0VUX0FMTF9TRVRUSU5HUywgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGV2aWNlSXAsIGZhbHNlKVxuXHRcdC8vIGRldmljZVN0YXRlIGlzIHBvcHVsYXRlZCBieSBsb2dTdFBheWxvYWQgd2hlbiB0aGUgQ01EX0dFVF9BTExfU0VUVElOR1MgcmVzcG9uc2UgYXJyaXZlc1xuXHRcdHJldHVybiByZXNwb25zZVxuXHR9XG5cblx0LyoqXG5cdCAqIERpc2NvdmVycyBTdHVkaW8gVGVjaG5vbG9naWVzIERhbnRlIGRldmljZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsuXG5cdCAqXG5cdCAqIFN0cmF0ZWd5OlxuXHQgKiAgRGFudGUgZGV2aWNlcyBicm9hZGNhc3QgYSAxLXNlY29uZCBhbm5vdW5jZSB0byBtdWx0aWNhc3QgMjI0LjAuMC4yMzM6ODcwOC5cblx0ICogIFdlIGxpc3RlbiBvbiB0aGF0IGdyb3VwLCBjb2xsZWN0IHNvdXJjZSBJUHMsIHRoZW4gc2VuZCBhIHVuaWNhc3QgZGV2aWNlIGluZm9cblx0ICogIHJlcXVlc3QgKDB4MDAyMCkgdG8gZWFjaCBuZXcgSVAgb24gcG9ydCA4NzAwLiBUaGUgZGV2aWNlIHJlc3BvbmRzIHRvIG91ciBJUFxuXHQgKiAgb24gcG9ydCA4NzAyIChyeFNvY2tldCksIHdoZXJlIGhhbmRsZUluY29taW5nKCkgcGlja3MgaXQgdXAgYW5kIGZpcmVzIHRoZVxuXHQgKiAgZGlzY292ZXJ5TGlzdGVuZXJzIGNhbGxiYWNrLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIGRpc2NvdmVyRGV2aWNlcyh0aW1lb3V0TXMgPSA1MDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvW10+IHtcblx0XHQvLyBSZWdpc3RlciBsaXN0ZW5lciBcdTIwMTQgaGFuZGxlSW5jb21pbmcoKSBmaXJlcyB0aGlzIGZvciBlYWNoIDB4MDE3MCByZXNwb25zZVxuXHRcdGNvbnN0IERJU0NPVkVSWV9LRVkgPSAnX19kaXNjb3ZlcnlfXydcblx0XHRjb25zdCBmb3VuZERldmljZXM6IERldmljZUluZm9bXSA9IFtdXG5cblx0XHRjb25zdCBvbkRldmljZUZvdW5kID0gKGRldmljZTogRGV2aWNlSW5mbykgPT4ge1xuXHRcdFx0aWYgKCFmb3VuZERldmljZXMuc29tZSgoZCkgPT4gZC5pcCA9PT0gZGV2aWNlLmlwKSkge1xuXHRcdFx0XHRmb3VuZERldmljZXMucHVzaChkZXZpY2UpXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gUmVnaXN0ZXIgdGhlIGNhbGxiYWNrIHNvIGhhbmRsZUluY29taW5nKCkgY2FuIGludm9rZSBpdCB3aGVuIDB4MDE3MCBhcnJpdmVzXG5cdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KERJU0NPVkVSWV9LRVksIG9uRGV2aWNlRm91bmQpXG5cblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0XHQvLyBkaXNjb3ZlckRldmljZXMoKSBpbiBkYW50ZS50cyBoYW5kbGVzIHRoZSBhbm5vdW5jZSBsaXN0ZW5pbmcgYW5kIHF1ZXJ5IHNlbmRpbmcuXG5cdFx0XHQvLyBSZXNwb25zZXMgY29tZSBiYWNrIHRvIHJ4U29ja2V0IFx1MjE5MiBoYW5kbGVJbmNvbWluZygpIFx1MjE5MiBkaXNjb3ZlcnlMaXN0ZW5lcnMuXG5cdFx0XHRhd2FpdCBkaXNjb3ZlckRldmljZXModGhpcy50eFNvY2tldCwgYXN5bmMgKGRlc3RJcCkgPT4gdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcCksIHRpbWVvdXRNcylcblx0XHRcdHJldHVybiBmb3VuZERldmljZXNcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKERJU0NPVkVSWV9LRVkpXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFJlcXVlc3RzIGRldmljZSBmaXJtd2FyZSB2ZXJzaW9uIHZpYSBTdHVkaW8tVCBwcm90b2NvbCAoQ01EX0dFVF9GSVJNV0FSRSkuXG5cdCAqIFJldHVybnMgdGhlIGZpcm13YXJlIHZlcnNpb24gc3RyaW5nIChlLmcuLCBcIjMuMDFcIiwgXCIyLjJcIiwgXCIxLjA1XCIpLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHJlcXVlc3RGaXJtd2FyZVZlcnNpb24oZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgZmlybXdhcmUgdmVyc2lvbiBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HRVRfRklSTVdBUkUsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRldmljZUlwLCBmYWxzZSlcblxuXHRcdC8vIFJlc3BvbnNlIHN0cnVjdHVyZTogW2hlYWRlcl0gMHg1YSAweDgwIFtmaXJtd2FyZV9kYXRhXSBDUkNcblx0XHQvLyBGaXJtd2FyZSBkYXRhIHN0YXJ0cyBhdCBieXRlIDI2ICgyNC1ieXRlIGhlYWRlciArIDB4NWEgKyAweDgwKVxuXHRcdGNvbnN0IGRhdGFTdGFydCA9IDI2XG5cblx0XHRpZiAocmVzcG9uc2UubGVuZ3RoIDwgZGF0YVN0YXJ0ICsgMykge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEZpcm13YXJlIHJlc3BvbnNlIHRvbyBzaG9ydDogJHtyZXNwb25zZS5sZW5ndGh9IGJ5dGVzYClcblx0XHRcdHJldHVybiAnVW5rbm93bidcblx0XHR9XG5cblx0XHQvLyBGaXJtd2FyZSBmb3JtYXQ6IFt1bmtub3duX2J5dGUsIG1ham9yLCBtaW5vcl1cblx0XHRjb25zdCBtYWpvciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDFdXG5cdFx0Y29uc3QgbWlub3IgPSByZXNwb25zZVtkYXRhU3RhcnQgKyAyXVxuXG5cdFx0Y29uc3QgbWlub3JTdHIgPVxuXHRcdFx0bWlub3IgPCAxMFxuXHRcdFx0XHQ/IG1pbm9yLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKSAvLyBlLmcuIDEgXHUyMTkyIFwiMDFcIiwgNSBcdTIxOTIgXCIwNVwiXG5cdFx0XHRcdDogbWlub3IudG9TdHJpbmcoKSAvLyBlLmcuIDEwIFx1MjE5MiBcIjEwXCJcblxuXHRcdGNvbnN0IGZpcm13YXJlID0gYCR7bWFqb3J9LiR7bWlub3JTdHJ9YFxuXG5cdFx0bG9nZ2VyLmluZm8oYEZpcm13YXJlIHZlcnNpb246ICR7ZmlybXdhcmV9YClcblx0XHRyZXR1cm4gZmlybXdhcmVcblx0fVxuXG5cdC8qKlxuXHQgKiBKb2lucyB0aGUgbXVsdGljYXN0IHJlc3BvbnNlIGdyb3VwIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gZGVzdElwLlxuXHQgKiBPbmx5IGpvaW5zIHRoZSBzcGVjaWZpYyBpbnRlcmZhY2UgdXNlZCB0byByZWFjaCB0aGUgZGV2aWNlLCBhbmQgb25seSBvbmNlIHBlciBpbnRlcmZhY2UuXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIGVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYXdhaXQgZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24oZGVzdElwKVxuXHRcdFx0aWYgKCFsb2NhbEFkZHIpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBkZXRlcm1pbmUgbG9jYWwgYWRkcmVzcyBmb3IgZGVzdGluYXRpb24gJHtkZXN0SXB9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdGlmICh0aGlzLmpvaW5lZEludGVyZmFjZXMuaGFzKGxvY2FsQWRkcikpIHtcblx0XHRcdFx0Ly8gYWxyZWFkeSBqb2luZWRcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMucnhTb2NrZXQuYWRkTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBsb2NhbEFkZHIpXG5cdFx0XHRcdHRoaXMuam9pbmVkSW50ZXJmYWNlcy5hZGQobG9jYWxBZGRyKVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgSm9pbmVkIG11bHRpY2FzdCAke3RoaXMubXVsdGljYXN0R3JvdXB9IG9uICR7bG9jYWxBZGRyfWApXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIGpvaW4gbXVsdGljYXN0IG9uICR7bG9jYWxBZGRyfTogJHtTdHJpbmcoX2UpfWApXG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBlbnN1cmVNZW1iZXJzaGlwRm9yIGZhaWxlZDogJHtfZX1gKVxuXHRcdH1cblx0fVxuXG5cdHB1YmxpYyBhc3luYyBzZW5kQXdhaXRBY2soXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0dGhpcy5wZW5kaW5nQ29tbWFuZENvdW50Kytcblx0XHRyZXR1cm4gbmV3IFByb21pc2U8QnVmZmVyPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHR0aGlzLnNlbmRRdWV1ZSA9IHRoaXMuc2VuZFF1ZXVlLnRoZW4oYXN5bmMgKCkgPT5cblx0XHRcdFx0dGhpcy5fc2VuZEF3YWl0QWNrKGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgZGVzdElwLCBhZGRMZW4pXG5cdFx0XHRcdFx0LnRoZW4oKGJ1ZikgPT4ge1xuXHRcdFx0XHRcdFx0dGhpcy5wZW5kaW5nQ29tbWFuZENvdW50LS1cblx0XHRcdFx0XHRcdC8vIE9ubHkgdHJpZ2dlciByZXF1ZXN0QWxsU2V0dGluZ3MgYWZ0ZXIgYSB3cml0ZSAoU0VUKSBjb21tYW5kLCBub3QgYSByZWFkL3BvbGwuXG5cdFx0XHRcdFx0XHQvLyBBIHdyaXRlIGFsd2F5cyBoYXMgYSB2YWx1ZTsgcmVhZHMgKEdFVCwgQlVTX0dFVCkgbmV2ZXIgZG8uXG5cdFx0XHRcdFx0XHRpZiAodGhpcy5wZW5kaW5nQ29tbWFuZENvdW50ID09PSAwICYmIHRoaXMucmVmcmVzaEFmdGVyQ29tbWFuZCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRcdHRoaXMucmVxdWVzdEFsbFNldHRpbmdzKGRlc3RJcCkuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gcmVmcmVzaCBzZXR0aW5ncyBhZnRlciBjb21tYW5kOiAke2Vycn1gKVxuXHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0cmVzb2x2ZShidWYpXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0XHQuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0dGhpcy5wZW5kaW5nQ29tbWFuZENvdW50LS1cblx0XHRcdFx0XHRcdHJlamVjdChlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyciA6IG5ldyBFcnJvcihTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdFx0fSksXG5cdFx0XHQpXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgYXN5bmMgX3NlbmRBd2FpdEFjayhcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0KTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRjb25zdCB0aW1lb3V0TXMgPSAyMDAwXG5cblx0XHRjb25zdCBkYXRhQmxvY2s6IG51bWJlcltdID0gW11cblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKHNldHRpbmdJZCAmIDB4ZmYpXG5cdFx0aWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKC4uLlN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpKVxuXG5cdFx0Y29uc3QgcGF5bG9hZEJvZHk6IG51bWJlcltdID0gWzB4NWEsIGNtZElkICYgMHhmZl1cblxuXHRcdGlmIChjbWRJZCA9PT0gQ01EX01JQ19QUkUgJiYgYnVzQ2ggIT09IHVuZGVmaW5lZCAmJiBzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHQvLyBQb3NpdGlvbmFsIGZvcm1hdDogWzB4NWFdIFsweDAyXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gW3ZhbDJdIC4uLlxuXHRcdFx0Ly8gUmVhZCBhbGwgcG9zaXRpb25zIGZyb20gZGV2aWNlU3RhdGUsIG92ZXJyaWRlIHRoZSB0YXJnZXQgcG9zaXRpb24gd2l0aCBuZXcgdmFsdWUuXG5cdFx0XHQvLyBBbHNvIHVwZGF0ZSBkZXZpY2VTdGF0ZSBvcHRpbWlzdGljYWxseSBzbyBjb25zZWN1dGl2ZSBDTURfTUlDX1BSRSBjb21tYW5kcyBjaGFpbiBjb3JyZWN0bHkuXG5cdFx0XHRpZiAoIXRoaXMuZGV2aWNlU3RhdGUuaGFzKGRlc3RJcCkpIHRoaXMuZGV2aWNlU3RhdGUuc2V0KGRlc3RJcCwgbmV3IE1hcCgpKVxuXHRcdFx0Y29uc3QgaXBTdGF0ZSA9IHRoaXMuZGV2aWNlU3RhdGUuZ2V0KGRlc3RJcCkhXG5cdFx0XHRjb25zdCBudW1Qb3NpdGlvbnMgPSAzIC8vIGdhaW4sIGVsZWN0cmV0L3BoYW50b20sIHVua25vd25cblx0XHRcdGNvbnN0IHBvc2l0aW9uczogbnVtYmVyW10gPSBbXVxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBudW1Qb3NpdGlvbnM7IGkrKykge1xuXHRcdFx0XHRjb25zdCBzdGF0ZUtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgQ01EX01JQ19QUkUsIGksIGJ1c0NoKVxuXHRcdFx0XHRjb25zdCB2YWwgPSBpID09PSBzZXR0aW5nSWQgPyBOdW1iZXIodmFsdWUpIDogKGlwU3RhdGUuZ2V0KHN0YXRlS2V5KSA/PyAwKVxuXHRcdFx0XHRwb3NpdGlvbnMucHVzaCh2YWwpXG5cdFx0XHRcdGlwU3RhdGUuc2V0KHN0YXRlS2V5LCB2YWwpIC8vIG9wdGltaXN0aWMgdXBkYXRlXG5cdFx0XHR9XG5cdFx0XHRwYXlsb2FkQm9keS5wdXNoKGJ1c0NoICYgMHhmZiwgLi4ucG9zaXRpb25zKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgcGF5bG9hZEJvZHkucHVzaChidXNDaCAmIDB4ZmYpXG5cdFx0XHRpZiAoYWRkTGVuKSBwYXlsb2FkQm9keS5wdXNoKGRhdGFCbG9jay5sZW5ndGgpXG5cdFx0XHRpZiAoZGF0YUJsb2NrLmxlbmd0aCA+IDApIHBheWxvYWRCb2R5LnB1c2goLi4uZGF0YUJsb2NrKVxuXHRcdH1cblxuXHRcdGNvbnN0IGNyYyA9IFN0Q29udHJvbGxlci5jcmM4RHZiUzIocGF5bG9hZEJvZHkpXG5cdFx0Y29uc3QgcGF5bG9hZFdpdGhDcmMgPSBCdWZmZXIuZnJvbShbLi4ucGF5bG9hZEJvZHksIGNyY10pXG5cblx0XHQvLyBIdW1hbi1yZWFkYWJsZSBpbmZvIGxvZyBmb3IgdGhlIG91dGdvaW5nIGNvbW1hbmRcblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IFN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IGNtZElkLFxuXHRcdFx0XHRpZDogc2V0dGluZ0lkLFxuXHRcdFx0XHRidXNDaCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKGBUWCAke2Rlc3RJcH0gfCAke2Zvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZywgdGhpcy5hY3Rpb25zKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtnZXRDb21tYW5kTmFtZShjbWRJZCl9YClcblx0XHR9XG5cblx0XHQvLyBSZWplY3QgY29tbWFuZHMgdG8gdW52ZXJpZmllZCBkZXZpY2VzIFx1MjAxNCBsb2cgdGhlIHdvdWxkLWJlIHBhY2tldCBmaXJzdCBhdCBkZWJ1Z1xuXHRcdC8vIHNvIHRoZSBieXRlcyBhcmUgdmlzaWJsZSBldmVuIHdoZW4gdGhlIGRldmljZSBpcyBvZmZsaW5lLlxuXHRcdGlmICghdGhpcy5hdXRob3JpemVkSXBzLmhhcyhkZXN0SXApKSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFBhY2tldCAobm90IHNlbnQgXHUyMDE0IGRldmljZSBub3QgYXV0aG9yaXplZCkgdG8gJHtkZXN0SXB9OiAke3BheWxvYWRXaXRoQ3JjLnRvU3RyaW5nKCdoZXgnKX1gKVxuXHRcdFx0dGhyb3cgbmV3IEVycm9yKGBEZXZpY2UgYXQgJHtkZXN0SXB9IGlzIG5vdCBhdXRob3JpemVkIFx1MjAxNCB2ZXJpZnkgdGhlIElQIGFuZCBtb2RlbCBtYXRjaCBiZWZvcmUgc2VuZGluZyBjb21tYW5kc2ApXG5cdFx0fVxuXG5cdFx0Ly8gRW5zdXJlIHdlIGFyZSBsaXN0ZW5pbmcgZm9yIHJlcGxpZXMgb24gdGhlIGludGVyZmFjZSB0aGF0IHdpbGwgcmVjZWl2ZSB0aGVtXG5cdFx0YXdhaXQgdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcClcblxuXHRcdGNvbnN0IHRvdGFsTGVuID0gMjQgKyBwYXlsb2FkV2l0aENyYy5sZW5ndGhcblx0XHRjb25zdCBoZWFkZXIgPSBhd2FpdCB0aGlzLmJ1aWxkSGVhZGVyKHRvdGFsTGVuLCBkZXN0SXApXG5cdFx0Y29uc3QgcGFja2V0ID0gQnVmZmVyLmNvbmNhdChbaGVhZGVyLCBwYXlsb2FkV2l0aENyY10pXG5cblx0XHRsb2dnZXIuZGVidWcoYFNlbmRpbmcgcGFja2V0IHRvICR7ZGVzdElwfTogJHtwYWNrZXQudG9TdHJpbmcoJ2hleCcpfWApXG5cblx0XHRjb25zdCBrZXkgPSBgJHtkZXN0SXB9OiR7Y21kSWR9YFxuXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPEJ1ZmZlcj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGBUaW1lb3V0IHdhaXRpbmcgZm9yIEFDSyBmcm9tIE1vZGVsICR7dGhpcy5tb2RlbH0gYXQgJHtkZXN0SXB9Ojg3MDBgKSlcblx0XHRcdH0sIHRpbWVvdXRNcylcblxuXHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5zZXQoa2V5LCB7XG5cdFx0XHRcdHJlc29sdmU6IChidWYpID0+IHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVzb2x2ZShidWYpXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHJlamVjdDogKGVycikgPT4ge1xuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZWplY3QoZXJyKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHR0aW1lcixcblx0XHRcdH0pXG5cblx0XHRcdHRoaXMudHhTb2NrZXQuc2VuZChwYWNrZXQsIHRoaXMuZGVmYXVsdFBvcnQsIGRlc3RJcCwgKGVycikgPT4ge1xuXHRcdFx0XHRpZiAoZXJyKSB7XG5cdFx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHRcdFx0fVxuXHRcdFx0fSlcblx0XHR9KVxuXHR9XG5cblx0cHJpdmF0ZSBoYW5kbGVJbmNvbWluZyhtc2c6IEJ1ZmZlciwgc3JjSXA6IHN0cmluZykge1xuXHRcdGlmIChtc2cubGVuZ3RoIDwgNCkgcmV0dXJuXG5cdFx0aWYgKG1zZ1swXSAhPT0gMHhmZiB8fCBtc2dbMV0gIT09IDB4ZmYpIHJldHVyblxuXG5cdFx0Y29uc3QgbXNnVHlwZSA9IG1zZy5yZWFkVUludDE2QkUoMilcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSAoMHgwMTcwKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBUaGVzZSBoYXZlIFwiQXVkaW5hdGVcIiBhdCBvZmZzZXQgMTYsIG5vdCBcIlN0dWRpby1UXCIgXHUyMDE0IGhhbmRsZSBiZWZvcmVcblx0XHQvLyB0aGUgU3R1ZGlvLVQgc2lnbmF0dXJlIGNoZWNrIGJlbG93LlxuXHRcdGlmIChtc2dUeXBlID09PSBEQU5URV9NU0dfSU5GT19SRVNQT05TRSAmJiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5zaXplID4gMCkge1xuXHRcdFx0Y29uc3QgZGV2aWNlID0gcGFyc2VEYW50ZUluZm9SZXNwb25zZShtc2csIHNyY0lwKVxuXHRcdFx0aWYgKGRldmljZSkge1xuXHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0YERhbnRlIGluZm8gcmVzcG9uc2UgZnJvbSAke3NyY0lwfTogYCArXG5cdFx0XHRcdFx0XHRgRGV2aWNlSUQ9XCIke2RldmljZS5uYW1lfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNb2RlbD1cIiR7ZGV2aWNlLm1vZGVsfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNb2RlbE5hbWU9XCIke2RldmljZS5tb2RlbE5hbWV9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1hbnVmYWN0dXJlcj1cIiR7ZGV2aWNlLm1hbnVmYWN0dXJlcn1cImAsXG5cdFx0XHRcdClcblxuXHRcdFx0XHQvLyBPbmx5IGFjY2VwdCBTdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZXMgKGlkZW50aWZpZWQgYnkgRGV2aWNlSUQgXCJTdHVkaW8tVFwiKVxuXHRcdFx0XHRpZiAoZGV2aWNlLm5hbWUgPT09ICdTdHVkaW8tVCcpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGNiIG9mIHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnZhbHVlcygpKSB7XG5cdFx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0XHRjYihkZXZpY2UpXG5cdFx0XHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgSWdub3Jpbmcgbm9uLVN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlOiBEZXZpY2VJRD1cIiR7ZGV2aWNlLm5hbWV9XCIgQCAke3NyY0lwfWApXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGlmIChtc2cubGVuZ3RoIDwgMjUpIHJldHVyblxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIFN0dWRpby1UIGNvbnRyb2wgcHJvdG9jb2wgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Y29uc3Qgc2lnID0gbXNnLnN1YmFycmF5KDE2LCAyNClcblx0XHRpZiAoc2lnLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnU3R1ZGlvLVQnKSByZXR1cm5cblxuXHRcdC8vIFBheWxvYWQgc3RhcnRzIGF0IG9mZnNldCAyNFxuXHRcdC8vIExheW91dDogWzB4NWFdIFtjbWRJZHwweDgwXSBbZGF0YS4uLl0gW2NyY11cblx0XHRjb25zdCBzdFBheWxvYWQgPSBtc2cuc3ViYXJyYXkoMjQpXG5cdFx0aWYgKHN0UGF5bG9hZC5sZW5ndGggPCAyKSByZXR1cm5cblx0XHRpZiAoc3RQYXlsb2FkWzBdICE9PSAweDVhKSByZXR1cm5cblxuXHRcdC8vIERldmljZSByZXBsaWVzIHdpdGggY21kIHwgMHg4MFxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGlzUmVzcG9uc2UgPSAocmVzcENtZElkICYgMHg4MCkgIT09IDBcblx0XHRjb25zdCBvcmlnaW5hbENtZElkID0gcmVzcENtZElkICYgMHg3ZiAvLyBzdHJpcCB0aGUgcmVzcG9uc2UgZmxhZ1xuXG5cdFx0Ly8gTG9nIHJhdyBwYWNrZXQgZm9yIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSByZXNwb25zZXMgYmVmb3JlIHBhcnNpbmdcblx0XHRpZiAoaXNSZXNwb25zZSAmJiBvcmlnaW5hbENtZElkID09PSBDTURfR0VUX0FMTF9TRVRUSU5HUykge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSZWNlaXZlZCBwYWNrZXQgZnJvbSAke3NyY0lwfTogJHttc2cudG9TdHJpbmcoJ2hleCcpfWApXG5cdFx0fVxuXG5cdFx0Ly8gTG9nIHRoZSBwYXlsb2FkICh3b3JrcyBmb3IgYm90aCByZXF1ZXN0cyBhbmQgcmVzcG9uc2VzKVxuXHRcdHRoaXMubG9nU3RQYXlsb2FkKHNyY0lwLCBvcmlnaW5hbENtZElkLCBtc2csIHN0UGF5bG9hZClcblxuXHRcdC8vIE9ubHkgcHJvY2VzcyBhcyBBQ0sgaWYgdGhpcyBpcyBhIHJlc3BvbnNlIHRvIG91ciByZXF1ZXN0XG5cdFx0aWYgKGlzUmVzcG9uc2UpIHtcblx0XHRcdGNvbnN0IGtleSA9IGAke3NyY0lwfToke29yaWdpbmFsQ21kSWR9YFxuXHRcdFx0Y29uc3QgcGVuZGluZyA9IHRoaXMucGVuZGluZ0Fja3MuZ2V0KGtleSlcblx0XHRcdGlmIChwZW5kaW5nKSB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cGVuZGluZy5yZXNvbHZlKG1zZylcblx0XHRcdH1cblx0XHR9XG5cdFx0Ly8gVW5zb2xpY2l0ZWQgbWVzc2FnZXMgYW5kIHJlcXVlc3RzIGZyb20gb3RoZXIgc291cmNlcyBhcmUgbG9nZ2VkIGFib3ZlXG5cdH1cblxuXHQvKipcblx0ICogRGVjb2RlcyBhbmQgbG9ncyBhIFN0dWRpby1UIHJlc3BvbnNlIHBheWxvYWQuXG5cdCAqIFJlY2VpdmVzIGJvdGggdGhlIGZ1bGwgbXNnIChmb3IgcGFyc2VycyB0aGF0IG5lZWQgdGhlIFN0dWRpby1UIGhlYWRlcilcblx0ICogYW5kIHN0UGF5bG9hZCAobXNnLnN1YmFycmF5KDI0KSwgZm9yIGRpcmVjdCBieXRlIGFjY2VzcykuXG5cdCAqXG5cdCAqIHN0UGF5bG9hZCBsYXlvdXQ6XG5cdCAqICAgWzBdICAgICAgMHg1YSAgbWFnaWNcblx0ICogICBbMV0gICAgICBjbWRJZCB8IDB4ODBcblx0ICogICBbMi4uLTJdICBkYXRhIGJ5dGVzXG5cdCAqICAgWy0xXSAgICAgQ1JDLTgvRFZCLVMyXG5cdCAqL1xuXHRwcml2YXRlIGxvZ1N0UGF5bG9hZChzcmNJcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBtc2c6IEJ1ZmZlciwgc3RQYXlsb2FkOiBCdWZmZXIpOiB2b2lkIHtcblx0XHRjb25zdCBjbWROYW1lID0gZ2V0Q29tbWFuZE5hbWUoY21kSWQpXG5cdFx0Y29uc3QgZGF0YSA9IHN0UGF5bG9hZC5zdWJhcnJheSgyLCBzdFBheWxvYWQubGVuZ3RoIC0gMSkgLy8gc3RyaXAgbWFnaWMrY21kSWQgaGVhZGVyIGFuZCBDUkNcblxuXHRcdC8vIFBheWxvYWQgc3RydWN0dXJlOiBbY21kOjB4OGRdIFtkYXRhIGJ5dGVzLi4uXSBbY3JjXVxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGNyYyA9IHN0UGF5bG9hZFtzdFBheWxvYWQubGVuZ3RoIC0gMV1cblx0XHRjb25zdCBmdWxsU3RydWN0dXJlID0gYFtjbWQ6JHt0b0hleChyZXNwQ21kSWQpfSBkYXRhOiR7ZGF0YS50b1N0cmluZygnaGV4Jyl9IGNyYzoke3RvSGV4KGNyYyl9XWBcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgYW5kIENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBQYXJzZSBhbGwgc2V0dGluZ3MsIGRpZmYgYWdhaW5zdCBkZXZpY2VTdGF0ZSwgbG9nIGNoYW5nZWQgYXQgaW5mbyAvIHVuY2hhbmdlZCBhdCBkZWJ1Zyxcblx0XHQvLyB0aGVuIHVwZGF0ZSBkZXZpY2VTdGF0ZS4gQ01EX0dFVF9BTExfU0VUVElOR1MgYWxzbyBzZXJ2ZXMgYXMgdGhlIGluaXRpYWwgc3RhdGUgcG9wdWxhdGlvbiBvbiBjb25uZWN0LlxuXHRcdGlmIChjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgfHwgY21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0XHRpZiAoIXRoaXMubW9kZWwpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IHNldHRpbmdzID1cblx0XHRcdFx0XHRjbWRJZCA9PT0gQ01EX1NFVFRJTkdTX1BVU0hcblx0XHRcdFx0XHRcdD8gcGFyc2VTZXR0aW5nc1Jlc3BvbnNlKHRoaXMubW9kZWwsIG1zZylcblx0XHRcdFx0XHRcdDogcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsKHRoaXMubW9kZWwsIG1zZylcblxuXHRcdFx0XHRjb25zdCBwcmV2U3RhdGUgPSB0aGlzLmRldmljZVN0YXRlLmdldChzcmNJcCkgPz8gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKVxuXHRcdFx0XHRjb25zdCBuZXdTdGF0ZSA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KHByZXZTdGF0ZSkgLy8gY29weSBcdTIwMTQgdXBkYXRlIGluIHBsYWNlXG5cblx0XHRcdFx0Zm9yIChjb25zdCBzIG9mIHNldHRpbmdzKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc3RhdGVLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIHMuY21kX2lkLCBzLmlkLCBzLmJ1c0NoKVxuXHRcdFx0XHRcdC8vIEZvciBSR0IgY29sb3JzICgzIGJ5dGVzKSwgcGFjayBpbnRvIHNpbmdsZSBudW1iZXI6IChSIDw8IDE2KSB8IChHIDw8IDgpIHwgQlxuXHRcdFx0XHRcdGNvbnN0IG5ld1ZhbHVlID1cblx0XHRcdFx0XHRcdHMudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdFx0XHRcdFx0PyAocy52YWx1ZUJ5dGVzWzBdIDw8IDE2KSB8IChzLnZhbHVlQnl0ZXNbMV0gPDwgOCkgfCBzLnZhbHVlQnl0ZXNbMl1cblx0XHRcdFx0XHRcdFx0OiAocy52YWx1ZUJ5dGVzWzBdID8/IDApXG5cdFx0XHRcdFx0Y29uc3QgcHJldlZhbHVlID0gcHJldlN0YXRlLmdldChzdGF0ZUtleSlcblx0XHRcdFx0XHRjb25zdCBjaGFuZ2VkID0gcHJldlZhbHVlID09PSB1bmRlZmluZWQgfHwgcHJldlZhbHVlICE9PSBuZXdWYWx1ZVxuXG5cdFx0XHRcdFx0bmV3U3RhdGUuc2V0KHN0YXRlS2V5LCBuZXdWYWx1ZSlcblxuXHRcdFx0XHRcdGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdFBhcnNlZFNldHRpbmcocywgdGhpcy5hY3Rpb25zKVxuXHRcdFx0XHRcdGlmIChjaGFuZ2VkKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgUlggJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdFx0Ly8gVHJpZ2dlciBmZWVkYmFjayB1cGRhdGUgXHUyMDE0IHVzZSBiYXNlIGtleSB3aXRob3V0IGJ1c0NoIHNvIGl0IG1hdGNoZXMgdGhlIGZlZWRiYWNrIGRlZmluaXRpb24gSURcblx0XHRcdFx0XHRcdGlmICh0aGlzLmZlZWRiYWNrQ2FsbGJhY2spIHtcblx0XHRcdFx0XHRcdFx0Y29uc3QgYmFzZUZlZWRiYWNrS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgcy5pZClcblx0XHRcdFx0XHRcdFx0Ly9sb2dnZXIuZGVidWcoYFRyaWdnZXJpbmcgZmVlZGJhY2sgdXBkYXRlIGZvciBrZXk6ICR7YmFzZUZlZWRiYWNrS2V5fWApXG5cdFx0XHRcdFx0XHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayhiYXNlRmVlZGJhY2tLZXkpXG5cdFx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgZmVlZGJhY2tDYWxsYmFjayBub3Qgc2V0IFx1MjAxNCBza2lwcGluZyBmZWVkYmFjayB1cGRhdGUgZm9yICR7c3RhdGVLZXl9YClcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCAke3NyY0lwfSB8ICR7Zm9ybWF0dGVkfWApXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuZGV2aWNlU3RhdGUuc2V0KHNyY0lwLCBuZXdTdGF0ZSlcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8IHBhcnNlIGZhaWxlZDogJHtlfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIEFsbCBvdGhlciBjb21tYW5kcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBkZWNvZGVkID0gdGhpcy5kZWNvZGVTdERhdGEoY21kSWQsIGRhdGEpXG5cdFx0Ly8gQ01EX0JVU19HRVQgKGtlZXBhbGl2ZSkgaXMgaGlnaC1mcmVxdWVuY3kgbm9pc2UgXHUyMDE0IGxvZyBhdCBkZWJ1ZyBvbmx5XG5cdFx0Y29uc3QgbG9nRm4gPSBjbWRJZCA9PT0gQ01EX0JVU19HRVQgPyBsb2dnZXIuZGVidWcuYmluZChsb2dnZXIpIDogbG9nZ2VyLmluZm8uYmluZChsb2dnZXIpXG5cdFx0aWYgKGRlY29kZWQpIHtcblx0XHRcdGxvZ0ZuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9IHwgJHtkZWNvZGVkfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ0ZuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogQXR0ZW1wdHMgdG8gZGVjb2RlIHRoZSBkYXRhIGJ5dGVzIG9mIGEgU3R1ZGlvLVQgcmVzcG9uc2UgaW50byBhXG5cdCAqIGh1bWFuLXJlYWRhYmxlIHN0cmluZy4gUmV0dXJucyBudWxsIHRvIGZhbGwgYmFjayB0byByYXcgaGV4LlxuXHQgKi9cblx0cHJpdmF0ZSBkZWNvZGVTdERhdGEoY21kSWQ6IG51bWJlciwgZGF0YTogQnVmZmVyKTogc3RyaW5nIHwgbnVsbCB7XG5cdFx0aWYgKGRhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gJ0FDSydcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDaGVjayBmb3Igc2luZ2xlLWJ5dGUgcmVzcG9uc2VzIChBQ0sgb3IgZXJyb3IpIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0aWYgKGRhdGFbMF0gPT09IDB4MDApIHtcblx0XHRcdFx0cmV0dXJuICdBQ0sgb2snXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRyZXR1cm4gYEVSUk9SICR7dG9IZXgoZGF0YVswXSl9YFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHN3aXRjaCAoY21kSWQpIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfTUlDX1BSRSAoMHgwMik6IHJhdyBwcmVhbXAgZWNobyBcdTIwMTQgcG9zaXRpb25hbCBieXRlcywgbm8gc2V0dGluZyBJRHMgXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBEZXZpY2UgZWNob2VzIFtidXNDaF1bdmFsMF1bdmFsMV0uLi4gY29uZmlybWluZyB0aGUgYXBwbGllZCB2YWx1ZXMuXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFOiB7XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCB2YWxzID0gQXJyYXkuZnJvbShkYXRhLnN1YmFycmF5KDEpKVxuXHRcdFx0XHRcdC5tYXAoKGIsIGkpID0+IGBbJHtpfV09MHgke2IudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9KCR7Yn0pYClcblx0XHRcdFx0XHQuam9pbignICcpXG5cdFx0XHRcdHJldHVybiBgY2g9JHtidXNDaH0gJHt2YWxzfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9ERVZfU1BFQyAoMHgwZCk6IHNpbmdsZS1ieXRlIEFDSyBvciBlY2hvIG9mIGFwcGxpZWQgc2V0dGluZyBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIERldmljZSBzZW5kcyB0d28gQ01EX0RFVl9TUEVDIHBhY2tldHMgaW4gcmVzcG9uc2UgdG8gYSBzZXQ6XG5cdFx0XHQvLyAgIDEuIEFDSzogIFtzdGF0dXNdICAgICAgICAgICAgICAgKDEgYnl0ZSwgMHgwMCA9IG9rKVxuXHRcdFx0Ly8gICAyLiBFY2hvOiBbYnVzQ2hdIFtzZXR0aW5nSWRdIFt2YWx1ZS4uLl0gIChjb25maXJtaW5nIHdoYXQgd2FzIGFwcGxpZWQpXG5cdFx0XHRjYXNlIENNRF9ERVZfU1BFQzoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdFx0XHRyZXR1cm4gZGF0YVswXSA9PT0gMHgwMCA/ICdBQ0sgb2snIDogYEFDSyBlcnI9JHt0b0hleChkYXRhWzBdKX1gXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID49IDMpIHtcblx0XHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0XHRjb25zdCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyBgc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9YFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LlswXT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IHZhbHVlTnVtID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/IGAke2Nob2ljZUxhYmVsfSAoJHt0b0hleCh2YWx1ZU51bSEpfSlgIDogYnl0ZXNUb0hleChBcnJheS5mcm9tKHZhbHVlQnl0ZXMpKVxuXHRcdFx0XHRcdGNvbnN0IHJhd1RhZyA9IGBbJHt0b0hleChjbWRJZCl9LyR7dG9IZXgoc2V0dGluZ0lkKX1dPSR7Ynl0ZXNUb0hleChBcnJheS5mcm9tKHZhbHVlQnl0ZXMpKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9ICR7cmF3VGFnfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gYHJhdzogJHtkYXRhLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfTUlDX1BSRV9CVVMgKDB4MTIpOiBNdWx0aS1ieXRlIGVjaG8gcmVzcG9uc2VzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6IHtcblx0XHRcdFx0Ly8gQWxyZWFkeSBoYW5kbGVkIHNpbmdsZS1ieXRlIGFib3ZlLCBzbyBtdWx0aS1ieXRlIG11c3QgYmUgZWNob1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VzID0gYWN0aW9uPy5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID1cblx0XHRcdFx0XHRcdGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlU3RyID0gY2hvaWNlTGFiZWwgPz8gYDB4JHt2YWx1ZUJ5dGVzLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBudWxsXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBCdXMtc2NvcGVkIGdldC9zZXQgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0Y2FzZSBDTURfQlVTX1NFVDoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPCAyKSByZXR1cm4gbnVsbFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0cmV0dXJuIGBjaD0ke2J1c0NofSBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX0gdmFsdWU9JHt2YWx1ZS50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0fVxuXG5cdFx0XHRkZWZhdWx0OlxuXHRcdFx0XHRyZXR1cm4gbnVsbCAvLyBmYWxsIHRocm91Z2ggdG8gcmF3IGhleFxuXHRcdH1cblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGJ1aWxkVmFsdWVCeXRlcyh2YWx1ZTogdW5rbm93bik6IG51bWJlcltdIHtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiBbdmFsdWUgPyAxIDogMF1cblx0XHRpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiB2YWx1ZS5tYXAoKHYpID0+IE51bWJlcih2KSAmIDB4ZmYpXG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcblx0XHRcdGlmICh2YWx1ZSA+IDB4ZmYpIHJldHVybiBbKHZhbHVlID4+IDE2KSAmIDB4ZmYsICh2YWx1ZSA+PiA4KSAmIDB4ZmYsIHZhbHVlICYgMHhmZl1cblx0XHRcdHJldHVybiBbdmFsdWUgJiAweGZmXVxuXHRcdH1cblx0XHR0aHJvdyBuZXcgRXJyb3IoYFVuc3VwcG9ydGVkIHZhbHVlIHR5cGUgZm9yIFNUY29udHJvbGxlcjogJHt2YWx1ZX1gKVxuXHR9XG5cblx0cHJpdmF0ZSBhc3luYyBidWlsZEhlYWRlcih0b3RhbExlbjogbnVtYmVyLCBkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0bGV0IG1hYyA9IHRoaXMubWFjQ2FjaGUuZ2V0KGRlc3RJcClcblx0XHRpZiAoIW1hYykge1xuXHRcdFx0bWFjID0gYXdhaXQgZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwKVxuXHRcdFx0dGhpcy5tYWNDYWNoZS5zZXQoZGVzdElwLCBtYWMpXG5cdFx0fVxuXG5cdFx0cmV0dXJuIEJ1ZmZlci5jb25jYXQoW1xuXHRcdFx0QnVmZmVyLmZyb20oWzB4ZmYsIDB4ZmYsIDB4MDAsIHRvdGFsTGVuICYgMHhmZiwgMHgwNywgMHhlMSwgMHgwMCwgMHgwMCwgLi4ubWFjLCAweDAwLCAweDAwXSksXG5cdFx0XHRCdWZmZXIuZnJvbSgnU3R1ZGlvLVQnLCAndXRmOCcpLFxuXHRcdF0pXG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBjcmM4RHZiUzIoZGF0YTogbnVtYmVyW10pOiBudW1iZXIge1xuXHRcdGxldCBjcmMgPSAwXG5cdFx0Zm9yIChjb25zdCBiIG9mIGRhdGEpIHtcblx0XHRcdGNyYyBePSBiXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IDg7IGkrKykge1xuXHRcdFx0XHRjcmMgPSAoY3JjICYgMHg4MCkgIT09IDAgPyAoKGNyYyA8PCAxKSBeIDB4ZDUpICYgMHhmZiA6IChjcmMgPDwgMSkgJiAweGZmXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBjcmNcblx0fVxuXG5cdC8qKlxuXHQgKiBSZXR1cm5zIHRoZSBjdXJyZW50IGtub3duIHZhbHVlIGZvciBhIHNldHRpbmcgb24gYSBkZXZpY2UsIG9yIHVuZGVmaW5lZCBpZiB1bmtub3duLlxuXHQgKiBVc2UgZm9yIGZlZWRiYWNrcyBcdTIwMTQgdmFsdWUgaXMgdXBkYXRlZCBvbiBldmVyeSBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgZnJvbSB0aGUgZGV2aWNlLlxuXHQgKlxuXHQgKiBAcGFyYW0gaXAgICAgICAgIERldmljZSBJUCBhZGRyZXNzXG5cdCAqIEBwYXJhbSBjbWRJZCAgICAgQ29tbWFuZCBJRCAoZS5nLiBDTURfREVWX1NQRUMpXG5cdCAqIEBwYXJhbSBzZXR0aW5nSWQgU2V0dGluZyBJRCAoZS5nLiAweDAyIGZvciBDb250cm9sIFNvdXJjZSlcblx0ICogQHBhcmFtIGJ1c0NoICAgICBPcHRpb25hbCBidXMvY2hhbm5lbCBJRCBmb3IgbXVsdGktY2hhbm5lbCBjb21tYW5kc1xuXHQgKi9cblx0cHVibGljIGdldFNldHRpbmdWYWx1ZShpcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBzZXR0aW5nSWQ6IG51bWJlciwgYnVzQ2g/OiBudW1iZXIpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuXHRcdGNvbnN0IGtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cdFx0cmV0dXJuIHRoaXMuZGV2aWNlU3RhdGUuZ2V0KGlwKT8uZ2V0KGtleSlcblx0fVxuXG5cdHB1YmxpYyBhc3luYyByZXNldERldmljZShkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKENNRF9SRVNFVF9ERVZJQ0UsIHVuZGVmaW5lZCwgMHgwMCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG5cblx0cHVibGljIGFzeW5jIGdsb2JhbE1pY0tpbGwoZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHJldHVybiB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0xPQkFMX01JQ19LSUxMLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IG9zIGZyb20gJ29zJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRGFudGUnKVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgRGFudGUgZGlzY292ZXJ5IGNvbnN0YW50cyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlcXVlc3QgbWVzc2FnZSB0eXBlIChzZW50IHRvIHBvcnQgODcwMCkgKi9cbmV4cG9ydCBjb25zdCBEQU5URV9NU0dfSU5GT19SRVFVRVNUID0gMHgwMDIwXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgbWVzc2FnZSB0eXBlIChyZWNlaXZlZCBvbiBwb3J0IDg3MDIpICovXG5leHBvcnQgY29uc3QgREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgPSAweDAxNzBcblxuLyoqXG4gKiBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSBsYXlvdXQgKGFsbCBvZmZzZXRzIGFyZSBpbnRvIHRoZSBVRFAgcGF5bG9hZCk6XG4gKiAgIDB4MDAgIHVpbnQxNkJFICBNYWdpYyAoMHhmZmZmKVxuICogICAweDAyICB1aW50MTZCRSAgTWVzc2FnZSB0eXBlICgweDAxNzApXG4gKiAgIDB4MDQgIHVpbnQxNkJFICBTZXF1ZW5jZSBudW1iZXJcbiAqICAgMHgwNiAgMiBieXRlcyAgIFBhZGRpbmdcbiAqICAgMHgwOCAgOCBieXRlcyAgIEVVSS02NCAoc291cmNlIE1BQyB3aXRoIGZmOmZlIGluc2VydGVkIG1pZClcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBBU0NJSSBpZGVudGlmaWVyXG4gKiAgIDB4MTggIDIgYnl0ZXMgICBEYW50ZSBtb2R1bGUgZmlybXdhcmUgdmVyc2lvbiAobWFqb3IsIG1pbm9yKVxuICogICAweDIwICAzMSBieXRlcyAgRGV2aWNlIG5hbWUsIG51bGwtcGFkZGVkIEFTQ0lJIChtYXggMzEgY2hhcnMgcGVyIERhbnRlIHNwZWMpXG4gKiAgIDB4MmUgIHVpbnQxNkJFICBQcm9kdWN0IElEXG4gKiAgIDB4NGMgIDY0IGJ5dGVzICBNYW51ZmFjdHVyZXIgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICogICAweGNjICA2NCBieXRlcyAgTW9kZWwgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICovXG5leHBvcnQgY29uc3QgREFOVEVfSU5GT19NSU5fTEVOID0gMHhjYyArIDY0IC8vIDI2OCBieXRlcyBcdTIwMTQgbmVlZCBmdWxsIG1vZGVsIGZpZWxkXG5cbi8qKlxuICogQnVpbGRzIGEgRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBwYWNrZXQgKHR5cGUgMHgwMDIwKS5cbiAqXG4gKiBQYWNrZXQgbGF5b3V0ICgzMiBieXRlcykgXHUyMDE0IGRlcml2ZWQgZnJvbSBsaXZlIGNhcHR1cmUgYW5hbHlzaXM6XG4gKiAgIDB4MDAgIHVpbnQxNkJFICBNYWdpYyAoMHhmZmZmKVxuICogICAweDAyICB1aW50MTZCRSAgTWVzc2FnZSB0eXBlICgweDAwMjAgPSBkZXZpY2UgaW5mbyByZXF1ZXN0KVxuICogICAweDA0ICB1aW50MTZCRSAgU2VxdWVuY2UgbnVtYmVyIChyYW5kb20pXG4gKiAgIDB4MDYgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MDggIDYgYnl0ZXMgICBTb3VyY2UgTUFDXG4gKiAgIDB4MGUgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgQVNDSUkgaWRlbnRpZmllclxuICogICAweDE4ICAyIGJ5dGVzICAgUHJvdG9jb2wgdmVyc2lvbiAoMHgwNzM5KVxuICogICAweDFhICAyIGJ5dGVzICAgU3ViLXR5cGUgKDB4MDBjMSlcbiAqICAgMHgxYyAgdWludDMyQkUgIENhcGFiaWxpdHkgbWFzayAoMHgwMDBmNDI0MClcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpOiBCdWZmZXIge1xuXHRjb25zdCBidWYgPSBCdWZmZXIuYWxsb2MoMzIsIDApXG5cdGNvbnN0IHNlcSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDB4ZmZmZilcblxuXHRidWYud3JpdGVVSW50MTZCRSgweGZmZmYsIDApXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKERBTlRFX01TR19JTkZPX1JFUVVFU1QsIDIpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKHNlcSwgNClcblxuXHRjb25zdCBtYWMgPSBnZXRGaXJzdExvY2FsTWFjKClcblx0bWFjLmNvcHkoYnVmLCA4KVxuXG5cdEJ1ZmZlci5mcm9tKCdBdWRpbmF0ZScsICdhc2NpaScpLmNvcHkoYnVmLCAxNilcblx0YnVmLndyaXRlVUludDE2QkUoMHgwNzM5LCAyNClcblx0YnVmLndyaXRlVUludDE2QkUoMHgwMGMxLCAyNilcblx0YnVmLndyaXRlVUludDMyQkUoMHgwMDBmNDI0MCwgMjgpXG5cblx0cmV0dXJuIGJ1ZlxufVxuXG4vKiogUmV0dXJucyB0aGUgZmlyc3Qgbm9uLWxvb3BiYWNrIE1BQyBhcyBhIDYtYnl0ZSBCdWZmZXIsIG9yIHplcm9zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEZpcnN0TG9jYWxNYWMoKTogQnVmZmVyIHtcblx0dHJ5IHtcblx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdGZvciAoY29uc3QgYWRkciBvZiBpZmFjZXNbbmFtZV0gPz8gW10pIHtcblx0XHRcdFx0aWYgKCFhZGRyLmludGVybmFsICYmIGFkZHIuZmFtaWx5ID09PSAnSVB2NCcgJiYgYWRkci5tYWMgJiYgYWRkci5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCcpIHtcblx0XHRcdFx0XHRyZXR1cm4gQnVmZmVyLmZyb20oYWRkci5tYWMuc3BsaXQoJzonKS5tYXAoKGg6IHN0cmluZykgPT4gcGFyc2VJbnQoaCwgMTYpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCB7XG5cdFx0LyogaWdub3JlICovXG5cdH1cblx0cmV0dXJuIEJ1ZmZlci5hbGxvYyg2LCAwKVxufVxuXG4vKipcbiAqIFBhcnNlcyBhIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlICh0eXBlIDB4MDE3MCkgaW50byBhIERldmljZUluZm8uXG4gKlxuICogUmVzcG9uc2UgbGF5b3V0IChrZXkgb2Zmc2V0cyk6XG4gKiAgIDB4MDggIDggYnl0ZXMgICBFVUktNjQgXHUyMDE0IGNvbnZlcnQgdG8gTUFDIGJ5IGRyb3BwaW5nIGJ5dGVzIFszXSBhbmQgWzRdIChmZjpmZSlcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBpZGVudGlmaWVyICh1c2VkIHRvIHZlcmlmeSB0aGlzIGlzIGEgcmVhbCByZXNwb25zZSlcbiAqICAgMHgxOCAgMSBieXRlICAgIERhbnRlIEZXIG1ham9yXG4gKiAgIDB4MTkgIDEgYnl0ZSAgICBEYW50ZSBGVyBtaW5vclxuICogICAweDIwICAzMSBieXRlcyAgRGV2aWNlIG5hbWUgKERhbnRlIGxhYmVsKSwgbnVsbC1wYWRkZWQgQVNDSUkgKG1heCAzMSBjaGFycylcbiAqICAgMHgyZSAgdWludDE2QkUgIFByb2R1Y3QgSURcbiAqICAgMHg0YyAgNjQgYnl0ZXMgIE1hbnVmYWN0dXJlciwgbnVsbC1wYWRkZWQgQVNDSUlcbiAqICAgMHhjYyAgNjQgYnl0ZXMgIE1vZGVsIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqXG4gKiBSZXR1cm5zIG51bGwgaWYgYnVmZmVyIGlzIHRvbyBzaG9ydCwgd3JvbmcgbWFnaWMsIG9yIG1pc3NpbmcgbW9kZWwgc3RyaW5nLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VEYW50ZUluZm9SZXNwb25zZShtc2c6IEJ1ZmZlciwgc3JjSXA6IHN0cmluZyk6IERldmljZUluZm8gfCBudWxsIHtcblx0aWYgKG1zZy5sZW5ndGggPCBEQU5URV9JTkZPX01JTl9MRU4pIHJldHVybiBudWxsXG5cdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmYpIHJldHVybiBudWxsXG5cdGlmIChtc2cucmVhZFVJbnQxNkJFKDIpICE9PSBEQU5URV9NU0dfSU5GT19SRVNQT05TRSkgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm4gbnVsbFxuXG5cdGNvbnN0IHJlYWRTdHIgPSAob2Zmc2V0OiBudW1iZXIsIGxlbjogbnVtYmVyKTogc3RyaW5nID0+XG5cdFx0bXNnXG5cdFx0XHQuc3ViYXJyYXkob2Zmc2V0LCBvZmZzZXQgKyBsZW4pXG5cdFx0XHQudG9TdHJpbmcoJ2FzY2lpJylcblx0XHRcdC5zcGxpdCgnXFwwJylbMF1cblx0XHRcdC50cmltKClcblxuXHRjb25zdCBldWk2NCA9IG1zZy5zdWJhcnJheSg4LCAxNilcblx0Y29uc3QgbWFjQnl0ZXMgPSBbZXVpNjRbMF0sIGV1aTY0WzFdLCBldWk2NFsyXSwgZXVpNjRbNV0sIGV1aTY0WzZdLCBldWk2NFs3XV1cblx0Y29uc3QgbWFjID0gbWFjQnl0ZXMubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKS5qb2luKCc6JylcblxuXHRjb25zdCBuYW1lID0gcmVhZFN0cigweDIwLCAzMSkgLy8gRGFudGUgZGV2aWNlIGxhYmVsIChjYW4gYmUgdXAgdG8gMzEgY2hhcnMgcGVyIERhbnRlIHNwZWMpXG5cdGNvbnN0IG1hbnVmYWN0dXJlciA9IHJlYWRTdHIoMHg0YywgNjQpIC8vIGUuZy4gXCJTdHVkaW8gVGVjaG5vbG9naWVzLCBJbmMuXCJcblx0Y29uc3QgbW9kZWxSYXcgPSByZWFkU3RyKDB4Y2MsIDY0KVxuXHRjb25zdCBkYW50ZUZpcm13YXJlID0gYCR7bXNnWzB4MThdfS4ke21zZ1sweDE5XX1gXG5cblx0aWYgKCFtb2RlbFJhdykgcmV0dXJuIG51bGxcblxuXHQvLyBFeHRyYWN0IGp1c3QgdGhlIG1vZGVsIG51bWJlci9jb2RlIChlLmcuIFwiTW9kZWwgMzkxIEFsZXJ0aW5nIFVuaXRcIiBcdTIxOTIgXCIzOTFcIilcblx0Ly8gU3RyaXAgXCJNb2RlbCBcIiBwcmVmaXgsIHRoZW4gdGFrZSBvbmx5IHRoZSBmaXJzdCB3b3JkICh0aGUgbW9kZWwgbnVtYmVyKVxuXHRjb25zdCBtb2RlbCA9IG1vZGVsUmF3XG5cdFx0LnJlcGxhY2UoL15Nb2RlbFxccysvaSwgJycpXG5cdFx0LnRyaW0oKVxuXHRcdC5zcGxpdCgvXFxzKy8pWzBdXG5cblx0cmV0dXJuIHtcblx0XHRpcDogc3JjSXAsXG5cdFx0bmFtZSxcblx0XHRtYW51ZmFjdHVyZXIsXG5cdFx0bW9kZWwsXG5cdFx0bW9kZWxOYW1lOiBtb2RlbFJhdywgLy8gRnVsbCBtb2RlbCBkZXNjcmlwdGlvblxuXHRcdG1hYyxcblx0XHRkYW50ZUZpcm13YXJlLFxuXHR9XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgTUFDIGFkZHJlc3MgYnl0ZXMgb2YgdGhlIGxvY2FsIGludGVyZmFjZSB1c2VkIHRvIHJvdXRlIHRvIGRlc3RJcC5cbiAqIFVzZXMgYSB0ZW1wb3JhcnkgVURQIGNvbm5lY3QgdG8gbGV0IHRoZSBPUyBzZWxlY3QgdGhlIG91dGdvaW5nIGludGVyZmFjZSxcbiAqIHRoZW4gZmluZHMgdGhlIG1hdGNoaW5nIE1BQyBmcm9tIG9zLm5ldHdvcmtJbnRlcmZhY2VzKCkuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8bnVtYmVyW10+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPG51bWJlcltdPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHR9KVxuXG5cdFx0dG1wLmNvbm5lY3QoOSwgZGVzdElwLCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGFkZHIuYWRkcmVzc1xuXHRcdFx0XHR0bXAuY2xvc2UoKVxuXG5cdFx0XHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRcdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGlmYWNlIG9mIGlmYWNlc1tuYW1lXSA/PyBbXSkge1xuXHRcdFx0XHRcdFx0aWYgKFxuXHRcdFx0XHRcdFx0XHRpZmFjZS5mYW1pbHkgPT09ICdJUHY0JyAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5hZGRyZXNzID09PSBsb2NhbEFkZHIgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UubWFjICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAhPT0gJzAwOjAwOjAwOjAwOjAwOjAwJ1xuXHRcdFx0XHRcdFx0KSB7XG5cdFx0XHRcdFx0XHRcdHJldHVybiByZXNvbHZlKGlmYWNlLm1hYy5zcGxpdCgnOicpLm1hcCgoYikgPT4gcGFyc2VJbnQoYiwgMTYpICYgMHhmZikpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYE5vIGludGVyZmFjZSBmb3VuZCBmb3IgbG9jYWwgYWRkcmVzcyAke2xvY2FsQWRkcn1gKSlcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoU3RyaW5nKF9lKSkpXG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBsb2NhbCBJUCBhZGRyZXNzIHVzZWQgYnkgdGhlIE9TIHRvIHJvdXRlIHRvIGRlc3RJcC5cbiAqIFVzZXMgYSB0ZW1wb3JhcnkgVURQIHNvY2tldCBjb25uZWN0IHRvIGxldCB0aGUgT1Mgc2VsZWN0IHRoZSBvdXRnb2luZyBpbnRlcmZhY2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTxzdHJpbmc+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCB0bXAgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoJ3VkcDQnKVxuXG5cdFx0bGV0IHJlc29sdmVkID0gZmFsc2Vcblx0XHR0bXAub25jZSgnZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gVXNlIGFuIGFyYml0cmFyeSBwb3J0IGZvciBjb25uZWN0OyB3ZSBvbmx5IG5lZWQgdGhlIGtlcm5lbCB0byBhc3NpZ24gYSBsb2NhbCBhZGRyZXNzLlxuXHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgYWRkciA9IHRtcC5hZGRyZXNzKCkgYXMgeyBhZGRyZXNzOiBzdHJpbmcgfVxuXHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3Ncblx0XHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdFx0cmVzb2x2ZShsb2NhbEFkZHIpXG5cdFx0XHRcdH1cblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoU3RyaW5nKF9lKSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuXG4vKipcbiAqIExpc3RlbnMgZm9yIERhbnRlIGRldmljZSBhbm5vdW5jZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsgYW5kIHNlbmRzIHVuaWNhc3RcbiAqIGluZm8gcmVxdWVzdHMgdG8gZWFjaCBkaXNjb3ZlcmVkIElQLiBSZXNwb25zZXMgYXJyaXZlIG9uIHRoZSBjYWxsZXIncyByeFNvY2tldFxuICogdmlhIGhhbmRsZUluY29taW5nKCkgXHUyMTkyIGRpc2NvdmVyeUxpc3RlbmVycy5cbiAqXG4gKiBAcGFyYW0gdHhTb2NrZXQgLSBUaGUgc29ja2V0IHRvIHVzZSBmb3Igc2VuZGluZyBkaXNjb3ZlcnkgcmVxdWVzdHNcbiAqIEBwYXJhbSBlbnN1cmVNZW1iZXJzaGlwIC0gQ2FsbGJhY2sgdG8gZW5zdXJlIG11bHRpY2FzdCBtZW1iZXJzaGlwIGJlZm9yZSBxdWVyeWluZ1xuICogQHBhcmFtIHRpbWVvdXRNcyAtIEhvdyBsb25nIHRvIGxpc3RlbiBmb3IgYW5ub3VuY2VzIGJlZm9yZSByZXNvbHZpbmdcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRpc2NvdmVyRGV2aWNlcyhcblx0dHhTb2NrZXQ6IGRncmFtLlNvY2tldCxcblx0ZW5zdXJlTWVtYmVyc2hpcDogKGRlc3RJcDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+LFxuXHR0aW1lb3V0TXMgPSA1MDAwLFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IERBTlRFX0FOTk9VTkNFX0dST1VQID0gJzIyNC4wLjAuMjMzJ1xuXHRjb25zdCBEQU5URV9BTk5PVU5DRV9QT1JUID0gODcwOFxuXHRjb25zdCBERUZBVUxUX1BPUlQgPSA4NzAwXG5cblx0Y29uc3QgcXVlcmllZElwcyA9IG5ldyBTZXQ8c3RyaW5nPigpXG5cblx0cmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiB7XG5cdFx0Y29uc3QgYW5ub3VuY2VTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0Y29uc3QgY2xlYW51cCA9ICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmRyb3BNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0cmVzb2x2ZSgpXG5cdFx0fVxuXG5cdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KGNsZWFudXAsIHRpbWVvdXRNcylcblx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdGFubm91bmNlU29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci53YXJuKGBBbm5vdW5jZSBzb2NrZXQgZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0Y29uc3Qgc3JjSXAgPSByaW5mby5hZGRyZXNzXG5cdFx0XHQvLyBWYWxpZGF0ZSBpdCdzIGEgRGFudGUgYW5ub3VuY2UgKG1hZ2ljIDB4ZmZmZSArIFwiQXVkaW5hdGVcIiBhdCBvZmZzZXQgMTYpXG5cdFx0XHRpZiAobXNnLmxlbmd0aCA8IDI0KSByZXR1cm5cblx0XHRcdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmUpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm5cblxuXHRcdFx0aWYgKHF1ZXJpZWRJcHMuaGFzKHNyY0lwKSkgcmV0dXJuXG5cdFx0XHRxdWVyaWVkSXBzLmFkZChzcmNJcClcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgQW5ub3VuY2UgZnJvbSAke3NyY0lwfSBcdTIwMTQgc2VuZGluZyB1bmljYXN0IHF1ZXJ5YClcblxuXHRcdFx0Ly8gSm9pbiAyMjQuMC4wLjIzMSBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIHRoaXMgZGV2aWNlIEJFRk9SRSBzZW5kaW5nXG5cdFx0XHQvLyB0aGUgcXVlcnkuIFRoZSBkZXZpY2UgbXVsdGljYXN0cyBpdHMgMHgwMTcwIHJlc3BvbnNlIHRvIDIyNC4wLjAuMjMxOjg3MDJcblx0XHRcdC8vIGluIGFkZGl0aW9uIHRvIHVuaWNhc3RpbmcgaXQgXHUyMDE0IHJ4U29ja2V0IG11c3QgYmUgYSBtZW1iZXIgdG8gcmVjZWl2ZSBpdC5cblx0XHRcdGNvbnN0IHNlbmRRdWVyeSA9IGFzeW5jICgpID0+IHtcblx0XHRcdFx0YXdhaXQgZW5zdXJlTWVtYmVyc2hpcChzcmNJcClcblx0XHRcdFx0Y29uc3QgcXVlcnkgPSBidWlsZERhbnRlSW5mb1JlcXVlc3QoKVxuXHRcdFx0XHR0eFNvY2tldC5zZW5kKHF1ZXJ5LCBERUZBVUxUX1BPUlQsIHNyY0lwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVycikgbG9nZ2VyLndhcm4oYFVuaWNhc3QgcXVlcnkgdG8gJHtzcmNJcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cdFx0XHRzZW5kUXVlcnkoKS5jYXRjaCgoZXJyKSA9PiBsb2dnZXIud2FybihgUXVlcnkgc2V0dXAgZmFpbGVkOiAke2Vycn1gKSlcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQuYmluZChEQU5URV9BTk5PVU5DRV9QT1JULCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhbm5vdW5jZVNvY2tldC5hZGRNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQKVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgTGlzdGVuaW5nIGZvciBEYW50ZSBhbm5vdW5jZXMgb24gJHtEQU5URV9BTk5PVU5DRV9HUk9VUH06JHtEQU5URV9BTk5PVU5DRV9QT1JUfWApXG5cdFx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBqb2luIGFubm91bmNlIG11bHRpY2FzdCBncm91cDogJHtlcnJ9YClcblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuIiwgImltcG9ydCB7XG5cdEluc3RhbmNlVHlwZXMsXG5cdEluc3RhbmNlQmFzZSxcblx0SW5zdGFuY2VTdGF0dXMsXG5cdFNvbWVDb21wYW5pb25Db25maWdGaWVsZCxcblx0Y3JlYXRlTW9kdWxlTG9nZ2VyLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgR2V0Q29uZmlnRmllbGRzLCByZXNvbHZlSG9zdCwgcmVzb2x2ZU1vZGVsLCBnZXREZXZpY2VTY2hlbWEsIHR5cGUgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zLCBVcGRhdGVWYXJpYWJsZVZhbHVlcyB9IGZyb20gJy4vdmFyaWFibGVzLmpzJ1xuaW1wb3J0IHsgVXBncmFkZVNjcmlwdHMgfSBmcm9tICcuL3VwZ3JhZGVzLmpzJ1xuaW1wb3J0IHsgVXBkYXRlQWN0aW9ucyB9IGZyb20gJy4vYWN0aW9ucy5qcydcbmltcG9ydCB7IFVwZGF0ZUZlZWRiYWNrcyB9IGZyb20gJy4vZmVlZGJhY2tzLmpzJ1xuaW1wb3J0IHsgU3RDb250cm9sbGVyIH0gZnJvbSAnLi9zdGNvbnRyb2xsZXIuanMnXG5pbXBvcnQgdHlwZSB7IERldmljZUluZm8gfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ01vZHVsZUluc3RhbmNlJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlVHlwZXMgPSBJbnN0YW5jZVR5cGVzICYge1xuXHRjb25maWc6IE1vZHVsZUNvbmZpZ1xufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNb2R1bGVJbnN0YW5jZSBleHRlbmRzIEluc3RhbmNlQmFzZTxNb2R1bGVUeXBlcz4ge1xuXHRjb25maWchOiBNb2R1bGVDb25maWcgLy8gU2V0dXAgaW4gaW5pdCgpXG5cdHN0Q29udHJvbGxlciE6IFN0Q29udHJvbGxlclxuXG5cdC8qKiBDYWNoZWQgZGlzY292ZXJ5IHJlc3VsdHMgXHUyMDE0IHBhc3NlZCBpbnRvIGdldENvbmZpZ0ZpZWxkcygpIHNvIHRoZSBVSVxuXHQgKiAgY2FuIHNob3cgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIGRyb3Bkb3duIG9uIHN1YnNlcXVlbnQgY29uZmlnIG9wZW5zLiAqL1xuXHRwcml2YXRlIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXVxuXG5cdC8qKiBDdXJyZW50bHkgYWN0aXZlIG1vZGVsIFx1MjAxNCByZXNvbHZlZCBvbmNlIGluIHN5bmNNb2RlbCgpIGFuZCBjYWNoZWQgaGVyZVxuXHQgKiAgc28gVXBkYXRlQWN0aW9ucywgVXBkYXRlRmVlZGJhY2tzIGV0Yy4gZG9uJ3QgZWFjaCBjYWxsIHJlc29sdmVNb2RlbCBpbmRlcGVuZGVudGx5LiAqL1xuXHRhY3RpdmVNb2RlbDogc3RyaW5nID0gJydcblxuXHRjb25zdHJ1Y3RvcihpbnRlcm5hbDogdW5rbm93bikge1xuXHRcdHN1cGVyKGludGVybmFsKVxuXHR9XG5cblx0YXN5bmMgaW5pdChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0aWYgKCF0aGlzLnN0Q29udHJvbGxlcikge1xuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIgPSBuZXcgU3RDb250cm9sbGVyKClcblx0XHR9XG5cdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGluZywgJ0Rpc2NvdmVyaW5nIGRldmljZXMuLi4nKVxuXG5cdFx0Ly8gV2lyZSBmZWVkYmFjayBjYWxsYmFjayBzbyBzdENvbnRyb2xsZXIgY2FuIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlc1xuXHRcdHRoaXMuc3RDb250cm9sbGVyLnNldEZlZWRiYWNrQ2FsbGJhY2soKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4ge1xuXHRcdFx0dGhpcy5jaGVja0ZlZWRiYWNrcyhmZWVkYmFja0lkKVxuXHRcdH0pXG5cblx0XHQvLyBTdGFydCBkaXNjb3ZlcnkgaW4gdGhlIGJhY2tncm91bmQgXHUyMDE0IGFsbCBtb2RlbCByZXNvbHV0aW9uLCBzY2hlbWEgc3luYyxcblx0XHQvLyBhbmQgVUkgdXBkYXRlcyBoYXBwZW4gaW5zaWRlIHJ1bkRpc2NvdmVyeSgpIG9uY2UgdGhlIGRldmljZSBsaXN0IGlzIGtub3duLlxuXHRcdHRoaXMucnVuRGlzY292ZXJ5KCkuY2F0Y2goKGUpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgRGlzY292ZXJ5IGZhaWxlZDogJHtlfWApXG5cdFx0fSlcblx0fVxuXG5cdC8qKlxuXHQgKiBSdW4gZGV2aWNlIGRpc2NvdmVyeSwgdGhlbiByZXNvbHZlIHRoZSBtb2RlbCBhbmQgdXBkYXRlIGFsbCBVSS5cblx0ICogLSBJZiBkaXNjb3ZlcnkgZmluZHMgZGV2aWNlcywgcmVzb2x2ZU1vZGVsIHBpY2tzIGZyb20gdGhvc2UuXG5cdCAqIC0gT25seSBpZiB0aGUgbGlzdCBpcyBlbXB0eSBkbyB3ZSBmYWxsIGJhY2sgdG8gdGhlIG1hbnVhbCBjb25maWcgc2VsZWN0aW9uLlxuXHQgKiBBbGwgYWN0aW9ucy9mZWVkYmFja3MvdmFyaWFibGVzIGFyZSBidWlsdCBhZnRlciB0aGUgbW9kZWwgaXMga25vd24uXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIHJ1bkRpc2NvdmVyeSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRsb2dnZXIuaW5mbygnU3RhcnRpbmcgZGV2aWNlIGRpc2NvdmVyeS4uLicpXG5cblx0XHR0aGlzLmRpc2NvdmVyZWREZXZpY2VzID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIuZGlzY292ZXJEZXZpY2VzKClcblxuXHRcdC8vIERldGVybWluZSBlZmZlY3RpdmUgbW9kZWwgXHUyMDE0IGZyb20gZGlzY292ZXJlZCBkZXZpY2VzIGZpcnN0LCBtYW51YWwgY29uZmlnIG9ubHkgYXMgZmFsbGJhY2tcblx0XHRsZXQgZWZmZWN0aXZlTW9kZWw6IHN0cmluZ1xuXHRcdGlmICh0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0Ly8gSWYgYSBzcGVjaWZpYyBkZXZpY2UgTUFDIHdhcyBzYXZlZCBpbiBjb25maWcsIGl0IHdhc24ndCBmb3VuZCBcdTIwMTQgc3RvcCBoZXJlLlxuXHRcdFx0aWYgKHRoaXMuY29uZmlnLmRldmljZU1hYykge1xuXHRcdFx0XHRjb25zdCBtb2RlbExhYmVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWwgPyBgTW9kZWwgJHt0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbH0gYCA6ICcnXG5cdFx0XHRcdGxvZ2dlci53YXJuKGBTYXZlZCBkZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGR1cmluZyBkaXNjb3ZlcnkgXHUyMDE0IHN0b3BwaW5nYClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsIGAke21vZGVsTGFiZWx9WyR7dGhpcy5jb25maWcuZGV2aWNlTWFjfV0gbm90IGZvdW5kYClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHRjb25zdCBtYW51YWxNb2RlbCA9IHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsXG5cdFx0XHRpZiAoIXRoaXMuY29uZmlnLmhvc3QgfHwgIW1hbnVhbE1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKCdObyBkZXZpY2VzIGRpc2NvdmVyZWQgYW5kIG5vIG1hbnVhbCBJUC9tb2RlbCBjb25maWd1cmVkJylcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHRsb2dnZXIuaW5mbygnTm8gZGV2aWNlcyBkaXNjb3ZlcmVkIFx1MjAxNCB3aWxsIHByb2JlIG1hbnVhbCBJUCBkdXJpbmcgYXV0aG9yaXphdGlvbicpXG5cdFx0XHRlZmZlY3RpdmVNb2RlbCA9IG1hbnVhbE1vZGVsXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBEaXNjb3ZlcmVkICR7dGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGh9IGRldmljZShzKTpgKVxuXHRcdFx0Zm9yIChjb25zdCBkIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSBNb2RlbCAke2QubW9kZWx9ICR7ZC5tYW51ZmFjdHVyZXIgPz8gJyd9IEAgJHtkLmlwfWApXG5cdFx0XHR9XG5cblx0XHRcdC8vIEF1dGhvcml6ZSBhbGwgZGlzY292ZXJlZCBkZXZpY2VzIHNvIGZpcm13YXJlIHJlcXVlc3RzIGNhbiBwcm9jZWVkLlxuXHRcdFx0Ly8gdmVyaWZ5QXV0aG9yaXphdGlvbiAoY2FsbGVkIGJlbG93KSB3aWxsIHJldm9rZSBhbnkgdGhhdCBkb24ndCBtYXRjaFxuXHRcdFx0Ly8gdGhlIGN1cnJlbnQgY29uZmlnIHNlbGVjdGlvbi5cblx0XHRcdGZvciAoY29uc3QgZGV2aWNlIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKGRldmljZS5pcClcblx0XHRcdH1cblxuXHRcdFx0Ly8gUmVxdWVzdCBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gZWFjaCBkaXNjb3ZlcmVkIGRldmljZVxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNvbnN0IGZpcm13YXJlID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2UuaXApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9IGZpcm13YXJlXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSAke2RldmljZS5pcH06IEZpcm13YXJlICR7ZmlybXdhcmV9LCBEYW50ZSAke2RldmljZS5kYW50ZUZpcm13YXJlfWApXG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgICAtICR7ZGV2aWNlLmlwfTogRmFpbGVkIHRvIGdldCBmaXJtd2FyZTogJHtlfWApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9ICdVbmtub3duJ1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdGVmZmVjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKHRoaXMuY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXG5cdFx0XHQvLyBJZiBhIHNwZWNpZmljIE1BQyB3YXMgc2F2ZWQgYnV0IGlzbid0IGluIHRoZSBkaXNjb3ZlcmVkIGxpc3QsIHN0b3AuXG5cdFx0XHRpZiAoIWVmZmVjdGl2ZU1vZGVsICYmIHRoaXMuY29uZmlnLmRldmljZU1hYykge1xuXHRcdFx0XHRjb25zdCBtb2RlbExhYmVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWwgPyBgTW9kZWwgJHt0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbH0gYCA6ICcnXG5cdFx0XHRcdGxvZ2dlci53YXJuKGBTYXZlZCBkZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGFtb25nIGRpc2NvdmVyZWQgZGV2aWNlcyBcdTIwMTQgc3RvcHBpbmdgKVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSwgYCR7bW9kZWxMYWJlbH1bJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XSBub3QgZm91bmRgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBTeW5jIG1vZGVsIHNjaGVtYSB0byBjb250cm9sbGVyXG5cdFx0dGhpcy5zeW5jTW9kZWwoZWZmZWN0aXZlTW9kZWwpXG5cblx0XHQvLyBWZXJpZnkgdGhhdCB0aGUgY3VycmVudGx5IGNvbmZpZ3VyZWQgaG9zdCttb2RlbCBpcyB2YWxpZCBub3cgdGhhdFxuXHRcdC8vIGRpc2NvdmVyeSByZXN1bHRzIGFyZSBrbm93bi4gVGhpcyBpcyB0aGUgc2FtZSBjaGVjayBjb25maWdVcGRhdGVkIHVzZXMuXG5cdFx0Y29uc3QgdGFyZ2V0SG9zdCA9IHRoaXMuaG9zdFxuXHRcdGF3YWl0IHRoaXMudmVyaWZ5QXV0aG9yaXphdGlvbignJywgdGFyZ2V0SG9zdClcblxuXHRcdC8vIEJ1aWxkIGFsbCBVSSBub3cgdGhhdCBtb2RlbCBhbmQgYXV0aG9yaXphdGlvbiBzdGF0ZSBhcmUga25vd25cblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXG5cdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cdFx0bG9nZ2VyLmluZm8oJ0RldmljZSBkaXNjb3ZlcnkgY29tcGxldGUnKVxuXHR9XG5cblx0Ly8gV2hlbiBtb2R1bGUgZ2V0cyBkZWxldGVkXG5cdGFzeW5jIGRlc3Ryb3koKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5zdENvbnRyb2xsZXI/LmNsb3NlKClcblx0XHRsb2dnZXIuZGVidWcoJ2Rlc3Ryb3knKVxuXHR9XG5cblx0YXN5bmMgY29uZmlnVXBkYXRlZChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGNvbnN0IHByZXZpb3VzSG9zdCA9IHRoaXMuaG9zdFxuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0Y29uc3QgZWZmZWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwoY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXG5cdFx0Ly8gQ2xlYXIgdmFyaWFibGVzIGltbWVkaWF0ZWx5IFx1MjAxNCB0aGUgbmV3IHNlbGVjdGlvbiBpc24ndCBhdXRob3JpemVkIHlldC5cblx0XHQvLyBUaGV5J2xsIGJlIHJlcG9wdWxhdGVkIGJlbG93IG9uY2UgdmVyaWZ5QXV0aG9yaXphdGlvbiBjb21wbGV0ZXMuXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cblx0XHRjb25zdCBuZXdIb3N0ID0gdGhpcy5ob3N0XG5cblx0XHQvLyBSZS12ZXJpZnkgYXV0aG9yaXphdGlvbiBvbiBldmVyeSBjb25maWcgY2hhbmdlIChtb2RlbCBvciBJUCkuXG5cdFx0Ly8gVGhpcyBoYW5kbGVzIHN3aXRjaGluZyBmcm9tIGEgdmFsaWQgZGV2aWNlIHRvIGFuIGludmFsaWQgb25lIGFuZCBiYWNrLlxuXHRcdGF3YWl0IHRoaXMudmVyaWZ5QXV0aG9yaXphdGlvbihwcmV2aW91c0hvc3QsIG5ld0hvc3QpXG5cblx0XHQvLyBSZWJ1aWxkIFVJIGFmdGVyIGF1dGhvcml6YXRpb24gc3RhdGUgaXMgc2V0dGxlZFxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cdH1cblxuXHQvKipcblx0ICogUmUtZXZhbHVhdGVzIHdoZXRoZXIgdGhlIGN1cnJlbnQgY29uZmlnIGlzIGF1dGhvcml6ZWQgdG8gc2VuZCBjb21tYW5kcy5cblx0ICpcblx0ICogQXV0byBtb2RlIChkZXZpY2VNYWMgc2V0KTpcblx0ICogICAtIEZpbmQgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIHdpdGggbWF0Y2hpbmcgTUFDIFx1MjE5MiBnZXQgaXRzIGN1cnJlbnQgSVBcblx0ICogICAtIFJldm9rZSB0aGUgcHJldmlvdXMgSVAsIGF1dGhvcml6ZSB0aGUgbmV3IElQXG5cdCAqICAgLSBJZiBNQUMgbm90IGZvdW5kIGluIGRpc2NvdmVyeSwgcmV2b2tlIGFuZCBibG9ja1xuXHQgKlxuXHQgKiBNYW51YWwgbW9kZSAoZGV2aWNlTWFjIGVtcHR5KTpcblx0ICogICAtIENoZWNrIGRpc2NvdmVyZWQgbGlzdCBieSBJUCttb2RlbCBtYXRjaCwgb3IgcHJvYmUgZGlyZWN0bHlcblx0ICovXG5cdHByaXZhdGUgYXN5bmMgdmVyaWZ5QXV0aG9yaXphdGlvbihwcmV2aW91c0hvc3Q6IHN0cmluZywgbmV3SG9zdDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0aWYgKCFuZXdIb3N0KSB7XG5cdFx0XHRpZiAocHJldmlvdXNIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY29uZmlnLmRldmljZU1hYykge1xuXHRcdFx0Ly8gQXV0byBtb2RlIFx1MjAxNCBtYXRjaCBieSBNQUMsIHVzZSB3aGF0ZXZlciBJUCBkaXNjb3ZlcnkgZm91bmQgaXQgYXRcblx0XHRcdGNvbnN0IGRldmljZSA9IHRoaXMuZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5tYWMgPT09IHRoaXMuY29uZmlnLmRldmljZU1hYylcblx0XHRcdGlmICghZGV2aWNlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBEZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGluIGN1cnJlbnQgZGlzY292ZXJ5IFx1MjAxNCBub3QgYXV0aG9yaXppbmdgKVxuXHRcdFx0XHRpZiAocHJldmlvdXNIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdH1cblx0XHRcdGNvbnN0IHdhc0F1dGhvcml6ZWQgPSB0aGlzLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQobmV3SG9zdClcblx0XHRcdGlmICghd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdH1cblx0XHRcdGlmIChuZXdIb3N0ICE9PSBwcmV2aW91c0hvc3QgfHwgIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKGRldmljZS5tb2RlbCwgbmV3SG9zdClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIE1hbnVhbCBtb2RlIFx1MjAxNCBjb25maWcuaG9zdCArIGNvbmZpZy5hY3RpdmVNb2RlbCBtdXN0IG1hdGNoXG5cdFx0Y29uc3QgbWFudWFsTW9kZWwgPSBTdHJpbmcodGhpcy5jb25maWcuYWN0aXZlTW9kZWwgPz8gJycpXG5cdFx0Y29uc3QgZGlzY292ZXJlZEF0SXAgPSB0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQuaXAgPT09IG5ld0hvc3QpXG5cblx0XHRpZiAoZGlzY292ZXJlZEF0SXApIHtcblx0XHRcdGlmIChkaXNjb3ZlcmVkQXRJcC5tb2RlbCA9PT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRcdGNvbnN0IHdhc0F1dGhvcml6ZWQgPSB0aGlzLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQobmV3SG9zdClcblx0XHRcdFx0aWYgKCF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCB8fCAhd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRcdGF3YWl0IHRoaXMuZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtYW51YWxNb2RlbCwgbmV3SG9zdClcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0bG9nZ2VyLmVycm9yKFxuXHRcdFx0XHRcdGBEZXZpY2Ugc2VsZWN0ZWQgKE1vZGVsICR7bWFudWFsTW9kZWx9KSBkb2VzIG5vdCBtYXRjaCBkZXRlY3RlZCBkZXZpY2UgKE1vZGVsICR7ZGlzY292ZXJlZEF0SXAubW9kZWx9KSBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYCxcblx0XHRcdFx0KVxuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UobmV3SG9zdClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoXG5cdFx0XHRcdFx0SW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsXG5cdFx0XHRcdFx0YE1vZGVsIG1pc21hdGNoOiBleHBlY3RlZCAke21hbnVhbE1vZGVsfSwgZ290ICR7ZGlzY292ZXJlZEF0SXAubW9kZWx9YCxcblx0XHRcdFx0KVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gSVAgbm90IGluIGRpc2NvdmVyZWQgbGlzdCBcdTIwMTQgcHJvYmUgaXQgZGlyZWN0bHkgdmlhIERhbnRlXG5cdFx0bG9nZ2VyLmluZm8oYCR7bmV3SG9zdH0gbm90IGluIGRpc2NvdmVyZWQgbGlzdCBcdTIwMTQgcHJvYmluZ2ApXG5cdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKG5ld0hvc3QpXG5cblx0XHRjb25zdCBwcm9iZWQgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5wcm9iZURldmljZShuZXdIb3N0KVxuXHRcdGlmICghcHJvYmVkKSB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYE5vIGRldmljZSByZXNwb25kZWQgYXQgJHtuZXdIb3N0fSBcdTIwMTQgY29tbWFuZHMgYmxvY2tlZGApXG5cdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Vbmtub3duV2FybmluZywgYERldmljZSBvZmZsaW5lOiAke25ld0hvc3R9YClcblx0XHR9IGVsc2UgaWYgKHByb2JlZC5tb2RlbCAhPT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihcblx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtwcm9iZWQubW9kZWx9KSBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYCxcblx0XHRcdClcblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKFxuXHRcdFx0XHRJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSxcblx0XHRcdFx0YE1vZGVsIG1pc21hdGNoOiBleHBlY3RlZCAke21hbnVhbE1vZGVsfSwgZ290ICR7cHJvYmVkLm1vZGVsfWAsXG5cdFx0XHQpXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBWZXJpZmllZCBNb2RlbCAke3Byb2JlZC5tb2RlbH0gYXQgJHtuZXdIb3N0fWApXG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdGF3YWl0IHRoaXMuZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtYW51YWxNb2RlbCwgbmV3SG9zdClcblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLk9rKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBGZXRjaGVzIGFsbCBzZXR0aW5ncyBmcm9tIHRoZSBkZXZpY2UuIElmIG5vIHNjaGVtYSBleGlzdHMgZm9yIHRoZSBtb2RlbCxcblx0ICogY3JlYXRlcyBvbmUgZnJvbSB0aGUgcmVzcG9uc2UgYW5kIHJlbG9hZHMgdGhlIHNjaGVtYSBjYWNoZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtb2RlbDogc3RyaW5nLCBpcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0aWYgKCFnZXREZXZpY2VTY2hlbWEobW9kZWwpKSB7XG5cdFx0XHRcdC8vIE5vIHNjaGVtYSBleGlzdHMgXHUyMDE0IGRvIE5PVCBhdXRvLWNyZWF0ZSBvbmUgaGVyZS5cblx0XHRcdFx0Ly8gVGhlIHVzZXIgbXVzdCBydW4gXCJHTE9CQUw6IEdldCBBbGwgU2V0dGluZ3NcIiB0byBjcmVhdGUgaXQuXG5cdFx0XHRcdGxvZ2dlci53YXJuKGBObyBzY2hlbWEgZm91bmQgZm9yIE1vZGVsICR7bW9kZWx9IFx1MjAxNCBydW4gXCJHTE9CQUw6IEdldCBBbGwgU2V0dGluZ3NcIiB0byBjcmVhdGUgb25lYClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBmZXRjaCBzZXR0aW5ncyBmcm9tICR7aXB9OiAke2V9YClcblx0XHR9XG5cdH1cblxuXHQvKiogTG9hZHMgdGhlIGRldmljZSBKU09OIGZvciB0aGUgZ2l2ZW4gbW9kZWwsIGNhY2hlcyBpdCBhcyBhY3RpdmVNb2RlbCwgYW5kIHB1c2hlcyBpdCB0byB0aGUgY29udHJvbGxlci4gKi9cblx0cHJpdmF0ZSBzeW5jTW9kZWwobW9kZWw6IHN0cmluZyk6IHZvaWQge1xuXHRcdHRoaXMuYWN0aXZlTW9kZWwgPSBtb2RlbFxuXHRcdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0XHRpZiAoIXNjaGVtYSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYE1vZGVsIFwiJHttb2RlbH1cIiBub3QgZm91bmQgaW4gZGV2aWNlIHNjaGVtYXNgKVxuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0TW9kZWwobW9kZWwsIFtdLCB0cnVlKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Y29uc3QgYWN0aW9ucyA9IEFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkgPyBzY2hlbWEuY21kU2NoZW1hIDogW11cblx0XHRjb25zdCByZWZyZXNoQWZ0ZXJDb21tYW5kID0gc2NoZW1hLnJlZnJlc2hBZnRlckNvbW1hbmQgPz8gdHJ1ZVxuXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0TW9kZWwobW9kZWwsIGFjdGlvbnMsIHJlZnJlc2hBZnRlckNvbW1hbmQpXG5cdFx0aWYgKGFjdGlvbnMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTm8gYWN0aW9ucyBmb3VuZCBmb3IgbW9kZWwgXCIke21vZGVsfVwiIFx1MjAxNCBzZXR0aW5ncyBkZWNvZGluZyB3aWxsIHVzZSByYXcgSURzYClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKFxuXHRcdFx0XHRgTG9hZGVkICR7YWN0aW9ucy5sZW5ndGh9IGFjdGlvbnMgZm9yIG1vZGVsIFwiJHttb2RlbH1cIiwgc2VjdGlvbmVkPSR7c2NoZW1hLnNlY3Rpb25lZH0sIHJlZnJlc2hBZnRlckNvbW1hbmQ9JHtyZWZyZXNoQWZ0ZXJDb21tYW5kfWAsXG5cdFx0XHQpXG5cdFx0fVxuXHR9XG5cblx0Z2V0Q29uZmlnRmllbGRzKCk6IFNvbWVDb21wYW5pb25Db25maWdGaWVsZFtdIHtcblx0XHRyZXR1cm4gR2V0Q29uZmlnRmllbGRzKHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdH1cblxuXHQvKiogUmV0dXJucyB0aGUgZWZmZWN0aXZlIGhvc3QgSVAsIHJlc29sdmVkIGZyb20gTUFDXHUyMTkySVAgdmlhIGRpc2NvdmVyZWREZXZpY2VzIChhdXRvKSBvciBjb25maWcuaG9zdCAobWFudWFsKS4gKi9cblx0Z2V0IGhvc3QoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gcmVzb2x2ZUhvc3QodGhpcy5jb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdH1cblxuXHQvKiogUmV0dXJucyBkaXNjb3ZlcmVkIGRldmljZXMgZm9yIHVzZSBpbiBhY3Rpb25zL2NvbmZpZyAqL1xuXHRnZXQgZGV2aWNlcygpOiBEZXZpY2VJbmZvW10ge1xuXHRcdHJldHVybiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzXG5cdH1cblxuXHR1cGRhdGVBY3Rpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZUFjdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZUZlZWRiYWNrcygpOiB2b2lkIHtcblx0XHRVcGRhdGVGZWVkYmFja3ModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlVmFyaWFibGVWYWx1ZXMoKTogdm9pZCB7XG5cdFx0VXBkYXRlVmFyaWFibGVWYWx1ZXModGhpcylcblx0fVxufVxuXG5leHBvcnQgeyBVcGdyYWRlU2NyaXB0cyB9XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7OztBQWtCQSxJQUFNLHFCQUFrQyxDQUFDLFFBQVEsT0FBTyxZQUFXO0FBRWxFLFVBQVEsSUFBSSxJQUFJLE1BQU0sWUFBVyxDQUFFLElBQUksU0FBUyxLQUFLLE1BQU0sTUFBTSxFQUFFLElBQUksT0FBTyxFQUFFO0FBQ2pGO0FBRUEsU0FBUyxVQUFVLFFBQTRCLE9BQWlCLFNBQWU7QUFDOUUsUUFBTSxPQUFPLE9BQU8sT0FBTyxxQkFBcUIsYUFBYSxPQUFPLG1CQUFtQjtBQUN2RixPQUFLLFFBQVEsT0FBTyxPQUFPO0FBQzVCO0FBT00sU0FBVSxtQkFBbUIsUUFBZTtBQUNqRCxTQUFPO0lBQ04sT0FBTyxDQUFDLFlBQW9CLFVBQVUsUUFBUSxTQUFTLE9BQU87SUFDOUQsTUFBTSxDQUFDLFlBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU87SUFDNUQsTUFBTSxDQUFDLFlBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU87SUFDNUQsT0FBTyxDQUFDLFlBQW9CLFVBQVUsUUFBUSxTQUFTLE9BQU87O0FBRWhFOzs7QUNUTSxTQUFVLFlBQVksTUFBVztBQUV2Qzs7O0FDaENBLFNBQVMsb0JBQW9CO0FBMkV2QixJQUFPLHNCQUFQLGNBQW1DLGFBQW1DO0VBQ2xFO0VBQ0E7RUFFVCxJQUFXLFdBQVE7QUFDbEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFDQSxJQUFXLGFBQVU7QUFDcEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFFQSxJQUFZLGFBQVU7QUFDckIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtBQUNuRCxhQUFPLEtBQUs7SUFDYixPQUFPO0FBQ04sYUFBTztJQUNSO0VBQ0Q7RUFFQSxTQUF1RTtFQUV2RSxZQUFZLFNBQXlDLFNBQStCO0FBQ25GLFVBQUs7QUFFTCxTQUFLLFdBQVc7QUFDaEIsU0FBSyxXQUFXLEVBQUUsR0FBRyxRQUFPO0VBQzdCO0VBRUEsS0FBSyxNQUFjLFVBQW1CLFVBQXFCO0FBQzFELFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0seUJBQXlCO0FBQzdGLFlBQVEsS0FBSyxRQUFRO01BQ3BCLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxvQ0FBb0M7TUFDckQsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLHlCQUF5QjtNQUMxQyxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sbUJBQW1CO01BQ3BDLEtBQUs7QUFDSjtNQUNEO0FBQ0Msb0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGNBQU0sSUFBSSxNQUFNLHNCQUFzQjtJQUN4QztBQUVBLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsYUFBYSxRQUFRO0FBRTNDLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsUUFBUSxLQUFLLFNBQVM7TUFDdEIsWUFBWTs7S0FFWixFQUNBLEtBQ0EsQ0FBQyxhQUFZO0FBQ1osV0FBSyxTQUFTLEVBQUUsWUFBWSxNQUFNLFNBQVE7QUFDMUMsV0FBSyxTQUFTLHdCQUF3QixJQUFJLFVBQVUsSUFBSTtBQUN4RCxXQUFLLEtBQUssV0FBVztJQUN0QixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUztBQUNkLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEsTUFBTSxVQUFxQjtBQUMxQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0lBRXBELE9BQU87QUFDTixjQUFRLEtBQUssUUFBUTtRQUNwQixLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9DQUFvQztRQUNyRCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0JBQW9CO1FBQ3JDO0FBQ0Msc0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGdCQUFNLElBQUksTUFBTSxzQkFBc0I7TUFDeEM7SUFDRDtBQUVBLFVBQU0sV0FBVyxLQUFLLE9BQU87QUFDN0IsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxTQUFTLFFBQVE7QUFFdkMsU0FBSyxTQUNILHFCQUFxQjtNQUNyQjtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLE9BQU87SUFDbEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQVdBLEtBQ0MsY0FDQSxjQUNBLGlCQUNBLGdCQUNBLFNBQ0EsVUFBcUI7QUFFckIsUUFBSSxPQUFPLGlCQUFpQjtBQUFVLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUN6RSxRQUFJLE9BQU8sb0JBQW9CLFVBQVU7QUFDeEMsVUFBSSxPQUFPLG1CQUFtQixZQUFZLE9BQU8sWUFBWTtBQUFVLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUMxRyxVQUFJLGFBQWEsVUFBYSxPQUFPLGFBQWE7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFakcsWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLGNBQWMsZUFBZTtBQUM5RSxXQUFLLFdBQVcsUUFBUSxnQkFBZ0IsU0FBUyxRQUFRO0lBQzFELFdBQVcsT0FBTyxvQkFBb0IsVUFBVTtBQUMvQyxVQUFJLG1CQUFtQixVQUFhLE9BQU8sbUJBQW1CO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRTdHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxHQUFHLE1BQVM7QUFDN0QsV0FBSyxXQUFXLFFBQVEsY0FBYyxpQkFBaUIsY0FBYztJQUN0RSxPQUFPO0FBQ04sWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0lBQ3BDO0VBQ0Q7RUFFQSxlQUNDLGNBQ0EsUUFDQSxRQUEwQjtBQUUxQixRQUFJO0FBQ0osUUFBSSxPQUFPLGlCQUFpQixVQUFVO0FBQ3JDLGVBQVMsT0FBTyxLQUFLLGNBQWMsT0FBTztJQUMzQyxXQUFXLE9BQU8sU0FBUyxZQUFZLEdBQUc7QUFDekMsZUFBUztJQUNWLFdBQVcsTUFBTSxRQUFRLFlBQVksR0FBRztBQUV2QyxhQUFPLE9BQU8sS0FBSyxZQUFZO0lBQ2hDLE9BQU87QUFDTixlQUFTLE9BQU8sS0FBSyxhQUFhLFFBQVEsYUFBYSxZQUFZLGFBQWEsVUFBVTtJQUMzRjtBQUVBLFdBQU8sT0FBTyxTQUFTLFFBQVEsV0FBVyxTQUFZLFNBQVMsU0FBUyxNQUFTO0VBQ2xGO0VBRUEsV0FBVyxRQUFnQixNQUFjLFNBQWlCLFVBQXFCO0FBQzlFLFFBQUksQ0FBQyxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFFekYsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixVQUFVLEtBQUssT0FBTztNQUN0QixTQUFTO01BRVQ7TUFDQTtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osaUJBQVU7SUFDWCxHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEscUJBQXFCLFNBQStCO0FBQ25ELFFBQUk7QUFDSCxXQUFLLEtBQUssV0FBVyxRQUFRLFNBQVMsUUFBUSxNQUFNO0lBQ3JELFNBQVMsSUFBSTtJQUViO0VBQ0Q7RUFDQSxtQkFBbUIsT0FBWTtBQUM5QixTQUFLLFNBQVM7QUFFZCxVQUFNLGFBQWEsS0FBSztBQUN4QixRQUFJO0FBQVksV0FBSyxTQUFTLHdCQUF3QixPQUFPLFdBQVcsUUFBUTtBQUVoRixRQUFJO0FBQ0gsV0FBSyxLQUFLLFNBQVMsS0FBSztJQUN6QixTQUFTLElBQUk7SUFFYjtFQUNEOzs7O0FDOVBLLFNBQVUsa0JBQW1ELEtBQVk7QUFDOUUsUUFBTSxPQUFPO0FBQ2IsU0FBTyxDQUFDLENBQUMsUUFBUSxPQUFPLFNBQVMsWUFBWSxPQUFPLEtBQUssT0FBTyxZQUFZLEtBQUssdUJBQXVCO0FBQ3pHOzs7QUM2Qk0sSUFBZ0IsZUFBaEIsTUFBNEI7RUFDeEI7RUFDQTtFQUVBO0VBRVQsSUFBVyxLQUFFO0FBQ1osV0FBTyxLQUFLLFNBQVM7RUFDdEI7RUFFQSxJQUFXLGtCQUFlO0FBQ3pCLFdBQU8sS0FBSztFQUNiOzs7OztFQU1BLElBQVcsUUFBSztBQUNmLFdBQU8sS0FBSyxTQUFTO0VBQ3RCOzs7O0VBS0EsWUFBWSxVQUFpQjtBQUM1QixRQUFJLENBQUMsa0JBQTZCLFFBQVEsS0FBSyxDQUFDLFNBQVM7QUFDeEQsWUFBTSxJQUFJLE1BQ1QsbUdBQW1HO0FBR3JHLFNBQUssV0FBVztBQUVoQixTQUFLLFVBQVUsbUJBQWtCO0FBRWpDLFNBQUssd0JBQXdCLEtBQUssc0JBQXNCLEtBQUssSUFBSTtBQUVqRSxTQUFLLFdBQVc7TUFDZiwyQkFBMkI7TUFDM0Isd0JBQXdCOztBQUd6QixTQUFLLElBQUksU0FBUyxjQUFjO0VBQ2pDO0VBK0JBLFdBQVcsV0FBNEMsWUFBaUM7QUFDdkYsU0FBSyxTQUFTLFdBQVcsV0FBVyxVQUFVO0VBQy9DOzs7OztFQXVCQSxxQkFBcUIsU0FBeUQ7QUFDN0UsU0FBSyxTQUFTLHFCQUFxQixPQUFPO0VBQzNDOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7OztFQU9BLHFCQUNDLFdBQ0EsU0FBOEM7QUFFOUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXLE9BQU87RUFDdEQ7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFFBQUksTUFBTSxRQUFRLFNBQVM7QUFBRyxZQUFNLElBQUksTUFBTSx3REFBd0Q7QUFFdEcsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7OztFQU1BLGtCQUFrQixRQUF1QztBQUN4RCxTQUFLLFNBQVMsa0JBQWtCLE1BQU07RUFDdkM7Ozs7OztFQU9BLGlCQUFtQyxZQUFhO0FBQy9DLFdBQU8sS0FBSyxTQUFTLGlCQUFpQixVQUFVO0VBQ2pEOzs7O0VBS0Esb0JBQWlCO0FBQ2hCLFNBQUssU0FBUyxrQkFBaUI7RUFDaEM7Ozs7Ozs7RUFRQSxlQUNDLGlCQUNHLGVBQW1EO0FBRXRELFNBQUssU0FBUyxlQUFlLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQztFQUM5RDs7Ozs7RUFNQSxzQkFBc0IsYUFBcUI7QUFDMUMsU0FBSyxTQUFTLG1CQUFtQixXQUFXO0VBQzdDOzs7Ozs7RUFPQSxvQkFBb0IsV0FBbUI7QUFDdEMsU0FBSyxTQUFTLGlCQUFpQixTQUFTO0VBQ3pDOzs7Ozs7RUFNQSxzQkFBc0IsV0FBbUI7QUFDeEMsU0FBSyxTQUFTLG1CQUFtQixTQUFTO0VBQzNDOzs7Ozs7RUFPQSx3QkFBd0IsYUFBcUI7QUFDNUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXO0VBQy9DOzs7Ozs7RUFPQSxhQUFhLFFBQWlDLGNBQXFCO0FBQ2xFLFNBQUssU0FBUyxhQUFhLFFBQVEsWUFBWTtFQUNoRDs7Ozs7Ozs7RUFTQSxRQUFRLE1BQWMsTUFBY0EsT0FBYyxNQUFzQjtBQUN2RSxTQUFLLFNBQVMsUUFBUSxNQUFNLE1BQU1BLE9BQU0sSUFBSTtFQUM3Qzs7Ozs7Ozs7Ozs7RUFZQSxhQUFhLFFBQXdCLFNBQXVCO0FBQzNELFNBQUssU0FBUyxhQUFhLFFBQVEsV0FBVyxJQUFJO0VBQ25EOzs7Ozs7RUFPQSxJQUFJLE9BQWlCLFNBQWU7QUFDbkMsWUFBUSxPQUFPO01BQ2QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRDtBQUNDLG9CQUFZLEtBQUs7QUFDakIsYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtJQUNGO0VBQ0Q7RUFZQSxzQkFDQyxlQUNBLFVBQXlDO0FBRXpDLFVBQU0sVUFBa0MsT0FBTyxrQkFBa0IsV0FBVyxFQUFFLE1BQU0sY0FBYSxJQUFLO0FBRXRHLFVBQU0sU0FBUyxJQUFJLG9CQUFvQixLQUFLLFVBQVUsT0FBTztBQUM3RCxRQUFJO0FBQVUsYUFBTyxHQUFHLFdBQVcsUUFBUTtBQUUzQyxXQUFPO0VBQ1I7Ozs7QUMvVUQsSUFBWTtDQUFaLFNBQVlDLGlCQUFjO0FBQ3pCLEVBQUFBLGdCQUFBLElBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFlBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLG1CQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxXQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxnQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsdUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHlCQUFBLElBQUE7QUFDRCxHQVZZLG1CQUFBLGlCQUFjLENBQUEsRUFBQTtBQWFwQixJQUFXO0NBQWpCLFNBQWlCQyxRQUFLO0FBRVIsRUFBQUEsT0FBQSxLQUFLO0FBQ0wsRUFBQUEsT0FBQSxXQUNaO0FBQ1ksRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxPQUNaO0FBQ1ksRUFBQUEsT0FBQSxjQUFjO0FBQ2QsRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxRQUFRO0FBQ1IsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxTQUFTO0FBQ1QsRUFBQUEsT0FBQSxnQkFBZ0I7QUFDaEIsRUFBQUEsT0FBQSxZQUFZO0FBQ1osRUFBQUEsT0FBQSxXQUNaO0FBQ0YsR0FsQmlCLFVBQUEsUUFBSyxDQUFBLEVBQUE7OztBQ2pCdEIsT0FBTyxRQUFRO0FBQ2YsT0FBTyxVQUFVO0FBSWpCLElBQU0sU0FBUyxtQkFBbUIsUUFBUTtBQXVCMUMsU0FBUyx1QkFBb0I7QUFDNUIsUUFBTSxjQUFjLEtBQUssS0FBSyxZQUFZLFNBQVMsWUFBWTtBQUMvRCxRQUFNLGVBQWUsS0FBSyxLQUFLLFlBQVksU0FBUyxXQUFXO0FBRy9ELE1BQUksR0FBRyxXQUFXLFdBQVcsR0FBRztBQUMvQixXQUFPLE1BQU0seUJBQXlCLFdBQVcsRUFBRTtBQUNuRCxXQUFPO0VBQ1I7QUFHQSxNQUFJLEdBQUcsV0FBVyxZQUFZLEdBQUc7QUFDaEMsV0FBTyxLQUFLLHFEQUFxRCxZQUFZLEVBQUU7QUFDL0UsV0FBTztFQUNSO0FBR0EsUUFBTSxXQUFXOztNQUEwQyxXQUFXO01BQVMsWUFBWTs7QUFDM0YsU0FBTyxNQUFNLFFBQVE7QUFDckIsUUFBTSxJQUFJLE1BQU0sUUFBUTtBQUN6QjtBQUdBLElBQU0sZ0JBQWdCLHFCQUFvQjtBQUcxQyxJQUFJLHFCQUFpRDtBQU0vQyxTQUFVLG1CQUFnQjtBQUMvQixTQUFPO0FBQ1I7QUFNQSxTQUFTLG9CQUFpQjtBQUN6QixRQUFNLFVBQStCLENBQUE7QUFDckMsTUFBSTtBQUNILFVBQU0sUUFBUSxHQUFHLFlBQVksYUFBYSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxPQUFPLENBQUM7QUFFN0UsZUFBVyxLQUFLLE9BQU87QUFDdEIsWUFBTSxXQUFXLEtBQUssS0FBSyxlQUFlLENBQUM7QUFDM0MsWUFBTSxPQUFPLEtBQUssTUFBTSxHQUFHLGFBQWEsVUFBVSxNQUFNLENBQUM7QUFDekQsVUFBSSxNQUFNLE9BQU87QUFDaEIsZ0JBQVEsT0FBTyxLQUFLLEtBQUssQ0FBQyxJQUFJO01BQy9CO0lBQ0Q7QUFFQSxXQUFPLE1BQU0sVUFBVSxPQUFPLEtBQUssT0FBTyxFQUFFLE1BQU0sNEJBQTRCO0VBQy9FLFNBQVMsR0FBRztBQUNYLFdBQU8sTUFBTSxrQ0FBa0MsQ0FBQyxFQUFFO0VBQ25EO0FBQ0EsU0FBTztBQUNSO0FBTU0sU0FBVSxtQkFBZ0I7QUFDL0IsTUFBSSxDQUFDLG9CQUFvQjtBQUN4Qix5QkFBcUIsa0JBQWlCO0VBQ3ZDO0FBQ0EsU0FBTztBQUNSO0FBTU0sU0FBVSxnQkFBZ0IsT0FBYTtBQUM1QyxRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFNBQU8sUUFBUSxLQUFLO0FBQ3JCO0FBTU0sU0FBVSxzQkFBbUI7QUFDbEMsU0FBTyxLQUFLLHVDQUF1QztBQUNuRCx1QkFBcUIsa0JBQWlCO0FBQ3ZDO0FBS0EsU0FBUyxzQkFBbUI7QUFDM0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxTQUFPLE9BQU8sS0FBSyxPQUFPLEVBQUUsS0FBSTtBQUNqQztBQUVNLFNBQVUsZ0JBQWdCLG9CQUFrQyxDQUFBLEdBQUU7QUFDbkUsUUFBTSxTQUFTLG9CQUFtQjtBQUlsQyxRQUFNLGdCQUFnQjtJQUNyQixFQUFFLElBQUksSUFBSSxPQUFPLGtDQUFpQztJQUNsRCxHQUFHLGtCQUFrQixJQUFJLENBQUMsT0FBTztNQUNoQyxJQUFJLEVBQUUsT0FBTztNQUNiLE9BQU8sU0FBUyxFQUFFLEtBQUssS0FBSyxFQUFFLEdBQUcsT0FBTyxFQUFFLEVBQUU7TUFDM0M7O0FBR0gsU0FBTzs7O0lBR047TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULFNBQVM7TUFDVCxTQUFTOzs7SUFJVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsT0FBTyxNQUFNO01BQ2IscUJBQXFCO01BQ3JCLFNBQVM7OztJQUlWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVMsT0FBTyxDQUFDLEtBQUs7TUFDdEIsU0FBUyxPQUFPLElBQUksQ0FBQyxXQUFXO1FBQy9CLElBQUk7UUFDSixPQUFPLFNBQVMsS0FBSztRQUNwQjtNQUNGLHFCQUFxQjtNQUNyQixTQUFTOzs7QUFHWjtBQU9NLFNBQVUsWUFBWSxRQUFzQixtQkFBK0I7QUFDaEYsTUFBSSxPQUFPLFdBQVc7QUFDckIsVUFBTSxTQUFTLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsT0FBTyxTQUFTO0FBQ3ZFLFdBQU8sUUFBUSxNQUFNO0VBQ3RCO0FBQ0EsU0FBTyxPQUFPLE9BQU8sUUFBUSxFQUFFO0FBQ2hDO0FBT00sU0FBVSxhQUFhLFFBQXNCLG1CQUErQjtBQUNqRixNQUFJLE9BQU8sV0FBVztBQUNyQixVQUFNLFNBQVMsa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxPQUFPLFNBQVM7QUFDdkUsV0FBTyxNQUFNLDRCQUE0QixPQUFPLFNBQVMsb0JBQW9CLFFBQVEsU0FBUyxNQUFNLEVBQUU7QUFDdEcsV0FBTyxRQUFRLFNBQVM7RUFDekI7QUFDQSxTQUFPLE1BQU0sMkNBQTJDLE9BQU8sV0FBVyxHQUFHO0FBQzdFLFNBQU8sT0FBTyxPQUFPLGVBQWUsRUFBRTtBQUN2Qzs7O0FDeE1NLFNBQVUsMEJBQTBCLE1BQW9CO0FBQzdELE9BQUssdUJBQXVCO0lBQzNCLE9BQU8sRUFBRSxNQUFNLHNCQUFxQjtJQUNwQyxXQUFXLEVBQUUsTUFBTSx1Q0FBc0M7SUFDekQsY0FBYyxFQUFFLE1BQU0sc0JBQXFCO0lBQzNDLFVBQVUsRUFBRSxNQUFNLDBCQUF5QjtJQUMzQyxTQUFTLEVBQUUsTUFBTSxnQ0FBK0I7SUFDaEQsS0FBSyxFQUFFLE1BQU0scUJBQW9CO0lBQ2pDLElBQUksRUFBRSxNQUFNLG9CQUFtQjtHQUMvQjtBQUNGO0FBRUEsSUFBTSxvQkFBb0I7RUFDekIsT0FBTztFQUNQLFdBQVc7RUFDWCxjQUFjO0VBQ2QsVUFBVTtFQUNWLFNBQVM7RUFDVCxLQUFLO0VBQ0wsSUFBSTs7QUFRQyxTQUFVLHFCQUFxQixNQUFvQjtBQUN4RCxRQUFNLGNBQWMsS0FBSztBQUd6QixNQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssYUFBYSxtQkFBbUIsV0FBVyxHQUFHO0FBQ3ZFLFNBQUssa0JBQWtCLGlCQUFpQjtBQUN4QztFQUNEO0FBRUEsUUFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sV0FBVztBQUM1RCxNQUFJLFFBQVE7QUFDWCxTQUFLLGtCQUFrQjtNQUN0QixPQUFPLE9BQU8sU0FBUztNQUN2QixXQUFXLE9BQU8sYUFBYTtNQUMvQixjQUFjLE9BQU8sZ0JBQWdCO01BQ3JDLFVBQVUsT0FBTyxnQkFBZ0I7TUFDakMsU0FBUyxPQUFPLGlCQUFpQjtNQUNqQyxLQUFLLE9BQU8sT0FBTztNQUNuQixJQUFJLE9BQU87S0FDWDtFQUNGLE9BQU87QUFHTixTQUFLLGtCQUFrQjtNQUN0QixHQUFHO01BQ0gsSUFBSTtLQUNKO0VBQ0Y7QUFDRDs7O0FDMURPLElBQU0saUJBQStEOzs7Ozs7Ozs7Ozs7Ozs7QUNxQnJFLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sY0FBYztBQUNwQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sYUFBYTtBQUNuQixJQUFNLHVCQUF1QjtBQUM3QixJQUFNLG9CQUFvQjtBQUMxQixJQUFNLGVBQWU7QUFDckIsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxjQUFjO0FBR3JCLFNBQVUsZUFBZSxPQUFhO0FBQzNDLFVBQVEsT0FBTztJQUNkLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUjtBQUNDLGFBQU8sU0FBUyxNQUFNLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUM7RUFDckQ7QUFDRDtBQVFNLFNBQVUsY0FDZixPQUNBLE9BQ0EsV0FDQSxPQUF1QjtBQUV2QixRQUFNLE1BQU0sT0FBTyxVQUFVLFdBQVcsTUFBTSxTQUFTLEVBQUUsSUFBSTtBQUM3RCxRQUFNLEtBQUssT0FBTyxjQUFjLFdBQVcsVUFBVSxTQUFTLEVBQUUsSUFBSTtBQUVwRSxNQUFJLFVBQVUsUUFBVztBQUN4QixVQUFNLEtBQUssT0FBTyxVQUFVLFdBQVcsTUFBTSxTQUFTLEVBQUUsSUFBSTtBQUM1RCxXQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUksRUFBRTtFQUNuQztBQUVBLFNBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDN0I7QUFTTSxTQUFVLE1BQU0sT0FBZSxZQUFZLEdBQUM7QUFDakQsU0FBTyxLQUFLLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxXQUFXLEdBQUcsQ0FBQztBQUN4RDtBQU9NLFNBQVUsV0FBVyxPQUF3QjtBQUNsRCxTQUFPLEtBQUssTUFBTSxLQUFLLEtBQUssRUFDMUIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxDQUFDO0FBQ1g7QUFTTSxTQUFVLGVBQWUsR0FBVyxHQUFXLEdBQVM7QUFDN0QsU0FBTyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsRUFDakIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxFQUNQLFlBQVcsQ0FBRTtBQUNoQjtBQVFNLFNBQVUsZUFBZSxJQUFVO0FBQ3hDLFFBQU0sQ0FBQyxPQUFPLFVBQVUsS0FBSyxJQUFJLEdBQUcsTUFBTSxHQUFHO0FBQzdDLFNBQU87SUFDTjtJQUNBLE9BQU8sU0FBUyxVQUFVLEVBQUU7SUFDNUIsUUFBUSxTQUFTLE9BQU8sRUFBRTs7QUFFNUI7QUFVTSxTQUFVLGNBQWMsUUFBZ0IsUUFBYztBQUMzRCxRQUFNLEtBQUssU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUNqRCxRQUFNLEtBQUssU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUNqRCxNQUFJLE9BQU8sTUFBTSxFQUFFLEtBQUssT0FBTyxNQUFNLEVBQUU7QUFBRyxXQUFPO0FBQ2pELFNBQU8sS0FBSyxJQUFJLEtBQUssRUFBRTtBQUN4QjtBQVNNLFNBQVUscUJBQ2YsWUFBK0I7QUFFL0IsUUFBTSxhQUFrRSxDQUFBO0FBQ3hFLGFBQVcsQ0FBQyxPQUFPLElBQUksS0FBSyxPQUFPLFFBQVEsVUFBVSxHQUFHO0FBQ3ZELGVBQVcsS0FBSyxJQUFJO01BQ25CLE9BQU8sS0FBSztNQUNaLFdBQVcsTUFBTSxRQUFRLEtBQUssU0FBUyxJQUFJLEtBQUssWUFBWSxDQUFBOztFQUU5RDtBQUNBLFNBQU87QUFDUjtBQVlNLFNBQVUscUJBQ2YsU0FDQSxPQUNBLE9BQ0EsV0FBaUI7QUFFakIsUUFBTSxTQUFTLFFBQVEsS0FBSztBQUM1QixNQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sUUFBUSxPQUFPLFNBQVM7QUFBRyxXQUFPO0FBR3hELE1BQUksU0FBUyxPQUFPLFVBQVUsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFHdkYsTUFBSSxDQUFDLFFBQVE7QUFDWixhQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVTtBQUN6QyxVQUFJLEVBQUUsV0FBVztBQUFPLGVBQU87QUFDL0IsWUFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUNwRSxVQUFJLENBQUMsYUFBYTtBQUFTLGVBQU87QUFFbEMsWUFBTSxTQUFTLFlBQVksRUFBRTtBQUM3QixhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sTUFBTTtJQUM1RCxDQUFDO0VBQ0Y7QUFFQSxTQUFPO0FBQ1I7OztBQ3pNQSxTQUFTLFlBQVksR0FBTTtBQUMxQixRQUFNLE9BQU87SUFDWixNQUFNLEVBQUU7SUFDUixJQUFJLEVBQUU7SUFDTixPQUFPLEVBQUU7SUFDVCxTQUFTLEVBQUU7SUFDWCxTQUFTLEVBQUU7O0FBR1osVUFBUSxFQUFFLE1BQU07SUFDZixLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxDQUFBLEVBQUU7SUFFM0MsS0FBSztBQUNKLGFBQU87UUFDTixHQUFHO1FBQ0gsS0FBSyxFQUFFO1FBQ1AsS0FBSyxFQUFFO1FBQ1AsTUFBTSxFQUFFLFFBQVE7UUFDaEIsT0FBTzs7SUFHVCxLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxNQUFLO0lBRTlDLEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU8sRUFBRSxTQUFTLEdBQUU7SUFFdkMsS0FBSztJQUNMLEtBQUs7SUFDTDtBQUNDLGFBQU87RUFDVDtBQUNEO0FBTU0sU0FBVSxlQUFZO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsUUFBTSxVQUFzQyxDQUFBO0FBRTVDLGFBQVcsQ0FBQyxPQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ3RELFVBQU0sWUFBWSxPQUFPO0FBQ3pCLFFBQUksQ0FBQyxNQUFNLFFBQVEsU0FBUztBQUFHO0FBRS9CLGVBQVcsS0FBSyxXQUFXO0FBQzFCLFlBQU0sV0FBVyxjQUFjLE9BQU8sRUFBRSxRQUFRLEVBQUUsRUFBRTtBQUVwRCxZQUFNLFdBQVcsRUFBRSxXQUFXLENBQUEsR0FBSSxJQUFJLFdBQVc7QUFFakQsWUFBTSxTQUFvQztRQUN6QyxNQUFNLFNBQVMsS0FBSyxLQUFLLEVBQUUsSUFBSTtRQUMvQjtRQUNBLFVBQVUsWUFBVztRQUVyQjs7QUFHRCxjQUFRLFFBQVEsSUFBSTtJQUNyQjtFQUNEO0FBRUEsU0FBTztBQUNSO0FBTU0sU0FBVSxpQkFBYztBQUM3QixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sWUFBMEMsQ0FBQTtBQUVoRCxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLFdBQVcsV0FBVztBQUNoQyxZQUFNLGlCQUFpQixjQUFjLE9BQU8sUUFBUSxRQUFRLFFBQVEsRUFBRTtBQUd0RSxZQUFNLGNBQWMsUUFBUSxXQUFXLENBQUEsR0FBSSxJQUFJLFdBQVc7QUFHMUQsWUFBTSxlQUFlLFdBQVcsT0FBTyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFHdkUsbUJBQWEsS0FBSztRQUNqQixNQUFNO1FBQ04sSUFBSTtRQUNKLE9BQU87UUFDUCxTQUFTO1FBQ1QsU0FBUztPQUNUO0FBR0QsWUFBTSxnQkFBcUI7UUFDMUIsTUFBTTtRQUNOLE1BQU0sU0FBUyxLQUFLLEtBQUssUUFBUSxJQUFJO1FBQ3JDLFNBQVM7UUFDVCxVQUFVLE1BQUs7QUFFZCxpQkFBTztRQUNSOztBQUdELGdCQUFVLGNBQWMsSUFBSTtJQUM3QjtFQUNEO0FBRUEsU0FBTztBQUNSOzs7QUM5SEEsT0FBT0MsV0FBVTs7O0FDTGpCLE9BQU9DLFNBQVE7QUFpQmYsSUFBTUMsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBeUNsRCxTQUFTLGVBQWUsT0FBYTtBQUNwQyxRQUFNLFNBQVMsb0JBQUksSUFBRztBQUN0QixNQUFJLFlBQVk7QUFFaEIsTUFBSTtBQUVILFVBQU0sT0FBTyxnQkFBZ0IsS0FBSztBQUNsQyxRQUFJLENBQUMsTUFBTTtBQUVWLGFBQU8sRUFBRSxXQUFXLE9BQU07SUFDM0I7QUFHQSxnQkFBWSxLQUFLLGFBQWE7QUFHOUIsZUFBVyxVQUFVLEtBQUssYUFBYSxDQUFBLEdBQUk7QUFDMUMsWUFBTSxpQkFBaUIsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLFNBQVMsYUFBYTtBQUMvRixVQUFJLGdCQUFnQjtBQUVuQixlQUFPLElBQUksT0FBTyxFQUFFO0FBR3BCLGNBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQXdCLElBQUksT0FBTyxPQUFPO0FBQ3BGLFlBQUksYUFBYSxTQUFTO0FBQ3pCLHFCQUFXLFVBQVUsWUFBWSxTQUFTO0FBQ3pDLGdCQUFJLE9BQU8sT0FBTyxPQUFPLFVBQVU7QUFDbEMscUJBQU8sSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFO1lBQ2pDO1VBQ0Q7UUFDRDtNQUNEO0lBQ0Q7RUFDRCxTQUFTLE1BQU07RUFFZjtBQUVBLFNBQU8sRUFBRSxXQUFXLE9BQU07QUFDM0I7QUFNQSxTQUFTLHNCQUFzQixLQUFXO0FBQ3pDLFFBQU0sV0FBVyxJQUFJLFFBQVEsT0FBTyxLQUFLLFVBQVUsQ0FBQztBQUNwRCxNQUFJLFdBQVc7QUFBRyxVQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFFbkUsUUFBTSxlQUFlLFdBQVc7QUFDaEMsTUFBSSxJQUFJLFlBQVksTUFBTSxJQUFNO0FBQy9CLFVBQU0sSUFBSSxNQUFNLHVDQUF1QyxJQUFJLFlBQVksRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO0VBQ3hGO0FBRUEsU0FBTztBQUNSO0FBTUEsU0FBUyx1QkFBdUIsT0FBZSxTQUFzQixvQkFBSSxJQUFHLEdBQUU7QUFDN0UsTUFBSSxJQUFJO0FBQ1IsUUFBTSxNQUF1QixDQUFBO0FBRTdCLFNBQU8sSUFBSSxNQUFNLFFBQVE7QUFDeEIsVUFBTSxLQUFLLE1BQU0sQ0FBQztBQUNsQixRQUFJLElBQUksS0FBSyxNQUFNO0FBQVE7QUFHM0IsUUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNLFFBQVE7QUFDM0MsVUFBSSxLQUFLO1FBQ1IsUUFBUTtRQUNSO1FBQ0EsWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxDQUFDO09BQ3JEO0FBQ0QsV0FBSztBQUNMO0lBQ0Q7QUFFQSxRQUFJLEtBQUssRUFBRSxRQUFRLGNBQWMsSUFBSSxZQUFZLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUU7QUFDakUsU0FBSztFQUNOO0FBRUEsU0FBTztBQUNSO0FBRU0sU0FBVSx5QkFBeUIsS0FBYSxPQUFhO0FBQ2xFLFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtFQUM3QztBQUVBLFFBQU0sV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUM1QixRQUFNLFFBQVEsTUFBTTtBQUNwQixRQUFNLE1BQU0sUUFBUTtBQUNwQixNQUFJLE1BQU0sSUFBSTtBQUFRLFVBQU0sSUFBSSxNQUFNLHNCQUFzQjtBQUU1RCxRQUFNLEVBQUUsT0FBTSxJQUFLLGVBQWUsS0FBSztBQUN2QyxTQUFPLHVCQUF1QixJQUFJLFNBQVMsT0FBTyxHQUFHLEdBQUcsTUFBTTtBQUMvRDtBQU1NLFNBQVUsOEJBQThCLEtBQWEsT0FBYTtBQUN2RSxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSw0QkFBNEI7RUFDN0M7QUFHQSxNQUFJLElBQUksVUFBVSx1QkFBdUIsTUFBTSxJQUFJLE1BQU07QUFDekQsUUFBTSxNQUFNLElBQUksU0FBUztBQUN6QixRQUFNLE1BQXVCLENBQUE7QUFHN0IsUUFBTSxFQUFFLE9BQU0sSUFBSyxlQUFlLEtBQUs7QUFJdkMsUUFBTSxvQkFBb0IsQ0FBQyxhQUFhLGlCQUFpQixXQUFXO0FBS3BFLFFBQU0sbUJBQW1CLENBQUMsV0FBVztBQUVyQyxTQUFPLElBQUksSUFBSSxLQUFLO0FBQ25CLFVBQU0sU0FBUyxJQUFJLENBQUM7QUFDcEIsVUFBTSxlQUFlLElBQUksSUFBSSxDQUFDO0FBRTlCLFVBQU0sYUFBYSxJQUFJLElBQUk7QUFDM0IsUUFBSSxhQUFhO0FBQUs7QUFFdEIsVUFBTSxXQUFXLGtCQUFrQixTQUFTLFlBQVk7QUFDeEQsVUFBTSxhQUFhLGlCQUFpQixTQUFTLFlBQVk7QUFFekQsUUFBSTtBQUNKLFFBQUk7QUFDSixRQUFJO0FBRUosUUFBSSxZQUFZO0FBT2YsY0FBUSxJQUFJLElBQUksQ0FBQztBQUNqQixZQUFNLFdBQVcsSUFBSSxTQUFTLElBQUksR0FBRyxVQUFVO0FBQy9DLFlBQU0sY0FBb0MsQ0FBQyxHQUFHLENBQUM7QUFDL0MsZUFBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztBQUN6QyxZQUFJLGlCQUFpQixhQUFhO0FBQ2pDLGdCQUFNLGFBQWEsSUFBSSxZQUFZLFNBQVMsWUFBWSxDQUFDLElBQUk7QUFDN0QsY0FBSSxlQUFlLE1BQU07QUFDeEIsZ0JBQUksS0FBSyxFQUFFLFFBQVEsaUJBQWlCLElBQUksWUFBWSxPQUFPLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFDLENBQUU7VUFDdkY7UUFDRCxPQUFPO0FBQ04sY0FBSSxLQUFLLEVBQUUsUUFBUSxjQUFjLElBQUksR0FBRyxPQUFPLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFDLENBQUU7UUFDM0U7TUFDRDtBQUNBLFVBQUk7QUFDSjtJQUNELFdBQVcsVUFBVTtBQUVwQixjQUFRLElBQUksSUFBSSxDQUFDO0FBQ2pCLGdCQUFVLElBQUksSUFBSSxDQUFDO0FBQ25CLFVBQUksSUFBSTtJQUNULE9BQU87QUFFTixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVDtBQUVBLFVBQU0sT0FBTyxJQUFJO0FBQ2pCLFVBQU0sU0FBUztBQUVmLFdBQU8sSUFBSSxJQUFJLE1BQU07QUFDcEIsWUFBTSxLQUFLLElBQUksQ0FBQztBQUNoQixVQUFJO0FBR0osVUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNO0FBQ25DLHFCQUFhLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLENBQUM7QUFDaEQsYUFBSztNQUNOLE9BQU87QUFDTixxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUM7QUFDeEIsYUFBSztNQUNOO0FBRUEsWUFBTSxVQUF5QjtRQUM5QixRQUFRO1FBQ1I7UUFDQTs7QUFFRCxVQUFJLFVBQVUsUUFBVztBQUN4QixnQkFBUSxRQUFRO01BQ2pCO0FBQ0EsVUFBSSxLQUFLLE9BQU87SUFDakI7QUFRQSxRQUFJLE1BQU0sVUFBVSxhQUFhLElBQUksR0FBRztBQUN2QyxVQUFJLE1BQU0sV0FBVyxJQUFJLElBQUksSUFBSTtBQUNqQyxVQUFJLFFBQVE7QUFDWixhQUFPLE1BQU0sWUFBWTtBQUN4QixjQUFNLFVBQXlCLEVBQUUsUUFBUSxjQUFjLElBQUksU0FBUyxZQUFZLENBQUMsSUFBSSxLQUFLLENBQUMsRUFBQztBQUM1RixZQUFJLFVBQVU7QUFBVyxrQkFBUSxRQUFRO0FBQ3pDLFlBQUksS0FBSyxPQUFPO01BQ2pCO0lBQ0Q7QUFFQSxRQUFJO0VBQ0w7QUFFQSxTQUFPO0FBQ1I7QUFXTSxTQUFVLHNCQUFzQixPQUFlLEtBQVc7QUFDL0QsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0saUNBQWlDLE1BQU0sU0FBUyxFQUFFLENBQUMsR0FBRztFQUN2RTtBQUNBLFFBQU0sRUFBRSxVQUFTLElBQUssZUFBZSxLQUFLO0FBQzFDLFNBQU8sWUFBWSw4QkFBOEIsS0FBSyxLQUFLLElBQUkseUJBQXlCLEtBQUssS0FBSztBQUNuRztBQU1NLFNBQVUsb0JBQW9CLFNBQXdCLFNBQW1CO0FBRTlFLE1BQUksU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxRQUFRLFVBQVUsRUFBRSxPQUFPLFFBQVEsRUFBRTtBQUtuRixNQUFJLENBQUMsUUFBUTtBQUNaLFVBQU0sYUFBYSxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQ3JDLFVBQUksRUFBRSxXQUFXLFFBQVE7QUFBUSxlQUFPO0FBRXhDLFlBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDL0QsVUFBSSxDQUFDLGFBQWE7QUFBUyxlQUFPO0FBRWxDLFlBQU0sZ0JBQWdCLFFBQVEsS0FBSyxFQUFFO0FBQ3JDLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxhQUFhO0lBQzlELENBQUM7QUFDRCxRQUFJLFlBQVk7QUFDZixlQUFTO0lBQ1Y7RUFDRDtBQUVBLFFBQU0sU0FBUyxNQUFNLFFBQVEsTUFBTTtBQUNuQyxRQUFNLFFBQVEsTUFBTSxRQUFRLEVBQUU7QUFDOUIsUUFBTSxTQUFTLFdBQVcsUUFBUSxVQUFVO0FBQzVDLFFBQU0sU0FDTCxRQUFRLFdBQVcsV0FBVyxJQUMzQixlQUFlLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsR0FBRyxRQUFRLFdBQVcsQ0FBQyxDQUFDLElBQ2xGLFFBQVEsV0FBVyxXQUFXLElBQzdCLFFBQVEsV0FBVyxDQUFDLElBQ3BCLFFBQVEsV0FBVyxLQUFLLEdBQUc7QUFHaEMsUUFBTSxXQUFXLFFBQVEsVUFBVSxTQUFZLE9BQU8sUUFBUSxLQUFLLEtBQUs7QUFDeEUsUUFBTSxTQUFTLE9BQU8sTUFBTSxHQUFHLFFBQVEsT0FBTyxLQUFLLFFBQVEsTUFBTTtBQUdqRSxNQUFJLFFBQVE7QUFDWCxRQUFJLE9BQU8sT0FBTztBQUdsQixRQUFJLFFBQVEsVUFBVSxRQUFXO0FBQ2hDLGFBQU8sR0FBRyxJQUFJLE1BQU0sUUFBUSxRQUFRLENBQUM7SUFDdEMsT0FFSztBQUNKLFlBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsVUFBSSxhQUFhLFNBQVM7QUFDekIsY0FBTSxnQkFBZ0IsUUFBUSxLQUFLLE9BQU87QUFDMUMsY0FBTSxjQUFjLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtBQUMxRSxZQUFJLGFBQWE7QUFDaEIsaUJBQU8sR0FBRyxJQUFJLElBQUksWUFBWSxLQUFLO1FBQ3BDO01BQ0Q7SUFDRDtBQUdBLFVBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsUUFBSSxhQUFhLFdBQVcsUUFBUSxXQUFXLFdBQVcsR0FBRztBQUM1RCxZQUFNLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLFdBQVcsQ0FBQyxDQUFDO0FBQzdFLFVBQUksUUFBUTtBQUNYLGVBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSyxLQUFLLE1BQU07TUFDdkQ7SUFDRDtBQUNBLFdBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLE1BQU07RUFDdEM7QUFHQSxTQUFPLEdBQUcsTUFBTTtBQUNqQjtBQWlCTSxTQUFVLGlDQUNmLE9BQ0EsS0FBVztBQUVYLFFBQU0sU0FBUyxnQkFBZ0IsS0FBSztBQUNwQyxRQUFNLG9CQUFvQixRQUFRO0FBR2xDLE1BQUksc0JBQXNCLFFBQVc7QUFDcEMsVUFBTSxXQUFXLG9CQUNkLDhCQUE4QixLQUFLLEtBQUssSUFDeEMseUJBQXlCLEtBQUssS0FBSztBQUN0QyxXQUFPLEVBQUUsVUFBVSxtQkFBbUIsS0FBSTtFQUMzQztBQUdBLE1BQUksZUFBZ0MsQ0FBQTtBQUNwQyxNQUFJLG9CQUFxQyxDQUFBO0FBRXpDLE1BQUk7QUFDSCxtQkFBZSx5QkFBeUIsS0FBSyxLQUFLO0VBQ25ELFNBQVMsR0FBRztBQUNYLElBQUFBLFFBQU8sTUFBTSx1QkFBdUIsQ0FBQyxFQUFFO0VBQ3hDO0FBRUEsTUFBSTtBQUNILHdCQUFvQiw4QkFBOEIsS0FBSyxLQUFLO0VBQzdELFNBQVMsR0FBRztBQUNYLElBQUFBLFFBQU8sTUFBTSw0QkFBNEIsQ0FBQyxFQUFFO0VBQzdDO0FBR0EsTUFBSSxrQkFBa0IsU0FBUyxhQUFhLFFBQVE7QUFDbkQsSUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxrQkFBa0IsTUFBTSxZQUFZLGFBQWEsTUFBTSxHQUFHO0FBQ25ILFdBQU8sRUFBRSxVQUFVLG1CQUFtQixtQkFBbUIsS0FBSTtFQUM5RCxXQUFXLGFBQWEsU0FBUyxHQUFHO0FBQ25DLElBQUFBLFFBQU8sS0FBSyxtQ0FBbUMsYUFBYSxNQUFNLGlCQUFpQixrQkFBa0IsTUFBTSxHQUFHO0FBQzlHLFdBQU8sRUFBRSxVQUFVLGNBQWMsbUJBQW1CLE1BQUs7RUFDMUQsT0FBTztBQUVOLElBQUFBLFFBQU8sS0FBSyx1REFBdUQsS0FBSyxFQUFFO0FBQzFFLFdBQU8sRUFBRSxVQUFVLENBQUEsR0FBSSxtQkFBbUIsS0FBSTtFQUMvQztBQUNEO0FBRU0sU0FBVSw0QkFBNEIsT0FBZSxLQUFXO0FBQ3JFLFFBQU0sRUFBRSxVQUFTLElBQUssZUFBZSxLQUFLO0FBQzFDLFNBQU8sWUFBWSw4QkFBOEIsS0FBSyxLQUFLLElBQUkseUJBQXlCLEtBQUssS0FBSztBQUNuRztBQVNBLFNBQVMsbUJBQW1CLFlBQW9CO0FBQy9DLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsV0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxVQUFVLFNBQVMsV0FBVyxDQUFDLEVBQUM7RUFDN0U7QUFFQSxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFVBQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBQ2xCLFdBQU87TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE1BQU07TUFDTixTQUFTLGVBQWUsR0FBRyxHQUFHLENBQUM7O0VBRWpDO0FBRUEsU0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxPQUFPLFNBQVMsQ0FBQyxHQUFHLFVBQVUsRUFBQztBQUM1RTtBQU1NLFNBQVUsNEJBQ2YsV0FDQSxRQUNBLFdBQXNDO0FBRXRDLFFBQU0sTUFBTSxnQkFBZ0IsU0FBUztBQUdyQyxNQUFJLENBQUMsSUFBSSxXQUFXO0FBQ25CLFFBQUksWUFBWSxDQUFBO0VBQ2pCO0FBR0EsUUFBTSxhQUFhLE9BQU8sT0FBTyxTQUFTLEVBQ3hDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsVUFBVSxVQUFVLEtBQUssRUFDekMsS0FBSyxDQUFDLEdBQUcsTUFBTSxjQUFjLFVBQVUsT0FBTyxFQUFFLEtBQUssSUFBSSxjQUFjLFVBQVUsT0FBTyxFQUFFLEtBQUssQ0FBQztBQUVsRyxFQUFBQyxRQUFPLEtBQUssbUJBQW1CLFVBQVUsS0FBSyxFQUFFO0FBQ2hELEVBQUFBLFFBQU8sTUFBTSw2QkFBNkIsV0FBVyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLElBQUksQ0FBQyxFQUFFO0FBS3JGLFFBQU0sbUJBQW1CLG9CQUFJLElBQUc7QUFDaEMsYUFBVyxLQUFLLFlBQVk7QUFDM0IsZUFBVyxhQUFhLEVBQUUsYUFBYSxDQUFBLEdBQUk7QUFDMUMsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTztBQUNyRSxVQUFJLENBQUMsVUFBVTtBQUFTO0FBQ3hCLFlBQU0sU0FBUyxVQUFVO0FBQ3pCLFlBQU0sUUFBUSxVQUFVO0FBQ3hCLFlBQU0sTUFBTSxHQUFHLEtBQUssSUFBSSxNQUFNO0FBQzlCLFVBQUksaUJBQWlCLElBQUksR0FBRztBQUFHO0FBRS9CLFlBQU0sZ0JBQWdCLE9BQ3BCLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsS0FBSyxNQUFNLEVBQ2pELElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxNQUFNLEVBQ3hCLEtBQUssQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBRXRCLFVBQUksU0FBUztBQUNiLGlCQUFXLE9BQU8sZUFBZTtBQUNoQyxZQUFJLFFBQVEsU0FBUztBQUFHLG1CQUFTO2lCQUN4QixNQUFNLFNBQVM7QUFBRztNQUM1QjtBQUNBLFVBQUksU0FBUyxHQUFHO0FBQ2YseUJBQWlCLElBQUksS0FBSyxNQUFNO0FBQ2hDLFFBQUFBLFFBQU8sTUFBTSxnQ0FBZ0MsTUFBTSxLQUFLLENBQUMsWUFBWSxNQUFNLE1BQU0sQ0FBQyxvQkFBZSxNQUFNLEVBQUU7TUFDMUc7SUFDRDtFQUNEO0FBSUEsUUFBTSxZQUFZLG9CQUFJLElBQUc7QUFDekIsYUFBVyxFQUFFLFFBQVEsSUFBSSxNQUFLLEtBQU0sUUFBUTtBQUMzQyxRQUFJLFVBQVU7QUFBVztBQUN6QixVQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksRUFBRTtBQUMzQixRQUFJLENBQUMsVUFBVSxJQUFJLEdBQUc7QUFBRyxnQkFBVSxJQUFJLEtBQUssb0JBQUksSUFBRyxDQUFFO0FBQ3JELGNBQVUsSUFBSSxHQUFHLEVBQUcsSUFBSSxLQUFLO0VBQzlCO0FBTUEsYUFBVyxFQUFFLFFBQVEsSUFBSSxPQUFPLFdBQVUsS0FBTSxRQUFRO0FBRXZELFVBQU0sZ0JBQWdCLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUNsRixRQUFJLGVBQWU7QUFDbEIsWUFBTSxNQUFNLGNBQWMsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUMvRCxVQUFJO0FBQUssWUFBSSxVQUFVLG1CQUFtQixVQUFVLEVBQUU7QUFDdEQ7SUFDRDtBQUtBLFVBQU0sWUFBWSxJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQUs7QUFDMUMsVUFBSSxFQUFFLFdBQVc7QUFBUSxlQUFPO0FBQ2hDLFlBQU0sV0FBVyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDeEQsVUFBSSxDQUFDLFVBQVU7QUFBUyxlQUFPO0FBQy9CLFVBQUksTUFBTSxFQUFFO0FBQUksZUFBTztBQUN2QixZQUFNLFNBQVMsS0FBSyxFQUFFO0FBRXRCLGFBQU8sV0FBVyxLQUFLLENBQUMsTUFBSztBQUM1QixjQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFLEVBQUU7QUFDOUUsY0FBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxlQUFPLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtNQUM3RCxDQUFDO0lBQ0YsQ0FBQztBQUNELFFBQUksV0FBVztBQUNkLFlBQU0sU0FBUyxLQUFLLFVBQVU7QUFDOUIsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxVQUFJLFVBQVUsV0FBVyxDQUFDLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sTUFBTSxHQUFHO0FBQzdFLFlBQUksUUFBUSxXQUFXLFNBQVMsQ0FBQztBQUNqQyxtQkFBVyxLQUFLLFlBQVk7QUFDM0IsZ0JBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLFVBQVUsRUFBRTtBQUN0RixnQkFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxnQkFBTSxZQUFZLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtBQUN2RSxjQUFJLFdBQVc7QUFDZCxvQkFBUSxVQUFVO0FBQ2xCO1VBQ0Q7UUFDRDtBQUNBLGlCQUFTLFFBQVEsS0FBSyxFQUFFLElBQUksUUFBUSxNQUFLLENBQUU7QUFDM0MsUUFBQUEsUUFBTyxLQUNOLGlCQUFpQixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLHVCQUF1QixNQUFNLFVBQVUsRUFBRSxDQUFDLGNBQWMsTUFBTSxNQUFNLEtBQUssSUFBSTtNQUU3SDtBQUNBO0lBQ0Q7QUFHQSxRQUFJO0FBRUosZUFBVyxLQUFLLFlBQVk7QUFDM0IsWUFBTSxRQUFRLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUN6RSxVQUFJLE9BQU87QUFDVixpQkFBUyxnQkFBZ0IsS0FBSztBQUU5QixjQUFNLFdBQVcsTUFBTSxLQUFLLFFBQVEscUNBQXFDLEVBQUUsRUFBRSxLQUFJO0FBQ2pGLGVBQU8sT0FBTyxHQUFHLFFBQVEseUJBQXlCLEVBQUUsS0FBSztBQUN6RCxRQUFBQSxRQUFPLEtBQUssbUJBQW1CLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsZUFBZSxFQUFFLEtBQUssVUFBVTtBQUM1RjtNQUNEO0lBQ0Q7QUFJQSxRQUFJLENBQUMsUUFBUTtBQUNaLFVBQUksY0FBYztBQUNsQixpQkFBVyxLQUFLLFlBQVk7QUFDM0IsY0FBTSxZQUFZLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBVTtBQUM5QyxjQUFJLEVBQUUsV0FBVztBQUFRLG1CQUFPO0FBQ2hDLGdCQUFNLFdBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxPQUFPO0FBQzdELGNBQUksQ0FBQyxVQUFVO0FBQVMsbUJBQU87QUFDL0IsY0FBSSxNQUFNLEVBQUU7QUFBSSxtQkFBTztBQUN2QixnQkFBTSxTQUFTLEtBQUssRUFBRTtBQUN0QixnQkFBTSxTQUFTLGlCQUFpQixJQUFJLEdBQUcsTUFBTSxJQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUs7QUFDNUQsaUJBQU8sVUFBVTtRQUNsQixDQUFDO0FBQ0QsWUFBSSxXQUFXO0FBQ2Qsd0JBQWM7QUFDZCxVQUFBQSxRQUFPLE1BQ04sVUFBVSxNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLDRDQUE0QyxNQUFNLFVBQVUsRUFBRSxDQUFDLDZCQUF3QjtBQUUvSDtRQUNEO01BQ0Q7QUFDQSxVQUFJO0FBQWE7SUFDbEI7QUFHQSxRQUFJLENBQUMsUUFBUTtBQUNaLGVBQVM7UUFDUjtRQUNBO1FBQ0EsTUFBTSxlQUFlLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLEVBQUUsWUFBVyxDQUFFO1FBQ2hFLFNBQVMsQ0FBQyxtQkFBbUIsVUFBVSxDQUFDOztBQUV6QyxVQUFJLFVBQVU7QUFBVyxlQUFPLFFBQVE7QUFDeEMsTUFBQUEsUUFBTyxLQUFLLDBCQUEwQixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLEVBQUU7SUFDdEUsT0FBTztBQUlOLGFBQU8sVUFBVSxPQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sS0FBSyxDQUFBO0FBQ3BFLGFBQU8sT0FBTztBQUVkLFlBQU0sa0JBQWtCLFVBQVUsSUFBSSxHQUFHLE1BQU0sSUFBSSxFQUFFLEVBQUU7QUFDdkQsVUFBSSxtQkFBbUIsZ0JBQWdCLE9BQU8sR0FBRztBQUNoRCxjQUFNLFdBQVcsS0FBSyxJQUFJLEdBQUcsZUFBZTtBQUM1QyxZQUFJLGFBQWEsR0FBRztBQUVuQixpQkFBTyxRQUFRO1FBQ2hCLE9BQU87QUFFTixnQkFBTSxlQUFlLE1BQU0sS0FBSyxFQUFFLFFBQVEsV0FBVyxFQUFDLEdBQUksQ0FBQyxHQUFHLE9BQU87WUFDcEUsSUFBSTtZQUNKLE9BQU8sV0FBVyxJQUFJLENBQUM7WUFDdEI7QUFDRixpQkFBTyxRQUFRLFFBQVE7WUFDdEIsSUFBSTtZQUNKLE9BQU87WUFDUCxNQUFNO1lBQ04sU0FBUztZQUNULFNBQVM7V0FDRjtRQUNUO01BQ0Q7QUFNQSxZQUFNLGtCQUFrQixtQkFBbUIsVUFBVSxFQUFFO0FBQ3ZELFlBQU0sV0FBVyxPQUFPLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDN0QsVUFBSSxVQUFVO0FBQ2IsWUFBSSxTQUFTLFdBQVcsTUFBTSxRQUFRLFNBQVMsT0FBTyxHQUFHO0FBQ3hELGdCQUFNLFlBQVksU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxlQUFlO0FBQzVFLGNBQUksQ0FBQyxXQUFXO0FBQ2YsWUFBQUEsUUFBTyxLQUNOLCtCQUErQixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLGlDQUFpQyxlQUFlLHNDQUFpQztBQUc5SSxxQkFBUyxPQUFPO0FBQ2hCLG1CQUFRLFNBQWlCO1VBQzFCO1FBQ0Q7QUFDQSxpQkFBUyxVQUFVO01BQ3BCO0lBQ0Q7QUFFQSxRQUFJLFVBQVUsS0FBSyxNQUFNO0VBQzFCO0FBU0EsYUFBVyxFQUFFLFFBQVEsR0FBRSxLQUFNLFFBQVE7QUFDcEMsVUFBTSxrQkFBa0IsSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ3BGLFFBQUk7QUFBaUI7QUFHckIsVUFBTSxZQUFZLElBQUksVUFBVSxLQUFLLENBQUMsTUFBSztBQUMxQyxVQUFJLEVBQUUsV0FBVztBQUFRLGVBQU87QUFDaEMsWUFBTUMsWUFBVyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDeEQsYUFBTyxDQUFDLENBQUNBLFdBQVUsV0FBVyxLQUFLLEVBQUU7SUFDdEMsQ0FBQztBQUNELFFBQUksQ0FBQztBQUFXO0FBRWhCLFVBQU0sU0FBUyxLQUFLLFVBQVU7QUFDOUIsVUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxRQUFJLENBQUMsVUFBVSxXQUFXLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sTUFBTTtBQUFHO0FBSTlFLFVBQU0sZUFBZSxXQUFXLEtBQUssQ0FBQyxNQUFLO0FBQzFDLFlBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLFVBQVUsRUFBRTtBQUN0RixZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLGFBQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO0lBQzdELENBQUM7QUFDRCxVQUFNLGtCQUFrQixTQUFTLFFBQVEsSUFBSSxDQUFDLE1BQVcsRUFBRSxFQUFZLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFDN0YsVUFBTSxlQUFlLGdCQUFnQixTQUFTLEtBQUssV0FBVyxnQkFBZ0IsZ0JBQWdCLFNBQVMsQ0FBQyxJQUFJO0FBRTVHLFFBQUksQ0FBQyxnQkFBZ0IsQ0FBQztBQUFjO0FBR3BDLFFBQUksUUFBUSxXQUFXLFNBQVMsQ0FBQztBQUNqQyxlQUFXLEtBQUssWUFBWTtBQUMzQixZQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUU7QUFDdEYsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxZQUFNLFlBQVksVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO0FBQ3ZFLFVBQUksV0FBVztBQUNkLGdCQUFRLFVBQVU7QUFDbEI7TUFDRDtJQUNEO0FBRUEsYUFBUyxRQUFRLEtBQUssRUFBRSxJQUFJLFFBQVEsTUFBSyxDQUFFO0FBQzNDLElBQUFELFFBQU8sS0FDTix5QkFBeUIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyx1QkFBdUIsTUFBTSxVQUFVLEVBQUUsQ0FBQyxjQUFjLE1BQU0sTUFBTSxLQUFLLElBQUk7RUFFckk7QUFFQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLG9CQUFvQixVQUFrQixTQUFvQjtBQUN6RSxNQUFJO0FBRUgsVUFBTSxhQUFrQixFQUFFLE9BQU8sUUFBUSxNQUFLO0FBRzlDLFFBQUksZUFBZSxTQUFTO0FBQzNCLGlCQUFXLFlBQVksUUFBUTtJQUNoQztBQUdBLFFBQUkseUJBQXlCLFNBQVM7QUFDckMsaUJBQVcsc0JBQXNCLFFBQVE7SUFDMUM7QUFDQSxRQUFJLGVBQWUsU0FBUztBQUMzQixpQkFBVyxZQUFZLFFBQVEsVUFBVSxJQUFJLENBQUMsVUFBYztBQUUzRCxjQUFNLGVBQW9CLENBQUE7QUFDMUIsWUFBSSxZQUFZO0FBQU8sdUJBQWEsU0FBUyxNQUFNO0FBQ25ELFlBQUksUUFBUTtBQUFPLHVCQUFhLEtBQUssTUFBTTtBQUMzQyxZQUFJLFdBQVc7QUFBTyx1QkFBYSxRQUFRLE1BQU07QUFDakQsWUFBSSxVQUFVO0FBQU8sdUJBQWEsT0FBTyxNQUFNO0FBQy9DLFlBQUksYUFBYTtBQUFPLHVCQUFhLFVBQVUsTUFBTTtBQUVyRCxtQkFBVyxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDckMsY0FBSSxFQUFFLE9BQU87QUFBZSx5QkFBYSxHQUFHLElBQUksTUFBTSxHQUFHO1FBQzFEO0FBQ0EsZUFBTztNQUNSLENBQUM7SUFDRjtBQUVBLGVBQVcsT0FBTyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3ZDLFVBQUksRUFBRSxPQUFPLGFBQWE7QUFDekIsbUJBQVcsR0FBRyxJQUFLLFFBQWdCLEdBQUc7TUFDdkM7SUFDRDtBQUdBLFFBQUksT0FBTyxLQUFLLFVBQVUsWUFBWSxNQUFNLENBQUM7QUFLN0MsV0FBTyxLQUFLLFFBQVEsMERBQTBELDZCQUE2QjtBQUUzRyxJQUFBRSxJQUFHLGNBQWMsVUFBVSxPQUFPLE1BQU0sTUFBTTtFQUMvQyxTQUFTLEdBQUc7QUFDWCxJQUFBRixRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtFQUN0QztBQUNEOzs7QURueEJBLElBQU1HLFVBQVMsbUJBQW1CLFNBQVM7QUFFckMsU0FBVSxjQUFjLE1BQW9CO0FBQ2pELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxhQUFhLGFBQVk7QUFDL0IsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0sZUFBb0IsQ0FBQTtBQUUxQixRQUFNLGNBQWMsS0FBSztBQU16QixlQUFhLHVCQUF1QixJQUFJO0lBQ3ZDLE1BQU07SUFDTixTQUFTLENBQUE7SUFDVCxVQUFVLFlBQVc7QUFDcEIsWUFBTSxRQUFRO0FBQ2QsWUFBTSxLQUFLLEtBQUs7QUFFaEIsWUFBTSxNQUFNLE1BQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFO0FBR3pELFVBQUksWUFBWSxnQkFBZ0IsS0FBSztBQUdyQyxZQUFNLEVBQUUsVUFBVSxRQUFRLGtCQUFpQixJQUFLLGlDQUFpQyxPQUFPLEdBQUc7QUFDM0YsTUFBQUEsUUFBTyxNQUFNLGlCQUFpQixLQUFLLFVBQVUsTUFBTSxDQUFDLEVBQUU7QUFFdEQsVUFBSSxDQUFDLFdBQVc7QUFFZixRQUFBQSxRQUFPLEtBQUssU0FBUyxLQUFLLHVEQUFrRDtBQUM1RSxvQkFBWTtVQUNYO1VBQ0EsV0FBVyxxQkFBcUI7VUFDaEMscUJBQXFCO1VBQ3JCLFdBQVcsQ0FBQTs7TUFFYixXQUFXLHNCQUFzQixNQUFNO0FBRXRDLFFBQUFBLFFBQU8sS0FBSywyQkFBMkIsaUJBQWlCLHdCQUF3QjtBQUNoRixvQkFBWSxFQUFFLEdBQUcsV0FBVyxXQUFXLGtCQUFpQjtNQUN6RDtBQUVBLFlBQU0sVUFBVSw0QkFBNEIsV0FBVyxRQUFRLE9BQU87QUFDdEUsTUFBQUEsUUFBTyxNQUFNLHFCQUFxQixLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUMsQ0FBQyxFQUFFO0FBR3BFLFlBQU1DLGlCQUFnQixpQkFBZ0I7QUFDdEMsWUFBTSxhQUFhQyxNQUFLLEtBQUtELGdCQUFlLFFBQVEsS0FBSyxPQUFPO0FBQ2hFLDBCQUFvQixZQUFZLE9BQU87QUFHdkMsMEJBQW1CO0FBRW5CLE1BQUFELFFBQU8sS0FBSyxTQUFTLEtBQUssd0NBQXdDO0lBQ25FOztBQU9ELGFBQVcsQ0FBQyxVQUFVLE1BQU0sS0FBSyxPQUFPLFFBQVEsVUFBVSxHQUFHO0FBQzVELFVBQU0sRUFBRSxPQUFPLE9BQU8sT0FBTSxJQUFLLGVBQWUsUUFBUTtBQUd4RCxRQUFJLFVBQVU7QUFBYTtBQUczQixVQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLFVBQU0sWUFBWSxRQUFRLFdBQVcsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLE1BQU07QUFFM0YsaUJBQWEsUUFBUSxJQUFJO01BQ3hCLEdBQUc7TUFDSCxVQUFVLE9BQU8sVUFBYztBQUM5QixjQUFNLEtBQUssS0FBSztBQUNoQixjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFZLE1BQU0sUUFBUSxPQUFPLElBQUksV0FBVztBQUN6RixjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU87QUFDbkMsY0FBTSxRQUFRLE1BQU0sUUFBUSxPQUFPLEtBQUs7QUFDeEMsY0FBTSxZQUFZLFNBQVM7QUFFM0IsY0FBTSxLQUFLLGFBQWEsYUFBYSxPQUFPLE9BQU8sV0FBVyxPQUFPLEVBQUU7TUFDeEU7O0VBRUY7QUFLQSxRQUFNLGVBQWUsUUFBUSxXQUFXO0FBQ3hDLE1BQUksY0FBYztBQUNqQixVQUFNLG1CQUFtQixhQUFhLGFBQWEsQ0FBQSxHQUFJLEtBQUssQ0FBQyxNQUFXLEVBQUUsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUUvRixRQUFJLGlCQUFpQjtBQUNwQixZQUFNLFdBQVcsR0FBRyxXQUFXO0FBRS9CLG1CQUFhLFFBQVEsSUFBSTtRQUN4QixNQUFNLFNBQVMsV0FBVztRQUMxQixTQUFTLENBQUE7UUFDVCxVQUFVLFlBQVc7QUFDcEIsZ0JBQU0sS0FBSyxLQUFLO0FBQ2hCLFVBQUFBLFFBQU8sS0FBSyx5QkFBb0IsV0FBVyxNQUFNLEVBQUUsRUFBRTtBQUNyRCxnQkFBTSxLQUFLLGFBQWEsY0FBYyxFQUFFO0FBQ3hDLGdCQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRSxFQUFFLE1BQU0sQ0FBQyxRQUFPO0FBQzVELFlBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsR0FBRyxFQUFFO1VBQy9ELENBQUM7UUFDRjs7SUFFRjtFQUNEO0FBRUEsT0FBSyxxQkFBcUIsWUFBWTtBQUd2Qzs7O0FFckhBLFNBQVMsaUJBQ1IsU0FDQSxPQUNBLE9BQ0EsV0FDQSxPQUFhO0FBRWIsUUFBTSxVQUFVLHFCQUFxQixTQUFTLE9BQU8sT0FBTyxTQUFTO0FBQ3JFLE1BQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxRQUFRLFFBQVEsT0FBTztBQUFHLFdBQU87QUFHeEQsUUFBTSxjQUFjLFFBQVEsUUFBUSxLQUFLLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUN6RSxNQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sUUFBUSxZQUFZLE9BQU87QUFBRyxXQUFPO0FBR2hFLFFBQU0sU0FBUyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLEtBQUs7QUFDbEUsU0FBTyxRQUFRLFNBQVM7QUFDekI7QUFNTSxTQUFVLGdCQUFnQixNQUFvQjtBQUNuRCxRQUFNLGFBQWEsaUJBQWdCO0FBQ25DLFFBQU0sZUFBZSxlQUFjO0FBQ25DLFFBQU0sVUFBVSxxQkFBcUIsVUFBVTtBQUMvQyxRQUFNLGlCQUFzQixDQUFBO0FBRzVCLFFBQU0sY0FBYyxLQUFLO0FBTXpCLGFBQVcsQ0FBQyxZQUFZLFFBQVEsS0FBSyxPQUFPLFFBQVEsWUFBWSxHQUFHO0FBQ2xFLFVBQU0sRUFBRSxPQUFPLE9BQU8sT0FBTSxJQUFLLGVBQWUsVUFBVTtBQUcxRCxRQUFJLFVBQVU7QUFBYTtBQUczQixtQkFBZSxVQUFVLElBQUk7TUFDNUIsR0FBRztNQUNILFVBQVUsQ0FBQyxrQkFBc0I7QUFDaEMsY0FBTSxLQUFLLEtBQUs7QUFDaEIsY0FBTSxRQUFRLGNBQWMsUUFBUSxPQUFPLEtBQUs7QUFDaEQsY0FBTSxZQUFZLFNBQVM7QUFHM0IsWUFBSSxRQUFRLGNBQWMsUUFBUSxPQUFPO0FBQ3pDLFlBQUksVUFBVSxRQUFXO0FBQ3hCLGdCQUFNLGVBQWUscUJBQXFCLFNBQVMsT0FBTyxPQUFPLFNBQVM7QUFDMUUsY0FBSSxjQUFjLFVBQVUsUUFBVztBQUN0QyxvQkFBUSxhQUFhO1VBQ3RCO1FBQ0Q7QUFFQSxjQUFNLFVBQVUsS0FBSyxhQUFhLGdCQUFnQixJQUFJLE9BQU8sV0FBVyxLQUFLO0FBRzdFLGNBQU0sWUFBWSxjQUFjLFFBQVEsV0FBVyxLQUFLO0FBRXhELFlBQUksYUFBYSxZQUFZLFFBQVc7QUFFdkMsaUJBQU8saUJBQWlCLFNBQVMsT0FBTyxPQUFPLFdBQVcsT0FBTztRQUNsRTtBQUdBLGVBQU8sV0FBVztNQUNuQjs7RUFFRjtBQUVBLE9BQUssdUJBQXVCLGNBQWM7QUFHM0M7OztBQ3RGQSxPQUFPRyxZQUFXOzs7QUNBbEIsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sUUFBUTtBQUlmLElBQU1DLFVBQVMsbUJBQW1CLE9BQU87QUFLbEMsSUFBTSx5QkFBeUI7QUFFL0IsSUFBTSwwQkFBMEI7QUFnQmhDLElBQU0scUJBQXFCLE1BQU87QUFpQm5DLFNBQVUsd0JBQXFCO0FBQ3BDLFFBQU0sTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQzlCLFFBQU0sTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssS0FBTTtBQUU3QyxNQUFJLGNBQWMsT0FBUSxDQUFDO0FBQzNCLE1BQUksY0FBYyx3QkFBd0IsQ0FBQztBQUMzQyxNQUFJLGNBQWMsS0FBSyxDQUFDO0FBRXhCLFFBQU0sTUFBTSxpQkFBZ0I7QUFDNUIsTUFBSSxLQUFLLEtBQUssQ0FBQztBQUVmLFNBQU8sS0FBSyxZQUFZLE9BQU8sRUFBRSxLQUFLLEtBQUssRUFBRTtBQUM3QyxNQUFJLGNBQWMsTUFBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFRLEVBQUU7QUFDNUIsTUFBSSxjQUFjLEtBQVksRUFBRTtBQUVoQyxTQUFPO0FBQ1I7QUFHTSxTQUFVLG1CQUFnQjtBQUMvQixNQUFJO0FBQ0gsVUFBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLGVBQVcsUUFBUSxPQUFPLEtBQUssTUFBTSxHQUFHO0FBQ3ZDLGlCQUFXLFFBQVEsT0FBTyxJQUFJLEtBQUssQ0FBQSxHQUFJO0FBQ3RDLFlBQUksQ0FBQyxLQUFLLFlBQVksS0FBSyxXQUFXLFVBQVUsS0FBSyxPQUFPLEtBQUssUUFBUSxxQkFBcUI7QUFDN0YsaUJBQU8sT0FBTyxLQUFLLEtBQUssSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBYyxTQUFTLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDM0U7TUFDRDtJQUNEO0VBQ0QsUUFBUTtFQUVSO0FBQ0EsU0FBTyxPQUFPLE1BQU0sR0FBRyxDQUFDO0FBQ3pCO0FBaUJNLFNBQVUsdUJBQXVCLEtBQWEsT0FBYTtBQUNoRSxNQUFJLElBQUksU0FBUztBQUFvQixXQUFPO0FBQzVDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRLFdBQU87QUFDM0MsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQXlCLFdBQU87QUFDNUQsTUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWSxXQUFPO0FBRWxFLFFBQU0sVUFBVSxDQUFDLFFBQWdCLFFBQ2hDLElBQ0UsU0FBUyxRQUFRLFNBQVMsR0FBRyxFQUM3QixTQUFTLE9BQU8sRUFDaEIsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUNiLEtBQUk7QUFFUCxRQUFNLFFBQVEsSUFBSSxTQUFTLEdBQUcsRUFBRTtBQUNoQyxRQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztBQUM1RSxRQUFNLE1BQU0sU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUc7QUFFekUsUUFBTSxPQUFPLFFBQVEsSUFBTSxFQUFFO0FBQzdCLFFBQU0sZUFBZSxRQUFRLElBQU0sRUFBRTtBQUNyQyxRQUFNLFdBQVcsUUFBUSxLQUFNLEVBQUU7QUFDakMsUUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEVBQUksQ0FBQyxJQUFJLElBQUksRUFBSSxDQUFDO0FBRS9DLE1BQUksQ0FBQztBQUFVLFdBQU87QUFJdEIsUUFBTSxRQUFRLFNBQ1osUUFBUSxjQUFjLEVBQUUsRUFDeEIsS0FBSSxFQUNKLE1BQU0sS0FBSyxFQUFFLENBQUM7QUFFaEIsU0FBTztJQUNOLElBQUk7SUFDSjtJQUNBO0lBQ0E7SUFDQSxXQUFXOztJQUNYO0lBQ0E7O0FBRUY7QUFPQSxlQUFzQixxQkFBcUIsUUFBYztBQUN4RCxTQUFPLElBQUksUUFBa0IsQ0FBQyxTQUFTLFdBQVU7QUFDaEQsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLE1BQUs7QUFDVCxhQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztJQUM3QyxDQUFDO0FBRUQsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksTUFBSztBQUVULGNBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxtQkFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMscUJBQVcsU0FBUyxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdkMsZ0JBQ0MsTUFBTSxXQUFXLFVBQ2pCLE1BQU0sWUFBWSxhQUNsQixNQUFNLE9BQ04sTUFBTSxRQUFRLHFCQUNiO0FBQ0QscUJBQU8sUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSSxHQUFJLENBQUM7WUFDdkU7VUFDRDtRQUNEO0FBQ0EsZUFBTyxJQUFJLE1BQU0sd0NBQXdDLFNBQVMsRUFBRSxDQUFDO01BQ3RFLFNBQVMsSUFBSTtBQUNaLGVBQU8sSUFBSSxNQUFNLE9BQU8sRUFBRSxDQUFDLENBQUM7TUFDN0I7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBTUEsZUFBc0IsOEJBQThCLFFBQWM7QUFDakUsU0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFVBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUVyQyxRQUFJLFdBQVc7QUFDZixRQUFJLEtBQUssU0FBUyxDQUFDLFFBQU87QUFDekIsVUFBSSxDQUFDLFVBQVU7QUFDZCxtQkFBVztBQUNYLFlBQUksTUFBSztBQUNULGVBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzdDO0lBQ0QsQ0FBQztBQUdELFFBQUksUUFBUSxHQUFHLFFBQVEsTUFBSztBQUMzQixVQUFJO0FBQ0gsY0FBTSxPQUFPLElBQUksUUFBTztBQUN4QixjQUFNLFlBQVksS0FBSztBQUN2QixZQUFJLENBQUMsVUFBVTtBQUNkLHFCQUFXO0FBQ1gsY0FBSSxNQUFLO0FBQ1Qsa0JBQVEsU0FBUztRQUNsQjtNQUNELFNBQVMsSUFBSTtBQUNaLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxpQkFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM3QjtNQUNEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQVdBLGVBQXNCLGdCQUNyQixVQUNBLGtCQUNBLFlBQVksS0FBSTtBQUVoQixRQUFNLHVCQUF1QjtBQUM3QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLGVBQWU7QUFFckIsUUFBTSxhQUFhLG9CQUFJLElBQUc7QUFFMUIsU0FBTyxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQ3BDLFVBQU0saUJBQWlCLE1BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUUzRSxVQUFNLFVBQVUsTUFBSztBQUNwQixVQUFJO0FBQ0gsdUJBQWUsZUFBZSxvQkFBb0I7TUFDbkQsUUFBUTtNQUVSO0FBQ0EsVUFBSTtBQUNILHVCQUFlLE1BQUs7TUFDckIsUUFBUTtNQUVSO0FBQ0EsY0FBTztJQUNSO0FBRUEsVUFBTSxRQUFRLFdBQVcsU0FBUyxTQUFTO0FBQzNDLFVBQU0sUUFBTztBQUViLG1CQUFlLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDbEMsTUFBQUEsUUFBTyxLQUFLLDBCQUEwQixJQUFJLE9BQU8sRUFBRTtJQUNwRCxDQUFDO0FBRUQsbUJBQWUsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzNDLFlBQU0sUUFBUSxNQUFNO0FBRXBCLFVBQUksSUFBSSxTQUFTO0FBQUk7QUFDckIsVUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVE7QUFDcEMsVUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWTtBQUUzRCxVQUFJLFdBQVcsSUFBSSxLQUFLO0FBQUc7QUFDM0IsaUJBQVcsSUFBSSxLQUFLO0FBQ3BCLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSywrQkFBMEI7QUFLN0QsWUFBTSxZQUFZLFlBQVc7QUFDNUIsY0FBTSxpQkFBaUIsS0FBSztBQUM1QixjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGlCQUFTLEtBQUssT0FBTyxjQUFjLE9BQU8sQ0FBQyxRQUFPO0FBQ2pELGNBQUk7QUFBSyxZQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssWUFBWSxJQUFJLE9BQU8sRUFBRTtRQUN4RSxDQUFDO01BQ0Y7QUFDQSxnQkFBUyxFQUFHLE1BQU0sQ0FBQyxRQUFRQSxRQUFPLEtBQUssdUJBQXVCLEdBQUcsRUFBRSxDQUFDO0lBQ3JFLENBQUM7QUFFRCxtQkFBZSxLQUFLLHFCQUFxQixNQUFLO0FBQzdDLFVBQUk7QUFDSCx1QkFBZSxjQUFjLG9CQUFvQjtBQUNqRCxRQUFBQSxRQUFPLEtBQUssb0NBQW9DLG9CQUFvQixJQUFJLG1CQUFtQixFQUFFO01BQzlGLFNBQVMsS0FBSztBQUNiLFFBQUFBLFFBQU8sS0FBSyw0Q0FBNEMsR0FBRyxFQUFFO01BQzlEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjs7O0FEblFBLElBQU1DLFVBQVMsbUJBQW1CLGNBQWM7QUFFMUMsSUFBTyxlQUFQLE1BQU8sY0FBWTtFQUNQLGNBQXNCO0VBQ3RCLGlCQUFpQjtFQUNqQixTQUFTO0VBRWxCO0VBQ0E7O0VBQ0EsY0FHSixvQkFBSSxJQUFHO0VBQ0gsbUJBQWdDLG9CQUFJLElBQUc7OztFQUd2QyxZQUEyQixRQUFRLFFBQU87O0VBRzFDLHNCQUFzQjs7RUFHdEI7O0VBR0EsUUFBZ0I7RUFDaEIsVUFBc0IsQ0FBQTtFQUN0QixzQkFBK0I7Ozs7Ozs7O0VBUS9CLGNBQWdELG9CQUFJLElBQUc7Ozs7Ozs7RUFRdkQsZ0JBQTZCLG9CQUFJLElBQUc7O0VBR3BDLHFCQUFnRSxvQkFBSSxJQUFHOztFQUd2RTs7RUFHQSxXQUFrQyxvQkFBSSxJQUFHO0VBRWpELGNBQUE7QUFDQyxJQUFBQSxRQUFPLEtBQUssMEJBQTBCO0FBSXRDLFNBQUssV0FBV0MsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ3BFLFNBQUssVUFBVSxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQzVDLFdBQUssU0FBUyxLQUFLLEdBQUcsTUFBSztBQUMxQixRQUFBRCxRQUFPLE1BQU0sMkJBQTRCLEtBQUssU0FBUyxRQUFPLEVBQXdCLElBQUksRUFBRTtBQUM1RixnQkFBTztNQUNSLENBQUM7SUFDRixDQUFDO0FBQ0QsU0FBSyxTQUFTLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDakMsTUFBQUEsUUFBTyxNQUFNLG9CQUFvQixHQUFHLEVBQUU7SUFDdkMsQ0FBQztBQUdELFNBQUssV0FBV0MsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBRXBFLFNBQUssU0FBUyxHQUFHLGFBQWEsTUFBSztBQUNsQyxZQUFNLE9BQU8sS0FBSyxTQUFTLFFBQU87QUFDbEMsTUFBQUQsUUFBTyxNQUFNLDBCQUEwQixLQUFLLFVBQVUsSUFBSSxDQUFDLEVBQUU7QUFDN0QsVUFBSTtBQUNILGFBQUssU0FBUyxxQkFBcUIsSUFBSTtNQUN4QyxTQUFTLElBQUk7TUFFYjtJQUNELENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBRUQsU0FBSyxTQUFTLEdBQUcsV0FBVyxDQUFDLEtBQUssVUFBUztBQUMxQyxVQUFJO0FBQ0gsYUFBSyxlQUFlLEtBQUssTUFBTSxPQUFPO01BQ3ZDLFNBQVMsSUFBSTtBQUNaLFFBQUFBLFFBQU8sTUFBTSxvQ0FBb0MsRUFBRSxFQUFFO01BQ3REO0lBQ0QsQ0FBQztBQUdELFNBQUssU0FBUyxLQUFLLEVBQUUsU0FBUyxXQUFXLE1BQU0sS0FBSyxPQUFNLEdBQUksTUFBSztBQUNsRSxNQUFBQSxRQUFPLE1BQU0sOEJBQThCLEtBQUssTUFBTSxFQUFFO0lBQ3pELENBQUM7RUFDRjtFQUVPLFFBQUs7QUFDWCxRQUFJO0FBQ0gsaUJBQVcsYUFBYSxNQUFNLEtBQUssS0FBSyxnQkFBZ0IsR0FBRztBQUMxRCxZQUFJO0FBQ0gsZUFBSyxTQUFTLGVBQWUsS0FBSyxnQkFBZ0IsU0FBUztRQUM1RCxRQUFRO1FBRVI7TUFDRDtJQUNELFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7QUFDQSxRQUFJO0FBQ0gsV0FBSyxTQUFTLE1BQUs7SUFDcEIsUUFBUTtJQUVSO0VBQ0Q7Ozs7O0VBTU8sU0FBUyxPQUFlLFNBQXFCLHNCQUErQixNQUFJO0FBQ3RGLFNBQUssUUFBUTtBQUNiLFNBQUssVUFBVTtBQUNmLFNBQUssc0JBQXNCO0VBQzVCOzs7OztFQU1PLG9CQUFvQixVQUFzQztBQUNoRSxTQUFLLG1CQUFtQjtFQUN6Qjs7RUFHTyxtQkFBbUIsSUFBVTtBQUNuQyxXQUFPLEtBQUssY0FBYyxJQUFJLEVBQUU7RUFDakM7O0VBR08sZ0JBQWdCLElBQVU7QUFDaEMsU0FBSyxjQUFjLElBQUksRUFBRTtBQUN6QixJQUFBQSxRQUFPLE1BQU0sd0JBQXdCLEVBQUUsRUFBRTtFQUMxQzs7RUFHTyxhQUFhLElBQVU7QUFDN0IsU0FBSyxjQUFjLE9BQU8sRUFBRTtBQUM1QixTQUFLLFlBQVksT0FBTyxFQUFFO0FBQzFCLFNBQUssU0FBUyxPQUFPLEVBQUU7QUFDdkIsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixFQUFFLEVBQUU7RUFDdkM7Ozs7Ozs7RUFRTyxNQUFNLFlBQVksSUFBWSxZQUFZLEtBQUk7QUFDcEQsV0FBTyxJQUFJLFFBQTJCLENBQUMsWUFBVztBQUNqRCxZQUFNLE1BQU0sV0FBVyxFQUFFO0FBQ3pCLFVBQUksV0FBVztBQUVmLFlBQU0sU0FBUyxDQUFDLFdBQTZCO0FBQzVDLFlBQUk7QUFBVTtBQUNkLG1CQUFXO0FBQ1gsYUFBSyxtQkFBbUIsT0FBTyxHQUFHO0FBQ2xDLGdCQUFRLE1BQU07TUFDZjtBQUVBLFdBQUssbUJBQW1CLElBQUksS0FBSyxDQUFDLFdBQXNCO0FBQ3ZELFlBQUksT0FBTyxPQUFPO0FBQUksaUJBQU8sTUFBTTtNQUNwQyxDQUFDO0FBRUQsWUFBTSxRQUFRLFdBQVcsTUFBTSxPQUFPLElBQUksR0FBRyxTQUFTO0FBQ3RELFlBQU0sUUFBTztBQUViLFlBQU0sTUFBTSxZQUFXO0FBQ3RCLGNBQU0sS0FBSyxvQkFBb0IsRUFBRTtBQUNqQyxjQUFNLEtBQUs7QUFDWCxjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGFBQUssU0FBUyxLQUFLLE9BQU8sS0FBSyxhQUFhLElBQUksQ0FBQyxRQUFPO0FBQ3ZELGNBQUksS0FBSztBQUNSLFlBQUFBLFFBQU8sS0FBSyxZQUFZLEVBQUUsWUFBWSxJQUFJLE9BQU8sRUFBRTtBQUNuRCx5QkFBYSxLQUFLO0FBQ2xCLG1CQUFPLElBQUk7VUFDWjtRQUNELENBQUM7TUFDRjtBQUVBLFVBQUcsRUFBRyxNQUFNLENBQUMsTUFBSztBQUNqQixRQUFBQSxRQUFPLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLEVBQUU7QUFDdEQscUJBQWEsS0FBSztBQUNsQixlQUFPLElBQUk7TUFDWixDQUFDO0lBQ0YsQ0FBQztFQUNGOzs7OztFQU1PLE1BQU0sbUJBQW1CLFVBQWdCO0FBQy9DLElBQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsUUFBUSxFQUFFO0FBQ3RELFVBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSxzQkFBc0IsUUFBVyxRQUFXLFFBQVcsVUFBVSxLQUFLO0FBRS9HLFdBQU87RUFDUjs7Ozs7Ozs7Ozs7RUFZTyxNQUFNLGdCQUFnQixZQUFZLEtBQUk7QUFFNUMsVUFBTSxnQkFBZ0I7QUFDdEIsVUFBTSxlQUE2QixDQUFBO0FBRW5DLFVBQU0sZ0JBQWdCLENBQUMsV0FBc0I7QUFDNUMsVUFBSSxDQUFDLGFBQWEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sRUFBRSxHQUFHO0FBQ2xELHFCQUFhLEtBQUssTUFBTTtNQUN6QjtJQUNEO0FBR0EsU0FBSyxtQkFBbUIsSUFBSSxlQUFlLGFBQWE7QUFFeEQsUUFBSTtBQUNILFlBQU0sS0FBSztBQUdYLFlBQU0sZ0JBQWdCLEtBQUssVUFBVSxPQUFPLFdBQVcsS0FBSyxvQkFBb0IsTUFBTSxHQUFHLFNBQVM7QUFDbEcsYUFBTztJQUNSO0FBQ0MsV0FBSyxtQkFBbUIsT0FBTyxhQUFhO0lBQzdDO0VBQ0Q7Ozs7O0VBTU8sTUFBTSx1QkFBdUIsVUFBZ0I7QUFDbkQsSUFBQUEsUUFBTyxLQUFLLG9DQUFvQyxRQUFRLEVBQUU7QUFDMUQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLGtCQUFrQixRQUFXLFFBQVcsUUFBVyxVQUFVLEtBQUs7QUFJM0csVUFBTSxZQUFZO0FBRWxCLFFBQUksU0FBUyxTQUFTLFlBQVksR0FBRztBQUNwQyxNQUFBQSxRQUFPLEtBQUssZ0NBQWdDLFNBQVMsTUFBTSxRQUFRO0FBQ25FLGFBQU87SUFDUjtBQUdBLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUNwQyxVQUFNLFFBQVEsU0FBUyxZQUFZLENBQUM7QUFFcEMsVUFBTSxXQUNMLFFBQVEsS0FDTCxNQUFNLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRyxJQUNoQyxNQUFNLFNBQVE7QUFFbEIsVUFBTSxXQUFXLEdBQUcsS0FBSyxJQUFJLFFBQVE7QUFFckMsSUFBQUEsUUFBTyxLQUFLLHFCQUFxQixRQUFRLEVBQUU7QUFDM0MsV0FBTztFQUNSOzs7OztFQU1RLE1BQU0sb0JBQW9CLFFBQWM7QUFDL0MsUUFBSTtBQUNILFlBQU0sWUFBWSxNQUFNLDhCQUE4QixNQUFNO0FBQzVELFVBQUksQ0FBQyxXQUFXO0FBQ2YsUUFBQUEsUUFBTyxLQUFLLHFEQUFxRCxNQUFNLEVBQUU7QUFDekU7TUFDRDtBQUVBLFVBQUksS0FBSyxpQkFBaUIsSUFBSSxTQUFTLEdBQUc7QUFFekM7TUFDRDtBQUVBLFVBQUk7QUFDSCxhQUFLLFNBQVMsY0FBYyxLQUFLLGdCQUFnQixTQUFTO0FBQzFELGFBQUssaUJBQWlCLElBQUksU0FBUztBQUNuQyxRQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssY0FBYyxPQUFPLFNBQVMsRUFBRTtNQUN0RSxTQUFTLElBQUk7QUFDWixRQUFBQSxRQUFPLEtBQUssK0JBQStCLFNBQVMsS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFO01BQ3RFO0lBQ0QsU0FBUyxJQUFJO0FBQ1osTUFBQUEsUUFBTyxLQUFLLCtCQUErQixFQUFFLEVBQUU7SUFDaEQ7RUFDRDtFQUVPLE1BQU0sYUFDWixPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUFJO0FBRWIsU0FBSztBQUNMLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxXQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssWUFDcEMsS0FBSyxjQUFjLE9BQU8sT0FBTyxXQUFXLE9BQU8sUUFBUSxNQUFNLEVBQy9ELEtBQUssQ0FBQyxRQUFPO0FBQ2IsYUFBSztBQUdMLFlBQUksS0FBSyx3QkFBd0IsS0FBSyxLQUFLLHVCQUF1QixVQUFVLFFBQVc7QUFDdEYsZUFBSyxtQkFBbUIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxRQUFPO0FBQzdDLFlBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsR0FBRyxFQUFFO1VBQy9ELENBQUM7UUFDRjtBQUNBLGdCQUFRLEdBQUc7TUFDWixDQUFDLEVBQ0EsTUFBTSxDQUFDLFFBQU87QUFDZCxhQUFLO0FBQ0wsZUFBTyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQztNQUMzRCxDQUFDLENBQUM7SUFFTCxDQUFDO0VBQ0Y7RUFFUSxNQUFNLGNBQ2IsT0FDQSxPQUNBLFdBQ0EsT0FDQSxRQUNBLFNBQVMsTUFBSTtBQUViLFVBQU0sWUFBWTtBQUVsQixVQUFNLFlBQXNCLENBQUE7QUFDNUIsUUFBSSxjQUFjO0FBQVcsZ0JBQVUsS0FBSyxZQUFZLEdBQUk7QUFDNUQsUUFBSSxVQUFVO0FBQVcsZ0JBQVUsS0FBSyxHQUFHLGNBQWEsZ0JBQWdCLEtBQUssQ0FBQztBQUU5RSxVQUFNLGNBQXdCLENBQUMsSUFBTSxRQUFRLEdBQUk7QUFFakQsUUFBSSxVQUFVLGVBQWUsVUFBVSxVQUFhLGNBQWMsVUFBYSxVQUFVLFFBQVc7QUFJbkcsVUFBSSxDQUFDLEtBQUssWUFBWSxJQUFJLE1BQU07QUFBRyxhQUFLLFlBQVksSUFBSSxRQUFRLG9CQUFJLElBQUcsQ0FBRTtBQUN6RSxZQUFNLFVBQVUsS0FBSyxZQUFZLElBQUksTUFBTTtBQUMzQyxZQUFNLGVBQWU7QUFDckIsWUFBTSxZQUFzQixDQUFBO0FBQzVCLGVBQVMsSUFBSSxHQUFHLElBQUksY0FBYyxLQUFLO0FBQ3RDLGNBQU0sV0FBVyxjQUFjLEtBQUssT0FBTyxhQUFhLEdBQUcsS0FBSztBQUNoRSxjQUFNLE1BQU0sTUFBTSxZQUFZLE9BQU8sS0FBSyxJQUFLLFFBQVEsSUFBSSxRQUFRLEtBQUs7QUFDeEUsa0JBQVUsS0FBSyxHQUFHO0FBQ2xCLGdCQUFRLElBQUksVUFBVSxHQUFHO01BQzFCO0FBQ0Esa0JBQVksS0FBSyxRQUFRLEtBQU0sR0FBRyxTQUFTO0lBQzVDLE9BQU87QUFDTixVQUFJLFVBQVU7QUFBVyxvQkFBWSxLQUFLLFFBQVEsR0FBSTtBQUN0RCxVQUFJO0FBQVEsb0JBQVksS0FBSyxVQUFVLE1BQU07QUFDN0MsVUFBSSxVQUFVLFNBQVM7QUFBRyxvQkFBWSxLQUFLLEdBQUcsU0FBUztJQUN4RDtBQUVBLFVBQU0sTUFBTSxjQUFhLFVBQVUsV0FBVztBQUM5QyxVQUFNLGlCQUFpQixPQUFPLEtBQUssQ0FBQyxHQUFHLGFBQWEsR0FBRyxDQUFDO0FBR3hELFFBQUksY0FBYyxVQUFhLFVBQVUsUUFBVztBQUNuRCxZQUFNLGFBQWEsY0FBYSxnQkFBZ0IsS0FBSztBQUNyRCxZQUFNLFVBQXlCO1FBQzlCLFFBQVE7UUFDUixJQUFJO1FBQ0o7UUFDQTs7QUFFRCxNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sb0JBQW9CLFNBQVMsS0FBSyxPQUFPLENBQUMsRUFBRTtJQUMzRSxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLE1BQU0sTUFBTSxNQUFNLGVBQWUsS0FBSyxDQUFDLEVBQUU7SUFDdEQ7QUFJQSxRQUFJLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxHQUFHO0FBQ3BDLE1BQUFBLFFBQU8sTUFBTSxxREFBZ0QsTUFBTSxLQUFLLGVBQWUsU0FBUyxLQUFLLENBQUMsRUFBRTtBQUN4RyxZQUFNLElBQUksTUFBTSxhQUFhLE1BQU0saUZBQTRFO0lBQ2hIO0FBR0EsVUFBTSxLQUFLLG9CQUFvQixNQUFNO0FBRXJDLFVBQU0sV0FBVyxLQUFLLGVBQWU7QUFDckMsVUFBTSxTQUFTLE1BQU0sS0FBSyxZQUFZLFVBQVUsTUFBTTtBQUN0RCxVQUFNLFNBQVMsT0FBTyxPQUFPLENBQUMsUUFBUSxjQUFjLENBQUM7QUFFckQsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixNQUFNLEtBQUssT0FBTyxTQUFTLEtBQUssQ0FBQyxFQUFFO0FBRXJFLFVBQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxLQUFLO0FBRTlCLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxZQUFNLFFBQVEsV0FBVyxNQUFLO0FBQzdCLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZUFBTyxJQUFJLE1BQU0sc0NBQXNDLEtBQUssS0FBSyxPQUFPLE1BQU0sT0FBTyxDQUFDO01BQ3ZGLEdBQUcsU0FBUztBQUVaLFdBQUssWUFBWSxJQUFJLEtBQUs7UUFDekIsU0FBUyxDQUFDLFFBQU87QUFDaEIsdUJBQWEsS0FBSztBQUNsQixrQkFBUSxHQUFHO1FBQ1o7UUFDQSxRQUFRLENBQUMsUUFBTztBQUNmLHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sR0FBRztRQUNYO1FBQ0E7T0FDQTtBQUVELFdBQUssU0FBUyxLQUFLLFFBQVEsS0FBSyxhQUFhLFFBQVEsQ0FBQyxRQUFPO0FBQzVELFlBQUksS0FBSztBQUNSLGVBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDN0M7TUFDRCxDQUFDO0lBQ0YsQ0FBQztFQUNGO0VBRVEsZUFBZSxLQUFhLE9BQWE7QUFDaEQsUUFBSSxJQUFJLFNBQVM7QUFBRztBQUNwQixRQUFJLElBQUksQ0FBQyxNQUFNLE9BQVEsSUFBSSxDQUFDLE1BQU07QUFBTTtBQUV4QyxVQUFNLFVBQVUsSUFBSSxhQUFhLENBQUM7QUFLbEMsUUFBSSxZQUFZLDJCQUEyQixLQUFLLG1CQUFtQixPQUFPLEdBQUc7QUFDNUUsWUFBTSxTQUFTLHVCQUF1QixLQUFLLEtBQUs7QUFDaEQsVUFBSSxRQUFRO0FBQ1gsUUFBQUEsUUFBTyxNQUNOLDRCQUE0QixLQUFLLGVBQ25CLE9BQU8sSUFBSSxhQUNkLE9BQU8sS0FBSyxpQkFDUixPQUFPLFNBQVMsb0JBQ2IsT0FBTyxZQUFZLEdBQUc7QUFJekMsWUFBSSxPQUFPLFNBQVMsWUFBWTtBQUMvQixxQkFBVyxNQUFNLEtBQUssbUJBQW1CLE9BQU0sR0FBSTtBQUNsRCxnQkFBSTtBQUNILGlCQUFHLE1BQU07WUFDVixRQUFRO1lBRVI7VUFDRDtRQUNELE9BQU87QUFDTixVQUFBQSxRQUFPLE1BQU0sc0RBQXNELE9BQU8sSUFBSSxPQUFPLEtBQUssRUFBRTtRQUM3RjtNQUNEO0FBQ0E7SUFDRDtBQUVBLFFBQUksSUFBSSxTQUFTO0FBQUk7QUFHckIsVUFBTSxNQUFNLElBQUksU0FBUyxJQUFJLEVBQUU7QUFDL0IsUUFBSSxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQVk7QUFJMUMsVUFBTSxZQUFZLElBQUksU0FBUyxFQUFFO0FBQ2pDLFFBQUksVUFBVSxTQUFTO0FBQUc7QUFDMUIsUUFBSSxVQUFVLENBQUMsTUFBTTtBQUFNO0FBRzNCLFVBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsVUFBTSxjQUFjLFlBQVksU0FBVTtBQUMxQyxVQUFNLGdCQUFnQixZQUFZO0FBR2xDLFFBQUksY0FBYyxrQkFBa0Isc0JBQXNCO0FBQ3pELE1BQUFBLFFBQU8sTUFBTSx3QkFBd0IsS0FBSyxLQUFLLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRTtJQUNyRTtBQUdBLFNBQUssYUFBYSxPQUFPLGVBQWUsS0FBSyxTQUFTO0FBR3RELFFBQUksWUFBWTtBQUNmLFlBQU0sTUFBTSxHQUFHLEtBQUssSUFBSSxhQUFhO0FBQ3JDLFlBQU0sVUFBVSxLQUFLLFlBQVksSUFBSSxHQUFHO0FBQ3hDLFVBQUksU0FBUztBQUNaLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZ0JBQVEsUUFBUSxHQUFHO01BQ3BCO0lBQ0Q7RUFFRDs7Ozs7Ozs7Ozs7O0VBYVEsYUFBYSxPQUFlLE9BQWUsS0FBYSxXQUFpQjtBQUNoRixVQUFNLFVBQVUsZUFBZSxLQUFLO0FBQ3BDLFVBQU0sT0FBTyxVQUFVLFNBQVMsR0FBRyxVQUFVLFNBQVMsQ0FBQztBQUd2RCxVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxDQUFDO0FBQzFDLFVBQU0sZ0JBQWdCLFFBQVEsTUFBTSxTQUFTLENBQUMsU0FBUyxLQUFLLFNBQVMsS0FBSyxDQUFDLFFBQVEsTUFBTSxHQUFHLENBQUM7QUFLN0YsUUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFJLENBQUMsS0FBSyxPQUFPO0FBQ2hCLFFBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxFQUFFO0FBQ3pEO01BQ0Q7QUFDQSxVQUFJO0FBQ0gsY0FBTSxXQUNMLFVBQVUsb0JBQ1Asc0JBQXNCLEtBQUssT0FBTyxHQUFHLElBQ3JDLDRCQUE0QixLQUFLLE9BQU8sR0FBRztBQUUvQyxjQUFNLFlBQVksS0FBSyxZQUFZLElBQUksS0FBSyxLQUFLLG9CQUFJLElBQUc7QUFDeEQsY0FBTSxXQUFXLElBQUksSUFBb0IsU0FBUztBQUVsRCxtQkFBVyxLQUFLLFVBQVU7QUFDekIsZ0JBQU0sV0FBVyxjQUFjLEtBQUssT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSztBQUVsRSxnQkFBTSxXQUNMLEVBQUUsV0FBVyxXQUFXLElBQ3BCLEVBQUUsV0FBVyxDQUFDLEtBQUssS0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLElBQUssRUFBRSxXQUFXLENBQUMsSUFDaEUsRUFBRSxXQUFXLENBQUMsS0FBSztBQUN4QixnQkFBTSxZQUFZLFVBQVUsSUFBSSxRQUFRO0FBQ3hDLGdCQUFNLFVBQVUsY0FBYyxVQUFhLGNBQWM7QUFFekQsbUJBQVMsSUFBSSxVQUFVLFFBQVE7QUFFL0IsZ0JBQU0sWUFBWSxvQkFBb0IsR0FBRyxLQUFLLE9BQU87QUFDckQsY0FBSSxTQUFTO0FBQ1osWUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLFNBQVMsRUFBRTtBQUV4QyxnQkFBSSxLQUFLLGtCQUFrQjtBQUMxQixvQkFBTSxrQkFBa0IsY0FBYyxLQUFLLE9BQU8sRUFBRSxRQUFRLEVBQUUsRUFBRTtBQUVoRSxtQkFBSyxpQkFBaUIsZUFBZTtZQUN0QyxPQUFPO0FBQ04sY0FBQUEsUUFBTyxLQUFLLGdFQUEyRCxRQUFRLEVBQUU7WUFDbEY7VUFDRCxPQUFPO0FBQ04sWUFBQUEsUUFBTyxNQUFNLE1BQU0sS0FBSyxNQUFNLFNBQVMsRUFBRTtVQUMxQztRQUNEO0FBQ0EsYUFBSyxZQUFZLElBQUksT0FBTyxRQUFRO01BQ3JDLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLG9CQUFvQixDQUFDLE1BQU0sYUFBYSxFQUFFO01BQy9FO0FBQ0E7SUFDRDtBQUdBLFVBQU0sVUFBVSxLQUFLLGFBQWEsT0FBTyxJQUFJO0FBRTdDLFVBQU0sUUFBUSxVQUFVLGNBQWNBLFFBQU8sTUFBTSxLQUFLQSxPQUFNLElBQUlBLFFBQU8sS0FBSyxLQUFLQSxPQUFNO0FBQ3pGLFFBQUksU0FBUztBQUNaLFlBQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsTUFBTSxPQUFPLEVBQUU7SUFDakUsT0FBTztBQUNOLFlBQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsRUFBRTtJQUNwRDtFQUNEOzs7OztFQU1RLGFBQWEsT0FBZSxNQUFZO0FBQy9DLFFBQUksS0FBSyxXQUFXO0FBQUcsYUFBTztBQUc5QixRQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLFVBQUksS0FBSyxDQUFDLE1BQU0sR0FBTTtBQUNyQixlQUFPO01BQ1IsT0FBTztBQUNOLGVBQU8sU0FBUyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7TUFDL0I7SUFDRDtBQUVBLFlBQVEsT0FBTzs7O01BR2QsS0FBSyxhQUFhO0FBQ2pCLGNBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsY0FBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLEVBQ3RDLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQ2pFLEtBQUssR0FBRztBQUNWLGVBQU8sTUFBTSxLQUFLLElBQUksSUFBSTtNQUMzQjs7Ozs7TUFNQSxLQUFLLGNBQWM7QUFDbEIsWUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixpQkFBTyxLQUFLLENBQUMsTUFBTSxJQUFPLFdBQVcsV0FBVyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDL0Q7QUFDQSxZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxVQUFVLFFBQVEsVUFBVSxDQUFDLEdBQUc7QUFDdEMsZ0JBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxnQkFBTSxjQUNMLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBQ3JGLGdCQUFNLFdBQVcsY0FBYyxHQUFHLFdBQVcsS0FBSyxNQUFNLFFBQVMsQ0FBQyxNQUFNLFdBQVcsTUFBTSxLQUFLLFVBQVUsQ0FBQztBQUN6RyxnQkFBTSxTQUFTLElBQUksTUFBTSxLQUFLLENBQUMsSUFBSSxNQUFNLFNBQVMsQ0FBQyxLQUFLLFdBQVcsTUFBTSxLQUFLLFVBQVUsQ0FBQyxDQUFDO0FBQzFGLGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRLElBQUksTUFBTTtRQUNoRTtBQUNBLGVBQU8sUUFBUSxLQUFLLFNBQVMsS0FBSyxDQUFDO01BQ3BDOztNQUdBLEtBQUssaUJBQWlCO0FBRXJCLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDckIsZ0JBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsZ0JBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsZ0JBQU0sYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNsQyxnQkFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUNoRixnQkFBTSxjQUFjLFFBQVEsUUFBUSxXQUFXLE1BQU0sU0FBUyxDQUFDO0FBQy9ELGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sVUFBVSxRQUFRLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sR0FBRztBQUNoRSxnQkFBTSxjQUNMLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBQ3JGLGdCQUFNLFdBQVcsZUFBZSxLQUFLLFdBQVcsU0FBUyxLQUFLLENBQUM7QUFDL0QsaUJBQU8sV0FBVyxLQUFLLE1BQU0sV0FBVyxLQUFLLFFBQVE7UUFDdEQ7QUFDQSxlQUFPO01BQ1I7O01BR0EsS0FBSztNQUNMLEtBQUssYUFBYTtBQUNqQixZQUFJLEtBQUssU0FBUztBQUFHLGlCQUFPO0FBQzVCLGNBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsY0FBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixjQUFNLFFBQVEsS0FBSyxTQUFTLENBQUM7QUFDN0IsZUFBTyxNQUFNLEtBQUssWUFBWSxNQUFNLFNBQVMsQ0FBQyxVQUFVLE1BQU0sU0FBUyxLQUFLLENBQUM7TUFDOUU7TUFFQTtBQUNDLGVBQU87SUFDVDtFQUNEO0VBRVEsT0FBTyxnQkFBZ0IsT0FBYztBQUM1QyxRQUFJLE9BQU8sVUFBVTtBQUFXLGFBQU8sQ0FBQyxRQUFRLElBQUksQ0FBQztBQUNyRCxRQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUcsYUFBTyxNQUFNLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxJQUFJLEdBQUk7QUFDbEUsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM5QixVQUFJLFFBQVE7QUFBTSxlQUFPLENBQUUsU0FBUyxLQUFNLEtBQU8sU0FBUyxJQUFLLEtBQU0sUUFBUSxHQUFJO0FBQ2pGLGFBQU8sQ0FBQyxRQUFRLEdBQUk7SUFDckI7QUFDQSxVQUFNLElBQUksTUFBTSw0Q0FBNEMsS0FBSyxFQUFFO0VBQ3BFO0VBRVEsTUFBTSxZQUFZLFVBQWtCLFFBQWM7QUFDekQsUUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLE1BQU07QUFDbEMsUUFBSSxDQUFDLEtBQUs7QUFDVCxZQUFNLE1BQU0scUJBQXFCLE1BQU07QUFDdkMsV0FBSyxTQUFTLElBQUksUUFBUSxHQUFHO0lBQzlCO0FBRUEsV0FBTyxPQUFPLE9BQU87TUFDcEIsT0FBTyxLQUFLLENBQUMsS0FBTSxLQUFNLEdBQU0sV0FBVyxLQUFNLEdBQU0sS0FBTSxHQUFNLEdBQU0sR0FBRyxLQUFLLEdBQU0sQ0FBSSxDQUFDO01BQzNGLE9BQU8sS0FBSyxZQUFZLE1BQU07S0FDOUI7RUFDRjtFQUVRLE9BQU8sVUFBVSxNQUFjO0FBQ3RDLFFBQUksTUFBTTtBQUNWLGVBQVcsS0FBSyxNQUFNO0FBQ3JCLGFBQU87QUFDUCxlQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUMzQixlQUFPLE1BQU0sU0FBVSxLQUFNLE9BQU8sSUFBSyxPQUFRLE1BQVEsT0FBTyxJQUFLO01BQ3RFO0lBQ0Q7QUFDQSxXQUFPO0VBQ1I7Ozs7Ozs7Ozs7RUFXTyxnQkFBZ0IsSUFBWSxPQUFlLFdBQW1CLE9BQWM7QUFDbEYsVUFBTSxNQUFNLGNBQWMsS0FBSyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQzdELFdBQU8sS0FBSyxZQUFZLElBQUksRUFBRSxHQUFHLElBQUksR0FBRztFQUN6QztFQUVPLE1BQU0sWUFBWSxRQUFjO0FBQ3RDLFdBQU8sS0FBSyxhQUFhLGtCQUFrQixRQUFXLEdBQU0sUUFBVyxRQUFRLEtBQUs7RUFDckY7RUFFTyxNQUFNLGNBQWMsUUFBYztBQUN4QyxXQUFPLEtBQUssYUFBYSxxQkFBcUIsUUFBVyxRQUFXLFFBQVcsUUFBUSxLQUFLO0VBQzdGOzs7O0FFenZCRCxJQUFNRSxVQUFTLG1CQUFtQixnQkFBZ0I7QUFNbEQsSUFBcUIsaUJBQXJCLGNBQTRDLGFBQXlCO0VBQ3BFOztFQUNBOzs7RUFJUSxvQkFBa0MsQ0FBQTs7O0VBSTFDLGNBQXNCO0VBRXRCLFlBQVksVUFBaUI7QUFDNUIsVUFBTSxRQUFRO0VBQ2Y7RUFFQSxNQUFNLEtBQUssUUFBb0I7QUFDOUIsU0FBSyxTQUFTO0FBQ2QsUUFBSSxDQUFDLEtBQUssY0FBYztBQUN2QixXQUFLLGVBQWUsSUFBSSxhQUFZO0lBQ3JDO0FBQ0EsU0FBSyxhQUFhLGVBQWUsWUFBWSx3QkFBd0I7QUFHckUsU0FBSyxhQUFhLG9CQUFvQixDQUFDLGVBQXNCO0FBQzVELFdBQUssZUFBZSxVQUFVO0lBQy9CLENBQUM7QUFJRCxTQUFLLGFBQVksRUFBRyxNQUFNLENBQUMsTUFBSztBQUMvQixNQUFBQSxRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtJQUN0QyxDQUFDO0VBQ0Y7Ozs7Ozs7RUFRUSxNQUFNLGVBQVk7QUFDekIsSUFBQUEsUUFBTyxLQUFLLDhCQUE4QjtBQUUxQyxTQUFLLG9CQUFvQixNQUFNLEtBQUssYUFBYSxnQkFBZTtBQUdoRSxRQUFJO0FBQ0osUUFBSSxLQUFLLGtCQUFrQixXQUFXLEdBQUc7QUFFeEMsVUFBSSxLQUFLLE9BQU8sV0FBVztBQUMxQixjQUFNLGFBQWEsS0FBSyxPQUFPLGNBQWMsU0FBUyxLQUFLLE9BQU8sV0FBVyxNQUFNO0FBQ25GLFFBQUFBLFFBQU8sS0FBSyxxQkFBcUIsS0FBSyxPQUFPLFNBQVMsOENBQXlDO0FBQy9GLGFBQUssYUFBYSxlQUFlLG1CQUFtQixHQUFHLFVBQVUsSUFBSSxLQUFLLE9BQU8sU0FBUyxhQUFhO0FBQ3ZHO01BQ0Q7QUFDQSxZQUFNLGNBQWMsS0FBSyxPQUFPO0FBQ2hDLFVBQUksQ0FBQyxLQUFLLE9BQU8sUUFBUSxDQUFDLGFBQWE7QUFDdEMsUUFBQUEsUUFBTyxLQUFLLHlEQUF5RDtBQUNyRTtNQUNEO0FBQ0EsTUFBQUEsUUFBTyxLQUFLLHdFQUFtRTtBQUMvRSx1QkFBaUI7SUFDbEIsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxjQUFjLEtBQUssa0JBQWtCLE1BQU0sYUFBYTtBQUNwRSxpQkFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3ZDLFFBQUFBLFFBQU8sS0FBSyxhQUFhLEVBQUUsS0FBSyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRTtNQUNyRTtBQUtBLGlCQUFXLFVBQVUsS0FBSyxtQkFBbUI7QUFDNUMsYUFBSyxhQUFhLGdCQUFnQixPQUFPLEVBQUU7TUFDNUM7QUFHQSxpQkFBVyxVQUFVLEtBQUssbUJBQW1CO0FBQzVDLFlBQUk7QUFDSCxnQkFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLHVCQUF1QixPQUFPLEVBQUU7QUFDekUsaUJBQU8sZUFBZTtBQUN0QixVQUFBQSxRQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsY0FBYyxRQUFRLFdBQVcsT0FBTyxhQUFhLEVBQUU7UUFDcEYsU0FBUyxHQUFHO0FBQ1gsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLDZCQUE2QixDQUFDLEVBQUU7QUFDNUQsaUJBQU8sZUFBZTtRQUN2QjtNQUNEO0FBRUEsdUJBQWlCLGFBQWEsS0FBSyxRQUFRLEtBQUssaUJBQWlCO0FBR2pFLFVBQUksQ0FBQyxrQkFBa0IsS0FBSyxPQUFPLFdBQVc7QUFDN0MsY0FBTSxhQUFhLEtBQUssT0FBTyxjQUFjLFNBQVMsS0FBSyxPQUFPLFdBQVcsTUFBTTtBQUNuRixRQUFBQSxRQUFPLEtBQUsscUJBQXFCLEtBQUssT0FBTyxTQUFTLHNEQUFpRDtBQUN2RyxhQUFLLGFBQWEsZUFBZSxtQkFBbUIsR0FBRyxVQUFVLElBQUksS0FBSyxPQUFPLFNBQVMsYUFBYTtBQUN2RztNQUNEO0lBQ0Q7QUFHQSxTQUFLLFVBQVUsY0FBYztBQUk3QixVQUFNLGFBQWEsS0FBSztBQUN4QixVQUFNLEtBQUssb0JBQW9CLElBQUksVUFBVTtBQUc3QyxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtBQUV6QixTQUFLLGFBQWEsZUFBZSxFQUFFO0FBQ25DLElBQUFBLFFBQU8sS0FBSywyQkFBMkI7RUFDeEM7O0VBR0EsTUFBTSxVQUFPO0FBQ1osU0FBSyxjQUFjLE1BQUs7QUFDeEIsSUFBQUEsUUFBTyxNQUFNLFNBQVM7RUFDdkI7RUFFQSxNQUFNLGNBQWMsUUFBb0I7QUFDdkMsVUFBTSxlQUFlLEtBQUs7QUFDMUIsU0FBSyxTQUFTO0FBQ2QsVUFBTSxpQkFBaUIsYUFBYSxRQUFRLEtBQUssaUJBQWlCO0FBQ2xFLFNBQUssVUFBVSxjQUFjO0FBSTdCLFNBQUsscUJBQW9CO0FBRXpCLFVBQU0sVUFBVSxLQUFLO0FBSXJCLFVBQU0sS0FBSyxvQkFBb0IsY0FBYyxPQUFPO0FBR3BELFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0VBQzFCOzs7Ozs7Ozs7Ozs7RUFhUSxNQUFNLG9CQUFvQixjQUFzQixTQUFlO0FBQ3RFLFFBQUksQ0FBQyxTQUFTO0FBQ2IsVUFBSTtBQUFjLGFBQUssYUFBYSxhQUFhLFlBQVk7QUFDN0Q7SUFDRDtBQUVBLFFBQUksS0FBSyxPQUFPLFdBQVc7QUFFMUIsWUFBTSxTQUFTLEtBQUssa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxLQUFLLE9BQU8sU0FBUztBQUNqRixVQUFJLENBQUMsUUFBUTtBQUNaLFFBQUFBLFFBQU8sS0FBSyxlQUFlLEtBQUssT0FBTyxTQUFTLHlEQUFvRDtBQUNwRyxZQUFJO0FBQWMsZUFBSyxhQUFhLGFBQWEsWUFBWTtBQUM3RDtNQUNEO0FBRUEsVUFBSSxnQkFBZ0IsaUJBQWlCLFNBQVM7QUFDN0MsYUFBSyxhQUFhLGFBQWEsWUFBWTtNQUM1QztBQUNBLFlBQU0sZ0JBQWdCLEtBQUssYUFBYSxtQkFBbUIsT0FBTztBQUNsRSxVQUFJLENBQUMsZUFBZTtBQUNuQixhQUFLLGFBQWEsZ0JBQWdCLE9BQU87TUFDMUM7QUFDQSxVQUFJLFlBQVksZ0JBQWdCLENBQUMsZUFBZTtBQUMvQyxjQUFNLEtBQUssNkJBQTZCLE9BQU8sT0FBTyxPQUFPO01BQzlEO0FBQ0E7SUFDRDtBQUdBLFVBQU0sY0FBYyxPQUFPLEtBQUssT0FBTyxlQUFlLEVBQUU7QUFDeEQsVUFBTSxpQkFBaUIsS0FBSyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFFMUUsUUFBSSxnQkFBZ0I7QUFDbkIsVUFBSSxlQUFlLFVBQVUsYUFBYTtBQUN6QyxZQUFJLGdCQUFnQixpQkFBaUI7QUFBUyxlQUFLLGFBQWEsYUFBYSxZQUFZO0FBQ3pGLGNBQU0sZ0JBQWdCLEtBQUssYUFBYSxtQkFBbUIsT0FBTztBQUNsRSxZQUFJLENBQUMsZUFBZTtBQUNuQixlQUFLLGFBQWEsZ0JBQWdCLE9BQU87UUFDMUM7QUFDQSxZQUFJLFlBQVksZ0JBQWdCLENBQUMsZUFBZTtBQUMvQyxnQkFBTSxLQUFLLDZCQUE2QixhQUFhLE9BQU87UUFDN0Q7TUFDRCxPQUFPO0FBQ04sUUFBQUEsUUFBTyxNQUNOLDBCQUEwQixXQUFXLDJDQUEyQyxlQUFlLEtBQUssUUFBUSxPQUFPLDBCQUFxQjtBQUV6SSxhQUFLLGFBQWEsYUFBYSxPQUFPO0FBQ3RDLGFBQUssYUFDSixlQUFlLG1CQUNmLDRCQUE0QixXQUFXLFNBQVMsZUFBZSxLQUFLLEVBQUU7TUFFeEU7QUFDQTtJQUNEO0FBR0EsSUFBQUEsUUFBTyxLQUFLLEdBQUcsT0FBTyx3Q0FBbUM7QUFDekQsUUFBSSxnQkFBZ0IsaUJBQWlCO0FBQVMsV0FBSyxhQUFhLGFBQWEsWUFBWTtBQUN6RixTQUFLLGFBQWEsYUFBYSxPQUFPO0FBRXRDLFVBQU0sU0FBUyxNQUFNLEtBQUssYUFBYSxZQUFZLE9BQU87QUFDMUQsUUFBSSxDQUFDLFFBQVE7QUFDWixNQUFBQSxRQUFPLE1BQU0sMEJBQTBCLE9BQU8sMEJBQXFCO0FBQ25FLFdBQUssYUFBYSxlQUFlLGdCQUFnQixtQkFBbUIsT0FBTyxFQUFFO0lBQzlFLFdBQVcsT0FBTyxVQUFVLGFBQWE7QUFDeEMsTUFBQUEsUUFBTyxNQUNOLDBCQUEwQixXQUFXLDJDQUEyQyxPQUFPLEtBQUssUUFBUSxPQUFPLDBCQUFxQjtBQUVqSSxXQUFLLGFBQ0osZUFBZSxtQkFDZiw0QkFBNEIsV0FBVyxTQUFTLE9BQU8sS0FBSyxFQUFFO0lBRWhFLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssa0JBQWtCLE9BQU8sS0FBSyxPQUFPLE9BQU8sRUFBRTtBQUMxRCxXQUFLLGFBQWEsZ0JBQWdCLE9BQU87QUFDekMsWUFBTSxLQUFLLDZCQUE2QixhQUFhLE9BQU87QUFDNUQsV0FBSyxhQUFhLGVBQWUsRUFBRTtJQUNwQztFQUNEOzs7OztFQU1RLE1BQU0sNkJBQTZCLE9BQWUsSUFBVTtBQUNuRSxRQUFJO0FBQ0gsWUFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUU7QUFFN0MsVUFBSSxDQUFDLGdCQUFnQixLQUFLLEdBQUc7QUFHNUIsUUFBQUEsUUFBTyxLQUFLLDZCQUE2QixLQUFLLHNEQUFpRDtBQUMvRjtNQUNEO0lBQ0QsU0FBUyxHQUFHO0FBQ1gsTUFBQUEsUUFBTyxLQUFLLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxFQUFFO0lBQ3hEO0VBQ0Q7O0VBR1EsVUFBVSxPQUFhO0FBQzlCLFNBQUssY0FBYztBQUNuQixVQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsUUFBSSxDQUFDLFFBQVE7QUFDWixNQUFBQSxRQUFPLEtBQUssVUFBVSxLQUFLLCtCQUErQjtBQUMxRCxXQUFLLGFBQWEsU0FBUyxPQUFPLENBQUEsR0FBSSxJQUFJO0FBQzFDO0lBQ0Q7QUFFQSxVQUFNLFVBQVUsTUFBTSxRQUFRLE9BQU8sU0FBUyxJQUFJLE9BQU8sWUFBWSxDQUFBO0FBQ3JFLFVBQU0sc0JBQXNCLE9BQU8sdUJBQXVCO0FBRTFELFNBQUssYUFBYSxTQUFTLE9BQU8sU0FBUyxtQkFBbUI7QUFDOUQsUUFBSSxRQUFRLFdBQVcsR0FBRztBQUN6QixNQUFBQSxRQUFPLEtBQUssK0JBQStCLEtBQUssNkNBQXdDO0lBQ3pGLE9BQU87QUFDTixNQUFBQSxRQUFPLE1BQ04sVUFBVSxRQUFRLE1BQU0sdUJBQXVCLEtBQUssZ0JBQWdCLE9BQU8sU0FBUyx5QkFBeUIsbUJBQW1CLEVBQUU7SUFFcEk7RUFDRDtFQUVBLGtCQUFlO0FBQ2QsV0FBTyxnQkFBZ0IsS0FBSyxpQkFBaUI7RUFDOUM7O0VBR0EsSUFBSSxPQUFJO0FBQ1AsV0FBTyxZQUFZLEtBQUssUUFBUSxLQUFLLGlCQUFpQjtFQUN2RDs7RUFHQSxJQUFJLFVBQU87QUFDVixXQUFPLEtBQUs7RUFDYjtFQUVBLGdCQUFhO0FBQ1osa0JBQWMsSUFBSTtFQUNuQjtFQUVBLGtCQUFlO0FBQ2Qsb0JBQWdCLElBQUk7RUFDckI7RUFFQSw0QkFBeUI7QUFDeEIsOEJBQTBCLElBQUk7RUFDL0I7RUFFQSx1QkFBb0I7QUFDbkIseUJBQXFCLElBQUk7RUFDMUI7OyIsCiAgIm5hbWVzIjogWyJwYXRoIiwgIkluc3RhbmNlU3RhdHVzIiwgIlJlZ2V4IiwgInBhdGgiLCAiZnMiLCAibG9nZ2VyIiwgImxvZ2dlciIsICJpZEFkZE9wdCIsICJmcyIsICJsb2dnZXIiLCAiZGV2aWNlc0ZvbGRlciIsICJwYXRoIiwgImRncmFtIiwgImxvZ2dlciIsICJsb2dnZXIiLCAiZGdyYW0iLCAibG9nZ2VyIl0KfQo=
