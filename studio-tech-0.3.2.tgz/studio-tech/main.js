import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// dist/main.js
import path6 from "path";

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path7, args) {
    this.#context.oscSend(host, port, path7, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
var devicesFolder = path.join(import.meta.dirname, "../devices");
function loadAvailableModels() {
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    const models = [];
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const j = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (j?.model) {
        models.push(String(j.model));
      }
    }
    return models.sort();
  } catch (_e) {
    logger.error(`Failed to load device models: ${_e}`);
    return [];
  }
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual" },
    ...discoveredDevices.map((d) => ({
      id: d.ip,
      label: `Model ${d.model} (${d.ip})`
    }))
  ];
  return [
    // ── Device discovery dropdown ────────────────────────────────────────
    // Mirrors the bonjour-device field: selecting a device populates the
    // host automatically; selecting 'Manual' shows the textinput below.
    {
      type: "dropdown",
      id: "discoveredHost",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies Dante device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry ──────────────────────────────────────────────────
    // Only visible when discoveredHost is '' (Manual selected).
    // Matches the pattern from the bonjour-device docs.
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Model selector ───────────────────────────────────────────────────
    // Only visible when Manual mode is selected (no discovered device).
    // When a discovered device is selected, the model is auto-detected.
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Select which Studio Technologies model is active for actions and Get All Settings"
    }
  ];
}
function resolveHost(config) {
  return config.discoveredHost || config.host;
}
function resolveModel(config, discoveredDevices) {
  if (config.discoveredHost) {
    const device = discoveredDevices.find((d) => d.ip === config.discoveredHost);
    console.log(`resolveModel: discoveredHost="${config.discoveredHost}", found device:`, device);
    if (device?.model) {
      return device.model;
    }
  }
  console.log(`resolveModel: falling back to activeModel="${config.activeModel}"`);
  return config.activeModel;
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    variable1: { name: "My first variable" },
    variable2: { name: "My second variable" },
    variable3: { name: "Another variable" }
  });
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/build-commands.js
import fs2 from "fs";
import path2 from "path";

// dist/types.js
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_BUS_GET:
      return "Get Bus Setting";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}

// dist/build-commands.js
var devicesFolder2 = path2.join(import.meta.dirname, "../devices");
function loadUiSchemas(dir = devicesFolder2) {
  const files = fs2.readdirSync(dir).filter((f) => f.endsWith(".json"));
  const out = {};
  for (const f of files) {
    const j = JSON.parse(fs2.readFileSync(path2.join(dir, f), "utf8"));
    out[j.model] = j;
  }
  return out;
}
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "textinput":
    case "colorpicker":
    case "static-text":
    default:
      return base;
  }
}
function buildActions(dir = devicesFolder2) {
  const schemas = loadUiSchemas(dir);
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks(dir = devicesFolder2) {
  const schemas = loadUiSchemas(dir);
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path4 from "path";
import fs4 from "fs";

// dist/settingsParser.js
import fs3 from "fs";
import path3 from "path";
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const schemaPath = path3.resolve(`./devices/Model${model}.json`);
    const json = JSON.parse(fs3.readFileSync(schemaPath, "utf-8"));
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function modelDistance(a, b) {
  const na = parseInt(a.replace(/\D/g, ""), 10);
  const nb = parseInt(b.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = `0x${setting.cmd_id.toString(16).padStart(2, "0")}`;
  const idHex = `0x${setting.id.toString(16).padStart(2, "0")}`;
  const valHex = `0x${setting.valueBytes.map((b) => b.toString(16).padStart(2, "0")).join("")}`;
  const valDec = setting.valueBytes.length === 3 ? `#${setting.valueBytes.map((b) => b.toString(16).padStart(2, "0")).join("").toUpperCase()}` : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.actions) {
    out.actions = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  console.log(`Updating model: ${modelJson.model}`);
  console.log(`Candidates for inference: ${candidates.map((c) => c.model)}`);
  for (const { cmd_id, id, valueBytes } of parsed) {
    let action = out.actions.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (!action) {
      for (const c of candidates) {
        const match = c.actions?.find((a) => a.cmd_id === cmd_id && a.id === id);
        if (match) {
          action = structuredClone(match);
          action.name = `${match.name} (inferred from Model ${c.model})`;
          console.log(`Inferred setting 0x${id.toString(16)} from Model ${c.model}`);
          break;
        }
      }
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown Setting 0x${id.toString(16).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      console.log(`Could not infer setting 0x${id.toString(16)}`);
    } else {
      const opt = action.options?.[0];
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
    }
    const exists = out.actions.some((a) => a.cmd_id === action.cmd_id && a.id === action.id);
    if (!exists)
      out.actions.push(action);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    let json = JSON.stringify(jsonObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs3.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    console.log("File Write Error:", e);
  }
}
function loadModelConfig(devicesFolder4, model) {
  try {
    const filePath = path3.join(devicesFolder4, `Model${model}.json`);
    const json = JSON.parse(fs3.readFileSync(filePath, "utf8"));
    return {
      actions: json?.cmdSchema ?? [],
      refreshAfterCommand: json?.refreshAfterCommand ?? true
      // Default to true if not specified
    };
  } catch {
    return { actions: [], refreshAfterCommand: true };
  }
}

// dist/actions.js
function UpdateActions(self) {
  const devicesFolder4 = path4.join(import.meta.dirname, "../devices");
  const schemasRaw = loadUiSchemas(devicesFolder4);
  const rawActions = buildActions(devicesFolder4);
  const schemas = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    schemas[model] = {
      model: json.model,
      actions: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  const wiredActions = {};
  const activeModel = resolveModel(self.config, self.devices);
  console.log(`UpdateActions: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  wiredActions["global_getAllSettings"] = {
    name: "GLOBAL: Get All Settings (Auto-Update JSON)",
    options: [],
    callback: async () => {
      const model = activeModel;
      const ip = self.host;
      const buf = await self.stController.requestAllSettings(ip);
      const schemaPath = path4.join(devicesFolder4, `model${model}.json`);
      const modelJson = JSON.parse(fs4.readFileSync(schemaPath, "utf8"));
      const parsed = parseGetAllSettingsForModel(model, buf);
      console.log("parsed reply: ", parsed);
      const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
      console.log("new Actions json: ", JSON.stringify(updated, null, 2));
      saveModelJsonPretty(schemaPath, updated);
      console.log(`Model ${model} JSON auto-updated from getAllSettings`);
    }
  };
  for (const [actionId, action] of Object.entries(rawActions)) {
    const [model, cmdIdStr, idStr] = actionId.split("_");
    if (model !== activeModel)
      continue;
    const cmdId = parseInt(cmdIdStr, 16);
    const baseId = parseInt(idStr, 16);
    const schema = schemas[model];
    const rawAction = schema?.actions?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(activeModel, cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.actions ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          console.log(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(activeModel, ip);
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
  console.log("UpdateActions: wired actions:", Object.keys(wiredActions).length);
}

// dist/feedbacks.js
import path5 from "path";
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.actions))
    return value;
  let setting = schema.actions.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!setting) {
    setting = schema.actions.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const devicesFolder4 = path5.join(import.meta.dirname, "../devices");
  const schemasRaw = loadUiSchemas(devicesFolder4);
  const rawFeedbacks = buildFeedbacks(devicesFolder4);
  const schemas = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    schemas[model] = {
      model: json.model,
      actions: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  const wiredFeedbacks = {};
  const activeModel = resolveModel(self.config, self.devices);
  console.log(`UpdateFeedbacks: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const [model, cmdIdStr, idStr] = feedbackId.split("_");
    if (model !== activeModel)
      continue;
    const cmdId = parseInt(cmdIdStr, 16);
    const baseId = parseInt(idStr, 16);
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const busCh = feedbackEvent.options["busCh"];
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
  console.log("UpdateFeedbacks: wired feedbacks:", Object.keys(wiredFeedbacks).length);
}

// dist/stcontroller.js
import dgram2 from "dgram";
import os2 from "os";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger2 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 14);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const firmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return { ip: srcIp, name, manufacturer, model, mac, firmware };
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, onDeviceFound, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const found = /* @__PURE__ */ new Map();
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const wrappedCallback = (device) => {
      if (!found.has(device.ip)) {
        found.set(device.ip, device);
        onDeviceFound(device);
      }
    };
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve(Array.from(found.values()));
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger2.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger2.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      ensureMembership(srcIp).then(() => {
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger2.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      }).catch((err) => logger2.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger2.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger2.warn(`Could not join announce multicast group: ${err}`);
      }
    });
    announceSocket.wrappedCallback = wrappedCallback;
  });
}

// dist/stcontroller.js
var logger3 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks;
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  constructor() {
    logger3.info("StController initialized");
    this.pendingAcks = /* @__PURE__ */ new Map();
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger3.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger3.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger3.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger3.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger3.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger3.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger3.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(this.model, CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    console.log("Raw response buffer:", response.toString("hex"));
    console.log("Response length:", response.length);
    const parsed = parseGetAllSettingsForModel(this.model, response);
    console.log("Parsed settings count:", parsed.length);
    if (parsed.length > 0) {
      console.log("First few settings:", parsed.slice(0, 3));
    }
    const stateMap = /* @__PURE__ */ new Map();
    for (const setting of parsed) {
      const key = makeSettingId(this.model, setting.cmd_id, setting.id, setting.busCh);
      const value = setting.valueBytes.length === 3 ? setting.valueBytes[0] << 16 | setting.valueBytes[1] << 8 | setting.valueBytes[2] : setting.valueBytes[0] ?? 0;
      stateMap.set(key, value);
    }
    this.deviceState.set(deviceIp, stateMap);
    return response;
  }
  /** Return a snapshot of the current device state for a given IP (for feedbacks). */
  getDeviceState(deviceIp) {
    return this.deviceState.get(deviceIp) ?? /* @__PURE__ */ new Map();
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      foundDevices.push(device);
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(
        this.txSocket,
        onDeviceFound,
        // dante.ts doesn't actually use this, but kept for compatibility
        async (destIp) => this.ensureMembershipFor(destIp),
        timeoutMs
      );
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Ensure we've joined the multicast group on the interface that routes to destIp.
   * Option B behavior: join ONLY the interface used to reach the device.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger3.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger3.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger3.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger3.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(model, cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    await this.ensureMembershipFor(destIp);
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (busCh !== void 0)
      payloadBody.push(busCh & 255);
    if (addLen)
      payloadBody.push(dataBlock.length);
    if (dataBlock.length > 0)
      payloadBody.push(...dataBlock);
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await _StController.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    const cmdName = getCommandName(cmdId);
    if (settingId !== void 0 && value !== void 0) {
      let action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
      if (!action) {
        action = this.actions.find((a) => {
          if (a.cmd_id !== cmdId)
            return false;
          const hasIdAdd = a.options?.some((opt) => opt.id === "idAdd");
          if (!hasIdAdd)
            return false;
          return settingId >= a.id && settingId < a.id + 10;
        });
      }
      let settingName = action?.name ?? "Unknown Setting";
      if (action) {
        const hasIdAdd = action.options?.some((opt) => opt.id === "idAdd");
        if (hasIdAdd && settingId !== action.id) {
          const channelOffset = settingId - action.id;
          settingName = `${settingName} Ch${channelOffset + 1}`;
        }
      }
      const valueOption = action?.options?.find((opt) => opt.id === "value");
      const choices = valueOption?.choices;
      const valueBytes = _StController.buildValueBytes(value);
      const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
      const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
      const cmdHex = `0x${cmdId.toString(16).padStart(2, "0")}`;
      const idHex = `0x${settingId.toString(16).padStart(2, "0")}`;
      const valHex = `0x${valueBytes.map((b) => b.toString(16).padStart(2, "0")).join("")}`;
      const valDec = valueBytes.length === 1 ? valueBytes[0] : valueBytes.join(",");
      const prefix = `cmd:${cmdHex} id:${idHex} val:${valHex}`;
      const suffix = choiceLabel ? `${settingName}: ${choiceLabel} (${valDec})` : `${settingName}: ${valDec}`;
      logger3.info(`TX ${destIp} | ${prefix} | ${suffix}`);
    } else {
      logger3.info(`TX ${destIp} | ${cmdName}`);
    }
    logger3.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    await this.txReady;
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model${model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          if (this.refreshAfterCommand && settingId !== void 0) {
            this.requestAllSettings(destIp).catch((err) => {
              logger3.warn(`Failed to refresh settings after command: ${err}`);
            });
          }
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        for (const cb of this.discoveryListeners.values()) {
          try {
            cb(device);
          } catch {
          }
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    this.logStPayload(srcIp, originalCmdId, msg, stPayload, isResponse);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload, isResponse = true) {
    const cmdName = `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
    const data = stPayload.subarray(2, stPayload.length - 1);
    const magic = stPayload[0];
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[magic:0x${magic.toString(16).padStart(2, "0")} cmd:0x${respCmdId.toString(16).padStart(2, "0")} data:${data.toString("hex")} crc:0x${crc.toString(16).padStart(2, "0")}]`;
    const direction = isResponse ? "RX" : "SNIFF";
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger3.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue !== void 0 && prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger3.info(`${direction} ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              this.feedbackCallback(stateKey);
            }
          } else {
            logger3.debug(`${direction} ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger3.warn(`${direction} ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    if (decoded) {
      logger3.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logger3.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   *
   * msg is the full packet buffer — required by the settings parsers which
   * locate the Studio-T signature themselves.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR 0x${data[0].toString(16).padStart(2, "0")}`;
      }
    }
    switch (cmdId) {
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=0x${data[0].toString(16).padStart(2, "0")}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=0x${settingId.toString(16).padStart(2, "0")}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (0x${valueNum.toString(16).padStart(2, "0")})` : `0x${Array.from(valueBytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
          const rawTag = `[0x${cmdId.toString(16).padStart(2, "0")}/0x${settingId.toString(16).padStart(2, "0")}]=0x${Array.from(valueBytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=0x${settingId.toString(16).padStart(2, "0")}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=0x${settingId.toString(16).padStart(2, "0")} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  static async getMacForDestination(destIp) {
    return new Promise((resolve, reject) => {
      const tmp = dgram2.createSocket("udp4");
      tmp.once("error", (err) => {
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      });
      tmp.connect(9, destIp, () => {
        try {
          const addr = tmp.address();
          const localAddr = addr.address;
          tmp.close();
          const ifaces = os2.networkInterfaces();
          for (const name of Object.keys(ifaces)) {
            for (const iface of ifaces[name] ?? []) {
              if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
                return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
              }
            }
          }
          reject(new Error(`No interface found for local address ${localAddr}`));
        } catch (_e) {
          reject(new Error(String(_e)));
        }
      });
    });
  }
  static async buildHeader(totalLen, destIp) {
    const mac = await _StController.getMacForDestination(destIp);
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(model, destIp) {
    return this.sendAwaitAck(model, CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(model, destIp) {
    return this.sendAwaitAck(model, CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger4 = createModuleLogger("ModuleInstance");
var devicesFolder3 = path6.join(import.meta.dirname, "../devices");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Ok);
    this.discoveredDevices = await this.stController.discoverDevices();
    if (this.discoveredDevices.length === 0) {
      logger4.warn("No devices discovered");
    } else {
      logger4.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger4.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
    }
    const effectiveModel = resolveModel(this.config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    const targetHost = this.host;
    if (targetHost) {
      try {
        await this.stController.requestAllSettings(targetHost);
      } catch (e) {
        logger4.warn(`Failed to get all settings from ${targetHost}: ${e}`);
      }
    }
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger4.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    const newHost = this.host;
    if (newHost && newHost !== previousHost) {
      try {
        await this.stController.requestAllSettings(newHost);
      } catch (e) {
        logger4.warn(`Failed to get all settings from ${newHost}: ${e}`);
      }
    }
  }
  /** Loads the device JSON for the given model and pushes it to the controller. */
  syncModel(model) {
    const { actions, refreshAfterCommand } = loadModelConfig(devicesFolder3, model);
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger4.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger4.debug(`Loaded ${actions.length} actions for model "${model}", refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  // Return config fields for web config — include discovered devices so the
  // dropdown is populated. Called by Companion on first load and after
  // setConfigSchemaVersion() triggers a refresh.
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, preferring the discovered device selection. */
  get host() {
    return resolveHost(this.config);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL21haW4udHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy9idWlsZC1jb21tYW5kcy50cyIsICIuLi8uLi9zcmMvdHlwZXMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQge1xuXHRJbnN0YW5jZVR5cGVzLFxuXHRJbnN0YW5jZUJhc2UsXG5cdEluc3RhbmNlU3RhdHVzLFxuXHRTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsXG5cdGNyZWF0ZU1vZHVsZUxvZ2dlcixcbn0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7IEdldENvbmZpZ0ZpZWxkcywgcmVzb2x2ZUhvc3QsIHJlc29sdmVNb2RlbCwgdHlwZSBNb2R1bGVDb25maWcgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcbmltcG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH0gZnJvbSAnLi91cGdyYWRlcy5qcydcbmltcG9ydCB7IFVwZGF0ZUFjdGlvbnMgfSBmcm9tICcuL2FjdGlvbnMuanMnXG5pbXBvcnQgeyBVcGRhdGVGZWVkYmFja3MgfSBmcm9tICcuL2ZlZWRiYWNrcy5qcydcbmltcG9ydCB7IFN0Q29udHJvbGxlciB9IGZyb20gJy4vc3Rjb250cm9sbGVyLmpzJ1xuaW1wb3J0IHsgbG9hZE1vZGVsQ29uZmlnIH0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignTW9kdWxlSW5zdGFuY2UnKVxuY29uc3QgZGV2aWNlc0ZvbGRlciA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi4vZGV2aWNlcycpXG5cbmV4cG9ydCBpbnRlcmZhY2UgTW9kdWxlVHlwZXMgZXh0ZW5kcyBJbnN0YW5jZVR5cGVzIHtcblx0Y29uZmlnOiBNb2R1bGVDb25maWdcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTW9kdWxlSW5zdGFuY2UgZXh0ZW5kcyBJbnN0YW5jZUJhc2U8TW9kdWxlVHlwZXM+IHtcblx0Y29uZmlnITogTW9kdWxlQ29uZmlnIC8vIFNldHVwIGluIGluaXQoKVxuXHRzdENvbnRyb2xsZXIhOiBTdENvbnRyb2xsZXJcblxuXHQvKiogQ2FjaGVkIGRpc2NvdmVyeSByZXN1bHRzIFx1MjAxNCBwYXNzZWQgaW50byBnZXRDb25maWdGaWVsZHMoKSBzbyB0aGUgVUlcblx0ICogIGNhbiBzaG93IHRoZSBkaXNjb3ZlcmVkIGRldmljZSBkcm9wZG93biBvbiBzdWJzZXF1ZW50IGNvbmZpZyBvcGVucy4gKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHRjb25zdHJ1Y3RvcihpbnRlcm5hbDogdW5rbm93bikge1xuXHRcdHN1cGVyKGludGVybmFsKVxuXHR9XG5cblx0YXN5bmMgaW5pdChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0aWYgKCF0aGlzLnN0Q29udHJvbGxlcikge1xuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIgPSBuZXcgU3RDb250cm9sbGVyKClcblx0XHR9XG5cdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cblx0XHQvLyBSdW4gZGlzY292ZXJ5IHRvIHBvcHVsYXRlIHRoZSBkZXZpY2UgbGlzdCBGSVJTVFxuXHRcdHRoaXMuZGlzY292ZXJlZERldmljZXMgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5kaXNjb3ZlckRldmljZXMoKVxuXHRcdGlmICh0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0bG9nZ2VyLndhcm4oJ05vIGRldmljZXMgZGlzY292ZXJlZCcpXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBEaXNjb3ZlcmVkICR7dGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGh9IGRldmljZShzKTpgKVxuXHRcdFx0Zm9yIChjb25zdCBkIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSBNb2RlbCAke2QubW9kZWx9ICR7ZC5tYW51ZmFjdHVyZXIgPz8gJyd9IEAgJHtkLmlwfWApXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gTG9hZCBkZXZpY2Ugc2NoZW1hIGFuZCBzeW5jIHRvIGNvbnRyb2xsZXIgZm9yIG1lc3NhZ2UgZGVjb2Rpbmdcblx0XHQvLyBVc2UgcmVzb2x2ZU1vZGVsIHRvIGF1dG8tZGV0ZWN0IG1vZGVsIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaWYgc2VsZWN0ZWRcblx0XHRjb25zdCBlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIFdpcmUgZmVlZGJhY2sgY2FsbGJhY2sgc28gc3RDb250cm9sbGVyIGNhbiB0cmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZXNcblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRGZWVkYmFja0NhbGxiYWNrKChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHtcblx0XHRcdHRoaXMuY2hlY2tGZWVkYmFja3MoZmVlZGJhY2tJZClcblx0XHR9KVxuXG5cdFx0Ly8gTk9XIHVwZGF0ZSBhY3Rpb25zL2ZlZWRiYWNrcy92YXJpYWJsZXMgYWZ0ZXIgZGlzY292ZXJ5IGFuZCBtb2RlbCByZXNvbHV0aW9uXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblxuXHRcdC8vIEZldGNoIGluaXRpYWwgc2V0dGluZ3Mgc3RhdGUgZnJvbSB0aGUgY29uZmlndXJlZCBkZXZpY2Ugb25seVxuXHRcdGNvbnN0IHRhcmdldEhvc3QgPSB0aGlzLmhvc3Rcblx0XHRpZiAodGFyZ2V0SG9zdCkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKHRhcmdldEhvc3QpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZ2V0IGFsbCBzZXR0aW5ncyBmcm9tICR7dGFyZ2V0SG9zdH06ICR7ZX1gKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdC8vIFdoZW4gbW9kdWxlIGdldHMgZGVsZXRlZFxuXHRhc3luYyBkZXN0cm95KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuc3RDb250cm9sbGVyPy5jbG9zZSgpXG5cdFx0bG9nZ2VyLmRlYnVnKCdkZXN0cm95Jylcblx0fVxuXG5cdGFzeW5jIGNvbmZpZ1VwZGF0ZWQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRjb25zdCBwcmV2aW91c0hvc3QgPSB0aGlzLmhvc3Rcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGNvbnN0IGVmZmVjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKGNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIFJlYnVpbGQgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgdmFyaWFibGVzIHdoZW4gY29uZmlnIGNoYW5nZXMgKG1vZGVsIG9yIGRldmljZSBzZWxlY3Rpb24gY2hhbmdlZClcblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXG5cdFx0Ly8gSWYgdGhlIGhvc3QgY2hhbmdlZCwgcmVxdWVzdCBzZXR0aW5ncyBmcm9tIHRoZSBuZXcgZGV2aWNlXG5cdFx0Y29uc3QgbmV3SG9zdCA9IHRoaXMuaG9zdFxuXHRcdGlmIChuZXdIb3N0ICYmIG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKG5ld0hvc3QpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZ2V0IGFsbCBzZXR0aW5ncyBmcm9tICR7bmV3SG9zdH06ICR7ZX1gKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdC8qKiBMb2FkcyB0aGUgZGV2aWNlIEpTT04gZm9yIHRoZSBnaXZlbiBtb2RlbCBhbmQgcHVzaGVzIGl0IHRvIHRoZSBjb250cm9sbGVyLiAqL1xuXHRwcml2YXRlIHN5bmNNb2RlbChtb2RlbDogc3RyaW5nKTogdm9pZCB7XG5cdFx0Y29uc3QgeyBhY3Rpb25zLCByZWZyZXNoQWZ0ZXJDb21tYW5kIH0gPSBsb2FkTW9kZWxDb25maWcoZGV2aWNlc0ZvbGRlciwgbW9kZWwpXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0TW9kZWwobW9kZWwsIGFjdGlvbnMsIHJlZnJlc2hBZnRlckNvbW1hbmQpXG5cdFx0aWYgKGFjdGlvbnMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTm8gYWN0aW9ucyBmb3VuZCBmb3IgbW9kZWwgXCIke21vZGVsfVwiIFx1MjAxNCBzZXR0aW5ncyBkZWNvZGluZyB3aWxsIHVzZSByYXcgSURzYClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBMb2FkZWQgJHthY3Rpb25zLmxlbmd0aH0gYWN0aW9ucyBmb3IgbW9kZWwgXCIke21vZGVsfVwiLCByZWZyZXNoQWZ0ZXJDb21tYW5kPSR7cmVmcmVzaEFmdGVyQ29tbWFuZH1gKVxuXHRcdH1cblx0fVxuXG5cdC8vIFJldHVybiBjb25maWcgZmllbGRzIGZvciB3ZWIgY29uZmlnIFx1MjAxNCBpbmNsdWRlIGRpc2NvdmVyZWQgZGV2aWNlcyBzbyB0aGVcblx0Ly8gZHJvcGRvd24gaXMgcG9wdWxhdGVkLiBDYWxsZWQgYnkgQ29tcGFuaW9uIG9uIGZpcnN0IGxvYWQgYW5kIGFmdGVyXG5cdC8vIHNldENvbmZpZ1NjaGVtYVZlcnNpb24oKSB0cmlnZ2VycyBhIHJlZnJlc2guXG5cdGdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdFx0cmV0dXJuIEdldENvbmZpZ0ZpZWxkcyh0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLCBwcmVmZXJyaW5nIHRoZSBkaXNjb3ZlcmVkIGRldmljZSBzZWxlY3Rpb24uICovXG5cdGdldCBob3N0KCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIHJlc29sdmVIb3N0KHRoaXMuY29uZmlnKVxuXHR9XG5cblx0LyoqIFJldHVybnMgZGlzY292ZXJlZCBkZXZpY2VzIGZvciB1c2UgaW4gYWN0aW9ucy9jb25maWcgKi9cblx0Z2V0IGRldmljZXMoKTogRGV2aWNlSW5mb1tdIHtcblx0XHRyZXR1cm4gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlc1xuXHR9XG5cblx0dXBkYXRlQWN0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVBY3Rpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVGZWVkYmFja3MoKTogdm9pZCB7XG5cdFx0VXBkYXRlRmVlZGJhY2tzKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnModGhpcylcblx0fVxufVxuXG5leHBvcnQgeyBVcGdyYWRlU2NyaXB0cyB9XG4iLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCAiaW1wb3J0IGZzIGZyb20gJ2ZzJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcbmltcG9ydCB7IFJlZ2V4LCB0eXBlIFNvbWVDb21wYW5pb25Db25maWdGaWVsZCwgdHlwZSBKc29uT2JqZWN0LCBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ0NvbmZpZycpXG5pbXBvcnQgdHlwZSB7IERldmljZUluZm8gfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5leHBvcnQgaW50ZXJmYWNlIE1vZHVsZUNvbmZpZyBleHRlbmRzIEpzb25PYmplY3Qge1xuXHRob3N0OiBzdHJpbmdcblx0YWN0aXZlTW9kZWw6IHN0cmluZ1xuXHQvKiogSVAgb2YgYSBkaXNjb3ZlcmVkIERhbnRlIGRldmljZSwgb3IgJycgd2hlbiB0aGUgdXNlciBjaG9vc2VzIE1hbnVhbCAqL1xuXHRkaXNjb3ZlcmVkSG9zdDogc3RyaW5nXG59XG5cbi8vIEFkanVzdCB0aGlzIHBhdGggaWYgeW91ciBmb2xkZXIgbGF5b3V0IGRpZmZlcnNcbmNvbnN0IGRldmljZXNGb2xkZXIgPSBwYXRoLmpvaW4oaW1wb3J0Lm1ldGEuZGlybmFtZSwgJy4uL2RldmljZXMnKVxuXG5mdW5jdGlvbiBsb2FkQXZhaWxhYmxlTW9kZWxzKCk6IHN0cmluZ1tdIHtcblx0dHJ5IHtcblx0XHRjb25zdCBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKGRldmljZXNGb2xkZXIpLmZpbHRlcigoZikgPT4gZi5lbmRzV2l0aCgnLmpzb24nKSlcblx0XHRjb25zdCBtb2RlbHM6IHN0cmluZ1tdID0gW11cblxuXHRcdGZvciAoY29uc3QgZiBvZiBmaWxlcykge1xuXHRcdFx0Y29uc3QgZnVsbFBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgZilcblx0XHRcdGNvbnN0IGogPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCwgJ3V0ZjgnKSlcblx0XHRcdGlmIChqPy5tb2RlbCkge1xuXHRcdFx0XHRtb2RlbHMucHVzaChTdHJpbmcoai5tb2RlbCkpXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cmV0dXJuIG1vZGVscy5zb3J0KClcblx0fSBjYXRjaCAoX2UpIHtcblx0XHRsb2dnZXIuZXJyb3IoYEZhaWxlZCB0byBsb2FkIGRldmljZSBtb2RlbHM6ICR7X2V9YClcblx0XHRyZXR1cm4gW11cblx0fVxufVxuXG5leHBvcnQgZnVuY3Rpb24gR2V0Q29uZmlnRmllbGRzKGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXSk6IFNvbWVDb21wYW5pb25Db25maWdGaWVsZFtdIHtcblx0Y29uc3QgbW9kZWxzID0gbG9hZEF2YWlsYWJsZU1vZGVscygpXG5cblx0Ly8gQnVpbGQgY2hvaWNlcyBtaXJyb3JpbmcgdGhlIGJvbmpvdXItZGV2aWNlIHBhdHRlcm46XG5cdC8vICAgZmlyc3QgZW50cnkgaXMgYWx3YXlzICdNYW51YWwnIChlbXB0eSB2YWx1ZSlcblx0Ly8gICB0aGVuIG9uZSBlbnRyeSBwZXIgZGlzY292ZXJlZCBkZXZpY2Vcblx0Y29uc3QgZGV2aWNlQ2hvaWNlcyA9IFtcblx0XHR7IGlkOiAnJywgbGFiZWw6ICdNYW51YWwnIH0sXG5cdFx0Li4uZGlzY292ZXJlZERldmljZXMubWFwKChkKSA9PiAoe1xuXHRcdFx0aWQ6IGQuaXAsXG5cdFx0XHRsYWJlbDogYE1vZGVsICR7ZC5tb2RlbH0gKCR7ZC5pcH0pYCxcblx0XHR9KSksXG5cdF1cblxuXHRyZXR1cm4gW1xuXHRcdC8vIFx1MjUwMFx1MjUwMCBEZXZpY2UgZGlzY292ZXJ5IGRyb3Bkb3duIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIE1pcnJvcnMgdGhlIGJvbmpvdXItZGV2aWNlIGZpZWxkOiBzZWxlY3RpbmcgYSBkZXZpY2UgcG9wdWxhdGVzIHRoZVxuXHRcdC8vIGhvc3QgYXV0b21hdGljYWxseTsgc2VsZWN0aW5nICdNYW51YWwnIHNob3dzIHRoZSB0ZXh0aW5wdXQgYmVsb3cuXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnZGlzY292ZXJlZEhvc3QnLFxuXHRcdFx0bGFiZWw6ICdEZXZpY2UnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHRcdGNob2ljZXM6IGRldmljZUNob2ljZXMsXG5cdFx0XHR0b29sdGlwOiAnU2VsZWN0IGFuIGF1dG8tZGlzY292ZXJlZCBTdHVkaW8gVGVjaG5vbG9naWVzIERhbnRlIGRldmljZSwgb3IgY2hvb3NlIE1hbnVhbCB0byBlbnRlciBhbiBJUCBhZGRyZXNzLicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNYW51YWwgSVAgZW50cnkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gT25seSB2aXNpYmxlIHdoZW4gZGlzY292ZXJlZEhvc3QgaXMgJycgKE1hbnVhbCBzZWxlY3RlZCkuXG5cdFx0Ly8gTWF0Y2hlcyB0aGUgcGF0dGVybiBmcm9tIHRoZSBib25qb3VyLWRldmljZSBkb2NzLlxuXHRcdHtcblx0XHRcdHR5cGU6ICd0ZXh0aW5wdXQnLFxuXHRcdFx0aWQ6ICdob3N0Jyxcblx0XHRcdGxhYmVsOiAnVGFyZ2V0IElQJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRyZWdleDogUmVnZXguSVAsXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkaXNjb3ZlcmVkSG9zdClgLFxuXHRcdFx0dG9vbHRpcDogJ0VudGVyIHRoZSBJUCBhZGRyZXNzIG9mIHRoZSBkZXZpY2UgbWFudWFsbHkuJyxcblx0XHR9LFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIE1vZGVsIHNlbGVjdG9yIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIE9ubHkgdmlzaWJsZSB3aGVuIE1hbnVhbCBtb2RlIGlzIHNlbGVjdGVkIChubyBkaXNjb3ZlcmVkIGRldmljZSkuXG5cdFx0Ly8gV2hlbiBhIGRpc2NvdmVyZWQgZGV2aWNlIGlzIHNlbGVjdGVkLCB0aGUgbW9kZWwgaXMgYXV0by1kZXRlY3RlZC5cblx0XHR7XG5cdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0aWQ6ICdhY3RpdmVNb2RlbCcsXG5cdFx0XHRsYWJlbDogJ0FjdGl2ZSBEZXZpY2UgTW9kZWwnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiBtb2RlbHNbMF0gPz8gJycsXG5cdFx0XHRjaG9pY2VzOiBtb2RlbHMubWFwKChtb2RlbCkgPT4gKHtcblx0XHRcdFx0aWQ6IG1vZGVsLFxuXHRcdFx0XHRsYWJlbDogYE1vZGVsICR7bW9kZWx9YCxcblx0XHRcdH0pKSxcblx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246IGAhJChvcHRpb25zOmRpc2NvdmVyZWRIb3N0KWAsXG5cdFx0XHR0b29sdGlwOiAnU2VsZWN0IHdoaWNoIFN0dWRpbyBUZWNobm9sb2dpZXMgbW9kZWwgaXMgYWN0aXZlIGZvciBhY3Rpb25zIGFuZCBHZXQgQWxsIFNldHRpbmdzJyxcblx0XHR9LFxuXHRdXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZWZmZWN0aXZlIGhvc3QgSVAgZnJvbSBjb25maWcgXHUyMDE0IHByZWZlcnMgdGhlIGRpc2NvdmVyZWQgZGV2aWNlXG4gKiBJUCB3aGVuIG9uZSBpcyBzZWxlY3RlZCwgZmFsbHMgYmFjayB0byB0aGUgbWFudWFsbHkgZW50ZXJlZCBob3N0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUhvc3QoY29uZmlnOiBNb2R1bGVDb25maWcpOiBzdHJpbmcge1xuXHRyZXR1cm4gY29uZmlnLmRpc2NvdmVyZWRIb3N0IHx8IGNvbmZpZy5ob3N0XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZWZmZWN0aXZlIG1vZGVsIFx1MjAxNCBpZiBhIGRpc2NvdmVyZWQgZGV2aWNlIGlzIHNlbGVjdGVkLCBleHRyYWN0c1xuICogaXRzIG1vZGVsIGZyb20gdGhlIGRpc2NvdmVyZWREZXZpY2VzIGxpc3Q7IG90aGVyd2lzZSB1c2VzIGFjdGl2ZU1vZGVsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZU1vZGVsKGNvbmZpZzogTW9kdWxlQ29uZmlnLCBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdKTogc3RyaW5nIHtcblx0aWYgKGNvbmZpZy5kaXNjb3ZlcmVkSG9zdCkge1xuXHRcdGNvbnN0IGRldmljZSA9IGRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQuaXAgPT09IGNvbmZpZy5kaXNjb3ZlcmVkSG9zdClcblx0XHRjb25zb2xlLmxvZyhgcmVzb2x2ZU1vZGVsOiBkaXNjb3ZlcmVkSG9zdD1cIiR7Y29uZmlnLmRpc2NvdmVyZWRIb3N0fVwiLCBmb3VuZCBkZXZpY2U6YCwgZGV2aWNlKVxuXHRcdGlmIChkZXZpY2U/Lm1vZGVsKSB7XG5cdFx0XHRyZXR1cm4gZGV2aWNlLm1vZGVsXG5cdFx0fVxuXHR9XG5cdGNvbnNvbGUubG9nKGByZXNvbHZlTW9kZWw6IGZhbGxpbmcgYmFjayB0byBhY3RpdmVNb2RlbD1cIiR7Y29uZmlnLmFjdGl2ZU1vZGVsfVwiYClcblx0cmV0dXJuIGNvbmZpZy5hY3RpdmVNb2RlbFxufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh7XG5cdFx0dmFyaWFibGUxOiB7IG5hbWU6ICdNeSBmaXJzdCB2YXJpYWJsZScgfSxcblx0XHR2YXJpYWJsZTI6IHsgbmFtZTogJ015IHNlY29uZCB2YXJpYWJsZScgfSxcblx0XHR2YXJpYWJsZTM6IHsgbmFtZTogJ0Fub3RoZXIgdmFyaWFibGUnIH0sXG5cdH0pXG59XG4iLCAiaW1wb3J0IHR5cGUgeyBDb21wYW5pb25TdGF0aWNVcGdyYWRlU2NyaXB0IH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbmV4cG9ydCBjb25zdCBVcGdyYWRlU2NyaXB0czogQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdDxNb2R1bGVDb25maWc+W10gPSBbXG5cdC8qXG5cdCAqIFBsYWNlIHlvdXIgdXBncmFkZSBzY3JpcHRzIGhlcmVcblx0ICogUmVtZW1iZXIgdGhhdCBvbmNlIGl0IGhhcyBiZWVuIGFkZGVkIGl0IGNhbm5vdCBiZSByZW1vdmVkIVxuXHQgKi9cblx0Ly8gZnVuY3Rpb24gKGNvbnRleHQsIHByb3BzKSB7XG5cdC8vIFx0cmV0dXJuIHtcblx0Ly8gXHRcdHVwZGF0ZWRDb25maWc6IG51bGwsXG5cdC8vIFx0XHR1cGRhdGVkQWN0aW9uczogW10sXG5cdC8vIFx0XHR1cGRhdGVkRmVlZGJhY2tzOiBbXSxcblx0Ly8gXHR9XG5cdC8vIH0sXG5dXG4iLCAiLyoqXG4gKiBidWlsZC1jb21tYW5kcy50c1xuICogLSBMb2FkcyAuL2RldmljZXMvKi5qc29uIChVSSBzY2hlbWFzKVxuICogLSBQcm9kdWNlcyBDb21wYW5pb24gYWN0aW9uIGRlZmluaXRpb25zIGFuZCBmZWVkYmFja3NcbiAqL1xuXG5pbXBvcnQgZnMgZnJvbSAnZnMnXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuaW1wb3J0IHtcblx0Q29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMsXG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24sXG5cdENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBtYWtlU2V0dGluZ0lkIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgZGV2aWNlc0ZvbGRlciA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi4vZGV2aWNlcycpXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0gTG9hZCBKU09OIC0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZXhwb3J0IGZ1bmN0aW9uIGxvYWRVaVNjaGVtYXMoZGlyID0gZGV2aWNlc0ZvbGRlcik6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRjb25zdCBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKGRpcikuZmlsdGVyKChmKSA9PiBmLmVuZHNXaXRoKCcuanNvbicpKVxuXHRjb25zdCBvdXQ6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7fVxuXG5cdGZvciAoY29uc3QgZiBvZiBmaWxlcykge1xuXHRcdGNvbnN0IGogPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhwYXRoLmpvaW4oZGlyLCBmKSwgJ3V0ZjgnKSlcblx0XHRvdXRbai5tb2RlbF0gPSBqXG5cdH1cblxuXHRyZXR1cm4gb3V0XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0gT3B0aW9uIEJ1aWxkZXIgLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZnVuY3Rpb24gYnVpbGRPcHRpb24obzogYW55KTogYW55IHtcblx0Y29uc3QgYmFzZSA9IHtcblx0XHR0eXBlOiBvLnR5cGUsXG5cdFx0aWQ6IG8uaWQsXG5cdFx0bGFiZWw6IG8ubGFiZWwsXG5cdFx0ZGVmYXVsdDogby5kZWZhdWx0LFxuXHRcdHRvb2x0aXA6IG8udG9vbHRpcCxcblx0fVxuXG5cdHN3aXRjaCAoby50eXBlKSB7XG5cdFx0Y2FzZSAnZHJvcGRvd24nOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgY2hvaWNlczogby5jaG9pY2VzID8/IFtdIH1cblxuXHRcdGNhc2UgJ251bWJlcic6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5iYXNlLFxuXHRcdFx0XHRtaW46IG8ubWluLFxuXHRcdFx0XHRtYXg6IG8ubWF4LFxuXHRcdFx0XHRzdGVwOiBvLnN0ZXAgPz8gMSxcblx0XHRcdFx0cmFuZ2U6IHRydWUsXG5cdFx0XHR9XG5cblx0XHRjYXNlICdjaGVja2JveCc6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBkZWZhdWx0OiBvLmRlZmF1bHQgPz8gZmFsc2UgfVxuXG5cdFx0Y2FzZSAndGV4dGlucHV0Jzpcblx0XHRjYXNlICdjb2xvcnBpY2tlcic6XG5cdFx0Y2FzZSAnc3RhdGljLXRleHQnOlxuXHRcdGRlZmF1bHQ6XG5cdFx0XHRyZXR1cm4gYmFzZVxuXHR9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0gQWN0aW9ucyAtLS0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkQWN0aW9ucyhkaXIgPSBkZXZpY2VzRm9sZGVyKTogQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMge1xuXHRjb25zdCBzY2hlbWFzID0gbG9hZFVpU2NoZW1hcyhkaXIpXG5cdGNvbnN0IGFjdGlvbnM6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3QgYSBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdGNvbnN0IGFjdGlvbklkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgYS5jbWRfaWQsIGEuaWQpXG5cblx0XHRcdGNvbnN0IG9wdGlvbnMgPSAoYS5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdGNvbnN0IGFjdGlvbjogQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbiA9IHtcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7bW9kZWx9XSAke2EubmFtZX1gLFxuXHRcdFx0XHRvcHRpb25zLFxuXHRcdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRcdC8qIHdpcmVkIGxhdGVyIGluIFVwZGF0ZUFjdGlvbnMgKi9cblx0XHRcdFx0fSxcblx0XHRcdH1cblxuXHRcdFx0YWN0aW9uc1thY3Rpb25JZF0gPSBhY3Rpb25cblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gYWN0aW9uc1xufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tIEZlZWRiYWNrcyAtLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEZlZWRiYWNrcyhkaXIgPSBkZXZpY2VzRm9sZGVyKTogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyB7XG5cdGNvbnN0IHNjaGVtYXMgPSBsb2FkVWlTY2hlbWFzKGRpcilcblx0Y29uc3QgZmVlZGJhY2tzOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3Qgc2V0dGluZyBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0lkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgc2V0dGluZy5jbWRfaWQsIHNldHRpbmcuaWQpXG5cblx0XHRcdC8vIEJ1aWxkIG9wdGlvbnNcblx0XHRcdGNvbnN0IGFsbE9wdGlvbnMgPSAoc2V0dGluZy5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdC8vIEZpbHRlciBvdXQgJ3ZhbHVlJyBvcHRpb24gZm9yIHZhbHVlIGZlZWRiYWNrIChrZWVwIG9ubHkgYnVzQ2gvaWRBZGQpXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbnMgPSBhbGxPcHRpb25zLmZpbHRlcigob3B0OiBhbnkpID0+IG9wdC5pZCAhPT0gJ3ZhbHVlJylcblxuXHRcdFx0Ly8gQWRkIGEgY2hlY2tib3ggb3B0aW9uIHRvIHJldHVybiBsYWJlbCBpbnN0ZWFkIG9mIHZhbHVlXG5cdFx0XHR2YWx1ZU9wdGlvbnMucHVzaCh7XG5cdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0bGFiZWw6ICdTaG93IExhYmVsJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHR9KVxuXG5cdFx0XHQvLyBWYWx1ZSBmZWVkYmFjayBmb3IgYWxsIHNldHRpbmdzIChhcHBlYXJzIGluIFZhcmlhYmxlcyBsaXN0KVxuXHRcdFx0Y29uc3QgdmFsdWVGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHR0eXBlOiAndmFsdWUnLFxuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnM6IHZhbHVlT3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRyZXR1cm4gMFxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRmZWVkYmFja3NbYmFzZUZlZWRiYWNrSWRdID0gdmFsdWVGZWVkYmFja1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJleHBvcnQgaW50ZXJmYWNlIENvbXBhbmlvbklucHV0Q2hvaWNlIHtcblx0aWQ6IHN0cmluZyB8IG51bWJlclxuXHRsYWJlbDogc3RyaW5nXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRGV2aWNlU2V0dGluZyB7XG5cdHR5cGU6IHN0cmluZ1xuXHRsYWJlbDogc3RyaW5nXG5cdGRlZmF1bHQ6IHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW5cblx0Y2hvaWNlcz86IENvbXBhbmlvbklucHV0Q2hvaWNlW11cbn1cblxuZXhwb3J0IGludGVyZmFjZSBEZXZpY2VJbmZvIHtcblx0bW9kZWw6IHN0cmluZ1xuXHRpcDogc3RyaW5nXG5cdG5hbWU/OiBzdHJpbmcgLy8gRGFudGUgZGV2aWNlIG5hbWUgKHVzZXItY29uZmlndXJhYmxlIGxhYmVsLCBlLmcuIFwiU3R1ZGlvLVRaXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlPzogc3RyaW5nXG5cdG1hYz86IHN0cmluZ1xuXHRzZXJpYWw/OiBzdHJpbmdcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFN0dWRpby1UIENvbW1hbmQgSUQgQ29uc3RhbnRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBHZXQgc2V0dGluZyBmcm9tIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0JVU19TRVQgPSAweDA0IC8vIFNldCBzZXR0aW5nIG9uIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0hFQURQSE9ORSA9IDB4MDUgLy8gSGVhZHBob25lIGNvbnRyb2xzIChyZXNlcnZlZCBmb3IgZnV0dXJlIHVzZSlcbmV4cG9ydCBjb25zdCBDTURfQlVUVE9OX01PREUgPSAweDA3IC8vIEJ1dHRvbiBtb2RlIGNvbmZpZ3VyYXRpb24gKHJlc2VydmVkIGZvciBmdXR1cmUgdXNlKVxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kcyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5leHBvcnQgY29uc3QgQ01EX0dFVF9BTExfU0VUVElOR1MgPSAweDBhIC8vIFJlcXVlc3QgYWxsIGN1cnJlbnQgc2V0dGluZ3MgZnJvbSBkZXZpY2VcbmV4cG9ydCBjb25zdCBDTURfU0VUVElOR1NfUFVTSCA9IDB4MGIgLy8gVW5zb2xpY2l0ZWQgc2V0dGluZ3MgdXBkYXRlIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX0RFVl9TUEVDID0gMHgwZCAvLyBEZXZpY2Utc3BlY2lmaWMgc2V0dGluZyBnZXQvc2V0IHdpdGggQUNLXG5leHBvcnQgY29uc3QgQ01EX1JFU0VUX0RFVklDRSA9IDB4MGUgLy8gRmFjdG9yeSByZXNldCBjb21tYW5kXG5leHBvcnQgY29uc3QgQ01EX0dMT0JBTF9NSUNfS0lMTCA9IDB4MTAgLy8gRW1lcmdlbmN5IG1pYyBraWxsIChhbGwgY2hhbm5lbHMpXG5leHBvcnQgY29uc3QgQ01EX01JQ19QUkVfQlVTID0gMHgxMiAvLyBNaWMvcHJlYW1wIHNldHRpbmdzIHBlciBidXMgKGdhaW4sIHBoYW50b20sIGV0YylcbmV4cG9ydCBjb25zdCBDTURfQ0hBTk5FTCA9IDB4MTQgLy8gQ2hhbm5lbC1zcGVjaWZpYyBjb250cm9scyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBDb21tYW5kIE5hbWUgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbW1hbmROYW1lKGNtZElkOiBudW1iZXIpOiBzdHJpbmcge1xuXHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdHJldHVybiAnR2V0IEJ1cyBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0JVU19TRVQ6XG5cdFx0XHRyZXR1cm4gJ1NldCBCdXMgU2V0dGluZydcblx0XHRjYXNlIENNRF9IRUFEUEhPTkU6XG5cdFx0XHRyZXR1cm4gJ0hlYWRwaG9uZSBDb250cm9sJ1xuXHRcdGNhc2UgQ01EX0JVVFRPTl9NT0RFOlxuXHRcdFx0cmV0dXJuICdCdXR0b24gTW9kZSdcblx0XHRjYXNlIENNRF9TWVNURU06XG5cdFx0XHRyZXR1cm4gJ1N5c3RlbSBDb21tYW5kJ1xuXHRcdGNhc2UgQ01EX0dFVF9BTExfU0VUVElOR1M6XG5cdFx0XHRyZXR1cm4gJ1JlcXVlc3QgQWxsIFNldHRpbmdzJ1xuXHRcdGNhc2UgQ01EX1NFVFRJTkdTX1BVU0g6XG5cdFx0XHRyZXR1cm4gJ1NldHRpbmdzIFB1c2gnXG5cdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6XG5cdFx0XHRyZXR1cm4gJ01pYy9QcmUgQnVzJ1xuXHRcdGNhc2UgQ01EX0RFVl9TUEVDOlxuXHRcdFx0cmV0dXJuICdEZXZpY2UgU2V0dGluZydcblx0XHRjYXNlIENNRF9DSEFOTkVMOlxuXHRcdFx0cmV0dXJuICdDaGFubmVsIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfUkVTRVRfREVWSUNFOlxuXHRcdFx0cmV0dXJuICdSZXNldCBEZXZpY2UnXG5cdFx0Y2FzZSBDTURfR0xPQkFMX01JQ19LSUxMOlxuXHRcdFx0cmV0dXJuICdHbG9iYWwgTWljIEtpbGwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgY21kXzB4JHtjbWRJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIEdlbmVyYXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDcmVhdGVzIGEgY29uc2lzdGVudCBJRCBmb3IgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgc3RhdGUga2V5cy5cbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2J1c0NofV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKGUuZy4sIFwiNTMwNF8xNF8wXzBcIilcbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGhvdXQgYnVzQ2ggKGUuZy4sIFwiNTMwNF8xMl9kXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWtlU2V0dGluZ0lkKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRzZXR0aW5nSWQ6IG51bWJlciB8IHN0cmluZyxcblx0YnVzQ2g/OiBudW1iZXIgfCBzdHJpbmcsXG4pOiBzdHJpbmcge1xuXHRjb25zdCBjbWQgPSB0eXBlb2YgY21kSWQgPT09ICdudW1iZXInID8gY21kSWQudG9TdHJpbmcoMTYpIDogY21kSWRcblx0Y29uc3QgaWQgPSB0eXBlb2Ygc2V0dGluZ0lkID09PSAnbnVtYmVyJyA/IHNldHRpbmdJZC50b1N0cmluZygxNikgOiBzZXR0aW5nSWRcblxuXHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IGNoID0gdHlwZW9mIGJ1c0NoID09PSAnbnVtYmVyJyA/IGJ1c0NoLnRvU3RyaW5nKDE2KSA6IGJ1c0NoXG5cdFx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtjaH1fJHtpZH1gXG5cdH1cblxuXHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2lkfWBcbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zLCBsb2FkVWlTY2hlbWFzIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IHJlc29sdmVNb2RlbCB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcblxuLy8gRm9yIEdFVCBBTEwgU0VUVElOR1MgQUNUSU9OXG5pbXBvcnQgZnMgZnJvbSAnZnMnXG5pbXBvcnQge1xuXHRwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwsXG5cdHNhdmVNb2RlbEpzb25QcmV0dHksXG5cdHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyxcblx0U3RNb2RlbEpzb24sXG59IGZyb20gJy4vc2V0dGluZ3NQYXJzZXIuanMnXG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVBY3Rpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IGRldmljZXNGb2xkZXIgPSBwYXRoLmpvaW4oaW1wb3J0Lm1ldGEuZGlybmFtZSwgJy4uL2RldmljZXMnKVxuXG5cdGNvbnN0IHNjaGVtYXNSYXcgPSBsb2FkVWlTY2hlbWFzKGRldmljZXNGb2xkZXIpXG5cdGNvbnN0IHJhd0FjdGlvbnMgPSBidWlsZEFjdGlvbnMoZGV2aWNlc0ZvbGRlcilcblx0Y29uc3Qgc2NoZW1hczogUmVjb3JkPHN0cmluZywgU3RNb2RlbEpzb24+ID0ge31cblx0Zm9yIChjb25zdCBbbW9kZWwsIGpzb25dIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXNSYXcpKSB7XG5cdFx0c2NoZW1hc1ttb2RlbF0gPSB7XG5cdFx0XHRtb2RlbDoganNvbi5tb2RlbCxcblx0XHRcdGFjdGlvbnM6IEFycmF5LmlzQXJyYXkoanNvbi5jbWRTY2hlbWEpID8ganNvbi5jbWRTY2hlbWEgOiBbXSxcblx0XHR9XG5cdH1cblx0Y29uc3Qgd2lyZWRBY3Rpb25zOiBhbnkgPSB7fVxuXG5cdC8vIEdldCB0aGUgYWN0aXZlIG1vZGVsIHVzaW5nIHJlc29sdmVNb2RlbFxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbChzZWxmLmNvbmZpZywgc2VsZi5kZXZpY2VzKVxuXHRjb25zb2xlLmxvZyhcblx0XHRgVXBkYXRlQWN0aW9uczogYWN0aXZlTW9kZWw9XCIke2FjdGl2ZU1vZGVsfVwiLCBkaXNjb3ZlcmVkSG9zdD1cIiR7c2VsZi5jb25maWcuZGlzY292ZXJlZEhvc3R9XCIsIGRldmljZXMgY291bnQ9JHtzZWxmLmRldmljZXMubGVuZ3RofWAsXG5cdClcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEdMT0JBTDogR0VUIEFMTCBTRVRUSU5HUyAoQVVUTyBKU09OIFVQREFURSlcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0d2lyZWRBY3Rpb25zWydnbG9iYWxfZ2V0QWxsU2V0dGluZ3MnXSA9IHtcblx0XHRuYW1lOiAnR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzIChBdXRvLVVwZGF0ZSBKU09OKScsXG5cdFx0b3B0aW9uczogW10sXG5cdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdGNvbnN0IG1vZGVsID0gYWN0aXZlTW9kZWxcblx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cblx0XHRcdGNvbnN0IGJ1ZiA9IGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0Y29uc3Qgc2NoZW1hUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBgbW9kZWwke21vZGVsfS5qc29uYClcblx0XHRcdGNvbnN0IG1vZGVsSnNvbiA9IEpTT04ucGFyc2UoZnMucmVhZEZpbGVTeW5jKHNjaGVtYVBhdGgsICd1dGY4JykpXG5cblx0XHRcdC8vIE1vZGVsLWF3YXJlIHBhcnNpbmdcblx0XHRcdGNvbnN0IHBhcnNlZCA9IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbChtb2RlbCwgYnVmKVxuXHRcdFx0Y29uc29sZS5sb2coJ3BhcnNlZCByZXBseTogJywgcGFyc2VkKVxuXG5cdFx0XHRjb25zdCB1cGRhdGVkID0gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKG1vZGVsSnNvbiwgcGFyc2VkLCBzY2hlbWFzKVxuXHRcdFx0Y29uc29sZS5sb2coJ25ldyBBY3Rpb25zIGpzb246ICcsIEpTT04uc3RyaW5naWZ5KHVwZGF0ZWQsIG51bGwsIDIpKVxuXG5cdFx0XHRzYXZlTW9kZWxKc29uUHJldHR5KHNjaGVtYVBhdGgsIHVwZGF0ZWQpXG5cblx0XHRcdGNvbnNvbGUubG9nKGBNb2RlbCAke21vZGVsfSBKU09OIGF1dG8tdXBkYXRlZCBmcm9tIGdldEFsbFNldHRpbmdzYClcblx0XHR9LFxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBCVUlMRCBQRVItU0VUVElORyBBQ1RJT05TIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2FjdGlvbklkLCBhY3Rpb25dIG9mIE9iamVjdC5lbnRyaWVzKHJhd0FjdGlvbnMpKSB7XG5cdFx0Y29uc3QgW21vZGVsLCBjbWRJZFN0ciwgaWRTdHJdID0gYWN0aW9uSWQuc3BsaXQoJ18nKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGFjdGlvbnMgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIFBhcnNlIGhleCBzdHJpbmdzIGZyb20gYWN0aW9uSWQgKGUuZy4sIFwiMzkxX2RfMFwiIFx1MjE5MiBjbWRJZD0xMywgYmFzZUlkPTApXG5cdFx0Y29uc3QgY21kSWQgPSBwYXJzZUludChjbWRJZFN0ciwgMTYpXG5cdFx0Y29uc3QgYmFzZUlkID0gcGFyc2VJbnQoaWRTdHIsIDE2KVxuXG5cdFx0Ly8gR2V0IHRoZSByYXcgYWN0aW9uIHNjaGVtYSB0byBhY2Nlc3MgZml4ZWQgYnVzQ2ggdmFsdWVcblx0XHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRcdGNvbnN0IHJhd0FjdGlvbiA9IHNjaGVtYT8uYWN0aW9ucz8uZmluZCgoYTogYW55KSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gYmFzZUlkKVxuXG5cdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdC4uLmFjdGlvbixcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoZXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHQvLyBVc2UgYnVzQ2ggZnJvbSBvcHRpb25zIGlmIHByZXNlbnQsIG90aGVyd2lzZSB1c2UgZml4ZWQgdmFsdWUgZnJvbSBzY2hlbWFcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBldmVudC5vcHRpb25zWydidXNDaCddICE9PSB1bmRlZmluZWQgPyBldmVudC5vcHRpb25zWydidXNDaCddIDogcmF3QWN0aW9uPy5idXNDaFxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGV2ZW50Lm9wdGlvbnNbJ3ZhbHVlJ11cblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBldmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblxuXHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5zZW5kQXdhaXRBY2soYWN0aXZlTW9kZWwsIGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgaXApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgTUlDIEtJTEwgKE9OTFkgSUYgQUNUSVZFIE1PREVMIFNVUFBPUlRTIElUKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Y29uc3QgYWN0aXZlU2NoZW1hID0gc2NoZW1hc1thY3RpdmVNb2RlbF1cblx0aWYgKGFjdGl2ZVNjaGVtYSkge1xuXHRcdGNvbnN0IHN1cHBvcnRzTWljS2lsbCA9IChhY3RpdmVTY2hlbWEuYWN0aW9ucyA/PyBbXSkuc29tZSgoYTogYW55KSA9PiBhLm5hbWUuaW5jbHVkZXMoJ0tpbGwnKSlcblxuXHRcdGlmIChzdXBwb3J0c01pY0tpbGwpIHtcblx0XHRcdGNvbnN0IGFjdGlvbklkID0gYCR7YWN0aXZlTW9kZWx9X21pY0tpbGxgXG5cblx0XHRcdHdpcmVkQWN0aW9uc1thY3Rpb25JZF0gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke2FjdGl2ZU1vZGVsfV0gTWljIEtpbGxgLFxuXHRcdFx0XHRvcHRpb25zOiBbXSxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRcdGNvbnNvbGUubG9nKGBNaWMgS2lsbCBcdTIxOTIgTW9kZWwgJHthY3RpdmVNb2RlbH0gQCAke2lwfWApXG5cdFx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIuZ2xvYmFsTWljS2lsbChhY3RpdmVNb2RlbCwgaXApXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0c2VsZi5zZXRBY3Rpb25EZWZpbml0aW9ucyh3aXJlZEFjdGlvbnMpXG5cblx0Y29uc29sZS5sb2coJ1VwZGF0ZUFjdGlvbnM6IHdpcmVkIGFjdGlvbnM6JywgT2JqZWN0LmtleXMod2lyZWRBY3Rpb25zKS5sZW5ndGgpXG59XG4iLCAiaW1wb3J0IGZzIGZyb20gJ2ZzJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcbmltcG9ydCB7XG5cdENNRF9CVVNfU0VULFxuXHRDTURfQ0hBTk5FTCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcbn0gZnJvbSAnLi90eXBlcy5qcydcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVFlQRVNcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGludGVyZmFjZSBQYXJzZWRTZXR0aW5nIHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRidXNDaD86IG51bWJlciAvLyBPcHRpb25hbDogb25seSBwcmVzZW50IGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoICgweDA0LCAweDEyLCAweDE0KVxuXHR2YWx1ZUJ5dGVzOiBudW1iZXJbXVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFN0QWN0aW9uT3B0aW9uIHtcblx0aWQ/OiBzdHJpbmdcblx0bGFiZWw6IHN0cmluZ1xuXHR0eXBlOiBzdHJpbmdcblx0ZGVmYXVsdDogdW5rbm93blxuXHR0b29sdGlwPzogc3RyaW5nXG5cdGNob2ljZXM/OiBBcnJheTx7IGlkOiBudW1iZXI7IGxhYmVsOiBzdHJpbmcgfT5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBTdEFjdGlvbiB7XG5cdGNtZF9pZDogbnVtYmVyXG5cdGlkOiBudW1iZXJcblx0bmFtZTogc3RyaW5nXG5cdG9wdGlvbnM6IFN0QWN0aW9uT3B0aW9uW11cblx0YnVzQ2g/OiBudW1iZXIgLy8gRml4ZWQgY2hhbm5lbCB2YWx1ZSBmb3IgYWN0aW9ucyB0aGF0IGRvbid0IGhhdmUgYSBjaGFubmVsIG9wdGlvblxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFN0TW9kZWxKc29uIHtcblx0bW9kZWw6IHN0cmluZ1xuXHRhY3Rpb25zOiBTdEFjdGlvbltdXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZPUk1BVCBIRUxQRVJTXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIGdldE1vZGVsQ29uZmlnKG1vZGVsOiBzdHJpbmcpOiB7IHNlY3Rpb25lZDogYm9vbGVhbjsgcmdiSWRzOiBTZXQ8bnVtYmVyPiB9IHtcblx0Y29uc3QgcmdiSWRzID0gbmV3IFNldDxudW1iZXI+KClcblx0bGV0IHNlY3Rpb25lZCA9IGZhbHNlXG5cblx0dHJ5IHtcblx0XHRjb25zdCBzY2hlbWFQYXRoID0gcGF0aC5yZXNvbHZlKGAuL2RldmljZXMvTW9kZWwke21vZGVsfS5qc29uYClcblx0XHRjb25zdCBqc29uID0gSlNPTi5wYXJzZShmcy5yZWFkRmlsZVN5bmMoc2NoZW1hUGF0aCwgJ3V0Zi04JykpXG5cblx0XHQvLyBSZWFkIHNlY3Rpb25lZCBwcm9wZXJ0eSAoZGVmYXVsdCB0byBmYWxzZSBpZiBub3Qgc3BlY2lmaWVkKVxuXHRcdHNlY3Rpb25lZCA9IGpzb24uc2VjdGlvbmVkID8/IGZhbHNlXG5cblx0XHQvLyBCdWlsZCBSR0IgSURzIHNldFxuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHQvLyBBZGQgdGhlIGJhc2UgSURcblx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQpXG5cblx0XHRcdFx0Ly8gSWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkIGNob2ljZXMsIGFkZCBhbGwgdGhlIG9mZnNldCBJRHMgdG9vXG5cdFx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjaG9pY2Ugb2YgaWRBZGRPcHRpb24uY2hvaWNlcykge1xuXHRcdFx0XHRcdFx0aWYgKHR5cGVvZiBjaG9pY2UuaWQgPT09ICdudW1iZXInKSB7XG5cdFx0XHRcdFx0XHRcdHJnYklkcy5hZGQoYWN0aW9uLmlkICsgY2hvaWNlLmlkKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCAoX2Vycikge1xuXHRcdC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHNjaGVtYSwgcmV0dXJuIGRlZmF1bHRzXG5cdH1cblxuXHRyZXR1cm4geyBzZWN0aW9uZWQsIHJnYklkcyB9XG59XG5cbmZ1bmN0aW9uIG1vZGVsRGlzdGFuY2UoYTogc3RyaW5nLCBiOiBzdHJpbmcpOiBudW1iZXIge1xuXHRjb25zdCBuYSA9IHBhcnNlSW50KGEucmVwbGFjZSgvXFxEL2csICcnKSwgMTApXG5cdGNvbnN0IG5iID0gcGFyc2VJbnQoYi5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0aWYgKE51bWJlci5pc05hTihuYSkgfHwgTnVtYmVyLmlzTmFOKG5iKSkgcmV0dXJuIEluZmluaXR5XG5cdHJldHVybiBNYXRoLmFicyhuYSAtIG5iKVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGSU5EIFRIRSBSRUFMIDVBIFBBWUxPQUQgSU5ERVhcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1ZjogQnVmZmVyKTogbnVtYmVyIHtcblx0Y29uc3Qgc2lnSW5kZXggPSBidWYuaW5kZXhPZihCdWZmZXIuZnJvbSgnU3R1ZGlvLVQnKSlcblx0aWYgKHNpZ0luZGV4IDwgMCkgdGhyb3cgbmV3IEVycm9yKCdObyBTdHVkaW8tVCBzaWduYXR1cmUgaW4gcGFja2V0JylcblxuXHRjb25zdCBwYXlsb2FkSW5kZXggPSBzaWdJbmRleCArIDhcblx0aWYgKGJ1ZltwYXlsb2FkSW5kZXhdICE9PSAweDVhKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCAweDVBIGFmdGVyIFN0dWRpby1ULCBmb3VuZCAke2J1ZltwYXlsb2FkSW5kZXhdLnRvU3RyaW5nKDE2KX1gKVxuXHR9XG5cblx0cmV0dXJuIHBheWxvYWRJbmRleFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGTEFUIFBBUlNFUlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBwYXJzZUZsYXRJZFZhbFNlcXVlbmNlKGJsb2NrOiBCdWZmZXIsIHJnYklkczogU2V0PG51bWJlcj4gPSBuZXcgU2V0KCkpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRsZXQgcCA9IDBcblx0Y29uc3Qgb3V0OiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdHdoaWxlIChwIDwgYmxvY2subGVuZ3RoKSB7XG5cdFx0Y29uc3QgaWQgPSBibG9ja1twXVxuXHRcdGlmIChwICsgMSA+PSBibG9jay5sZW5ndGgpIGJyZWFrXG5cblx0XHQvLyBSR0IgY2FzZSAtIGNoZWNrIGlmIHRoaXMgSUQgaXMgYSBrbm93biBjb2xvcnBpY2tlclxuXHRcdGlmIChyZ2JJZHMuaGFzKGlkKSAmJiBwICsgMyA8IGJsb2NrLmxlbmd0aCkge1xuXHRcdFx0b3V0LnB1c2goe1xuXHRcdFx0XHRjbWRfaWQ6IENNRF9ERVZfU1BFQyxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdHZhbHVlQnl0ZXM6IFtibG9ja1twICsgMV0sIGJsb2NrW3AgKyAyXSwgYmxvY2tbcCArIDNdXSxcblx0XHRcdH0pXG5cdFx0XHRwICs9IDRcblx0XHRcdGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0b3V0LnB1c2goeyBjbWRfaWQ6IENNRF9ERVZfU1BFQywgaWQsIHZhbHVlQnl0ZXM6IFtibG9ja1twICsgMV1dIH0pXG5cdFx0cCArPSAyXG5cdH1cblxuXHRyZXR1cm4gb3V0XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmOiBCdWZmZXIsIG1vZGVsOiBzdHJpbmcpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ05vdCBhIGdldEFsbFNldHRpbmdzIHJlcGx5Jylcblx0fVxuXG5cdGNvbnN0IGJsb2NrTGVuID0gYnVmW2lkeCArIDJdXG5cdGNvbnN0IHN0YXJ0ID0gaWR4ICsgM1xuXHRjb25zdCBlbmQgPSBzdGFydCArIGJsb2NrTGVuXG5cdGlmIChlbmQgPiBidWYubGVuZ3RoKSB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgYmxvY2sgbGVuZ3RoJylcblxuXHRjb25zdCB7IHJnYklkcyB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cdHJldHVybiBwYXJzZUZsYXRJZFZhbFNlcXVlbmNlKGJ1Zi5zdWJhcnJheShzdGFydCwgZW5kKSwgcmdiSWRzKVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTRUNUSU9ORUQgUEFSU0VSXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Ly8gQ01EX0dFVF9BTExfU0VUVElOR1MgaGFzIGEgdG90YWwtbGVuZ3RoIGJ5dGUgYXQgaWR4KzIgYmVmb3JlIHRoZSBzZWN0aW9uczsgQ01EX1NFVFRJTkdTX1BVU0ggZG9lcyBub3QuXG5cdGxldCBwID0gY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTID8gaWR4ICsgMyA6IGlkeCArIDJcblx0Y29uc3QgZW5kID0gYnVmLmxlbmd0aCAtIDFcblx0Y29uc3Qgb3V0OiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdC8vIEdldCBSR0IgSURzIGZvciB0aGlzIG1vZGVsXG5cdGNvbnN0IHsgcmdiSWRzIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblxuXHQvLyBDb21tYW5kIElEcyB0aGF0IGluY2x1ZGUgYSBidXNDaCBieXRlIGluIHRoZWlyIHNlY3Rpb24gc3RydWN0dXJlXG5cdGNvbnN0IGNvbW1hbmRzV2l0aEJ1c0NoID0gW0NNRF9CVVNfU0VULCBDTURfTUlDX1BSRV9CVVMsIENNRF9DSEFOTkVMXVxuXG5cdHdoaWxlIChwICsgMiA8IGVuZCkge1xuXHRcdGNvbnN0IGNtZExlbiA9IGJ1ZltwXVxuXHRcdGNvbnN0IHNlY3Rpb25DbWRJZCA9IGJ1ZltwICsgMV1cblxuXHRcdGNvbnN0IHNlY3Rpb25FbmQgPSBwICsgMSArIGNtZExlblxuXHRcdGlmIChzZWN0aW9uRW5kID4gZW5kKSBicmVha1xuXG5cdFx0Ly8gQ2hlY2sgaWYgdGhpcyBjb21tYW5kIGluY2x1ZGVzIGEgYnVzQ2ggYnl0ZVxuXHRcdGNvbnN0IGhhc0J1c0NoID0gY29tbWFuZHNXaXRoQnVzQ2guaW5jbHVkZXMoc2VjdGlvbkNtZElkKVxuXG5cdFx0bGV0IGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWRcblx0XHRsZXQgZGF0YUxlbjogbnVtYmVyXG5cdFx0bGV0IHE6IG51bWJlclxuXG5cdFx0aWYgKGhhc0J1c0NoKSB7XG5cdFx0XHQvLyBTdHJ1Y3R1cmU6IFtjbWRMZW5dIFtjbWRJZF0gW2J1c0NoXSBbZGF0YUxlbl0gW2lkOnZhbCBwYWlyc11cblx0XHRcdGJ1c0NoID0gYnVmW3AgKyAyXVxuXHRcdFx0ZGF0YUxlbiA9IGJ1ZltwICsgM11cblx0XHRcdHEgPSBwICsgNCAvLyBEYXRhIHN0YXJ0cyBhZnRlciBjbWRMZW4sIGNtZElkLCBidXNDaCwgZGF0YUxlblxuXHRcdH0gZWxzZSB7XG5cdFx0XHQvLyBTdHJ1Y3R1cmU6IFtjbWRMZW5dIFtjbWRJZF0gW2RhdGFMZW5dIFtpZDp2YWwgcGFpcnNdXG5cdFx0XHRkYXRhTGVuID0gYnVmW3AgKyAyXVxuXHRcdFx0cSA9IHAgKyAzIC8vIERhdGEgc3RhcnRzIGFmdGVyIGNtZExlbiwgY21kSWQsIGRhdGFMZW5cblx0XHR9XG5cblx0XHRjb25zdCBxRW5kID0gcSArIGRhdGFMZW5cblxuXHRcdHdoaWxlIChxICsgMSA8IHFFbmQpIHtcblx0XHRcdGNvbnN0IGlkID0gYnVmW3FdXG5cdFx0XHRsZXQgdmFsdWVCeXRlczogbnVtYmVyW11cblxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBJRCBpcyBhbiBSR0IgY29sb3JwaWNrZXIgKG5lZWRzIDMgYnl0ZXMpXG5cdFx0XHRpZiAocmdiSWRzLmhhcyhpZCkgJiYgcSArIDMgPCBxRW5kKSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXSwgYnVmW3EgKyAyXSwgYnVmW3EgKyAzXV1cblx0XHRcdFx0cSArPSA0XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV1dXG5cdFx0XHRcdHEgKz0gMlxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IHNlY3Rpb25DbWRJZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdH1cblx0XHRcdG91dC5wdXNoKHNldHRpbmcpXG5cdFx0fVxuXG5cdFx0cCA9IHNlY3Rpb25FbmRcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgR0VORVJJQyBTRVRUSU5HUyBSRVNQT05TRSBQQVJTRVIgKDB4MGEgZ2V0LWFsbCArIDB4MGIgdW5zb2xpY2l0ZWQgcHVzaClcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBQYXJzZXMgYW55IGZ1bGwgc2V0dGluZ3MgYmxvY2sgcmVnYXJkbGVzcyBvZiB3aGV0aGVyIHRoZSBjbWRJZCBpcyAweDBhXG4gKiAocmVzcG9uc2UgdG8gR2V0IEFsbCBTZXR0aW5ncykgb3IgMHgwYiAodW5zb2xpY2l0ZWQgcHVzaCBhZnRlciBhIHNldCkuXG4gKiBCb3RoIHVzZSB0aGUgc2FtZSBzZWN0aW9uZWQgb3IgZmxhdCBibG9jayBsYXlvdXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdzUmVzcG9uc2UobW9kZWw6IHN0cmluZywgYnVmOiBCdWZmZXIpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYE5vdCBhIHNldHRpbmdzIGJsb2NrIChjbWRJZD0weCR7Y21kSWQudG9TdHJpbmcoMTYpfSlgKVxuXHR9XG5cdGNvbnN0IHsgc2VjdGlvbmVkIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHNlY3Rpb25lZCA/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpIDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG59XG5cbi8qKlxuICogRm9ybWF0cyBhIHNpbmdsZSBwYXJzZWQgc2V0dGluZyBpbnRvIGEgaHVtYW4tcmVhZGFibGUgc3RyaW5nIHVzaW5nIGFjdGlvblxuICogZGVmaW5pdGlvbnMgZnJvbSB0aGUgZGV2aWNlIEpTT04uIEZhbGxzIGJhY2sgdG8gaGV4IElEcyB3aGVuIHVua25vd24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmc6IFBhcnNlZFNldHRpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiBzdHJpbmcge1xuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IHNldHRpbmcuY21kX2lkICYmIGEuaWQgPT09IHNldHRpbmcuaWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2ggYW5kIGlkID4gYmFzZSBpZCwgdHJ5IHRvIGZpbmQgYWN0aW9uIHdpdGggaWRBZGQgb3B0aW9uXG5cdC8vIFRoaXMgaGFuZGxlcyBjYXNlcyBsaWtlIGNtZF9pZCA1IChQaG9uZXMgUm91dGluZykgYW5kIGNtZF9pZCA3IChCdXR0b25zKVxuXHQvLyB3aGVyZSBpZCAwLTMgcmVwcmVzZW50cyBjaGFubmVscyAxLTRcblx0aWYgKCFhY3Rpb24pIHtcblx0XHRjb25zdCBiYXNlQWN0aW9uID0gYWN0aW9ucy5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IHNldHRpbmcuY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHRoaXMgYWN0aW9uIGhhcyBhbiBpZEFkZCBvcHRpb24gKGluZGljYXRpbmcgY2hhbm5lbCBzZWxlY3Rpb24pXG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGEub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHRoZSBzZXR0aW5nLmlkIG9mZnNldCBtYXRjaGVzIG9uZSBvZiB0aGUgaWRBZGQgY2hvaWNlIElEc1xuXHRcdFx0Y29uc3QgY2hhbm5lbE9mZnNldCA9IHNldHRpbmcuaWQgLSBhLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdH0pXG5cdFx0aWYgKGJhc2VBY3Rpb24pIHtcblx0XHRcdGFjdGlvbiA9IGJhc2VBY3Rpb25cblx0XHR9XG5cdH1cblxuXHRjb25zdCBjbWRIZXggPSBgMHgke3NldHRpbmcuY21kX2lkLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfWBcblx0Y29uc3QgaWRIZXggPSBgMHgke3NldHRpbmcuaWQudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9YFxuXHRjb25zdCB2YWxIZXggPSBgMHgke3NldHRpbmcudmFsdWVCeXRlcy5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJycpfWBcblx0Y29uc3QgdmFsRGVjID1cblx0XHRzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHQ/IGAjJHtzZXR0aW5nLnZhbHVlQnl0ZXNcblx0XHRcdFx0XHQubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuXHRcdFx0XHRcdC5qb2luKCcnKVxuXHRcdFx0XHRcdC50b1VwcGVyQ2FzZSgpfWBcblx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMVxuXHRcdFx0XHQ/IHNldHRpbmcudmFsdWVCeXRlc1swXVxuXHRcdFx0XHQ6IHNldHRpbmcudmFsdWVCeXRlcy5qb2luKCcsJylcblxuXHQvLyBCdWlsZCB0aGUgcHJlZml4OiBjbWQ6MHgxMiBjaDowIGlkOjB4MDEgdmFsOjB4MTQgKGNoIG9ubHkgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2gpXG5cdGNvbnN0IGJ1c0NoU3RyID0gc2V0dGluZy5idXNDaCAhPT0gdW5kZWZpbmVkID8gYCBjaDoke3NldHRpbmcuYnVzQ2h9YCA6ICcnXG5cdGNvbnN0IHByZWZpeCA9IGBjbWQ6JHtjbWRIZXh9JHtidXNDaFN0cn0gaWQ6JHtpZEhleH0gdmFsOiR7dmFsSGV4fWBcblxuXHQvLyBJZiB3ZSBoYXZlIGFuIGFjdGlvbiB3aXRoIGEgbmFtZSBhbmQgY2hvaWNlIGxhYmVsLCB1c2UgaXRcblx0aWYgKGFjdGlvbikge1xuXHRcdGxldCBuYW1lID0gYWN0aW9uLm5hbWVcblxuXHRcdC8vIElmIHNldHRpbmcgaGFzIGJ1c0NoLCBhZGQgY2hhbm5lbCBpbmZvIHRvIG5hbWVcblx0XHRpZiAoc2V0dGluZy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRuYW1lID0gYCR7bmFtZX0gQ2gke3NldHRpbmcuYnVzQ2ggKyAxfWBcblx0XHR9XG5cdFx0Ly8gT3RoZXJ3aXNlLCBpZiB0aGlzIGFjdGlvbiBoYXMgaWRBZGQsIGluY2x1ZGUgdGhlIGlkQWRkIGxhYmVsXG5cdFx0ZWxzZSB7XG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmIChpZEFkZE9wdGlvbj8uY2hvaWNlcykge1xuXHRcdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZy5pZCAtIGFjdGlvbi5pZFxuXHRcdFx0XHRjb25zdCBpZEFkZENob2ljZSA9IGlkQWRkT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHRcdFx0aWYgKGlkQWRkQ2hvaWNlKSB7XG5cdFx0XHRcdFx0bmFtZSA9IGAke25hbWV9ICR7aWRBZGRDaG9pY2UubGFiZWx9YFxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gTG9vayBmb3IgdGhlIHZhbHVlIG9wdGlvbiAobm90IGJ1c0NoIG9yIGlkQWRkKVxuXHRcdGNvbnN0IHZhbHVlT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAndmFsdWUnKVxuXHRcdGlmICh2YWx1ZU9wdGlvbj8uY2hvaWNlcyAmJiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRjb25zdCBjaG9pY2UgPSB2YWx1ZU9wdGlvbi5jaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHNldHRpbmcudmFsdWVCeXRlc1swXSlcblx0XHRcdGlmIChjaG9pY2UpIHtcblx0XHRcdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke2Nob2ljZS5sYWJlbH0gKCR7dmFsRGVjfSlgXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBgJHtwcmVmaXh9IHwgJHtuYW1lfTogJHt2YWxEZWN9YFxuXHR9XG5cblx0Ly8gTm8gYWN0aW9uIGZvdW5kIC0ganVzdCBzaG93IHRoZSByYXcgdmFsdWVzXG5cdHJldHVybiBgJHtwcmVmaXh9IHwgVW5rbm93biBTZXR0aW5nYFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBQQVJTRVIgRElTUEFUQ0hcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbChtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IHsgc2VjdGlvbmVkIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHNlY3Rpb25lZCA/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpIDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG59XG5cbi8qIFx1MjcwNSBiYWNrd2FyZC1jb21wYXRpYmxlIGV4cG9ydCAqL1xuZXhwb3J0IGNvbnN0IHBhcnNlR2V0QWxsU2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWxcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVkFMVUUgXHUyMTkyIE9QVElPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlczogbnVtYmVyW10pOiBTdEFjdGlvbk9wdGlvbiB7XG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdHJldHVybiB7IGlkOiAndmFsdWUnLCBsYWJlbDogJ1ZhbHVlJywgdHlwZTogJ251bWJlcicsIGRlZmF1bHQ6IHZhbHVlQnl0ZXNbMF0gfVxuXHR9XG5cblx0aWYgKHZhbHVlQnl0ZXMubGVuZ3RoID09PSAzKSB7XG5cdFx0Y29uc3QgW3IsIGcsIGJdID0gdmFsdWVCeXRlc1xuXHRcdHJldHVybiB7XG5cdFx0XHRpZDogJ3ZhbHVlJyxcblx0XHRcdGxhYmVsOiAnQ29sb3InLFxuXHRcdFx0dHlwZTogJ2NvbG9ycGlja2VyJyxcblx0XHRcdGRlZmF1bHQ6IGAjJHtyLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfSR7Z1xuXHRcdFx0XHQudG9TdHJpbmcoMTYpXG5cdFx0XHRcdC5wYWRTdGFydCgyLCAnMCcpfSR7Yi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gLFxuXHRcdH1cblx0fVxuXG5cdHJldHVybiB7IGlkOiAndmFsdWUnLCBsYWJlbDogJ1ZhbHVlJywgdHlwZTogJ3JhdycsIGRlZmF1bHQ6IFsuLi52YWx1ZUJ5dGVzXSB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNNQVJUIEpTT04gVVBEQVRFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MoXG5cdG1vZGVsSnNvbjogU3RNb2RlbEpzb24sXG5cdHBhcnNlZDogUGFyc2VkU2V0dGluZ1tdLFxuXHRhbGxNb2RlbHM6IFJlY29yZDxzdHJpbmcsIFN0TW9kZWxKc29uPixcbik6IFN0TW9kZWxKc29uIHtcblx0Y29uc3Qgb3V0ID0gc3RydWN0dXJlZENsb25lKG1vZGVsSnNvbilcblxuXHQvLyBFbnN1cmUgYWN0aW9ucyBhcnJheSBleGlzdHNcblx0aWYgKCFvdXQuYWN0aW9ucykge1xuXHRcdG91dC5hY3Rpb25zID0gW11cblx0fVxuXG5cdC8vIFNvcnQgb3RoZXIgbW9kZWxzIGJ5IG51bWVyaWMgZGlzdGFuY2UgdG8gY3VycmVudCBtb2RlbFxuXHRjb25zdCBjYW5kaWRhdGVzID0gT2JqZWN0LnZhbHVlcyhhbGxNb2RlbHMpXG5cdFx0LmZpbHRlcigobSkgPT4gbS5tb2RlbCAhPT0gbW9kZWxKc29uLm1vZGVsKSAvLyBleGNsdWRlIHNlbGZcblx0XHQuc29ydCgoYSwgYikgPT4gbW9kZWxEaXN0YW5jZShtb2RlbEpzb24ubW9kZWwsIGEubW9kZWwpIC0gbW9kZWxEaXN0YW5jZShtb2RlbEpzb24ubW9kZWwsIGIubW9kZWwpKVxuXG5cdGNvbnNvbGUubG9nKGBVcGRhdGluZyBtb2RlbDogJHttb2RlbEpzb24ubW9kZWx9YClcblx0Y29uc29sZS5sb2coYENhbmRpZGF0ZXMgZm9yIGluZmVyZW5jZTogJHtjYW5kaWRhdGVzLm1hcCgoYykgPT4gYy5tb2RlbCl9YClcblxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCwgdmFsdWVCeXRlcyB9IG9mIHBhcnNlZCkge1xuXHRcdGxldCBhY3Rpb24gPSBvdXQuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXG5cdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdC8vIFRyeSBjYW5kaWRhdGVzIGluIG9yZGVyIG9mIHByb3hpbWl0eVxuXHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0Y29uc3QgbWF0Y2ggPSBjLmFjdGlvbnM/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0XHRcdGlmIChtYXRjaCkge1xuXHRcdFx0XHRcdGFjdGlvbiA9IHN0cnVjdHVyZWRDbG9uZShtYXRjaClcblx0XHRcdFx0XHRhY3Rpb24ubmFtZSA9IGAke21hdGNoLm5hbWV9IChpbmZlcnJlZCBmcm9tIE1vZGVsICR7Yy5tb2RlbH0pYFxuXHRcdFx0XHRcdGNvbnNvbGUubG9nKGBJbmZlcnJlZCBzZXR0aW5nIDB4JHtpZC50b1N0cmluZygxNil9IGZyb20gTW9kZWwgJHtjLm1vZGVsfWApXG5cdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSB7XG5cdFx0XHRcdGNtZF9pZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdG5hbWU6IGBVbmtub3duIFNldHRpbmcgMHgke2lkLnRvU3RyaW5nKDE2KS50b1VwcGVyQ2FzZSgpfWAsXG5cdFx0XHRcdG9wdGlvbnM6IFt2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcyldLFxuXHRcdFx0fVxuXHRcdFx0Y29uc29sZS5sb2coYENvdWxkIG5vdCBpbmZlciBzZXR0aW5nIDB4JHtpZC50b1N0cmluZygxNil9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3Qgb3B0ID0gYWN0aW9uLm9wdGlvbnM/LlswXVxuXHRcdFx0aWYgKG9wdCkgb3B0LmRlZmF1bHQgPSB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcykuZGVmYXVsdFxuXHRcdH1cblxuXHRcdC8vIEF2b2lkIGR1cGxpY2F0ZXNcblx0XHRjb25zdCBleGlzdHMgPSBvdXQuYWN0aW9ucy5zb21lKChhKSA9PiBhLmNtZF9pZCA9PT0gYWN0aW9uLmNtZF9pZCAmJiBhLmlkID09PSBhY3Rpb24uaWQpXG5cdFx0aWYgKCFleGlzdHMpIG91dC5hY3Rpb25zLnB1c2goYWN0aW9uKVxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTQVZFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBzYXZlTW9kZWxKc29uUHJldHR5KGZpbGVQYXRoOiBzdHJpbmcsIGpzb25PYmo6IFN0TW9kZWxKc29uKTogdm9pZCB7XG5cdHRyeSB7XG5cdFx0Ly8gQ3VzdG9tIGZvcm1hdHRlcjoga2VlcCBjaG9pY2Ugb2JqZWN0cyBjb21wYWN0IG9uIG9uZSBsaW5lXG5cdFx0bGV0IGpzb24gPSBKU09OLnN0cmluZ2lmeShqc29uT2JqLCBudWxsLCAyKVxuXG5cdFx0Ly8gUmVwbGFjZSBleHBhbmRlZCBjaG9pY2Ugb2JqZWN0cyB3aXRoIGNvbXBhY3Qgc2luZ2xlLWxpbmUgZm9ybWF0XG5cdFx0Ly8gTWF0Y2hlczoge1xcbiAgICAgICAgICAgIFwiaWRcIjogWCxcXG4gICAgICAgICAgICBcImxhYmVsXCI6IFwiWVwiXFxuICAgICAgICAgIH1cblx0XHQvLyBSZXBsYWNlcyB3aXRoOiB7IFwiaWRcIjogWCwgXCJsYWJlbFwiOiBcIllcIiB9XG5cdFx0anNvbiA9IGpzb24ucmVwbGFjZSgvXFx7XFxuXFxzK1wiaWRcIjpcXHMqKFxcZCspLFxcblxccytcImxhYmVsXCI6XFxzKlwiKFteXCJdKilcIlxcblxccytcXH0vZywgJ3sgXCJpZFwiOiAkMSwgXCJsYWJlbFwiOiBcIiQyXCIgfScpXG5cblx0XHRmcy53cml0ZUZpbGVTeW5jKGZpbGVQYXRoLCBqc29uICsgJ1xcbicsICd1dGY4Jylcblx0fSBjYXRjaCAoZSkge1xuXHRcdGNvbnNvbGUubG9nKCdGaWxlIFdyaXRlIEVycm9yOicsIGUpXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgTE9BRCBERVZJQ0UgSlNPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIExvYWRzIHRoZSBhY3Rpb25zIGFycmF5IGZvciBhIGdpdmVuIG1vZGVsIGZyb20gdGhlIGRldmljZXMgZm9sZGVyLlxuICogUmV0dXJucyBhbiBlbXB0eSBhcnJheSBpZiB0aGUgZmlsZSBpcyBtaXNzaW5nIG9yIHVucGFyc2VhYmxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZEFjdGlvbnNGb3JNb2RlbChkZXZpY2VzRm9sZGVyOiBzdHJpbmcsIG1vZGVsOiBzdHJpbmcpOiBTdEFjdGlvbltdIHtcblx0dHJ5IHtcblx0XHRjb25zdCBmaWxlUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBgTW9kZWwke21vZGVsfS5qc29uYClcblx0XHRjb25zdCBqc29uOiBhbnkgPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhmaWxlUGF0aCwgJ3V0ZjgnKSlcblx0XHRyZXR1cm4ganNvbj8uY21kU2NoZW1hID8/IFtdXG5cdH0gY2F0Y2gge1xuXHRcdHJldHVybiBbXVxuXHR9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBsb2FkTW9kZWxDb25maWcoXG5cdGRldmljZXNGb2xkZXI6IHN0cmluZyxcblx0bW9kZWw6IHN0cmluZyxcbik6IHsgYWN0aW9uczogU3RBY3Rpb25bXTsgcmVmcmVzaEFmdGVyQ29tbWFuZDogYm9vbGVhbiB9IHtcblx0dHJ5IHtcblx0XHRjb25zdCBmaWxlUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBgTW9kZWwke21vZGVsfS5qc29uYClcblx0XHRjb25zdCBqc29uOiBhbnkgPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhmaWxlUGF0aCwgJ3V0ZjgnKSlcblx0XHRyZXR1cm4ge1xuXHRcdFx0YWN0aW9uczoganNvbj8uY21kU2NoZW1hID8/IFtdLFxuXHRcdFx0cmVmcmVzaEFmdGVyQ29tbWFuZDoganNvbj8ucmVmcmVzaEFmdGVyQ29tbWFuZCA/PyB0cnVlLCAvLyBEZWZhdWx0IHRvIHRydWUgaWYgbm90IHNwZWNpZmllZFxuXHRcdH1cblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIHsgYWN0aW9uczogW10sIHJlZnJlc2hBZnRlckNvbW1hbmQ6IHRydWUgfVxuXHR9XG59XG4iLCAiaW1wb3J0IE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcbmltcG9ydCB7IGJ1aWxkRmVlZGJhY2tzLCBsb2FkVWlTY2hlbWFzIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IHJlc29sdmVNb2RlbCB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgU3RNb2RlbEpzb24gfSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcblxuLyoqXG4gKiBIZWxwZXIgZnVuY3Rpb24gdG8gZ2V0IGxhYmVsIGZyb20gY2hvaWNlcyBiYXNlZCBvbiB2YWx1ZVxuICovXG5mdW5jdGlvbiBnZXRMYWJlbEZvclZhbHVlKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCBTdE1vZGVsSnNvbj4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuXHR2YWx1ZTogbnVtYmVyLFxuKTogc3RyaW5nIHwgbnVtYmVyIHtcblx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0aWYgKCFzY2hlbWEgfHwgIUFycmF5LmlzQXJyYXkoc2NoZW1hLmFjdGlvbnMpKSByZXR1cm4gdmFsdWVcblxuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IHNldHRpbmcgPSBzY2hlbWEuYWN0aW9ucy5maW5kKChzOiBhbnkpID0+IHMuY21kX2lkID09PSBjbWRJZCAmJiBzLmlkID09PSBzZXR0aW5nSWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2gsIHRyeSB0byBmaW5kIGJhc2UgYWN0aW9uIHdpdGggaWRBZGRcblx0aWYgKCFzZXR0aW5nKSB7XG5cdFx0c2V0dGluZyA9IHNjaGVtYS5hY3Rpb25zLmZpbmQoKHM6IGFueSkgPT4ge1xuXHRcdFx0aWYgKHMuY21kX2lkICE9PSBjbWRJZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IHMub3B0aW9ucz8uZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgc2V0dGluZ0lkIG1hdGNoZXMgYmFzZSArIGFueSBpZEFkZCBvZmZzZXRcblx0XHRcdGNvbnN0IG9mZnNldCA9IHNldHRpbmdJZCAtIHMuaWRcblx0XHRcdHJldHVybiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KVxuXHRcdH0pXG5cdH1cblxuXHRpZiAoIXNldHRpbmcgfHwgIUFycmF5LmlzQXJyYXkoc2V0dGluZy5vcHRpb25zKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgJ3ZhbHVlJyBvcHRpb24gd2hpY2ggY29udGFpbnMgdGhlIGNob2ljZXNcblx0Y29uc3QgdmFsdWVPcHRpb24gPSBzZXR0aW5nLm9wdGlvbnMuZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0aWYgKCF2YWx1ZU9wdGlvbiB8fCAhQXJyYXkuaXNBcnJheSh2YWx1ZU9wdGlvbi5jaG9pY2VzKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgY2hvaWNlIHdpdGggbWF0Y2hpbmcgaWRcblx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjOiBhbnkpID0+IGMuaWQgPT09IHZhbHVlKVxuXHRyZXR1cm4gY2hvaWNlPy5sYWJlbCA/PyB2YWx1ZVxufVxuXG4vKipcbiAqIEJ1aWxkIGFuZCB3aXJlIENvbXBhbmlvbiBmZWVkYmFjayBkZWZpbml0aW9uc1xuICogUGF0dGVybiBtYXRjaGVzIGFjdGlvbnMudHMgLSBmaWx0ZXJzIGJ5IGFjdGl2ZSBtb2RlbCBhbmQgd2lyZXMgY2FsbGJhY2tzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVGZWVkYmFja3Moc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3QgZGV2aWNlc0ZvbGRlciA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi4vZGV2aWNlcycpXG5cblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGxvYWRVaVNjaGVtYXMoZGV2aWNlc0ZvbGRlcilcblx0Y29uc3QgcmF3RmVlZGJhY2tzID0gYnVpbGRGZWVkYmFja3MoZGV2aWNlc0ZvbGRlcilcblx0Y29uc3Qgc2NoZW1hczogUmVjb3JkPHN0cmluZywgU3RNb2RlbEpzb24+ID0ge31cblx0Zm9yIChjb25zdCBbbW9kZWwsIGpzb25dIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXNSYXcpKSB7XG5cdFx0c2NoZW1hc1ttb2RlbF0gPSB7XG5cdFx0XHRtb2RlbDoganNvbi5tb2RlbCxcblx0XHRcdGFjdGlvbnM6IEFycmF5LmlzQXJyYXkoanNvbi5jbWRTY2hlbWEpID8ganNvbi5jbWRTY2hlbWEgOiBbXSxcblx0XHR9XG5cdH1cblx0Y29uc3Qgd2lyZWRGZWVkYmFja3M6IGFueSA9IHt9XG5cblx0Ly8gR2V0IHRoZSBhY3RpdmUgbW9kZWwgdXNpbmcgcmVzb2x2ZU1vZGVsXG5cdGNvbnN0IGFjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKHNlbGYuY29uZmlnLCBzZWxmLmRldmljZXMpXG5cdGNvbnNvbGUubG9nKFxuXHRcdGBVcGRhdGVGZWVkYmFja3M6IGFjdGl2ZU1vZGVsPVwiJHthY3RpdmVNb2RlbH1cIiwgZGlzY292ZXJlZEhvc3Q9XCIke3NlbGYuY29uZmlnLmRpc2NvdmVyZWRIb3N0fVwiLCBkZXZpY2VzIGNvdW50PSR7c2VsZi5kZXZpY2VzLmxlbmd0aH1gLFxuXHQpXG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBCVUlMRCBQRVItU0VUVElORyBGRUVEQkFDS1MgKEZJTFRFUkVEIEJZIEFDVElWRSBNT0RFTClcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0Zm9yIChjb25zdCBbZmVlZGJhY2tJZCwgZmVlZGJhY2tdIG9mIE9iamVjdC5lbnRyaWVzKHJhd0ZlZWRiYWNrcykpIHtcblx0XHRjb25zdCBbbW9kZWwsIGNtZElkU3RyLCBpZFN0cl0gPSBmZWVkYmFja0lkLnNwbGl0KCdfJylcblxuXHRcdC8vIE9ubHkgaW5jbHVkZSBmZWVkYmFja3MgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdGNvbnN0IGNtZElkID0gcGFyc2VJbnQoY21kSWRTdHIsIDE2KVxuXHRcdGNvbnN0IGJhc2VJZCA9IHBhcnNlSW50KGlkU3RyLCAxNilcblxuXHRcdC8vIFZBTFVFIEZFRURCQUNLOiBSZXR1cm5zIGN1cnJlbnQgdmFsdWUgZm9yIGxvY2FsIHZhcmlhYmxlXG5cdFx0d2lyZWRGZWVkYmFja3NbZmVlZGJhY2tJZF0gPSB7XG5cdFx0XHQuLi5mZWVkYmFjayxcblx0XHRcdGNhbGxiYWNrOiAoZmVlZGJhY2tFdmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydidXNDaCddXG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblx0XHRcdFx0Y29uc3QgY3VycmVudCA9IHNlbGYuc3RDb250cm9sbGVyLmdldFNldHRpbmdWYWx1ZShpcCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cblx0XHRcdFx0Ly8gQ2hlY2sgaWYgdXNlciB3YW50cyBsYWJlbCBpbnN0ZWFkIG9mIG51bWVyaWMgdmFsdWVcblx0XHRcdFx0Y29uc3Qgc2hvd0xhYmVsID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydzaG93TGFiZWwnXSA/PyBmYWxzZVxuXG5cdFx0XHRcdGlmIChzaG93TGFiZWwgJiYgY3VycmVudCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Ly8gUmV0dXJuIHRoZSBsYWJlbCBmcm9tIGNob2ljZXNcblx0XHRcdFx0XHRyZXR1cm4gZ2V0TGFiZWxGb3JWYWx1ZShzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgY3VycmVudClcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFJldHVybiBudW1lcmljIHZhbHVlIGRpcmVjdGx5IGZvciBsb2NhbCB2YXJpYWJsZSAodHlwZTogJ3ZhbHVlJylcblx0XHRcdFx0cmV0dXJuIGN1cnJlbnQgPz8gMFxuXHRcdFx0fSxcblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEZlZWRiYWNrRGVmaW5pdGlvbnMod2lyZWRGZWVkYmFja3MpXG5cblx0Y29uc29sZS5sb2coJ1VwZGF0ZUZlZWRiYWNrczogd2lyZWQgZmVlZGJhY2tzOicsIE9iamVjdC5rZXlzKHdpcmVkRmVlZGJhY2tzKS5sZW5ndGgpXG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IG9zIGZyb20gJ29zJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9CVVNfR0VULFxuXHRDTURfQlVTX1NFVCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX0dMT0JBTF9NSUNfS0lMTCxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfUkVTRVRfREVWSUNFLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0Z2V0Q29tbWFuZE5hbWUsXG5cdG1ha2VTZXR0aW5nSWQsXG5cdHR5cGUgRGV2aWNlSW5mbyxcbn0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7XG5cdHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCxcblx0cGFyc2VTZXR0aW5nc1Jlc3BvbnNlLFxuXHRmb3JtYXRQYXJzZWRTZXR0aW5nLFxuXHR0eXBlIFN0QWN0aW9uLFxufSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuaW1wb3J0IHtcblx0REFOVEVfTVNHX0lORk9fUkVTUE9OU0UsXG5cdHBhcnNlRGFudGVJbmZvUmVzcG9uc2UsXG5cdGRpc2NvdmVyRGV2aWNlcyxcblx0Z2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24sXG59IGZyb20gJy4vZGFudGUuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU3RDb250cm9sbGVyJylcblxuZXhwb3J0IGNsYXNzIFN0Q29udHJvbGxlciB7XG5cdHByaXZhdGUgcmVhZG9ubHkgZGVmYXVsdFBvcnQ6IG51bWJlciA9IDg3MDBcblx0cHJpdmF0ZSByZWFkb25seSBtdWx0aWNhc3RHcm91cCA9ICcyMjQuMC4wLjIzMSdcblx0cHJpdmF0ZSByZWFkb25seSByeFBvcnQgPSA4NzAyXG5cblx0cHJpdmF0ZSB0eFNvY2tldDogZGdyYW0uU29ja2V0XG5cdHByaXZhdGUgcnhTb2NrZXQ6IGRncmFtLlNvY2tldCAvLyBmb3IgcmVjZWl2aW5nIHJlc3BvbnNlcyAoODcwMilcblx0cHJpdmF0ZSBwZW5kaW5nQWNrczogTWFwPFxuXHRcdHN0cmluZyxcblx0XHR7IHJlc29sdmU6IChidWY6IEJ1ZmZlcikgPT4gdm9pZDsgcmVqZWN0OiAoZTogRXJyb3IpID0+IHZvaWQ7IHRpbWVyOiBOb2RlSlMuVGltZW91dCB9XG5cdD5cblx0cHJpdmF0ZSBqb2luZWRJbnRlcmZhY2VzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKSAvLyBsb2NhbCBJUHMgd2UndmUgam9pbmVkIG11bHRpY2FzdCBvblxuXG5cdC8qKiBSZXNvbHZlcyBvbmNlIHR4U29ja2V0IGlzIGJvdW5kIGFuZCByZWFkeSB0byBzZW5kICovXG5cdHByaXZhdGUgdHhSZWFkeTogUHJvbWlzZTx2b2lkPlxuXG5cdC8qKiBBY3RpdmUgZGV2aWNlIG1vZGVsIGFuZCBhY3Rpb24gZGVmaW5pdGlvbnMgZm9yIHNldHRpbmdzIGRlY29kaW5nICovXG5cdHByaXZhdGUgbW9kZWw6IHN0cmluZyA9ICcnXG5cdHByaXZhdGUgYWN0aW9uczogU3RBY3Rpb25bXSA9IFtdXG5cdHByaXZhdGUgcmVmcmVzaEFmdGVyQ29tbWFuZDogYm9vbGVhbiA9IHRydWUgLy8gRGVmYXVsdCB0byB0cnVlIChtb3N0IGRldmljZXMgbmVlZCBpdClcblxuXHQvKipcblx0ICogS25vd24gc3RhdGUgb2YgZXZlcnkgc2V0dGluZyBwZXIgZGV2aWNlIElQLlxuXHQgKiBLZXllZCBieSBJUCBcdTIxOTIgTWFwIG9mIFwiJHtjbWRJZH0vJHtzZXR0aW5nSWR9XCIgXHUyMTkyIGN1cnJlbnQgdmFsdWUgYnl0ZS5cblx0ICogUG9wdWxhdGVkIG9uIGNvbm5lY3QgdmlhIHJlcXVlc3RBbGxTZXR0aW5ncygpLCB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKS5cblx0ICogVXNlZCB0byBkaWZmIGluY29taW5nIHB1c2hlcyAoY2hhbmdlZCA9IGluZm8sIHVuY2hhbmdlZCA9IGRlYnVnKSBhbmQgZm9yIGZlZWRiYWNrcy5cblx0ICovXG5cdHByaXZhdGUgZGV2aWNlU3RhdGU6IE1hcDxzdHJpbmcsIE1hcDxzdHJpbmcsIG51bWJlcj4+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrcyByZWdpc3RlcmVkIGJ5IGRpc2NvdmVyRGV2aWNlcygpIFx1MjAxNCBrZXllZCBieSBzb3VyY2UgSVAgKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcnlMaXN0ZW5lcnM6IE1hcDxzdHJpbmcsIChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQ+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrIHRvIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlcyB3aGVuIHN0YXRlIGNoYW5nZXMgKi9cblx0cHJpdmF0ZSBmZWVkYmFja0NhbGxiYWNrPzogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZFxuXG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdGxvZ2dlci5pbmZvKCdTdENvbnRyb2xsZXIgaW5pdGlhbGl6ZWQnKVxuXG5cdFx0dGhpcy5wZW5kaW5nQWNrcyA9IG5ldyBNYXAoKVxuXG5cdFx0Ly8gU2VuZCBzb2NrZXQgXHUyMDE0IGJpbmQgdG8gZXBoZW1lcmFsIHBvcnQuIFJlc3BvbnNlcyBhbHdheXMgZ28gdG8gcnhTb2NrZXQgb25cblx0XHQvLyBwb3J0IDg3MDIgKERhbnRlIGhhcmRjb2RlcyB0aGUgcmVzcG9uc2UgZGVzdGluYXRpb24gcG9ydCB0byA4NzAyKS5cblx0XHR0aGlzLnR4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnR4UmVhZHkgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0dGhpcy50eFNvY2tldC5iaW5kKDAsICgpID0+IHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBUWCBzb2NrZXQgYm91bmQgdG8gcG9ydCAkeyh0aGlzLnR4U29ja2V0LmFkZHJlc3MoKSBhcyB7IHBvcnQ6IG51bWJlciB9KS5wb3J0fWApXG5cdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdHRoaXMudHhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBUWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdC8vIFJlY2VpdmUgc29ja2V0IC0gYmluZCB0byBhbGwgYWRkcmVzc2VzIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0c1xuXHRcdHRoaXMucnhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbGlzdGVuaW5nJywgKCkgPT4ge1xuXHRcdFx0Y29uc3QgYWRkciA9IHRoaXMucnhTb2NrZXQuYWRkcmVzcygpXG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBsaXN0ZW5pbmcgb24gJHtKU09OLnN0cmluZ2lmeShhZGRyKX1gKVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5zZXRNdWx0aWNhc3RMb29wYmFjayh0cnVlKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBSWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5oYW5kbGVJbmNvbWluZyhtc2csIHJpbmZvLmFkZHJlc3MpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoYEVycm9yIGhhbmRsaW5nIGluY29taW5nIG1lc3NhZ2U6ICR7X2V9YClcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gQmluZCB0byB3aWxkY2FyZCBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHMgZm9yIGpvaW5lZCBpbnRlcmZhY2VzXG5cdFx0dGhpcy5yeFNvY2tldC5iaW5kKHsgYWRkcmVzczogJzAuMC4wLjAnLCBwb3J0OiB0aGlzLnJ4UG9ydCB9LCAoKSA9PiB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBib3VuZCB0byAwLjAuMC4wOiR7dGhpcy5yeFBvcnR9YClcblx0XHR9KVxuXHR9XG5cblx0cHVibGljIGNsb3NlKCk6IHZvaWQge1xuXHRcdHRyeSB7XG5cdFx0XHRmb3IgKGNvbnN0IGxvY2FsQWRkciBvZiBBcnJheS5mcm9tKHRoaXMuam9pbmVkSW50ZXJmYWNlcykpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR0aGlzLnJ4U29ja2V0LmRyb3BNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy5yeFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFByb3ZpZGUgdGhlIGFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBzbyBpbmNvbWluZyBtZXNzYWdlc1xuXHQgKiBjYW4gYmUgZGVjb2RlZCBpbnRvIGh1bWFuLXJlYWRhYmxlIG5hbWVzLiBDYWxsIGZyb20gbWFpbi50cyBhZnRlciBjb25maWcgbG9hZC5cblx0ICovXG5cdHB1YmxpYyBzZXRNb2RlbChtb2RlbDogc3RyaW5nLCBhY3Rpb25zOiBTdEFjdGlvbltdLCByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xuXHRcdHRoaXMubW9kZWwgPSBtb2RlbFxuXHRcdHRoaXMuYWN0aW9ucyA9IGFjdGlvbnNcblx0XHR0aGlzLnJlZnJlc2hBZnRlckNvbW1hbmQgPSByZWZyZXNoQWZ0ZXJDb21tYW5kXG5cdH1cblxuXHQvKipcblx0ICogU2V0IGNhbGxiYWNrIHRvIHRyaWdnZXIgd2hlbiBkZXZpY2Ugc3RhdGUgY2hhbmdlcyAoZm9yIGZlZWRiYWNrcykuXG5cdCAqIENhbGwgZnJvbSBtYWluLnRzIHRvIHdpcmUgdXAgY2hlY2tGZWVkYmFja3MuXG5cdCAqL1xuXHRwdWJsaWMgc2V0RmVlZGJhY2tDYWxsYmFjayhjYWxsYmFjazogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZCk6IHZvaWQge1xuXHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayA9IGNhbGxiYWNrXG5cdH1cblxuXHQvKipcblx0ICogU2VuZCBhIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSByZXF1ZXN0IHRvIHRoZSBkZXZpY2UgYW5kIHN0b3JlIHRoZSByZXNwb25zZVxuXHQgKiBpbiBkZXZpY2VTdGF0ZS4gUmV0dXJucyB0aGUgcmF3IHJlc3BvbnNlIGJ1ZmZlciBmb3IgcGFyc2luZy5cblx0ICovXG5cdHB1YmxpYyBhc3luYyByZXF1ZXN0QWxsU2V0dGluZ3MoZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgYWxsIHNldHRpbmdzIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soXG5cdFx0XHR0aGlzLm1vZGVsLFxuXHRcdFx0Q01EX0dFVF9BTExfU0VUVElOR1MsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHRkZXZpY2VJcCxcblx0XHRcdGZhbHNlLFxuXHRcdClcblxuXHRcdC8vIERlYnVnOiBMb2cgdGhlIHJhdyByZXNwb25zZVxuXHRcdGNvbnNvbGUubG9nKCdSYXcgcmVzcG9uc2UgYnVmZmVyOicsIHJlc3BvbnNlLnRvU3RyaW5nKCdoZXgnKSlcblx0XHRjb25zb2xlLmxvZygnUmVzcG9uc2UgbGVuZ3RoOicsIHJlc3BvbnNlLmxlbmd0aClcblxuXHRcdC8vIFBhcnNlIGFuZCBzdG9yZSBpbiBkZXZpY2VTdGF0ZVxuXHRcdGNvbnN0IHBhcnNlZCA9IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCh0aGlzLm1vZGVsLCByZXNwb25zZSlcblx0XHRjb25zb2xlLmxvZygnUGFyc2VkIHNldHRpbmdzIGNvdW50OicsIHBhcnNlZC5sZW5ndGgpXG5cdFx0aWYgKHBhcnNlZC5sZW5ndGggPiAwKSB7XG5cdFx0XHRjb25zb2xlLmxvZygnRmlyc3QgZmV3IHNldHRpbmdzOicsIHBhcnNlZC5zbGljZSgwLCAzKSlcblx0XHR9XG5cblx0XHRjb25zdCBzdGF0ZU1hcCA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0XHRmb3IgKGNvbnN0IHNldHRpbmcgb2YgcGFyc2VkKSB7XG5cdFx0XHRjb25zdCBrZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIHNldHRpbmcuY21kX2lkLCBzZXR0aW5nLmlkLCBzZXR0aW5nLmJ1c0NoKVxuXHRcdFx0Ly8gRm9yIFJHQiBjb2xvcnMgKDMgYnl0ZXMpLCBwYWNrIGludG8gc2luZ2xlIG51bWJlcjogKFIgPDwgMTYpIHwgKEcgPDwgOCkgfCBCXG5cdFx0XHRjb25zdCB2YWx1ZSA9XG5cdFx0XHRcdHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdFx0XHQ/IChzZXR0aW5nLnZhbHVlQnl0ZXNbMF0gPDwgMTYpIHwgKHNldHRpbmcudmFsdWVCeXRlc1sxXSA8PCA4KSB8IHNldHRpbmcudmFsdWVCeXRlc1syXVxuXHRcdFx0XHRcdDogKHNldHRpbmcudmFsdWVCeXRlc1swXSA/PyAwKVxuXHRcdFx0c3RhdGVNYXAuc2V0KGtleSwgdmFsdWUpXG5cdFx0fVxuXHRcdHRoaXMuZGV2aWNlU3RhdGUuc2V0KGRldmljZUlwLCBzdGF0ZU1hcCkgLy8gUmV0dXJuIGJ1ZmZlciBmb3IgY2FsbGVyIHRvIHBhcnNlIGlmIG5lZWRlZFxuXHRcdHJldHVybiByZXNwb25zZVxuXHR9IC8qKiBSZXR1cm4gYSBzbmFwc2hvdCBvZiB0aGUgY3VycmVudCBkZXZpY2Ugc3RhdGUgZm9yIGEgZ2l2ZW4gSVAgKGZvciBmZWVkYmFja3MpLiAqL1xuXHRwdWJsaWMgZ2V0RGV2aWNlU3RhdGUoZGV2aWNlSXA6IHN0cmluZyk6IE1hcDxzdHJpbmcsIG51bWJlcj4ge1xuXHRcdHJldHVybiB0aGlzLmRldmljZVN0YXRlLmdldChkZXZpY2VJcCkgPz8gbmV3IE1hcCgpXG5cdH1cblxuXHQvKipcblx0ICogRGlzY292ZXJzIFN0dWRpbyBUZWNobm9sb2dpZXMgRGFudGUgZGV2aWNlcyBvbiB0aGUgbG9jYWwgbmV0d29yay5cblx0ICpcblx0ICogU3RyYXRlZ3k6XG5cdCAqICBEYW50ZSBkZXZpY2VzIGJyb2FkY2FzdCBhIDEtc2Vjb25kIGFubm91bmNlIHRvIG11bHRpY2FzdCAyMjQuMC4wLjIzMzo4NzA4LlxuXHQgKiAgV2UgbGlzdGVuIG9uIHRoYXQgZ3JvdXAsIGNvbGxlY3Qgc291cmNlIElQcywgdGhlbiBzZW5kIGEgdW5pY2FzdCBkZXZpY2UgaW5mb1xuXHQgKiAgcmVxdWVzdCAoMHgwMDIwKSB0byBlYWNoIG5ldyBJUCBvbiBwb3J0IDg3MDAuIFRoZSBkZXZpY2UgcmVzcG9uZHMgdG8gb3VyIElQXG5cdCAqICBvbiBwb3J0IDg3MDIgKHJ4U29ja2V0KSwgd2hlcmUgaGFuZGxlSW5jb21pbmcoKSBwaWNrcyBpdCB1cCBhbmQgZmlyZXMgdGhlXG5cdCAqICBkaXNjb3ZlcnlMaXN0ZW5lcnMgY2FsbGJhY2suXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgZGlzY292ZXJEZXZpY2VzKHRpbWVvdXRNcyA9IDUwMDApOiBQcm9taXNlPERldmljZUluZm9bXT4ge1xuXHRcdC8vIFJlZ2lzdGVyIGxpc3RlbmVyIFx1MjAxNCBoYW5kbGVJbmNvbWluZygpIGZpcmVzIHRoaXMgZm9yIGVhY2ggMHgwMTcwIHJlc3BvbnNlXG5cdFx0Y29uc3QgRElTQ09WRVJZX0tFWSA9ICdfX2Rpc2NvdmVyeV9fJ1xuXHRcdGNvbnN0IGZvdW5kRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHRcdGNvbnN0IG9uRGV2aWNlRm91bmQgPSAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB7XG5cdFx0XHRmb3VuZERldmljZXMucHVzaChkZXZpY2UpXG5cdFx0fVxuXG5cdFx0Ly8gUmVnaXN0ZXIgdGhlIGNhbGxiYWNrIHNvIGhhbmRsZUluY29taW5nKCkgY2FuIGludm9rZSBpdCB3aGVuIDB4MDE3MCBhcnJpdmVzXG5cdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KERJU0NPVkVSWV9LRVksIG9uRGV2aWNlRm91bmQpXG5cblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0XHQvLyBkaXNjb3ZlckRldmljZXMoKSBpbiBkYW50ZS50cyBoYW5kbGVzIHRoZSBhbm5vdW5jZSBsaXN0ZW5pbmcgYW5kIHF1ZXJ5IHNlbmRpbmdcblx0XHRcdC8vIFJlc3BvbnNlcyBjb21lIGJhY2sgdG8gcnhTb2NrZXQgXHUyMTkyIGhhbmRsZUluY29taW5nKCkgXHUyMTkyIGRpc2NvdmVyeUxpc3RlbmVyc1xuXHRcdFx0YXdhaXQgZGlzY292ZXJEZXZpY2VzKFxuXHRcdFx0XHR0aGlzLnR4U29ja2V0LFxuXHRcdFx0XHRvbkRldmljZUZvdW5kLCAvLyBkYW50ZS50cyBkb2Vzbid0IGFjdHVhbGx5IHVzZSB0aGlzLCBidXQga2VwdCBmb3IgY29tcGF0aWJpbGl0eVxuXHRcdFx0XHRhc3luYyAoZGVzdElwKSA9PiB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKSxcblx0XHRcdFx0dGltZW91dE1zLFxuXHRcdFx0KVxuXHRcdFx0cmV0dXJuIGZvdW5kRGV2aWNlc1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5kZWxldGUoRElTQ09WRVJZX0tFWSlcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogRW5zdXJlIHdlJ3ZlIGpvaW5lZCB0aGUgbXVsdGljYXN0IGdyb3VwIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gZGVzdElwLlxuXHQgKiBPcHRpb24gQiBiZWhhdmlvcjogam9pbiBPTkxZIHRoZSBpbnRlcmZhY2UgdXNlZCB0byByZWFjaCB0aGUgZGV2aWNlLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBlbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGF3YWl0IGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblx0XHRcdGlmICghbG9jYWxBZGRyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgZGV0ZXJtaW5lIGxvY2FsIGFkZHJlc3MgZm9yIGRlc3RpbmF0aW9uICR7ZGVzdElwfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAodGhpcy5qb2luZWRJbnRlcmZhY2VzLmhhcyhsb2NhbEFkZHIpKSB7XG5cdFx0XHRcdC8vIGFscmVhZHkgam9pbmVkXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLnJ4U29ja2V0LmFkZE1lbWJlcnNoaXAodGhpcy5tdWx0aWNhc3RHcm91cCwgbG9jYWxBZGRyKVxuXHRcdFx0XHR0aGlzLmpvaW5lZEludGVyZmFjZXMuYWRkKGxvY2FsQWRkcilcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEpvaW5lZCBtdWx0aWNhc3QgJHt0aGlzLm11bHRpY2FzdEdyb3VwfSBvbiAke2xvY2FsQWRkcn1gKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBqb2luIG11bHRpY2FzdCBvbiAke2xvY2FsQWRkcn06ICR7U3RyaW5nKF9lKX1gKVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRsb2dnZXIud2FybihgZW5zdXJlTWVtYmVyc2hpcEZvciBmYWlsZWQ6ICR7X2V9YClcblx0XHR9XG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgc2VuZEF3YWl0QWNrKFxuXHRcdG1vZGVsOiBzdHJpbmcsXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0Y29uc3QgdGltZW91dE1zID0gMjAwMFxuXG5cdFx0Ly8gRW5zdXJlIHdlIGFyZSBsaXN0ZW5pbmcgZm9yIHJlcGxpZXMgb24gdGhlIGludGVyZmFjZSB0aGF0IHdpbGwgcmVjZWl2ZSB0aGVtXG5cdFx0YXdhaXQgdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcClcblxuXHRcdGNvbnN0IGRhdGFCbG9jazogbnVtYmVyW10gPSBbXVxuXHRcdGlmIChzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCkgZGF0YUJsb2NrLnB1c2goc2V0dGluZ0lkICYgMHhmZilcblx0XHRpZiAodmFsdWUgIT09IHVuZGVmaW5lZCkgZGF0YUJsb2NrLnB1c2goLi4uU3RDb250cm9sbGVyLmJ1aWxkVmFsdWVCeXRlcyh2YWx1ZSkpXG5cblx0XHRjb25zdCBwYXlsb2FkQm9keTogbnVtYmVyW10gPSBbMHg1YSwgY21kSWQgJiAweGZmXVxuXG5cdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHBheWxvYWRCb2R5LnB1c2goYnVzQ2ggJiAweGZmKVxuXHRcdGlmIChhZGRMZW4pIHBheWxvYWRCb2R5LnB1c2goZGF0YUJsb2NrLmxlbmd0aClcblxuXHRcdGlmIChkYXRhQmxvY2subGVuZ3RoID4gMCkgcGF5bG9hZEJvZHkucHVzaCguLi5kYXRhQmxvY2spXG5cblx0XHRjb25zdCBjcmMgPSBTdENvbnRyb2xsZXIuY3JjOER2YlMyKHBheWxvYWRCb2R5KVxuXHRcdGNvbnN0IHBheWxvYWRXaXRoQ3JjID0gQnVmZmVyLmZyb20oWy4uLnBheWxvYWRCb2R5LCBjcmNdKVxuXG5cdFx0Y29uc3QgdG90YWxMZW4gPSAyNCArIHBheWxvYWRXaXRoQ3JjLmxlbmd0aFxuXHRcdGNvbnN0IGhlYWRlciA9IGF3YWl0IFN0Q29udHJvbGxlci5idWlsZEhlYWRlcih0b3RhbExlbiwgZGVzdElwKVxuXHRcdGNvbnN0IHBhY2tldCA9IEJ1ZmZlci5jb25jYXQoW2hlYWRlciwgcGF5bG9hZFdpdGhDcmNdKVxuXG5cdFx0Ly8gSHVtYW4tcmVhZGFibGUgaW5mbyBsb2cgZm9yIHRoZSBvdXRnb2luZyBjb21tYW5kXG5cdFx0Y29uc3QgY21kTmFtZSA9IGdldENvbW1hbmROYW1lKGNtZElkKVxuXHRcdGlmIChzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0XHRcdGxldCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblxuXHRcdFx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2gsIHRyeSB0byBmaW5kIGFjdGlvbiB3aXRoIGlkQWRkIG9wdGlvblxuXHRcdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdFx0YWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IHtcblx0XHRcdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZElkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRjb25zdCBoYXNJZEFkZCA9IGEub3B0aW9ucz8uc29tZSgob3B0KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdFx0aWYgKCFoYXNJZEFkZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0cmV0dXJuIHNldHRpbmdJZCA+PSBhLmlkICYmIHNldHRpbmdJZCA8IGEuaWQgKyAxMFxuXHRcdFx0XHR9KVxuXHRcdFx0fVxuXG5cdFx0XHRsZXQgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gJ1Vua25vd24gU2V0dGluZydcblxuXHRcdFx0Ly8gSWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkIGFuZCB0aGUgc2V0dGluZyBpZCBpcyBvZmZzZXQgZnJvbSBiYXNlLCBpbmNsdWRlIGNoYW5uZWwgaW5mb1xuXHRcdFx0aWYgKGFjdGlvbikge1xuXHRcdFx0XHRjb25zdCBoYXNJZEFkZCA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0aWYgKGhhc0lkQWRkICYmIHNldHRpbmdJZCAhPT0gYWN0aW9uLmlkKSB7XG5cdFx0XHRcdFx0Y29uc3QgY2hhbm5lbE9mZnNldCA9IHNldHRpbmdJZCAtIGFjdGlvbi5pZFxuXHRcdFx0XHRcdHNldHRpbmdOYW1lID0gYCR7c2V0dGluZ05hbWV9IENoJHtjaGFubmVsT2Zmc2V0ICsgMX1gXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Ly8gTG9vayBmb3IgdGhlIHZhbHVlIG9wdGlvbiB0byBnZXQgY2hvaWNlc1xuXHRcdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBhY3Rpb24/Lm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAndmFsdWUnKVxuXHRcdFx0Y29uc3QgY2hvaWNlcyA9IHZhbHVlT3B0aW9uPy5jaG9pY2VzXG5cdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gU3RDb250cm9sbGVyLmJ1aWxkVmFsdWVCeXRlcyh2YWx1ZSlcblx0XHRcdGNvbnN0IHZhbHVlTnVtID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdW5kZWZpbmVkXG5cdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9IGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXG5cdFx0XHRjb25zdCBjbWRIZXggPSBgMHgke2NtZElkLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfWBcblx0XHRcdGNvbnN0IGlkSGV4ID0gYDB4JHtzZXR0aW5nSWQudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9YFxuXHRcdFx0Y29uc3QgdmFsSGV4ID0gYDB4JHt2YWx1ZUJ5dGVzLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSkuam9pbignJyl9YFxuXHRcdFx0Y29uc3QgdmFsRGVjID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdmFsdWVCeXRlcy5qb2luKCcsJylcblxuXHRcdFx0Y29uc3QgcHJlZml4ID0gYGNtZDoke2NtZEhleH0gaWQ6JHtpZEhleH0gdmFsOiR7dmFsSGV4fWBcblx0XHRcdGNvbnN0IHN1ZmZpeCA9IGNob2ljZUxhYmVsID8gYCR7c2V0dGluZ05hbWV9OiAke2Nob2ljZUxhYmVsfSAoJHt2YWxEZWN9KWAgOiBgJHtzZXR0aW5nTmFtZX06ICR7dmFsRGVjfWBcblxuXHRcdFx0bG9nZ2VyLmluZm8oYFRYICR7ZGVzdElwfSB8ICR7cHJlZml4fSB8ICR7c3VmZml4fWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBUWCAke2Rlc3RJcH0gfCAke2NtZE5hbWV9YClcblx0XHR9XG5cdFx0bG9nZ2VyLmRlYnVnKGBTZW5kaW5nIHBhY2tldCB0byAke2Rlc3RJcH06ICR7cGFja2V0LnRvU3RyaW5nKCdoZXgnKX1gKVxuXG5cdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cblx0XHRjb25zdCBrZXkgPSBgJHtkZXN0SXB9OiR7Y21kSWR9YFxuXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPEJ1ZmZlcj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGBUaW1lb3V0IHdhaXRpbmcgZm9yIEFDSyBmcm9tIE1vZGVsJHttb2RlbH0gYXQgJHtkZXN0SXB9Ojg3MDBgKSlcblx0XHRcdH0sIHRpbWVvdXRNcylcblxuXHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5zZXQoa2V5LCB7XG5cdFx0XHRcdHJlc29sdmU6IChidWYpID0+IHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cblx0XHRcdFx0XHQvLyBJZiBkZXZpY2UgcmVxdWlyZXMgcmVmcmVzaCBhZnRlciBjb21tYW5kLCByZXF1ZXN0IGFsbCBzZXR0aW5ncyAobm9uLWJsb2NraW5nKVxuXHRcdFx0XHRcdGlmICh0aGlzLnJlZnJlc2hBZnRlckNvbW1hbmQgJiYgc2V0dGluZ0lkICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdHRoaXMucmVxdWVzdEFsbFNldHRpbmdzKGRlc3RJcCkuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0cmVzb2x2ZShidWYpXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHJlamVjdDogKGVycikgPT4ge1xuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZWplY3QoZXJyKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHR0aW1lcixcblx0XHRcdH0pXG5cblx0XHRcdHRoaXMudHhTb2NrZXQuc2VuZChwYWNrZXQsIHRoaXMuZGVmYXVsdFBvcnQsIGRlc3RJcCwgKGVycikgPT4ge1xuXHRcdFx0XHRpZiAoZXJyKSB7XG5cdFx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHRcdFx0fVxuXHRcdFx0fSlcblx0XHR9KVxuXHR9XG5cblx0cHJpdmF0ZSBoYW5kbGVJbmNvbWluZyhtc2c6IEJ1ZmZlciwgc3JjSXA6IHN0cmluZykge1xuXHRcdGlmIChtc2cubGVuZ3RoIDwgNCkgcmV0dXJuXG5cdFx0aWYgKG1zZ1swXSAhPT0gMHhmZiB8fCBtc2dbMV0gIT09IDB4ZmYpIHJldHVyblxuXG5cdFx0Y29uc3QgbXNnVHlwZSA9IG1zZy5yZWFkVUludDE2QkUoMilcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSAoMHgwMTcwKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBUaGVzZSBoYXZlIFwiQXVkaW5hdGVcIiBhdCBvZmZzZXQgMTYsIG5vdCBcIlN0dWRpby1UXCIgXHUyMDE0IGhhbmRsZSBiZWZvcmVcblx0XHQvLyB0aGUgU3R1ZGlvLVQgc2lnbmF0dXJlIGNoZWNrIGJlbG93LlxuXHRcdGlmIChtc2dUeXBlID09PSBEQU5URV9NU0dfSU5GT19SRVNQT05TRSAmJiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5zaXplID4gMCkge1xuXHRcdFx0Y29uc3QgZGV2aWNlID0gcGFyc2VEYW50ZUluZm9SZXNwb25zZShtc2csIHNyY0lwKVxuXHRcdFx0aWYgKGRldmljZSkge1xuXHRcdFx0XHRmb3IgKGNvbnN0IGNiIG9mIHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnZhbHVlcygpKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdGNiKGRldmljZSlcblx0XHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKG1zZy5sZW5ndGggPCAyNSkgcmV0dXJuXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgY29udHJvbCBwcm90b2NvbCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBzaWcgPSBtc2cuc3ViYXJyYXkoMTYsIDI0KVxuXHRcdGlmIChzaWcudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdTdHVkaW8tVCcpIHJldHVyblxuXG5cdFx0Ly8gUGF5bG9hZCBzdGFydHMgYXQgb2Zmc2V0IDI0XG5cdFx0Ly8gTGF5b3V0OiBbMHg1YV0gW2NtZElkfDB4ODBdIFtkYXRhLi4uXSBbY3JjXVxuXHRcdGNvbnN0IHN0UGF5bG9hZCA9IG1zZy5zdWJhcnJheSgyNClcblx0XHRpZiAoc3RQYXlsb2FkLmxlbmd0aCA8IDIpIHJldHVyblxuXHRcdGlmIChzdFBheWxvYWRbMF0gIT09IDB4NWEpIHJldHVyblxuXG5cdFx0Ly8gRGV2aWNlIHJlcGxpZXMgd2l0aCBjbWQgfCAweDgwXG5cdFx0Y29uc3QgcmVzcENtZElkID0gc3RQYXlsb2FkWzFdXG5cdFx0Y29uc3QgaXNSZXNwb25zZSA9IChyZXNwQ21kSWQgJiAweDgwKSAhPT0gMFxuXHRcdGNvbnN0IG9yaWdpbmFsQ21kSWQgPSByZXNwQ21kSWQgJiAweDdmIC8vIHN0cmlwIHRoZSByZXNwb25zZSBmbGFnXG5cblx0XHQvLyBMb2cgdGhlIHBheWxvYWQgKHdvcmtzIGZvciBib3RoIHJlcXVlc3RzIGFuZCByZXNwb25zZXMpXG5cdFx0dGhpcy5sb2dTdFBheWxvYWQoc3JjSXAsIG9yaWdpbmFsQ21kSWQsIG1zZywgc3RQYXlsb2FkLCBpc1Jlc3BvbnNlKVxuXG5cdFx0Ly8gT25seSBwcm9jZXNzIGFzIEFDSyBpZiB0aGlzIGlzIGEgcmVzcG9uc2UgdG8gb3VyIHJlcXVlc3Rcblx0XHRpZiAoaXNSZXNwb25zZSkge1xuXHRcdFx0Y29uc3Qga2V5ID0gYCR7c3JjSXB9OiR7b3JpZ2luYWxDbWRJZH1gXG5cdFx0XHRjb25zdCBwZW5kaW5nID0gdGhpcy5wZW5kaW5nQWNrcy5nZXQoa2V5KVxuXHRcdFx0aWYgKHBlbmRpbmcpIHtcblx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRwZW5kaW5nLnJlc29sdmUobXNnKVxuXHRcdFx0fVxuXHRcdH1cblx0XHQvLyBVbnNvbGljaXRlZCBtZXNzYWdlcyBhbmQgcmVxdWVzdHMgZnJvbSBvdGhlciBzb3VyY2VzIGFyZSBsb2dnZWQgYWJvdmVcblx0fVxuXG5cdC8qKlxuXHQgKiBEZWNvZGVzIGFuZCBsb2dzIGEgU3R1ZGlvLVQgcmVzcG9uc2UgcGF5bG9hZC5cblx0ICogUmVjZWl2ZXMgYm90aCB0aGUgZnVsbCBtc2cgKGZvciBwYXJzZXJzIHRoYXQgbmVlZCB0aGUgU3R1ZGlvLVQgaGVhZGVyKVxuXHQgKiBhbmQgc3RQYXlsb2FkIChtc2cuc3ViYXJyYXkoMjQpLCBmb3IgZGlyZWN0IGJ5dGUgYWNjZXNzKS5cblx0ICpcblx0ICogc3RQYXlsb2FkIGxheW91dDpcblx0ICogICBbMF0gICAgICAweDVhICBtYWdpY1xuXHQgKiAgIFsxXSAgICAgIGNtZElkIHwgMHg4MFxuXHQgKiAgIFsyLi4tMl0gIGRhdGEgYnl0ZXNcblx0ICogICBbLTFdICAgICBDUkMtOC9EVkItUzJcblx0ICovXG5cdHByaXZhdGUgbG9nU3RQYXlsb2FkKHNyY0lwOiBzdHJpbmcsIGNtZElkOiBudW1iZXIsIG1zZzogQnVmZmVyLCBzdFBheWxvYWQ6IEJ1ZmZlciwgaXNSZXNwb25zZSA9IHRydWUpOiB2b2lkIHtcblx0XHRjb25zdCBjbWROYW1lID0gYGNtZF8weCR7Y21kSWQudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9YFxuXHRcdGNvbnN0IGRhdGEgPSBzdFBheWxvYWQuc3ViYXJyYXkoMiwgc3RQYXlsb2FkLmxlbmd0aCAtIDEpIC8vIHN0cmlwIG1hZ2ljK2NtZElkIGhlYWRlciBhbmQgQ1JDXG5cblx0XHQvLyBTaG93IGNvbXBsZXRlIHBheWxvYWQgc3RydWN0dXJlOiBbMHg1YV0gW2NtZElkfDB4ODBdIFtkYXRhIGJ5dGVzLi4uXSBbY3JjXVxuXHRcdGNvbnN0IG1hZ2ljID0gc3RQYXlsb2FkWzBdXG5cdFx0Y29uc3QgcmVzcENtZElkID0gc3RQYXlsb2FkWzFdXG5cdFx0Y29uc3QgY3JjID0gc3RQYXlsb2FkW3N0UGF5bG9hZC5sZW5ndGggLSAxXVxuXHRcdGNvbnN0IGZ1bGxTdHJ1Y3R1cmUgPSBgW21hZ2ljOjB4JHttYWdpYy50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX0gY21kOjB4JHtyZXNwQ21kSWQudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9IGRhdGE6JHtkYXRhLnRvU3RyaW5nKCdoZXgnKX0gY3JjOjB4JHtjcmMudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9XWBcblxuXHRcdC8vIERldGVybWluZSBkaXJlY3Rpb24gcHJlZml4XG5cdFx0Y29uc3QgZGlyZWN0aW9uID0gaXNSZXNwb25zZSA/ICdSWCcgOiAnU05JRkYnXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIGFuZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gUGFyc2UgYWxsIHNldHRpbmdzLCBkaWZmIGFnYWluc3QgZGV2aWNlU3RhdGUsIGxvZyBjaGFuZ2VkIGF0IGluZm8gLyB1bmNoYW5nZWQgYXQgZGVidWcsXG5cdFx0Ly8gdGhlbiB1cGRhdGUgZGV2aWNlU3RhdGUuIENNRF9HRVRfQUxMX1NFVFRJTkdTIGFsc28gc2VydmVzIGFzIHRoZSBpbml0aWFsIHN0YXRlIHBvcHVsYXRpb24gb24gY29ubmVjdC5cblx0XHRpZiAoY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTIHx8IGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0aWYgKCF0aGlzLm1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ3MgPVxuXHRcdFx0XHRcdGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSFxuXHRcdFx0XHRcdFx0PyBwYXJzZVNldHRpbmdzUmVzcG9uc2UodGhpcy5tb2RlbCwgbXNnKVxuXHRcdFx0XHRcdFx0OiBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwodGhpcy5tb2RlbCwgbXNnKVxuXG5cdFx0XHRcdGNvbnN0IHByZXZTdGF0ZSA9IHRoaXMuZGV2aWNlU3RhdGUuZ2V0KHNyY0lwKSA/PyBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpXG5cdFx0XHRcdGNvbnN0IG5ld1N0YXRlID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4ocHJldlN0YXRlKSAvLyBjb3B5IFx1MjAxNCB1cGRhdGUgaW4gcGxhY2VcblxuXHRcdFx0XHRmb3IgKGNvbnN0IHMgb2Ygc2V0dGluZ3MpIHtcblx0XHRcdFx0XHRjb25zdCBzdGF0ZUtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgcy5jbWRfaWQsIHMuaWQsIHMuYnVzQ2gpXG5cdFx0XHRcdFx0Ly8gRm9yIFJHQiBjb2xvcnMgKDMgYnl0ZXMpLCBwYWNrIGludG8gc2luZ2xlIG51bWJlcjogKFIgPDwgMTYpIHwgKEcgPDwgOCkgfCBCXG5cdFx0XHRcdFx0Y29uc3QgbmV3VmFsdWUgPVxuXHRcdFx0XHRcdFx0cy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0XHRcdFx0XHQ/IChzLnZhbHVlQnl0ZXNbMF0gPDwgMTYpIHwgKHMudmFsdWVCeXRlc1sxXSA8PCA4KSB8IHMudmFsdWVCeXRlc1syXVxuXHRcdFx0XHRcdFx0XHQ6IChzLnZhbHVlQnl0ZXNbMF0gPz8gMClcblx0XHRcdFx0XHRjb25zdCBwcmV2VmFsdWUgPSBwcmV2U3RhdGUuZ2V0KHN0YXRlS2V5KVxuXHRcdFx0XHRcdGNvbnN0IGNoYW5nZWQgPSBwcmV2VmFsdWUgIT09IHVuZGVmaW5lZCAmJiBwcmV2VmFsdWUgIT09IG5ld1ZhbHVlXG5cblx0XHRcdFx0XHRuZXdTdGF0ZS5zZXQoc3RhdGVLZXksIG5ld1ZhbHVlKVxuXG5cdFx0XHRcdFx0Y29uc3QgZm9ybWF0dGVkID0gZm9ybWF0UGFyc2VkU2V0dGluZyhzLCB0aGlzLmFjdGlvbnMpXG5cdFx0XHRcdFx0aWYgKGNoYW5nZWQpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5pbmZvKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdFx0Ly8gVHJpZ2dlciBmZWVkYmFjayB1cGRhdGUgZm9yIHRoaXMgc2V0dGluZ1xuXHRcdFx0XHRcdFx0aWYgKHRoaXMuZmVlZGJhY2tDYWxsYmFjaykge1xuXHRcdFx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soc3RhdGVLZXkpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgJHtkaXJlY3Rpb259ICR7c3JjSXB9IHwgJHtmb3JtYXR0ZWR9YClcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy5kZXZpY2VTdGF0ZS5zZXQoc3JjSXAsIG5ld1N0YXRlKVxuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgJHtkaXJlY3Rpb259ICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8IHBhcnNlIGZhaWxlZDogJHtlfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIEFsbCBvdGhlciBjb21tYW5kcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBkZWNvZGVkID0gdGhpcy5kZWNvZGVTdERhdGEoY21kSWQsIGRhdGEpXG5cdFx0aWYgKGRlY29kZWQpIHtcblx0XHRcdGxvZ2dlci5pbmZvKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfSB8ICR7ZGVjb2RlZH1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgJHtkaXJlY3Rpb259ICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBBdHRlbXB0cyB0byBkZWNvZGUgdGhlIGRhdGEgYnl0ZXMgb2YgYSBTdHVkaW8tVCByZXNwb25zZSBpbnRvIGFcblx0ICogaHVtYW4tcmVhZGFibGUgc3RyaW5nLiBSZXR1cm5zIG51bGwgdG8gZmFsbCBiYWNrIHRvIHJhdyBoZXguXG5cdCAqXG5cdCAqIG1zZyBpcyB0aGUgZnVsbCBwYWNrZXQgYnVmZmVyIFx1MjAxNCByZXF1aXJlZCBieSB0aGUgc2V0dGluZ3MgcGFyc2VycyB3aGljaFxuXHQgKiBsb2NhdGUgdGhlIFN0dWRpby1UIHNpZ25hdHVyZSB0aGVtc2VsdmVzLlxuXHQgKi9cblx0cHJpdmF0ZSBkZWNvZGVTdERhdGEoY21kSWQ6IG51bWJlciwgZGF0YTogQnVmZmVyKTogc3RyaW5nIHwgbnVsbCB7XG5cdFx0aWYgKGRhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gJ0FDSydcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDaGVjayBmb3Igc2luZ2xlLWJ5dGUgcmVzcG9uc2VzIChBQ0sgb3IgZXJyb3IpIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0aWYgKGRhdGFbMF0gPT09IDB4MDApIHtcblx0XHRcdFx0cmV0dXJuICdBQ0sgb2snXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRyZXR1cm4gYEVSUk9SIDB4JHtkYXRhWzBdLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfWBcblx0XHRcdH1cblx0XHR9XG5cblx0XHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0RFVl9TUEVDICgweDBkKTogc2luZ2xlLWJ5dGUgQUNLIG9yIGVjaG8gb2YgYXBwbGllZCBzZXR0aW5nIFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gRGV2aWNlIHNlbmRzIHR3byBDTURfREVWX1NQRUMgcGFja2V0cyBpbiByZXNwb25zZSB0byBhIHNldDpcblx0XHRcdC8vICAgMS4gQUNLOiAgW3N0YXR1c10gICAgICAgICAgICAgICAoMSBieXRlLCAweDAwID0gb2spXG5cdFx0XHQvLyAgIDIuIEVjaG86IFtidXNDaF0gW3NldHRpbmdJZF0gW3ZhbHVlLi4uXSAgKGNvbmZpcm1pbmcgd2hhdCB3YXMgYXBwbGllZClcblx0XHRcdGNhc2UgQ01EX0RFVl9TUEVDOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0XHRcdHJldHVybiBkYXRhWzBdID09PSAweDAwID8gJ0FDSyBvaycgOiBgQUNLIGVycj0weCR7ZGF0YVswXS50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID49IDMpIHtcblx0XHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0XHRjb25zdCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyBgc2V0dGluZz0weCR7c2V0dGluZ0lkLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfWBcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VzID0gYWN0aW9uPy5vcHRpb25zPy5bMF0/LmNob2ljZXNcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID1cblx0XHRcdFx0XHRcdGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlU3RyID0gY2hvaWNlTGFiZWxcblx0XHRcdFx0XHRcdD8gYCR7Y2hvaWNlTGFiZWx9ICgweCR7dmFsdWVOdW0hLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfSlgXG5cdFx0XHRcdFx0XHQ6IGAweCR7QXJyYXkuZnJvbSh2YWx1ZUJ5dGVzKVxuXHRcdFx0XHRcdFx0XHRcdC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0XHRcdFx0XHRcdFx0LmpvaW4oJycpfWBcblx0XHRcdFx0XHRjb25zdCByYXdUYWcgPSBgWzB4JHtjbWRJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX0vMHgke3NldHRpbmdJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1dPTB4JHtBcnJheS5mcm9tKFxuXHRcdFx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0XHQubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuXHRcdFx0XHRcdFx0LmpvaW4oJycpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn0gJHtyYXdUYWd9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBgcmF3OiAke2RhdGEudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9NSUNfUFJFX0JVUyAoMHgxMik6IE11bHRpLWJ5dGUgZWNobyByZXNwb25zZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzoge1xuXHRcdFx0XHQvLyBBbHJlYWR5IGhhbmRsZWQgc2luZ2xlLWJ5dGUgYWJvdmUsIHNvIG11bHRpLWJ5dGUgbXVzdCBiZSBlY2hvXG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9MHgke3NldHRpbmdJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VzID0gYWN0aW9uPy5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID1cblx0XHRcdFx0XHRcdGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlU3RyID0gY2hvaWNlTGFiZWwgPz8gYDB4JHt2YWx1ZUJ5dGVzLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBudWxsXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBCdXMtc2NvcGVkIGdldC9zZXQgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0Y2FzZSBDTURfQlVTX1NFVDoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPCAyKSByZXR1cm4gbnVsbFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0cmV0dXJuIGBjaD0ke2J1c0NofSBzZXR0aW5nPTB4JHtzZXR0aW5nSWQudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9IHZhbHVlPSR7dmFsdWUudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0cmV0dXJuIG51bGwgLy8gZmFsbCB0aHJvdWdoIHRvIHJhdyBoZXhcblx0XHR9XG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBidWlsZFZhbHVlQnl0ZXModmFsdWU6IHVua25vd24pOiBudW1iZXJbXSB7XG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gW3ZhbHVlID8gMSA6IDBdXG5cdFx0aWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSByZXR1cm4gdmFsdWUubWFwKCh2KSA9PiBOdW1iZXIodikgJiAweGZmKVxuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG5cdFx0XHRpZiAodmFsdWUgPiAweGZmKSByZXR1cm4gWyh2YWx1ZSA+PiAxNikgJiAweGZmLCAodmFsdWUgPj4gOCkgJiAweGZmLCB2YWx1ZSAmIDB4ZmZdXG5cdFx0XHRyZXR1cm4gW3ZhbHVlICYgMHhmZl1cblx0XHR9XG5cdFx0dGhyb3cgbmV3IEVycm9yKGBVbnN1cHBvcnRlZCB2YWx1ZSB0eXBlIGZvciBTVGNvbnRyb2xsZXI6ICR7dmFsdWV9YClcblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGFzeW5jIGdldE1hY0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxudW1iZXJbXT4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxudW1iZXJbXT4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHRcdH0pXG5cblx0XHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3NcblxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cblx0XHRcdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0XHRcdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdFx0XHRcdGZvciAoY29uc3QgaWZhY2Ugb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChcblx0XHRcdFx0XHRcdFx0XHRpZmFjZS5mYW1pbHkgPT09ICdJUHY0JyAmJlxuXHRcdFx0XHRcdFx0XHRcdGlmYWNlLmFkZHJlc3MgPT09IGxvY2FsQWRkciAmJlxuXHRcdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAmJlxuXHRcdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAhPT0gJzAwOjAwOjAwOjAwOjAwOjAwJ1xuXHRcdFx0XHRcdFx0XHQpIHtcblx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gcmVzb2x2ZShpZmFjZS5tYWMuc3BsaXQoJzonKS5tYXAoKGIpID0+IHBhcnNlSW50KGIsIDE2KSAmIDB4ZmYpKVxuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgTm8gaW50ZXJmYWNlIGZvdW5kIGZvciBsb2NhbCBhZGRyZXNzICR7bG9jYWxBZGRyfWApKVxuXHRcdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoU3RyaW5nKF9lKSkpXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGFzeW5jIGJ1aWxkSGVhZGVyKHRvdGFsTGVuOiBudW1iZXIsIGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRjb25zdCBtYWMgPSBhd2FpdCBTdENvbnRyb2xsZXIuZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwKVxuXG5cdFx0cmV0dXJuIEJ1ZmZlci5jb25jYXQoW1xuXHRcdFx0QnVmZmVyLmZyb20oWzB4ZmYsIDB4ZmYsIDB4MDAsIHRvdGFsTGVuICYgMHhmZiwgMHgwNywgMHhlMSwgMHgwMCwgMHgwMCwgLi4ubWFjLCAweDAwLCAweDAwXSksXG5cdFx0XHRCdWZmZXIuZnJvbSgnU3R1ZGlvLVQnLCAndXRmOCcpLFxuXHRcdF0pXG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBjcmM4RHZiUzIoZGF0YTogbnVtYmVyW10pOiBudW1iZXIge1xuXHRcdGxldCBjcmMgPSAwXG5cdFx0Zm9yIChjb25zdCBiIG9mIGRhdGEpIHtcblx0XHRcdGNyYyBePSBiXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IDg7IGkrKykge1xuXHRcdFx0XHRjcmMgPSAoY3JjICYgMHg4MCkgIT09IDAgPyAoKGNyYyA8PCAxKSBeIDB4ZDUpICYgMHhmZiA6IChjcmMgPDwgMSkgJiAweGZmXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBjcmNcblx0fVxuXG5cdC8qKlxuXHQgKiBSZXR1cm5zIHRoZSBjdXJyZW50IGtub3duIHZhbHVlIGZvciBhIHNldHRpbmcgb24gYSBkZXZpY2UsIG9yIHVuZGVmaW5lZCBpZiB1bmtub3duLlxuXHQgKiBVc2UgZm9yIGZlZWRiYWNrcyBcdTIwMTQgdmFsdWUgaXMgdXBkYXRlZCBvbiBldmVyeSBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgZnJvbSB0aGUgZGV2aWNlLlxuXHQgKlxuXHQgKiBAcGFyYW0gaXAgICAgICAgIERldmljZSBJUCBhZGRyZXNzXG5cdCAqIEBwYXJhbSBjbWRJZCAgICAgQ29tbWFuZCBJRCAoZS5nLiBDTURfREVWX1NQRUMpXG5cdCAqIEBwYXJhbSBzZXR0aW5nSWQgU2V0dGluZyBJRCAoZS5nLiAweDAyIGZvciBDb250cm9sIFNvdXJjZSlcblx0ICogQHBhcmFtIGJ1c0NoICAgICBPcHRpb25hbCBidXMvY2hhbm5lbCBJRCBmb3IgbXVsdGktY2hhbm5lbCBjb21tYW5kc1xuXHQgKi9cblx0cHVibGljIGdldFNldHRpbmdWYWx1ZShpcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBzZXR0aW5nSWQ6IG51bWJlciwgYnVzQ2g/OiBudW1iZXIpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuXHRcdGNvbnN0IGtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cdFx0cmV0dXJuIHRoaXMuZGV2aWNlU3RhdGUuZ2V0KGlwKT8uZ2V0KGtleSlcblx0fVxuXG5cdHB1YmxpYyBhc3luYyByZXNldERldmljZShtb2RlbDogc3RyaW5nLCBkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKG1vZGVsLCBDTURfUkVTRVRfREVWSUNFLCB1bmRlZmluZWQsIDB4MDAsIHVuZGVmaW5lZCwgZGVzdElwLCBmYWxzZSlcblx0fVxuXG5cdHB1YmxpYyBhc3luYyBnbG9iYWxNaWNLaWxsKG1vZGVsOiBzdHJpbmcsIGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5zZW5kQXdhaXRBY2sobW9kZWwsIENNRF9HTE9CQUxfTUlDX0tJTEwsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdEYW50ZScpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBEYW50ZSBkaXNjb3ZlcnkgY29uc3RhbnRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBtZXNzYWdlIHR5cGUgKHNlbnQgdG8gcG9ydCA4NzAwKSAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX01TR19JTkZPX1JFUVVFU1QgPSAweDAwMjBcbi8qKiBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSBtZXNzYWdlIHR5cGUgKHJlY2VpdmVkIG9uIHBvcnQgODcwMikgKi9cbmV4cG9ydCBjb25zdCBEQU5URV9NU0dfSU5GT19SRVNQT05TRSA9IDB4MDE3MFxuXG4vKipcbiAqIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlIGxheW91dCAoYWxsIG9mZnNldHMgYXJlIGludG8gdGhlIFVEUCBwYXlsb2FkKTpcbiAqICAgMHgwMCAgdWludDE2QkUgIE1hZ2ljICgweGZmZmYpXG4gKiAgIDB4MDIgIHVpbnQxNkJFICBNZXNzYWdlIHR5cGUgKDB4MDE3MClcbiAqICAgMHgwNCAgdWludDE2QkUgIFNlcXVlbmNlIG51bWJlclxuICogICAweDA2ICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDA4ICA4IGJ5dGVzICAgRVVJLTY0IChzb3VyY2UgTUFDIHdpdGggZmY6ZmUgaW5zZXJ0ZWQgbWlkKVxuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIEFTQ0lJIGlkZW50aWZpZXJcbiAqICAgMHgxOCAgMiBieXRlcyAgIERhbnRlIGZpcm13YXJlIHZlcnNpb24gKG1ham9yLCBtaW5vcilcbiAqICAgMHgyMCAgMTQgYnl0ZXMgIERldmljZSBuYW1lLCBudWxsLXBhZGRlZCBBU0NJSVxuICogICAweDJlICB1aW50MTZCRSAgUHJvZHVjdCBJRFxuICogICAweDRjICA2NCBieXRlcyAgTWFudWZhY3R1cmVyIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqICAgMHhjYyAgNjQgYnl0ZXMgIE1vZGVsIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX0lORk9fTUlOX0xFTiA9IDB4Y2MgKyA2NCAvLyAyNjggYnl0ZXMgXHUyMDE0IG5lZWQgZnVsbCBtb2RlbCBmaWVsZFxuXG4vKipcbiAqIEJ1aWxkcyBhIERhbnRlIGRldmljZSBpbmZvIHJlcXVlc3QgcGFja2V0ICh0eXBlIDB4MDAyMCkuXG4gKlxuICogUGFja2V0IGxheW91dCAoMzIgYnl0ZXMpIFx1MjAxNCBkZXJpdmVkIGZyb20gbGl2ZSBjYXB0dXJlIGFuYWx5c2lzOlxuICogICAweDAwICB1aW50MTZCRSAgTWFnaWMgKDB4ZmZmZilcbiAqICAgMHgwMiAgdWludDE2QkUgIE1lc3NhZ2UgdHlwZSAoMHgwMDIwID0gZGV2aWNlIGluZm8gcmVxdWVzdClcbiAqICAgMHgwNCAgdWludDE2QkUgIFNlcXVlbmNlIG51bWJlciAocmFuZG9tKVxuICogICAweDA2ICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDA4ICA2IGJ5dGVzICAgU291cmNlIE1BQ1xuICogICAweDBlICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIEFTQ0lJIGlkZW50aWZpZXJcbiAqICAgMHgxOCAgMiBieXRlcyAgIFByb3RvY29sIHZlcnNpb24gKDB4MDczOSlcbiAqICAgMHgxYSAgMiBieXRlcyAgIFN1Yi10eXBlICgweDAwYzEpXG4gKiAgIDB4MWMgIHVpbnQzMkJFICBDYXBhYmlsaXR5IG1hc2sgKDB4MDAwZjQyNDApXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidWlsZERhbnRlSW5mb1JlcXVlc3QoKTogQnVmZmVyIHtcblx0Y29uc3QgYnVmID0gQnVmZmVyLmFsbG9jKDMyLCAwKVxuXHRjb25zdCBzZXEgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAweGZmZmYpXG5cblx0YnVmLndyaXRlVUludDE2QkUoMHhmZmZmLCAwKVxuXHRidWYud3JpdGVVSW50MTZCRShEQU5URV9NU0dfSU5GT19SRVFVRVNULCAyKVxuXHRidWYud3JpdGVVSW50MTZCRShzZXEsIDQpXG5cblx0Y29uc3QgbWFjID0gZ2V0Rmlyc3RMb2NhbE1hYygpXG5cdG1hYy5jb3B5KGJ1ZiwgOClcblxuXHRCdWZmZXIuZnJvbSgnQXVkaW5hdGUnLCAnYXNjaWknKS5jb3B5KGJ1ZiwgMTYpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4MDczOSwgMjQpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4MDBjMSwgMjYpXG5cdGJ1Zi53cml0ZVVJbnQzMkJFKDB4MDAwZjQyNDAsIDI4KVxuXG5cdHJldHVybiBidWZcbn1cblxuLyoqIFJldHVybnMgdGhlIGZpcnN0IG5vbi1sb29wYmFjayBNQUMgYXMgYSA2LWJ5dGUgQnVmZmVyLCBvciB6ZXJvcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRGaXJzdExvY2FsTWFjKCk6IEJ1ZmZlciB7XG5cdHRyeSB7XG5cdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRmb3IgKGNvbnN0IGFkZHIgb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdGlmICghYWRkci5pbnRlcm5hbCAmJiBhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmIGFkZHIubWFjICYmIGFkZHIubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnKSB7XG5cdFx0XHRcdFx0cmV0dXJuIEJ1ZmZlci5mcm9tKGFkZHIubWFjLnNwbGl0KCc6JykubWFwKChoOiBzdHJpbmcpID0+IHBhcnNlSW50KGgsIDE2KSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH0gY2F0Y2gge1xuXHRcdC8qIGlnbm9yZSAqL1xuXHR9XG5cdHJldHVybiBCdWZmZXIuYWxsb2MoNiwgMClcbn1cblxuLyoqXG4gKiBQYXJzZXMgYSBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSAodHlwZSAweDAxNzApIGludG8gYSBEZXZpY2VJbmZvLlxuICpcbiAqIFJlc3BvbnNlIGxheW91dCAoa2V5IG9mZnNldHMpOlxuICogICAweDA4ICA4IGJ5dGVzICAgRVVJLTY0IFx1MjAxNCBjb252ZXJ0IHRvIE1BQyBieSBkcm9wcGluZyBieXRlcyBbM10gYW5kIFs0XSAoZmY6ZmUpXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgaWRlbnRpZmllciAodXNlZCB0byB2ZXJpZnkgdGhpcyBpcyBhIHJlYWwgcmVzcG9uc2UpXG4gKiAgIDB4MTggIDEgYnl0ZSAgICBEYW50ZSBGVyBtYWpvclxuICogICAweDE5ICAxIGJ5dGUgICAgRGFudGUgRlcgbWlub3JcbiAqICAgMHgyMCAgMTQgYnl0ZXMgIERldmljZSBuYW1lIChEYW50ZSBsYWJlbCwgdXNlci1jb25maWd1cmFibGUpLCBudWxsLXBhZGRlZCBBU0NJSVxuICogICAweDJlICB1aW50MTZCRSAgUHJvZHVjdCBJRFxuICogICAweDRjICA2NCBieXRlcyAgTWFudWZhY3R1cmVyLCBudWxsLXBhZGRlZCBBU0NJSVxuICogICAweGNjICA2NCBieXRlcyAgTW9kZWwgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICpcbiAqIFJldHVybnMgbnVsbCBpZiBidWZmZXIgaXMgdG9vIHNob3J0LCB3cm9uZyBtYWdpYywgb3IgbWlzc2luZyBtb2RlbCBzdHJpbmcuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKTogRGV2aWNlSW5mbyB8IG51bGwge1xuXHRpZiAobXNnLmxlbmd0aCA8IERBTlRFX0lORk9fTUlOX0xFTikgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZikgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5yZWFkVUludDE2QkUoMikgIT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVybiBudWxsXG5cblx0Y29uc3QgcmVhZFN0ciA9IChvZmZzZXQ6IG51bWJlciwgbGVuOiBudW1iZXIpOiBzdHJpbmcgPT5cblx0XHRtc2dcblx0XHRcdC5zdWJhcnJheShvZmZzZXQsIG9mZnNldCArIGxlbilcblx0XHRcdC50b1N0cmluZygnYXNjaWknKVxuXHRcdFx0LnNwbGl0KCdcXDAnKVswXVxuXHRcdFx0LnRyaW0oKVxuXG5cdGNvbnN0IGV1aTY0ID0gbXNnLnN1YmFycmF5KDgsIDE2KVxuXHRjb25zdCBtYWNCeXRlcyA9IFtldWk2NFswXSwgZXVpNjRbMV0sIGV1aTY0WzJdLCBldWk2NFs1XSwgZXVpNjRbNl0sIGV1aTY0WzddXVxuXHRjb25zdCBtYWMgPSBtYWNCeXRlcy5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJzonKVxuXG5cdGNvbnN0IG5hbWUgPSByZWFkU3RyKDB4MjAsIDE0KSAvLyBEYW50ZSBkZXZpY2UgbGFiZWwgKHVzZXItY29uZmlndXJhYmxlKVxuXHRjb25zdCBtYW51ZmFjdHVyZXIgPSByZWFkU3RyKDB4NGMsIDY0KSAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGNvbnN0IG1vZGVsUmF3ID0gcmVhZFN0cigweGNjLCA2NClcblx0Y29uc3QgZmlybXdhcmUgPSBgJHttc2dbMHgxOF19LiR7bXNnWzB4MTldfWBcblxuXHRpZiAoIW1vZGVsUmF3KSByZXR1cm4gbnVsbFxuXG5cdC8vIEV4dHJhY3QganVzdCB0aGUgbW9kZWwgbnVtYmVyL2NvZGUgKGUuZy4gXCJNb2RlbCAzOTEgQWxlcnRpbmcgVW5pdFwiIFx1MjE5MiBcIjM5MVwiKVxuXHQvLyBTdHJpcCBcIk1vZGVsIFwiIHByZWZpeCwgdGhlbiB0YWtlIG9ubHkgdGhlIGZpcnN0IHdvcmQgKHRoZSBtb2RlbCBudW1iZXIpXG5cdGNvbnN0IG1vZGVsID0gbW9kZWxSYXdcblx0XHQucmVwbGFjZSgvXk1vZGVsXFxzKy9pLCAnJylcblx0XHQudHJpbSgpXG5cdFx0LnNwbGl0KC9cXHMrLylbMF1cblxuXHRyZXR1cm4geyBpcDogc3JjSXAsIG5hbWUsIG1hbnVmYWN0dXJlciwgbW9kZWwsIG1hYywgZmlybXdhcmUgfVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGxvY2FsIElQIGFkZHJlc3MgdXNlZCBieSB0aGUgT1MgdG8gcm91dGUgdG8gZGVzdElwLlxuICogVXNlcyBhIHRlbXBvcmFyeSBVRFAgc29ja2V0IGNvbm5lY3QgdG8gbGV0IHRoZSBPUyBzZWxlY3QgdGhlIG91dGdvaW5nIGludGVyZmFjZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPHN0cmluZz4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHQvLyBVc2UgYW4gYXJiaXRyYXJ5IHBvcnQgZm9yIGNvbm5lY3Q7IHdlIG9ubHkgbmVlZCB0aGUga2VybmVsIHRvIGFzc2lnbiBhIGxvY2FsIGFkZHJlc3MuXG5cdFx0dG1wLmNvbm5lY3QoOSwgZGVzdElwLCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGFkZHIuYWRkcmVzc1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZXNvbHZlKGxvY2FsQWRkcilcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihTdHJpbmcoX2UpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogRGlzY292ZXJzIFN0dWRpbyBUZWNobm9sb2dpZXMgRGFudGUgZGV2aWNlcyBvbiB0aGUgbG9jYWwgbmV0d29yay5cbiAqXG4gKiBTdHJhdGVneTpcbiAqICBEYW50ZSBkZXZpY2VzIGJyb2FkY2FzdCBhIDEtc2Vjb25kIGFubm91bmNlIHRvIG11bHRpY2FzdCAyMjQuMC4wLjIzMzo4NzA4LlxuICogIFdlIGxpc3RlbiBvbiB0aGF0IGdyb3VwLCBjb2xsZWN0IHNvdXJjZSBJUHMsIHRoZW4gc2VuZCBhIHVuaWNhc3QgZGV2aWNlIGluZm9cbiAqICByZXF1ZXN0ICgweDAwMjApIHRvIGVhY2ggbmV3IElQIG9uIHBvcnQgODcwMC4gVGhlIGRldmljZSByZXNwb25kcyBvbiBwb3J0IDg3MDIsXG4gKiAgd2hlcmUgdGhlIHByb3ZpZGVkIG9uRGV2aWNlRm91bmQgY2FsbGJhY2sgaXMgaW52b2tlZC5cbiAqXG4gKiBAcGFyYW0gdHhTb2NrZXQgLSBUaGUgc29ja2V0IHRvIHVzZSBmb3Igc2VuZGluZyBkaXNjb3ZlcnkgcmVxdWVzdHNcbiAqIEBwYXJhbSBvbkRldmljZUZvdW5kIC0gQ2FsbGJhY2sgaW52b2tlZCB3aGVuIGEgZGV2aWNlIGluZm8gcmVzcG9uc2UgKDB4MDE3MCkgaXMgcmVjZWl2ZWRcbiAqIEBwYXJhbSBlbnN1cmVNZW1iZXJzaGlwIC0gQ2FsbGJhY2sgdG8gZW5zdXJlIG11bHRpY2FzdCBtZW1iZXJzaGlwIGZvciBkZXZpY2UgSVBcbiAqIEBwYXJhbSB0aW1lb3V0TXMgLSBEaXNjb3ZlcnkgdGltZW91dCBpbiBtaWxsaXNlY29uZHNcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRpc2NvdmVyRGV2aWNlcyhcblx0dHhTb2NrZXQ6IGRncmFtLlNvY2tldCxcblx0b25EZXZpY2VGb3VuZDogKGRldmljZTogRGV2aWNlSW5mbykgPT4gdm9pZCxcblx0ZW5zdXJlTWVtYmVyc2hpcDogKGRlc3RJcDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+LFxuXHR0aW1lb3V0TXMgPSA1MDAwLFxuKTogUHJvbWlzZTxEZXZpY2VJbmZvW10+IHtcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfR1JPVVAgPSAnMjI0LjAuMC4yMzMnXG5cdGNvbnN0IERBTlRFX0FOTk9VTkNFX1BPUlQgPSA4NzA4XG5cdGNvbnN0IERFRkFVTFRfUE9SVCA9IDg3MDBcblxuXHRjb25zdCBmb3VuZCA9IG5ldyBNYXA8c3RyaW5nLCBEZXZpY2VJbmZvPigpXG5cdGNvbnN0IHF1ZXJpZWRJcHMgPSBuZXcgU2V0PHN0cmluZz4oKVxuXG5cdHJldHVybiBuZXcgUHJvbWlzZTxEZXZpY2VJbmZvW10+KChyZXNvbHZlKSA9PiB7XG5cdFx0Ly8gV3JhcCB0aGUgY2FsbGJhY2sgdG8gdHJhY2sgZm91bmQgZGV2aWNlc1xuXHRcdGNvbnN0IHdyYXBwZWRDYWxsYmFjayA9IChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdGlmICghZm91bmQuaGFzKGRldmljZS5pcCkpIHtcblx0XHRcdFx0Zm91bmQuc2V0KGRldmljZS5pcCwgZGV2aWNlKVxuXHRcdFx0XHRvbkRldmljZUZvdW5kKGRldmljZSlcblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBPcGVuIGEgc2hvcnQtbGl2ZWQgc29ja2V0IGp1c3QgdG8gcmVjZWl2ZSB0aGUgRGFudGUgcGVyaW9kaWMgYW5ub3VuY2VzXG5cdFx0Y29uc3QgYW5ub3VuY2VTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0Y29uc3QgY2xlYW51cCA9ICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmRyb3BNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0cmVzb2x2ZShBcnJheS5mcm9tKGZvdW5kLnZhbHVlcygpKSlcblx0XHR9XG5cblx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoY2xlYW51cCwgdGltZW91dE1zKVxuXHRcdHRpbWVyLnVucmVmPy4oKVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEFubm91bmNlIHNvY2tldCBlcnJvcjogJHtlcnIubWVzc2FnZX1gKVxuXHRcdH0pXG5cblx0XHRhbm5vdW5jZVNvY2tldC5vbignbWVzc2FnZScsIChtc2csIHJpbmZvKSA9PiB7XG5cdFx0XHRjb25zdCBzcmNJcCA9IHJpbmZvLmFkZHJlc3Ncblx0XHRcdC8vIFZhbGlkYXRlIGl0J3MgYSBEYW50ZSBhbm5vdW5jZSAobWFnaWMgMHhmZmZlICsgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNilcblx0XHRcdGlmIChtc2cubGVuZ3RoIDwgMjQpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZSkgcmV0dXJuXG5cdFx0XHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVyblxuXG5cdFx0XHRpZiAocXVlcmllZElwcy5oYXMoc3JjSXApKSByZXR1cm5cblx0XHRcdHF1ZXJpZWRJcHMuYWRkKHNyY0lwKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBBbm5vdW5jZSBmcm9tICR7c3JjSXB9IFx1MjAxNCBzZW5kaW5nIHVuaWNhc3QgcXVlcnlgKVxuXG5cdFx0XHQvLyBKb2luIDIyNC4wLjAuMjMxIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gdGhpcyBkZXZpY2UgQkVGT1JFIHNlbmRpbmdcblx0XHRcdC8vIHRoZSBxdWVyeS4gVGhlIGRldmljZSBtdWx0aWNhc3RzIGl0cyAweDAxNzAgcmVzcG9uc2UgdG8gMjI0LjAuMC4yMzE6ODcwMlxuXHRcdFx0Ly8gaW4gYWRkaXRpb24gdG8gdW5pY2FzdGluZyBpdCBcdTIwMTQgcnhTb2NrZXQgbXVzdCBiZSBhIG1lbWJlciB0byByZWNlaXZlIGl0LlxuXHRcdFx0ZW5zdXJlTWVtYmVyc2hpcChzcmNJcClcblx0XHRcdFx0LnRoZW4oKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IHF1ZXJ5ID0gYnVpbGREYW50ZUluZm9SZXF1ZXN0KClcblx0XHRcdFx0XHR0eFNvY2tldC5zZW5kKHF1ZXJ5LCBERUZBVUxUX1BPUlQsIHNyY0lwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0XHRpZiAoZXJyKSBsb2dnZXIud2FybihgVW5pY2FzdCBxdWVyeSB0byAke3NyY0lwfSBmYWlsZWQ6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9KVxuXHRcdFx0XHQuY2F0Y2goKGVycikgPT4gbG9nZ2VyLndhcm4oYFF1ZXJ5IHNldHVwIGZhaWxlZDogJHtlcnJ9YCkpXG5cdFx0fSlcblxuXHRcdGFubm91bmNlU29ja2V0LmJpbmQoREFOVEVfQU5OT1VOQ0VfUE9SVCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuYWRkTWVtYmVyc2hpcChEQU5URV9BTk5PVU5DRV9HUk9VUClcblx0XHRcdFx0bG9nZ2VyLmluZm8oYExpc3RlbmluZyBmb3IgRGFudGUgYW5ub3VuY2VzIG9uICR7REFOVEVfQU5OT1VOQ0VfR1JPVVB9OiR7REFOVEVfQU5OT1VOQ0VfUE9SVH1gKVxuXHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3Qgam9pbiBhbm5vdW5jZSBtdWx0aWNhc3QgZ3JvdXA6ICR7ZXJyfWApXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIFN0b3JlIGNhbGxiYWNrIGZvciBjbGVhbnVwXG5cdFx0Oyhhbm5vdW5jZVNvY2tldCBhcyBhbnkpLndyYXBwZWRDYWxsYmFjayA9IHdyYXBwZWRDYWxsYmFja1xuXHR9KVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7QUFBQSxPQUFPQSxXQUFVOzs7QUNrQmpCLElBQU0scUJBQWtDLENBQUMsUUFBUSxPQUFPLFlBQVc7QUFFbEUsVUFBUSxJQUFJLElBQUksTUFBTSxZQUFXLENBQUUsSUFBSSxTQUFTLEtBQUssTUFBTSxNQUFNLEVBQUUsSUFBSSxPQUFPLEVBQUU7QUFDakY7QUFFQSxTQUFTLFVBQVUsUUFBNEIsT0FBaUIsU0FBZTtBQUM5RSxRQUFNLE9BQU8sT0FBTyxPQUFPLHFCQUFxQixhQUFhLE9BQU8sbUJBQW1CO0FBQ3ZGLE9BQUssUUFBUSxPQUFPLE9BQU87QUFDNUI7QUFPTSxTQUFVLG1CQUFtQixRQUFlO0FBQ2pELFNBQU87SUFDTixPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTztJQUM5RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTzs7QUFFaEU7OztBQ1RNLFNBQVUsWUFBWSxNQUFXO0FBRXZDOzs7QUNoQ0EsU0FBUyxvQkFBb0I7QUEyRXZCLElBQU8sc0JBQVAsY0FBbUMsYUFBbUM7RUFDbEU7RUFDQTtFQUVULElBQVcsV0FBUTtBQUNsQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUNBLElBQVcsYUFBVTtBQUNwQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUVBLElBQVksYUFBVTtBQUNyQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0FBQ25ELGFBQU8sS0FBSztJQUNiLE9BQU87QUFDTixhQUFPO0lBQ1I7RUFDRDtFQUVBLFNBQXVFO0VBRXZFLFlBQVksU0FBeUMsU0FBK0I7QUFDbkYsVUFBSztBQUVMLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVcsRUFBRSxHQUFHLFFBQU87RUFDN0I7RUFFQSxLQUFLLE1BQWMsVUFBbUIsVUFBcUI7QUFDMUQsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSx5QkFBeUI7QUFDN0YsWUFBUSxLQUFLLFFBQVE7TUFDcEIsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG9DQUFvQztNQUNyRCxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0seUJBQXlCO01BQzFDLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxtQkFBbUI7TUFDcEMsS0FBSztBQUNKO01BQ0Q7QUFDQyxvQkFBWSxLQUFLLE1BQU07QUFDdkIsY0FBTSxJQUFJLE1BQU0sc0JBQXNCO0lBQ3hDO0FBRUEsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxhQUFhLFFBQVE7QUFFM0MsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixRQUFRLEtBQUssU0FBUztNQUN0QixZQUFZOztLQUVaLEVBQ0EsS0FDQSxDQUFDLGFBQVk7QUFDWixXQUFLLFNBQVMsRUFBRSxZQUFZLE1BQU0sU0FBUTtBQUMxQyxXQUFLLFNBQVMsd0JBQXdCLElBQUksVUFBVSxJQUFJO0FBQ3hELFdBQUssS0FBSyxXQUFXO0lBQ3RCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTO0FBQ2QsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxNQUFNLFVBQXFCO0FBQzFCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7SUFFcEQsT0FBTztBQUNOLGNBQVEsS0FBSyxRQUFRO1FBQ3BCLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0NBQW9DO1FBQ3JELEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQkFBb0I7UUFDckM7QUFDQyxzQkFBWSxLQUFLLE1BQU07QUFDdkIsZ0JBQU0sSUFBSSxNQUFNLHNCQUFzQjtNQUN4QztJQUNEO0FBRUEsVUFBTSxXQUFXLEtBQUssT0FBTztBQUM3QixTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLFNBQVMsUUFBUTtBQUV2QyxTQUFLLFNBQ0gscUJBQXFCO01BQ3JCO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssT0FBTztJQUNsQixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBV0EsS0FDQyxjQUNBLGNBQ0EsaUJBQ0EsZ0JBQ0EsU0FDQSxVQUFxQjtBQUVyQixRQUFJLE9BQU8saUJBQWlCO0FBQVUsWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ3pFLFFBQUksT0FBTyxvQkFBb0IsVUFBVTtBQUN4QyxVQUFJLE9BQU8sbUJBQW1CLFlBQVksT0FBTyxZQUFZO0FBQVUsY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQzFHLFVBQUksYUFBYSxVQUFhLE9BQU8sYUFBYTtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUVqRyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsY0FBYyxlQUFlO0FBQzlFLFdBQUssV0FBVyxRQUFRLGdCQUFnQixTQUFTLFFBQVE7SUFDMUQsV0FBVyxPQUFPLG9CQUFvQixVQUFVO0FBQy9DLFVBQUksbUJBQW1CLFVBQWEsT0FBTyxtQkFBbUI7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFN0csWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLEdBQUcsTUFBUztBQUM3RCxXQUFLLFdBQVcsUUFBUSxjQUFjLGlCQUFpQixjQUFjO0lBQ3RFLE9BQU87QUFDTixZQUFNLElBQUksTUFBTSxtQkFBbUI7SUFDcEM7RUFDRDtFQUVBLGVBQ0MsY0FDQSxRQUNBLFFBQTBCO0FBRTFCLFFBQUk7QUFDSixRQUFJLE9BQU8saUJBQWlCLFVBQVU7QUFDckMsZUFBUyxPQUFPLEtBQUssY0FBYyxPQUFPO0lBQzNDLFdBQVcsT0FBTyxTQUFTLFlBQVksR0FBRztBQUN6QyxlQUFTO0lBQ1YsV0FBVyxNQUFNLFFBQVEsWUFBWSxHQUFHO0FBRXZDLGFBQU8sT0FBTyxLQUFLLFlBQVk7SUFDaEMsT0FBTztBQUNOLGVBQVMsT0FBTyxLQUFLLGFBQWEsUUFBUSxhQUFhLFlBQVksYUFBYSxVQUFVO0lBQzNGO0FBRUEsV0FBTyxPQUFPLFNBQVMsUUFBUSxXQUFXLFNBQVksU0FBUyxTQUFTLE1BQVM7RUFDbEY7RUFFQSxXQUFXLFFBQWdCLE1BQWMsU0FBaUIsVUFBcUI7QUFDOUUsUUFBSSxDQUFDLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUV6RixTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFVBQVUsS0FBSyxPQUFPO01BQ3RCLFNBQVM7TUFFVDtNQUNBO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixpQkFBVTtJQUNYLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxxQkFBcUIsU0FBK0I7QUFDbkQsUUFBSTtBQUNILFdBQUssS0FBSyxXQUFXLFFBQVEsU0FBUyxRQUFRLE1BQU07SUFDckQsU0FBUyxJQUFJO0lBRWI7RUFDRDtFQUNBLG1CQUFtQixPQUFZO0FBQzlCLFNBQUssU0FBUztBQUVkLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFFBQUk7QUFBWSxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sV0FBVyxRQUFRO0FBRWhGLFFBQUk7QUFDSCxXQUFLLEtBQUssU0FBUyxLQUFLO0lBQ3pCLFNBQVMsSUFBSTtJQUViO0VBQ0Q7Ozs7QUM5UEssU0FBVSxrQkFBbUQsS0FBWTtBQUM5RSxRQUFNLE9BQU87QUFDYixTQUFPLENBQUMsQ0FBQyxRQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSyxPQUFPLFlBQVksS0FBSyx1QkFBdUI7QUFDekc7OztBQzZCTSxJQUFnQixlQUFoQixNQUE0QjtFQUN4QjtFQUNBO0VBRUE7RUFFVCxJQUFXLEtBQUU7QUFDWixXQUFPLEtBQUssU0FBUztFQUN0QjtFQUVBLElBQVcsa0JBQWU7QUFDekIsV0FBTyxLQUFLO0VBQ2I7Ozs7O0VBTUEsSUFBVyxRQUFLO0FBQ2YsV0FBTyxLQUFLLFNBQVM7RUFDdEI7Ozs7RUFLQSxZQUFZLFVBQWlCO0FBQzVCLFFBQUksQ0FBQyxrQkFBNkIsUUFBUSxLQUFLLENBQUMsU0FBUztBQUN4RCxZQUFNLElBQUksTUFDVCxtR0FBbUc7QUFHckcsU0FBSyxXQUFXO0FBRWhCLFNBQUssVUFBVSxtQkFBa0I7QUFFakMsU0FBSyx3QkFBd0IsS0FBSyxzQkFBc0IsS0FBSyxJQUFJO0FBRWpFLFNBQUssV0FBVztNQUNmLDJCQUEyQjtNQUMzQix3QkFBd0I7O0FBR3pCLFNBQUssSUFBSSxTQUFTLGNBQWM7RUFDakM7RUErQkEsV0FBVyxXQUE0QyxZQUFpQztBQUN2RixTQUFLLFNBQVMsV0FBVyxXQUFXLFVBQVU7RUFDL0M7Ozs7O0VBdUJBLHFCQUFxQixTQUF5RDtBQUM3RSxTQUFLLFNBQVMscUJBQXFCLE9BQU87RUFDM0M7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7O0VBT0EscUJBQ0MsV0FDQSxTQUE4QztBQUU5QyxTQUFLLFNBQVMscUJBQXFCLFdBQVcsT0FBTztFQUN0RDs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsUUFBSSxNQUFNLFFBQVEsU0FBUztBQUFHLFlBQU0sSUFBSSxNQUFNLHdEQUF3RDtBQUV0RyxTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7O0VBTUEsa0JBQWtCLFFBQXVDO0FBQ3hELFNBQUssU0FBUyxrQkFBa0IsTUFBTTtFQUN2Qzs7Ozs7O0VBT0EsaUJBQW1DLFlBQWE7QUFDL0MsV0FBTyxLQUFLLFNBQVMsaUJBQWlCLFVBQVU7RUFDakQ7Ozs7RUFLQSxvQkFBaUI7QUFDaEIsU0FBSyxTQUFTLGtCQUFpQjtFQUNoQzs7Ozs7OztFQVFBLGVBQ0MsaUJBQ0csZUFBbUQ7QUFFdEQsU0FBSyxTQUFTLGVBQWUsQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO0VBQzlEOzs7OztFQU1BLHNCQUFzQixhQUFxQjtBQUMxQyxTQUFLLFNBQVMsbUJBQW1CLFdBQVc7RUFDN0M7Ozs7OztFQU9BLG9CQUFvQixXQUFtQjtBQUN0QyxTQUFLLFNBQVMsaUJBQWlCLFNBQVM7RUFDekM7Ozs7OztFQU1BLHNCQUFzQixXQUFtQjtBQUN4QyxTQUFLLFNBQVMsbUJBQW1CLFNBQVM7RUFDM0M7Ozs7OztFQU9BLHdCQUF3QixhQUFxQjtBQUM1QyxTQUFLLFNBQVMscUJBQXFCLFdBQVc7RUFDL0M7Ozs7OztFQU9BLGFBQWEsUUFBaUMsY0FBcUI7QUFDbEUsU0FBSyxTQUFTLGFBQWEsUUFBUSxZQUFZO0VBQ2hEOzs7Ozs7OztFQVNBLFFBQVEsTUFBYyxNQUFjQyxPQUFjLE1BQXNCO0FBQ3ZFLFNBQUssU0FBUyxRQUFRLE1BQU0sTUFBTUEsT0FBTSxJQUFJO0VBQzdDOzs7Ozs7Ozs7OztFQVlBLGFBQWEsUUFBd0IsU0FBdUI7QUFDM0QsU0FBSyxTQUFTLGFBQWEsUUFBUSxXQUFXLElBQUk7RUFDbkQ7Ozs7OztFQU9BLElBQUksT0FBaUIsU0FBZTtBQUNuQyxZQUFRLE9BQU87TUFDZCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNEO0FBQ0Msb0JBQVksS0FBSztBQUNqQixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO0lBQ0Y7RUFDRDtFQVlBLHNCQUNDLGVBQ0EsVUFBeUM7QUFFekMsVUFBTSxVQUFrQyxPQUFPLGtCQUFrQixXQUFXLEVBQUUsTUFBTSxjQUFhLElBQUs7QUFFdEcsVUFBTSxTQUFTLElBQUksb0JBQW9CLEtBQUssVUFBVSxPQUFPO0FBQzdELFFBQUk7QUFBVSxhQUFPLEdBQUcsV0FBVyxRQUFRO0FBRTNDLFdBQU87RUFDUjs7OztBQy9VRCxJQUFZO0NBQVosU0FBWUMsaUJBQWM7QUFDekIsRUFBQUEsZ0JBQUEsSUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsWUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsbUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFdBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGdCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx1QkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEseUJBQUEsSUFBQTtBQUNELEdBVlksbUJBQUEsaUJBQWMsQ0FBQSxFQUFBO0FBYXBCLElBQVc7Q0FBakIsU0FBaUJDLFFBQUs7QUFFUixFQUFBQSxPQUFBLEtBQUs7QUFDTCxFQUFBQSxPQUFBLFdBQ1o7QUFDWSxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLE9BQ1o7QUFDWSxFQUFBQSxPQUFBLGNBQWM7QUFDZCxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLFFBQVE7QUFDUixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLFNBQVM7QUFDVCxFQUFBQSxPQUFBLGdCQUFnQjtBQUNoQixFQUFBQSxPQUFBLFlBQVk7QUFDWixFQUFBQSxPQUFBLFdBQ1o7QUFDRixHQWxCaUIsVUFBQSxRQUFLLENBQUEsRUFBQTs7O0FDakJ0QixPQUFPLFFBQVE7QUFDZixPQUFPLFVBQVU7QUFHakIsSUFBTSxTQUFTLG1CQUFtQixRQUFRO0FBVzFDLElBQU0sZ0JBQWdCLEtBQUssS0FBSyxZQUFZLFNBQVMsWUFBWTtBQUVqRSxTQUFTLHNCQUFtQjtBQUMzQixNQUFJO0FBQ0gsVUFBTSxRQUFRLEdBQUcsWUFBWSxhQUFhLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLE9BQU8sQ0FBQztBQUM3RSxVQUFNLFNBQW1CLENBQUE7QUFFekIsZUFBVyxLQUFLLE9BQU87QUFDdEIsWUFBTSxXQUFXLEtBQUssS0FBSyxlQUFlLENBQUM7QUFDM0MsWUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHLGFBQWEsVUFBVSxNQUFNLENBQUM7QUFDdEQsVUFBSSxHQUFHLE9BQU87QUFDYixlQUFPLEtBQUssT0FBTyxFQUFFLEtBQUssQ0FBQztNQUM1QjtJQUNEO0FBRUEsV0FBTyxPQUFPLEtBQUk7RUFDbkIsU0FBUyxJQUFJO0FBQ1osV0FBTyxNQUFNLGlDQUFpQyxFQUFFLEVBQUU7QUFDbEQsV0FBTyxDQUFBO0VBQ1I7QUFDRDtBQUVNLFNBQVUsZ0JBQWdCLG9CQUFrQyxDQUFBLEdBQUU7QUFDbkUsUUFBTSxTQUFTLG9CQUFtQjtBQUtsQyxRQUFNLGdCQUFnQjtJQUNyQixFQUFFLElBQUksSUFBSSxPQUFPLFNBQVE7SUFDekIsR0FBRyxrQkFBa0IsSUFBSSxDQUFDLE9BQU87TUFDaEMsSUFBSSxFQUFFO01BQ04sT0FBTyxTQUFTLEVBQUUsS0FBSyxLQUFLLEVBQUUsRUFBRTtNQUMvQjs7QUFHSCxTQUFPOzs7O0lBSU47TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULFNBQVM7TUFDVCxTQUFTOzs7OztJQU1WO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxPQUFPLE1BQU07TUFDYixxQkFBcUI7TUFDckIsU0FBUzs7Ozs7SUFNVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTLE9BQU8sQ0FBQyxLQUFLO01BQ3RCLFNBQVMsT0FBTyxJQUFJLENBQUMsV0FBVztRQUMvQixJQUFJO1FBQ0osT0FBTyxTQUFTLEtBQUs7UUFDcEI7TUFDRixxQkFBcUI7TUFDckIsU0FBUzs7O0FBR1o7QUFNTSxTQUFVLFlBQVksUUFBb0I7QUFDL0MsU0FBTyxPQUFPLGtCQUFrQixPQUFPO0FBQ3hDO0FBTU0sU0FBVSxhQUFhLFFBQXNCLG1CQUErQjtBQUNqRixNQUFJLE9BQU8sZ0JBQWdCO0FBQzFCLFVBQU0sU0FBUyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sY0FBYztBQUMzRSxZQUFRLElBQUksaUNBQWlDLE9BQU8sY0FBYyxvQkFBb0IsTUFBTTtBQUM1RixRQUFJLFFBQVEsT0FBTztBQUNsQixhQUFPLE9BQU87SUFDZjtFQUNEO0FBQ0EsVUFBUSxJQUFJLDhDQUE4QyxPQUFPLFdBQVcsR0FBRztBQUMvRSxTQUFPLE9BQU87QUFDZjs7O0FDdEhNLFNBQVUsMEJBQTBCLE1BQW9CO0FBQzdELE9BQUssdUJBQXVCO0lBQzNCLFdBQVcsRUFBRSxNQUFNLG9CQUFtQjtJQUN0QyxXQUFXLEVBQUUsTUFBTSxxQkFBb0I7SUFDdkMsV0FBVyxFQUFFLE1BQU0sbUJBQWtCO0dBQ3JDO0FBQ0Y7OztBQ0xPLElBQU0saUJBQStEOzs7Ozs7Ozs7Ozs7Ozs7QUNHNUUsT0FBT0MsU0FBUTtBQUNmLE9BQU9DLFdBQVU7OztBQ2dCVixJQUFNLGNBQWM7QUFDcEIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sYUFBYTtBQUNuQixJQUFNLHVCQUF1QjtBQUM3QixJQUFNLG9CQUFvQjtBQUMxQixJQUFNLGVBQWU7QUFDckIsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxjQUFjO0FBR3JCLFNBQVUsZUFBZSxPQUFhO0FBQzNDLFVBQVEsT0FBTztJQUNkLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSO0FBQ0MsYUFBTyxTQUFTLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztFQUNyRDtBQUNEO0FBUU0sU0FBVSxjQUNmLE9BQ0EsT0FDQSxXQUNBLE9BQXVCO0FBRXZCLFFBQU0sTUFBTSxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzdELFFBQU0sS0FBSyxPQUFPLGNBQWMsV0FBVyxVQUFVLFNBQVMsRUFBRSxJQUFJO0FBRXBFLE1BQUksVUFBVSxRQUFXO0FBQ3hCLFVBQU0sS0FBSyxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzVELFdBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFO0VBQ25DO0FBRUEsU0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRTtBQUM3Qjs7O0FEMUVBLElBQU1DLGlCQUFnQkMsTUFBSyxLQUFLLFlBQVksU0FBUyxZQUFZO0FBTTNELFNBQVUsY0FBYyxNQUFNRCxnQkFBYTtBQUNoRCxRQUFNLFFBQVFFLElBQUcsWUFBWSxHQUFHLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLE9BQU8sQ0FBQztBQUNuRSxRQUFNLE1BQTJCLENBQUE7QUFFakMsYUFBVyxLQUFLLE9BQU87QUFDdEIsVUFBTSxJQUFJLEtBQUssTUFBTUEsSUFBRyxhQUFhRCxNQUFLLEtBQUssS0FBSyxDQUFDLEdBQUcsTUFBTSxDQUFDO0FBQy9ELFFBQUksRUFBRSxLQUFLLElBQUk7RUFDaEI7QUFFQSxTQUFPO0FBQ1I7QUFNQSxTQUFTLFlBQVksR0FBTTtBQUMxQixRQUFNLE9BQU87SUFDWixNQUFNLEVBQUU7SUFDUixJQUFJLEVBQUU7SUFDTixPQUFPLEVBQUU7SUFDVCxTQUFTLEVBQUU7SUFDWCxTQUFTLEVBQUU7O0FBR1osVUFBUSxFQUFFLE1BQU07SUFDZixLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxDQUFBLEVBQUU7SUFFM0MsS0FBSztBQUNKLGFBQU87UUFDTixHQUFHO1FBQ0gsS0FBSyxFQUFFO1FBQ1AsS0FBSyxFQUFFO1FBQ1AsTUFBTSxFQUFFLFFBQVE7UUFDaEIsT0FBTzs7SUFHVCxLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxNQUFLO0lBRTlDLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMO0FBQ0MsYUFBTztFQUNUO0FBQ0Q7QUFNTSxTQUFVLGFBQWEsTUFBTUQsZ0JBQWE7QUFDL0MsUUFBTSxVQUFVLGNBQWMsR0FBRztBQUNqQyxRQUFNLFVBQXNDLENBQUE7QUFFNUMsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxLQUFLLFdBQVc7QUFDMUIsWUFBTSxXQUFXLGNBQWMsT0FBTyxFQUFFLFFBQVEsRUFBRSxFQUFFO0FBRXBELFlBQU0sV0FBVyxFQUFFLFdBQVcsQ0FBQSxHQUFJLElBQUksV0FBVztBQUVqRCxZQUFNLFNBQW9DO1FBQ3pDLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxJQUFJO1FBQy9CO1FBQ0EsVUFBVSxZQUFXO1FBRXJCOztBQUdELGNBQVEsUUFBUSxJQUFJO0lBQ3JCO0VBQ0Q7QUFFQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLGVBQWUsTUFBTUEsZ0JBQWE7QUFDakQsUUFBTSxVQUFVLGNBQWMsR0FBRztBQUNqQyxRQUFNLFlBQTBDLENBQUE7QUFFaEQsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxXQUFXLFdBQVc7QUFDaEMsWUFBTSxpQkFBaUIsY0FBYyxPQUFPLFFBQVEsUUFBUSxRQUFRLEVBQUU7QUFHdEUsWUFBTSxjQUFjLFFBQVEsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRzFELFlBQU0sZUFBZSxXQUFXLE9BQU8sQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBR3ZFLG1CQUFhLEtBQUs7UUFDakIsTUFBTTtRQUNOLElBQUk7UUFDSixPQUFPO1FBQ1AsU0FBUztRQUNULFNBQVM7T0FDVDtBQUdELFlBQU0sZ0JBQXFCO1FBQzFCLE1BQU07UUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtRQUNyQyxTQUFTO1FBQ1QsVUFBVSxNQUFLO0FBRWQsaUJBQU87UUFDUjs7QUFHRCxnQkFBVSxjQUFjLElBQUk7SUFDN0I7RUFDRDtBQUVBLFNBQU87QUFDUjs7O0FFakpBLE9BQU9HLFdBQVU7QUFHakIsT0FBT0MsU0FBUTs7O0FDTmYsT0FBT0MsU0FBUTtBQUNmLE9BQU9DLFdBQVU7QUErQ2pCLFNBQVMsZUFBZSxPQUFhO0FBQ3BDLFFBQU0sU0FBUyxvQkFBSSxJQUFHO0FBQ3RCLE1BQUksWUFBWTtBQUVoQixNQUFJO0FBQ0gsVUFBTSxhQUFhQyxNQUFLLFFBQVEsa0JBQWtCLEtBQUssT0FBTztBQUM5RCxVQUFNLE9BQU8sS0FBSyxNQUFNQyxJQUFHLGFBQWEsWUFBWSxPQUFPLENBQUM7QUFHNUQsZ0JBQVksS0FBSyxhQUFhO0FBRzlCLGVBQVcsVUFBVSxLQUFLLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0saUJBQWlCLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBd0IsSUFBSSxTQUFTLGFBQWE7QUFDL0YsVUFBSSxnQkFBZ0I7QUFFbkIsZUFBTyxJQUFJLE9BQU8sRUFBRTtBQUdwQixjQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLE9BQU8sT0FBTztBQUNwRixZQUFJLGFBQWEsU0FBUztBQUN6QixxQkFBVyxVQUFVLFlBQVksU0FBUztBQUN6QyxnQkFBSSxPQUFPLE9BQU8sT0FBTyxVQUFVO0FBQ2xDLHFCQUFPLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRTtZQUNqQztVQUNEO1FBQ0Q7TUFDRDtJQUNEO0VBQ0QsU0FBUyxNQUFNO0VBRWY7QUFFQSxTQUFPLEVBQUUsV0FBVyxPQUFNO0FBQzNCO0FBRUEsU0FBUyxjQUFjLEdBQVcsR0FBUztBQUMxQyxRQUFNLEtBQUssU0FBUyxFQUFFLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUM1QyxRQUFNLEtBQUssU0FBUyxFQUFFLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUM1QyxNQUFJLE9BQU8sTUFBTSxFQUFFLEtBQUssT0FBTyxNQUFNLEVBQUU7QUFBRyxXQUFPO0FBQ2pELFNBQU8sS0FBSyxJQUFJLEtBQUssRUFBRTtBQUN4QjtBQU1BLFNBQVMsc0JBQXNCLEtBQVc7QUFDekMsUUFBTSxXQUFXLElBQUksUUFBUSxPQUFPLEtBQUssVUFBVSxDQUFDO0FBQ3BELE1BQUksV0FBVztBQUFHLFVBQU0sSUFBSSxNQUFNLGlDQUFpQztBQUVuRSxRQUFNLGVBQWUsV0FBVztBQUNoQyxNQUFJLElBQUksWUFBWSxNQUFNLElBQU07QUFDL0IsVUFBTSxJQUFJLE1BQU0sdUNBQXVDLElBQUksWUFBWSxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUU7RUFDeEY7QUFFQSxTQUFPO0FBQ1I7QUFNQSxTQUFTLHVCQUF1QixPQUFlLFNBQXNCLG9CQUFJLElBQUcsR0FBRTtBQUM3RSxNQUFJLElBQUk7QUFDUixRQUFNLE1BQXVCLENBQUE7QUFFN0IsU0FBTyxJQUFJLE1BQU0sUUFBUTtBQUN4QixVQUFNLEtBQUssTUFBTSxDQUFDO0FBQ2xCLFFBQUksSUFBSSxLQUFLLE1BQU07QUFBUTtBQUczQixRQUFJLE9BQU8sSUFBSSxFQUFFLEtBQUssSUFBSSxJQUFJLE1BQU0sUUFBUTtBQUMzQyxVQUFJLEtBQUs7UUFDUixRQUFRO1FBQ1I7UUFDQSxZQUFZLENBQUMsTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLENBQUM7T0FDckQ7QUFDRCxXQUFLO0FBQ0w7SUFDRDtBQUVBLFFBQUksS0FBSyxFQUFFLFFBQVEsY0FBYyxJQUFJLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBRTtBQUNqRSxTQUFLO0VBQ047QUFFQSxTQUFPO0FBQ1I7QUFFTSxTQUFVLHlCQUF5QixLQUFhLE9BQWE7QUFDbEUsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0sNEJBQTRCO0VBQzdDO0FBRUEsUUFBTSxXQUFXLElBQUksTUFBTSxDQUFDO0FBQzVCLFFBQU0sUUFBUSxNQUFNO0FBQ3BCLFFBQU0sTUFBTSxRQUFRO0FBQ3BCLE1BQUksTUFBTSxJQUFJO0FBQVEsVUFBTSxJQUFJLE1BQU0sc0JBQXNCO0FBRTVELFFBQU0sRUFBRSxPQUFNLElBQUssZUFBZSxLQUFLO0FBQ3ZDLFNBQU8sdUJBQXVCLElBQUksU0FBUyxPQUFPLEdBQUcsR0FBRyxNQUFNO0FBQy9EO0FBTU0sU0FBVSw4QkFBOEIsS0FBYSxPQUFhO0FBQ3ZFLFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtFQUM3QztBQUdBLE1BQUksSUFBSSxVQUFVLHVCQUF1QixNQUFNLElBQUksTUFBTTtBQUN6RCxRQUFNLE1BQU0sSUFBSSxTQUFTO0FBQ3pCLFFBQU0sTUFBdUIsQ0FBQTtBQUc3QixRQUFNLEVBQUUsT0FBTSxJQUFLLGVBQWUsS0FBSztBQUd2QyxRQUFNLG9CQUFvQixDQUFDLGFBQWEsaUJBQWlCLFdBQVc7QUFFcEUsU0FBTyxJQUFJLElBQUksS0FBSztBQUNuQixVQUFNLFNBQVMsSUFBSSxDQUFDO0FBQ3BCLFVBQU0sZUFBZSxJQUFJLElBQUksQ0FBQztBQUU5QixVQUFNLGFBQWEsSUFBSSxJQUFJO0FBQzNCLFFBQUksYUFBYTtBQUFLO0FBR3RCLFVBQU0sV0FBVyxrQkFBa0IsU0FBUyxZQUFZO0FBRXhELFFBQUk7QUFDSixRQUFJO0FBQ0osUUFBSTtBQUVKLFFBQUksVUFBVTtBQUViLGNBQVEsSUFBSSxJQUFJLENBQUM7QUFDakIsZ0JBQVUsSUFBSSxJQUFJLENBQUM7QUFDbkIsVUFBSSxJQUFJO0lBQ1QsT0FBTztBQUVOLGdCQUFVLElBQUksSUFBSSxDQUFDO0FBQ25CLFVBQUksSUFBSTtJQUNUO0FBRUEsVUFBTSxPQUFPLElBQUk7QUFFakIsV0FBTyxJQUFJLElBQUksTUFBTTtBQUNwQixZQUFNLEtBQUssSUFBSSxDQUFDO0FBQ2hCLFVBQUk7QUFHSixVQUFJLE9BQU8sSUFBSSxFQUFFLEtBQUssSUFBSSxJQUFJLE1BQU07QUFDbkMscUJBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQztBQUNoRCxhQUFLO01BQ04sT0FBTztBQUNOLHFCQUFhLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQztBQUN4QixhQUFLO01BQ047QUFFQSxZQUFNLFVBQXlCO1FBQzlCLFFBQVE7UUFDUjtRQUNBOztBQUVELFVBQUksVUFBVSxRQUFXO0FBQ3hCLGdCQUFRLFFBQVE7TUFDakI7QUFDQSxVQUFJLEtBQUssT0FBTztJQUNqQjtBQUVBLFFBQUk7RUFDTDtBQUVBLFNBQU87QUFDUjtBQVdNLFNBQVUsc0JBQXNCLE9BQWUsS0FBVztBQUMvRCxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSxpQ0FBaUMsTUFBTSxTQUFTLEVBQUUsQ0FBQyxHQUFHO0VBQ3ZFO0FBQ0EsUUFBTSxFQUFFLFVBQVMsSUFBSyxlQUFlLEtBQUs7QUFDMUMsU0FBTyxZQUFZLDhCQUE4QixLQUFLLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxLQUFLO0FBQ25HO0FBTU0sU0FBVSxvQkFBb0IsU0FBd0IsU0FBbUI7QUFFOUUsTUFBSSxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFFBQVEsVUFBVSxFQUFFLE9BQU8sUUFBUSxFQUFFO0FBS25GLE1BQUksQ0FBQyxRQUFRO0FBQ1osVUFBTSxhQUFhLFFBQVEsS0FBSyxDQUFDLE1BQUs7QUFDckMsVUFBSSxFQUFFLFdBQVcsUUFBUTtBQUFRLGVBQU87QUFFeEMsWUFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUMvRCxVQUFJLENBQUMsYUFBYTtBQUFTLGVBQU87QUFFbEMsWUFBTSxnQkFBZ0IsUUFBUSxLQUFLLEVBQUU7QUFDckMsYUFBTyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGFBQWE7SUFDOUQsQ0FBQztBQUNELFFBQUksWUFBWTtBQUNmLGVBQVM7SUFDVjtFQUNEO0FBRUEsUUFBTSxTQUFTLEtBQUssUUFBUSxPQUFPLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDaEUsUUFBTSxRQUFRLEtBQUssUUFBUSxHQUFHLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDM0QsUUFBTSxTQUFTLEtBQUssUUFBUSxXQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDO0FBQzNGLFFBQU0sU0FDTCxRQUFRLFdBQVcsV0FBVyxJQUMzQixJQUFJLFFBQVEsV0FDWCxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLEVBQ1AsWUFBVyxDQUFFLEtBQ2QsUUFBUSxXQUFXLFdBQVcsSUFDN0IsUUFBUSxXQUFXLENBQUMsSUFDcEIsUUFBUSxXQUFXLEtBQUssR0FBRztBQUdoQyxRQUFNLFdBQVcsUUFBUSxVQUFVLFNBQVksT0FBTyxRQUFRLEtBQUssS0FBSztBQUN4RSxRQUFNLFNBQVMsT0FBTyxNQUFNLEdBQUcsUUFBUSxPQUFPLEtBQUssUUFBUSxNQUFNO0FBR2pFLE1BQUksUUFBUTtBQUNYLFFBQUksT0FBTyxPQUFPO0FBR2xCLFFBQUksUUFBUSxVQUFVLFFBQVc7QUFDaEMsYUFBTyxHQUFHLElBQUksTUFBTSxRQUFRLFFBQVEsQ0FBQztJQUN0QyxPQUVLO0FBQ0osWUFBTSxjQUFjLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUNwRSxVQUFJLGFBQWEsU0FBUztBQUN6QixjQUFNLGdCQUFnQixRQUFRLEtBQUssT0FBTztBQUMxQyxjQUFNLGNBQWMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxhQUFhO0FBQzFFLFlBQUksYUFBYTtBQUNoQixpQkFBTyxHQUFHLElBQUksSUFBSSxZQUFZLEtBQUs7UUFDcEM7TUFDRDtJQUNEO0FBR0EsVUFBTSxjQUFjLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUNwRSxRQUFJLGFBQWEsV0FBVyxRQUFRLFdBQVcsV0FBVyxHQUFHO0FBQzVELFlBQU0sU0FBUyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsV0FBVyxDQUFDLENBQUM7QUFDN0UsVUFBSSxRQUFRO0FBQ1gsZUFBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssT0FBTyxLQUFLLEtBQUssTUFBTTtNQUN2RDtJQUNEO0FBQ0EsV0FBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssTUFBTTtFQUN0QztBQUdBLFNBQU8sR0FBRyxNQUFNO0FBQ2pCO0FBTU0sU0FBVSw0QkFBNEIsT0FBZSxLQUFXO0FBQ3JFLFFBQU0sRUFBRSxVQUFTLElBQUssZUFBZSxLQUFLO0FBQzFDLFNBQU8sWUFBWSw4QkFBOEIsS0FBSyxLQUFLLElBQUkseUJBQXlCLEtBQUssS0FBSztBQUNuRztBQVNBLFNBQVMsbUJBQW1CLFlBQW9CO0FBQy9DLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsV0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxVQUFVLFNBQVMsV0FBVyxDQUFDLEVBQUM7RUFDN0U7QUFFQSxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFVBQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBQ2xCLFdBQU87TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE1BQU07TUFDTixTQUFTLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFDN0MsU0FBUyxFQUFFLEVBQ1gsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQzs7RUFFdEQ7QUFFQSxTQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLE9BQU8sU0FBUyxDQUFDLEdBQUcsVUFBVSxFQUFDO0FBQzVFO0FBTU0sU0FBVSw0QkFDZixXQUNBLFFBQ0EsV0FBc0M7QUFFdEMsUUFBTSxNQUFNLGdCQUFnQixTQUFTO0FBR3JDLE1BQUksQ0FBQyxJQUFJLFNBQVM7QUFDakIsUUFBSSxVQUFVLENBQUE7RUFDZjtBQUdBLFFBQU0sYUFBYSxPQUFPLE9BQU8sU0FBUyxFQUN4QyxPQUFPLENBQUMsTUFBTSxFQUFFLFVBQVUsVUFBVSxLQUFLLEVBQ3pDLEtBQUssQ0FBQyxHQUFHLE1BQU0sY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLElBQUksY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLENBQUM7QUFFbEcsVUFBUSxJQUFJLG1CQUFtQixVQUFVLEtBQUssRUFBRTtBQUNoRCxVQUFRLElBQUksNkJBQTZCLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRTtBQUV6RSxhQUFXLEVBQUUsUUFBUSxJQUFJLFdBQVUsS0FBTSxRQUFRO0FBQ2hELFFBQUksU0FBUyxJQUFJLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFFdkUsUUFBSSxDQUFDLFFBQVE7QUFFWixpQkFBVyxLQUFLLFlBQVk7QUFDM0IsY0FBTSxRQUFRLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUN2RSxZQUFJLE9BQU87QUFDVixtQkFBUyxnQkFBZ0IsS0FBSztBQUM5QixpQkFBTyxPQUFPLEdBQUcsTUFBTSxJQUFJLHlCQUF5QixFQUFFLEtBQUs7QUFDM0Qsa0JBQVEsSUFBSSxzQkFBc0IsR0FBRyxTQUFTLEVBQUUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxFQUFFO0FBQ3pFO1FBQ0Q7TUFDRDtJQUNEO0FBRUEsUUFBSSxDQUFDLFFBQVE7QUFDWixlQUFTO1FBQ1I7UUFDQTtRQUNBLE1BQU0scUJBQXFCLEdBQUcsU0FBUyxFQUFFLEVBQUUsWUFBVyxDQUFFO1FBQ3hELFNBQVMsQ0FBQyxtQkFBbUIsVUFBVSxDQUFDOztBQUV6QyxjQUFRLElBQUksNkJBQTZCLEdBQUcsU0FBUyxFQUFFLENBQUMsRUFBRTtJQUMzRCxPQUFPO0FBQ04sWUFBTSxNQUFNLE9BQU8sVUFBVSxDQUFDO0FBQzlCLFVBQUk7QUFBSyxZQUFJLFVBQVUsbUJBQW1CLFVBQVUsRUFBRTtJQUN2RDtBQUdBLFVBQU0sU0FBUyxJQUFJLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLE9BQU8sVUFBVSxFQUFFLE9BQU8sT0FBTyxFQUFFO0FBQ3ZGLFFBQUksQ0FBQztBQUFRLFVBQUksUUFBUSxLQUFLLE1BQU07RUFDckM7QUFFQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLG9CQUFvQixVQUFrQixTQUFvQjtBQUN6RSxNQUFJO0FBRUgsUUFBSSxPQUFPLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQztBQUsxQyxXQUFPLEtBQUssUUFBUSwwREFBMEQsNkJBQTZCO0FBRTNHLElBQUFDLElBQUcsY0FBYyxVQUFVLE9BQU8sTUFBTSxNQUFNO0VBQy9DLFNBQVMsR0FBRztBQUNYLFlBQVEsSUFBSSxxQkFBcUIsQ0FBQztFQUNuQztBQUNEO0FBb0JNLFNBQVUsZ0JBQ2ZDLGdCQUNBLE9BQWE7QUFFYixNQUFJO0FBQ0gsVUFBTSxXQUFXQyxNQUFLLEtBQUtELGdCQUFlLFFBQVEsS0FBSyxPQUFPO0FBQzlELFVBQU0sT0FBWSxLQUFLLE1BQU1FLElBQUcsYUFBYSxVQUFVLE1BQU0sQ0FBQztBQUM5RCxXQUFPO01BQ04sU0FBUyxNQUFNLGFBQWEsQ0FBQTtNQUM1QixxQkFBcUIsTUFBTSx1QkFBdUI7OztFQUVwRCxRQUFRO0FBQ1AsV0FBTyxFQUFFLFNBQVMsQ0FBQSxHQUFJLHFCQUFxQixLQUFJO0VBQ2hEO0FBQ0Q7OztBRGhkTSxTQUFVLGNBQWMsTUFBb0I7QUFDakQsUUFBTUMsaUJBQWdCQyxNQUFLLEtBQUssWUFBWSxTQUFTLFlBQVk7QUFFakUsUUFBTSxhQUFhLGNBQWNELGNBQWE7QUFDOUMsUUFBTSxhQUFhLGFBQWFBLGNBQWE7QUFDN0MsUUFBTSxVQUF1QyxDQUFBO0FBQzdDLGFBQVcsQ0FBQyxPQUFPLElBQUksS0FBSyxPQUFPLFFBQVEsVUFBVSxHQUFHO0FBQ3ZELFlBQVEsS0FBSyxJQUFJO01BQ2hCLE9BQU8sS0FBSztNQUNaLFNBQVMsTUFBTSxRQUFRLEtBQUssU0FBUyxJQUFJLEtBQUssWUFBWSxDQUFBOztFQUU1RDtBQUNBLFFBQU0sZUFBb0IsQ0FBQTtBQUcxQixRQUFNLGNBQWMsYUFBYSxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQzFELFVBQVEsSUFDUCwrQkFBK0IsV0FBVyxzQkFBc0IsS0FBSyxPQUFPLGNBQWMsb0JBQW9CLEtBQUssUUFBUSxNQUFNLEVBQUU7QUFPcEksZUFBYSx1QkFBdUIsSUFBSTtJQUN2QyxNQUFNO0lBQ04sU0FBUyxDQUFBO0lBQ1QsVUFBVSxZQUFXO0FBQ3BCLFlBQU0sUUFBUTtBQUNkLFlBQU0sS0FBSyxLQUFLO0FBRWhCLFlBQU0sTUFBTSxNQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUV6RCxZQUFNLGFBQWFDLE1BQUssS0FBS0QsZ0JBQWUsUUFBUSxLQUFLLE9BQU87QUFDaEUsWUFBTSxZQUFZLEtBQUssTUFBTUUsSUFBRyxhQUFhLFlBQVksTUFBTSxDQUFDO0FBR2hFLFlBQU0sU0FBUyw0QkFBNEIsT0FBTyxHQUFHO0FBQ3JELGNBQVEsSUFBSSxrQkFBa0IsTUFBTTtBQUVwQyxZQUFNLFVBQVUsNEJBQTRCLFdBQVcsUUFBUSxPQUFPO0FBQ3RFLGNBQVEsSUFBSSxzQkFBc0IsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLENBQUM7QUFFbEUsMEJBQW9CLFlBQVksT0FBTztBQUV2QyxjQUFRLElBQUksU0FBUyxLQUFLLHdDQUF3QztJQUNuRTs7QUFPRCxhQUFXLENBQUMsVUFBVSxNQUFNLEtBQUssT0FBTyxRQUFRLFVBQVUsR0FBRztBQUM1RCxVQUFNLENBQUMsT0FBTyxVQUFVLEtBQUssSUFBSSxTQUFTLE1BQU0sR0FBRztBQUduRCxRQUFJLFVBQVU7QUFBYTtBQUczQixVQUFNLFFBQVEsU0FBUyxVQUFVLEVBQUU7QUFDbkMsVUFBTSxTQUFTLFNBQVMsT0FBTyxFQUFFO0FBR2pDLFVBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsVUFBTSxZQUFZLFFBQVEsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sTUFBTTtBQUV6RixpQkFBYSxRQUFRLElBQUk7TUFDeEIsR0FBRztNQUNILFVBQVUsT0FBTyxVQUFjO0FBQzlCLGNBQU0sS0FBSyxLQUFLO0FBRWhCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBQ3pGLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTztBQUNuQyxjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxjQUFNLFlBQVksU0FBUztBQUUzQixjQUFNLEtBQUssYUFBYSxhQUFhLGFBQWEsT0FBTyxPQUFPLFdBQVcsT0FBTyxFQUFFO01BQ3JGOztFQUVGO0FBS0EsUUFBTSxlQUFlLFFBQVEsV0FBVztBQUN4QyxNQUFJLGNBQWM7QUFDakIsVUFBTSxtQkFBbUIsYUFBYSxXQUFXLENBQUEsR0FBSSxLQUFLLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxNQUFNLENBQUM7QUFFN0YsUUFBSSxpQkFBaUI7QUFDcEIsWUFBTSxXQUFXLEdBQUcsV0FBVztBQUUvQixtQkFBYSxRQUFRLElBQUk7UUFDeEIsTUFBTSxTQUFTLFdBQVc7UUFDMUIsU0FBUyxDQUFBO1FBQ1QsVUFBVSxZQUFXO0FBQ3BCLGdCQUFNLEtBQUssS0FBSztBQUNoQixrQkFBUSxJQUFJLHlCQUFvQixXQUFXLE1BQU0sRUFBRSxFQUFFO0FBQ3JELGdCQUFNLEtBQUssYUFBYSxjQUFjLGFBQWEsRUFBRTtRQUN0RDs7SUFFRjtFQUNEO0FBRUEsT0FBSyxxQkFBcUIsWUFBWTtBQUV0QyxVQUFRLElBQUksaUNBQWlDLE9BQU8sS0FBSyxZQUFZLEVBQUUsTUFBTTtBQUM5RTs7O0FFckhBLE9BQU9DLFdBQVU7QUFLakIsU0FBUyxpQkFDUixTQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQWE7QUFFYixRQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLE1BQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxRQUFRLE9BQU8sT0FBTztBQUFHLFdBQU87QUFHdEQsTUFBSSxVQUFVLE9BQU8sUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUd0RixNQUFJLENBQUMsU0FBUztBQUNiLGNBQVUsT0FBTyxRQUFRLEtBQUssQ0FBQyxNQUFVO0FBQ3hDLFVBQUksRUFBRSxXQUFXO0FBQU8sZUFBTztBQUMvQixZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLFNBQVMsWUFBWSxFQUFFO0FBQzdCLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0lBQzVELENBQUM7RUFDRjtBQUVBLE1BQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxRQUFRLFFBQVEsT0FBTztBQUFHLFdBQU87QUFHeEQsUUFBTSxjQUFjLFFBQVEsUUFBUSxLQUFLLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUN6RSxNQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sUUFBUSxZQUFZLE9BQU87QUFBRyxXQUFPO0FBR2hFLFFBQU0sU0FBUyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLEtBQUs7QUFDbEUsU0FBTyxRQUFRLFNBQVM7QUFDekI7QUFNTSxTQUFVLGdCQUFnQixNQUFvQjtBQUNuRCxRQUFNQyxpQkFBZ0JELE1BQUssS0FBSyxZQUFZLFNBQVMsWUFBWTtBQUVqRSxRQUFNLGFBQWEsY0FBY0MsY0FBYTtBQUM5QyxRQUFNLGVBQWUsZUFBZUEsY0FBYTtBQUNqRCxRQUFNLFVBQXVDLENBQUE7QUFDN0MsYUFBVyxDQUFDLE9BQU8sSUFBSSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDdkQsWUFBUSxLQUFLLElBQUk7TUFDaEIsT0FBTyxLQUFLO01BQ1osU0FBUyxNQUFNLFFBQVEsS0FBSyxTQUFTLElBQUksS0FBSyxZQUFZLENBQUE7O0VBRTVEO0FBQ0EsUUFBTSxpQkFBc0IsQ0FBQTtBQUc1QixRQUFNLGNBQWMsYUFBYSxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQzFELFVBQVEsSUFDUCxpQ0FBaUMsV0FBVyxzQkFBc0IsS0FBSyxPQUFPLGNBQWMsb0JBQW9CLEtBQUssUUFBUSxNQUFNLEVBQUU7QUFPdEksYUFBVyxDQUFDLFlBQVksUUFBUSxLQUFLLE9BQU8sUUFBUSxZQUFZLEdBQUc7QUFDbEUsVUFBTSxDQUFDLE9BQU8sVUFBVSxLQUFLLElBQUksV0FBVyxNQUFNLEdBQUc7QUFHckQsUUFBSSxVQUFVO0FBQWE7QUFFM0IsVUFBTSxRQUFRLFNBQVMsVUFBVSxFQUFFO0FBQ25DLFVBQU0sU0FBUyxTQUFTLE9BQU8sRUFBRTtBQUdqQyxtQkFBZSxVQUFVLElBQUk7TUFDNUIsR0FBRztNQUNILFVBQVUsQ0FBQyxrQkFBc0I7QUFDaEMsY0FBTSxLQUFLLEtBQUs7QUFDaEIsY0FBTSxRQUFRLGNBQWMsUUFBUSxPQUFPO0FBQzNDLGNBQU0sUUFBUSxjQUFjLFFBQVEsT0FBTyxLQUFLO0FBQ2hELGNBQU0sWUFBWSxTQUFTO0FBQzNCLGNBQU0sVUFBVSxLQUFLLGFBQWEsZ0JBQWdCLElBQUksT0FBTyxXQUFXLEtBQUs7QUFHN0UsY0FBTSxZQUFZLGNBQWMsUUFBUSxXQUFXLEtBQUs7QUFFeEQsWUFBSSxhQUFhLFlBQVksUUFBVztBQUV2QyxpQkFBTyxpQkFBaUIsU0FBUyxPQUFPLE9BQU8sV0FBVyxPQUFPO1FBQ2xFO0FBR0EsZUFBTyxXQUFXO01BQ25COztFQUVGO0FBRUEsT0FBSyx1QkFBdUIsY0FBYztBQUUxQyxVQUFRLElBQUkscUNBQXFDLE9BQU8sS0FBSyxjQUFjLEVBQUUsTUFBTTtBQUNwRjs7O0FDN0dBLE9BQU9DLFlBQVc7QUFDbEIsT0FBT0MsU0FBUTs7O0FDRGYsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sUUFBUTtBQUlmLElBQU1DLFVBQVMsbUJBQW1CLE9BQU87QUFLbEMsSUFBTSx5QkFBeUI7QUFFL0IsSUFBTSwwQkFBMEI7QUFnQmhDLElBQU0scUJBQXFCLE1BQU87QUFpQm5DLFNBQVUsd0JBQXFCO0FBQ3BDLFFBQU0sTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQzlCLFFBQU0sTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssS0FBTTtBQUU3QyxNQUFJLGNBQWMsT0FBUSxDQUFDO0FBQzNCLE1BQUksY0FBYyx3QkFBd0IsQ0FBQztBQUMzQyxNQUFJLGNBQWMsS0FBSyxDQUFDO0FBRXhCLFFBQU0sTUFBTSxpQkFBZ0I7QUFDNUIsTUFBSSxLQUFLLEtBQUssQ0FBQztBQUVmLFNBQU8sS0FBSyxZQUFZLE9BQU8sRUFBRSxLQUFLLEtBQUssRUFBRTtBQUM3QyxNQUFJLGNBQWMsTUFBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFRLEVBQUU7QUFDNUIsTUFBSSxjQUFjLEtBQVksRUFBRTtBQUVoQyxTQUFPO0FBQ1I7QUFHTSxTQUFVLG1CQUFnQjtBQUMvQixNQUFJO0FBQ0gsVUFBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLGVBQVcsUUFBUSxPQUFPLEtBQUssTUFBTSxHQUFHO0FBQ3ZDLGlCQUFXLFFBQVEsT0FBTyxJQUFJLEtBQUssQ0FBQSxHQUFJO0FBQ3RDLFlBQUksQ0FBQyxLQUFLLFlBQVksS0FBSyxXQUFXLFVBQVUsS0FBSyxPQUFPLEtBQUssUUFBUSxxQkFBcUI7QUFDN0YsaUJBQU8sT0FBTyxLQUFLLEtBQUssSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBYyxTQUFTLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDM0U7TUFDRDtJQUNEO0VBQ0QsUUFBUTtFQUVSO0FBQ0EsU0FBTyxPQUFPLE1BQU0sR0FBRyxDQUFDO0FBQ3pCO0FBaUJNLFNBQVUsdUJBQXVCLEtBQWEsT0FBYTtBQUNoRSxNQUFJLElBQUksU0FBUztBQUFvQixXQUFPO0FBQzVDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRLFdBQU87QUFDM0MsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQXlCLFdBQU87QUFDNUQsTUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWSxXQUFPO0FBRWxFLFFBQU0sVUFBVSxDQUFDLFFBQWdCLFFBQ2hDLElBQ0UsU0FBUyxRQUFRLFNBQVMsR0FBRyxFQUM3QixTQUFTLE9BQU8sRUFDaEIsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUNiLEtBQUk7QUFFUCxRQUFNLFFBQVEsSUFBSSxTQUFTLEdBQUcsRUFBRTtBQUNoQyxRQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztBQUM1RSxRQUFNLE1BQU0sU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUc7QUFFekUsUUFBTSxPQUFPLFFBQVEsSUFBTSxFQUFFO0FBQzdCLFFBQU0sZUFBZSxRQUFRLElBQU0sRUFBRTtBQUNyQyxRQUFNLFdBQVcsUUFBUSxLQUFNLEVBQUU7QUFDakMsUUFBTSxXQUFXLEdBQUcsSUFBSSxFQUFJLENBQUMsSUFBSSxJQUFJLEVBQUksQ0FBQztBQUUxQyxNQUFJLENBQUM7QUFBVSxXQUFPO0FBSXRCLFFBQU0sUUFBUSxTQUNaLFFBQVEsY0FBYyxFQUFFLEVBQ3hCLEtBQUksRUFDSixNQUFNLEtBQUssRUFBRSxDQUFDO0FBRWhCLFNBQU8sRUFBRSxJQUFJLE9BQU8sTUFBTSxjQUFjLE9BQU8sS0FBSyxTQUFRO0FBQzdEO0FBTUEsZUFBc0IsOEJBQThCLFFBQWM7QUFDakUsU0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFVBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUVyQyxRQUFJLFdBQVc7QUFDZixRQUFJLEtBQUssU0FBUyxDQUFDLFFBQU87QUFDekIsVUFBSSxDQUFDLFVBQVU7QUFDZCxtQkFBVztBQUNYLFlBQUksTUFBSztBQUNULGVBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzdDO0lBQ0QsQ0FBQztBQUdELFFBQUksUUFBUSxHQUFHLFFBQVEsTUFBSztBQUMzQixVQUFJO0FBQ0gsY0FBTSxPQUFPLElBQUksUUFBTztBQUN4QixjQUFNLFlBQVksS0FBSztBQUN2QixZQUFJLENBQUMsVUFBVTtBQUNkLHFCQUFXO0FBQ1gsY0FBSSxNQUFLO0FBQ1Qsa0JBQVEsU0FBUztRQUNsQjtNQUNELFNBQVMsSUFBSTtBQUNaLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxpQkFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM3QjtNQUNEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQWdCQSxlQUFzQixnQkFDckIsVUFDQSxlQUNBLGtCQUNBLFlBQVksS0FBSTtBQUVoQixRQUFNLHVCQUF1QjtBQUM3QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLGVBQWU7QUFFckIsUUFBTSxRQUFRLG9CQUFJLElBQUc7QUFDckIsUUFBTSxhQUFhLG9CQUFJLElBQUc7QUFFMUIsU0FBTyxJQUFJLFFBQXNCLENBQUMsWUFBVztBQUU1QyxVQUFNLGtCQUFrQixDQUFDLFdBQXNCO0FBQzlDLFVBQUksQ0FBQyxNQUFNLElBQUksT0FBTyxFQUFFLEdBQUc7QUFDMUIsY0FBTSxJQUFJLE9BQU8sSUFBSSxNQUFNO0FBQzNCLHNCQUFjLE1BQU07TUFDckI7SUFDRDtBQUdBLFVBQU0saUJBQWlCLE1BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUUzRSxVQUFNLFVBQVUsTUFBSztBQUNwQixVQUFJO0FBQ0gsdUJBQWUsZUFBZSxvQkFBb0I7TUFDbkQsUUFBUTtNQUVSO0FBQ0EsVUFBSTtBQUNILHVCQUFlLE1BQUs7TUFDckIsUUFBUTtNQUVSO0FBQ0EsY0FBUSxNQUFNLEtBQUssTUFBTSxPQUFNLENBQUUsQ0FBQztJQUNuQztBQUVBLFVBQU0sUUFBUSxXQUFXLFNBQVMsU0FBUztBQUMzQyxVQUFNLFFBQU87QUFFYixtQkFBZSxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2xDLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsSUFBSSxPQUFPLEVBQUU7SUFDcEQsQ0FBQztBQUVELG1CQUFlLEdBQUcsV0FBVyxDQUFDLEtBQUssVUFBUztBQUMzQyxZQUFNLFFBQVEsTUFBTTtBQUVwQixVQUFJLElBQUksU0FBUztBQUFJO0FBQ3JCLFVBQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRO0FBQ3BDLFVBQUksSUFBSSxTQUFTLElBQUksRUFBRSxFQUFFLFNBQVMsT0FBTyxNQUFNO0FBQVk7QUFFM0QsVUFBSSxXQUFXLElBQUksS0FBSztBQUFHO0FBQzNCLGlCQUFXLElBQUksS0FBSztBQUNwQixNQUFBQSxRQUFPLE1BQU0saUJBQWlCLEtBQUssK0JBQTBCO0FBSzdELHVCQUFpQixLQUFLLEVBQ3BCLEtBQUssTUFBSztBQUNWLGNBQU0sUUFBUSxzQkFBcUI7QUFDbkMsaUJBQVMsS0FBSyxPQUFPLGNBQWMsT0FBTyxDQUFDLFFBQU87QUFDakQsY0FBSTtBQUFLLFlBQUFBLFFBQU8sS0FBSyxvQkFBb0IsS0FBSyxZQUFZLElBQUksT0FBTyxFQUFFO1FBQ3hFLENBQUM7TUFDRixDQUFDLEVBQ0EsTUFBTSxDQUFDLFFBQVFBLFFBQU8sS0FBSyx1QkFBdUIsR0FBRyxFQUFFLENBQUM7SUFDM0QsQ0FBQztBQUVELG1CQUFlLEtBQUsscUJBQXFCLE1BQUs7QUFDN0MsVUFBSTtBQUNILHVCQUFlLGNBQWMsb0JBQW9CO0FBQ2pELFFBQUFBLFFBQU8sS0FBSyxvQ0FBb0Msb0JBQW9CLElBQUksbUJBQW1CLEVBQUU7TUFDOUYsU0FBUyxLQUFLO0FBQ2IsUUFBQUEsUUFBTyxLQUFLLDRDQUE0QyxHQUFHLEVBQUU7TUFDOUQ7SUFDRCxDQUFDO0FBR0MsbUJBQXVCLGtCQUFrQjtFQUM1QyxDQUFDO0FBQ0Y7OztBRDNPQSxJQUFNQyxVQUFTLG1CQUFtQixjQUFjO0FBRTFDLElBQU8sZUFBUCxNQUFPLGNBQVk7RUFDUCxjQUFzQjtFQUN0QixpQkFBaUI7RUFDakIsU0FBUztFQUVsQjtFQUNBOztFQUNBO0VBSUEsbUJBQWdDLG9CQUFJLElBQUc7OztFQUd2Qzs7RUFHQSxRQUFnQjtFQUNoQixVQUFzQixDQUFBO0VBQ3RCLHNCQUErQjs7Ozs7Ozs7RUFRL0IsY0FBZ0Qsb0JBQUksSUFBRzs7RUFHdkQscUJBQWdFLG9CQUFJLElBQUc7O0VBR3ZFO0VBRVIsY0FBQTtBQUNDLElBQUFBLFFBQU8sS0FBSywwQkFBMEI7QUFFdEMsU0FBSyxjQUFjLG9CQUFJLElBQUc7QUFJMUIsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDcEUsU0FBSyxVQUFVLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDNUMsV0FBSyxTQUFTLEtBQUssR0FBRyxNQUFLO0FBQzFCLFFBQUFELFFBQU8sTUFBTSwyQkFBNEIsS0FBSyxTQUFTLFFBQU8sRUFBd0IsSUFBSSxFQUFFO0FBQzVGLGdCQUFPO01BQ1IsQ0FBQztJQUNGLENBQUM7QUFDRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBR0QsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFcEUsU0FBSyxTQUFTLEdBQUcsYUFBYSxNQUFLO0FBQ2xDLFlBQU0sT0FBTyxLQUFLLFNBQVMsUUFBTztBQUNsQyxNQUFBRCxRQUFPLE1BQU0sMEJBQTBCLEtBQUssVUFBVSxJQUFJLENBQUMsRUFBRTtBQUM3RCxVQUFJO0FBQ0gsYUFBSyxTQUFTLHFCQUFxQixJQUFJO01BQ3hDLFNBQVMsSUFBSTtNQUViO0lBQ0QsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzFDLFVBQUk7QUFDSCxhQUFLLGVBQWUsS0FBSyxNQUFNLE9BQU87TUFDdkMsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxFQUFFLEVBQUU7TUFDdEQ7SUFDRCxDQUFDO0FBR0QsU0FBSyxTQUFTLEtBQUssRUFBRSxTQUFTLFdBQVcsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2xFLE1BQUFBLFFBQU8sTUFBTSw4QkFBOEIsS0FBSyxNQUFNLEVBQUU7SUFDekQsQ0FBQztFQUNGO0VBRU8sUUFBSztBQUNYLFFBQUk7QUFDSCxpQkFBVyxhQUFhLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixHQUFHO0FBQzFELFlBQUk7QUFDSCxlQUFLLFNBQVMsZUFBZSxLQUFLLGdCQUFnQixTQUFTO1FBQzVELFFBQVE7UUFFUjtNQUNEO0lBQ0QsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7RUFDRDs7Ozs7RUFNTyxTQUFTLE9BQWUsU0FBcUIsc0JBQStCLE1BQUk7QUFDdEYsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVO0FBQ2YsU0FBSyxzQkFBc0I7RUFDNUI7Ozs7O0VBTU8sb0JBQW9CLFVBQXNDO0FBQ2hFLFNBQUssbUJBQW1CO0VBQ3pCOzs7OztFQU1PLE1BQU0sbUJBQW1CLFVBQWdCO0FBQy9DLElBQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsUUFBUSxFQUFFO0FBQ3RELFVBQU0sV0FBVyxNQUFNLEtBQUssYUFDM0IsS0FBSyxPQUNMLHNCQUNBLFFBQ0EsUUFDQSxRQUNBLFVBQ0EsS0FBSztBQUlOLFlBQVEsSUFBSSx3QkFBd0IsU0FBUyxTQUFTLEtBQUssQ0FBQztBQUM1RCxZQUFRLElBQUksb0JBQW9CLFNBQVMsTUFBTTtBQUcvQyxVQUFNLFNBQVMsNEJBQTRCLEtBQUssT0FBTyxRQUFRO0FBQy9ELFlBQVEsSUFBSSwwQkFBMEIsT0FBTyxNQUFNO0FBQ25ELFFBQUksT0FBTyxTQUFTLEdBQUc7QUFDdEIsY0FBUSxJQUFJLHVCQUF1QixPQUFPLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDdEQ7QUFFQSxVQUFNLFdBQVcsb0JBQUksSUFBRztBQUN4QixlQUFXLFdBQVcsUUFBUTtBQUM3QixZQUFNLE1BQU0sY0FBYyxLQUFLLE9BQU8sUUFBUSxRQUFRLFFBQVEsSUFBSSxRQUFRLEtBQUs7QUFFL0UsWUFBTSxRQUNMLFFBQVEsV0FBVyxXQUFXLElBQzFCLFFBQVEsV0FBVyxDQUFDLEtBQUssS0FBTyxRQUFRLFdBQVcsQ0FBQyxLQUFLLElBQUssUUFBUSxXQUFXLENBQUMsSUFDbEYsUUFBUSxXQUFXLENBQUMsS0FBSztBQUM5QixlQUFTLElBQUksS0FBSyxLQUFLO0lBQ3hCO0FBQ0EsU0FBSyxZQUFZLElBQUksVUFBVSxRQUFRO0FBQ3ZDLFdBQU87RUFDUjs7RUFDTyxlQUFlLFVBQWdCO0FBQ3JDLFdBQU8sS0FBSyxZQUFZLElBQUksUUFBUSxLQUFLLG9CQUFJLElBQUc7RUFDakQ7Ozs7Ozs7Ozs7O0VBWU8sTUFBTSxnQkFBZ0IsWUFBWSxLQUFJO0FBRTVDLFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sZUFBNkIsQ0FBQTtBQUVuQyxVQUFNLGdCQUFnQixDQUFDLFdBQXNCO0FBQzVDLG1CQUFhLEtBQUssTUFBTTtJQUN6QjtBQUdBLFNBQUssbUJBQW1CLElBQUksZUFBZSxhQUFhO0FBRXhELFFBQUk7QUFDSCxZQUFNLEtBQUs7QUFHWCxZQUFNO1FBQ0wsS0FBSztRQUNMOztRQUNBLE9BQU8sV0FBVyxLQUFLLG9CQUFvQixNQUFNO1FBQ2pEO01BQVM7QUFFVixhQUFPO0lBQ1I7QUFDQyxXQUFLLG1CQUFtQixPQUFPLGFBQWE7SUFDN0M7RUFDRDs7Ozs7RUFNUSxNQUFNLG9CQUFvQixRQUFjO0FBQy9DLFFBQUk7QUFDSCxZQUFNLFlBQVksTUFBTSw4QkFBOEIsTUFBTTtBQUM1RCxVQUFJLENBQUMsV0FBVztBQUNmLFFBQUFBLFFBQU8sS0FBSyxxREFBcUQsTUFBTSxFQUFFO0FBQ3pFO01BQ0Q7QUFFQSxVQUFJLEtBQUssaUJBQWlCLElBQUksU0FBUyxHQUFHO0FBRXpDO01BQ0Q7QUFFQSxVQUFJO0FBQ0gsYUFBSyxTQUFTLGNBQWMsS0FBSyxnQkFBZ0IsU0FBUztBQUMxRCxhQUFLLGlCQUFpQixJQUFJLFNBQVM7QUFDbkMsUUFBQUEsUUFBTyxLQUFLLG9CQUFvQixLQUFLLGNBQWMsT0FBTyxTQUFTLEVBQUU7TUFDdEUsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxLQUFLLCtCQUErQixTQUFTLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRTtNQUN0RTtJQUNELFNBQVMsSUFBSTtBQUNaLE1BQUFBLFFBQU8sS0FBSywrQkFBK0IsRUFBRSxFQUFFO0lBQ2hEO0VBQ0Q7RUFFTyxNQUFNLGFBQ1osT0FDQSxPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUFJO0FBRWIsVUFBTSxZQUFZO0FBR2xCLFVBQU0sS0FBSyxvQkFBb0IsTUFBTTtBQUVyQyxVQUFNLFlBQXNCLENBQUE7QUFDNUIsUUFBSSxjQUFjO0FBQVcsZ0JBQVUsS0FBSyxZQUFZLEdBQUk7QUFDNUQsUUFBSSxVQUFVO0FBQVcsZ0JBQVUsS0FBSyxHQUFHLGNBQWEsZ0JBQWdCLEtBQUssQ0FBQztBQUU5RSxVQUFNLGNBQXdCLENBQUMsSUFBTSxRQUFRLEdBQUk7QUFFakQsUUFBSSxVQUFVO0FBQVcsa0JBQVksS0FBSyxRQUFRLEdBQUk7QUFDdEQsUUFBSTtBQUFRLGtCQUFZLEtBQUssVUFBVSxNQUFNO0FBRTdDLFFBQUksVUFBVSxTQUFTO0FBQUcsa0JBQVksS0FBSyxHQUFHLFNBQVM7QUFFdkQsVUFBTSxNQUFNLGNBQWEsVUFBVSxXQUFXO0FBQzlDLFVBQU0saUJBQWlCLE9BQU8sS0FBSyxDQUFDLEdBQUcsYUFBYSxHQUFHLENBQUM7QUFFeEQsVUFBTSxXQUFXLEtBQUssZUFBZTtBQUNyQyxVQUFNLFNBQVMsTUFBTSxjQUFhLFlBQVksVUFBVSxNQUFNO0FBQzlELFVBQU0sU0FBUyxPQUFPLE9BQU8sQ0FBQyxRQUFRLGNBQWMsQ0FBQztBQUdyRCxVQUFNLFVBQVUsZUFBZSxLQUFLO0FBQ3BDLFFBQUksY0FBYyxVQUFhLFVBQVUsUUFBVztBQUVuRCxVQUFJLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBRzlFLFVBQUksQ0FBQyxRQUFRO0FBQ1osaUJBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQ2hDLGNBQUksRUFBRSxXQUFXO0FBQU8sbUJBQU87QUFDL0IsZ0JBQU0sV0FBVyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDNUQsY0FBSSxDQUFDO0FBQVUsbUJBQU87QUFDdEIsaUJBQU8sYUFBYSxFQUFFLE1BQU0sWUFBWSxFQUFFLEtBQUs7UUFDaEQsQ0FBQztNQUNGO0FBRUEsVUFBSSxjQUFjLFFBQVEsUUFBUTtBQUdsQyxVQUFJLFFBQVE7QUFDWCxjQUFNLFdBQVcsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ2pFLFlBQUksWUFBWSxjQUFjLE9BQU8sSUFBSTtBQUN4QyxnQkFBTSxnQkFBZ0IsWUFBWSxPQUFPO0FBQ3pDLHdCQUFjLEdBQUcsV0FBVyxNQUFNLGdCQUFnQixDQUFDO1FBQ3BEO01BQ0Q7QUFHQSxZQUFNLGNBQWMsUUFBUSxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3JFLFlBQU0sVUFBVSxhQUFhO0FBQzdCLFlBQU0sYUFBYSxjQUFhLGdCQUFnQixLQUFLO0FBQ3JELFlBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxZQUFNLGNBQWMsV0FBVyxhQUFhLFNBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7QUFFeEcsWUFBTSxTQUFTLEtBQUssTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ3ZELFlBQU0sUUFBUSxLQUFLLFVBQVUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUMxRCxZQUFNLFNBQVMsS0FBSyxXQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDO0FBQ25GLFlBQU0sU0FBUyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSSxXQUFXLEtBQUssR0FBRztBQUU1RSxZQUFNLFNBQVMsT0FBTyxNQUFNLE9BQU8sS0FBSyxRQUFRLE1BQU07QUFDdEQsWUFBTSxTQUFTLGNBQWMsR0FBRyxXQUFXLEtBQUssV0FBVyxLQUFLLE1BQU0sTUFBTSxHQUFHLFdBQVcsS0FBSyxNQUFNO0FBRXJHLE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxFQUFFO0lBQ25ELE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sT0FBTyxFQUFFO0lBQ3hDO0FBQ0EsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixNQUFNLEtBQUssT0FBTyxTQUFTLEtBQUssQ0FBQyxFQUFFO0FBRXJFLFVBQU0sS0FBSztBQUVYLFVBQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxLQUFLO0FBRTlCLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxZQUFNLFFBQVEsV0FBVyxNQUFLO0FBQzdCLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZUFBTyxJQUFJLE1BQU0scUNBQXFDLEtBQUssT0FBTyxNQUFNLE9BQU8sQ0FBQztNQUNqRixHQUFHLFNBQVM7QUFFWixXQUFLLFlBQVksSUFBSSxLQUFLO1FBQ3pCLFNBQVMsQ0FBQyxRQUFPO0FBQ2hCLHVCQUFhLEtBQUs7QUFHbEIsY0FBSSxLQUFLLHVCQUF1QixjQUFjLFFBQVc7QUFDeEQsaUJBQUssbUJBQW1CLE1BQU0sRUFBRSxNQUFNLENBQUMsUUFBTztBQUM3QyxjQUFBQSxRQUFPLEtBQUssNkNBQTZDLEdBQUcsRUFBRTtZQUMvRCxDQUFDO1VBQ0Y7QUFFQSxrQkFBUSxHQUFHO1FBQ1o7UUFDQSxRQUFRLENBQUMsUUFBTztBQUNmLHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sR0FBRztRQUNYO1FBQ0E7T0FDQTtBQUVELFdBQUssU0FBUyxLQUFLLFFBQVEsS0FBSyxhQUFhLFFBQVEsQ0FBQyxRQUFPO0FBQzVELFlBQUksS0FBSztBQUNSLGVBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDN0M7TUFDRCxDQUFDO0lBQ0YsQ0FBQztFQUNGO0VBRVEsZUFBZSxLQUFhLE9BQWE7QUFDaEQsUUFBSSxJQUFJLFNBQVM7QUFBRztBQUNwQixRQUFJLElBQUksQ0FBQyxNQUFNLE9BQVEsSUFBSSxDQUFDLE1BQU07QUFBTTtBQUV4QyxVQUFNLFVBQVUsSUFBSSxhQUFhLENBQUM7QUFLbEMsUUFBSSxZQUFZLDJCQUEyQixLQUFLLG1CQUFtQixPQUFPLEdBQUc7QUFDNUUsWUFBTSxTQUFTLHVCQUF1QixLQUFLLEtBQUs7QUFDaEQsVUFBSSxRQUFRO0FBQ1gsbUJBQVcsTUFBTSxLQUFLLG1CQUFtQixPQUFNLEdBQUk7QUFDbEQsY0FBSTtBQUNILGVBQUcsTUFBTTtVQUNWLFFBQVE7VUFFUjtRQUNEO01BQ0Q7QUFDQTtJQUNEO0FBRUEsUUFBSSxJQUFJLFNBQVM7QUFBSTtBQUdyQixVQUFNLE1BQU0sSUFBSSxTQUFTLElBQUksRUFBRTtBQUMvQixRQUFJLElBQUksU0FBUyxPQUFPLE1BQU07QUFBWTtBQUkxQyxVQUFNLFlBQVksSUFBSSxTQUFTLEVBQUU7QUFDakMsUUFBSSxVQUFVLFNBQVM7QUFBRztBQUMxQixRQUFJLFVBQVUsQ0FBQyxNQUFNO0FBQU07QUFHM0IsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLGNBQWMsWUFBWSxTQUFVO0FBQzFDLFVBQU0sZ0JBQWdCLFlBQVk7QUFHbEMsU0FBSyxhQUFhLE9BQU8sZUFBZSxLQUFLLFdBQVcsVUFBVTtBQUdsRSxRQUFJLFlBQVk7QUFDZixZQUFNLE1BQU0sR0FBRyxLQUFLLElBQUksYUFBYTtBQUNyQyxZQUFNLFVBQVUsS0FBSyxZQUFZLElBQUksR0FBRztBQUN4QyxVQUFJLFNBQVM7QUFDWixhQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLGdCQUFRLFFBQVEsR0FBRztNQUNwQjtJQUNEO0VBRUQ7Ozs7Ozs7Ozs7OztFQWFRLGFBQWEsT0FBZSxPQUFlLEtBQWEsV0FBbUIsYUFBYSxNQUFJO0FBQ25HLFVBQU0sVUFBVSxTQUFTLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUM1RCxVQUFNLE9BQU8sVUFBVSxTQUFTLEdBQUcsVUFBVSxTQUFTLENBQUM7QUFHdkQsVUFBTSxRQUFRLFVBQVUsQ0FBQztBQUN6QixVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxDQUFDO0FBQzFDLFVBQU0sZ0JBQWdCLFlBQVksTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLFVBQVUsVUFBVSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLFNBQVMsS0FBSyxTQUFTLEtBQUssQ0FBQyxVQUFVLElBQUksU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUc5TCxVQUFNLFlBQVksYUFBYSxPQUFPO0FBS3RDLFFBQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBSSxDQUFDLEtBQUssT0FBTztBQUNoQixRQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7QUFDbkU7TUFDRDtBQUNBLFVBQUk7QUFDSCxjQUFNLFdBQ0wsVUFBVSxvQkFDUCxzQkFBc0IsS0FBSyxPQUFPLEdBQUcsSUFDckMsNEJBQTRCLEtBQUssT0FBTyxHQUFHO0FBRS9DLGNBQU0sWUFBWSxLQUFLLFlBQVksSUFBSSxLQUFLLEtBQUssb0JBQUksSUFBRztBQUN4RCxjQUFNLFdBQVcsSUFBSSxJQUFvQixTQUFTO0FBRWxELG1CQUFXLEtBQUssVUFBVTtBQUN6QixnQkFBTSxXQUFXLGNBQWMsS0FBSyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLO0FBRWxFLGdCQUFNLFdBQ0wsRUFBRSxXQUFXLFdBQVcsSUFDcEIsRUFBRSxXQUFXLENBQUMsS0FBSyxLQUFPLEVBQUUsV0FBVyxDQUFDLEtBQUssSUFBSyxFQUFFLFdBQVcsQ0FBQyxJQUNoRSxFQUFFLFdBQVcsQ0FBQyxLQUFLO0FBQ3hCLGdCQUFNLFlBQVksVUFBVSxJQUFJLFFBQVE7QUFDeEMsZ0JBQU0sVUFBVSxjQUFjLFVBQWEsY0FBYztBQUV6RCxtQkFBUyxJQUFJLFVBQVUsUUFBUTtBQUUvQixnQkFBTSxZQUFZLG9CQUFvQixHQUFHLEtBQUssT0FBTztBQUNyRCxjQUFJLFNBQVM7QUFDWixZQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLFNBQVMsRUFBRTtBQUVsRCxnQkFBSSxLQUFLLGtCQUFrQjtBQUMxQixtQkFBSyxpQkFBaUIsUUFBUTtZQUMvQjtVQUNELE9BQU87QUFDTixZQUFBQSxRQUFPLE1BQU0sR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLFNBQVMsRUFBRTtVQUNwRDtRQUNEO0FBQ0EsYUFBSyxZQUFZLElBQUksT0FBTyxRQUFRO01BQ3JDLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxHQUFHLFNBQVMsSUFBSSxLQUFLLE1BQU0sT0FBTyxvQkFBb0IsQ0FBQyxNQUFNLGFBQWEsRUFBRTtNQUN6RjtBQUNBO0lBQ0Q7QUFHQSxVQUFNLFVBQVUsS0FBSyxhQUFhLE9BQU8sSUFBSTtBQUM3QyxRQUFJLFNBQVM7QUFDWixNQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLE1BQU0sT0FBTyxFQUFFO0lBQ2pGLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7SUFDcEU7RUFDRDs7Ozs7Ozs7RUFTUSxhQUFhLE9BQWUsTUFBWTtBQUMvQyxRQUFJLEtBQUssV0FBVztBQUFHLGFBQU87QUFHOUIsUUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixVQUFJLEtBQUssQ0FBQyxNQUFNLEdBQU07QUFDckIsZUFBTztNQUNSLE9BQU87QUFDTixlQUFPLFdBQVcsS0FBSyxDQUFDLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztNQUN4RDtJQUNEO0FBRUEsWUFBUSxPQUFPOzs7OztNQUtkLEtBQUssY0FBYztBQUNsQixZQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLGlCQUFPLEtBQUssQ0FBQyxNQUFNLElBQU8sV0FBVyxhQUFhLEtBQUssQ0FBQyxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUM7UUFDeEY7QUFDQSxZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsYUFBYSxVQUFVLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDeEYsZ0JBQU0sVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0FBQ3RDLGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGNBQ2QsR0FBRyxXQUFXLE9BQU8sU0FBVSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLE1BQzVELEtBQUssTUFBTSxLQUFLLFVBQVUsRUFDekIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxDQUFDO0FBQ1osZ0JBQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxNQUFNLFVBQVUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxPQUFPLE1BQU0sS0FDakgsVUFBVSxFQUVULElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUUsQ0FBQztBQUNWLGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRLElBQUksTUFBTTtRQUNoRTtBQUNBLGVBQU8sUUFBUSxLQUFLLFNBQVMsS0FBSyxDQUFDO01BQ3BDOztNQUdBLEtBQUssaUJBQWlCO0FBRXJCLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDckIsZ0JBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsZ0JBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsZ0JBQU0sYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNsQyxnQkFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUNoRixnQkFBTSxjQUFjLFFBQVEsUUFBUSxhQUFhLFVBQVUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUN4RixnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLFVBQVUsUUFBUSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEdBQUc7QUFDaEUsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGVBQWUsS0FBSyxXQUFXLFNBQVMsS0FBSyxDQUFDO0FBQy9ELGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRO1FBQ3REO0FBQ0EsZUFBTztNQUNSOztNQUdBLEtBQUs7TUFDTCxLQUFLLGFBQWE7QUFDakIsWUFBSSxLQUFLLFNBQVM7QUFBRyxpQkFBTztBQUM1QixjQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGNBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsY0FBTSxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQzdCLGVBQU8sTUFBTSxLQUFLLGNBQWMsVUFBVSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLFVBQVUsTUFBTSxTQUFTLEtBQUssQ0FBQztNQUN2RztNQUVBO0FBQ0MsZUFBTztJQUNUO0VBQ0Q7RUFFUSxPQUFPLGdCQUFnQixPQUFjO0FBQzVDLFFBQUksT0FBTyxVQUFVO0FBQVcsYUFBTyxDQUFDLFFBQVEsSUFBSSxDQUFDO0FBQ3JELFFBQUksTUFBTSxRQUFRLEtBQUs7QUFBRyxhQUFPLE1BQU0sSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDLElBQUksR0FBSTtBQUNsRSxRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzlCLFVBQUksUUFBUTtBQUFNLGVBQU8sQ0FBRSxTQUFTLEtBQU0sS0FBTyxTQUFTLElBQUssS0FBTSxRQUFRLEdBQUk7QUFDakYsYUFBTyxDQUFDLFFBQVEsR0FBSTtJQUNyQjtBQUNBLFVBQU0sSUFBSSxNQUFNLDRDQUE0QyxLQUFLLEVBQUU7RUFDcEU7RUFFUSxhQUFhLHFCQUFxQixRQUFjO0FBQ3ZELFdBQU8sSUFBSSxRQUFrQixDQUFDLFNBQVMsV0FBVTtBQUNoRCxZQUFNLE1BQU1DLE9BQU0sYUFBYSxNQUFNO0FBRXJDLFVBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixZQUFJLE1BQUs7QUFDVCxlQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztNQUM3QyxDQUFDO0FBRUQsVUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFlBQUk7QUFDSCxnQkFBTSxPQUFPLElBQUksUUFBTztBQUN4QixnQkFBTSxZQUFZLEtBQUs7QUFFdkIsY0FBSSxNQUFLO0FBRVQsZ0JBQU0sU0FBU0MsSUFBRyxrQkFBaUI7QUFDbkMscUJBQVcsUUFBUSxPQUFPLEtBQUssTUFBTSxHQUFHO0FBQ3ZDLHVCQUFXLFNBQVMsT0FBTyxJQUFJLEtBQUssQ0FBQSxHQUFJO0FBQ3ZDLGtCQUNDLE1BQU0sV0FBVyxVQUNqQixNQUFNLFlBQVksYUFDbEIsTUFBTSxPQUNOLE1BQU0sUUFBUSxxQkFDYjtBQUNELHVCQUFPLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLFNBQVMsR0FBRyxFQUFFLElBQUksR0FBSSxDQUFDO2NBQ3ZFO1lBQ0Q7VUFDRDtBQUVBLGlCQUFPLElBQUksTUFBTSx3Q0FBd0MsU0FBUyxFQUFFLENBQUM7UUFDdEUsU0FBUyxJQUFJO0FBQ1osaUJBQU8sSUFBSSxNQUFNLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDN0I7TUFDRCxDQUFDO0lBQ0YsQ0FBQztFQUNGO0VBRVEsYUFBYSxZQUFZLFVBQWtCLFFBQWM7QUFDaEUsVUFBTSxNQUFNLE1BQU0sY0FBYSxxQkFBcUIsTUFBTTtBQUUxRCxXQUFPLE9BQU8sT0FBTztNQUNwQixPQUFPLEtBQUssQ0FBQyxLQUFNLEtBQU0sR0FBTSxXQUFXLEtBQU0sR0FBTSxLQUFNLEdBQU0sR0FBTSxHQUFHLEtBQUssR0FBTSxDQUFJLENBQUM7TUFDM0YsT0FBTyxLQUFLLFlBQVksTUFBTTtLQUM5QjtFQUNGO0VBRVEsT0FBTyxVQUFVLE1BQWM7QUFDdEMsUUFBSSxNQUFNO0FBQ1YsZUFBVyxLQUFLLE1BQU07QUFDckIsYUFBTztBQUNQLGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0FBQzNCLGVBQU8sTUFBTSxTQUFVLEtBQU0sT0FBTyxJQUFLLE9BQVEsTUFBUSxPQUFPLElBQUs7TUFDdEU7SUFDRDtBQUNBLFdBQU87RUFDUjs7Ozs7Ozs7OztFQVdPLGdCQUFnQixJQUFZLE9BQWUsV0FBbUIsT0FBYztBQUNsRixVQUFNLE1BQU0sY0FBYyxLQUFLLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDN0QsV0FBTyxLQUFLLFlBQVksSUFBSSxFQUFFLEdBQUcsSUFBSSxHQUFHO0VBQ3pDO0VBRU8sTUFBTSxZQUFZLE9BQWUsUUFBYztBQUNyRCxXQUFPLEtBQUssYUFBYSxPQUFPLGtCQUFrQixRQUFXLEdBQU0sUUFBVyxRQUFRLEtBQUs7RUFDNUY7RUFFTyxNQUFNLGNBQWMsT0FBZSxRQUFjO0FBQ3ZELFdBQU8sS0FBSyxhQUFhLE9BQU8scUJBQXFCLFFBQVcsUUFBVyxRQUFXLFFBQVEsS0FBSztFQUNwRzs7OztBZnpxQkQsSUFBTUMsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBQ2xELElBQU1DLGlCQUFnQkMsTUFBSyxLQUFLLFlBQVksU0FBUyxZQUFZO0FBTWpFLElBQXFCLGlCQUFyQixjQUE0QyxhQUF5QjtFQUNwRTs7RUFDQTs7O0VBSVEsb0JBQWtDLENBQUE7RUFFMUMsWUFBWSxVQUFpQjtBQUM1QixVQUFNLFFBQVE7RUFDZjtFQUVBLE1BQU0sS0FBSyxRQUFvQjtBQUM5QixTQUFLLFNBQVM7QUFDZCxRQUFJLENBQUMsS0FBSyxjQUFjO0FBQ3ZCLFdBQUssZUFBZSxJQUFJLGFBQVk7SUFDckM7QUFDQSxTQUFLLGFBQWEsZUFBZSxFQUFFO0FBR25DLFNBQUssb0JBQW9CLE1BQU0sS0FBSyxhQUFhLGdCQUFlO0FBQ2hFLFFBQUksS0FBSyxrQkFBa0IsV0FBVyxHQUFHO0FBQ3hDLE1BQUFGLFFBQU8sS0FBSyx1QkFBdUI7SUFDcEMsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxjQUFjLEtBQUssa0JBQWtCLE1BQU0sYUFBYTtBQUNwRSxpQkFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3ZDLFFBQUFBLFFBQU8sS0FBSyxhQUFhLEVBQUUsS0FBSyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRTtNQUNyRTtJQUNEO0FBSUEsVUFBTSxpQkFBaUIsYUFBYSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7QUFDdkUsU0FBSyxVQUFVLGNBQWM7QUFHN0IsU0FBSyxhQUFhLG9CQUFvQixDQUFDLGVBQXNCO0FBQzVELFdBQUssZUFBZSxVQUFVO0lBQy9CLENBQUM7QUFHRCxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUc5QixVQUFNLGFBQWEsS0FBSztBQUN4QixRQUFJLFlBQVk7QUFDZixVQUFJO0FBQ0gsY0FBTSxLQUFLLGFBQWEsbUJBQW1CLFVBQVU7TUFDdEQsU0FBUyxHQUFHO0FBQ1gsUUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxVQUFVLEtBQUssQ0FBQyxFQUFFO01BQ2xFO0lBQ0Q7RUFDRDs7RUFHQSxNQUFNLFVBQU87QUFDWixTQUFLLGNBQWMsTUFBSztBQUN4QixJQUFBQSxRQUFPLE1BQU0sU0FBUztFQUN2QjtFQUVBLE1BQU0sY0FBYyxRQUFvQjtBQUN2QyxVQUFNLGVBQWUsS0FBSztBQUMxQixTQUFLLFNBQVM7QUFDZCxVQUFNLGlCQUFpQixhQUFhLFFBQVEsS0FBSyxpQkFBaUI7QUFDbEUsU0FBSyxVQUFVLGNBQWM7QUFHN0IsU0FBSyxjQUFhO0FBQ2xCLFNBQUssZ0JBQWU7QUFDcEIsU0FBSywwQkFBeUI7QUFHOUIsVUFBTSxVQUFVLEtBQUs7QUFDckIsUUFBSSxXQUFXLFlBQVksY0FBYztBQUN4QyxVQUFJO0FBQ0gsY0FBTSxLQUFLLGFBQWEsbUJBQW1CLE9BQU87TUFDbkQsU0FBUyxHQUFHO0FBQ1gsUUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxPQUFPLEtBQUssQ0FBQyxFQUFFO01BQy9EO0lBQ0Q7RUFDRDs7RUFHUSxVQUFVLE9BQWE7QUFDOUIsVUFBTSxFQUFFLFNBQVMsb0JBQW1CLElBQUssZ0JBQWdCQyxnQkFBZSxLQUFLO0FBQzdFLFNBQUssYUFBYSxTQUFTLE9BQU8sU0FBUyxtQkFBbUI7QUFDOUQsUUFBSSxRQUFRLFdBQVcsR0FBRztBQUN6QixNQUFBRCxRQUFPLEtBQUssK0JBQStCLEtBQUssNkNBQXdDO0lBQ3pGLE9BQU87QUFDTixNQUFBQSxRQUFPLE1BQU0sVUFBVSxRQUFRLE1BQU0sdUJBQXVCLEtBQUssMEJBQTBCLG1CQUFtQixFQUFFO0lBQ2pIO0VBQ0Q7Ozs7RUFLQSxrQkFBZTtBQUNkLFdBQU8sZ0JBQWdCLEtBQUssaUJBQWlCO0VBQzlDOztFQUdBLElBQUksT0FBSTtBQUNQLFdBQU8sWUFBWSxLQUFLLE1BQU07RUFDL0I7O0VBR0EsSUFBSSxVQUFPO0FBQ1YsV0FBTyxLQUFLO0VBQ2I7RUFFQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSxrQkFBZTtBQUNkLG9CQUFnQixJQUFJO0VBQ3JCO0VBRUEsNEJBQXlCO0FBQ3hCLDhCQUEwQixJQUFJO0VBQy9COzsiLAogICJuYW1lcyI6IFsicGF0aCIsICJwYXRoIiwgIkluc3RhbmNlU3RhdHVzIiwgIlJlZ2V4IiwgImZzIiwgInBhdGgiLCAiZGV2aWNlc0ZvbGRlciIsICJwYXRoIiwgImZzIiwgInBhdGgiLCAiZnMiLCAiZnMiLCAicGF0aCIsICJwYXRoIiwgImZzIiwgImZzIiwgImRldmljZXNGb2xkZXIiLCAicGF0aCIsICJmcyIsICJkZXZpY2VzRm9sZGVyIiwgInBhdGgiLCAiZnMiLCAicGF0aCIsICJkZXZpY2VzRm9sZGVyIiwgImRncmFtIiwgIm9zIiwgImxvZ2dlciIsICJsb2dnZXIiLCAiZGdyYW0iLCAib3MiLCAibG9nZ2VyIiwgImRldmljZXNGb2xkZXIiLCAicGF0aCJdCn0K
