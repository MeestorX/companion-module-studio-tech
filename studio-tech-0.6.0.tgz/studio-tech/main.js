import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual (enter IP + model below)" },
    ...discoveredDevices.map((d) => ({
      id: d.mac ?? "",
      label: `Model ${d.model} [${d.mac}] @ ${d.ip}`
    }))
  ];
  return [
    // ── Device selection dropdown ────────────────────────────────────────
    // Stores the MAC so re-discovery with a changed IP still matches.
    {
      type: "dropdown",
      id: "deviceMac",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry — only visible in manual mode ────────────────────
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Manual model selector — only visible in manual mode ──────────────
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Select which Studio Technologies model is active for actions and feedbacks."
    }
  ];
}
function resolveHost(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    return device?.ip ?? "";
  }
  return String(config.host ?? "");
}
function resolveModel(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    logger.debug(`resolveModel: deviceMac="${config.deviceMac}", found device: ${device?.model ?? "none"}`);
    return device?.model ?? "";
  }
  logger.debug(`resolveModel: manual mode, activeModel="${config.activeModel}"`);
  return String(config.activeModel ?? "");
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_MIC_PRE = 2;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_MIC_PRE:
      return "Mic Preamp";
    case CMD_BUS_GET:
      return "Heartbeat";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "static-text":
      return { ...base, value: o.value ?? "" };
    case "textinput":
    case "colorpicker":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      if (a.readonly === true)
        continue;
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  const commandsRawValue = [CMD_MIC_PRE];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    const isRawValue = commandsRawValue.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (isRawValue) {
      busCh = buf[p + 2];
      const rawBytes = buf.subarray(p + 3, sectionEnd);
      const schema = getDeviceSchema(model);
      const micPreEntries = (schema?.cmdSchema ?? []).filter((a) => (a.cmd_id === CMD_MIC_PRE || a.cmd_id === CMD_MIC_PRE_BUS) && a.busCh !== void 0).sort((a, b) => a.id - b.id);
      for (let i = 0; i < rawBytes.length; i++) {
        const entry = micPreEntries[i];
        if (entry) {
          out.push({ cmd_id: entry.cmd_id, id: entry.id, busCh, valueBytes: [rawBytes[i]] });
        }
      }
      p = sectionEnd;
      continue;
    } else if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    const qStart = q;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    if (q === qStart && sectionEnd > p + 3) {
      let pos = hasBusCh ? p + 3 : p + 2;
      let posId = 0;
      while (pos < sectionEnd) {
        const setting = { cmd_id: sectionCmdId, id: posId++, valueBytes: [buf[pos++]] };
        if (busCh !== void 0)
          setting.busCh = busCh;
        out.push(setting);
      }
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  const idAddDeferRanges = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    for (const baseEntry of c.cmdSchema ?? []) {
      const idAddOpt = baseEntry.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        continue;
      const baseId = baseEntry.id;
      const cmdId = baseEntry.cmd_id;
      const key = `${cmdId}_${baseId}`;
      if (idAddDeferRanges.has(key))
        continue;
      const parsedOffsets = parsed.filter((p) => p.cmd_id === cmdId && p.id > baseId).map((p) => p.id - baseId).sort((a, b) => a - b);
      let maxSeq = 0;
      for (const off of parsedOffsets) {
        if (off === maxSeq + 1)
          maxSeq = off;
        else if (off > maxSeq + 1)
          break;
      }
      if (maxSeq > 0) {
        idAddDeferRanges.set(key, maxSeq);
        logger2.debug(`idAdd defer range for cmd_id=${toHex(cmdId)} base_id=${toHex(baseId)}: offsets 1\u2013${maxSeq}`);
      }
    }
  }
  const busChSeen = /* @__PURE__ */ new Map();
  for (const { cmd_id, id, busCh } of parsed) {
    if (busCh === void 0)
      continue;
    const key = `${cmd_id}_${id}`;
    if (!busChSeen.has(key))
      busChSeen.set(key, /* @__PURE__ */ new Set());
    busChSeen.get(key).add(busCh);
  }
  for (const { cmd_id, id, busCh, valueBytes } of parsed) {
    const existingExact = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (existingExact) {
      const opt = existingExact.options?.find((o) => o.id === "value");
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
      continue;
    }
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt = a.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        return false;
      if (id <= a.id)
        return false;
      const offset = id - a.id;
      return candidates.some((c) => {
        const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === a.id);
        const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
        return refIdAdd?.choices?.some((ch) => ch.id === offset);
      });
    });
    if (idAddBase) {
      const offset = id - idAddBase.id;
      const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
      if (idAddOpt?.choices && !idAddOpt.choices.some((c) => c.id === offset)) {
        let label = `Channel ${offset + 1}`;
        for (const c of candidates) {
          const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
          const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
          const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
          if (refChoice) {
            label = refChoice.label;
            break;
          }
        }
        idAddOpt.choices.push({ id: offset, label });
        logger2.info(`Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
      }
      continue;
    }
    let action;
    for (const c of candidates) {
      const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
      if (match) {
        action = structuredClone(match);
        const baseName = match.name.replace(/\s*\(inferred from Model [^)]+\)/g, "").trim();
        action.name = `${baseName} (inferred from Model ${c.model})`;
        logger2.info(`Inferred cmd_id=${toHex(cmd_id)} id=${toHex(id)} from Model ${c.model} (exact)`);
        break;
      }
    }
    if (!action) {
      let shouldDefer = false;
      for (const c of candidates) {
        const baseEntry = c.cmdSchema?.find((a) => {
          if (a.cmd_id !== cmd_id)
            return false;
          const idAddOpt = a.options?.find((o) => o.id === "idAdd");
          if (!idAddOpt?.choices)
            return false;
          if (id <= a.id)
            return false;
          const offset = id - a.id;
          const maxSeq = idAddDeferRanges.get(`${cmd_id}_${a.id}`) ?? 0;
          return offset <= maxSeq;
        });
        if (baseEntry) {
          shouldDefer = true;
          logger2.debug(`cmd_id=${toHex(cmd_id)} id=${toHex(id)} is an idAdd offset of candidate base id=${toHex(baseEntry.id)} \u2014 deferring to pass 2`);
          break;
        }
      }
      if (shouldDefer)
        continue;
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown cmd:${toHex(cmd_id)} id:${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      if (busCh !== void 0)
        action.busCh = busCh;
      logger2.warn(`Could not infer cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
    } else {
      action.options = action.options?.filter((o) => o.id !== "busCh") ?? [];
      delete action.busCh;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        if (maxBusCh === 0) {
          action.busCh = 0;
        } else {
          const busChChoices = Array.from({ length: maxBusCh + 1 }, (_, i) => ({
            id: i,
            label: `Channel ${i + 1}`
          }));
          action.options.unshift({
            id: "busCh",
            label: "Channel",
            type: "dropdown",
            choices: busChChoices,
            default: 0
          });
        }
      }
      const observedDefault = valueBytesToOption(valueBytes).default;
      const valueOpt = action.options?.find((o) => o.id === "value");
      if (valueOpt) {
        if (valueOpt.choices && Array.isArray(valueOpt.choices)) {
          const inChoices = valueOpt.choices.some((c) => c.id === observedDefault);
          if (!inChoices) {
            logger2.warn(`Inferred choices for cmd_id=${toHex(cmd_id)} id=${toHex(id)} don't contain observed value ${observedDefault} \u2014 discarding inherited choices`);
            valueOpt.type = "number";
            delete valueOpt.choices;
          }
        }
        valueOpt.default = observedDefault;
      }
    }
    out.cmdSchema.push(action);
  }
  for (const { cmd_id, id } of parsed) {
    const alreadyTopLevel = out.cmdSchema.some((a) => a.cmd_id === cmd_id && a.id === id);
    if (alreadyTopLevel)
      continue;
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt2 = a.options?.find((o) => o.id === "idAdd");
      return !!idAddOpt2?.choices && id > a.id;
    });
    if (!idAddBase)
      continue;
    const offset = id - idAddBase.id;
    const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
    if (!idAddOpt?.choices || idAddOpt.choices.some((c) => c.id === offset))
      continue;
    const refHasOffset = candidates.some((c) => {
      const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      return refIdAdd?.choices?.some((ch) => ch.id === offset);
    });
    const existingOffsets = idAddOpt.choices.map((c) => c.id).sort((a, b) => a - b);
    const isSequential = existingOffsets.length > 0 && offset === existingOffsets[existingOffsets.length - 1] + 1;
    if (!refHasOffset && !isSequential)
      continue;
    let label = `Channel ${offset + 1}`;
    for (const c of candidates) {
      const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
      if (refChoice) {
        label = refChoice.label;
        break;
      }
    }
    idAddOpt.choices.push({ id: offset, label });
    logger2.info(`Pass 2: Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("refreshAfterCommand" in jsonObj) {
      orderedObj.refreshAfterCommand = jsonObj.refreshAfterCommand;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema.map((entry) => {
        const orderedEntry = {};
        if ("cmd_id" in entry)
          orderedEntry.cmd_id = entry.cmd_id;
        if ("id" in entry)
          orderedEntry.id = entry.id;
        if ("busCh" in entry)
          orderedEntry.busCh = entry.busCh;
        if ("name" in entry)
          orderedEntry.name = entry.name;
        if ("options" in entry)
          orderedEntry.options = entry.options;
        for (const key of Object.keys(entry)) {
          if (!(key in orderedEntry))
            orderedEntry[key] = entry[key];
        }
        return orderedEntry;
      });
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  wiredActions["global_getAllSettings"] = {
    name: "GLOBAL: Get All Settings (Auto-Update JSON)",
    options: [],
    callback: async () => {
      const model = activeModel;
      const ip = self.host;
      const buf = await self.stController.requestAllSettings(ip);
      let modelJson = getDeviceSchema(model);
      const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
      logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
      if (!modelJson) {
        logger3.info(`Model ${model} has no schema \u2014 creating new JSON from settings`);
        modelJson = {
          model,
          sectioned: detectedSectioned ?? false,
          refreshAfterCommand: true,
          cmdSchema: []
        };
      } else if (detectedSectioned !== null) {
        logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
        modelJson = { ...modelJson, sectioned: detectedSectioned };
      }
      const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
      logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
      const devicesFolder2 = getDevicesFolder();
      const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
      saveModelJsonPretty(schemaPath, updated);
      reloadDeviceSchemas();
      logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
    }
  };
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
          await self.stController.requestAllSettings(ip).catch((err) => {
            logger3.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
}

// dist/feedbacks.js
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        let busCh = feedbackEvent.options["busCh"];
        if (busCh === void 0) {
          const schemaAction = findActionForSetting(schemas, model, cmdId, settingId);
          if (schemaAction?.busCh !== void 0) {
            busCh = schemaAction.busCh;
          }
        }
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
}

// dist/stcontroller.js
import dgram2 from "dgram";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger4 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger4.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger4.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger4.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger4.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger4.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger4.warn(`Could not join announce multicast group: ${err}`);
      }
    });
  });
}

// dist/stcontroller.js
var logger5 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  constructor() {
    logger5.info("StController initialized");
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger5.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger5.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger5.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger5.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger5.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger5.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger5.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    logger5.debug(`Revoked device at ${ip}`);
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    return new Promise((resolve) => {
      const key = `__probe_${ip}__`;
      let resolved = false;
      const finish = (result) => {
        if (resolved)
          return;
        resolved = true;
        this.discoveryListeners.delete(key);
        resolve(result);
      };
      this.discoveryListeners.set(key, (device) => {
        if (device.ip === ip)
          finish(device);
      });
      const timer = setTimeout(() => finish(null), timeoutMs);
      timer.unref?.();
      const run = async () => {
        await this.ensureMembershipFor(ip);
        await this.txReady;
        const query = buildDanteInfoRequest();
        this.txSocket.send(query, this.defaultPort, ip, (err) => {
          if (err) {
            logger5.warn(`Probe to ${ip} failed: ${err.message}`);
            clearTimeout(timer);
            finish(null);
          }
        });
      };
      run().catch((e) => {
        logger5.warn(`probeDevice setup failed for ${ip}: ${e}`);
        clearTimeout(timer);
        finish(null);
      });
    });
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger5.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger5.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger5.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger5.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger5.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger5.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger5.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger5.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && this.refreshAfterCommand && value !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger5.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (cmdId === CMD_MIC_PRE && busCh !== void 0 && settingId !== void 0 && value !== void 0) {
      if (!this.deviceState.has(destIp))
        this.deviceState.set(destIp, /* @__PURE__ */ new Map());
      const ipState = this.deviceState.get(destIp);
      const numPositions = 3;
      const positions = [];
      for (let i = 0; i < numPositions; i++) {
        const stateKey = makeSettingId(this.model, CMD_MIC_PRE, i, busCh);
        const val = i === settingId ? Number(value) : ipState.get(stateKey) ?? 0;
        positions.push(val);
        ipState.set(stateKey, val);
      }
      payloadBody.push(busCh & 255, ...positions);
    } else {
      if (busCh !== void 0)
        payloadBody.push(busCh & 255);
      if (addLen)
        payloadBody.push(dataBlock.length);
      if (dataBlock.length > 0)
        payloadBody.push(...dataBlock);
    }
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger5.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger5.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    if (!this.authorizedIps.has(destIp)) {
      logger5.debug(`Packet (not sent \u2014 device not authorized) to ${destIp}: ${payloadWithCrc.toString("hex")}`);
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    await this.ensureMembershipFor(destIp);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    logger5.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger5.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger5.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse && originalCmdId === CMD_GET_ALL_SETTINGS) {
      logger5.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
    }
    this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger5.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger5.info(`RX ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              let baseId = s.id;
              const baseAction = this.actions.find((a) => {
                if (a.cmd_id !== s.cmd_id)
                  return false;
                if (a.id === s.id)
                  return true;
                const idAddOption = a.options?.find((o) => o.id === "idAdd");
                if (!idAddOption?.choices)
                  return false;
                const offset = s.id - a.id;
                return offset > 0 && idAddOption.choices.some((c) => c.id === offset);
              });
              if (baseAction)
                baseId = baseAction.id;
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, baseId);
              this.feedbackCallback(baseFeedbackKey);
            } else {
              logger5.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger5.debug(`RX ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger5.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    const logFn = cmdId === CMD_BUS_GET ? logger5.debug.bind(logger5) : logger5.info.bind(logger5);
    if (decoded) {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_MIC_PRE (0x02): raw preamp echo — positional bytes, no setting IDs ──
      // Device echoes [busCh][val0][val1]... confirming the applied values.
      case CMD_MIC_PRE: {
        const busCh = data[0];
        const vals = Array.from(data.subarray(1)).map((b, i) => `[${i}]=0x${b.toString(16).padStart(2, "0")}(${b})`).join(" ");
        return `ch=${busCh} ${vals}`;
      }
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger6 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Connecting, "Discovering devices...");
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger6.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger6.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      if (this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found during discovery \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger6.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger6.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger6.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger6.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger6.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger6.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
      if (!effectiveModel && this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found among discovered devices \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    this.updateStatus(InstanceStatus.Ok);
    logger6.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger6.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current config is authorized to send commands.
   *
   * Auto mode (deviceMac set):
   *   - Find the discovered device with matching MAC → get its current IP
   *   - Revoke the previous IP, authorize the new IP
   *   - If MAC not found in discovery, revoke and block
   *
   * Manual mode (deviceMac empty):
   *   - Check discovered list by IP+model match, or probe directly
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.deviceMac) {
      const device = this.discoveredDevices.find((d) => d.mac === this.config.deviceMac);
      if (!device) {
        logger6.warn(`Device MAC "${this.config.deviceMac}" not found in current discovery \u2014 not authorizing`);
        if (previousHost)
          this.stController.revokeDevice(previousHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        await this.fetchSettingsAndEnsureSchema(device.model, newHost);
      }
      return;
    }
    const manualModel = String(this.config.activeModel ?? "");
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
      } else {
        logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
        this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${discoveredAtIp.model}`);
      }
      return;
    }
    logger6.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger6.error(`No device responded at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.UnknownWarning, `Device offline: ${newHost}`);
    } else if (probed.model !== manualModel) {
      logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${probed.model}`);
    } else {
      logger6.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
      this.updateStatus(InstanceStatus.Ok);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger6.warn(`No schema found for Model ${model} \u2014 run "GLOBAL: Get All Settings" to create one`);
        return;
      }
    } catch (e) {
      logger6.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger6.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, [], true);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    const refreshAfterCommand = schema.refreshAfterCommand ?? true;
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger6.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger6.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}, refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, resolved from MAC→IP via discoveredDevices (auto) or config.host (manual). */
  get host() {
    return resolveHost(this.config, this.discoveredDevices);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0LyoqIE1BQyBvZiB0aGUgc2VsZWN0ZWQgZGlzY292ZXJlZCBkZXZpY2UgKGUuZy4gXCIwMDoxZDpjMTo5YjphNjpjZFwiKSwgb3IgJycgZm9yIG1hbnVhbCBtb2RlICovXG5cdGRldmljZU1hYzogc3RyaW5nXG5cdC8qKiBNYW51YWwgSVAgYWRkcmVzcyBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGhvc3Q6IHN0cmluZ1xuXHQvKiogTWFudWFsIG1vZGVsIHNlbGVjdGlvbiBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcbn1cblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQ0VOVFJBTElaRUQgREVWSUNFIFNDSEVNQSBDQUNIRVxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQWxsIGRldmljZSBKU09OIGZpbGVzIGFyZSBsb2FkZWQgb25jZSBpbnRvIG1lbW9yeSBoZXJlLiBPdGhlciBtb2R1bGVzIHNob3VsZFxuLy8gdXNlIGdldERldmljZXNGb2xkZXIoKSwgZ2V0RGV2aWNlU2NoZW1hcygpLCBhbmQgZ2V0RGV2aWNlU2NoZW1hKCkgaW5zdGVhZCBvZlxuLy8gcmVhZGluZyBmaWxlcyBkaXJlY3RseS4gQ2FsbCByZWxvYWREZXZpY2VTY2hlbWFzKCkgYWZ0ZXIgd3JpdGluZyB0byBhIGZpbGUuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB0aGUgY29ycmVjdCBkZXZpY2VzIGZvbGRlciBwYXRoIHdpdGggZmFsbGJhY2sgc3VwcG9ydC5cbiAqIENoZWNrcyBwcmltYXJ5IHBhdGggZmlyc3QsIHRoZW4gZmFsbGJhY2ssIHRoZW4gdGhyb3dzIGVycm9yIGlmIG5laXRoZXIgZXhpc3RzLlxuICovXG5mdW5jdGlvbiByZXNvbHZlRGV2aWNlc0ZvbGRlcigpOiBzdHJpbmcge1xuXHRjb25zdCBwcmltYXJ5UGF0aCA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi4vZGV2aWNlcycpXG5cdGNvbnN0IGZhbGxiYWNrUGF0aCA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi9kZXZpY2VzJylcblxuXHQvLyBDaGVjayBwcmltYXJ5IHBhdGhcblx0aWYgKGZzLmV4aXN0c1N5bmMocHJpbWFyeVBhdGgpKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBVc2luZyBkZXZpY2VzIGZvbGRlcjogJHtwcmltYXJ5UGF0aH1gKVxuXHRcdHJldHVybiBwcmltYXJ5UGF0aFxuXHR9XG5cblx0Ly8gQ2hlY2sgZmFsbGJhY2sgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhmYWxsYmFja1BhdGgpKSB7XG5cdFx0bG9nZ2VyLndhcm4oYFByaW1hcnkgZGV2aWNlcyBmb2xkZXIgbm90IGZvdW5kLCB1c2luZyBmYWxsYmFjazogJHtmYWxsYmFja1BhdGh9YClcblx0XHRyZXR1cm4gZmFsbGJhY2tQYXRoXG5cdH1cblxuXHQvLyBOZWl0aGVyIHBhdGggZXhpc3RzIC0gZmF0YWwgZXJyb3Jcblx0Y29uc3QgZXJyb3JNc2cgPSBgRGV2aWNlcyBmb2xkZXIgbm90IGZvdW5kIVxcblRyaWVkOlxcbiAgLSAke3ByaW1hcnlQYXRofVxcbiAgLSAke2ZhbGxiYWNrUGF0aH1cXG5Nb2R1bGUgY2Fubm90IGNvbnRpbnVlIHdpdGhvdXQgZGV2aWNlIHNjaGVtYXMuYFxuXHRsb2dnZXIuZXJyb3IoZXJyb3JNc2cpXG5cdHRocm93IG5ldyBFcnJvcihlcnJvck1zZylcbn1cblxuLy8gUmVzb2x2ZSB0aGUgZGV2aWNlcyBmb2xkZXIgcGF0aCAod2l0aCBleGlzdGVuY2UgY2hlY2sgYW5kIGZhbGxiYWNrKVxuY29uc3QgZGV2aWNlc0ZvbGRlciA9IHJlc29sdmVEZXZpY2VzRm9sZGVyKClcblxuLy8gSW4tbWVtb3J5IGNhY2hlIG9mIGFsbCBkZXZpY2Ugc2NoZW1hcywga2V5ZWQgYnkgbW9kZWwgbnVtYmVyXG5sZXQgZGV2aWNlU2NoZW1hc0NhY2hlOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgbnVsbCA9IG51bGxcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBhYnNvbHV0ZSBwYXRoIHRvIHRoZSBkZXZpY2VzIGZvbGRlci5cbiAqIFVzZSB0aGlzIGluc3RlYWQgb2YgcmVkZWZpbmluZyB0aGUgcGF0aCBpbiBldmVyeSBmaWxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlc0ZvbGRlcigpOiBzdHJpbmcge1xuXHRyZXR1cm4gZGV2aWNlc0ZvbGRlclxufVxuXG4vKipcbiAqIExvYWRzIGFsbCBkZXZpY2UgSlNPTiBmaWxlcyBmcm9tIHRoZSBkZXZpY2VzIGZvbGRlciBpbnRvIG1lbW9yeS5cbiAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uY2UgYXQgaW5pdGlhbGl6YXRpb24sIG9yIGFmdGVyIGEgZmlsZSBpcyB3cml0dGVuLlxuICovXG5mdW5jdGlvbiBsb2FkRGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0Y29uc3Qgc2NoZW1hczogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9XG5cdHRyeSB7XG5cdFx0Y29uc3QgZmlsZXMgPSBmcy5yZWFkZGlyU3luYyhkZXZpY2VzRm9sZGVyKS5maWx0ZXIoKGYpID0+IGYuZW5kc1dpdGgoJy5qc29uJykpXG5cblx0XHRmb3IgKGNvbnN0IGYgb2YgZmlsZXMpIHtcblx0XHRcdGNvbnN0IGZ1bGxQYXRoID0gcGF0aC5qb2luKGRldmljZXNGb2xkZXIsIGYpXG5cdFx0XHRjb25zdCBqc29uID0gSlNPTi5wYXJzZShmcy5yZWFkRmlsZVN5bmMoZnVsbFBhdGgsICd1dGY4JykpXG5cdFx0XHRpZiAoanNvbj8ubW9kZWwpIHtcblx0XHRcdFx0c2NoZW1hc1tTdHJpbmcoanNvbi5tb2RlbCldID0ganNvblxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGxvZ2dlci5kZWJ1ZyhgTG9hZGVkICR7T2JqZWN0LmtleXMoc2NoZW1hcykubGVuZ3RofSBkZXZpY2Ugc2NoZW1hcyBpbnRvIGNhY2hlYClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmFpbGVkIHRvIGxvYWQgZGV2aWNlIHNjaGVtYXM6ICR7ZX1gKVxuXHR9XG5cdHJldHVybiBzY2hlbWFzXG59XG5cbi8qKlxuICogUmV0dXJucyBhbGwgZGV2aWNlIHNjaGVtYXMgZnJvbSB0aGUgY2FjaGUuXG4gKiBJbml0aWFsaXplcyB0aGUgY2FjaGUgb24gZmlyc3QgY2FsbC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZVNjaGVtYXMoKTogUmVjb3JkPHN0cmluZywgYW55PiB7XG5cdGlmICghZGV2aWNlU2NoZW1hc0NhY2hlKSB7XG5cdFx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxuXHR9XG5cdHJldHVybiBkZXZpY2VTY2hlbWFzQ2FjaGVcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgc3BlY2lmaWMgZGV2aWNlIHNjaGVtYSBieSBtb2RlbCBudW1iZXIuXG4gKiBSZXR1cm5zIHVuZGVmaW5lZCBpZiB0aGUgbW9kZWwgZG9lc24ndCBleGlzdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZVNjaGVtYShtb2RlbDogc3RyaW5nKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRyZXR1cm4gc2NoZW1hc1ttb2RlbF1cbn1cblxuLyoqXG4gKiBSZWxvYWRzIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIGRpc2suXG4gKiBDYWxsIHRoaXMgYWZ0ZXIgd3JpdGluZyB0byBhIGRldmljZSBKU09OIGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZWxvYWREZXZpY2VTY2hlbWFzKCk6IHZvaWQge1xuXHRsb2dnZXIuaW5mbygnUmVsb2FkaW5nIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay4uLicpXG5cdGRldmljZVNjaGVtYXNDYWNoZSA9IGxvYWREZXZpY2VTY2hlbWFzKClcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgbGlzdCBvZiBhdmFpbGFibGUgbW9kZWwgbnVtYmVycywgc29ydGVkLlxuICovXG5mdW5jdGlvbiBsb2FkQXZhaWxhYmxlTW9kZWxzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRyZXR1cm4gT2JqZWN0LmtleXMoc2NoZW1hcykuc29ydCgpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBHZXRDb25maWdGaWVsZHMoZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSA9IFtdKTogU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkW10ge1xuXHRjb25zdCBtb2RlbHMgPSBsb2FkQXZhaWxhYmxlTW9kZWxzKClcblxuXHQvLyBEcm9wZG93biBpZCBpcyB0aGUgZGV2aWNlIE1BQyBcdTIwMTQgc3RhYmxlIGFjcm9zcyBJUCBjaGFuZ2VzLlxuXHQvLyBFbXB0eSBpZCA9IE1hbnVhbCBtb2RlLlxuXHRjb25zdCBkZXZpY2VDaG9pY2VzID0gW1xuXHRcdHsgaWQ6ICcnLCBsYWJlbDogJ01hbnVhbCAoZW50ZXIgSVAgKyBtb2RlbCBiZWxvdyknIH0sXG5cdFx0Li4uZGlzY292ZXJlZERldmljZXMubWFwKChkKSA9PiAoe1xuXHRcdFx0aWQ6IGQubWFjID8/ICcnLFxuXHRcdFx0bGFiZWw6IGBNb2RlbCAke2QubW9kZWx9IFske2QubWFjfV0gQCAke2QuaXB9YCxcblx0XHR9KSksXG5cdF1cblxuXHRyZXR1cm4gW1xuXHRcdC8vIFx1MjUwMFx1MjUwMCBEZXZpY2Ugc2VsZWN0aW9uIGRyb3Bkb3duIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFN0b3JlcyB0aGUgTUFDIHNvIHJlLWRpc2NvdmVyeSB3aXRoIGEgY2hhbmdlZCBJUCBzdGlsbCBtYXRjaGVzLlxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2RldmljZU1hYycsXG5cdFx0XHRsYWJlbDogJ0RldmljZScsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0Y2hvaWNlczogZGV2aWNlQ2hvaWNlcyxcblx0XHRcdHRvb2x0aXA6ICdTZWxlY3QgYW4gYXV0by1kaXNjb3ZlcmVkIFN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlLCBvciBjaG9vc2UgTWFudWFsIHRvIGVudGVyIGFuIElQIGFkZHJlc3MuJyxcblx0XHR9LFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIE1hbnVhbCBJUCBlbnRyeSBcdTIwMTQgb25seSB2aXNpYmxlIGluIG1hbnVhbCBtb2RlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdHtcblx0XHRcdHR5cGU6ICd0ZXh0aW5wdXQnLFxuXHRcdFx0aWQ6ICdob3N0Jyxcblx0XHRcdGxhYmVsOiAnVGFyZ2V0IElQJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRyZWdleDogUmVnZXguSVAsXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkZXZpY2VNYWMpYCxcblx0XHRcdHRvb2x0aXA6ICdFbnRlciB0aGUgSVAgYWRkcmVzcyBvZiB0aGUgZGV2aWNlIG1hbnVhbGx5LicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNYW51YWwgbW9kZWwgc2VsZWN0b3IgXHUyMDE0IG9ubHkgdmlzaWJsZSBpbiBtYW51YWwgbW9kZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHR7XG5cdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0aWQ6ICdhY3RpdmVNb2RlbCcsXG5cdFx0XHRsYWJlbDogJ0FjdGl2ZSBEZXZpY2UgTW9kZWwnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiBtb2RlbHNbMF0gPz8gJycsXG5cdFx0XHRjaG9pY2VzOiBtb2RlbHMubWFwKChtb2RlbCkgPT4gKHtcblx0XHRcdFx0aWQ6IG1vZGVsLFxuXHRcdFx0XHRsYWJlbDogYE1vZGVsICR7bW9kZWx9YCxcblx0XHRcdH0pKSxcblx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246IGAhJChvcHRpb25zOmRldmljZU1hYylgLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCB3aGljaCBTdHVkaW8gVGVjaG5vbG9naWVzIG1vZGVsIGlzIGFjdGl2ZSBmb3IgYWN0aW9ucyBhbmQgZmVlZGJhY2tzLicsXG5cdFx0fSxcblx0XVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLlxuICogQXV0byBtb2RlIChkZXZpY2VNYWMgc2V0KTogZmluZHMgdGhlIGN1cnJlbnQgSVAgb2YgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIHdpdGggdGhhdCBNQUMuXG4gKiBNYW51YWwgbW9kZSAoZGV2aWNlTWFjIGVtcHR5KTogcmV0dXJucyB0aGUgbWFudWFsbHkgZW50ZXJlZCBob3N0IElQLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUhvc3QoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRldmljZU1hYykge1xuXHRcdGNvbnN0IGRldmljZSA9IGRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQubWFjID09PSBjb25maWcuZGV2aWNlTWFjKVxuXHRcdHJldHVybiBkZXZpY2U/LmlwID8/ICcnXG5cdH1cblx0cmV0dXJuIFN0cmluZyhjb25maWcuaG9zdCA/PyAnJylcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgbW9kZWwuXG4gKiBBdXRvIG1vZGU6IHVzZXMgdGhlIG1vZGVsIGZyb20gdGhlIGRpc2NvdmVyZWQgZGV2aWNlIG1hdGNoaW5nIHRoZSBzdG9yZWQgTUFDLlxuICogTWFudWFsIG1vZGU6IHVzZXMgdGhlIG1hbnVhbGx5IHNlbGVjdGVkIGFjdGl2ZU1vZGVsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZU1vZGVsKGNvbmZpZzogTW9kdWxlQ29uZmlnLCBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdKTogc3RyaW5nIHtcblx0aWYgKGNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRjb25zdCBkZXZpY2UgPSBkaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gY29uZmlnLmRldmljZU1hYylcblx0XHRsb2dnZXIuZGVidWcoYHJlc29sdmVNb2RlbDogZGV2aWNlTWFjPVwiJHtjb25maWcuZGV2aWNlTWFjfVwiLCBmb3VuZCBkZXZpY2U6ICR7ZGV2aWNlPy5tb2RlbCA/PyAnbm9uZSd9YClcblx0XHRyZXR1cm4gZGV2aWNlPy5tb2RlbCA/PyAnJ1xuXHR9XG5cdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBtYW51YWwgbW9kZSwgYWN0aXZlTW9kZWw9XCIke2NvbmZpZy5hY3RpdmVNb2RlbH1cImApXG5cdHJldHVybiBTdHJpbmcoY29uZmlnLmFjdGl2ZU1vZGVsID8/ICcnKVxufVxuIiwgImltcG9ydCB0eXBlIE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcblxuLyoqXG4gKiBEZWZpbmUgQ29tcGFuaW9uIHZhcmlhYmxlcyBmb3IgdGhpcyBtb2R1bGUuXG4gKiBWYXJpYWJsZXMgY2FuIGJlIHVzZWQgdG8gZGlzcGxheSBkeW5hbWljIHN0YXRlIGluIGJ1dHRvbiBsYWJlbHMsIHRyaWdnZXJzLCBldGMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh7XG5cdFx0bW9kZWw6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOdW1iZXInIH0sXG5cdFx0bW9kZWxOYW1lOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTmFtZSAoRnVsbCBEZXNjcmlwdGlvbiknIH0sXG5cdFx0bWFudWZhY3R1cmVyOiB7IG5hbWU6ICdEZXZpY2UgTWFudWZhY3R1cmVyJyB9LFxuXHRcdGZpcm13YXJlOiB7IG5hbWU6ICdEZXZpY2UgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRkYW50ZUZXOiB7IG5hbWU6ICdEYW50ZSBNb2R1bGUgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRtYWM6IHsgbmFtZTogJ0RldmljZSBNQUMgQWRkcmVzcycgfSxcblx0XHRpcDogeyBuYW1lOiAnRGV2aWNlIElQIEFkZHJlc3MnIH0sXG5cdH0pXG59XG5cbmNvbnN0IENMRUFSRURfVkFSSUFCTEVTID0ge1xuXHRtb2RlbDogJycsXG5cdG1vZGVsTmFtZTogJycsXG5cdG1hbnVmYWN0dXJlcjogJycsXG5cdGZpcm13YXJlOiAnJyxcblx0ZGFudGVGVzogJycsXG5cdG1hYzogJycsXG5cdGlwOiAnJyxcbn1cblxuLyoqXG4gKiBVcGRhdGUgdmFyaWFibGUgdmFsdWVzIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaW5mb3JtYXRpb24uXG4gKiBPbmx5IHBvcHVsYXRlcyB2YXJpYWJsZXMgd2hlbiB0aGUgY3VycmVudCBob3N0IGlzIGF1dGhvcml6ZWQuXG4gKiBDbGVhcnMgYWxsIHZhcmlhYmxlcyBpZiB0aGUgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkIG9yIG5vdCBmb3VuZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IGN1cnJlbnRIb3N0ID0gc2VsZi5ob3N0XG5cblx0Ly8gQ2xlYXIgdmFyaWFibGVzIGlmIG5vIGhvc3QgY29uZmlndXJlZCBvciBkZXZpY2UgaXMgbm90IGF1dGhvcml6ZWRcblx0aWYgKCFjdXJyZW50SG9zdCB8fCAhc2VsZi5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKGN1cnJlbnRIb3N0KSkge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoQ0xFQVJFRF9WQVJJQUJMRVMpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBkZXZpY2UgPSBzZWxmLmRldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY3VycmVudEhvc3QpXG5cdGlmIChkZXZpY2UpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdG1vZGVsOiBkZXZpY2UubW9kZWwgfHwgJycsXG5cdFx0XHRtb2RlbE5hbWU6IGRldmljZS5tb2RlbE5hbWUgfHwgJycsXG5cdFx0XHRtYW51ZmFjdHVyZXI6IGRldmljZS5tYW51ZmFjdHVyZXIgfHwgJycsXG5cdFx0XHRmaXJtd2FyZTogZGV2aWNlLmZpcm13YXJlTWFpbiB8fCAnJyxcblx0XHRcdGRhbnRlRlc6IGRldmljZS5kYW50ZUZpcm13YXJlIHx8ICcnLFxuXHRcdFx0bWFjOiBkZXZpY2UubWFjIHx8ICcnLFxuXHRcdFx0aXA6IGRldmljZS5pcCxcblx0XHR9KVxuXHR9IGVsc2Uge1xuXHRcdC8vIEF1dGhvcml6ZWQgYnV0IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgKG1hbnVhbCBJUCB0aGF0IHByb2JlZCBzdWNjZXNzZnVsbHkpXG5cdFx0Ly8gV2Uga25vdyBpdCdzIHRoZSByaWdodCBkZXZpY2UgYnV0IGRvbid0IGhhdmUgZnVsbCBpbmZvIHlldFxuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0Li4uQ0xFQVJFRF9WQVJJQUJMRVMsXG5cdFx0XHRpcDogY3VycmVudEhvc3QsXG5cdFx0fSlcblx0fVxufVxuIiwgImltcG9ydCB0eXBlIHsgQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG5leHBvcnQgY29uc3QgVXBncmFkZVNjcmlwdHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQ8TW9kdWxlQ29uZmlnPltdID0gW1xuXHQvKlxuXHQgKiBQbGFjZSB5b3VyIHVwZ3JhZGUgc2NyaXB0cyBoZXJlXG5cdCAqIFJlbWVtYmVyIHRoYXQgb25jZSBpdCBoYXMgYmVlbiBhZGRlZCBpdCBjYW5ub3QgYmUgcmVtb3ZlZCFcblx0ICovXG5cdC8vIGZ1bmN0aW9uIChjb250ZXh0LCBwcm9wcykge1xuXHQvLyBcdHJldHVybiB7XG5cdC8vIFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHQvLyBcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHQvLyBcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdC8vIFx0fVxuXHQvLyB9LFxuXVxuIiwgImV4cG9ydCB0eXBlIENvbXBhbmlvbklucHV0Q2hvaWNlID0ge1xuXHRpZDogc3RyaW5nIHwgbnVtYmVyXG5cdGxhYmVsOiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgRGV2aWNlU2V0dGluZyA9IHtcblx0dHlwZTogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVmYXVsdDogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhblxuXHRjaG9pY2VzPzogQ29tcGFuaW9uSW5wdXRDaG9pY2VbXVxufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFID0gMHgwMiAvLyBNaWMgcHJlYW1wIHJhdyBzZXQgKGdhaW4sIHBoYW50b20pIFx1MjAxNCBwb3NpdGlvbmFsIGJ5dGVzLCBubyBzZXR0aW5nIElEc1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBIZWFydGJlYXQgLyBrZWVwYWxpdmUgcGluZ1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfU0VUID0gMHgwNCAvLyBTZXQgc2V0dGluZyBvbiBzcGVjaWZpYyBidXMvY2hhbm5lbFxuZXhwb3J0IGNvbnN0IENNRF9IRUFEUEhPTkUgPSAweDA1IC8vIEhlYWRwaG9uZSBjb250cm9sc1xuZXhwb3J0IGNvbnN0IENNRF9CVVRUT05fTU9ERSA9IDB4MDcgLy8gQnV0dG9uIG1vZGUgY29uZmlndXJhdGlvblxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kc1xuZXhwb3J0IGNvbnN0IENNRF9HRVRfQUxMX1NFVFRJTkdTID0gMHgwYSAvLyBSZXF1ZXN0IGFsbCBjdXJyZW50IHNldHRpbmdzIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX1NFVFRJTkdTX1BVU0ggPSAweDBiIC8vIFVuc29saWNpdGVkIHNldHRpbmdzIHVwZGF0ZSBmcm9tIGRldmljZVxuZXhwb3J0IGNvbnN0IENNRF9ERVZfU1BFQyA9IDB4MGQgLy8gRGV2aWNlLXNwZWNpZmljIHNldHRpbmcgZ2V0L3NldCB3aXRoIEFDS1xuZXhwb3J0IGNvbnN0IENNRF9SRVNFVF9ERVZJQ0UgPSAweDBlIC8vIEZhY3RvcnkgcmVzZXQgY29tbWFuZFxuZXhwb3J0IGNvbnN0IENNRF9HTE9CQUxfTUlDX0tJTEwgPSAweDEwIC8vIEVtZXJnZW5jeSBtaWMga2lsbCAoYWxsIGNoYW5uZWxzKVxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFX0JVUyA9IDB4MTIgLy8gTWljL3ByZWFtcCBzZXR0aW5ncyBwZXIgYnVzIChnYWluLCBwaGFudG9tLCBldGMpXG5leHBvcnQgY29uc3QgQ01EX0NIQU5ORUwgPSAweDE0IC8vIENoYW5uZWwtc3BlY2lmaWMgY29udHJvbHNcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIENvbW1hbmQgTmFtZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29tbWFuZE5hbWUoY21kSWQ6IG51bWJlcik6IHN0cmluZyB7XG5cdHN3aXRjaCAoY21kSWQpIHtcblx0XHRjYXNlIENNRF9HRVRfRklSTVdBUkU6XG5cdFx0XHRyZXR1cm4gJ0dldCBGaXJtd2FyZSBWZXJzaW9uJ1xuXHRcdGNhc2UgQ01EX01JQ19QUkU6XG5cdFx0XHRyZXR1cm4gJ01pYyBQcmVhbXAnXG5cdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdHJldHVybiAnSGVhcnRiZWF0J1xuXHRcdGNhc2UgQ01EX0JVU19TRVQ6XG5cdFx0XHRyZXR1cm4gJ1NldCBCdXMgU2V0dGluZydcblx0XHRjYXNlIENNRF9IRUFEUEhPTkU6XG5cdFx0XHRyZXR1cm4gJ0hlYWRwaG9uZSBDb250cm9sJ1xuXHRcdGNhc2UgQ01EX0JVVFRPTl9NT0RFOlxuXHRcdFx0cmV0dXJuICdCdXR0b24gTW9kZSdcblx0XHRjYXNlIENNRF9TWVNURU06XG5cdFx0XHRyZXR1cm4gJ1N5c3RlbSBDb21tYW5kJ1xuXHRcdGNhc2UgQ01EX0dFVF9BTExfU0VUVElOR1M6XG5cdFx0XHRyZXR1cm4gJ1JlcXVlc3QgQWxsIFNldHRpbmdzJ1xuXHRcdGNhc2UgQ01EX1NFVFRJTkdTX1BVU0g6XG5cdFx0XHRyZXR1cm4gJ1NldHRpbmdzIFB1c2gnXG5cdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6XG5cdFx0XHRyZXR1cm4gJ01pYy9QcmUgQnVzJ1xuXHRcdGNhc2UgQ01EX0RFVl9TUEVDOlxuXHRcdFx0cmV0dXJuICdEZXZpY2UgU2V0dGluZydcblx0XHRjYXNlIENNRF9DSEFOTkVMOlxuXHRcdFx0cmV0dXJuICdDaGFubmVsIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfUkVTRVRfREVWSUNFOlxuXHRcdFx0cmV0dXJuICdSZXNldCBEZXZpY2UnXG5cdFx0Y2FzZSBDTURfR0xPQkFMX01JQ19LSUxMOlxuXHRcdFx0cmV0dXJuICdHbG9iYWwgTWljIEtpbGwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgY21kXzB4JHtjbWRJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIEdlbmVyYXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDcmVhdGVzIGEgY29uc2lzdGVudCBJRCBmb3IgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgc3RhdGUga2V5cy5cbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2J1c0NofV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKGUuZy4sIFwiNTMwNF8xNF8wXzBcIilcbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGhvdXQgYnVzQ2ggKGUuZy4sIFwiNTMwNF8xMl9kXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWtlU2V0dGluZ0lkKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRzZXR0aW5nSWQ6IG51bWJlciB8IHN0cmluZyxcblx0YnVzQ2g/OiBudW1iZXIgfCBzdHJpbmcsXG4pOiBzdHJpbmcge1xuXHRjb25zdCBjbWQgPSB0eXBlb2YgY21kSWQgPT09ICdudW1iZXInID8gY21kSWQudG9TdHJpbmcoMTYpIDogY21kSWRcblx0Y29uc3QgaWQgPSB0eXBlb2Ygc2V0dGluZ0lkID09PSAnbnVtYmVyJyA/IHNldHRpbmdJZC50b1N0cmluZygxNikgOiBzZXR0aW5nSWRcblxuXHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IGNoID0gdHlwZW9mIGJ1c0NoID09PSAnbnVtYmVyJyA/IGJ1c0NoLnRvU3RyaW5nKDE2KSA6IGJ1c0NoXG5cdFx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtjaH1fJHtpZH1gXG5cdH1cblxuXHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2lkfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEhleCBGb3JtYXR0aW5nIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENvbnZlcnRzIGEgbnVtYmVyIHRvIGEgaGV4IHN0cmluZyB3aXRoIDB4IHByZWZpeCBhbmQgcGFkZGluZy5cbiAqIEBwYXJhbSB2YWx1ZSAtIFRoZSBudW1iZXIgdG8gY29udmVydFxuICogQHBhcmFtIHBhZExlbmd0aCAtIE51bWJlciBvZiBoZXggZGlnaXRzIHRvIHBhZCB0byAoZGVmYXVsdDogMilcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGRcIiwgXCIweGZmXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0hleCh2YWx1ZTogbnVtYmVyLCBwYWRMZW5ndGggPSAyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAweCR7dmFsdWUudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KHBhZExlbmd0aCwgJzAnKX1gXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gYXJyYXkgb2YgYnl0ZXMgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4LlxuICogQHBhcmFtIGJ5dGVzIC0gQXJyYXkgb2YgYnl0ZXMgb3IgQnVmZmVyXG4gKiBAcmV0dXJucyBGb3JtYXR0ZWQgaGV4IHN0cmluZyAoZS5nLiwgXCIweDBhZmYxMlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnl0ZXNUb0hleChieXRlczogbnVtYmVyW10gfCBCdWZmZXIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHtBcnJheS5mcm9tKGJ5dGVzKVxuXHRcdC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0LmpvaW4oJycpfWBcbn1cblxuLyoqXG4gKiBGb3JtYXRzIFJHQiBjb2xvciBieXRlcyBhcyBhIENTUyBoZXggY29sb3Igc3RyaW5nLlxuICogQHBhcmFtIHIgLSBSZWQgY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBnIC0gR3JlZW4gY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBiIC0gQmx1ZSBjb21wb25lbnQgKDAtMjU1KVxuICogQHJldHVybnMgQ1NTIGhleCBjb2xvciBzdHJpbmcgKGUuZy4sIFwiI0ZGMDBBQlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UmdiQ29sb3IocjogbnVtYmVyLCBnOiBudW1iZXIsIGI6IG51bWJlcik6IHN0cmluZyB7XG5cdHJldHVybiBgIyR7W3IsIGcsIGJdXG5cdFx0Lm1hcCgodikgPT4gdi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJylcblx0XHQudG9VcHBlckNhc2UoKX1gXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBJRCBQYXJzaW5nIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogUGFyc2VzIGEgc2V0dGluZyBJRCBzdHJpbmcgaW50byBpdHMgY29tcG9uZW50cy5cbiAqIEBwYXJhbSBpZCAtIFNldHRpbmcgSUQgc3RyaW5nIChlLmcuLCBcIjM5MV9kXzBcIiBvciBcIjUzMDRfMTRfMF8xXCIpXG4gKiBAcmV0dXJucyBQYXJzZWQgY29tcG9uZW50cyB3aXRoIGhleCBzdHJpbmdzIGNvbnZlcnRlZCB0byBudW1iZXJzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdJZChpZDogc3RyaW5nKTogeyBtb2RlbDogc3RyaW5nOyBjbWRJZDogbnVtYmVyOyBiYXNlSWQ6IG51bWJlciB9IHtcblx0Y29uc3QgW21vZGVsLCBjbWRJZFN0ciwgaWRTdHJdID0gaWQuc3BsaXQoJ18nKVxuXHRyZXR1cm4ge1xuXHRcdG1vZGVsLFxuXHRcdGNtZElkOiBwYXJzZUludChjbWRJZFN0ciwgMTYpLFxuXHRcdGJhc2VJZDogcGFyc2VJbnQoaWRTdHIsIDE2KSxcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgTW9kZWwgRGlzdGFuY2UgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDYWxjdWxhdGVzIG51bWVyaWMgZGlzdGFuY2UgYmV0d2VlbiB0d28gbW9kZWwgbnVtYmVycy5cbiAqIFVzZWQgZm9yIGZpbmRpbmcgc2ltaWxhciBtb2RlbHMgZm9yIHNldHRpbmcgaW5mZXJlbmNlLlxuICogQHBhcmFtIG1vZGVsQSAtIEZpcnN0IG1vZGVsIG51bWJlciAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBtb2RlbEIgLSBTZWNvbmQgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MlwiKVxuICogQHJldHVybnMgTnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIG1vZGVscywgb3IgSW5maW5pdHkgaWYgZWl0aGVyIGlzIG5vbi1udW1lcmljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb2RlbERpc3RhbmNlKG1vZGVsQTogc3RyaW5nLCBtb2RlbEI6IHN0cmluZyk6IG51bWJlciB7XG5cdGNvbnN0IG5hID0gcGFyc2VJbnQobW9kZWxBLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRjb25zdCBuYiA9IHBhcnNlSW50KG1vZGVsQi5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0aWYgKE51bWJlci5pc05hTihuYSkgfHwgTnVtYmVyLmlzTmFOKG5iKSkgcmV0dXJuIEluZmluaXR5XG5cdHJldHVybiBNYXRoLmFicyhuYSAtIG5iKVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU2NoZW1hIE5vcm1hbGl6YXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBOb3JtYWxpemVzIGRldmljZSBzY2hlbWFzIHRvIGVuc3VyZSBjbWRTY2hlbWEgaXMgYWx3YXlzIGFuIGFycmF5LlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgc2NoZW1hIHRyYW5zZm9ybWF0aW9uIGNvZGUuXG4gKiBAcGFyYW0gc2NoZW1hc1JhdyAtIFJhdyBzY2hlbWFzIGZyb20gZ2V0RGV2aWNlU2NoZW1hcygpXG4gKiBAcmV0dXJucyBOb3JtYWxpemVkIHNjaGVtYXMgd2l0aCBndWFyYW50ZWVkIGNtZFNjaGVtYSBhcnJheXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldE5vcm1hbGl6ZWRTY2hlbWFzKFxuXHRzY2hlbWFzUmF3OiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuKTogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+IHtcblx0Y29uc3Qgbm9ybWFsaXplZDogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+ID0ge31cblx0Zm9yIChjb25zdCBbbW9kZWwsIGpzb25dIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXNSYXcpKSB7XG5cdFx0bm9ybWFsaXplZFttb2RlbF0gPSB7XG5cdFx0XHRtb2RlbDoganNvbi5tb2RlbCxcblx0XHRcdGNtZFNjaGVtYTogQXJyYXkuaXNBcnJheShqc29uLmNtZFNjaGVtYSkgPyBqc29uLmNtZFNjaGVtYSA6IFtdLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4gbm9ybWFsaXplZFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQWN0aW9uIExvb2t1cCBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIEZpbmRzIGFuIGFjdGlvbi9zZXR0aW5nIGluIHRoZSBzY2hlbWEsIHN1cHBvcnRpbmcgYm90aCBleGFjdCBtYXRjaGVzIGFuZCBpZEFkZCBvZmZzZXRzLlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgYWN0aW9uIGxvb2t1cCBsb2dpYyBhY3Jvc3MgbXVsdGlwbGUgZmlsZXMuXG4gKiBAcGFyYW0gc2NoZW1hcyAtIE5vcm1hbGl6ZWQgZGV2aWNlIHNjaGVtYXNcbiAqIEBwYXJhbSBtb2RlbCAtIERldmljZSBtb2RlbCAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBjbWRJZCAtIENvbW1hbmQgSURcbiAqIEBwYXJhbSBzZXR0aW5nSWQgLSBTZXR0aW5nIElEIChtYXkgaW5jbHVkZSBpZEFkZCBvZmZzZXQpXG4gKiBAcmV0dXJucyBNYXRjaGluZyBhY3Rpb24vc2V0dGluZyBvciB1bmRlZmluZWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmRBY3Rpb25Gb3JTZXR0aW5nKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0aWYgKCFzY2hlbWEgfHwgIUFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkpIHJldHVybiB1bmRlZmluZWRcblxuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IHNjaGVtYS5jbWRTY2hlbWEuZmluZCgoczogYW55KSA9PiBzLmNtZF9pZCA9PT0gY21kSWQgJiYgcy5pZCA9PT0gc2V0dGluZ0lkKVxuXG5cdC8vIElmIG5vIGV4YWN0IG1hdGNoLCB0cnkgdG8gZmluZCBiYXNlIGFjdGlvbiB3aXRoIGlkQWRkXG5cdGlmICghYWN0aW9uKSB7XG5cdFx0YWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHtcblx0XHRcdGlmIChzLmNtZF9pZCAhPT0gY21kSWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBzLm9wdGlvbnM/LmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHNldHRpbmdJZCBtYXRjaGVzIGJhc2UgKyBhbnkgaWRBZGQgb2Zmc2V0XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBzZXR0aW5nSWQgLSBzLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvblxufVxuIiwgIi8qKlxuICogYnVpbGQtY29tbWFuZHMudHNcbiAqIC0gVXNlcyBjZW50cmFsaXplZCBkZXZpY2Ugc2NoZW1hIGNhY2hlIGZyb20gY29uZmlnLnRzXG4gKiAtIFByb2R1Y2VzIENvbXBhbmlvbiBhY3Rpb24gZGVmaW5pdGlvbnMgYW5kIGZlZWRiYWNrc1xuICovXG5cbmltcG9ydCB7XG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zLFxuXHRDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uLFxuXHRDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgbWFrZVNldHRpbmdJZCB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0gT3B0aW9uIEJ1aWxkZXIgLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZnVuY3Rpb24gYnVpbGRPcHRpb24obzogYW55KTogYW55IHtcblx0Y29uc3QgYmFzZSA9IHtcblx0XHR0eXBlOiBvLnR5cGUsXG5cdFx0aWQ6IG8uaWQsXG5cdFx0bGFiZWw6IG8ubGFiZWwsXG5cdFx0ZGVmYXVsdDogby5kZWZhdWx0LFxuXHRcdHRvb2x0aXA6IG8udG9vbHRpcCxcblx0fVxuXG5cdHN3aXRjaCAoby50eXBlKSB7XG5cdFx0Y2FzZSAnZHJvcGRvd24nOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgY2hvaWNlczogby5jaG9pY2VzID8/IFtdIH1cblxuXHRcdGNhc2UgJ251bWJlcic6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5iYXNlLFxuXHRcdFx0XHRtaW46IG8ubWluLFxuXHRcdFx0XHRtYXg6IG8ubWF4LFxuXHRcdFx0XHRzdGVwOiBvLnN0ZXAgPz8gMSxcblx0XHRcdFx0cmFuZ2U6IHRydWUsXG5cdFx0XHR9XG5cblx0XHRjYXNlICdjaGVja2JveCc6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBkZWZhdWx0OiBvLmRlZmF1bHQgPz8gZmFsc2UgfVxuXG5cdFx0Y2FzZSAnc3RhdGljLXRleHQnOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgdmFsdWU6IG8udmFsdWUgPz8gJycgfVxuXG5cdFx0Y2FzZSAndGV4dGlucHV0Jzpcblx0XHRjYXNlICdjb2xvcnBpY2tlcic6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHQvLyBTa2lwIHJlYWQtb25seSBlbnRyaWVzIFx1MjAxNCB0aGV5IGFyZSBmZWVkYmFjay1vbmx5IChpbmRpY2F0b3JzLCBzdGF0dXMpXG5cdFx0XHRpZiAoYS5yZWFkb25seSA9PT0gdHJ1ZSkgY29udGludWVcblxuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBtYWtlU2V0dGluZ0lkKG1vZGVsLCBhLmNtZF9pZCwgYS5pZClcblxuXHRcdFx0Y29uc3Qgb3B0aW9ucyA9IChhLm9wdGlvbnMgPz8gW10pLm1hcChidWlsZE9wdGlvbilcblxuXHRcdFx0Y29uc3QgYWN0aW9uOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7YS5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnMsXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlQWN0aW9ucyAqL1xuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRhY3Rpb25zW2FjdGlvbklkXSA9IGFjdGlvblxuXHRcdH1cblx0fVxuXG5cdHJldHVybiBhY3Rpb25zXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0gRmVlZGJhY2tzIC0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRmVlZGJhY2tzKCk6IENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IGZlZWRiYWNrczogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IHNldHRpbmcgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHRjb25zdCBiYXNlRmVlZGJhY2tJZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIHNldHRpbmcuY21kX2lkLCBzZXR0aW5nLmlkKVxuXG5cdFx0XHQvLyBCdWlsZCBvcHRpb25zXG5cdFx0XHRjb25zdCBhbGxPcHRpb25zID0gKHNldHRpbmcub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHQvLyBGaWx0ZXIgb3V0ICd2YWx1ZScgb3B0aW9uIGZvciB2YWx1ZSBmZWVkYmFjayAoa2VlcCBvbmx5IGJ1c0NoL2lkQWRkKVxuXHRcdFx0Y29uc3QgdmFsdWVPcHRpb25zID0gYWxsT3B0aW9ucy5maWx0ZXIoKG9wdDogYW55KSA9PiBvcHQuaWQgIT09ICd2YWx1ZScpXG5cblx0XHRcdC8vIEFkZCBhIGNoZWNrYm94IG9wdGlvbiB0byByZXR1cm4gbGFiZWwgaW5zdGVhZCBvZiB2YWx1ZVxuXHRcdFx0dmFsdWVPcHRpb25zLnB1c2goe1xuXHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRpZDogJ3Nob3dMYWJlbCcsXG5cdFx0XHRcdGxhYmVsOiAnU2hvdyBMYWJlbCcsXG5cdFx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0XHR0b29sdGlwOiAnUmV0dXJuIHRoZSBsYWJlbCB0ZXh0IGluc3RlYWQgb2YgdGhlIG51bWVyaWMgdmFsdWUnLFxuXHRcdFx0fSlcblxuXHRcdFx0Ly8gVmFsdWUgZmVlZGJhY2sgZm9yIGFsbCBzZXR0aW5ncyAoYXBwZWFycyBpbiBWYXJpYWJsZXMgbGlzdClcblx0XHRcdGNvbnN0IHZhbHVlRmVlZGJhY2s6IGFueSA9IHtcblx0XHRcdFx0dHlwZTogJ3ZhbHVlJyxcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7bW9kZWx9XSAke3NldHRpbmcubmFtZX1gLFxuXHRcdFx0XHRvcHRpb25zOiB2YWx1ZU9wdGlvbnMsXG5cdFx0XHRcdGNhbGxiYWNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlRmVlZGJhY2tzICovXG5cdFx0XHRcdFx0cmV0dXJuIDBcblx0XHRcdFx0fSxcblx0XHRcdH1cblxuXHRcdFx0ZmVlZGJhY2tzW2Jhc2VGZWVkYmFja0lkXSA9IHZhbHVlRmVlZGJhY2tcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gZmVlZGJhY2tzXG59XG4iLCAiaW1wb3J0IE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcbmltcG9ydCB7IGJ1aWxkQWN0aW9ucyB9IGZyb20gJy4vYnVpbGQtY29tbWFuZHMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VzRm9sZGVyLCBnZXREZXZpY2VTY2hlbWEsIGdldERldmljZVNjaGVtYXMsIHJlbG9hZERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IHBhcnNlU2V0dGluZ0lkLCBnZXROb3JtYWxpemVkU2NoZW1hcyB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcblxuaW1wb3J0IHsgcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24sIHNhdmVNb2RlbEpzb25QcmV0dHksIHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyB9IGZyb20gJy4vc2V0dGluZ3NQYXJzZXIuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQWN0aW9ucycpXG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVBY3Rpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IHNjaGVtYXNSYXcgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgcmF3QWN0aW9ucyA9IGJ1aWxkQWN0aW9ucygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEFjdGlvbnM6IGFueSA9IHt9XG5cblx0Y29uc3QgYWN0aXZlTW9kZWwgPSBzZWxmLmFjdGl2ZU1vZGVsXG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBHTE9CQUw6IEdFVCBBTEwgU0VUVElOR1MgKEFVVE8gSlNPTiBVUERBVEUpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdHdpcmVkQWN0aW9uc1snZ2xvYmFsX2dldEFsbFNldHRpbmdzJ10gPSB7XG5cdFx0bmFtZTogJ0dMT0JBTDogR2V0IEFsbCBTZXR0aW5ncyAoQXV0by1VcGRhdGUgSlNPTiknLFxuXHRcdG9wdGlvbnM6IFtdLFxuXHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRjb25zdCBtb2RlbCA9IGFjdGl2ZU1vZGVsXG5cdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXG5cdFx0XHRjb25zdCBidWYgPSBhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApXG5cblx0XHRcdC8vIFVzZSBjZW50cmFsaXplZCBjYWNoZSB0byBnZXQgdGhlIHNjaGVtYSAobWF5IGJlIG51bGwgZm9yIG5ldy91bmtub3duIGRldmljZXMpXG5cdFx0XHRsZXQgbW9kZWxKc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXG5cdFx0XHQvLyBQYXJzZSB3aXRoIGF1dG8tZGV0ZWN0aW9uXG5cdFx0XHRjb25zdCB7IHNldHRpbmdzOiBwYXJzZWQsIGRldGVjdGVkU2VjdGlvbmVkIH0gPSBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbihtb2RlbCwgYnVmKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBwYXJzZWQgcmVwbHk6ICR7SlNPTi5zdHJpbmdpZnkocGFyc2VkKX1gKVxuXG5cdFx0XHRpZiAoIW1vZGVsSnNvbikge1xuXHRcdFx0XHQvLyBObyBzY2hlbWEgeWV0IFx1MjAxNCBjcmVhdGUgYSBtaW5pbWFsIG9uZSBmcm9tIHRoZSBwYXJzZWQgc2V0dGluZ3Ncblx0XHRcdFx0bG9nZ2VyLmluZm8oYE1vZGVsICR7bW9kZWx9IGhhcyBubyBzY2hlbWEgXHUyMDE0IGNyZWF0aW5nIG5ldyBKU09OIGZyb20gc2V0dGluZ3NgKVxuXHRcdFx0XHRtb2RlbEpzb24gPSB7XG5cdFx0XHRcdFx0bW9kZWwsXG5cdFx0XHRcdFx0c2VjdGlvbmVkOiBkZXRlY3RlZFNlY3Rpb25lZCA/PyBmYWxzZSxcblx0XHRcdFx0XHRyZWZyZXNoQWZ0ZXJDb21tYW5kOiB0cnVlLFxuXHRcdFx0XHRcdGNtZFNjaGVtYTogW10sXG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBpZiAoZGV0ZWN0ZWRTZWN0aW9uZWQgIT09IG51bGwpIHtcblx0XHRcdFx0Ly8gSWYgd2UgYXV0by1kZXRlY3RlZCB0aGUgZm9ybWF0LCBhZGQgaXQgdG8gdGhlIEpTT05cblx0XHRcdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgc2VjdGlvbmVkPSR7ZGV0ZWN0ZWRTZWN0aW9uZWR9LCBhZGRpbmcgdG8gbW9kZWwgSlNPTmApXG5cdFx0XHRcdG1vZGVsSnNvbiA9IHsgLi4ubW9kZWxKc29uLCBzZWN0aW9uZWQ6IGRldGVjdGVkU2VjdGlvbmVkIH1cblx0XHRcdH1cblxuXHRcdFx0Y29uc3QgdXBkYXRlZCA9IHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyhtb2RlbEpzb24sIHBhcnNlZCwgc2NoZW1hcylcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgbmV3IEFjdGlvbnMganNvbjogJHtKU09OLnN0cmluZ2lmeSh1cGRhdGVkLCBudWxsLCAyKX1gKVxuXG5cdFx0XHQvLyBTYXZlIHRoZSB1cGRhdGVkIEpTT04gdG8gZGlza1xuXHRcdFx0Y29uc3QgZGV2aWNlc0ZvbGRlciA9IGdldERldmljZXNGb2xkZXIoKVxuXHRcdFx0Y29uc3Qgc2NoZW1hUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBgTW9kZWwke21vZGVsfS5qc29uYClcblx0XHRcdHNhdmVNb2RlbEpzb25QcmV0dHkoc2NoZW1hUGF0aCwgdXBkYXRlZClcblxuXHRcdFx0Ly8gUmVsb2FkIHRoZSBjYWNoZSBhZnRlciB3cml0aW5nIHRvIGZpbGVcblx0XHRcdHJlbG9hZERldmljZVNjaGVtYXMoKVxuXG5cdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gSlNPTiBhdXRvLXVwZGF0ZWQgZnJvbSBnZXRBbGxTZXR0aW5nc2ApXG5cdFx0fSxcblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgQUNUSU9OUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFthY3Rpb25JZCwgYWN0aW9uXSBvZiBPYmplY3QuZW50cmllcyhyYXdBY3Rpb25zKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGFjdGlvbklkKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGFjdGlvbnMgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIEdldCB0aGUgcmF3IGFjdGlvbiBzY2hlbWEgdG8gYWNjZXNzIGZpeGVkIGJ1c0NoIHZhbHVlXG5cdFx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0XHRjb25zdCByYXdBY3Rpb24gPSBzY2hlbWE/LmNtZFNjaGVtYT8uZmluZCgoYTogYW55KSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gYmFzZUlkKVxuXG5cdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdC4uLmFjdGlvbixcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoZXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGV2ZW50Lm9wdGlvbnNbJ2J1c0NoJ10gIT09IHVuZGVmaW5lZCA/IGV2ZW50Lm9wdGlvbnNbJ2J1c0NoJ10gOiByYXdBY3Rpb24/LmJ1c0NoXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZXZlbnQub3B0aW9uc1sndmFsdWUnXVxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGV2ZW50Lm9wdGlvbnNbJ2lkQWRkJ10gPz8gMFxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBiYXNlSWQgKyBpZEFkZFxuXG5cdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnNlbmRBd2FpdEFjayhjbWRJZCwgYnVzQ2gsIHNldHRpbmdJZCwgdmFsdWUsIGlwKVxuXHRcdFx0fSxcblx0XHR9XG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IE1JQyBLSUxMIChPTkxZIElGIEFDVElWRSBNT0RFTCBTVVBQT1JUUyBJVClcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdGNvbnN0IGFjdGl2ZVNjaGVtYSA9IHNjaGVtYXNbYWN0aXZlTW9kZWxdXG5cdGlmIChhY3RpdmVTY2hlbWEpIHtcblx0XHRjb25zdCBzdXBwb3J0c01pY0tpbGwgPSAoYWN0aXZlU2NoZW1hLmNtZFNjaGVtYSA/PyBbXSkuc29tZSgoYTogYW55KSA9PiBhLm5hbWUuaW5jbHVkZXMoJ0tpbGwnKSlcblxuXHRcdGlmIChzdXBwb3J0c01pY0tpbGwpIHtcblx0XHRcdGNvbnN0IGFjdGlvbklkID0gYCR7YWN0aXZlTW9kZWx9X21pY0tpbGxgXG5cblx0XHRcdHdpcmVkQWN0aW9uc1thY3Rpb25JZF0gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke2FjdGl2ZU1vZGVsfV0gTWljIEtpbGxgLFxuXHRcdFx0XHRvcHRpb25zOiBbXSxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBNaWMgS2lsbCBcdTIxOTIgTW9kZWwgJHthY3RpdmVNb2RlbH0gQCAke2lwfWApXG5cdFx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIuZ2xvYmFsTWljS2lsbChpcClcblx0XHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gcmVmcmVzaCBzZXR0aW5ncyBhZnRlciBjb21tYW5kOiAke2Vycn1gKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0c2VsZi5zZXRBY3Rpb25EZWZpbml0aW9ucyh3aXJlZEFjdGlvbnMpXG5cblx0Ly9jb25zb2xlLmxvZygnQWN0aW9uczpcXG4nLCBKU09OLnN0cmluZ2lmeSh3aXJlZEFjdGlvbnMsIG51bGwsIDIpKVxufVxuIiwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYSB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9NSUNfUFJFLFxuXHRDTURfQlVTX1NFVCxcblx0Q01EX0NIQU5ORUwsXG5cdENNRF9ERVZfU1BFQyxcblx0Q01EX0dFVF9BTExfU0VUVElOR1MsXG5cdENNRF9NSUNfUFJFX0JVUyxcblx0Q01EX1NFVFRJTkdTX1BVU0gsXG5cdHRvSGV4LFxuXHRieXRlc1RvSGV4LFxuXHRmb3JtYXRSZ2JDb2xvcixcblx0bW9kZWxEaXN0YW5jZSxcbn0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdTZXR0aW5nc1BhcnNlcicpXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFRZUEVTXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCB0eXBlIFBhcnNlZFNldHRpbmcgPSB7XG5cdGNtZF9pZDogbnVtYmVyXG5cdGlkOiBudW1iZXJcblx0YnVzQ2g/OiBudW1iZXIgLy8gT3B0aW9uYWw6IG9ubHkgcHJlc2VudCBmb3IgY29tbWFuZHMgd2l0aCBidXNDaCAoMHgwNCwgMHgxMiwgMHgxNClcblx0dmFsdWVCeXRlczogbnVtYmVyW11cbn1cblxuZXhwb3J0IHR5cGUgU3RBY3Rpb25PcHRpb24gPSB7XG5cdGlkPzogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0dHlwZTogc3RyaW5nXG5cdGRlZmF1bHQ6IHVua25vd25cblx0dG9vbHRpcD86IHN0cmluZ1xuXHRjaG9pY2VzPzogQXJyYXk8eyBpZDogbnVtYmVyOyBsYWJlbDogc3RyaW5nIH0+XG59XG5cbmV4cG9ydCB0eXBlIFN0QWN0aW9uID0ge1xuXHRjbWRfaWQ6IG51bWJlclxuXHRpZDogbnVtYmVyXG5cdG5hbWU6IHN0cmluZ1xuXHRvcHRpb25zOiBTdEFjdGlvbk9wdGlvbltdXG5cdGJ1c0NoPzogbnVtYmVyIC8vIEZpeGVkIGNoYW5uZWwgdmFsdWUgZm9yIGFjdGlvbnMgdGhhdCBkb24ndCBoYXZlIGEgY2hhbm5lbCBvcHRpb25cblx0cmVhZG9ubHk/OiBib29sZWFuIC8vIElmIHRydWUsIGVudHJ5IGlzIGZlZWRiYWNrLW9ubHkgXHUyMDE0IG5vIGFjdGlvbiB3aWxsIGJlIGNyZWF0ZWRcbn1cblxuZXhwb3J0IHR5cGUgU3RNb2RlbEpzb24gPSB7XG5cdG1vZGVsOiBzdHJpbmdcblx0c2VjdGlvbmVkPzogYm9vbGVhblxuXHRyZWZyZXNoQWZ0ZXJDb21tYW5kPzogYm9vbGVhblxuXHRjbWRTY2hlbWE6IFN0QWN0aW9uW11cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRk9STUFUIEhFTFBFUlNcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gZ2V0TW9kZWxDb25maWcobW9kZWw6IHN0cmluZyk6IHsgc2VjdGlvbmVkOiBib29sZWFuOyByZ2JJZHM6IFNldDxudW1iZXI+IH0ge1xuXHRjb25zdCByZ2JJZHMgPSBuZXcgU2V0PG51bWJlcj4oKVxuXHRsZXQgc2VjdGlvbmVkID0gZmFsc2VcblxuXHR0cnkge1xuXHRcdC8vIFVzZSBjZW50cmFsaXplZCBjYWNoZSBpbnN0ZWFkIG9mIHJlYWRpbmcgZnJvbSBkaXNrXG5cdFx0Y29uc3QganNvbiA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0XHRpZiAoIWpzb24pIHtcblx0XHRcdC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHNjaGVtYSwgcmV0dXJuIGRlZmF1bHRzXG5cdFx0XHRyZXR1cm4geyBzZWN0aW9uZWQsIHJnYklkcyB9XG5cdFx0fVxuXG5cdFx0Ly8gUmVhZCBzZWN0aW9uZWQgcHJvcGVydHkgKGRlZmF1bHQgdG8gZmFsc2UgaWYgbm90IHNwZWNpZmllZClcblx0XHRzZWN0aW9uZWQgPSBqc29uLnNlY3Rpb25lZCA/PyBmYWxzZVxuXG5cdFx0Ly8gQnVpbGQgUkdCIElEcyBzZXRcblx0XHRmb3IgKGNvbnN0IGFjdGlvbiBvZiBqc29uLmNtZFNjaGVtYSB8fCBbXSkge1xuXHRcdFx0Y29uc3QgaGFzQ29sb3JwaWNrZXIgPSBhY3Rpb24ub3B0aW9ucz8uc29tZSgob3B0OiBTdEFjdGlvbk9wdGlvbikgPT4gb3B0LnR5cGUgPT09ICdjb2xvcnBpY2tlcicpXG5cdFx0XHRpZiAoaGFzQ29sb3JwaWNrZXIpIHtcblx0XHRcdFx0Ly8gQWRkIHRoZSBiYXNlIElEXG5cdFx0XHRcdHJnYklkcy5hZGQoYWN0aW9uLmlkKVxuXG5cdFx0XHRcdC8vIElmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCBjaG9pY2VzLCBhZGQgYWxsIHRoZSBvZmZzZXQgSURzIHRvb1xuXHRcdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdGlmIChpZEFkZE9wdGlvbj8uY2hvaWNlcykge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgY2hvaWNlIG9mIGlkQWRkT3B0aW9uLmNob2ljZXMpIHtcblx0XHRcdFx0XHRcdGlmICh0eXBlb2YgY2hvaWNlLmlkID09PSAnbnVtYmVyJykge1xuXHRcdFx0XHRcdFx0XHRyZ2JJZHMuYWRkKGFjdGlvbi5pZCArIGNob2ljZS5pZClcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH0gY2F0Y2ggKF9lcnIpIHtcblx0XHQvLyBJZiB3ZSBjYW4ndCBsb2FkIHRoZSBzY2hlbWEsIHJldHVybiBkZWZhdWx0c1xuXHR9XG5cblx0cmV0dXJuIHsgc2VjdGlvbmVkLCByZ2JJZHMgfVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGSU5EIFRIRSBSRUFMIDVBIFBBWUxPQUQgSU5ERVhcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1ZjogQnVmZmVyKTogbnVtYmVyIHtcblx0Y29uc3Qgc2lnSW5kZXggPSBidWYuaW5kZXhPZihCdWZmZXIuZnJvbSgnU3R1ZGlvLVQnKSlcblx0aWYgKHNpZ0luZGV4IDwgMCkgdGhyb3cgbmV3IEVycm9yKCdObyBTdHVkaW8tVCBzaWduYXR1cmUgaW4gcGFja2V0JylcblxuXHRjb25zdCBwYXlsb2FkSW5kZXggPSBzaWdJbmRleCArIDhcblx0aWYgKGJ1ZltwYXlsb2FkSW5kZXhdICE9PSAweDVhKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCAweDVBIGFmdGVyIFN0dWRpby1ULCBmb3VuZCAke2J1ZltwYXlsb2FkSW5kZXhdLnRvU3RyaW5nKDE2KX1gKVxuXHR9XG5cblx0cmV0dXJuIHBheWxvYWRJbmRleFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGTEFUIFBBUlNFUlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBwYXJzZUZsYXRJZFZhbFNlcXVlbmNlKGJsb2NrOiBCdWZmZXIsIHJnYklkczogU2V0PG51bWJlcj4gPSBuZXcgU2V0KCkpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRsZXQgcCA9IDBcblx0Y29uc3Qgb3V0OiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdHdoaWxlIChwIDwgYmxvY2subGVuZ3RoKSB7XG5cdFx0Y29uc3QgaWQgPSBibG9ja1twXVxuXHRcdGlmIChwICsgMSA+PSBibG9jay5sZW5ndGgpIGJyZWFrXG5cblx0XHQvLyBSR0IgY2FzZSAtIGNoZWNrIGlmIHRoaXMgSUQgaXMgYSBrbm93biBjb2xvcnBpY2tlclxuXHRcdGlmIChyZ2JJZHMuaGFzKGlkKSAmJiBwICsgMyA8IGJsb2NrLmxlbmd0aCkge1xuXHRcdFx0b3V0LnB1c2goe1xuXHRcdFx0XHRjbWRfaWQ6IENNRF9ERVZfU1BFQyxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdHZhbHVlQnl0ZXM6IFtibG9ja1twICsgMV0sIGJsb2NrW3AgKyAyXSwgYmxvY2tbcCArIDNdXSxcblx0XHRcdH0pXG5cdFx0XHRwICs9IDRcblx0XHRcdGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0b3V0LnB1c2goeyBjbWRfaWQ6IENNRF9ERVZfU1BFQywgaWQsIHZhbHVlQnl0ZXM6IFtibG9ja1twICsgMV1dIH0pXG5cdFx0cCArPSAyXG5cdH1cblxuXHRyZXR1cm4gb3V0XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmOiBCdWZmZXIsIG1vZGVsOiBzdHJpbmcpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ05vdCBhIGdldEFsbFNldHRpbmdzIHJlcGx5Jylcblx0fVxuXG5cdGNvbnN0IGJsb2NrTGVuID0gYnVmW2lkeCArIDJdXG5cdGNvbnN0IHN0YXJ0ID0gaWR4ICsgM1xuXHRjb25zdCBlbmQgPSBzdGFydCArIGJsb2NrTGVuXG5cdGlmIChlbmQgPiBidWYubGVuZ3RoKSB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgYmxvY2sgbGVuZ3RoJylcblxuXHRjb25zdCB7IHJnYklkcyB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cdHJldHVybiBwYXJzZUZsYXRJZFZhbFNlcXVlbmNlKGJ1Zi5zdWJhcnJheShzdGFydCwgZW5kKSwgcmdiSWRzKVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTRUNUSU9ORUQgUEFSU0VSXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Ly8gQ01EX0dFVF9BTExfU0VUVElOR1MgaGFzIGEgdG90YWwtbGVuZ3RoIGJ5dGUgYXQgaWR4KzIgYmVmb3JlIHRoZSBzZWN0aW9uczsgQ01EX1NFVFRJTkdTX1BVU0ggZG9lcyBub3QuXG5cdGxldCBwID0gY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTID8gaWR4ICsgMyA6IGlkeCArIDJcblx0Y29uc3QgZW5kID0gYnVmLmxlbmd0aCAtIDFcblx0Y29uc3Qgb3V0OiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdC8vIEdldCBSR0IgSURzIGZvciB0aGlzIG1vZGVsXG5cdGNvbnN0IHsgcmdiSWRzIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblxuXHQvLyBDb21tYW5kIElEcyB0aGF0IGluY2x1ZGUgYSBidXNDaCBieXRlIGluIHRoZWlyIHNlY3Rpb24gc3RydWN0dXJlLFxuXHQvLyBmb2xsb3dlZCBieSBhIGRhdGFMZW4gYnl0ZSBhbmQgdGhlbiBpZDp2YWwgcGFpcnMuXG5cdGNvbnN0IGNvbW1hbmRzV2l0aEJ1c0NoID0gW0NNRF9CVVNfU0VULCBDTURfTUlDX1BSRV9CVVMsIENNRF9DSEFOTkVMXVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgYnV0IHN0b3JlIHJhdyBwb3NpdGlvbmFsIHZhbHVlIGJ5dGVzXG5cdC8vIHJhdGhlciB0aGFuIGlkOnZhbCBwYWlycyAobm8gZGF0YUxlbiBieXRlLCBubyBzZXR0aW5nIElEcykuXG5cdC8vIEZvcm1hdDogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gLi4uXG5cdGNvbnN0IGNvbW1hbmRzUmF3VmFsdWUgPSBbQ01EX01JQ19QUkVdIC8vIGNtZD0weDAyXG5cblx0d2hpbGUgKHAgKyAyIDwgZW5kKSB7XG5cdFx0Y29uc3QgY21kTGVuID0gYnVmW3BdXG5cdFx0Y29uc3Qgc2VjdGlvbkNtZElkID0gYnVmW3AgKyAxXVxuXG5cdFx0Y29uc3Qgc2VjdGlvbkVuZCA9IHAgKyAxICsgY21kTGVuXG5cdFx0aWYgKHNlY3Rpb25FbmQgPiBlbmQpIGJyZWFrXG5cblx0XHRjb25zdCBoYXNCdXNDaCA9IGNvbW1hbmRzV2l0aEJ1c0NoLmluY2x1ZGVzKHNlY3Rpb25DbWRJZClcblx0XHRjb25zdCBpc1Jhd1ZhbHVlID0gY29tbWFuZHNSYXdWYWx1ZS5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cblx0XHRsZXQgYnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZFxuXHRcdGxldCBkYXRhTGVuOiBudW1iZXJcblx0XHRsZXQgcTogbnVtYmVyXG5cblx0XHRpZiAoaXNSYXdWYWx1ZSkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW3ZhbDBdIFt2YWwxXSAuLi5cblx0XHRcdC8vIEJ1aWxkIHBvc2l0aW9uYWwgbWFwIGZyb20gc2NoZW1hOiBmaW5kIGFsbCBlbnRyaWVzIGZvciBDTURfTUlDX1BSRSAoMHgwMikgb3Jcblx0XHRcdC8vIENNRF9NSUNfUFJFX0JVUyAoMHgxMikgd2l0aCBhIGZpeGVkIGJ1c0NoLCBzb3J0ZWQgYnkgaWQgXHUyMDE0IGVhY2ggYmVjb21lcyBvbmVcblx0XHRcdC8vIHBvc2l0aW9uYWwgc2xvdC4gVGhpcyBtYWtlcyB0aGUgcmVtYXAgc2NoZW1hLWRyaXZlbjpcblx0XHRcdC8vICAgMjE0ICAoY21kX2lkPTIsICBpZD0wLzEpIFx1MjE5MiBwb3MwXHUyMTkyKDIsMCksICBwb3MxXHUyMTkyKDIsMSlcblx0XHRcdC8vICAgMjE0QSAoY21kX2lkPTE4LCBpZD0xLzIpIFx1MjE5MiBwb3MwXHUyMTkyKDE4LDEpLCBwb3MxXHUyMTkyKDE4LDIpXG5cdFx0XHQvLyBQb3NpdGlvbnMgd2l0aCBubyBzY2hlbWEgZW50cnkgYXJlIGRyb3BwZWQgKGUuZy4gdW5rbm93biAzcmQgYnl0ZSkuXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGNvbnN0IHJhd0J5dGVzID0gYnVmLnN1YmFycmF5KHAgKyAzLCBzZWN0aW9uRW5kKVxuXG5cdFx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0XHRjb25zdCBtaWNQcmVFbnRyaWVzID0gKHNjaGVtYT8uY21kU2NoZW1hID8/IFtdKVxuXHRcdFx0XHQuZmlsdGVyKChhOiBTdEFjdGlvbikgPT4gKGEuY21kX2lkID09PSBDTURfTUlDX1BSRSB8fCBhLmNtZF9pZCA9PT0gQ01EX01JQ19QUkVfQlVTKSAmJiBhLmJ1c0NoICE9PSB1bmRlZmluZWQpXG5cdFx0XHRcdC5zb3J0KChhOiBTdEFjdGlvbiwgYjogU3RBY3Rpb24pID0+IGEuaWQgLSBiLmlkKVxuXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IHJhd0J5dGVzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdGNvbnN0IGVudHJ5ID0gbWljUHJlRW50cmllc1tpXVxuXHRcdFx0XHRpZiAoZW50cnkpIHtcblx0XHRcdFx0XHRvdXQucHVzaCh7IGNtZF9pZDogZW50cnkuY21kX2lkLCBpZDogZW50cnkuaWQsIGJ1c0NoLCB2YWx1ZUJ5dGVzOiBbcmF3Qnl0ZXNbaV1dIH0pXG5cdFx0XHRcdH1cblx0XHRcdFx0Ly8gbm8gZW50cnkgPSB1bmtub3duIHBvc2l0aW9uYWwgYnl0ZSwgZHJvcCBpdFxuXHRcdFx0fVxuXHRcdFx0cCA9IHNlY3Rpb25FbmRcblx0XHRcdGNvbnRpbnVlXG5cdFx0fSBlbHNlIGlmIChoYXNCdXNDaCkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW2RhdGFMZW5dIFtpZDp2YWwgcGFpcnNdXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDNdXG5cdFx0XHRxID0gcCArIDRcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0ZGF0YUxlbiA9IGJ1ZltwICsgMl1cblx0XHRcdHEgPSBwICsgM1xuXHRcdH1cblxuXHRcdGNvbnN0IHFFbmQgPSBxICsgZGF0YUxlblxuXHRcdGNvbnN0IHFTdGFydCA9IHFcblxuXHRcdHdoaWxlIChxICsgMSA8IHFFbmQpIHtcblx0XHRcdGNvbnN0IGlkID0gYnVmW3FdXG5cdFx0XHRsZXQgdmFsdWVCeXRlczogbnVtYmVyW11cblxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBJRCBpcyBhbiBSR0IgY29sb3JwaWNrZXIgKG5lZWRzIDMgYnl0ZXMpXG5cdFx0XHRpZiAocmdiSWRzLmhhcyhpZCkgJiYgcSArIDMgPCBxRW5kKSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXSwgYnVmW3EgKyAyXSwgYnVmW3EgKyAzXV1cblx0XHRcdFx0cSArPSA0XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV1dXG5cdFx0XHRcdHEgKz0gMlxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IHNlY3Rpb25DbWRJZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdH1cblx0XHRcdG91dC5wdXNoKHNldHRpbmcpXG5cdFx0fVxuXG5cdFx0Ly8gUG9zaXRpb25hbCBmYWxsYmFjazogaWYgdGhlIGJ5dGUgd2UgcmVhZCBhcyBkYXRhTGVuIHdhcyAweDAwIGJ1dCB0aGUgc2VjdGlvblxuXHRcdC8vIHN0aWxsIGNvbnRhaW5zIGRhdGEgYnl0ZXMsIHRoaXMgc2VjdGlvbiBsaWtlbHkgdXNlcyBhIG5vLWRhdGFMZW4gZm9ybWF0IHdoZXJlXG5cdFx0Ly8gZWFjaCBieXRlIGFmdGVyIGNtZElkIGlzIGEgcmF3IHZhbHVlIGF0IGEgZml4ZWQgcG9zaXRpb24gKHBvc2l0aW9uID0gaWQpLlxuXHRcdC8vIFJlLXBhcnNlIGZyb20gcCsyIChyaWdodCBhZnRlciBjbWRJZCksIHRyZWF0aW5nIHRoZSBcImRhdGFMZW5cIiBieXRlIGFzIGlkPTAuXG5cdFx0Ly8gT25seSBmaXJlIGlmIG5vIGJ5dGVzIHdlcmUgY29uc3VtZWQgYnkgdGhlIG1haW4gbG9vcCAocSA9PT0gcVN0YXJ0KSwgdG8gYXZvaWRcblx0XHQvLyByZS1wYXJzaW5nIGJ5dGVzIHRoYXQgd2VyZSBhbHJlYWR5IHN1Y2Nlc3NmdWxseSBwYXJzZWQuXG5cdFx0aWYgKHEgPT09IHFTdGFydCAmJiBzZWN0aW9uRW5kID4gcCArIDMpIHtcblx0XHRcdGxldCBwb3MgPSBoYXNCdXNDaCA/IHAgKyAzIDogcCArIDIgLy8gc2tpcCBjbWRJZCAoYW5kIGJ1c0NoIGlmIHByZXNlbnQpXG5cdFx0XHRsZXQgcG9zSWQgPSAwXG5cdFx0XHR3aGlsZSAocG9zIDwgc2VjdGlvbkVuZCkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0geyBjbWRfaWQ6IHNlY3Rpb25DbWRJZCwgaWQ6IHBvc0lkKyssIHZhbHVlQnl0ZXM6IFtidWZbcG9zKytdXSB9XG5cdFx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdFx0b3V0LnB1c2goc2V0dGluZylcblx0XHRcdH1cblx0XHR9XG5cblx0XHRwID0gc2VjdGlvbkVuZFxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBHRU5FUklDIFNFVFRJTkdTIFJFU1BPTlNFIFBBUlNFUiAoMHgwYSBnZXQtYWxsICsgMHgwYiB1bnNvbGljaXRlZCBwdXNoKVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBhbnkgZnVsbCBzZXR0aW5ncyBibG9jayByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhlIGNtZElkIGlzIDB4MGFcbiAqIChyZXNwb25zZSB0byBHZXQgQWxsIFNldHRpbmdzKSBvciAweDBiICh1bnNvbGljaXRlZCBwdXNoIGFmdGVyIGEgc2V0KS5cbiAqIEJvdGggdXNlIHRoZSBzYW1lIHNlY3Rpb25lZCBvciBmbGF0IGJsb2NrIGxheW91dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ3NSZXNwb25zZShtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgTm90IGEgc2V0dGluZ3MgYmxvY2sgKGNtZElkPTB4JHtjbWRJZC50b1N0cmluZygxNil9KWApXG5cdH1cblx0Y29uc3QgeyBzZWN0aW9uZWQgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gc2VjdGlvbmVkID8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbCkgOiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcbn1cblxuLyoqXG4gKiBGb3JtYXRzIGEgc2luZ2xlIHBhcnNlZCBzZXR0aW5nIGludG8gYSBodW1hbi1yZWFkYWJsZSBzdHJpbmcgdXNpbmcgYWN0aW9uXG4gKiBkZWZpbml0aW9ucyBmcm9tIHRoZSBkZXZpY2UgSlNPTi4gRmFsbHMgYmFjayB0byBoZXggSURzIHdoZW4gdW5rbm93bi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZzogUGFyc2VkU2V0dGluZywgYWN0aW9uczogU3RBY3Rpb25bXSk6IHN0cmluZyB7XG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gc2V0dGluZy5jbWRfaWQgJiYgYS5pZCA9PT0gc2V0dGluZy5pZClcblxuXHQvLyBJZiBubyBleGFjdCBtYXRjaCBhbmQgaWQgPiBiYXNlIGlkLCB0cnkgdG8gZmluZCBhY3Rpb24gd2l0aCBpZEFkZCBvcHRpb25cblx0Ly8gVGhpcyBoYW5kbGVzIGNhc2VzIGxpa2UgQ01EX0hFQURQSE9ORSAoMHgwNSwgZS5nLiBQaG9uZXMgUm91dGluZykgYW5kXG5cdC8vIENNRF9CVVRUT05fTU9ERSAoMHgwNywgZS5nLiBCdXR0b25zKSB3aGVyZSBpZCAwLTMgcmVwcmVzZW50cyBjaGFubmVscyAxLTRcblx0aWYgKCFhY3Rpb24pIHtcblx0XHRjb25zdCBiYXNlQWN0aW9uID0gYWN0aW9ucy5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IHNldHRpbmcuY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHRoaXMgYWN0aW9uIGhhcyBhbiBpZEFkZCBvcHRpb24gKGluZGljYXRpbmcgY2hhbm5lbCBzZWxlY3Rpb24pXG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGEub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHRoZSBzZXR0aW5nLmlkIG9mZnNldCBtYXRjaGVzIG9uZSBvZiB0aGUgaWRBZGQgY2hvaWNlIElEc1xuXHRcdFx0Y29uc3QgY2hhbm5lbE9mZnNldCA9IHNldHRpbmcuaWQgLSBhLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdH0pXG5cdFx0aWYgKGJhc2VBY3Rpb24pIHtcblx0XHRcdGFjdGlvbiA9IGJhc2VBY3Rpb25cblx0XHR9XG5cdH1cblxuXHRjb25zdCBjbWRIZXggPSB0b0hleChzZXR0aW5nLmNtZF9pZClcblx0Y29uc3QgaWRIZXggPSB0b0hleChzZXR0aW5nLmlkKVxuXHRjb25zdCB2YWxIZXggPSBieXRlc1RvSGV4KHNldHRpbmcudmFsdWVCeXRlcylcblx0Y29uc3QgdmFsRGVjID1cblx0XHRzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHQ/IGZvcm1hdFJnYkNvbG9yKHNldHRpbmcudmFsdWVCeXRlc1swXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzFdLCBzZXR0aW5nLnZhbHVlQnl0ZXNbMl0pXG5cdFx0XHQ6IHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDFcblx0XHRcdFx0PyBzZXR0aW5nLnZhbHVlQnl0ZXNbMF1cblx0XHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMuam9pbignLCcpXG5cblx0Ly8gQnVpbGQgdGhlIHByZWZpeDogY21kOjB4MTIgY2g6MCBpZDoweDAxIHZhbDoweDE0IChjaCBvbmx5IGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoKVxuXHRjb25zdCBidXNDaFN0ciA9IHNldHRpbmcuYnVzQ2ggIT09IHVuZGVmaW5lZCA/IGAgY2g6JHtzZXR0aW5nLmJ1c0NofWAgOiAnJ1xuXHRjb25zdCBwcmVmaXggPSBgY21kOiR7Y21kSGV4fSR7YnVzQ2hTdHJ9IGlkOiR7aWRIZXh9IHZhbDoke3ZhbEhleH1gXG5cblx0Ly8gSWYgd2UgaGF2ZSBhbiBhY3Rpb24gd2l0aCBhIG5hbWUgYW5kIGNob2ljZSBsYWJlbCwgdXNlIGl0XG5cdGlmIChhY3Rpb24pIHtcblx0XHRsZXQgbmFtZSA9IGFjdGlvbi5uYW1lXG5cblx0XHQvLyBJZiBzZXR0aW5nIGhhcyBidXNDaCwgYWRkIGNoYW5uZWwgaW5mbyB0byBuYW1lXG5cdFx0aWYgKHNldHRpbmcuYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0bmFtZSA9IGAke25hbWV9IENoJHtzZXR0aW5nLmJ1c0NoICsgMX1gXG5cdFx0fVxuXHRcdC8vIE90aGVyd2lzZSwgaWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkLCBpbmNsdWRlIHRoZSBpZEFkZCBsYWJlbFxuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoaWRBZGRPcHRpb24/LmNob2ljZXMpIHtcblx0XHRcdFx0Y29uc3QgY2hhbm5lbE9mZnNldCA9IHNldHRpbmcuaWQgLSBhY3Rpb24uaWRcblx0XHRcdFx0Y29uc3QgaWRBZGRDaG9pY2UgPSBpZEFkZE9wdGlvbi5jaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IGNoYW5uZWxPZmZzZXQpXG5cdFx0XHRcdGlmIChpZEFkZENob2ljZSkge1xuXHRcdFx0XHRcdG5hbWUgPSBgJHtuYW1lfSAke2lkQWRkQ2hvaWNlLmxhYmVsfWBcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIExvb2sgZm9yIHRoZSB2YWx1ZSBvcHRpb24gKG5vdCBidXNDaCBvciBpZEFkZClcblx0XHRjb25zdCB2YWx1ZU9wdGlvbiA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0XHRpZiAodmFsdWVPcHRpb24/LmNob2ljZXMgJiYgc2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBzZXR0aW5nLnZhbHVlQnl0ZXNbMF0pXG5cdFx0XHRpZiAoY2hvaWNlKSB7XG5cdFx0XHRcdHJldHVybiBgJHtwcmVmaXh9IHwgJHtuYW1lfTogJHtjaG9pY2UubGFiZWx9ICgke3ZhbERlY30pYFxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7dmFsRGVjfWBcblx0fVxuXG5cdC8vIE5vIGFjdGlvbiBmb3VuZCAtIGp1c3Qgc2hvdyB0aGUgcmF3IHZhbHVlc1xuXHRyZXR1cm4gYCR7cHJlZml4fSB8IFVua25vd24gU2V0dGluZ2Bcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgUEFSU0VSIERJU1BBVENIIFdJVEggQVVUTy1ERVRFQ1RJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBQYXJzZXMgZ2V0QWxsU2V0dGluZ3MgcmVzcG9uc2Ugd2l0aCBhdXRvbWF0aWMgZm9ybWF0IGRldGVjdGlvbi5cbiAqXG4gKiBTdHJhdGVneTpcbiAqIDEuIElmIG1vZGVsIGhhcyBleHBsaWNpdCBcInNlY3Rpb25lZFwiIHByb3BlcnR5LCB1c2UgdGhhdFxuICogMi4gT3RoZXJ3aXNlLCB0cnkgRkxBVCBwYXJzZXIgZmlyc3QgKGl0J3Mgc2ltcGxlcilcbiAqIDMuIElmIEZMQVQgcmV0dXJucyAwIHNldHRpbmdzLCB0cnkgU0VDVElPTkVEIHBhcnNlclxuICogNC4gVXNlIHdoaWNoZXZlciBwYXJzZXIgcmV0dXJucyBtb3JlIHNldHRpbmdzXG4gKlxuICogQHJldHVybnMge3NldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10sIGRldGVjdGVkU2VjdGlvbmVkOiBib29sZWFuIHwgbnVsbH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRidWY6IEJ1ZmZlcixcbik6IHsgc2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXTsgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGJvb2xlYW4gfCBudWxsIH0ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdGNvbnN0IGRlY2xhcmVkU2VjdGlvbmVkID0gc2NoZW1hPy5zZWN0aW9uZWRcblxuXHQvLyBJZiBleHBsaWNpdGx5IGRlY2xhcmVkIGluIEpTT04sIHVzZSB0aGF0XG5cdGlmIChkZWNsYXJlZFNlY3Rpb25lZCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0Y29uc3Qgc2V0dGluZ3MgPSBkZWNsYXJlZFNlY3Rpb25lZFxuXHRcdFx0PyBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKVxuXHRcdFx0OiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcblx0XHRyZXR1cm4geyBzZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfSAvLyBudWxsID0gdXNlZCBkZWNsYXJlZCB2YWx1ZVxuXHR9XG5cblx0Ly8gTm8gZGVjbGFyYXRpb24gLSB0cnkgYm90aCBwYXJzZXJzIGFuZCBwaWNrIHRoZSBiZXN0IG9uZVxuXHRsZXQgZmxhdFNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXHRsZXQgc2VjdGlvbmVkU2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0dHJ5IHtcblx0XHRmbGF0U2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5kZWJ1ZyhgRmxhdCBwYXJzZXIgZmFpbGVkOiAke2V9YClcblx0fVxuXG5cdHRyeSB7XG5cdFx0c2VjdGlvbmVkU2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBTZWN0aW9uZWQgcGFyc2VyIGZhaWxlZDogJHtlfWApXG5cdH1cblxuXHQvLyBQaWNrIHRoZSBwYXJzZXIgdGhhdCByZXR1cm5lZCBtb3JlIHNldHRpbmdzXG5cdGlmIChzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGggPiBmbGF0U2V0dGluZ3MubGVuZ3RoKSB7XG5cdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgU0VDVElPTkVEIGZvcm1hdCAoc2VjdGlvbmVkPSR7c2VjdGlvbmVkU2V0dGluZ3MubGVuZ3RofSB2cyBmbGF0PSR7ZmxhdFNldHRpbmdzLmxlbmd0aH0pYClcblx0XHRyZXR1cm4geyBzZXR0aW5nczogc2VjdGlvbmVkU2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiB0cnVlIH1cblx0fSBlbHNlIGlmIChmbGF0U2V0dGluZ3MubGVuZ3RoID4gMCkge1xuXHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIEZMQVQgZm9ybWF0IChmbGF0PSR7ZmxhdFNldHRpbmdzLmxlbmd0aH0gdnMgc2VjdGlvbmVkPSR7c2VjdGlvbmVkU2V0dGluZ3MubGVuZ3RofSlgKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBmbGF0U2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiBmYWxzZSB9XG5cdH0gZWxzZSB7XG5cdFx0Ly8gQm90aCBwYXJzZXJzIHJldHVybmVkIDAgc2V0dGluZ3Ncblx0XHRsb2dnZXIud2FybihgV2FybmluZzogQm90aCBwYXJzZXJzIHJldHVybmVkIDAgc2V0dGluZ3MgZm9yIG1vZGVsICR7bW9kZWx9YClcblx0XHRyZXR1cm4geyBzZXR0aW5nczogW10sIGRldGVjdGVkU2VjdGlvbmVkOiBudWxsIH1cblx0fVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsKG1vZGVsOiBzdHJpbmcsIGJ1ZjogQnVmZmVyKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgeyBzZWN0aW9uZWQgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gc2VjdGlvbmVkID8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbCkgOiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcbn1cblxuLyogXHUyNzA1IGJhY2t3YXJkLWNvbXBhdGlibGUgZXhwb3J0ICovXG5leHBvcnQgY29uc3QgcGFyc2VHZXRBbGxTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbFxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBWQUxVRSBcdTIxOTIgT1BUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzOiBudW1iZXJbXSk6IFN0QWN0aW9uT3B0aW9uIHtcblx0aWYgKHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxKSB7XG5cdFx0cmV0dXJuIHsgaWQ6ICd2YWx1ZScsIGxhYmVsOiAnVmFsdWUnLCB0eXBlOiAnbnVtYmVyJywgZGVmYXVsdDogdmFsdWVCeXRlc1swXSB9XG5cdH1cblxuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDMpIHtcblx0XHRjb25zdCBbciwgZywgYl0gPSB2YWx1ZUJ5dGVzXG5cdFx0cmV0dXJuIHtcblx0XHRcdGlkOiAndmFsdWUnLFxuXHRcdFx0bGFiZWw6ICdDb2xvcicsXG5cdFx0XHR0eXBlOiAnY29sb3JwaWNrZXInLFxuXHRcdFx0ZGVmYXVsdDogZm9ybWF0UmdiQ29sb3IociwgZywgYiksXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIHsgaWQ6ICd2YWx1ZScsIGxhYmVsOiAnVmFsdWUnLCB0eXBlOiAncmF3JywgZGVmYXVsdDogWy4uLnZhbHVlQnl0ZXNdIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU01BUlQgSlNPTiBVUERBVEVcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyhcblx0bW9kZWxKc29uOiBTdE1vZGVsSnNvbixcblx0cGFyc2VkOiBQYXJzZWRTZXR0aW5nW10sXG5cdGFsbE1vZGVsczogUmVjb3JkPHN0cmluZywgU3RNb2RlbEpzb24+LFxuKTogU3RNb2RlbEpzb24ge1xuXHRjb25zdCBvdXQgPSBzdHJ1Y3R1cmVkQ2xvbmUobW9kZWxKc29uKVxuXG5cdC8vIEVuc3VyZSBjbWRTY2hlbWEgYXJyYXkgZXhpc3RzXG5cdGlmICghb3V0LmNtZFNjaGVtYSkge1xuXHRcdG91dC5jbWRTY2hlbWEgPSBbXVxuXHR9XG5cblx0Ly8gU29ydCBvdGhlciBtb2RlbHMgYnkgbnVtZXJpYyBkaXN0YW5jZSB0byBjdXJyZW50IG1vZGVsXG5cdGNvbnN0IGNhbmRpZGF0ZXMgPSBPYmplY3QudmFsdWVzKGFsbE1vZGVscylcblx0XHQuZmlsdGVyKChtKSA9PiBtLm1vZGVsICE9PSBtb2RlbEpzb24ubW9kZWwpIC8vIGV4Y2x1ZGUgc2VsZlxuXHRcdC5zb3J0KChhLCBiKSA9PiBtb2RlbERpc3RhbmNlKG1vZGVsSnNvbi5tb2RlbCwgYS5tb2RlbCkgLSBtb2RlbERpc3RhbmNlKG1vZGVsSnNvbi5tb2RlbCwgYi5tb2RlbCkpXG5cblx0bG9nZ2VyLmluZm8oYFVwZGF0aW5nIG1vZGVsOiAke21vZGVsSnNvbi5tb2RlbH1gKVxuXHRsb2dnZXIuZGVidWcoYENhbmRpZGF0ZXMgZm9yIGluZmVyZW5jZTogJHtjYW5kaWRhdGVzLm1hcCgoYykgPT4gYy5tb2RlbCkuam9pbignLCAnKX1gKVxuXG5cdC8vIFByZS1zY2FuOiBmb3IgZWFjaCBjYW5kaWRhdGUgaWRBZGQgYmFzZSBlbnRyeSwgZmluZCB0aGUgbWF4aW11bSBzZXF1ZW50aWFsXG5cdC8vIG9mZnNldCB0aGUgcGFja2V0IGNvbnRhaW5zIChldmVuIGJleW9uZCB3aGF0IHRoZSByZWZlcmVuY2UgbW9kZWwga25vd3MpLlxuXHQvLyBLZXk6IGAke2NtZF9pZH1fJHtiYXNlX2lkfWAsIHZhbHVlOiBtYXggc2VxdWVudGlhbCBvZmZzZXQgc2VlbiBpbiBwYXJzZWQgZGF0YS5cblx0Y29uc3QgaWRBZGREZWZlclJhbmdlcyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRmb3IgKGNvbnN0IGJhc2VFbnRyeSBvZiBjLmNtZFNjaGVtYSA/PyBbXSkge1xuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBiYXNlRW50cnkub3B0aW9ucz8uZmluZCgobzogYW55KSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcykgY29udGludWVcblx0XHRcdGNvbnN0IGJhc2VJZCA9IGJhc2VFbnRyeS5pZFxuXHRcdFx0Y29uc3QgY21kSWQgPSBiYXNlRW50cnkuY21kX2lkXG5cdFx0XHRjb25zdCBrZXkgPSBgJHtjbWRJZH1fJHtiYXNlSWR9YFxuXHRcdFx0aWYgKGlkQWRkRGVmZXJSYW5nZXMuaGFzKGtleSkpIGNvbnRpbnVlXG5cdFx0XHQvLyBGaW5kIHRoZSBtYXggc2VxdWVudGlhbCBvZmZzZXQgcHJlc2VudCBpbiB0aGUgcGFyc2VkIHBhY2tldCBmb3IgdGhpcyBiYXNlXG5cdFx0XHRjb25zdCBwYXJzZWRPZmZzZXRzID0gcGFyc2VkXG5cdFx0XHRcdC5maWx0ZXIoKHApID0+IHAuY21kX2lkID09PSBjbWRJZCAmJiBwLmlkID4gYmFzZUlkKVxuXHRcdFx0XHQubWFwKChwKSA9PiBwLmlkIC0gYmFzZUlkKVxuXHRcdFx0XHQuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cdFx0XHQvLyBXYWxrIGZyb20gMSB1cHdhcmQgXHUyMDE0IHN0b3AgYXQgZmlyc3QgZ2FwXG5cdFx0XHRsZXQgbWF4U2VxID0gMFxuXHRcdFx0Zm9yIChjb25zdCBvZmYgb2YgcGFyc2VkT2Zmc2V0cykge1xuXHRcdFx0XHRpZiAob2ZmID09PSBtYXhTZXEgKyAxKSBtYXhTZXEgPSBvZmZcblx0XHRcdFx0ZWxzZSBpZiAob2ZmID4gbWF4U2VxICsgMSkgYnJlYWtcblx0XHRcdH1cblx0XHRcdGlmIChtYXhTZXEgPiAwKSB7XG5cdFx0XHRcdGlkQWRkRGVmZXJSYW5nZXMuc2V0KGtleSwgbWF4U2VxKVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYGlkQWRkIGRlZmVyIHJhbmdlIGZvciBjbWRfaWQ9JHt0b0hleChjbWRJZCl9IGJhc2VfaWQ9JHt0b0hleChiYXNlSWQpfTogb2Zmc2V0cyAxXHUyMDEzJHttYXhTZXF9YClcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQvLyBQcmUtY29tcHV0ZSB0aGUgc2V0IG9mIGFsbCBidXNDaCB2YWx1ZXMgc2VlbiBwZXIgKGNtZF9pZCwgaWQpIHBhaXIgYWNyb3NzIHRoZSBmdWxsXG5cdC8vIHBhcnNlZCByZXNwb25zZSBcdTIwMTQgdXNlZCBsYXRlciB0byBkZWNpZGUgZml4ZWQgdnMuIHNlbGVjdGFibGUgYnVzQ2guXG5cdGNvbnN0IGJ1c0NoU2VlbiA9IG5ldyBNYXA8c3RyaW5nLCBTZXQ8bnVtYmVyPj4oKVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCwgYnVzQ2ggfSBvZiBwYXJzZWQpIHtcblx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkgY29udGludWVcblx0XHRjb25zdCBrZXkgPSBgJHtjbWRfaWR9XyR7aWR9YFxuXHRcdGlmICghYnVzQ2hTZWVuLmhhcyhrZXkpKSBidXNDaFNlZW4uc2V0KGtleSwgbmV3IFNldCgpKVxuXHRcdGJ1c0NoU2Vlbi5nZXQoa2V5KSEuYWRkKGJ1c0NoKVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBQQVNTIDE6IHJlc29sdmUgZWFjaCBwYXJzZWQgZW50cnkgXHUyMDE0IGV4YWN0IG1hdGNoLCBpbmZlcnJlZCxcblx0Ly8gaWRBZGQtZm9sZCAob2Zmc2V0IGludG8gYW4gYWxyZWFkeS1hZGRlZCBiYXNlIGVudHJ5KSwgb3IgdW5rbm93blxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdGZvciAoY29uc3QgeyBjbWRfaWQsIGlkLCBidXNDaCwgdmFsdWVCeXRlcyB9IG9mIHBhcnNlZCkge1xuXHRcdC8vIDFhLiBFeGFjdCBtYXRjaCBhbHJlYWR5IGluIG91dHB1dCBzY2hlbWEgXHUyMDE0IGp1c3QgcmVmcmVzaCB0aGUgZGVmYXVsdFxuXHRcdGNvbnN0IGV4aXN0aW5nRXhhY3QgPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0aWYgKGV4aXN0aW5nRXhhY3QpIHtcblx0XHRcdGNvbnN0IG9wdCA9IGV4aXN0aW5nRXhhY3Qub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJylcblx0XHRcdGlmIChvcHQpIG9wdC5kZWZhdWx0ID0gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpLmRlZmF1bHRcblx0XHRcdGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0Ly8gMWIuIENoZWNrIGlmIHRoaXMgaWQgZm9sZHMgaW50byBhbiBhbHJlYWR5LWFkZGVkIGJhc2UgZW50cnkgdmlhIGlkQWRkLlxuXHRcdC8vICAgICBHYXRlOiB0aGUgb2Zmc2V0IG11c3QgYWN0dWFsbHkgZXhpc3QgaW4gdGhlIHJlZmVyZW5jZSBtb2RlbCdzIGlkQWRkIGNob2ljZXNcblx0XHQvLyAgICAgdG8gYXZvaWQgc3dhbGxvd2luZyB1bnJlbGF0ZWQgc2FtZS1jbWRfaWQgZW50cmllcyAoZS5nLiBTaWRldG9uZSBhdCBpZD0yMSkuXG5cdFx0Y29uc3QgaWRBZGRCYXNlID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0aWYgKGlkIDw9IGEuaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBhLmlkXG5cdFx0XHQvLyBPbmx5IGZvbGQgaWYgYSByZWZlcmVuY2UgbW9kZWwgZXhwbGljaXRseSBsaXN0cyB0aGlzIG9mZnNldCBpbiBpdHMgaWRBZGQgY2hvaWNlc1xuXHRcdFx0cmV0dXJuIGNhbmRpZGF0ZXMuc29tZSgoYykgPT4ge1xuXHRcdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChyKSA9PiByLmNtZF9pZCA9PT0gY21kX2lkICYmIHIuaWQgPT09IGEuaWQpXG5cdFx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdHJldHVybiByZWZJZEFkZD8uY2hvaWNlcz8uc29tZSgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHRcdH0pXG5cdFx0fSlcblx0XHRpZiAoaWRBZGRCYXNlKSB7XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGlkQWRkQmFzZS5pZFxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBpZEFkZEJhc2Uub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmIChpZEFkZE9wdD8uY2hvaWNlcyAmJiAhaWRBZGRPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldCkpIHtcblx0XHRcdFx0bGV0IGxhYmVsID0gYENoYW5uZWwgJHtvZmZzZXQgKyAxfWBcblx0XHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdGNvbnN0IHJlZkNob2ljZSA9IHJlZklkQWRkPy5jaG9pY2VzPy5maW5kKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0XHRcdGlmIChyZWZDaG9pY2UpIHtcblx0XHRcdFx0XHRcdGxhYmVsID0gcmVmQ2hvaWNlLmxhYmVsXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRpZEFkZE9wdC5jaG9pY2VzLnB1c2goeyBpZDogb2Zmc2V0LCBsYWJlbCB9KVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhcblx0XHRcdFx0XHRgRm9sZGVkIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBpbnRvIGlkQWRkIGJhc2UgaWQ9JHt0b0hleChpZEFkZEJhc2UuaWQpfSBhcyBvZmZzZXQgJHtvZmZzZXR9IChcIiR7bGFiZWx9XCIpYCxcblx0XHRcdFx0KVxuXHRcdFx0fVxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHQvLyAxYy4gTm8gZXhhY3QgbWF0Y2ggXHUyMDE0IHRyeSBpbmZlcmVuY2UgZnJvbSBjYW5kaWRhdGUgbW9kZWxzXG5cdFx0bGV0IGFjdGlvbjogU3RBY3Rpb24gfCB1bmRlZmluZWRcblxuXHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdFx0aWYgKG1hdGNoKSB7XG5cdFx0XHRcdGFjdGlvbiA9IHN0cnVjdHVyZWRDbG9uZShtYXRjaClcblx0XHRcdFx0Ly8gU3RyaXAgYW55IGV4aXN0aW5nIFwiKGluZmVycmVkIGZyb20gTW9kZWwgWClcIiBzdWZmaXhlcyBiZWZvcmUgYWRkaW5nIG91ciBvd25cblx0XHRcdFx0Y29uc3QgYmFzZU5hbWUgPSBtYXRjaC5uYW1lLnJlcGxhY2UoL1xccypcXChpbmZlcnJlZCBmcm9tIE1vZGVsIFteKV0rXFwpL2csICcnKS50cmltKClcblx0XHRcdFx0YWN0aW9uLm5hbWUgPSBgJHtiYXNlTmFtZX0gKGluZmVycmVkIGZyb20gTW9kZWwgJHtjLm1vZGVsfSlgXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBJbmZlcnJlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gZnJvbSBNb2RlbCAke2MubW9kZWx9IChleGFjdClgKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIENoZWNrIGlmIHRoaXMgaWQgc2hvdWxkIGJlIGRlZmVycmVkIHRvIHBhc3MgMiBcdTIwMTRcblx0XHQvLyBpdCdzIGEgc2VxdWVudGlhbCBpZEFkZCBvZmZzZXQgb2YgYSBrbm93biBjYW5kaWRhdGUgYmFzZSBlbnRyeS5cblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0bGV0IHNob3VsZERlZmVyID0gZmFsc2Vcblx0XHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRcdGNvbnN0IGJhc2VFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IHtcblx0XHRcdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG86IGFueSkgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRpZiAoaWQgPD0gYS5pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBhLmlkXG5cdFx0XHRcdFx0Y29uc3QgbWF4U2VxID0gaWRBZGREZWZlclJhbmdlcy5nZXQoYCR7Y21kX2lkfV8ke2EuaWR9YCkgPz8gMFxuXHRcdFx0XHRcdHJldHVybiBvZmZzZXQgPD0gbWF4U2VxXG5cdFx0XHRcdH0pXG5cdFx0XHRcdGlmIChiYXNlRW50cnkpIHtcblx0XHRcdFx0XHRzaG91bGREZWZlciA9IHRydWVcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0XHRgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGlzIGFuIGlkQWRkIG9mZnNldCBvZiBjYW5kaWRhdGUgYmFzZSBpZD0ke3RvSGV4KGJhc2VFbnRyeS5pZCl9IFx1MjAxNCBkZWZlcnJpbmcgdG8gcGFzcyAyYCxcblx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKHNob3VsZERlZmVyKSBjb250aW51ZVxuXHRcdH1cblxuXHRcdC8vIEZhbGxiYWNrOiB1bmtub3duIHNldHRpbmdcblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0YWN0aW9uID0ge1xuXHRcdFx0XHRjbWRfaWQsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHRuYW1lOiBgVW5rbm93biBjbWQ6JHt0b0hleChjbWRfaWQpfSBpZDoke3RvSGV4KGlkKS50b1VwcGVyQ2FzZSgpfWAsXG5cdFx0XHRcdG9wdGlvbnM6IFt2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcyldLFxuXHRcdFx0fVxuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIGFjdGlvbi5idXNDaCA9IGJ1c0NoXG5cdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGluZmVyIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBGaXggMTogYnVzQ2ggaGFuZGxpbmcgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBTdHJpcCBhbnkgaW5oZXJpdGVkIGJ1c0NoIG9wdGlvbiBmcm9tIHRoZSBjYW5kaWRhdGUgXHUyMDE0IHdlJ2xsIHJlLWRlcml2ZVxuXHRcdFx0Ly8gaXQgZnJvbSB3aGF0IHRoZSBwYWNrZXQgYWN0dWFsbHkgcmVwb3J0ZWQgZm9yIHRoaXMgZGV2aWNlLlxuXHRcdFx0YWN0aW9uLm9wdGlvbnMgPSBhY3Rpb24ub3B0aW9ucz8uZmlsdGVyKChvKSA9PiBvLmlkICE9PSAnYnVzQ2gnKSA/PyBbXVxuXHRcdFx0ZGVsZXRlIGFjdGlvbi5idXNDaFxuXG5cdFx0XHRjb25zdCBzZWVuQnVzQ2hWYWx1ZXMgPSBidXNDaFNlZW4uZ2V0KGAke2NtZF9pZH1fJHtpZH1gKVxuXHRcdFx0aWYgKHNlZW5CdXNDaFZhbHVlcyAmJiBzZWVuQnVzQ2hWYWx1ZXMuc2l6ZSA+IDApIHtcblx0XHRcdFx0Y29uc3QgbWF4QnVzQ2ggPSBNYXRoLm1heCguLi5zZWVuQnVzQ2hWYWx1ZXMpXG5cdFx0XHRcdGlmIChtYXhCdXNDaCA9PT0gMCkge1xuXHRcdFx0XHRcdC8vIE9ubHkgZXZlciBzYXcgYnVzQ2g9MCBcdTIxOTIgZml4ZWQgcHJvcGVydHksIG5vdCBhbiBvcHRpb25cblx0XHRcdFx0XHRhY3Rpb24uYnVzQ2ggPSAwXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0Ly8gTXVsdGlwbGUgY2hhbm5lbHMgb2JzZXJ2ZWQgXHUyMTkyIHNlbGVjdGFibGUgb3B0aW9uXG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2hDaG9pY2VzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogbWF4QnVzQ2ggKyAxIH0sIChfLCBpKSA9PiAoe1xuXHRcdFx0XHRcdFx0aWQ6IGksXG5cdFx0XHRcdFx0XHRsYWJlbDogYENoYW5uZWwgJHtpICsgMX1gLFxuXHRcdFx0XHRcdH0pKVxuXHRcdFx0XHRcdGFjdGlvbi5vcHRpb25zLnVuc2hpZnQoe1xuXHRcdFx0XHRcdFx0aWQ6ICdidXNDaCcsXG5cdFx0XHRcdFx0XHRsYWJlbDogJ0NoYW5uZWwnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdFx0XHRcdGNob2ljZXM6IGJ1c0NoQ2hvaWNlcyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IDAsXG5cdFx0XHRcdFx0fSBhcyBhbnkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEZpeCAyOiBkZWZhdWx0IG11c3QgZXhpc3QgaW4gY2hvaWNlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIFNldCB0aGUgZGVmYXVsdCB0byB0aGUgb2JzZXJ2ZWQgdmFsdWUuIElmIHRoYXQgdmFsdWUgaXNuJ3QgaW4gdGhlXG5cdFx0XHQvLyBpbmhlcml0ZWQgY2hvaWNlcyBsaXN0LCB0aGUgY2hvaWNlcyBhcmUgZnJvbSBhIHN0cnVjdHVyYWxseSBkaWZmZXJlbnRcblx0XHRcdC8vIG1vZGVsIGFuZCBjYW4ndCBiZSB0cnVzdGVkIFx1MjAxNCBkaXNjYXJkIHRoZW0gYW5kIGZhbGwgYmFjayB0byBhIHBsYWluIG51bWJlci5cblx0XHRcdGNvbnN0IG9ic2VydmVkRGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cdFx0XHRjb25zdCB2YWx1ZU9wdCA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKVxuXHRcdFx0aWYgKHZhbHVlT3B0KSB7XG5cdFx0XHRcdGlmICh2YWx1ZU9wdC5jaG9pY2VzICYmIEFycmF5LmlzQXJyYXkodmFsdWVPcHQuY2hvaWNlcykpIHtcblx0XHRcdFx0XHRjb25zdCBpbkNob2ljZXMgPSB2YWx1ZU9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2JzZXJ2ZWREZWZhdWx0KVxuXHRcdFx0XHRcdGlmICghaW5DaG9pY2VzKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2Fybihcblx0XHRcdFx0XHRcdFx0YEluZmVycmVkIGNob2ljZXMgZm9yIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBkb24ndCBjb250YWluIG9ic2VydmVkIHZhbHVlICR7b2JzZXJ2ZWREZWZhdWx0fSBcdTIwMTQgZGlzY2FyZGluZyBpbmhlcml0ZWQgY2hvaWNlc2AsXG5cdFx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0XHQvLyBLZWVwIGxhYmVsL3Rvb2x0aXAgYnV0IGRyb3AgY2hvaWNlcywgc3dpdGNoIHRvIHBsYWluIG51bWJlclxuXHRcdFx0XHRcdFx0dmFsdWVPcHQudHlwZSA9ICdudW1iZXInXG5cdFx0XHRcdFx0XHRkZWxldGUgKHZhbHVlT3B0IGFzIGFueSkuY2hvaWNlc1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHR2YWx1ZU9wdC5kZWZhdWx0ID0gb2JzZXJ2ZWREZWZhdWx0XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0b3V0LmNtZFNjaGVtYS5wdXNoKGFjdGlvbilcblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gUEFTUyAyOiBmb2xkIGFueSBkZWZlcnJlZCBpZEFkZCBvZmZzZXRzIHdob3NlIGJhc2UgZW50cnlcblx0Ly8gaXMgbm93IHByZXNlbnQgaW4gdGhlIG91dHB1dCBzY2hlbWEuXG5cdC8vIEdhdGU6IHRoZSBvZmZzZXQgbXVzdCBlaXRoZXIgZXhpc3QgaW4gYSByZWZlcmVuY2UgbW9kZWwncyBjaG9pY2VzLFxuXHQvLyBPUiB0aGUgYmFzZSBlbnRyeSBpdHNlbGYgd2FzIGluZmVycmVkIChoYXMgaWRBZGQpIGFuZCB0aGUgb2Zmc2V0XG5cdC8vIGNvbnRpbnVlcyBzZXF1ZW50aWFsbHkgYmV5b25kIHRoZSByZWZlcmVuY2UgbW9kZWwncyBrbm93biByYW5nZS5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCB9IG9mIHBhcnNlZCkge1xuXHRcdGNvbnN0IGFscmVhZHlUb3BMZXZlbCA9IG91dC5jbWRTY2hlbWEuc29tZSgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZClcblx0XHRpZiAoYWxyZWFkeVRvcExldmVsKSBjb250aW51ZVxuXG5cdFx0Ly8gRmluZCBhIGJhc2UgZW50cnkgaW4gdGhlIG91dHB1dCB0aGF0IGhhcyBpZEFkZCBhbmQgd2hvc2UgaWQgPCB0aGlzIGlkXG5cdFx0Y29uc3QgaWRBZGRCYXNlID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdHJldHVybiAhIWlkQWRkT3B0Py5jaG9pY2VzICYmIGlkID4gYS5pZFxuXHRcdH0pXG5cdFx0aWYgKCFpZEFkZEJhc2UpIGNvbnRpbnVlXG5cblx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGlkQWRkQmFzZS5pZFxuXHRcdGNvbnN0IGlkQWRkT3B0ID0gaWRBZGRCYXNlLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcyB8fCBpZEFkZE9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KSkgY29udGludWVcblxuXHRcdC8vIEFjY2VwdCB0aGUgZm9sZCBpZjogYSByZWZlcmVuY2UgbW9kZWwgZXhwbGljaXRseSBoYXMgdGhpcyBvZmZzZXQsXG5cdFx0Ly8gT1IgdGhlIG9mZnNldHMgYXJlIHN0cmljdGx5IHNlcXVlbnRpYWwgZnJvbSAwIChkZXZpY2UgaGFzIG1vcmUgY2hhbm5lbHMgdGhhbiByZWZlcmVuY2UpXG5cdFx0Y29uc3QgcmVmSGFzT2Zmc2V0ID0gY2FuZGlkYXRlcy5zb21lKChjKSA9PiB7XG5cdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChyKSA9PiByLmNtZF9pZCA9PT0gY21kX2lkICYmIHIuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRyZXR1cm4gcmVmSWRBZGQ/LmNob2ljZXM/LnNvbWUoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0fSlcblx0XHRjb25zdCBleGlzdGluZ09mZnNldHMgPSBpZEFkZE9wdC5jaG9pY2VzLm1hcCgoYzogYW55KSA9PiBjLmlkIGFzIG51bWJlcikuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cdFx0Y29uc3QgaXNTZXF1ZW50aWFsID0gZXhpc3RpbmdPZmZzZXRzLmxlbmd0aCA+IDAgJiYgb2Zmc2V0ID09PSBleGlzdGluZ09mZnNldHNbZXhpc3RpbmdPZmZzZXRzLmxlbmd0aCAtIDFdICsgMVxuXG5cdFx0aWYgKCFyZWZIYXNPZmZzZXQgJiYgIWlzU2VxdWVudGlhbCkgY29udGludWVcblxuXHRcdC8vIEluaGVyaXQgbGFiZWwgZnJvbSByZWZlcmVuY2UgbW9kZWwgaWYgYXZhaWxhYmxlLCBvdGhlcndpc2UgZ2VuZXJhdGUgb25lXG5cdFx0bGV0IGxhYmVsID0gYENoYW5uZWwgJHtvZmZzZXQgKyAxfWBcblx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZEFkZEJhc2UuaWQpXG5cdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0Y29uc3QgcmVmQ2hvaWNlID0gcmVmSWRBZGQ/LmNob2ljZXM/LmZpbmQoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0XHRpZiAocmVmQ2hvaWNlKSB7XG5cdFx0XHRcdGxhYmVsID0gcmVmQ2hvaWNlLmxhYmVsXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWRBZGRPcHQuY2hvaWNlcy5wdXNoKHsgaWQ6IG9mZnNldCwgbGFiZWwgfSlcblx0XHRsb2dnZXIuaW5mbyhcblx0XHRcdGBQYXNzIDI6IEZvbGRlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gaW50byBpZEFkZCBiYXNlIGlkPSR7dG9IZXgoaWRBZGRCYXNlLmlkKX0gYXMgb2Zmc2V0ICR7b2Zmc2V0fSAoXCIke2xhYmVsfVwiKWAsXG5cdFx0KVxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTQVZFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBzYXZlTW9kZWxKc29uUHJldHR5KGZpbGVQYXRoOiBzdHJpbmcsIGpzb25PYmo6IFN0TW9kZWxKc29uKTogdm9pZCB7XG5cdHRyeSB7XG5cdFx0Ly8gRW5zdXJlIHByb3BlciBrZXkgb3JkZXJpbmc6IG1vZGVsLCBzZWN0aW9uZWQgKGlmIHByZXNlbnQpLCByZWZyZXNoQWZ0ZXJDb21tYW5kLCBjbWRTY2hlbWFcblx0XHRjb25zdCBvcmRlcmVkT2JqOiBhbnkgPSB7IG1vZGVsOiBqc29uT2JqLm1vZGVsIH1cblxuXHRcdC8vIEFkZCBzZWN0aW9uZWQga2V5IGlmIHByZXNlbnQgKHJpZ2h0IGFmdGVyIG1vZGVsKVxuXHRcdGlmICgnc2VjdGlvbmVkJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLnNlY3Rpb25lZCA9IGpzb25PYmouc2VjdGlvbmVkXG5cdFx0fVxuXG5cdFx0Ly8gQWRkIG90aGVyIGtleXMgaW4gb3JkZXJcblx0XHRpZiAoJ3JlZnJlc2hBZnRlckNvbW1hbmQnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmoucmVmcmVzaEFmdGVyQ29tbWFuZCA9IGpzb25PYmoucmVmcmVzaEFmdGVyQ29tbWFuZFxuXHRcdH1cblx0XHRpZiAoJ2NtZFNjaGVtYScgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5jbWRTY2hlbWEgPSBqc29uT2JqLmNtZFNjaGVtYS5tYXAoKGVudHJ5OiBhbnkpID0+IHtcblx0XHRcdFx0Ly8gRW5mb3JjZSBrZXkgb3JkZXIgd2l0aGluIGVhY2ggc2NoZW1hIGVudHJ5OiBjbWRfaWQsIGlkLCBidXNDaCwgbmFtZSwgb3B0aW9uc1xuXHRcdFx0XHRjb25zdCBvcmRlcmVkRW50cnk6IGFueSA9IHt9XG5cdFx0XHRcdGlmICgnY21kX2lkJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmNtZF9pZCA9IGVudHJ5LmNtZF9pZFxuXHRcdFx0XHRpZiAoJ2lkJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmlkID0gZW50cnkuaWRcblx0XHRcdFx0aWYgKCdidXNDaCcgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5idXNDaCA9IGVudHJ5LmJ1c0NoXG5cdFx0XHRcdGlmICgnbmFtZScgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5uYW1lID0gZW50cnkubmFtZVxuXHRcdFx0XHRpZiAoJ29wdGlvbnMnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkub3B0aW9ucyA9IGVudHJ5Lm9wdGlvbnNcblx0XHRcdFx0Ly8gQ29weSBhbnkgcmVtYWluaW5nIGtleXNcblx0XHRcdFx0Zm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoZW50cnkpKSB7XG5cdFx0XHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRFbnRyeSkpIG9yZGVyZWRFbnRyeVtrZXldID0gZW50cnlba2V5XVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBvcmRlcmVkRW50cnlcblx0XHRcdH0pXG5cdFx0fVxuXHRcdC8vIENvcHkgYW55IG90aGVyIGtleXMgdGhhdCBtaWdodCBleGlzdFxuXHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGpzb25PYmopKSB7XG5cdFx0XHRpZiAoIShrZXkgaW4gb3JkZXJlZE9iaikpIHtcblx0XHRcdFx0b3JkZXJlZE9ialtrZXldID0gKGpzb25PYmogYXMgYW55KVtrZXldXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ3VzdG9tIGZvcm1hdHRlcjoga2VlcCBjaG9pY2Ugb2JqZWN0cyBjb21wYWN0IG9uIG9uZSBsaW5lXG5cdFx0bGV0IGpzb24gPSBKU09OLnN0cmluZ2lmeShvcmRlcmVkT2JqLCBudWxsLCAyKVxuXG5cdFx0Ly8gUmVwbGFjZSBleHBhbmRlZCBjaG9pY2Ugb2JqZWN0cyB3aXRoIGNvbXBhY3Qgc2luZ2xlLWxpbmUgZm9ybWF0XG5cdFx0Ly8gTWF0Y2hlczoge1xcbiAgICAgICAgICAgIFwiaWRcIjogWCxcXG4gICAgICAgICAgICBcImxhYmVsXCI6IFwiWVwiXFxuICAgICAgICAgIH1cblx0XHQvLyBSZXBsYWNlcyB3aXRoOiB7IFwiaWRcIjogWCwgXCJsYWJlbFwiOiBcIllcIiB9XG5cdFx0anNvbiA9IGpzb24ucmVwbGFjZSgvXFx7XFxuXFxzK1wiaWRcIjpcXHMqKFxcZCspLFxcblxccytcImxhYmVsXCI6XFxzKlwiKFteXCJdKilcIlxcblxccytcXH0vZywgJ3sgXCJpZFwiOiAkMSwgXCJsYWJlbFwiOiBcIiQyXCIgfScpXG5cblx0XHRmcy53cml0ZUZpbGVTeW5jKGZpbGVQYXRoLCBqc29uICsgJ1xcbicsICd1dGY4Jylcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmlsZSBXcml0ZSBFcnJvcjogJHtlfWApXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgTE9BRCBERVZJQ0UgSlNPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIExvYWRzIHRoZSBhY3Rpb25zIGFycmF5IGZvciBhIGdpdmVuIG1vZGVsIGZyb20gdGhlIGNlbnRyYWxpemVkIGNhY2hlLlxuICogUmV0dXJucyBhbiBlbXB0eSBhcnJheSBpZiB0aGUgbW9kZWwgaXMgbm90IGZvdW5kLlxuICogQGRlcHJlY2F0ZWQgLSBUaGlzIGZ1bmN0aW9uIGlzIG5vIGxvbmdlciBuZWVkZWQuIFVzZSBnZXREZXZpY2VTY2hlbWEoKSBmcm9tIGNvbmZpZy50cyBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZEFjdGlvbnNGb3JNb2RlbChfZGV2aWNlc0ZvbGRlcjogc3RyaW5nLCBtb2RlbDogc3RyaW5nKTogU3RBY3Rpb25bXSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0cmV0dXJuIHNjaGVtYT8uY21kU2NoZW1hID8/IFtdXG59XG5cbi8qKlxuICogTG9hZHMgdGhlIG1vZGVsIGNvbmZpZ3VyYXRpb24gZnJvbSB0aGUgY2VudHJhbGl6ZWQgY2FjaGUuXG4gKiBAZGVwcmVjYXRlZCAtIFRoaXMgZnVuY3Rpb24gaXMgbm8gbG9uZ2VyIG5lZWRlZC4gVXNlIGdldERldmljZVNjaGVtYSgpIGZyb20gY29uZmlnLnRzIGluc3RlYWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsb2FkTW9kZWxDb25maWcoXG5cdF9kZXZpY2VzRm9sZGVyOiBzdHJpbmcsXG5cdG1vZGVsOiBzdHJpbmcsXG4pOiB7IGFjdGlvbnM6IFN0QWN0aW9uW107IHJlZnJlc2hBZnRlckNvbW1hbmQ6IGJvb2xlYW4gfSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0cmV0dXJuIHtcblx0XHRhY3Rpb25zOiBzY2hlbWE/LmNtZFNjaGVtYSA/PyBbXSxcblx0XHRyZWZyZXNoQWZ0ZXJDb21tYW5kOiBzY2hlbWE/LnJlZnJlc2hBZnRlckNvbW1hbmQgPz8gdHJ1ZSwgLy8gRGVmYXVsdCB0byB0cnVlIGlmIG5vdCBzcGVjaWZpZWRcblx0fVxufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQgeyBidWlsZEZlZWRiYWNrcyB9IGZyb20gJy4vYnVpbGQtY29tbWFuZHMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMsIGZpbmRBY3Rpb25Gb3JTZXR0aW5nIH0gZnJvbSAnLi90eXBlcy5qcydcblxuLyoqXG4gKiBIZWxwZXIgZnVuY3Rpb24gdG8gZ2V0IGxhYmVsIGZyb20gY2hvaWNlcyBiYXNlZCBvbiB2YWx1ZVxuICovXG5mdW5jdGlvbiBnZXRMYWJlbEZvclZhbHVlKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuXHR2YWx1ZTogbnVtYmVyLFxuKTogc3RyaW5nIHwgbnVtYmVyIHtcblx0Y29uc3Qgc2V0dGluZyA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRpZiAoIXNldHRpbmcgfHwgIUFycmF5LmlzQXJyYXkoc2V0dGluZy5vcHRpb25zKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgJ3ZhbHVlJyBvcHRpb24gd2hpY2ggY29udGFpbnMgdGhlIGNob2ljZXNcblx0Y29uc3QgdmFsdWVPcHRpb24gPSBzZXR0aW5nLm9wdGlvbnMuZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0aWYgKCF2YWx1ZU9wdGlvbiB8fCAhQXJyYXkuaXNBcnJheSh2YWx1ZU9wdGlvbi5jaG9pY2VzKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgY2hvaWNlIHdpdGggbWF0Y2hpbmcgaWRcblx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjOiBhbnkpID0+IGMuaWQgPT09IHZhbHVlKVxuXHRyZXR1cm4gY2hvaWNlPy5sYWJlbCA/PyB2YWx1ZVxufVxuXG4vKipcbiAqIEJ1aWxkIGFuZCB3aXJlIENvbXBhbmlvbiBmZWVkYmFjayBkZWZpbml0aW9uc1xuICogUGF0dGVybiBtYXRjaGVzIGFjdGlvbnMudHMgLSBmaWx0ZXJzIGJ5IGFjdGl2ZSBtb2RlbCBhbmQgd2lyZXMgY2FsbGJhY2tzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVGZWVkYmFja3Moc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdGZWVkYmFja3MgPSBidWlsZEZlZWRiYWNrcygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEZlZWRiYWNrczogYW55ID0ge31cblxuXHQvLyBHZXQgdGhlIGFjdGl2ZSBtb2RlbCBmcm9tIHRoZSBjYWNoZWQgdmFsdWUgc2V0IGJ5IHN5bmNNb2RlbCgpXG5cdGNvbnN0IGFjdGl2ZU1vZGVsID0gc2VsZi5hY3RpdmVNb2RlbFxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgRkVFREJBQ0tTIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2ZlZWRiYWNrSWQsIGZlZWRiYWNrXSBvZiBPYmplY3QuZW50cmllcyhyYXdGZWVkYmFja3MpKSB7XG5cdFx0Y29uc3QgeyBtb2RlbCwgY21kSWQsIGJhc2VJZCB9ID0gcGFyc2VTZXR0aW5nSWQoZmVlZGJhY2tJZClcblxuXHRcdC8vIE9ubHkgaW5jbHVkZSBmZWVkYmFja3MgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIFZBTFVFIEZFRURCQUNLOiBSZXR1cm5zIGN1cnJlbnQgdmFsdWUgZm9yIGxvY2FsIHZhcmlhYmxlXG5cdFx0d2lyZWRGZWVkYmFja3NbZmVlZGJhY2tJZF0gPSB7XG5cdFx0XHQuLi5mZWVkYmFjayxcblx0XHRcdGNhbGxiYWNrOiAoZmVlZGJhY2tFdmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblxuXHRcdFx0XHQvLyBidXNDaCBmcm9tIG9wdGlvbnMgdGFrZXMgcHJpb3JpdHk7IGZhbGwgYmFjayB0byBmaXhlZCBidXNDaCBpbiBzY2hlbWFcblx0XHRcdFx0bGV0IGJ1c0NoID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydidXNDaCddXG5cdFx0XHRcdGlmIChidXNDaCA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc2NoZW1hQWN0aW9uID0gZmluZEFjdGlvbkZvclNldHRpbmcoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0aWYgKHNjaGVtYUFjdGlvbj8uYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdFx0YnVzQ2ggPSBzY2hlbWFBY3Rpb24uYnVzQ2hcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRjb25zdCBjdXJyZW50ID0gc2VsZi5zdENvbnRyb2xsZXIuZ2V0U2V0dGluZ1ZhbHVlKGlwLCBjbWRJZCwgc2V0dGluZ0lkLCBidXNDaClcblxuXHRcdFx0XHQvLyBDaGVjayBpZiB1c2VyIHdhbnRzIGxhYmVsIGluc3RlYWQgb2YgbnVtZXJpYyB2YWx1ZVxuXHRcdFx0XHRjb25zdCBzaG93TGFiZWwgPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ3Nob3dMYWJlbCddID8/IGZhbHNlXG5cblx0XHRcdFx0aWYgKHNob3dMYWJlbCAmJiBjdXJyZW50ICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHQvLyBSZXR1cm4gdGhlIGxhYmVsIGZyb20gY2hvaWNlc1xuXHRcdFx0XHRcdHJldHVybiBnZXRMYWJlbEZvclZhbHVlKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBjdXJyZW50KVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gUmV0dXJuIG51bWVyaWMgdmFsdWUgZGlyZWN0bHkgZm9yIGxvY2FsIHZhcmlhYmxlICh0eXBlOiAndmFsdWUnKVxuXHRcdFx0XHRyZXR1cm4gY3VycmVudCA/PyAwXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdHNlbGYuc2V0RmVlZGJhY2tEZWZpbml0aW9ucyh3aXJlZEZlZWRiYWNrcylcblxuXHQvL2NvbnNvbGUubG9nKCdGZWVkYmFja3M6XFxuJywgSlNPTi5zdHJpbmdpZnkod2lyZWRGZWVkYmFja3MsIG51bGwsIDIpKVxufVxuIiwgImltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSdcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQge1xuXHRDTURfQlVTX0dFVCxcblx0Q01EX0JVU19TRVQsXG5cdENNRF9ERVZfU1BFQyxcblx0Q01EX0dFVF9BTExfU0VUVElOR1MsXG5cdENNRF9HRVRfRklSTVdBUkUsXG5cdENNRF9HTE9CQUxfTUlDX0tJTEwsXG5cdENNRF9NSUNfUFJFLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9SRVNFVF9ERVZJQ0UsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHRnZXRDb21tYW5kTmFtZSxcblx0bWFrZVNldHRpbmdJZCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdHR5cGUgRGV2aWNlSW5mbyxcbn0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7XG5cdHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCxcblx0cGFyc2VTZXR0aW5nc1Jlc3BvbnNlLFxuXHRmb3JtYXRQYXJzZWRTZXR0aW5nLFxuXHR0eXBlIFN0QWN0aW9uLFxuXHR0eXBlIFBhcnNlZFNldHRpbmcsXG59IGZyb20gJy4vc2V0dGluZ3NQYXJzZXIuanMnXG5pbXBvcnQge1xuXHREQU5URV9NU0dfSU5GT19SRVNQT05TRSxcblx0cGFyc2VEYW50ZUluZm9SZXNwb25zZSxcblx0ZGlzY292ZXJEZXZpY2VzLFxuXHRidWlsZERhbnRlSW5mb1JlcXVlc3QsXG5cdGdldE1hY0ZvckRlc3RpbmF0aW9uLFxuXHRnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbixcbn0gZnJvbSAnLi9kYW50ZS5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdTdENvbnRyb2xsZXInKVxuXG5leHBvcnQgY2xhc3MgU3RDb250cm9sbGVyIHtcblx0cHJpdmF0ZSByZWFkb25seSBkZWZhdWx0UG9ydDogbnVtYmVyID0gODcwMFxuXHRwcml2YXRlIHJlYWRvbmx5IG11bHRpY2FzdEdyb3VwID0gJzIyNC4wLjAuMjMxJ1xuXHRwcml2YXRlIHJlYWRvbmx5IHJ4UG9ydCA9IDg3MDJcblxuXHRwcml2YXRlIHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXRcblx0cHJpdmF0ZSByeFNvY2tldDogZGdyYW0uU29ja2V0IC8vIGZvciByZWNlaXZpbmcgcmVzcG9uc2VzICg4NzAyKVxuXHRwcml2YXRlIHBlbmRpbmdBY2tzOiBNYXA8XG5cdFx0c3RyaW5nLFxuXHRcdHsgcmVzb2x2ZTogKGJ1ZjogQnVmZmVyKSA9PiB2b2lkOyByZWplY3Q6IChlOiBFcnJvcikgPT4gdm9pZDsgdGltZXI6IE5vZGVKUy5UaW1lb3V0IH1cblx0PiA9IG5ldyBNYXAoKVxuXHRwcml2YXRlIGpvaW5lZEludGVyZmFjZXM6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpIC8vIGxvY2FsIElQcyB3ZSd2ZSBqb2luZWQgbXVsdGljYXN0IG9uXG5cblx0LyoqIFNlcmlhbGl6ZXMgb3V0Z29pbmcgY29tbWFuZHMgc28gZWFjaCB3YWl0cyBmb3IgQUNLIGJlZm9yZSB0aGUgbmV4dCBpcyBzZW50ICovXG5cdHByaXZhdGUgc2VuZFF1ZXVlOiBQcm9taXNlPHZvaWQ+ID0gUHJvbWlzZS5yZXNvbHZlKClcblxuXHQvKiogVHJhY2tzIGhvdyBtYW55IGNvbW1hbmRzIGFyZSBxdWV1ZWQvaW4tZmxpZ2h0LCB0byBkZWZlciByZXF1ZXN0QWxsU2V0dGluZ3MgKi9cblx0cHJpdmF0ZSBwZW5kaW5nQ29tbWFuZENvdW50ID0gMFxuXG5cdC8qKiBSZXNvbHZlcyBvbmNlIHR4U29ja2V0IGlzIGJvdW5kIGFuZCByZWFkeSB0byBzZW5kICovXG5cdHByaXZhdGUgdHhSZWFkeTogUHJvbWlzZTx2b2lkPlxuXG5cdC8qKiBBY3RpdmUgZGV2aWNlIG1vZGVsIGFuZCBhY3Rpb24gZGVmaW5pdGlvbnMgZm9yIHNldHRpbmdzIGRlY29kaW5nICovXG5cdHByaXZhdGUgbW9kZWw6IHN0cmluZyA9ICcnXG5cdHByaXZhdGUgYWN0aW9uczogU3RBY3Rpb25bXSA9IFtdXG5cdHByaXZhdGUgcmVmcmVzaEFmdGVyQ29tbWFuZDogYm9vbGVhbiA9IHRydWUgLy8gRGVmYXVsdCB0byB0cnVlIChtb3N0IGRldmljZXMgbmVlZCBpdClcblxuXHQvKipcblx0ICogS25vd24gc3RhdGUgb2YgZXZlcnkgc2V0dGluZyBwZXIgZGV2aWNlIElQLlxuXHQgKiBLZXllZCBieSBJUCBcdTIxOTIgTWFwIG9mIFwiJHtjbWRJZH0vJHtzZXR0aW5nSWR9XCIgXHUyMTkyIGN1cnJlbnQgdmFsdWUgYnl0ZS5cblx0ICogUG9wdWxhdGVkIG9uIGNvbm5lY3QgdmlhIHJlcXVlc3RBbGxTZXR0aW5ncygpLCB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKS5cblx0ICogVXNlZCB0byBkaWZmIGluY29taW5nIHB1c2hlcyAoY2hhbmdlZCA9IGluZm8sIHVuY2hhbmdlZCA9IGRlYnVnKSBhbmQgZm9yIGZlZWRiYWNrcy5cblx0ICovXG5cdHByaXZhdGUgZGV2aWNlU3RhdGU6IE1hcDxzdHJpbmcsIE1hcDxzdHJpbmcsIG51bWJlcj4+ID0gbmV3IE1hcCgpXG5cblx0LyoqXG5cdCAqIElQcyB0aGF0IGhhdmUgYmVlbiB2ZXJpZmllZCBhZ2FpbnN0IHRoZSBjb25maWd1cmVkIG1vZGVsIGFuZCBhcmUgYWxsb3dlZFxuXHQgKiB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiBQb3B1bGF0ZWQgYnkgYXV0aG9yaXplRGV2aWNlKCkgYWZ0ZXIgYVxuXHQgKiBzdWNjZXNzZnVsIHByb2JlRGV2aWNlKCkgbW9kZWwgbWF0Y2gsIG9yIGFmdGVyIG11bHRpY2FzdCBkaXNjb3ZlcnkuXG5cdCAqIF9zZW5kQXdhaXRBY2soKSByZWplY3RzIGFueSBkZXN0SXAgbm90IGluIHRoaXMgc2V0LlxuXHQgKi9cblx0cHJpdmF0ZSBhdXRob3JpemVkSXBzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxuXG5cdC8qKiBDYWxsYmFja3MgcmVnaXN0ZXJlZCBieSBkaXNjb3ZlckRldmljZXMoKSBcdTIwMTQga2V5ZWQgYnkgc291cmNlIElQICovXG5cdHByaXZhdGUgZGlzY292ZXJ5TGlzdGVuZXJzOiBNYXA8c3RyaW5nLCAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB2b2lkPiA9IG5ldyBNYXAoKVxuXG5cdC8qKiBDYWxsYmFjayB0byB0cmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZXMgd2hlbiBzdGF0ZSBjaGFuZ2VzICovXG5cdHByaXZhdGUgZmVlZGJhY2tDYWxsYmFjaz86IChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHZvaWRcblxuXHQvKiogQ2FjaGUgb2YgbG9jYWwgaW50ZXJmYWNlIE1BQyBieXRlcyBwZXIgZGVzdGluYXRpb24gSVAsIHRvIGF2b2lkIHJlcGVhdGVkIE9TIGxvb2t1cHMgKi9cblx0cHJpdmF0ZSBtYWNDYWNoZTogTWFwPHN0cmluZywgbnVtYmVyW10+ID0gbmV3IE1hcCgpXG5cblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0bG9nZ2VyLmluZm8oJ1N0Q29udHJvbGxlciBpbml0aWFsaXplZCcpXG5cblx0XHQvLyBTZW5kIHNvY2tldCBcdTIwMTQgYmluZCB0byBlcGhlbWVyYWwgcG9ydC4gUmVzcG9uc2VzIGFsd2F5cyBnbyB0byByeFNvY2tldCBvblxuXHRcdC8vIHBvcnQgODcwMiAoRGFudGUgaGFyZGNvZGVzIHRoZSByZXNwb25zZSBkZXN0aW5hdGlvbiBwb3J0IHRvIDg3MDIpLlxuXHRcdHRoaXMudHhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXHRcdHRoaXMudHhSZWFkeSA9IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiB7XG5cdFx0XHR0aGlzLnR4U29ja2V0LmJpbmQoMCwgKCkgPT4ge1xuXHRcdFx0XHRsb2dnZXIuZGVidWcoYFRYIHNvY2tldCBib3VuZCB0byBwb3J0ICR7KHRoaXMudHhTb2NrZXQuYWRkcmVzcygpIGFzIHsgcG9ydDogbnVtYmVyIH0pLnBvcnR9YClcblx0XHRcdFx0cmVzb2x2ZSgpXG5cdFx0XHR9KVxuXHRcdH0pXG5cdFx0dGhpcy50eFNvY2tldC5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYFRYIHNvY2tldCBlcnJvcjogJHtlcnJ9YClcblx0XHR9KVxuXG5cdFx0Ly8gUmVjZWl2ZSBzb2NrZXQgLSBiaW5kIHRvIGFsbCBhZGRyZXNzZXMgc28ga2VybmVsIGNhbiBkZWxpdmVyIG11bHRpY2FzdCBwYWNrZXRzXG5cdFx0dGhpcy5yeFNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdsaXN0ZW5pbmcnLCAoKSA9PiB7XG5cdFx0XHRjb25zdCBhZGRyID0gdGhpcy5yeFNvY2tldC5hZGRyZXNzKClcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggc29ja2V0IGxpc3RlbmluZyBvbiAke0pTT04uc3RyaW5naWZ5KGFkZHIpfWApXG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLnJ4U29ja2V0LnNldE11bHRpY2FzdExvb3BiYWNrKHRydWUpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYFJYIHNvY2tldCBlcnJvcjogJHtlcnJ9YClcblx0XHR9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbWVzc2FnZScsIChtc2csIHJpbmZvKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLmhhbmRsZUluY29taW5nKG1zZywgcmluZm8uYWRkcmVzcylcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGxvZ2dlci5lcnJvcihgRXJyb3IgaGFuZGxpbmcgaW5jb21pbmcgbWVzc2FnZTogJHtfZX1gKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHQvLyBCaW5kIHRvIHdpbGRjYXJkIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0cyBmb3Igam9pbmVkIGludGVyZmFjZXNcblx0XHR0aGlzLnJ4U29ja2V0LmJpbmQoeyBhZGRyZXNzOiAnMC4wLjAuMCcsIHBvcnQ6IHRoaXMucnhQb3J0IH0sICgpID0+IHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggc29ja2V0IGJvdW5kIHRvIDAuMC4wLjA6JHt0aGlzLnJ4UG9ydH1gKVxuXHRcdH0pXG5cdH1cblxuXHRwdWJsaWMgY2xvc2UoKTogdm9pZCB7XG5cdFx0dHJ5IHtcblx0XHRcdGZvciAoY29uc3QgbG9jYWxBZGRyIG9mIEFycmF5LmZyb20odGhpcy5qb2luZWRJbnRlcmZhY2VzKSkge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdHRoaXMucnhTb2NrZXQuZHJvcE1lbWJlcnNoaXAodGhpcy5tdWx0aWNhc3RHcm91cCwgbG9jYWxBZGRyKVxuXHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnJ4U29ja2V0LmNsb3NlKClcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy50eFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogUHJvdmlkZSB0aGUgYWN0aXZlIGRldmljZSBtb2RlbCBhbmQgYWN0aW9uIGRlZmluaXRpb25zIHNvIGluY29taW5nIG1lc3NhZ2VzXG5cdCAqIGNhbiBiZSBkZWNvZGVkIGludG8gaHVtYW4tcmVhZGFibGUgbmFtZXMuIENhbGwgZnJvbSBtYWluLnRzIGFmdGVyIGNvbmZpZyBsb2FkLlxuXHQgKi9cblx0cHVibGljIHNldE1vZGVsKG1vZGVsOiBzdHJpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10sIHJlZnJlc2hBZnRlckNvbW1hbmQ6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCB7XG5cdFx0dGhpcy5tb2RlbCA9IG1vZGVsXG5cdFx0dGhpcy5hY3Rpb25zID0gYWN0aW9uc1xuXHRcdHRoaXMucmVmcmVzaEFmdGVyQ29tbWFuZCA9IHJlZnJlc2hBZnRlckNvbW1hbmRcblx0fVxuXG5cdC8qKlxuXHQgKiBTZXQgY2FsbGJhY2sgdG8gdHJpZ2dlciB3aGVuIGRldmljZSBzdGF0ZSBjaGFuZ2VzIChmb3IgZmVlZGJhY2tzKS5cblx0ICogQ2FsbCBmcm9tIG1haW4udHMgdG8gd2lyZSB1cCBjaGVja0ZlZWRiYWNrcy5cblx0ICovXG5cdHB1YmxpYyBzZXRGZWVkYmFja0NhbGxiYWNrKGNhbGxiYWNrOiAoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB2b2lkKTogdm9pZCB7XG5cdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrID0gY2FsbGJhY2tcblx0fVxuXG5cdC8qKiBSZXR1cm5zIHRydWUgaWYgdGhlIGRldmljZSBhdCB0aGUgZ2l2ZW4gSVAgaGFzIGJlZW4gYXV0aG9yaXplZCB0byByZWNlaXZlIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgaXNEZXZpY2VBdXRob3JpemVkKGlwOiBzdHJpbmcpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5hdXRob3JpemVkSXBzLmhhcyhpcClcblx0fVxuXG5cdC8qKiBNYXJrIGFuIElQIGFzIHZlcmlmaWVkIGFuZCBhbGxvd2VkIHRvIHJlY2VpdmUgU3R1ZGlvLVQgY29tbWFuZHMuICovXG5cdHB1YmxpYyBhdXRob3JpemVEZXZpY2UoaXA6IHN0cmluZyk6IHZvaWQge1xuXHRcdHRoaXMuYXV0aG9yaXplZElwcy5hZGQoaXApXG5cdFx0bG9nZ2VyLmRlYnVnKGBBdXRob3JpemVkIGRldmljZSBhdCAke2lwfWApXG5cdH1cblxuXHQvKiogUmVtb3ZlIGF1dGhvcml6YXRpb24gZm9yIGFuIElQIChlLmcuIG9uIGNvbmZpZyBjaGFuZ2Ugb3IgbW9kZWwgbWlzbWF0Y2gpLiAqL1xuXHRwdWJsaWMgcmV2b2tlRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuZGVsZXRlKGlwKVxuXHRcdHRoaXMuZGV2aWNlU3RhdGUuZGVsZXRlKGlwKVxuXHRcdHRoaXMubWFjQ2FjaGUuZGVsZXRlKGlwKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgUmV2b2tlZCBkZXZpY2UgYXQgJHtpcH1gKVxuXHR9XG5cblx0LyoqXG5cdCAqIFNlbmRzIGEgdW5pY2FzdCBEYW50ZSBpbmZvIHJlcXVlc3QgdG8gYSBzcGVjaWZpYyBJUCBhbmQgd2FpdHMgZm9yIHRoZVxuXHQgKiBkZXZpY2UgaW5mbyByZXNwb25zZS4gUmV0dXJucyB0aGUgRGV2aWNlSW5mbyBpZiB0aGUgZGV2aWNlIHJlc3BvbmRzIHdpdGhpblxuXHQgKiB0aW1lb3V0TXMsIG9yIG51bGwgaWYgbm8gcmVzcG9uc2UuIFVzZWQgdG8gdmVyaWZ5IGEgbWFudWFsbHkgY29uZmlndXJlZCBJUC5cblx0ICogRG9lcyBOT1QgcmVxdWlyZSBhdXRob3JpemF0aW9uIFx1MjAxNCB0aGlzIGlzIGhvdyBhdXRob3JpemF0aW9uIGlzIGVzdGFibGlzaGVkLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHByb2JlRGV2aWNlKGlwOiBzdHJpbmcsIHRpbWVvdXRNcyA9IDMwMDApOiBQcm9taXNlPERldmljZUluZm8gfCBudWxsPiB7XG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPERldmljZUluZm8gfCBudWxsPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0Y29uc3Qga2V5ID0gYF9fcHJvYmVfJHtpcH1fX2Bcblx0XHRcdGxldCByZXNvbHZlZCA9IGZhbHNlXG5cblx0XHRcdGNvbnN0IGZpbmlzaCA9IChyZXN1bHQ6IERldmljZUluZm8gfCBudWxsKSA9PiB7XG5cdFx0XHRcdGlmIChyZXNvbHZlZCkgcmV0dXJuXG5cdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5kZWxldGUoa2V5KVxuXHRcdFx0XHRyZXNvbHZlKHJlc3VsdClcblx0XHRcdH1cblxuXHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KGtleSwgKGRldmljZTogRGV2aWNlSW5mbykgPT4ge1xuXHRcdFx0XHRpZiAoZGV2aWNlLmlwID09PSBpcCkgZmluaXNoKGRldmljZSlcblx0XHRcdH0pXG5cblx0XHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBmaW5pc2gobnVsbCksIHRpbWVvdXRNcylcblx0XHRcdHRpbWVyLnVucmVmPy4oKVxuXG5cdFx0XHRjb25zdCBydW4gPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdGF3YWl0IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihpcClcblx0XHRcdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0XHRcdGNvbnN0IHF1ZXJ5ID0gYnVpbGREYW50ZUluZm9SZXF1ZXN0KClcblx0XHRcdFx0dGhpcy50eFNvY2tldC5zZW5kKHF1ZXJ5LCB0aGlzLmRlZmF1bHRQb3J0LCBpcCwgKGVycikgPT4ge1xuXHRcdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBQcm9iZSB0byAke2lwfSBmYWlsZWQ6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRcdGZpbmlzaChudWxsKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSlcblx0XHRcdH1cblxuXHRcdFx0cnVuKCkuY2F0Y2goKGUpID0+IHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYHByb2JlRGV2aWNlIHNldHVwIGZhaWxlZCBmb3IgJHtpcH06ICR7ZX1gKVxuXHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdGZpbmlzaChudWxsKVxuXHRcdFx0fSlcblx0XHR9KVxuXHR9XG5cblx0LyoqXG5cdCAqIFNlbmQgYSBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgcmVxdWVzdCB0byB0aGUgZGV2aWNlIGFuZCBzdG9yZSB0aGUgcmVzcG9uc2Vcblx0ICogaW4gZGV2aWNlU3RhdGUuIFJldHVybnMgdGhlIHJhdyByZXNwb25zZSBidWZmZXIgZm9yIHBhcnNpbmcuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEFsbFNldHRpbmdzKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGxvZ2dlci5pbmZvKGBSZXF1ZXN0aW5nIGFsbCBzZXR0aW5ncyBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HRVRfQUxMX1NFVFRJTkdTLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXZpY2VJcCwgZmFsc2UpXG5cdFx0Ly8gZGV2aWNlU3RhdGUgaXMgcG9wdWxhdGVkIGJ5IGxvZ1N0UGF5bG9hZCB3aGVuIHRoZSBDTURfR0VUX0FMTF9TRVRUSU5HUyByZXNwb25zZSBhcnJpdmVzXG5cdFx0cmV0dXJuIHJlc3BvbnNlXG5cdH1cblxuXHQvKipcblx0ICogRGlzY292ZXJzIFN0dWRpbyBUZWNobm9sb2dpZXMgRGFudGUgZGV2aWNlcyBvbiB0aGUgbG9jYWwgbmV0d29yay5cblx0ICpcblx0ICogU3RyYXRlZ3k6XG5cdCAqICBEYW50ZSBkZXZpY2VzIGJyb2FkY2FzdCBhIDEtc2Vjb25kIGFubm91bmNlIHRvIG11bHRpY2FzdCAyMjQuMC4wLjIzMzo4NzA4LlxuXHQgKiAgV2UgbGlzdGVuIG9uIHRoYXQgZ3JvdXAsIGNvbGxlY3Qgc291cmNlIElQcywgdGhlbiBzZW5kIGEgdW5pY2FzdCBkZXZpY2UgaW5mb1xuXHQgKiAgcmVxdWVzdCAoMHgwMDIwKSB0byBlYWNoIG5ldyBJUCBvbiBwb3J0IDg3MDAuIFRoZSBkZXZpY2UgcmVzcG9uZHMgdG8gb3VyIElQXG5cdCAqICBvbiBwb3J0IDg3MDIgKHJ4U29ja2V0KSwgd2hlcmUgaGFuZGxlSW5jb21pbmcoKSBwaWNrcyBpdCB1cCBhbmQgZmlyZXMgdGhlXG5cdCAqICBkaXNjb3ZlcnlMaXN0ZW5lcnMgY2FsbGJhY2suXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgZGlzY292ZXJEZXZpY2VzKHRpbWVvdXRNcyA9IDUwMDApOiBQcm9taXNlPERldmljZUluZm9bXT4ge1xuXHRcdC8vIFJlZ2lzdGVyIGxpc3RlbmVyIFx1MjAxNCBoYW5kbGVJbmNvbWluZygpIGZpcmVzIHRoaXMgZm9yIGVhY2ggMHgwMTcwIHJlc3BvbnNlXG5cdFx0Y29uc3QgRElTQ09WRVJZX0tFWSA9ICdfX2Rpc2NvdmVyeV9fJ1xuXHRcdGNvbnN0IGZvdW5kRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHRcdGNvbnN0IG9uRGV2aWNlRm91bmQgPSAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB7XG5cdFx0XHRpZiAoIWZvdW5kRGV2aWNlcy5zb21lKChkKSA9PiBkLmlwID09PSBkZXZpY2UuaXApKSB7XG5cdFx0XHRcdGZvdW5kRGV2aWNlcy5wdXNoKGRldmljZSlcblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBSZWdpc3RlciB0aGUgY2FsbGJhY2sgc28gaGFuZGxlSW5jb21pbmcoKSBjYW4gaW52b2tlIGl0IHdoZW4gMHgwMTcwIGFycml2ZXNcblx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5zZXQoRElTQ09WRVJZX0tFWSwgb25EZXZpY2VGb3VuZClcblxuXHRcdHRyeSB7XG5cdFx0XHRhd2FpdCB0aGlzLnR4UmVhZHlcblx0XHRcdC8vIGRpc2NvdmVyRGV2aWNlcygpIGluIGRhbnRlLnRzIGhhbmRsZXMgdGhlIGFubm91bmNlIGxpc3RlbmluZyBhbmQgcXVlcnkgc2VuZGluZy5cblx0XHRcdC8vIFJlc3BvbnNlcyBjb21lIGJhY2sgdG8gcnhTb2NrZXQgXHUyMTkyIGhhbmRsZUluY29taW5nKCkgXHUyMTkyIGRpc2NvdmVyeUxpc3RlbmVycy5cblx0XHRcdGF3YWl0IGRpc2NvdmVyRGV2aWNlcyh0aGlzLnR4U29ja2V0LCBhc3luYyAoZGVzdElwKSA9PiB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKSwgdGltZW91dE1zKVxuXHRcdFx0cmV0dXJuIGZvdW5kRGV2aWNlc1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5kZWxldGUoRElTQ09WRVJZX0tFWSlcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogUmVxdWVzdHMgZGV2aWNlIGZpcm13YXJlIHZlcnNpb24gdmlhIFN0dWRpby1UIHByb3RvY29sIChDTURfR0VUX0ZJUk1XQVJFKS5cblx0ICogUmV0dXJucyB0aGUgZmlybXdhcmUgdmVyc2lvbiBzdHJpbmcgKGUuZy4sIFwiMy4wMVwiLCBcIjIuMlwiLCBcIjEuMDVcIikuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2VJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0XHRsb2dnZXIuaW5mbyhgUmVxdWVzdGluZyBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soQ01EX0dFVF9GSVJNV0FSRSwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGV2aWNlSXAsIGZhbHNlKVxuXG5cdFx0Ly8gUmVzcG9uc2Ugc3RydWN0dXJlOiBbaGVhZGVyXSAweDVhIDB4ODAgW2Zpcm13YXJlX2RhdGFdIENSQ1xuXHRcdC8vIEZpcm13YXJlIGRhdGEgc3RhcnRzIGF0IGJ5dGUgMjYgKDI0LWJ5dGUgaGVhZGVyICsgMHg1YSArIDB4ODApXG5cdFx0Y29uc3QgZGF0YVN0YXJ0ID0gMjZcblxuXHRcdGlmIChyZXNwb25zZS5sZW5ndGggPCBkYXRhU3RhcnQgKyAzKSB7XG5cdFx0XHRsb2dnZXIud2FybihgRmlybXdhcmUgcmVzcG9uc2UgdG9vIHNob3J0OiAke3Jlc3BvbnNlLmxlbmd0aH0gYnl0ZXNgKVxuXHRcdFx0cmV0dXJuICdVbmtub3duJ1xuXHRcdH1cblxuXHRcdC8vIEZpcm13YXJlIGZvcm1hdDogW3Vua25vd25fYnl0ZSwgbWFqb3IsIG1pbm9yXVxuXHRcdGNvbnN0IG1ham9yID0gcmVzcG9uc2VbZGF0YVN0YXJ0ICsgMV1cblx0XHRjb25zdCBtaW5vciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDJdXG5cblx0XHRjb25zdCBtaW5vclN0ciA9XG5cdFx0XHRtaW5vciA8IDEwXG5cdFx0XHRcdD8gbWlub3IudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpIC8vIGUuZy4gMSBcdTIxOTIgXCIwMVwiLCA1IFx1MjE5MiBcIjA1XCJcblx0XHRcdFx0OiBtaW5vci50b1N0cmluZygpIC8vIGUuZy4gMTAgXHUyMTkyIFwiMTBcIlxuXG5cdFx0Y29uc3QgZmlybXdhcmUgPSBgJHttYWpvcn0uJHttaW5vclN0cn1gXG5cblx0XHRsb2dnZXIuaW5mbyhgRmlybXdhcmUgdmVyc2lvbjogJHtmaXJtd2FyZX1gKVxuXHRcdHJldHVybiBmaXJtd2FyZVxuXHR9XG5cblx0LyoqXG5cdCAqIEpvaW5zIHRoZSBtdWx0aWNhc3QgcmVzcG9uc2UgZ3JvdXAgb24gdGhlIGludGVyZmFjZSB0aGF0IHJvdXRlcyB0byBkZXN0SXAuXG5cdCAqIE9ubHkgam9pbnMgdGhlIHNwZWNpZmljIGludGVyZmFjZSB1c2VkIHRvIHJlYWNoIHRoZSBkZXZpY2UsIGFuZCBvbmx5IG9uY2UgcGVyIGludGVyZmFjZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhd2FpdCBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHRpZiAoIWxvY2FsQWRkcikge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGRldGVybWluZSBsb2NhbCBhZGRyZXNzIGZvciBkZXN0aW5hdGlvbiAke2Rlc3RJcH1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0aWYgKHRoaXMuam9pbmVkSW50ZXJmYWNlcy5oYXMobG9jYWxBZGRyKSkge1xuXHRcdFx0XHQvLyBhbHJlYWR5IGpvaW5lZFxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5hZGRNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0dGhpcy5qb2luZWRJbnRlcmZhY2VzLmFkZChsb2NhbEFkZHIpXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBKb2luZWQgbXVsdGljYXN0ICR7dGhpcy5tdWx0aWNhc3RHcm91cH0gb24gJHtsb2NhbEFkZHJ9YClcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gam9pbiBtdWx0aWNhc3Qgb24gJHtsb2NhbEFkZHJ9OiAke1N0cmluZyhfZSl9YClcblx0XHRcdH1cblx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYGVuc3VyZU1lbWJlcnNoaXBGb3IgZmFpbGVkOiAke19lfWApXG5cdFx0fVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHNlbmRBd2FpdEFjayhcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0KTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQrK1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdHRoaXMuc2VuZFF1ZXVlID0gdGhpcy5zZW5kUXVldWUudGhlbihhc3luYyAoKSA9PlxuXHRcdFx0XHR0aGlzLl9zZW5kQXdhaXRBY2soY21kSWQsIGJ1c0NoLCBzZXR0aW5nSWQsIHZhbHVlLCBkZXN0SXAsIGFkZExlbilcblx0XHRcdFx0XHQudGhlbigoYnVmKSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQtLVxuXHRcdFx0XHRcdFx0Ly8gT25seSB0cmlnZ2VyIHJlcXVlc3RBbGxTZXR0aW5ncyBhZnRlciBhIHdyaXRlIChTRVQpIGNvbW1hbmQsIG5vdCBhIHJlYWQvcG9sbC5cblx0XHRcdFx0XHRcdC8vIEEgd3JpdGUgYWx3YXlzIGhhcyBhIHZhbHVlOyByZWFkcyAoR0VULCBCVVNfR0VUKSBuZXZlciBkby5cblx0XHRcdFx0XHRcdGlmICh0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQgPT09IDAgJiYgdGhpcy5yZWZyZXNoQWZ0ZXJDb21tYW5kICYmIHZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdFx0dGhpcy5yZXF1ZXN0QWxsU2V0dGluZ3MoZGVzdElwKS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byByZWZyZXNoIHNldHRpbmdzIGFmdGVyIGNvbW1hbmQ6ICR7ZXJyfWApXG5cdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRyZXNvbHZlKGJ1Zilcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdC5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQtLVxuXHRcdFx0XHRcdFx0cmVqZWN0KGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyIDogbmV3IEVycm9yKFN0cmluZyhlcnIpKSlcblx0XHRcdFx0XHR9KSxcblx0XHRcdClcblx0XHR9KVxuXHR9XG5cblx0cHJpdmF0ZSBhc3luYyBfc2VuZEF3YWl0QWNrKFxuXHRcdGNtZElkOiBudW1iZXIsXG5cdFx0YnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHRzZXR0aW5nSWQ6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHR2YWx1ZTogdW5rbm93bixcblx0XHRkZXN0SXA6IHN0cmluZyxcblx0XHRhZGRMZW4gPSB0cnVlLFxuXHQpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGNvbnN0IHRpbWVvdXRNcyA9IDIwMDBcblxuXHRcdGNvbnN0IGRhdGFCbG9jazogbnVtYmVyW10gPSBbXVxuXHRcdGlmIChzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCkgZGF0YUJsb2NrLnB1c2goc2V0dGluZ0lkICYgMHhmZilcblx0XHRpZiAodmFsdWUgIT09IHVuZGVmaW5lZCkgZGF0YUJsb2NrLnB1c2goLi4uU3RDb250cm9sbGVyLmJ1aWxkVmFsdWVCeXRlcyh2YWx1ZSkpXG5cblx0XHRjb25zdCBwYXlsb2FkQm9keTogbnVtYmVyW10gPSBbMHg1YSwgY21kSWQgJiAweGZmXVxuXG5cdFx0aWYgKGNtZElkID09PSBDTURfTUlDX1BSRSAmJiBidXNDaCAhPT0gdW5kZWZpbmVkICYmIHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkICYmIHZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdC8vIFBvc2l0aW9uYWwgZm9ybWF0OiBbMHg1YV0gWzB4MDJdIFtidXNDaF0gW3ZhbDBdIFt2YWwxXSBbdmFsMl0gLi4uXG5cdFx0XHQvLyBSZWFkIGFsbCBwb3NpdGlvbnMgZnJvbSBkZXZpY2VTdGF0ZSwgb3ZlcnJpZGUgdGhlIHRhcmdldCBwb3NpdGlvbiB3aXRoIG5ldyB2YWx1ZS5cblx0XHRcdC8vIEFsc28gdXBkYXRlIGRldmljZVN0YXRlIG9wdGltaXN0aWNhbGx5IHNvIGNvbnNlY3V0aXZlIENNRF9NSUNfUFJFIGNvbW1hbmRzIGNoYWluIGNvcnJlY3RseS5cblx0XHRcdGlmICghdGhpcy5kZXZpY2VTdGF0ZS5oYXMoZGVzdElwKSkgdGhpcy5kZXZpY2VTdGF0ZS5zZXQoZGVzdElwLCBuZXcgTWFwKCkpXG5cdFx0XHRjb25zdCBpcFN0YXRlID0gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoZGVzdElwKSFcblx0XHRcdGNvbnN0IG51bVBvc2l0aW9ucyA9IDMgLy8gZ2FpbiwgZWxlY3RyZXQvcGhhbnRvbSwgdW5rbm93blxuXHRcdFx0Y29uc3QgcG9zaXRpb25zOiBudW1iZXJbXSA9IFtdXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IG51bVBvc2l0aW9uczsgaSsrKSB7XG5cdFx0XHRcdGNvbnN0IHN0YXRlS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBDTURfTUlDX1BSRSwgaSwgYnVzQ2gpXG5cdFx0XHRcdGNvbnN0IHZhbCA9IGkgPT09IHNldHRpbmdJZCA/IE51bWJlcih2YWx1ZSkgOiAoaXBTdGF0ZS5nZXQoc3RhdGVLZXkpID8/IDApXG5cdFx0XHRcdHBvc2l0aW9ucy5wdXNoKHZhbClcblx0XHRcdFx0aXBTdGF0ZS5zZXQoc3RhdGVLZXksIHZhbCkgLy8gb3B0aW1pc3RpYyB1cGRhdGVcblx0XHRcdH1cblx0XHRcdHBheWxvYWRCb2R5LnB1c2goYnVzQ2ggJiAweGZmLCAuLi5wb3NpdGlvbnMpXG5cdFx0fSBlbHNlIHtcblx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBwYXlsb2FkQm9keS5wdXNoKGJ1c0NoICYgMHhmZilcblx0XHRcdGlmIChhZGRMZW4pIHBheWxvYWRCb2R5LnB1c2goZGF0YUJsb2NrLmxlbmd0aClcblx0XHRcdGlmIChkYXRhQmxvY2subGVuZ3RoID4gMCkgcGF5bG9hZEJvZHkucHVzaCguLi5kYXRhQmxvY2spXG5cdFx0fVxuXG5cdFx0Y29uc3QgY3JjID0gU3RDb250cm9sbGVyLmNyYzhEdmJTMihwYXlsb2FkQm9keSlcblx0XHRjb25zdCBwYXlsb2FkV2l0aENyYyA9IEJ1ZmZlci5mcm9tKFsuLi5wYXlsb2FkQm9keSwgY3JjXSlcblxuXHRcdC8vIEh1bWFuLXJlYWRhYmxlIGluZm8gbG9nIGZvciB0aGUgb3V0Z29pbmcgY29tbWFuZFxuXHRcdGlmIChzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gU3RDb250cm9sbGVyLmJ1aWxkVmFsdWVCeXRlcyh2YWx1ZSlcblx0XHRcdGNvbnN0IHNldHRpbmc6IFBhcnNlZFNldHRpbmcgPSB7XG5cdFx0XHRcdGNtZF9pZDogY21kSWQsXG5cdFx0XHRcdGlkOiBzZXR0aW5nSWQsXG5cdFx0XHRcdGJ1c0NoLFxuXHRcdFx0XHR2YWx1ZUJ5dGVzLFxuXHRcdFx0fVxuXHRcdFx0bG9nZ2VyLmluZm8oYFRYICR7ZGVzdElwfSB8ICR7Zm9ybWF0UGFyc2VkU2V0dGluZyhzZXR0aW5nLCB0aGlzLmFjdGlvbnMpfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBUWCAke2Rlc3RJcH0gfCAke2dldENvbW1hbmROYW1lKGNtZElkKX1gKVxuXHRcdH1cblxuXHRcdC8vIFJlamVjdCBjb21tYW5kcyB0byB1bnZlcmlmaWVkIGRldmljZXMgXHUyMDE0IGxvZyB0aGUgd291bGQtYmUgcGFja2V0IGZpcnN0IGF0IGRlYnVnXG5cdFx0Ly8gc28gdGhlIGJ5dGVzIGFyZSB2aXNpYmxlIGV2ZW4gd2hlbiB0aGUgZGV2aWNlIGlzIG9mZmxpbmUuXG5cdFx0aWYgKCF0aGlzLmF1dGhvcml6ZWRJcHMuaGFzKGRlc3RJcCkpIHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUGFja2V0IChub3Qgc2VudCBcdTIwMTQgZGV2aWNlIG5vdCBhdXRob3JpemVkKSB0byAke2Rlc3RJcH06ICR7cGF5bG9hZFdpdGhDcmMudG9TdHJpbmcoJ2hleCcpfWApXG5cdFx0XHR0aHJvdyBuZXcgRXJyb3IoYERldmljZSBhdCAke2Rlc3RJcH0gaXMgbm90IGF1dGhvcml6ZWQgXHUyMDE0IHZlcmlmeSB0aGUgSVAgYW5kIG1vZGVsIG1hdGNoIGJlZm9yZSBzZW5kaW5nIGNvbW1hbmRzYClcblx0XHR9XG5cblx0XHQvLyBFbnN1cmUgd2UgYXJlIGxpc3RlbmluZyBmb3IgcmVwbGllcyBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgd2lsbCByZWNlaXZlIHRoZW1cblx0XHRhd2FpdCB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKVxuXG5cdFx0Y29uc3QgdG90YWxMZW4gPSAyNCArIHBheWxvYWRXaXRoQ3JjLmxlbmd0aFxuXHRcdGNvbnN0IGhlYWRlciA9IGF3YWl0IHRoaXMuYnVpbGRIZWFkZXIodG90YWxMZW4sIGRlc3RJcClcblx0XHRjb25zdCBwYWNrZXQgPSBCdWZmZXIuY29uY2F0KFtoZWFkZXIsIHBheWxvYWRXaXRoQ3JjXSlcblxuXHRcdGxvZ2dlci5kZWJ1ZyhgU2VuZGluZyBwYWNrZXQgdG8gJHtkZXN0SXB9OiAke3BhY2tldC50b1N0cmluZygnaGV4Jyl9YClcblxuXHRcdGNvbnN0IGtleSA9IGAke2Rlc3RJcH06JHtjbWRJZH1gXG5cblx0XHRyZXR1cm4gbmV3IFByb21pc2U8QnVmZmVyPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYFRpbWVvdXQgd2FpdGluZyBmb3IgQUNLIGZyb20gTW9kZWwgJHt0aGlzLm1vZGVsfSBhdCAke2Rlc3RJcH06ODcwMGApKVxuXHRcdFx0fSwgdGltZW91dE1zKVxuXG5cdFx0XHR0aGlzLnBlbmRpbmdBY2tzLnNldChrZXksIHtcblx0XHRcdFx0cmVzb2x2ZTogKGJ1ZikgPT4ge1xuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZXNvbHZlKGJ1Zilcblx0XHRcdFx0fSxcblx0XHRcdFx0cmVqZWN0OiAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChlcnIpXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHRpbWVyLFxuXHRcdFx0fSlcblxuXHRcdFx0dGhpcy50eFNvY2tldC5zZW5kKHBhY2tldCwgdGhpcy5kZWZhdWx0UG9ydCwgZGVzdElwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGhhbmRsZUluY29taW5nKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKSB7XG5cdFx0aWYgKG1zZy5sZW5ndGggPCA0KSByZXR1cm5cblx0XHRpZiAobXNnWzBdICE9PSAweGZmIHx8IG1zZ1sxXSAhPT0gMHhmZikgcmV0dXJuXG5cblx0XHRjb25zdCBtc2dUeXBlID0gbXNnLnJlYWRVSW50MTZCRSgyKVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlICgweDAxNzApIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFRoZXNlIGhhdmUgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNiwgbm90IFwiU3R1ZGlvLVRcIiBcdTIwMTQgaGFuZGxlIGJlZm9yZVxuXHRcdC8vIHRoZSBTdHVkaW8tVCBzaWduYXR1cmUgY2hlY2sgYmVsb3cuXG5cdFx0aWYgKG1zZ1R5cGUgPT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFICYmIHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNpemUgPiAwKSB7XG5cdFx0XHRjb25zdCBkZXZpY2UgPSBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZywgc3JjSXApXG5cdFx0XHRpZiAoZGV2aWNlKSB7XG5cdFx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0XHRgRGFudGUgaW5mbyByZXNwb25zZSBmcm9tICR7c3JjSXB9OiBgICtcblx0XHRcdFx0XHRcdGBEZXZpY2VJRD1cIiR7ZGV2aWNlLm5hbWV9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1vZGVsPVwiJHtkZXZpY2UubW9kZWx9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1vZGVsTmFtZT1cIiR7ZGV2aWNlLm1vZGVsTmFtZX1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTWFudWZhY3R1cmVyPVwiJHtkZXZpY2UubWFudWZhY3R1cmVyfVwiYCxcblx0XHRcdFx0KVxuXG5cdFx0XHRcdC8vIE9ubHkgYWNjZXB0IFN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlcyAoaWRlbnRpZmllZCBieSBEZXZpY2VJRCBcIlN0dWRpby1UXCIpXG5cdFx0XHRcdGlmIChkZXZpY2UubmFtZSA9PT0gJ1N0dWRpby1UJykge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgY2Igb2YgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMudmFsdWVzKCkpIHtcblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdGNiKGRldmljZSlcblx0XHRcdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBJZ25vcmluZyBub24tU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2U6IERldmljZUlEPVwiJHtkZXZpY2UubmFtZX1cIiBAICR7c3JjSXB9YClcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKG1zZy5sZW5ndGggPCAyNSkgcmV0dXJuXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgY29udHJvbCBwcm90b2NvbCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBzaWcgPSBtc2cuc3ViYXJyYXkoMTYsIDI0KVxuXHRcdGlmIChzaWcudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdTdHVkaW8tVCcpIHJldHVyblxuXG5cdFx0Ly8gUGF5bG9hZCBzdGFydHMgYXQgb2Zmc2V0IDI0XG5cdFx0Ly8gTGF5b3V0OiBbMHg1YV0gW2NtZElkfDB4ODBdIFtkYXRhLi4uXSBbY3JjXVxuXHRcdGNvbnN0IHN0UGF5bG9hZCA9IG1zZy5zdWJhcnJheSgyNClcblx0XHRpZiAoc3RQYXlsb2FkLmxlbmd0aCA8IDIpIHJldHVyblxuXHRcdGlmIChzdFBheWxvYWRbMF0gIT09IDB4NWEpIHJldHVyblxuXG5cdFx0Ly8gRGV2aWNlIHJlcGxpZXMgd2l0aCBjbWQgfCAweDgwXG5cdFx0Y29uc3QgcmVzcENtZElkID0gc3RQYXlsb2FkWzFdXG5cdFx0Y29uc3QgaXNSZXNwb25zZSA9IChyZXNwQ21kSWQgJiAweDgwKSAhPT0gMFxuXHRcdGNvbnN0IG9yaWdpbmFsQ21kSWQgPSByZXNwQ21kSWQgJiAweDdmIC8vIHN0cmlwIHRoZSByZXNwb25zZSBmbGFnXG5cblx0XHQvLyBMb2cgcmF3IHBhY2tldCBmb3IgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIHJlc3BvbnNlcyBiZWZvcmUgcGFyc2luZ1xuXHRcdGlmIChpc1Jlc3BvbnNlICYmIG9yaWdpbmFsQ21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTKSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFJlY2VpdmVkIHBhY2tldCBmcm9tICR7c3JjSXB9OiAke21zZy50b1N0cmluZygnaGV4Jyl9YClcblx0XHR9XG5cblx0XHQvLyBMb2cgdGhlIHBheWxvYWQgKHdvcmtzIGZvciBib3RoIHJlcXVlc3RzIGFuZCByZXNwb25zZXMpXG5cdFx0dGhpcy5sb2dTdFBheWxvYWQoc3JjSXAsIG9yaWdpbmFsQ21kSWQsIG1zZywgc3RQYXlsb2FkKVxuXG5cdFx0Ly8gT25seSBwcm9jZXNzIGFzIEFDSyBpZiB0aGlzIGlzIGEgcmVzcG9uc2UgdG8gb3VyIHJlcXVlc3Rcblx0XHRpZiAoaXNSZXNwb25zZSkge1xuXHRcdFx0Y29uc3Qga2V5ID0gYCR7c3JjSXB9OiR7b3JpZ2luYWxDbWRJZH1gXG5cdFx0XHRjb25zdCBwZW5kaW5nID0gdGhpcy5wZW5kaW5nQWNrcy5nZXQoa2V5KVxuXHRcdFx0aWYgKHBlbmRpbmcpIHtcblx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRwZW5kaW5nLnJlc29sdmUobXNnKVxuXHRcdFx0fVxuXHRcdH1cblx0XHQvLyBVbnNvbGljaXRlZCBtZXNzYWdlcyBhbmQgcmVxdWVzdHMgZnJvbSBvdGhlciBzb3VyY2VzIGFyZSBsb2dnZWQgYWJvdmVcblx0fVxuXG5cdC8qKlxuXHQgKiBEZWNvZGVzIGFuZCBsb2dzIGEgU3R1ZGlvLVQgcmVzcG9uc2UgcGF5bG9hZC5cblx0ICogUmVjZWl2ZXMgYm90aCB0aGUgZnVsbCBtc2cgKGZvciBwYXJzZXJzIHRoYXQgbmVlZCB0aGUgU3R1ZGlvLVQgaGVhZGVyKVxuXHQgKiBhbmQgc3RQYXlsb2FkIChtc2cuc3ViYXJyYXkoMjQpLCBmb3IgZGlyZWN0IGJ5dGUgYWNjZXNzKS5cblx0ICpcblx0ICogc3RQYXlsb2FkIGxheW91dDpcblx0ICogICBbMF0gICAgICAweDVhICBtYWdpY1xuXHQgKiAgIFsxXSAgICAgIGNtZElkIHwgMHg4MFxuXHQgKiAgIFsyLi4tMl0gIGRhdGEgYnl0ZXNcblx0ICogICBbLTFdICAgICBDUkMtOC9EVkItUzJcblx0ICovXG5cdHByaXZhdGUgbG9nU3RQYXlsb2FkKHNyY0lwOiBzdHJpbmcsIGNtZElkOiBudW1iZXIsIG1zZzogQnVmZmVyLCBzdFBheWxvYWQ6IEJ1ZmZlcik6IHZvaWQge1xuXHRcdGNvbnN0IGNtZE5hbWUgPSBnZXRDb21tYW5kTmFtZShjbWRJZClcblx0XHRjb25zdCBkYXRhID0gc3RQYXlsb2FkLnN1YmFycmF5KDIsIHN0UGF5bG9hZC5sZW5ndGggLSAxKSAvLyBzdHJpcCBtYWdpYytjbWRJZCBoZWFkZXIgYW5kIENSQ1xuXG5cdFx0Ly8gUGF5bG9hZCBzdHJ1Y3R1cmU6IFtjbWQ6MHg4ZF0gW2RhdGEgYnl0ZXMuLi5dIFtjcmNdXG5cdFx0Y29uc3QgcmVzcENtZElkID0gc3RQYXlsb2FkWzFdXG5cdFx0Y29uc3QgY3JjID0gc3RQYXlsb2FkW3N0UGF5bG9hZC5sZW5ndGggLSAxXVxuXHRcdGNvbnN0IGZ1bGxTdHJ1Y3R1cmUgPSBgW2NtZDoke3RvSGV4KHJlc3BDbWRJZCl9IGRhdGE6JHtkYXRhLnRvU3RyaW5nKCdoZXgnKX0gY3JjOiR7dG9IZXgoY3JjKX1dYFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSBhbmQgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFBhcnNlIGFsbCBzZXR0aW5ncywgZGlmZiBhZ2FpbnN0IGRldmljZVN0YXRlLCBsb2cgY2hhbmdlZCBhdCBpbmZvIC8gdW5jaGFuZ2VkIGF0IGRlYnVnLFxuXHRcdC8vIHRoZW4gdXBkYXRlIGRldmljZVN0YXRlLiBDTURfR0VUX0FMTF9TRVRUSU5HUyBhbHNvIHNlcnZlcyBhcyB0aGUgaW5pdGlhbCBzdGF0ZSBwb3B1bGF0aW9uIG9uIGNvbm5lY3QuXG5cdFx0aWYgKGNtZElkID09PSBDTURfR0VUX0FMTF9TRVRUSU5HUyB8fCBjbWRJZCA9PT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHRcdGlmICghdGhpcy5tb2RlbCkge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ3MgPVxuXHRcdFx0XHRcdGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSFxuXHRcdFx0XHRcdFx0PyBwYXJzZVNldHRpbmdzUmVzcG9uc2UodGhpcy5tb2RlbCwgbXNnKVxuXHRcdFx0XHRcdFx0OiBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwodGhpcy5tb2RlbCwgbXNnKVxuXG5cdFx0XHRcdGNvbnN0IHByZXZTdGF0ZSA9IHRoaXMuZGV2aWNlU3RhdGUuZ2V0KHNyY0lwKSA/PyBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpXG5cdFx0XHRcdGNvbnN0IG5ld1N0YXRlID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4ocHJldlN0YXRlKSAvLyBjb3B5IFx1MjAxNCB1cGRhdGUgaW4gcGxhY2VcblxuXHRcdFx0XHRmb3IgKGNvbnN0IHMgb2Ygc2V0dGluZ3MpIHtcblx0XHRcdFx0XHRjb25zdCBzdGF0ZUtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgcy5jbWRfaWQsIHMuaWQsIHMuYnVzQ2gpXG5cdFx0XHRcdFx0Ly8gRm9yIFJHQiBjb2xvcnMgKDMgYnl0ZXMpLCBwYWNrIGludG8gc2luZ2xlIG51bWJlcjogKFIgPDwgMTYpIHwgKEcgPDwgOCkgfCBCXG5cdFx0XHRcdFx0Y29uc3QgbmV3VmFsdWUgPVxuXHRcdFx0XHRcdFx0cy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0XHRcdFx0XHQ/IChzLnZhbHVlQnl0ZXNbMF0gPDwgMTYpIHwgKHMudmFsdWVCeXRlc1sxXSA8PCA4KSB8IHMudmFsdWVCeXRlc1syXVxuXHRcdFx0XHRcdFx0XHQ6IChzLnZhbHVlQnl0ZXNbMF0gPz8gMClcblx0XHRcdFx0XHRjb25zdCBwcmV2VmFsdWUgPSBwcmV2U3RhdGUuZ2V0KHN0YXRlS2V5KVxuXHRcdFx0XHRcdGNvbnN0IGNoYW5nZWQgPSBwcmV2VmFsdWUgPT09IHVuZGVmaW5lZCB8fCBwcmV2VmFsdWUgIT09IG5ld1ZhbHVlXG5cblx0XHRcdFx0XHRuZXdTdGF0ZS5zZXQoc3RhdGVLZXksIG5ld1ZhbHVlKVxuXG5cdFx0XHRcdFx0Y29uc3QgZm9ybWF0dGVkID0gZm9ybWF0UGFyc2VkU2V0dGluZyhzLCB0aGlzLmFjdGlvbnMpXG5cdFx0XHRcdFx0aWYgKGNoYW5nZWQpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBSWCAke3NyY0lwfSB8ICR7Zm9ybWF0dGVkfWApXG5cdFx0XHRcdFx0XHQvLyBUcmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZSBcdTIwMTQgdXNlIGJhc2Uga2V5IHdpdGhvdXQgYnVzQ2ggc28gaXQgbWF0Y2hlcyB0aGUgZmVlZGJhY2sgZGVmaW5pdGlvbiBJRFxuXHRcdFx0XHRcdFx0aWYgKHRoaXMuZmVlZGJhY2tDYWxsYmFjaykge1xuXHRcdFx0XHRcdFx0XHRsZXQgYmFzZUlkID0gcy5pZFxuXHRcdFx0XHRcdFx0XHRjb25zdCBiYXNlQWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRpZiAoYS5jbWRfaWQgIT09IHMuY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRcdFx0XHRpZiAoYS5pZCA9PT0gcy5pZCkgcmV0dXJuIHRydWVcblx0XHRcdFx0XHRcdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRcdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRcdFx0XHRjb25zdCBvZmZzZXQgPSBzLmlkIC0gYS5pZFxuXHRcdFx0XHRcdFx0XHRcdHJldHVybiBvZmZzZXQgPiAwICYmIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYykgPT4gYy5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRpZiAoYmFzZUFjdGlvbikgYmFzZUlkID0gYmFzZUFjdGlvbi5pZFxuXHRcdFx0XHRcdFx0XHRjb25zdCBiYXNlRmVlZGJhY2tLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIHMuY21kX2lkLCBiYXNlSWQpXG5cdFx0XHRcdFx0XHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayhiYXNlRmVlZGJhY2tLZXkpXG5cdFx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgZmVlZGJhY2tDYWxsYmFjayBub3Qgc2V0IFx1MjAxNCBza2lwcGluZyBmZWVkYmFjayB1cGRhdGUgZm9yICR7c3RhdGVLZXl9YClcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCAke3NyY0lwfSB8ICR7Zm9ybWF0dGVkfWApXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuZGV2aWNlU3RhdGUuc2V0KHNyY0lwLCBuZXdTdGF0ZSlcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8IHBhcnNlIGZhaWxlZDogJHtlfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIEFsbCBvdGhlciBjb21tYW5kcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBkZWNvZGVkID0gdGhpcy5kZWNvZGVTdERhdGEoY21kSWQsIGRhdGEpXG5cdFx0Ly8gQ01EX0JVU19HRVQgKGtlZXBhbGl2ZSkgaXMgaGlnaC1mcmVxdWVuY3kgbm9pc2UgXHUyMDE0IGxvZyBhdCBkZWJ1ZyBvbmx5XG5cdFx0Y29uc3QgbG9nRm4gPSBjbWRJZCA9PT0gQ01EX0JVU19HRVQgPyBsb2dnZXIuZGVidWcuYmluZChsb2dnZXIpIDogbG9nZ2VyLmluZm8uYmluZChsb2dnZXIpXG5cdFx0aWYgKGRlY29kZWQpIHtcblx0XHRcdGxvZ0ZuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9IHwgJHtkZWNvZGVkfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ0ZuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogQXR0ZW1wdHMgdG8gZGVjb2RlIHRoZSBkYXRhIGJ5dGVzIG9mIGEgU3R1ZGlvLVQgcmVzcG9uc2UgaW50byBhXG5cdCAqIGh1bWFuLXJlYWRhYmxlIHN0cmluZy4gUmV0dXJucyBudWxsIHRvIGZhbGwgYmFjayB0byByYXcgaGV4LlxuXHQgKi9cblx0cHJpdmF0ZSBkZWNvZGVTdERhdGEoY21kSWQ6IG51bWJlciwgZGF0YTogQnVmZmVyKTogc3RyaW5nIHwgbnVsbCB7XG5cdFx0aWYgKGRhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gJ0FDSydcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDaGVjayBmb3Igc2luZ2xlLWJ5dGUgcmVzcG9uc2VzIChBQ0sgb3IgZXJyb3IpIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0aWYgKGRhdGFbMF0gPT09IDB4MDApIHtcblx0XHRcdFx0cmV0dXJuICdBQ0sgb2snXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRyZXR1cm4gYEVSUk9SICR7dG9IZXgoZGF0YVswXSl9YFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHN3aXRjaCAoY21kSWQpIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfTUlDX1BSRSAoMHgwMik6IHJhdyBwcmVhbXAgZWNobyBcdTIwMTQgcG9zaXRpb25hbCBieXRlcywgbm8gc2V0dGluZyBJRHMgXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBEZXZpY2UgZWNob2VzIFtidXNDaF1bdmFsMF1bdmFsMV0uLi4gY29uZmlybWluZyB0aGUgYXBwbGllZCB2YWx1ZXMuXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFOiB7XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCB2YWxzID0gQXJyYXkuZnJvbShkYXRhLnN1YmFycmF5KDEpKVxuXHRcdFx0XHRcdC5tYXAoKGIsIGkpID0+IGBbJHtpfV09MHgke2IudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9KCR7Yn0pYClcblx0XHRcdFx0XHQuam9pbignICcpXG5cdFx0XHRcdHJldHVybiBgY2g9JHtidXNDaH0gJHt2YWxzfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9ERVZfU1BFQyAoMHgwZCk6IHNpbmdsZS1ieXRlIEFDSyBvciBlY2hvIG9mIGFwcGxpZWQgc2V0dGluZyBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIERldmljZSBzZW5kcyB0d28gQ01EX0RFVl9TUEVDIHBhY2tldHMgaW4gcmVzcG9uc2UgdG8gYSBzZXQ6XG5cdFx0XHQvLyAgIDEuIEFDSzogIFtzdGF0dXNdICAgICAgICAgICAgICAgKDEgYnl0ZSwgMHgwMCA9IG9rKVxuXHRcdFx0Ly8gICAyLiBFY2hvOiBbYnVzQ2hdIFtzZXR0aW5nSWRdIFt2YWx1ZS4uLl0gIChjb25maXJtaW5nIHdoYXQgd2FzIGFwcGxpZWQpXG5cdFx0XHRjYXNlIENNRF9ERVZfU1BFQzoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdFx0XHRyZXR1cm4gZGF0YVswXSA9PT0gMHgwMCA/ICdBQ0sgb2snIDogYEFDSyBlcnI9JHt0b0hleChkYXRhWzBdKX1gXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID49IDMpIHtcblx0XHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0XHRjb25zdCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyBgc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9YFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LlswXT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IHZhbHVlTnVtID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/IGAke2Nob2ljZUxhYmVsfSAoJHt0b0hleCh2YWx1ZU51bSEpfSlgIDogYnl0ZXNUb0hleChBcnJheS5mcm9tKHZhbHVlQnl0ZXMpKVxuXHRcdFx0XHRcdGNvbnN0IHJhd1RhZyA9IGBbJHt0b0hleChjbWRJZCl9LyR7dG9IZXgoc2V0dGluZ0lkKX1dPSR7Ynl0ZXNUb0hleChBcnJheS5mcm9tKHZhbHVlQnl0ZXMpKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9ICR7cmF3VGFnfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gYHJhdzogJHtkYXRhLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfTUlDX1BSRV9CVVMgKDB4MTIpOiBNdWx0aS1ieXRlIGVjaG8gcmVzcG9uc2VzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6IHtcblx0XHRcdFx0Ly8gQWxyZWFkeSBoYW5kbGVkIHNpbmdsZS1ieXRlIGFib3ZlLCBzbyBtdWx0aS1ieXRlIG11c3QgYmUgZWNob1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VzID0gYWN0aW9uPy5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID1cblx0XHRcdFx0XHRcdGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlU3RyID0gY2hvaWNlTGFiZWwgPz8gYDB4JHt2YWx1ZUJ5dGVzLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBudWxsXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBCdXMtc2NvcGVkIGdldC9zZXQgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0Y2FzZSBDTURfQlVTX1NFVDoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPCAyKSByZXR1cm4gbnVsbFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0cmV0dXJuIGBjaD0ke2J1c0NofSBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX0gdmFsdWU9JHt2YWx1ZS50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0fVxuXG5cdFx0XHRkZWZhdWx0OlxuXHRcdFx0XHRyZXR1cm4gbnVsbCAvLyBmYWxsIHRocm91Z2ggdG8gcmF3IGhleFxuXHRcdH1cblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGJ1aWxkVmFsdWVCeXRlcyh2YWx1ZTogdW5rbm93bik6IG51bWJlcltdIHtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiBbdmFsdWUgPyAxIDogMF1cblx0XHRpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiB2YWx1ZS5tYXAoKHYpID0+IE51bWJlcih2KSAmIDB4ZmYpXG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcblx0XHRcdGlmICh2YWx1ZSA+IDB4ZmYpIHJldHVybiBbKHZhbHVlID4+IDE2KSAmIDB4ZmYsICh2YWx1ZSA+PiA4KSAmIDB4ZmYsIHZhbHVlICYgMHhmZl1cblx0XHRcdHJldHVybiBbdmFsdWUgJiAweGZmXVxuXHRcdH1cblx0XHR0aHJvdyBuZXcgRXJyb3IoYFVuc3VwcG9ydGVkIHZhbHVlIHR5cGUgZm9yIFNUY29udHJvbGxlcjogJHt2YWx1ZX1gKVxuXHR9XG5cblx0cHJpdmF0ZSBhc3luYyBidWlsZEhlYWRlcih0b3RhbExlbjogbnVtYmVyLCBkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0bGV0IG1hYyA9IHRoaXMubWFjQ2FjaGUuZ2V0KGRlc3RJcClcblx0XHRpZiAoIW1hYykge1xuXHRcdFx0bWFjID0gYXdhaXQgZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwKVxuXHRcdFx0dGhpcy5tYWNDYWNoZS5zZXQoZGVzdElwLCBtYWMpXG5cdFx0fVxuXG5cdFx0cmV0dXJuIEJ1ZmZlci5jb25jYXQoW1xuXHRcdFx0QnVmZmVyLmZyb20oWzB4ZmYsIDB4ZmYsIDB4MDAsIHRvdGFsTGVuICYgMHhmZiwgMHgwNywgMHhlMSwgMHgwMCwgMHgwMCwgLi4ubWFjLCAweDAwLCAweDAwXSksXG5cdFx0XHRCdWZmZXIuZnJvbSgnU3R1ZGlvLVQnLCAndXRmOCcpLFxuXHRcdF0pXG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBjcmM4RHZiUzIoZGF0YTogbnVtYmVyW10pOiBudW1iZXIge1xuXHRcdGxldCBjcmMgPSAwXG5cdFx0Zm9yIChjb25zdCBiIG9mIGRhdGEpIHtcblx0XHRcdGNyYyBePSBiXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IDg7IGkrKykge1xuXHRcdFx0XHRjcmMgPSAoY3JjICYgMHg4MCkgIT09IDAgPyAoKGNyYyA8PCAxKSBeIDB4ZDUpICYgMHhmZiA6IChjcmMgPDwgMSkgJiAweGZmXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBjcmNcblx0fVxuXG5cdC8qKlxuXHQgKiBSZXR1cm5zIHRoZSBjdXJyZW50IGtub3duIHZhbHVlIGZvciBhIHNldHRpbmcgb24gYSBkZXZpY2UsIG9yIHVuZGVmaW5lZCBpZiB1bmtub3duLlxuXHQgKiBVc2UgZm9yIGZlZWRiYWNrcyBcdTIwMTQgdmFsdWUgaXMgdXBkYXRlZCBvbiBldmVyeSBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgZnJvbSB0aGUgZGV2aWNlLlxuXHQgKlxuXHQgKiBAcGFyYW0gaXAgICAgICAgIERldmljZSBJUCBhZGRyZXNzXG5cdCAqIEBwYXJhbSBjbWRJZCAgICAgQ29tbWFuZCBJRCAoZS5nLiBDTURfREVWX1NQRUMpXG5cdCAqIEBwYXJhbSBzZXR0aW5nSWQgU2V0dGluZyBJRCAoZS5nLiAweDAyIGZvciBDb250cm9sIFNvdXJjZSlcblx0ICogQHBhcmFtIGJ1c0NoICAgICBPcHRpb25hbCBidXMvY2hhbm5lbCBJRCBmb3IgbXVsdGktY2hhbm5lbCBjb21tYW5kc1xuXHQgKi9cblx0cHVibGljIGdldFNldHRpbmdWYWx1ZShpcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBzZXR0aW5nSWQ6IG51bWJlciwgYnVzQ2g/OiBudW1iZXIpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuXHRcdGNvbnN0IGtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cdFx0cmV0dXJuIHRoaXMuZGV2aWNlU3RhdGUuZ2V0KGlwKT8uZ2V0KGtleSlcblx0fVxuXG5cdHB1YmxpYyBhc3luYyByZXNldERldmljZShkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKENNRF9SRVNFVF9ERVZJQ0UsIHVuZGVmaW5lZCwgMHgwMCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG5cblx0cHVibGljIGFzeW5jIGdsb2JhbE1pY0tpbGwoZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHJldHVybiB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0xPQkFMX01JQ19LSUxMLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IG9zIGZyb20gJ29zJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRGFudGUnKVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgRGFudGUgZGlzY292ZXJ5IGNvbnN0YW50cyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlcXVlc3QgbWVzc2FnZSB0eXBlIChzZW50IHRvIHBvcnQgODcwMCkgKi9cbmV4cG9ydCBjb25zdCBEQU5URV9NU0dfSU5GT19SRVFVRVNUID0gMHgwMDIwXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgbWVzc2FnZSB0eXBlIChyZWNlaXZlZCBvbiBwb3J0IDg3MDIpICovXG5leHBvcnQgY29uc3QgREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgPSAweDAxNzBcblxuLyoqXG4gKiBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSBsYXlvdXQgKGFsbCBvZmZzZXRzIGFyZSBpbnRvIHRoZSBVRFAgcGF5bG9hZCk6XG4gKiAgIDB4MDAgIHVpbnQxNkJFICBNYWdpYyAoMHhmZmZmKVxuICogICAweDAyICB1aW50MTZCRSAgTWVzc2FnZSB0eXBlICgweDAxNzApXG4gKiAgIDB4MDQgIHVpbnQxNkJFICBTZXF1ZW5jZSBudW1iZXJcbiAqICAgMHgwNiAgMiBieXRlcyAgIFBhZGRpbmdcbiAqICAgMHgwOCAgOCBieXRlcyAgIEVVSS02NCAoc291cmNlIE1BQyB3aXRoIGZmOmZlIGluc2VydGVkIG1pZClcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBBU0NJSSBpZGVudGlmaWVyXG4gKiAgIDB4MTggIDIgYnl0ZXMgICBEYW50ZSBtb2R1bGUgZmlybXdhcmUgdmVyc2lvbiAobWFqb3IsIG1pbm9yKVxuICogICAweDIwICAzMSBieXRlcyAgRGV2aWNlIG5hbWUsIG51bGwtcGFkZGVkIEFTQ0lJIChtYXggMzEgY2hhcnMgcGVyIERhbnRlIHNwZWMpXG4gKiAgIDB4MmUgIHVpbnQxNkJFICBQcm9kdWN0IElEXG4gKiAgIDB4NGMgIDY0IGJ5dGVzICBNYW51ZmFjdHVyZXIgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICogICAweGNjICA2NCBieXRlcyAgTW9kZWwgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICovXG5leHBvcnQgY29uc3QgREFOVEVfSU5GT19NSU5fTEVOID0gMHhjYyArIDY0IC8vIDI2OCBieXRlcyBcdTIwMTQgbmVlZCBmdWxsIG1vZGVsIGZpZWxkXG5cbi8qKlxuICogQnVpbGRzIGEgRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBwYWNrZXQgKHR5cGUgMHgwMDIwKS5cbiAqXG4gKiBQYWNrZXQgbGF5b3V0ICgzMiBieXRlcykgXHUyMDE0IGRlcml2ZWQgZnJvbSBsaXZlIGNhcHR1cmUgYW5hbHlzaXM6XG4gKiAgIDB4MDAgIHVpbnQxNkJFICBNYWdpYyAoMHhmZmZmKVxuICogICAweDAyICB1aW50MTZCRSAgTWVzc2FnZSB0eXBlICgweDAwMjAgPSBkZXZpY2UgaW5mbyByZXF1ZXN0KVxuICogICAweDA0ICB1aW50MTZCRSAgU2VxdWVuY2UgbnVtYmVyIChyYW5kb20pXG4gKiAgIDB4MDYgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MDggIDYgYnl0ZXMgICBTb3VyY2UgTUFDXG4gKiAgIDB4MGUgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgQVNDSUkgaWRlbnRpZmllclxuICogICAweDE4ICAyIGJ5dGVzICAgUHJvdG9jb2wgdmVyc2lvbiAoMHgwNzM5KVxuICogICAweDFhICAyIGJ5dGVzICAgU3ViLXR5cGUgKDB4MDBjMSlcbiAqICAgMHgxYyAgdWludDMyQkUgIENhcGFiaWxpdHkgbWFzayAoMHgwMDBmNDI0MClcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpOiBCdWZmZXIge1xuXHRjb25zdCBidWYgPSBCdWZmZXIuYWxsb2MoMzIsIDApXG5cdGNvbnN0IHNlcSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDB4ZmZmZilcblxuXHRidWYud3JpdGVVSW50MTZCRSgweGZmZmYsIDApXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKERBTlRFX01TR19JTkZPX1JFUVVFU1QsIDIpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKHNlcSwgNClcblxuXHRjb25zdCBtYWMgPSBnZXRGaXJzdExvY2FsTWFjKClcblx0bWFjLmNvcHkoYnVmLCA4KVxuXG5cdEJ1ZmZlci5mcm9tKCdBdWRpbmF0ZScsICdhc2NpaScpLmNvcHkoYnVmLCAxNilcblx0YnVmLndyaXRlVUludDE2QkUoMHgwNzM5LCAyNClcblx0YnVmLndyaXRlVUludDE2QkUoMHgwMGMxLCAyNilcblx0YnVmLndyaXRlVUludDMyQkUoMHgwMDBmNDI0MCwgMjgpXG5cblx0cmV0dXJuIGJ1ZlxufVxuXG4vKiogUmV0dXJucyB0aGUgZmlyc3Qgbm9uLWxvb3BiYWNrIE1BQyBhcyBhIDYtYnl0ZSBCdWZmZXIsIG9yIHplcm9zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEZpcnN0TG9jYWxNYWMoKTogQnVmZmVyIHtcblx0dHJ5IHtcblx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdGZvciAoY29uc3QgYWRkciBvZiBpZmFjZXNbbmFtZV0gPz8gW10pIHtcblx0XHRcdFx0aWYgKCFhZGRyLmludGVybmFsICYmIGFkZHIuZmFtaWx5ID09PSAnSVB2NCcgJiYgYWRkci5tYWMgJiYgYWRkci5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCcpIHtcblx0XHRcdFx0XHRyZXR1cm4gQnVmZmVyLmZyb20oYWRkci5tYWMuc3BsaXQoJzonKS5tYXAoKGg6IHN0cmluZykgPT4gcGFyc2VJbnQoaCwgMTYpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCB7XG5cdFx0LyogaWdub3JlICovXG5cdH1cblx0cmV0dXJuIEJ1ZmZlci5hbGxvYyg2LCAwKVxufVxuXG4vKipcbiAqIFBhcnNlcyBhIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlICh0eXBlIDB4MDE3MCkgaW50byBhIERldmljZUluZm8uXG4gKlxuICogUmVzcG9uc2UgbGF5b3V0IChrZXkgb2Zmc2V0cyk6XG4gKiAgIDB4MDggIDggYnl0ZXMgICBFVUktNjQgXHUyMDE0IGNvbnZlcnQgdG8gTUFDIGJ5IGRyb3BwaW5nIGJ5dGVzIFszXSBhbmQgWzRdIChmZjpmZSlcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBpZGVudGlmaWVyICh1c2VkIHRvIHZlcmlmeSB0aGlzIGlzIGEgcmVhbCByZXNwb25zZSlcbiAqICAgMHgxOCAgMSBieXRlICAgIERhbnRlIEZXIG1ham9yXG4gKiAgIDB4MTkgIDEgYnl0ZSAgICBEYW50ZSBGVyBtaW5vclxuICogICAweDIwICAzMSBieXRlcyAgRGV2aWNlIG5hbWUgKERhbnRlIGxhYmVsKSwgbnVsbC1wYWRkZWQgQVNDSUkgKG1heCAzMSBjaGFycylcbiAqICAgMHgyZSAgdWludDE2QkUgIFByb2R1Y3QgSURcbiAqICAgMHg0YyAgNjQgYnl0ZXMgIE1hbnVmYWN0dXJlciwgbnVsbC1wYWRkZWQgQVNDSUlcbiAqICAgMHhjYyAgNjQgYnl0ZXMgIE1vZGVsIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqXG4gKiBSZXR1cm5zIG51bGwgaWYgYnVmZmVyIGlzIHRvbyBzaG9ydCwgd3JvbmcgbWFnaWMsIG9yIG1pc3NpbmcgbW9kZWwgc3RyaW5nLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VEYW50ZUluZm9SZXNwb25zZShtc2c6IEJ1ZmZlciwgc3JjSXA6IHN0cmluZyk6IERldmljZUluZm8gfCBudWxsIHtcblx0aWYgKG1zZy5sZW5ndGggPCBEQU5URV9JTkZPX01JTl9MRU4pIHJldHVybiBudWxsXG5cdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmYpIHJldHVybiBudWxsXG5cdGlmIChtc2cucmVhZFVJbnQxNkJFKDIpICE9PSBEQU5URV9NU0dfSU5GT19SRVNQT05TRSkgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm4gbnVsbFxuXG5cdGNvbnN0IHJlYWRTdHIgPSAob2Zmc2V0OiBudW1iZXIsIGxlbjogbnVtYmVyKTogc3RyaW5nID0+XG5cdFx0bXNnXG5cdFx0XHQuc3ViYXJyYXkob2Zmc2V0LCBvZmZzZXQgKyBsZW4pXG5cdFx0XHQudG9TdHJpbmcoJ2FzY2lpJylcblx0XHRcdC5zcGxpdCgnXFwwJylbMF1cblx0XHRcdC50cmltKClcblxuXHRjb25zdCBldWk2NCA9IG1zZy5zdWJhcnJheSg4LCAxNilcblx0Y29uc3QgbWFjQnl0ZXMgPSBbZXVpNjRbMF0sIGV1aTY0WzFdLCBldWk2NFsyXSwgZXVpNjRbNV0sIGV1aTY0WzZdLCBldWk2NFs3XV1cblx0Y29uc3QgbWFjID0gbWFjQnl0ZXMubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKS5qb2luKCc6JylcblxuXHRjb25zdCBuYW1lID0gcmVhZFN0cigweDIwLCAzMSkgLy8gRGFudGUgZGV2aWNlIGxhYmVsIChjYW4gYmUgdXAgdG8gMzEgY2hhcnMgcGVyIERhbnRlIHNwZWMpXG5cdGNvbnN0IG1hbnVmYWN0dXJlciA9IHJlYWRTdHIoMHg0YywgNjQpIC8vIGUuZy4gXCJTdHVkaW8gVGVjaG5vbG9naWVzLCBJbmMuXCJcblx0Y29uc3QgbW9kZWxSYXcgPSByZWFkU3RyKDB4Y2MsIDY0KVxuXHRjb25zdCBkYW50ZUZpcm13YXJlID0gYCR7bXNnWzB4MThdfS4ke21zZ1sweDE5XX1gXG5cblx0aWYgKCFtb2RlbFJhdykgcmV0dXJuIG51bGxcblxuXHQvLyBFeHRyYWN0IGp1c3QgdGhlIG1vZGVsIG51bWJlci9jb2RlIChlLmcuIFwiTW9kZWwgMzkxIEFsZXJ0aW5nIFVuaXRcIiBcdTIxOTIgXCIzOTFcIilcblx0Ly8gU3RyaXAgXCJNb2RlbCBcIiBwcmVmaXgsIHRoZW4gdGFrZSBvbmx5IHRoZSBmaXJzdCB3b3JkICh0aGUgbW9kZWwgbnVtYmVyKVxuXHRjb25zdCBtb2RlbCA9IG1vZGVsUmF3XG5cdFx0LnJlcGxhY2UoL15Nb2RlbFxccysvaSwgJycpXG5cdFx0LnRyaW0oKVxuXHRcdC5zcGxpdCgvXFxzKy8pWzBdXG5cblx0cmV0dXJuIHtcblx0XHRpcDogc3JjSXAsXG5cdFx0bmFtZSxcblx0XHRtYW51ZmFjdHVyZXIsXG5cdFx0bW9kZWwsXG5cdFx0bW9kZWxOYW1lOiBtb2RlbFJhdywgLy8gRnVsbCBtb2RlbCBkZXNjcmlwdGlvblxuXHRcdG1hYyxcblx0XHRkYW50ZUZpcm13YXJlLFxuXHR9XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgTUFDIGFkZHJlc3MgYnl0ZXMgb2YgdGhlIGxvY2FsIGludGVyZmFjZSB1c2VkIHRvIHJvdXRlIHRvIGRlc3RJcC5cbiAqIFVzZXMgYSB0ZW1wb3JhcnkgVURQIGNvbm5lY3QgdG8gbGV0IHRoZSBPUyBzZWxlY3QgdGhlIG91dGdvaW5nIGludGVyZmFjZSxcbiAqIHRoZW4gZmluZHMgdGhlIG1hdGNoaW5nIE1BQyBmcm9tIG9zLm5ldHdvcmtJbnRlcmZhY2VzKCkuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8bnVtYmVyW10+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPG51bWJlcltdPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHR9KVxuXG5cdFx0dG1wLmNvbm5lY3QoOSwgZGVzdElwLCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGFkZHIuYWRkcmVzc1xuXHRcdFx0XHR0bXAuY2xvc2UoKVxuXG5cdFx0XHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRcdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGlmYWNlIG9mIGlmYWNlc1tuYW1lXSA/PyBbXSkge1xuXHRcdFx0XHRcdFx0aWYgKFxuXHRcdFx0XHRcdFx0XHRpZmFjZS5mYW1pbHkgPT09ICdJUHY0JyAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5hZGRyZXNzID09PSBsb2NhbEFkZHIgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UubWFjICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAhPT0gJzAwOjAwOjAwOjAwOjAwOjAwJ1xuXHRcdFx0XHRcdFx0KSB7XG5cdFx0XHRcdFx0XHRcdHJldHVybiByZXNvbHZlKGlmYWNlLm1hYy5zcGxpdCgnOicpLm1hcCgoYikgPT4gcGFyc2VJbnQoYiwgMTYpICYgMHhmZikpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYE5vIGludGVyZmFjZSBmb3VuZCBmb3IgbG9jYWwgYWRkcmVzcyAke2xvY2FsQWRkcn1gKSlcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoU3RyaW5nKF9lKSkpXG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBsb2NhbCBJUCBhZGRyZXNzIHVzZWQgYnkgdGhlIE9TIHRvIHJvdXRlIHRvIGRlc3RJcC5cbiAqIFVzZXMgYSB0ZW1wb3JhcnkgVURQIHNvY2tldCBjb25uZWN0IHRvIGxldCB0aGUgT1Mgc2VsZWN0IHRoZSBvdXRnb2luZyBpbnRlcmZhY2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTxzdHJpbmc+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCB0bXAgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoJ3VkcDQnKVxuXG5cdFx0bGV0IHJlc29sdmVkID0gZmFsc2Vcblx0XHR0bXAub25jZSgnZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gVXNlIGFuIGFyYml0cmFyeSBwb3J0IGZvciBjb25uZWN0OyB3ZSBvbmx5IG5lZWQgdGhlIGtlcm5lbCB0byBhc3NpZ24gYSBsb2NhbCBhZGRyZXNzLlxuXHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgYWRkciA9IHRtcC5hZGRyZXNzKCkgYXMgeyBhZGRyZXNzOiBzdHJpbmcgfVxuXHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3Ncblx0XHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdFx0cmVzb2x2ZShsb2NhbEFkZHIpXG5cdFx0XHRcdH1cblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoU3RyaW5nKF9lKSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuXG4vKipcbiAqIExpc3RlbnMgZm9yIERhbnRlIGRldmljZSBhbm5vdW5jZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsgYW5kIHNlbmRzIHVuaWNhc3RcbiAqIGluZm8gcmVxdWVzdHMgdG8gZWFjaCBkaXNjb3ZlcmVkIElQLiBSZXNwb25zZXMgYXJyaXZlIG9uIHRoZSBjYWxsZXIncyByeFNvY2tldFxuICogdmlhIGhhbmRsZUluY29taW5nKCkgXHUyMTkyIGRpc2NvdmVyeUxpc3RlbmVycy5cbiAqXG4gKiBAcGFyYW0gdHhTb2NrZXQgLSBUaGUgc29ja2V0IHRvIHVzZSBmb3Igc2VuZGluZyBkaXNjb3ZlcnkgcmVxdWVzdHNcbiAqIEBwYXJhbSBlbnN1cmVNZW1iZXJzaGlwIC0gQ2FsbGJhY2sgdG8gZW5zdXJlIG11bHRpY2FzdCBtZW1iZXJzaGlwIGJlZm9yZSBxdWVyeWluZ1xuICogQHBhcmFtIHRpbWVvdXRNcyAtIEhvdyBsb25nIHRvIGxpc3RlbiBmb3IgYW5ub3VuY2VzIGJlZm9yZSByZXNvbHZpbmdcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRpc2NvdmVyRGV2aWNlcyhcblx0dHhTb2NrZXQ6IGRncmFtLlNvY2tldCxcblx0ZW5zdXJlTWVtYmVyc2hpcDogKGRlc3RJcDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+LFxuXHR0aW1lb3V0TXMgPSA1MDAwLFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IERBTlRFX0FOTk9VTkNFX0dST1VQID0gJzIyNC4wLjAuMjMzJ1xuXHRjb25zdCBEQU5URV9BTk5PVU5DRV9QT1JUID0gODcwOFxuXHRjb25zdCBERUZBVUxUX1BPUlQgPSA4NzAwXG5cblx0Y29uc3QgcXVlcmllZElwcyA9IG5ldyBTZXQ8c3RyaW5nPigpXG5cblx0cmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiB7XG5cdFx0Y29uc3QgYW5ub3VuY2VTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0Y29uc3QgY2xlYW51cCA9ICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmRyb3BNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0cmVzb2x2ZSgpXG5cdFx0fVxuXG5cdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KGNsZWFudXAsIHRpbWVvdXRNcylcblx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdGFubm91bmNlU29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci53YXJuKGBBbm5vdW5jZSBzb2NrZXQgZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0Y29uc3Qgc3JjSXAgPSByaW5mby5hZGRyZXNzXG5cdFx0XHQvLyBWYWxpZGF0ZSBpdCdzIGEgRGFudGUgYW5ub3VuY2UgKG1hZ2ljIDB4ZmZmZSArIFwiQXVkaW5hdGVcIiBhdCBvZmZzZXQgMTYpXG5cdFx0XHRpZiAobXNnLmxlbmd0aCA8IDI0KSByZXR1cm5cblx0XHRcdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmUpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm5cblxuXHRcdFx0aWYgKHF1ZXJpZWRJcHMuaGFzKHNyY0lwKSkgcmV0dXJuXG5cdFx0XHRxdWVyaWVkSXBzLmFkZChzcmNJcClcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgQW5ub3VuY2UgZnJvbSAke3NyY0lwfSBcdTIwMTQgc2VuZGluZyB1bmljYXN0IHF1ZXJ5YClcblxuXHRcdFx0Ly8gSm9pbiAyMjQuMC4wLjIzMSBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIHRoaXMgZGV2aWNlIEJFRk9SRSBzZW5kaW5nXG5cdFx0XHQvLyB0aGUgcXVlcnkuIFRoZSBkZXZpY2UgbXVsdGljYXN0cyBpdHMgMHgwMTcwIHJlc3BvbnNlIHRvIDIyNC4wLjAuMjMxOjg3MDJcblx0XHRcdC8vIGluIGFkZGl0aW9uIHRvIHVuaWNhc3RpbmcgaXQgXHUyMDE0IHJ4U29ja2V0IG11c3QgYmUgYSBtZW1iZXIgdG8gcmVjZWl2ZSBpdC5cblx0XHRcdGNvbnN0IHNlbmRRdWVyeSA9IGFzeW5jICgpID0+IHtcblx0XHRcdFx0YXdhaXQgZW5zdXJlTWVtYmVyc2hpcChzcmNJcClcblx0XHRcdFx0Y29uc3QgcXVlcnkgPSBidWlsZERhbnRlSW5mb1JlcXVlc3QoKVxuXHRcdFx0XHR0eFNvY2tldC5zZW5kKHF1ZXJ5LCBERUZBVUxUX1BPUlQsIHNyY0lwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVycikgbG9nZ2VyLndhcm4oYFVuaWNhc3QgcXVlcnkgdG8gJHtzcmNJcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cdFx0XHRzZW5kUXVlcnkoKS5jYXRjaCgoZXJyKSA9PiBsb2dnZXIud2FybihgUXVlcnkgc2V0dXAgZmFpbGVkOiAke2Vycn1gKSlcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQuYmluZChEQU5URV9BTk5PVU5DRV9QT1JULCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhbm5vdW5jZVNvY2tldC5hZGRNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQKVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgTGlzdGVuaW5nIGZvciBEYW50ZSBhbm5vdW5jZXMgb24gJHtEQU5URV9BTk5PVU5DRV9HUk9VUH06JHtEQU5URV9BTk5PVU5DRV9QT1JUfWApXG5cdFx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBqb2luIGFubm91bmNlIG11bHRpY2FzdCBncm91cDogJHtlcnJ9YClcblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuIiwgImltcG9ydCB7XG5cdEluc3RhbmNlVHlwZXMsXG5cdEluc3RhbmNlQmFzZSxcblx0SW5zdGFuY2VTdGF0dXMsXG5cdFNvbWVDb21wYW5pb25Db25maWdGaWVsZCxcblx0Y3JlYXRlTW9kdWxlTG9nZ2VyLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgR2V0Q29uZmlnRmllbGRzLCByZXNvbHZlSG9zdCwgcmVzb2x2ZU1vZGVsLCBnZXREZXZpY2VTY2hlbWEsIHR5cGUgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zLCBVcGRhdGVWYXJpYWJsZVZhbHVlcyB9IGZyb20gJy4vdmFyaWFibGVzLmpzJ1xuaW1wb3J0IHsgVXBncmFkZVNjcmlwdHMgfSBmcm9tICcuL3VwZ3JhZGVzLmpzJ1xuaW1wb3J0IHsgVXBkYXRlQWN0aW9ucyB9IGZyb20gJy4vYWN0aW9ucy5qcydcbmltcG9ydCB7IFVwZGF0ZUZlZWRiYWNrcyB9IGZyb20gJy4vZmVlZGJhY2tzLmpzJ1xuaW1wb3J0IHsgU3RDb250cm9sbGVyIH0gZnJvbSAnLi9zdGNvbnRyb2xsZXIuanMnXG5pbXBvcnQgdHlwZSB7IERldmljZUluZm8gfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ01vZHVsZUluc3RhbmNlJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlVHlwZXMgPSBJbnN0YW5jZVR5cGVzICYge1xuXHRjb25maWc6IE1vZHVsZUNvbmZpZ1xufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNb2R1bGVJbnN0YW5jZSBleHRlbmRzIEluc3RhbmNlQmFzZTxNb2R1bGVUeXBlcz4ge1xuXHRjb25maWchOiBNb2R1bGVDb25maWcgLy8gU2V0dXAgaW4gaW5pdCgpXG5cdHN0Q29udHJvbGxlciE6IFN0Q29udHJvbGxlclxuXG5cdC8qKiBDYWNoZWQgZGlzY292ZXJ5IHJlc3VsdHMgXHUyMDE0IHBhc3NlZCBpbnRvIGdldENvbmZpZ0ZpZWxkcygpIHNvIHRoZSBVSVxuXHQgKiAgY2FuIHNob3cgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIGRyb3Bkb3duIG9uIHN1YnNlcXVlbnQgY29uZmlnIG9wZW5zLiAqL1xuXHRwcml2YXRlIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXVxuXG5cdC8qKiBDdXJyZW50bHkgYWN0aXZlIG1vZGVsIFx1MjAxNCByZXNvbHZlZCBvbmNlIGluIHN5bmNNb2RlbCgpIGFuZCBjYWNoZWQgaGVyZVxuXHQgKiAgc28gVXBkYXRlQWN0aW9ucywgVXBkYXRlRmVlZGJhY2tzIGV0Yy4gZG9uJ3QgZWFjaCBjYWxsIHJlc29sdmVNb2RlbCBpbmRlcGVuZGVudGx5LiAqL1xuXHRhY3RpdmVNb2RlbDogc3RyaW5nID0gJydcblxuXHRjb25zdHJ1Y3RvcihpbnRlcm5hbDogdW5rbm93bikge1xuXHRcdHN1cGVyKGludGVybmFsKVxuXHR9XG5cblx0YXN5bmMgaW5pdChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0aWYgKCF0aGlzLnN0Q29udHJvbGxlcikge1xuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIgPSBuZXcgU3RDb250cm9sbGVyKClcblx0XHR9XG5cdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGluZywgJ0Rpc2NvdmVyaW5nIGRldmljZXMuLi4nKVxuXG5cdFx0Ly8gV2lyZSBmZWVkYmFjayBjYWxsYmFjayBzbyBzdENvbnRyb2xsZXIgY2FuIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlc1xuXHRcdHRoaXMuc3RDb250cm9sbGVyLnNldEZlZWRiYWNrQ2FsbGJhY2soKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4ge1xuXHRcdFx0dGhpcy5jaGVja0ZlZWRiYWNrcyhmZWVkYmFja0lkKVxuXHRcdH0pXG5cblx0XHQvLyBTdGFydCBkaXNjb3ZlcnkgaW4gdGhlIGJhY2tncm91bmQgXHUyMDE0IGFsbCBtb2RlbCByZXNvbHV0aW9uLCBzY2hlbWEgc3luYyxcblx0XHQvLyBhbmQgVUkgdXBkYXRlcyBoYXBwZW4gaW5zaWRlIHJ1bkRpc2NvdmVyeSgpIG9uY2UgdGhlIGRldmljZSBsaXN0IGlzIGtub3duLlxuXHRcdHRoaXMucnVuRGlzY292ZXJ5KCkuY2F0Y2goKGUpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgRGlzY292ZXJ5IGZhaWxlZDogJHtlfWApXG5cdFx0fSlcblx0fVxuXG5cdC8qKlxuXHQgKiBSdW4gZGV2aWNlIGRpc2NvdmVyeSwgdGhlbiByZXNvbHZlIHRoZSBtb2RlbCBhbmQgdXBkYXRlIGFsbCBVSS5cblx0ICogLSBJZiBkaXNjb3ZlcnkgZmluZHMgZGV2aWNlcywgcmVzb2x2ZU1vZGVsIHBpY2tzIGZyb20gdGhvc2UuXG5cdCAqIC0gT25seSBpZiB0aGUgbGlzdCBpcyBlbXB0eSBkbyB3ZSBmYWxsIGJhY2sgdG8gdGhlIG1hbnVhbCBjb25maWcgc2VsZWN0aW9uLlxuXHQgKiBBbGwgYWN0aW9ucy9mZWVkYmFja3MvdmFyaWFibGVzIGFyZSBidWlsdCBhZnRlciB0aGUgbW9kZWwgaXMga25vd24uXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIHJ1bkRpc2NvdmVyeSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRsb2dnZXIuaW5mbygnU3RhcnRpbmcgZGV2aWNlIGRpc2NvdmVyeS4uLicpXG5cblx0XHR0aGlzLmRpc2NvdmVyZWREZXZpY2VzID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIuZGlzY292ZXJEZXZpY2VzKClcblxuXHRcdC8vIERldGVybWluZSBlZmZlY3RpdmUgbW9kZWwgXHUyMDE0IGZyb20gZGlzY292ZXJlZCBkZXZpY2VzIGZpcnN0LCBtYW51YWwgY29uZmlnIG9ubHkgYXMgZmFsbGJhY2tcblx0XHRsZXQgZWZmZWN0aXZlTW9kZWw6IHN0cmluZ1xuXHRcdGlmICh0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0Ly8gSWYgYSBzcGVjaWZpYyBkZXZpY2UgTUFDIHdhcyBzYXZlZCBpbiBjb25maWcsIGl0IHdhc24ndCBmb3VuZCBcdTIwMTQgc3RvcCBoZXJlLlxuXHRcdFx0aWYgKHRoaXMuY29uZmlnLmRldmljZU1hYykge1xuXHRcdFx0XHRjb25zdCBtb2RlbExhYmVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWwgPyBgTW9kZWwgJHt0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbH0gYCA6ICcnXG5cdFx0XHRcdGxvZ2dlci53YXJuKGBTYXZlZCBkZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGR1cmluZyBkaXNjb3ZlcnkgXHUyMDE0IHN0b3BwaW5nYClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsIGAke21vZGVsTGFiZWx9WyR7dGhpcy5jb25maWcuZGV2aWNlTWFjfV0gbm90IGZvdW5kYClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHRjb25zdCBtYW51YWxNb2RlbCA9IHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsXG5cdFx0XHRpZiAoIXRoaXMuY29uZmlnLmhvc3QgfHwgIW1hbnVhbE1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKCdObyBkZXZpY2VzIGRpc2NvdmVyZWQgYW5kIG5vIG1hbnVhbCBJUC9tb2RlbCBjb25maWd1cmVkJylcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHRsb2dnZXIuaW5mbygnTm8gZGV2aWNlcyBkaXNjb3ZlcmVkIFx1MjAxNCB3aWxsIHByb2JlIG1hbnVhbCBJUCBkdXJpbmcgYXV0aG9yaXphdGlvbicpXG5cdFx0XHRlZmZlY3RpdmVNb2RlbCA9IG1hbnVhbE1vZGVsXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBEaXNjb3ZlcmVkICR7dGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGh9IGRldmljZShzKTpgKVxuXHRcdFx0Zm9yIChjb25zdCBkIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSBNb2RlbCAke2QubW9kZWx9ICR7ZC5tYW51ZmFjdHVyZXIgPz8gJyd9IEAgJHtkLmlwfWApXG5cdFx0XHR9XG5cblx0XHRcdC8vIEF1dGhvcml6ZSBhbGwgZGlzY292ZXJlZCBkZXZpY2VzIHNvIGZpcm13YXJlIHJlcXVlc3RzIGNhbiBwcm9jZWVkLlxuXHRcdFx0Ly8gdmVyaWZ5QXV0aG9yaXphdGlvbiAoY2FsbGVkIGJlbG93KSB3aWxsIHJldm9rZSBhbnkgdGhhdCBkb24ndCBtYXRjaFxuXHRcdFx0Ly8gdGhlIGN1cnJlbnQgY29uZmlnIHNlbGVjdGlvbi5cblx0XHRcdGZvciAoY29uc3QgZGV2aWNlIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKGRldmljZS5pcClcblx0XHRcdH1cblxuXHRcdFx0Ly8gUmVxdWVzdCBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gZWFjaCBkaXNjb3ZlcmVkIGRldmljZVxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNvbnN0IGZpcm13YXJlID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2UuaXApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9IGZpcm13YXJlXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSAke2RldmljZS5pcH06IEZpcm13YXJlICR7ZmlybXdhcmV9LCBEYW50ZSAke2RldmljZS5kYW50ZUZpcm13YXJlfWApXG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgICAtICR7ZGV2aWNlLmlwfTogRmFpbGVkIHRvIGdldCBmaXJtd2FyZTogJHtlfWApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9ICdVbmtub3duJ1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdGVmZmVjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKHRoaXMuY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXG5cdFx0XHQvLyBJZiBhIHNwZWNpZmljIE1BQyB3YXMgc2F2ZWQgYnV0IGlzbid0IGluIHRoZSBkaXNjb3ZlcmVkIGxpc3QsIHN0b3AuXG5cdFx0XHRpZiAoIWVmZmVjdGl2ZU1vZGVsICYmIHRoaXMuY29uZmlnLmRldmljZU1hYykge1xuXHRcdFx0XHRjb25zdCBtb2RlbExhYmVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWwgPyBgTW9kZWwgJHt0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbH0gYCA6ICcnXG5cdFx0XHRcdGxvZ2dlci53YXJuKGBTYXZlZCBkZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGFtb25nIGRpc2NvdmVyZWQgZGV2aWNlcyBcdTIwMTQgc3RvcHBpbmdgKVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSwgYCR7bW9kZWxMYWJlbH1bJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XSBub3QgZm91bmRgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBTeW5jIG1vZGVsIHNjaGVtYSB0byBjb250cm9sbGVyXG5cdFx0dGhpcy5zeW5jTW9kZWwoZWZmZWN0aXZlTW9kZWwpXG5cblx0XHQvLyBWZXJpZnkgdGhhdCB0aGUgY3VycmVudGx5IGNvbmZpZ3VyZWQgaG9zdCttb2RlbCBpcyB2YWxpZCBub3cgdGhhdFxuXHRcdC8vIGRpc2NvdmVyeSByZXN1bHRzIGFyZSBrbm93bi4gVGhpcyBpcyB0aGUgc2FtZSBjaGVjayBjb25maWdVcGRhdGVkIHVzZXMuXG5cdFx0Y29uc3QgdGFyZ2V0SG9zdCA9IHRoaXMuaG9zdFxuXHRcdGF3YWl0IHRoaXMudmVyaWZ5QXV0aG9yaXphdGlvbignJywgdGFyZ2V0SG9zdClcblxuXHRcdC8vIEJ1aWxkIGFsbCBVSSBub3cgdGhhdCBtb2RlbCBhbmQgYXV0aG9yaXphdGlvbiBzdGF0ZSBhcmUga25vd25cblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXG5cdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cdFx0bG9nZ2VyLmluZm8oJ0RldmljZSBkaXNjb3ZlcnkgY29tcGxldGUnKVxuXHR9XG5cblx0Ly8gV2hlbiBtb2R1bGUgZ2V0cyBkZWxldGVkXG5cdGFzeW5jIGRlc3Ryb3koKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5zdENvbnRyb2xsZXI/LmNsb3NlKClcblx0XHRsb2dnZXIuZGVidWcoJ2Rlc3Ryb3knKVxuXHR9XG5cblx0YXN5bmMgY29uZmlnVXBkYXRlZChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGNvbnN0IHByZXZpb3VzSG9zdCA9IHRoaXMuaG9zdFxuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0Y29uc3QgZWZmZWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwoY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXG5cdFx0Ly8gQ2xlYXIgdmFyaWFibGVzIGltbWVkaWF0ZWx5IFx1MjAxNCB0aGUgbmV3IHNlbGVjdGlvbiBpc24ndCBhdXRob3JpemVkIHlldC5cblx0XHQvLyBUaGV5J2xsIGJlIHJlcG9wdWxhdGVkIGJlbG93IG9uY2UgdmVyaWZ5QXV0aG9yaXphdGlvbiBjb21wbGV0ZXMuXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cblx0XHRjb25zdCBuZXdIb3N0ID0gdGhpcy5ob3N0XG5cblx0XHQvLyBSZS12ZXJpZnkgYXV0aG9yaXphdGlvbiBvbiBldmVyeSBjb25maWcgY2hhbmdlIChtb2RlbCBvciBJUCkuXG5cdFx0Ly8gVGhpcyBoYW5kbGVzIHN3aXRjaGluZyBmcm9tIGEgdmFsaWQgZGV2aWNlIHRvIGFuIGludmFsaWQgb25lIGFuZCBiYWNrLlxuXHRcdGF3YWl0IHRoaXMudmVyaWZ5QXV0aG9yaXphdGlvbihwcmV2aW91c0hvc3QsIG5ld0hvc3QpXG5cblx0XHQvLyBSZWJ1aWxkIFVJIGFmdGVyIGF1dGhvcml6YXRpb24gc3RhdGUgaXMgc2V0dGxlZFxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cdH1cblxuXHQvKipcblx0ICogUmUtZXZhbHVhdGVzIHdoZXRoZXIgdGhlIGN1cnJlbnQgY29uZmlnIGlzIGF1dGhvcml6ZWQgdG8gc2VuZCBjb21tYW5kcy5cblx0ICpcblx0ICogQXV0byBtb2RlIChkZXZpY2VNYWMgc2V0KTpcblx0ICogICAtIEZpbmQgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIHdpdGggbWF0Y2hpbmcgTUFDIFx1MjE5MiBnZXQgaXRzIGN1cnJlbnQgSVBcblx0ICogICAtIFJldm9rZSB0aGUgcHJldmlvdXMgSVAsIGF1dGhvcml6ZSB0aGUgbmV3IElQXG5cdCAqICAgLSBJZiBNQUMgbm90IGZvdW5kIGluIGRpc2NvdmVyeSwgcmV2b2tlIGFuZCBibG9ja1xuXHQgKlxuXHQgKiBNYW51YWwgbW9kZSAoZGV2aWNlTWFjIGVtcHR5KTpcblx0ICogICAtIENoZWNrIGRpc2NvdmVyZWQgbGlzdCBieSBJUCttb2RlbCBtYXRjaCwgb3IgcHJvYmUgZGlyZWN0bHlcblx0ICovXG5cdHByaXZhdGUgYXN5bmMgdmVyaWZ5QXV0aG9yaXphdGlvbihwcmV2aW91c0hvc3Q6IHN0cmluZywgbmV3SG9zdDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0aWYgKCFuZXdIb3N0KSB7XG5cdFx0XHRpZiAocHJldmlvdXNIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY29uZmlnLmRldmljZU1hYykge1xuXHRcdFx0Ly8gQXV0byBtb2RlIFx1MjAxNCBtYXRjaCBieSBNQUMsIHVzZSB3aGF0ZXZlciBJUCBkaXNjb3ZlcnkgZm91bmQgaXQgYXRcblx0XHRcdGNvbnN0IGRldmljZSA9IHRoaXMuZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5tYWMgPT09IHRoaXMuY29uZmlnLmRldmljZU1hYylcblx0XHRcdGlmICghZGV2aWNlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBEZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGluIGN1cnJlbnQgZGlzY292ZXJ5IFx1MjAxNCBub3QgYXV0aG9yaXppbmdgKVxuXHRcdFx0XHRpZiAocHJldmlvdXNIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdH1cblx0XHRcdGNvbnN0IHdhc0F1dGhvcml6ZWQgPSB0aGlzLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQobmV3SG9zdClcblx0XHRcdGlmICghd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdH1cblx0XHRcdGlmIChuZXdIb3N0ICE9PSBwcmV2aW91c0hvc3QgfHwgIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKGRldmljZS5tb2RlbCwgbmV3SG9zdClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIE1hbnVhbCBtb2RlIFx1MjAxNCBjb25maWcuaG9zdCArIGNvbmZpZy5hY3RpdmVNb2RlbCBtdXN0IG1hdGNoXG5cdFx0Y29uc3QgbWFudWFsTW9kZWwgPSBTdHJpbmcodGhpcy5jb25maWcuYWN0aXZlTW9kZWwgPz8gJycpXG5cdFx0Y29uc3QgZGlzY292ZXJlZEF0SXAgPSB0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQuaXAgPT09IG5ld0hvc3QpXG5cblx0XHRpZiAoZGlzY292ZXJlZEF0SXApIHtcblx0XHRcdGlmIChkaXNjb3ZlcmVkQXRJcC5tb2RlbCA9PT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRcdGNvbnN0IHdhc0F1dGhvcml6ZWQgPSB0aGlzLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQobmV3SG9zdClcblx0XHRcdFx0aWYgKCF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCB8fCAhd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRcdGF3YWl0IHRoaXMuZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtYW51YWxNb2RlbCwgbmV3SG9zdClcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0bG9nZ2VyLmVycm9yKFxuXHRcdFx0XHRcdGBEZXZpY2Ugc2VsZWN0ZWQgKE1vZGVsICR7bWFudWFsTW9kZWx9KSBkb2VzIG5vdCBtYXRjaCBkZXRlY3RlZCBkZXZpY2UgKE1vZGVsICR7ZGlzY292ZXJlZEF0SXAubW9kZWx9KSBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYCxcblx0XHRcdFx0KVxuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UobmV3SG9zdClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoXG5cdFx0XHRcdFx0SW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsXG5cdFx0XHRcdFx0YE1vZGVsIG1pc21hdGNoOiBleHBlY3RlZCAke21hbnVhbE1vZGVsfSwgZ290ICR7ZGlzY292ZXJlZEF0SXAubW9kZWx9YCxcblx0XHRcdFx0KVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gSVAgbm90IGluIGRpc2NvdmVyZWQgbGlzdCBcdTIwMTQgcHJvYmUgaXQgZGlyZWN0bHkgdmlhIERhbnRlXG5cdFx0bG9nZ2VyLmluZm8oYCR7bmV3SG9zdH0gbm90IGluIGRpc2NvdmVyZWQgbGlzdCBcdTIwMTQgcHJvYmluZ2ApXG5cdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKG5ld0hvc3QpXG5cblx0XHRjb25zdCBwcm9iZWQgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5wcm9iZURldmljZShuZXdIb3N0KVxuXHRcdGlmICghcHJvYmVkKSB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYE5vIGRldmljZSByZXNwb25kZWQgYXQgJHtuZXdIb3N0fSBcdTIwMTQgY29tbWFuZHMgYmxvY2tlZGApXG5cdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Vbmtub3duV2FybmluZywgYERldmljZSBvZmZsaW5lOiAke25ld0hvc3R9YClcblx0XHR9IGVsc2UgaWYgKHByb2JlZC5tb2RlbCAhPT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihcblx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtwcm9iZWQubW9kZWx9KSBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYCxcblx0XHRcdClcblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKFxuXHRcdFx0XHRJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSxcblx0XHRcdFx0YE1vZGVsIG1pc21hdGNoOiBleHBlY3RlZCAke21hbnVhbE1vZGVsfSwgZ290ICR7cHJvYmVkLm1vZGVsfWAsXG5cdFx0XHQpXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBWZXJpZmllZCBNb2RlbCAke3Byb2JlZC5tb2RlbH0gYXQgJHtuZXdIb3N0fWApXG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdGF3YWl0IHRoaXMuZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtYW51YWxNb2RlbCwgbmV3SG9zdClcblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLk9rKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBGZXRjaGVzIGFsbCBzZXR0aW5ncyBmcm9tIHRoZSBkZXZpY2UuIElmIG5vIHNjaGVtYSBleGlzdHMgZm9yIHRoZSBtb2RlbCxcblx0ICogY3JlYXRlcyBvbmUgZnJvbSB0aGUgcmVzcG9uc2UgYW5kIHJlbG9hZHMgdGhlIHNjaGVtYSBjYWNoZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtb2RlbDogc3RyaW5nLCBpcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0aWYgKCFnZXREZXZpY2VTY2hlbWEobW9kZWwpKSB7XG5cdFx0XHRcdC8vIE5vIHNjaGVtYSBleGlzdHMgXHUyMDE0IGRvIE5PVCBhdXRvLWNyZWF0ZSBvbmUgaGVyZS5cblx0XHRcdFx0Ly8gVGhlIHVzZXIgbXVzdCBydW4gXCJHTE9CQUw6IEdldCBBbGwgU2V0dGluZ3NcIiB0byBjcmVhdGUgaXQuXG5cdFx0XHRcdGxvZ2dlci53YXJuKGBObyBzY2hlbWEgZm91bmQgZm9yIE1vZGVsICR7bW9kZWx9IFx1MjAxNCBydW4gXCJHTE9CQUw6IEdldCBBbGwgU2V0dGluZ3NcIiB0byBjcmVhdGUgb25lYClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBmZXRjaCBzZXR0aW5ncyBmcm9tICR7aXB9OiAke2V9YClcblx0XHR9XG5cdH1cblxuXHQvKiogTG9hZHMgdGhlIGRldmljZSBKU09OIGZvciB0aGUgZ2l2ZW4gbW9kZWwsIGNhY2hlcyBpdCBhcyBhY3RpdmVNb2RlbCwgYW5kIHB1c2hlcyBpdCB0byB0aGUgY29udHJvbGxlci4gKi9cblx0cHJpdmF0ZSBzeW5jTW9kZWwobW9kZWw6IHN0cmluZyk6IHZvaWQge1xuXHRcdHRoaXMuYWN0aXZlTW9kZWwgPSBtb2RlbFxuXHRcdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0XHRpZiAoIXNjaGVtYSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYE1vZGVsIFwiJHttb2RlbH1cIiBub3QgZm91bmQgaW4gZGV2aWNlIHNjaGVtYXNgKVxuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0TW9kZWwobW9kZWwsIFtdLCB0cnVlKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Y29uc3QgYWN0aW9ucyA9IEFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkgPyBzY2hlbWEuY21kU2NoZW1hIDogW11cblx0XHRjb25zdCByZWZyZXNoQWZ0ZXJDb21tYW5kID0gc2NoZW1hLnJlZnJlc2hBZnRlckNvbW1hbmQgPz8gdHJ1ZVxuXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0TW9kZWwobW9kZWwsIGFjdGlvbnMsIHJlZnJlc2hBZnRlckNvbW1hbmQpXG5cdFx0aWYgKGFjdGlvbnMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTm8gYWN0aW9ucyBmb3VuZCBmb3IgbW9kZWwgXCIke21vZGVsfVwiIFx1MjAxNCBzZXR0aW5ncyBkZWNvZGluZyB3aWxsIHVzZSByYXcgSURzYClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKFxuXHRcdFx0XHRgTG9hZGVkICR7YWN0aW9ucy5sZW5ndGh9IGFjdGlvbnMgZm9yIG1vZGVsIFwiJHttb2RlbH1cIiwgc2VjdGlvbmVkPSR7c2NoZW1hLnNlY3Rpb25lZH0sIHJlZnJlc2hBZnRlckNvbW1hbmQ9JHtyZWZyZXNoQWZ0ZXJDb21tYW5kfWAsXG5cdFx0XHQpXG5cdFx0fVxuXHR9XG5cblx0Z2V0Q29uZmlnRmllbGRzKCk6IFNvbWVDb21wYW5pb25Db25maWdGaWVsZFtdIHtcblx0XHRyZXR1cm4gR2V0Q29uZmlnRmllbGRzKHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdH1cblxuXHQvKiogUmV0dXJucyB0aGUgZWZmZWN0aXZlIGhvc3QgSVAsIHJlc29sdmVkIGZyb20gTUFDXHUyMTkySVAgdmlhIGRpc2NvdmVyZWREZXZpY2VzIChhdXRvKSBvciBjb25maWcuaG9zdCAobWFudWFsKS4gKi9cblx0Z2V0IGhvc3QoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gcmVzb2x2ZUhvc3QodGhpcy5jb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdH1cblxuXHQvKiogUmV0dXJucyBkaXNjb3ZlcmVkIGRldmljZXMgZm9yIHVzZSBpbiBhY3Rpb25zL2NvbmZpZyAqL1xuXHRnZXQgZGV2aWNlcygpOiBEZXZpY2VJbmZvW10ge1xuXHRcdHJldHVybiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzXG5cdH1cblxuXHR1cGRhdGVBY3Rpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZUFjdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZUZlZWRiYWNrcygpOiB2b2lkIHtcblx0XHRVcGRhdGVGZWVkYmFja3ModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlVmFyaWFibGVWYWx1ZXMoKTogdm9pZCB7XG5cdFx0VXBkYXRlVmFyaWFibGVWYWx1ZXModGhpcylcblx0fVxufVxuXG5leHBvcnQgeyBVcGdyYWRlU2NyaXB0cyB9XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7OztBQWtCQSxJQUFNLHFCQUFrQyxDQUFDLFFBQVEsT0FBTyxZQUFXO0FBRWxFLFVBQVEsSUFBSSxJQUFJLE1BQU0sWUFBVyxDQUFFLElBQUksU0FBUyxLQUFLLE1BQU0sTUFBTSxFQUFFLElBQUksT0FBTyxFQUFFO0FBQ2pGO0FBRUEsU0FBUyxVQUFVLFFBQTRCLE9BQWlCLFNBQWU7QUFDOUUsUUFBTSxPQUFPLE9BQU8sT0FBTyxxQkFBcUIsYUFBYSxPQUFPLG1CQUFtQjtBQUN2RixPQUFLLFFBQVEsT0FBTyxPQUFPO0FBQzVCO0FBT00sU0FBVSxtQkFBbUIsUUFBZTtBQUNqRCxTQUFPO0lBQ04sT0FBTyxDQUFDLFlBQW9CLFVBQVUsUUFBUSxTQUFTLE9BQU87SUFDOUQsTUFBTSxDQUFDLFlBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU87SUFDNUQsTUFBTSxDQUFDLFlBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU87SUFDNUQsT0FBTyxDQUFDLFlBQW9CLFVBQVUsUUFBUSxTQUFTLE9BQU87O0FBRWhFOzs7QUNUTSxTQUFVLFlBQVksTUFBVztBQUV2Qzs7O0FDaENBLFNBQVMsb0JBQW9CO0FBMkV2QixJQUFPLHNCQUFQLGNBQW1DLGFBQW1DO0VBQ2xFO0VBQ0E7RUFFVCxJQUFXLFdBQVE7QUFDbEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFDQSxJQUFXLGFBQVU7QUFDcEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFFQSxJQUFZLGFBQVU7QUFDckIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtBQUNuRCxhQUFPLEtBQUs7SUFDYixPQUFPO0FBQ04sYUFBTztJQUNSO0VBQ0Q7RUFFQSxTQUF1RTtFQUV2RSxZQUFZLFNBQXlDLFNBQStCO0FBQ25GLFVBQUs7QUFFTCxTQUFLLFdBQVc7QUFDaEIsU0FBSyxXQUFXLEVBQUUsR0FBRyxRQUFPO0VBQzdCO0VBRUEsS0FBSyxNQUFjLFVBQW1CLFVBQXFCO0FBQzFELFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0seUJBQXlCO0FBQzdGLFlBQVEsS0FBSyxRQUFRO01BQ3BCLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxvQ0FBb0M7TUFDckQsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLHlCQUF5QjtNQUMxQyxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sbUJBQW1CO01BQ3BDLEtBQUs7QUFDSjtNQUNEO0FBQ0Msb0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGNBQU0sSUFBSSxNQUFNLHNCQUFzQjtJQUN4QztBQUVBLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsYUFBYSxRQUFRO0FBRTNDLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsUUFBUSxLQUFLLFNBQVM7TUFDdEIsWUFBWTs7S0FFWixFQUNBLEtBQ0EsQ0FBQyxhQUFZO0FBQ1osV0FBSyxTQUFTLEVBQUUsWUFBWSxNQUFNLFNBQVE7QUFDMUMsV0FBSyxTQUFTLHdCQUF3QixJQUFJLFVBQVUsSUFBSTtBQUN4RCxXQUFLLEtBQUssV0FBVztJQUN0QixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUztBQUNkLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEsTUFBTSxVQUFxQjtBQUMxQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0lBRXBELE9BQU87QUFDTixjQUFRLEtBQUssUUFBUTtRQUNwQixLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9DQUFvQztRQUNyRCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0JBQW9CO1FBQ3JDO0FBQ0Msc0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGdCQUFNLElBQUksTUFBTSxzQkFBc0I7TUFDeEM7SUFDRDtBQUVBLFVBQU0sV0FBVyxLQUFLLE9BQU87QUFDN0IsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxTQUFTLFFBQVE7QUFFdkMsU0FBSyxTQUNILHFCQUFxQjtNQUNyQjtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLE9BQU87SUFDbEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQVdBLEtBQ0MsY0FDQSxjQUNBLGlCQUNBLGdCQUNBLFNBQ0EsVUFBcUI7QUFFckIsUUFBSSxPQUFPLGlCQUFpQjtBQUFVLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUN6RSxRQUFJLE9BQU8sb0JBQW9CLFVBQVU7QUFDeEMsVUFBSSxPQUFPLG1CQUFtQixZQUFZLE9BQU8sWUFBWTtBQUFVLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUMxRyxVQUFJLGFBQWEsVUFBYSxPQUFPLGFBQWE7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFakcsWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLGNBQWMsZUFBZTtBQUM5RSxXQUFLLFdBQVcsUUFBUSxnQkFBZ0IsU0FBUyxRQUFRO0lBQzFELFdBQVcsT0FBTyxvQkFBb0IsVUFBVTtBQUMvQyxVQUFJLG1CQUFtQixVQUFhLE9BQU8sbUJBQW1CO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRTdHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxHQUFHLE1BQVM7QUFDN0QsV0FBSyxXQUFXLFFBQVEsY0FBYyxpQkFBaUIsY0FBYztJQUN0RSxPQUFPO0FBQ04sWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0lBQ3BDO0VBQ0Q7RUFFQSxlQUNDLGNBQ0EsUUFDQSxRQUEwQjtBQUUxQixRQUFJO0FBQ0osUUFBSSxPQUFPLGlCQUFpQixVQUFVO0FBQ3JDLGVBQVMsT0FBTyxLQUFLLGNBQWMsT0FBTztJQUMzQyxXQUFXLE9BQU8sU0FBUyxZQUFZLEdBQUc7QUFDekMsZUFBUztJQUNWLFdBQVcsTUFBTSxRQUFRLFlBQVksR0FBRztBQUV2QyxhQUFPLE9BQU8sS0FBSyxZQUFZO0lBQ2hDLE9BQU87QUFDTixlQUFTLE9BQU8sS0FBSyxhQUFhLFFBQVEsYUFBYSxZQUFZLGFBQWEsVUFBVTtJQUMzRjtBQUVBLFdBQU8sT0FBTyxTQUFTLFFBQVEsV0FBVyxTQUFZLFNBQVMsU0FBUyxNQUFTO0VBQ2xGO0VBRUEsV0FBVyxRQUFnQixNQUFjLFNBQWlCLFVBQXFCO0FBQzlFLFFBQUksQ0FBQyxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFFekYsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixVQUFVLEtBQUssT0FBTztNQUN0QixTQUFTO01BRVQ7TUFDQTtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osaUJBQVU7SUFDWCxHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEscUJBQXFCLFNBQStCO0FBQ25ELFFBQUk7QUFDSCxXQUFLLEtBQUssV0FBVyxRQUFRLFNBQVMsUUFBUSxNQUFNO0lBQ3JELFNBQVMsSUFBSTtJQUViO0VBQ0Q7RUFDQSxtQkFBbUIsT0FBWTtBQUM5QixTQUFLLFNBQVM7QUFFZCxVQUFNLGFBQWEsS0FBSztBQUN4QixRQUFJO0FBQVksV0FBSyxTQUFTLHdCQUF3QixPQUFPLFdBQVcsUUFBUTtBQUVoRixRQUFJO0FBQ0gsV0FBSyxLQUFLLFNBQVMsS0FBSztJQUN6QixTQUFTLElBQUk7SUFFYjtFQUNEOzs7O0FDOVBLLFNBQVUsa0JBQW1ELEtBQVk7QUFDOUUsUUFBTSxPQUFPO0FBQ2IsU0FBTyxDQUFDLENBQUMsUUFBUSxPQUFPLFNBQVMsWUFBWSxPQUFPLEtBQUssT0FBTyxZQUFZLEtBQUssdUJBQXVCO0FBQ3pHOzs7QUM2Qk0sSUFBZ0IsZUFBaEIsTUFBNEI7RUFDeEI7RUFDQTtFQUVBO0VBRVQsSUFBVyxLQUFFO0FBQ1osV0FBTyxLQUFLLFNBQVM7RUFDdEI7RUFFQSxJQUFXLGtCQUFlO0FBQ3pCLFdBQU8sS0FBSztFQUNiOzs7OztFQU1BLElBQVcsUUFBSztBQUNmLFdBQU8sS0FBSyxTQUFTO0VBQ3RCOzs7O0VBS0EsWUFBWSxVQUFpQjtBQUM1QixRQUFJLENBQUMsa0JBQTZCLFFBQVEsS0FBSyxDQUFDLFNBQVM7QUFDeEQsWUFBTSxJQUFJLE1BQ1QsbUdBQW1HO0FBR3JHLFNBQUssV0FBVztBQUVoQixTQUFLLFVBQVUsbUJBQWtCO0FBRWpDLFNBQUssd0JBQXdCLEtBQUssc0JBQXNCLEtBQUssSUFBSTtBQUVqRSxTQUFLLFdBQVc7TUFDZiwyQkFBMkI7TUFDM0Isd0JBQXdCOztBQUd6QixTQUFLLElBQUksU0FBUyxjQUFjO0VBQ2pDO0VBK0JBLFdBQVcsV0FBNEMsWUFBaUM7QUFDdkYsU0FBSyxTQUFTLFdBQVcsV0FBVyxVQUFVO0VBQy9DOzs7OztFQXVCQSxxQkFBcUIsU0FBeUQ7QUFDN0UsU0FBSyxTQUFTLHFCQUFxQixPQUFPO0VBQzNDOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7OztFQU9BLHFCQUNDLFdBQ0EsU0FBOEM7QUFFOUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXLE9BQU87RUFDdEQ7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFFBQUksTUFBTSxRQUFRLFNBQVM7QUFBRyxZQUFNLElBQUksTUFBTSx3REFBd0Q7QUFFdEcsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7OztFQU1BLGtCQUFrQixRQUF1QztBQUN4RCxTQUFLLFNBQVMsa0JBQWtCLE1BQU07RUFDdkM7Ozs7OztFQU9BLGlCQUFtQyxZQUFhO0FBQy9DLFdBQU8sS0FBSyxTQUFTLGlCQUFpQixVQUFVO0VBQ2pEOzs7O0VBS0Esb0JBQWlCO0FBQ2hCLFNBQUssU0FBUyxrQkFBaUI7RUFDaEM7Ozs7Ozs7RUFRQSxlQUNDLGlCQUNHLGVBQW1EO0FBRXRELFNBQUssU0FBUyxlQUFlLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQztFQUM5RDs7Ozs7RUFNQSxzQkFBc0IsYUFBcUI7QUFDMUMsU0FBSyxTQUFTLG1CQUFtQixXQUFXO0VBQzdDOzs7Ozs7RUFPQSxvQkFBb0IsV0FBbUI7QUFDdEMsU0FBSyxTQUFTLGlCQUFpQixTQUFTO0VBQ3pDOzs7Ozs7RUFNQSxzQkFBc0IsV0FBbUI7QUFDeEMsU0FBSyxTQUFTLG1CQUFtQixTQUFTO0VBQzNDOzs7Ozs7RUFPQSx3QkFBd0IsYUFBcUI7QUFDNUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXO0VBQy9DOzs7Ozs7RUFPQSxhQUFhLFFBQWlDLGNBQXFCO0FBQ2xFLFNBQUssU0FBUyxhQUFhLFFBQVEsWUFBWTtFQUNoRDs7Ozs7Ozs7RUFTQSxRQUFRLE1BQWMsTUFBY0EsT0FBYyxNQUFzQjtBQUN2RSxTQUFLLFNBQVMsUUFBUSxNQUFNLE1BQU1BLE9BQU0sSUFBSTtFQUM3Qzs7Ozs7Ozs7Ozs7RUFZQSxhQUFhLFFBQXdCLFNBQXVCO0FBQzNELFNBQUssU0FBUyxhQUFhLFFBQVEsV0FBVyxJQUFJO0VBQ25EOzs7Ozs7RUFPQSxJQUFJLE9BQWlCLFNBQWU7QUFDbkMsWUFBUSxPQUFPO01BQ2QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRDtBQUNDLG9CQUFZLEtBQUs7QUFDakIsYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtJQUNGO0VBQ0Q7RUFZQSxzQkFDQyxlQUNBLFVBQXlDO0FBRXpDLFVBQU0sVUFBa0MsT0FBTyxrQkFBa0IsV0FBVyxFQUFFLE1BQU0sY0FBYSxJQUFLO0FBRXRHLFVBQU0sU0FBUyxJQUFJLG9CQUFvQixLQUFLLFVBQVUsT0FBTztBQUM3RCxRQUFJO0FBQVUsYUFBTyxHQUFHLFdBQVcsUUFBUTtBQUUzQyxXQUFPO0VBQ1I7Ozs7QUMvVUQsSUFBWTtDQUFaLFNBQVlDLGlCQUFjO0FBQ3pCLEVBQUFBLGdCQUFBLElBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFlBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLG1CQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxXQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxnQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsdUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHlCQUFBLElBQUE7QUFDRCxHQVZZLG1CQUFBLGlCQUFjLENBQUEsRUFBQTtBQWFwQixJQUFXO0NBQWpCLFNBQWlCQyxRQUFLO0FBRVIsRUFBQUEsT0FBQSxLQUFLO0FBQ0wsRUFBQUEsT0FBQSxXQUNaO0FBQ1ksRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxPQUNaO0FBQ1ksRUFBQUEsT0FBQSxjQUFjO0FBQ2QsRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxRQUFRO0FBQ1IsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxTQUFTO0FBQ1QsRUFBQUEsT0FBQSxnQkFBZ0I7QUFDaEIsRUFBQUEsT0FBQSxZQUFZO0FBQ1osRUFBQUEsT0FBQSxXQUNaO0FBQ0YsR0FsQmlCLFVBQUEsUUFBSyxDQUFBLEVBQUE7OztBQ2pCdEIsT0FBTyxRQUFRO0FBQ2YsT0FBTyxVQUFVO0FBSWpCLElBQU0sU0FBUyxtQkFBbUIsUUFBUTtBQXVCMUMsU0FBUyx1QkFBb0I7QUFDNUIsUUFBTSxjQUFjLEtBQUssS0FBSyxZQUFZLFNBQVMsWUFBWTtBQUMvRCxRQUFNLGVBQWUsS0FBSyxLQUFLLFlBQVksU0FBUyxXQUFXO0FBRy9ELE1BQUksR0FBRyxXQUFXLFdBQVcsR0FBRztBQUMvQixXQUFPLE1BQU0seUJBQXlCLFdBQVcsRUFBRTtBQUNuRCxXQUFPO0VBQ1I7QUFHQSxNQUFJLEdBQUcsV0FBVyxZQUFZLEdBQUc7QUFDaEMsV0FBTyxLQUFLLHFEQUFxRCxZQUFZLEVBQUU7QUFDL0UsV0FBTztFQUNSO0FBR0EsUUFBTSxXQUFXOztNQUEwQyxXQUFXO01BQVMsWUFBWTs7QUFDM0YsU0FBTyxNQUFNLFFBQVE7QUFDckIsUUFBTSxJQUFJLE1BQU0sUUFBUTtBQUN6QjtBQUdBLElBQU0sZ0JBQWdCLHFCQUFvQjtBQUcxQyxJQUFJLHFCQUFpRDtBQU0vQyxTQUFVLG1CQUFnQjtBQUMvQixTQUFPO0FBQ1I7QUFNQSxTQUFTLG9CQUFpQjtBQUN6QixRQUFNLFVBQStCLENBQUE7QUFDckMsTUFBSTtBQUNILFVBQU0sUUFBUSxHQUFHLFlBQVksYUFBYSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxPQUFPLENBQUM7QUFFN0UsZUFBVyxLQUFLLE9BQU87QUFDdEIsWUFBTSxXQUFXLEtBQUssS0FBSyxlQUFlLENBQUM7QUFDM0MsWUFBTSxPQUFPLEtBQUssTUFBTSxHQUFHLGFBQWEsVUFBVSxNQUFNLENBQUM7QUFDekQsVUFBSSxNQUFNLE9BQU87QUFDaEIsZ0JBQVEsT0FBTyxLQUFLLEtBQUssQ0FBQyxJQUFJO01BQy9CO0lBQ0Q7QUFFQSxXQUFPLE1BQU0sVUFBVSxPQUFPLEtBQUssT0FBTyxFQUFFLE1BQU0sNEJBQTRCO0VBQy9FLFNBQVMsR0FBRztBQUNYLFdBQU8sTUFBTSxrQ0FBa0MsQ0FBQyxFQUFFO0VBQ25EO0FBQ0EsU0FBTztBQUNSO0FBTU0sU0FBVSxtQkFBZ0I7QUFDL0IsTUFBSSxDQUFDLG9CQUFvQjtBQUN4Qix5QkFBcUIsa0JBQWlCO0VBQ3ZDO0FBQ0EsU0FBTztBQUNSO0FBTU0sU0FBVSxnQkFBZ0IsT0FBYTtBQUM1QyxRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFNBQU8sUUFBUSxLQUFLO0FBQ3JCO0FBTU0sU0FBVSxzQkFBbUI7QUFDbEMsU0FBTyxLQUFLLHVDQUF1QztBQUNuRCx1QkFBcUIsa0JBQWlCO0FBQ3ZDO0FBS0EsU0FBUyxzQkFBbUI7QUFDM0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxTQUFPLE9BQU8sS0FBSyxPQUFPLEVBQUUsS0FBSTtBQUNqQztBQUVNLFNBQVUsZ0JBQWdCLG9CQUFrQyxDQUFBLEdBQUU7QUFDbkUsUUFBTSxTQUFTLG9CQUFtQjtBQUlsQyxRQUFNLGdCQUFnQjtJQUNyQixFQUFFLElBQUksSUFBSSxPQUFPLGtDQUFpQztJQUNsRCxHQUFHLGtCQUFrQixJQUFJLENBQUMsT0FBTztNQUNoQyxJQUFJLEVBQUUsT0FBTztNQUNiLE9BQU8sU0FBUyxFQUFFLEtBQUssS0FBSyxFQUFFLEdBQUcsT0FBTyxFQUFFLEVBQUU7TUFDM0M7O0FBR0gsU0FBTzs7O0lBR047TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULFNBQVM7TUFDVCxTQUFTOzs7SUFJVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsT0FBTyxNQUFNO01BQ2IscUJBQXFCO01BQ3JCLFNBQVM7OztJQUlWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVMsT0FBTyxDQUFDLEtBQUs7TUFDdEIsU0FBUyxPQUFPLElBQUksQ0FBQyxXQUFXO1FBQy9CLElBQUk7UUFDSixPQUFPLFNBQVMsS0FBSztRQUNwQjtNQUNGLHFCQUFxQjtNQUNyQixTQUFTOzs7QUFHWjtBQU9NLFNBQVUsWUFBWSxRQUFzQixtQkFBK0I7QUFDaEYsTUFBSSxPQUFPLFdBQVc7QUFDckIsVUFBTSxTQUFTLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsT0FBTyxTQUFTO0FBQ3ZFLFdBQU8sUUFBUSxNQUFNO0VBQ3RCO0FBQ0EsU0FBTyxPQUFPLE9BQU8sUUFBUSxFQUFFO0FBQ2hDO0FBT00sU0FBVSxhQUFhLFFBQXNCLG1CQUErQjtBQUNqRixNQUFJLE9BQU8sV0FBVztBQUNyQixVQUFNLFNBQVMsa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxPQUFPLFNBQVM7QUFDdkUsV0FBTyxNQUFNLDRCQUE0QixPQUFPLFNBQVMsb0JBQW9CLFFBQVEsU0FBUyxNQUFNLEVBQUU7QUFDdEcsV0FBTyxRQUFRLFNBQVM7RUFDekI7QUFDQSxTQUFPLE1BQU0sMkNBQTJDLE9BQU8sV0FBVyxHQUFHO0FBQzdFLFNBQU8sT0FBTyxPQUFPLGVBQWUsRUFBRTtBQUN2Qzs7O0FDeE1NLFNBQVUsMEJBQTBCLE1BQW9CO0FBQzdELE9BQUssdUJBQXVCO0lBQzNCLE9BQU8sRUFBRSxNQUFNLHNCQUFxQjtJQUNwQyxXQUFXLEVBQUUsTUFBTSx1Q0FBc0M7SUFDekQsY0FBYyxFQUFFLE1BQU0sc0JBQXFCO0lBQzNDLFVBQVUsRUFBRSxNQUFNLDBCQUF5QjtJQUMzQyxTQUFTLEVBQUUsTUFBTSxnQ0FBK0I7SUFDaEQsS0FBSyxFQUFFLE1BQU0scUJBQW9CO0lBQ2pDLElBQUksRUFBRSxNQUFNLG9CQUFtQjtHQUMvQjtBQUNGO0FBRUEsSUFBTSxvQkFBb0I7RUFDekIsT0FBTztFQUNQLFdBQVc7RUFDWCxjQUFjO0VBQ2QsVUFBVTtFQUNWLFNBQVM7RUFDVCxLQUFLO0VBQ0wsSUFBSTs7QUFRQyxTQUFVLHFCQUFxQixNQUFvQjtBQUN4RCxRQUFNLGNBQWMsS0FBSztBQUd6QixNQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssYUFBYSxtQkFBbUIsV0FBVyxHQUFHO0FBQ3ZFLFNBQUssa0JBQWtCLGlCQUFpQjtBQUN4QztFQUNEO0FBRUEsUUFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sV0FBVztBQUM1RCxNQUFJLFFBQVE7QUFDWCxTQUFLLGtCQUFrQjtNQUN0QixPQUFPLE9BQU8sU0FBUztNQUN2QixXQUFXLE9BQU8sYUFBYTtNQUMvQixjQUFjLE9BQU8sZ0JBQWdCO01BQ3JDLFVBQVUsT0FBTyxnQkFBZ0I7TUFDakMsU0FBUyxPQUFPLGlCQUFpQjtNQUNqQyxLQUFLLE9BQU8sT0FBTztNQUNuQixJQUFJLE9BQU87S0FDWDtFQUNGLE9BQU87QUFHTixTQUFLLGtCQUFrQjtNQUN0QixHQUFHO01BQ0gsSUFBSTtLQUNKO0VBQ0Y7QUFDRDs7O0FDMURPLElBQU0saUJBQStEOzs7Ozs7Ozs7Ozs7Ozs7QUNxQnJFLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sY0FBYztBQUNwQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sYUFBYTtBQUNuQixJQUFNLHVCQUF1QjtBQUM3QixJQUFNLG9CQUFvQjtBQUMxQixJQUFNLGVBQWU7QUFDckIsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxjQUFjO0FBR3JCLFNBQVUsZUFBZSxPQUFhO0FBQzNDLFVBQVEsT0FBTztJQUNkLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUjtBQUNDLGFBQU8sU0FBUyxNQUFNLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUM7RUFDckQ7QUFDRDtBQVFNLFNBQVUsY0FDZixPQUNBLE9BQ0EsV0FDQSxPQUF1QjtBQUV2QixRQUFNLE1BQU0sT0FBTyxVQUFVLFdBQVcsTUFBTSxTQUFTLEVBQUUsSUFBSTtBQUM3RCxRQUFNLEtBQUssT0FBTyxjQUFjLFdBQVcsVUFBVSxTQUFTLEVBQUUsSUFBSTtBQUVwRSxNQUFJLFVBQVUsUUFBVztBQUN4QixVQUFNLEtBQUssT0FBTyxVQUFVLFdBQVcsTUFBTSxTQUFTLEVBQUUsSUFBSTtBQUM1RCxXQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUksRUFBRTtFQUNuQztBQUVBLFNBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDN0I7QUFTTSxTQUFVLE1BQU0sT0FBZSxZQUFZLEdBQUM7QUFDakQsU0FBTyxLQUFLLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxXQUFXLEdBQUcsQ0FBQztBQUN4RDtBQU9NLFNBQVUsV0FBVyxPQUF3QjtBQUNsRCxTQUFPLEtBQUssTUFBTSxLQUFLLEtBQUssRUFDMUIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxDQUFDO0FBQ1g7QUFTTSxTQUFVLGVBQWUsR0FBVyxHQUFXLEdBQVM7QUFDN0QsU0FBTyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsRUFDakIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxFQUNQLFlBQVcsQ0FBRTtBQUNoQjtBQVFNLFNBQVUsZUFBZSxJQUFVO0FBQ3hDLFFBQU0sQ0FBQyxPQUFPLFVBQVUsS0FBSyxJQUFJLEdBQUcsTUFBTSxHQUFHO0FBQzdDLFNBQU87SUFDTjtJQUNBLE9BQU8sU0FBUyxVQUFVLEVBQUU7SUFDNUIsUUFBUSxTQUFTLE9BQU8sRUFBRTs7QUFFNUI7QUFVTSxTQUFVLGNBQWMsUUFBZ0IsUUFBYztBQUMzRCxRQUFNLEtBQUssU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUNqRCxRQUFNLEtBQUssU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUNqRCxNQUFJLE9BQU8sTUFBTSxFQUFFLEtBQUssT0FBTyxNQUFNLEVBQUU7QUFBRyxXQUFPO0FBQ2pELFNBQU8sS0FBSyxJQUFJLEtBQUssRUFBRTtBQUN4QjtBQVNNLFNBQVUscUJBQ2YsWUFBK0I7QUFFL0IsUUFBTSxhQUFrRSxDQUFBO0FBQ3hFLGFBQVcsQ0FBQyxPQUFPLElBQUksS0FBSyxPQUFPLFFBQVEsVUFBVSxHQUFHO0FBQ3ZELGVBQVcsS0FBSyxJQUFJO01BQ25CLE9BQU8sS0FBSztNQUNaLFdBQVcsTUFBTSxRQUFRLEtBQUssU0FBUyxJQUFJLEtBQUssWUFBWSxDQUFBOztFQUU5RDtBQUNBLFNBQU87QUFDUjtBQVlNLFNBQVUscUJBQ2YsU0FDQSxPQUNBLE9BQ0EsV0FBaUI7QUFFakIsUUFBTSxTQUFTLFFBQVEsS0FBSztBQUM1QixNQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sUUFBUSxPQUFPLFNBQVM7QUFBRyxXQUFPO0FBR3hELE1BQUksU0FBUyxPQUFPLFVBQVUsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFHdkYsTUFBSSxDQUFDLFFBQVE7QUFDWixhQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVTtBQUN6QyxVQUFJLEVBQUUsV0FBVztBQUFPLGVBQU87QUFDL0IsWUFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUNwRSxVQUFJLENBQUMsYUFBYTtBQUFTLGVBQU87QUFFbEMsWUFBTSxTQUFTLFlBQVksRUFBRTtBQUM3QixhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sTUFBTTtJQUM1RCxDQUFDO0VBQ0Y7QUFFQSxTQUFPO0FBQ1I7OztBQ3pNQSxTQUFTLFlBQVksR0FBTTtBQUMxQixRQUFNLE9BQU87SUFDWixNQUFNLEVBQUU7SUFDUixJQUFJLEVBQUU7SUFDTixPQUFPLEVBQUU7SUFDVCxTQUFTLEVBQUU7SUFDWCxTQUFTLEVBQUU7O0FBR1osVUFBUSxFQUFFLE1BQU07SUFDZixLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxDQUFBLEVBQUU7SUFFM0MsS0FBSztBQUNKLGFBQU87UUFDTixHQUFHO1FBQ0gsS0FBSyxFQUFFO1FBQ1AsS0FBSyxFQUFFO1FBQ1AsTUFBTSxFQUFFLFFBQVE7UUFDaEIsT0FBTzs7SUFHVCxLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxNQUFLO0lBRTlDLEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU8sRUFBRSxTQUFTLEdBQUU7SUFFdkMsS0FBSztJQUNMLEtBQUs7SUFDTDtBQUNDLGFBQU87RUFDVDtBQUNEO0FBTU0sU0FBVSxlQUFZO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsUUFBTSxVQUFzQyxDQUFBO0FBRTVDLGFBQVcsQ0FBQyxPQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ3RELFVBQU0sWUFBWSxPQUFPO0FBQ3pCLFFBQUksQ0FBQyxNQUFNLFFBQVEsU0FBUztBQUFHO0FBRS9CLGVBQVcsS0FBSyxXQUFXO0FBRTFCLFVBQUksRUFBRSxhQUFhO0FBQU07QUFFekIsWUFBTSxXQUFXLGNBQWMsT0FBTyxFQUFFLFFBQVEsRUFBRSxFQUFFO0FBRXBELFlBQU0sV0FBVyxFQUFFLFdBQVcsQ0FBQSxHQUFJLElBQUksV0FBVztBQUVqRCxZQUFNLFNBQW9DO1FBQ3pDLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxJQUFJO1FBQy9CO1FBQ0EsVUFBVSxZQUFXO1FBRXJCOztBQUdELGNBQVEsUUFBUSxJQUFJO0lBQ3JCO0VBQ0Q7QUFFQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLGlCQUFjO0FBQzdCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsUUFBTSxZQUEwQyxDQUFBO0FBRWhELGFBQVcsQ0FBQyxPQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ3RELFVBQU0sWUFBWSxPQUFPO0FBQ3pCLFFBQUksQ0FBQyxNQUFNLFFBQVEsU0FBUztBQUFHO0FBRS9CLGVBQVcsV0FBVyxXQUFXO0FBQ2hDLFlBQU0saUJBQWlCLGNBQWMsT0FBTyxRQUFRLFFBQVEsUUFBUSxFQUFFO0FBR3RFLFlBQU0sY0FBYyxRQUFRLFdBQVcsQ0FBQSxHQUFJLElBQUksV0FBVztBQUcxRCxZQUFNLGVBQWUsV0FBVyxPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUd2RSxtQkFBYSxLQUFLO1FBQ2pCLE1BQU07UUFDTixJQUFJO1FBQ0osT0FBTztRQUNQLFNBQVM7UUFDVCxTQUFTO09BQ1Q7QUFHRCxZQUFNLGdCQUFxQjtRQUMxQixNQUFNO1FBQ04sTUFBTSxTQUFTLEtBQUssS0FBSyxRQUFRLElBQUk7UUFDckMsU0FBUztRQUNULFVBQVUsTUFBSztBQUVkLGlCQUFPO1FBQ1I7O0FBR0QsZ0JBQVUsY0FBYyxJQUFJO0lBQzdCO0VBQ0Q7QUFFQSxTQUFPO0FBQ1I7OztBQ2pJQSxPQUFPQyxXQUFVOzs7QUNMakIsT0FBT0MsU0FBUTtBQWlCZixJQUFNQyxVQUFTLG1CQUFtQixnQkFBZ0I7QUEwQ2xELFNBQVMsZUFBZSxPQUFhO0FBQ3BDLFFBQU0sU0FBUyxvQkFBSSxJQUFHO0FBQ3RCLE1BQUksWUFBWTtBQUVoQixNQUFJO0FBRUgsVUFBTSxPQUFPLGdCQUFnQixLQUFLO0FBQ2xDLFFBQUksQ0FBQyxNQUFNO0FBRVYsYUFBTyxFQUFFLFdBQVcsT0FBTTtJQUMzQjtBQUdBLGdCQUFZLEtBQUssYUFBYTtBQUc5QixlQUFXLFVBQVUsS0FBSyxhQUFhLENBQUEsR0FBSTtBQUMxQyxZQUFNLGlCQUFpQixPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQXdCLElBQUksU0FBUyxhQUFhO0FBQy9GLFVBQUksZ0JBQWdCO0FBRW5CLGVBQU8sSUFBSSxPQUFPLEVBQUU7QUFHcEIsY0FBTSxjQUFjLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBd0IsSUFBSSxPQUFPLE9BQU87QUFDcEYsWUFBSSxhQUFhLFNBQVM7QUFDekIscUJBQVcsVUFBVSxZQUFZLFNBQVM7QUFDekMsZ0JBQUksT0FBTyxPQUFPLE9BQU8sVUFBVTtBQUNsQyxxQkFBTyxJQUFJLE9BQU8sS0FBSyxPQUFPLEVBQUU7WUFDakM7VUFDRDtRQUNEO01BQ0Q7SUFDRDtFQUNELFNBQVMsTUFBTTtFQUVmO0FBRUEsU0FBTyxFQUFFLFdBQVcsT0FBTTtBQUMzQjtBQU1BLFNBQVMsc0JBQXNCLEtBQVc7QUFDekMsUUFBTSxXQUFXLElBQUksUUFBUSxPQUFPLEtBQUssVUFBVSxDQUFDO0FBQ3BELE1BQUksV0FBVztBQUFHLFVBQU0sSUFBSSxNQUFNLGlDQUFpQztBQUVuRSxRQUFNLGVBQWUsV0FBVztBQUNoQyxNQUFJLElBQUksWUFBWSxNQUFNLElBQU07QUFDL0IsVUFBTSxJQUFJLE1BQU0sdUNBQXVDLElBQUksWUFBWSxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUU7RUFDeEY7QUFFQSxTQUFPO0FBQ1I7QUFNQSxTQUFTLHVCQUF1QixPQUFlLFNBQXNCLG9CQUFJLElBQUcsR0FBRTtBQUM3RSxNQUFJLElBQUk7QUFDUixRQUFNLE1BQXVCLENBQUE7QUFFN0IsU0FBTyxJQUFJLE1BQU0sUUFBUTtBQUN4QixVQUFNLEtBQUssTUFBTSxDQUFDO0FBQ2xCLFFBQUksSUFBSSxLQUFLLE1BQU07QUFBUTtBQUczQixRQUFJLE9BQU8sSUFBSSxFQUFFLEtBQUssSUFBSSxJQUFJLE1BQU0sUUFBUTtBQUMzQyxVQUFJLEtBQUs7UUFDUixRQUFRO1FBQ1I7UUFDQSxZQUFZLENBQUMsTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLENBQUM7T0FDckQ7QUFDRCxXQUFLO0FBQ0w7SUFDRDtBQUVBLFFBQUksS0FBSyxFQUFFLFFBQVEsY0FBYyxJQUFJLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBRTtBQUNqRSxTQUFLO0VBQ047QUFFQSxTQUFPO0FBQ1I7QUFFTSxTQUFVLHlCQUF5QixLQUFhLE9BQWE7QUFDbEUsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0sNEJBQTRCO0VBQzdDO0FBRUEsUUFBTSxXQUFXLElBQUksTUFBTSxDQUFDO0FBQzVCLFFBQU0sUUFBUSxNQUFNO0FBQ3BCLFFBQU0sTUFBTSxRQUFRO0FBQ3BCLE1BQUksTUFBTSxJQUFJO0FBQVEsVUFBTSxJQUFJLE1BQU0sc0JBQXNCO0FBRTVELFFBQU0sRUFBRSxPQUFNLElBQUssZUFBZSxLQUFLO0FBQ3ZDLFNBQU8sdUJBQXVCLElBQUksU0FBUyxPQUFPLEdBQUcsR0FBRyxNQUFNO0FBQy9EO0FBTU0sU0FBVSw4QkFBOEIsS0FBYSxPQUFhO0FBQ3ZFLFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtFQUM3QztBQUdBLE1BQUksSUFBSSxVQUFVLHVCQUF1QixNQUFNLElBQUksTUFBTTtBQUN6RCxRQUFNLE1BQU0sSUFBSSxTQUFTO0FBQ3pCLFFBQU0sTUFBdUIsQ0FBQTtBQUc3QixRQUFNLEVBQUUsT0FBTSxJQUFLLGVBQWUsS0FBSztBQUl2QyxRQUFNLG9CQUFvQixDQUFDLGFBQWEsaUJBQWlCLFdBQVc7QUFLcEUsUUFBTSxtQkFBbUIsQ0FBQyxXQUFXO0FBRXJDLFNBQU8sSUFBSSxJQUFJLEtBQUs7QUFDbkIsVUFBTSxTQUFTLElBQUksQ0FBQztBQUNwQixVQUFNLGVBQWUsSUFBSSxJQUFJLENBQUM7QUFFOUIsVUFBTSxhQUFhLElBQUksSUFBSTtBQUMzQixRQUFJLGFBQWE7QUFBSztBQUV0QixVQUFNLFdBQVcsa0JBQWtCLFNBQVMsWUFBWTtBQUN4RCxVQUFNLGFBQWEsaUJBQWlCLFNBQVMsWUFBWTtBQUV6RCxRQUFJO0FBQ0osUUFBSTtBQUNKLFFBQUk7QUFFSixRQUFJLFlBQVk7QUFRZixjQUFRLElBQUksSUFBSSxDQUFDO0FBQ2pCLFlBQU0sV0FBVyxJQUFJLFNBQVMsSUFBSSxHQUFHLFVBQVU7QUFFL0MsWUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFlBQU0saUJBQWlCLFFBQVEsYUFBYSxDQUFBLEdBQzFDLE9BQU8sQ0FBQyxPQUFpQixFQUFFLFdBQVcsZUFBZSxFQUFFLFdBQVcsb0JBQW9CLEVBQUUsVUFBVSxNQUFTLEVBQzNHLEtBQUssQ0FBQyxHQUFhLE1BQWdCLEVBQUUsS0FBSyxFQUFFLEVBQUU7QUFFaEQsZUFBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztBQUN6QyxjQUFNLFFBQVEsY0FBYyxDQUFDO0FBQzdCLFlBQUksT0FBTztBQUNWLGNBQUksS0FBSyxFQUFFLFFBQVEsTUFBTSxRQUFRLElBQUksTUFBTSxJQUFJLE9BQU8sWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUMsQ0FBRTtRQUNsRjtNQUVEO0FBQ0EsVUFBSTtBQUNKO0lBQ0QsV0FBVyxVQUFVO0FBRXBCLGNBQVEsSUFBSSxJQUFJLENBQUM7QUFDakIsZ0JBQVUsSUFBSSxJQUFJLENBQUM7QUFDbkIsVUFBSSxJQUFJO0lBQ1QsT0FBTztBQUVOLGdCQUFVLElBQUksSUFBSSxDQUFDO0FBQ25CLFVBQUksSUFBSTtJQUNUO0FBRUEsVUFBTSxPQUFPLElBQUk7QUFDakIsVUFBTSxTQUFTO0FBRWYsV0FBTyxJQUFJLElBQUksTUFBTTtBQUNwQixZQUFNLEtBQUssSUFBSSxDQUFDO0FBQ2hCLFVBQUk7QUFHSixVQUFJLE9BQU8sSUFBSSxFQUFFLEtBQUssSUFBSSxJQUFJLE1BQU07QUFDbkMscUJBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQztBQUNoRCxhQUFLO01BQ04sT0FBTztBQUNOLHFCQUFhLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQztBQUN4QixhQUFLO01BQ047QUFFQSxZQUFNLFVBQXlCO1FBQzlCLFFBQVE7UUFDUjtRQUNBOztBQUVELFVBQUksVUFBVSxRQUFXO0FBQ3hCLGdCQUFRLFFBQVE7TUFDakI7QUFDQSxVQUFJLEtBQUssT0FBTztJQUNqQjtBQVFBLFFBQUksTUFBTSxVQUFVLGFBQWEsSUFBSSxHQUFHO0FBQ3ZDLFVBQUksTUFBTSxXQUFXLElBQUksSUFBSSxJQUFJO0FBQ2pDLFVBQUksUUFBUTtBQUNaLGFBQU8sTUFBTSxZQUFZO0FBQ3hCLGNBQU0sVUFBeUIsRUFBRSxRQUFRLGNBQWMsSUFBSSxTQUFTLFlBQVksQ0FBQyxJQUFJLEtBQUssQ0FBQyxFQUFDO0FBQzVGLFlBQUksVUFBVTtBQUFXLGtCQUFRLFFBQVE7QUFDekMsWUFBSSxLQUFLLE9BQU87TUFDakI7SUFDRDtBQUVBLFFBQUk7RUFDTDtBQUVBLFNBQU87QUFDUjtBQVdNLFNBQVUsc0JBQXNCLE9BQWUsS0FBVztBQUMvRCxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSxpQ0FBaUMsTUFBTSxTQUFTLEVBQUUsQ0FBQyxHQUFHO0VBQ3ZFO0FBQ0EsUUFBTSxFQUFFLFVBQVMsSUFBSyxlQUFlLEtBQUs7QUFDMUMsU0FBTyxZQUFZLDhCQUE4QixLQUFLLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxLQUFLO0FBQ25HO0FBTU0sU0FBVSxvQkFBb0IsU0FBd0IsU0FBbUI7QUFFOUUsTUFBSSxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFFBQVEsVUFBVSxFQUFFLE9BQU8sUUFBUSxFQUFFO0FBS25GLE1BQUksQ0FBQyxRQUFRO0FBQ1osVUFBTSxhQUFhLFFBQVEsS0FBSyxDQUFDLE1BQUs7QUFDckMsVUFBSSxFQUFFLFdBQVcsUUFBUTtBQUFRLGVBQU87QUFFeEMsWUFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUMvRCxVQUFJLENBQUMsYUFBYTtBQUFTLGVBQU87QUFFbEMsWUFBTSxnQkFBZ0IsUUFBUSxLQUFLLEVBQUU7QUFDckMsYUFBTyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGFBQWE7SUFDOUQsQ0FBQztBQUNELFFBQUksWUFBWTtBQUNmLGVBQVM7SUFDVjtFQUNEO0FBRUEsUUFBTSxTQUFTLE1BQU0sUUFBUSxNQUFNO0FBQ25DLFFBQU0sUUFBUSxNQUFNLFFBQVEsRUFBRTtBQUM5QixRQUFNLFNBQVMsV0FBVyxRQUFRLFVBQVU7QUFDNUMsUUFBTSxTQUNMLFFBQVEsV0FBVyxXQUFXLElBQzNCLGVBQWUsUUFBUSxXQUFXLENBQUMsR0FBRyxRQUFRLFdBQVcsQ0FBQyxHQUFHLFFBQVEsV0FBVyxDQUFDLENBQUMsSUFDbEYsUUFBUSxXQUFXLFdBQVcsSUFDN0IsUUFBUSxXQUFXLENBQUMsSUFDcEIsUUFBUSxXQUFXLEtBQUssR0FBRztBQUdoQyxRQUFNLFdBQVcsUUFBUSxVQUFVLFNBQVksT0FBTyxRQUFRLEtBQUssS0FBSztBQUN4RSxRQUFNLFNBQVMsT0FBTyxNQUFNLEdBQUcsUUFBUSxPQUFPLEtBQUssUUFBUSxNQUFNO0FBR2pFLE1BQUksUUFBUTtBQUNYLFFBQUksT0FBTyxPQUFPO0FBR2xCLFFBQUksUUFBUSxVQUFVLFFBQVc7QUFDaEMsYUFBTyxHQUFHLElBQUksTUFBTSxRQUFRLFFBQVEsQ0FBQztJQUN0QyxPQUVLO0FBQ0osWUFBTSxjQUFjLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUNwRSxVQUFJLGFBQWEsU0FBUztBQUN6QixjQUFNLGdCQUFnQixRQUFRLEtBQUssT0FBTztBQUMxQyxjQUFNLGNBQWMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxhQUFhO0FBQzFFLFlBQUksYUFBYTtBQUNoQixpQkFBTyxHQUFHLElBQUksSUFBSSxZQUFZLEtBQUs7UUFDcEM7TUFDRDtJQUNEO0FBR0EsVUFBTSxjQUFjLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUNwRSxRQUFJLGFBQWEsV0FBVyxRQUFRLFdBQVcsV0FBVyxHQUFHO0FBQzVELFlBQU0sU0FBUyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsV0FBVyxDQUFDLENBQUM7QUFDN0UsVUFBSSxRQUFRO0FBQ1gsZUFBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssT0FBTyxLQUFLLEtBQUssTUFBTTtNQUN2RDtJQUNEO0FBQ0EsV0FBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssTUFBTTtFQUN0QztBQUdBLFNBQU8sR0FBRyxNQUFNO0FBQ2pCO0FBaUJNLFNBQVUsaUNBQ2YsT0FDQSxLQUFXO0FBRVgsUUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQU0sb0JBQW9CLFFBQVE7QUFHbEMsTUFBSSxzQkFBc0IsUUFBVztBQUNwQyxVQUFNLFdBQVcsb0JBQ2QsOEJBQThCLEtBQUssS0FBSyxJQUN4Qyx5QkFBeUIsS0FBSyxLQUFLO0FBQ3RDLFdBQU8sRUFBRSxVQUFVLG1CQUFtQixLQUFJO0VBQzNDO0FBR0EsTUFBSSxlQUFnQyxDQUFBO0FBQ3BDLE1BQUksb0JBQXFDLENBQUE7QUFFekMsTUFBSTtBQUNILG1CQUFlLHlCQUF5QixLQUFLLEtBQUs7RUFDbkQsU0FBUyxHQUFHO0FBQ1gsSUFBQUEsUUFBTyxNQUFNLHVCQUF1QixDQUFDLEVBQUU7RUFDeEM7QUFFQSxNQUFJO0FBQ0gsd0JBQW9CLDhCQUE4QixLQUFLLEtBQUs7RUFDN0QsU0FBUyxHQUFHO0FBQ1gsSUFBQUEsUUFBTyxNQUFNLDRCQUE0QixDQUFDLEVBQUU7RUFDN0M7QUFHQSxNQUFJLGtCQUFrQixTQUFTLGFBQWEsUUFBUTtBQUNuRCxJQUFBQSxRQUFPLEtBQUssNkNBQTZDLGtCQUFrQixNQUFNLFlBQVksYUFBYSxNQUFNLEdBQUc7QUFDbkgsV0FBTyxFQUFFLFVBQVUsbUJBQW1CLG1CQUFtQixLQUFJO0VBQzlELFdBQVcsYUFBYSxTQUFTLEdBQUc7QUFDbkMsSUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxhQUFhLE1BQU0saUJBQWlCLGtCQUFrQixNQUFNLEdBQUc7QUFDOUcsV0FBTyxFQUFFLFVBQVUsY0FBYyxtQkFBbUIsTUFBSztFQUMxRCxPQUFPO0FBRU4sSUFBQUEsUUFBTyxLQUFLLHVEQUF1RCxLQUFLLEVBQUU7QUFDMUUsV0FBTyxFQUFFLFVBQVUsQ0FBQSxHQUFJLG1CQUFtQixLQUFJO0VBQy9DO0FBQ0Q7QUFFTSxTQUFVLDRCQUE0QixPQUFlLEtBQVc7QUFDckUsUUFBTSxFQUFFLFVBQVMsSUFBSyxlQUFlLEtBQUs7QUFDMUMsU0FBTyxZQUFZLDhCQUE4QixLQUFLLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxLQUFLO0FBQ25HO0FBU0EsU0FBUyxtQkFBbUIsWUFBb0I7QUFDL0MsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUM1QixXQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLFVBQVUsU0FBUyxXQUFXLENBQUMsRUFBQztFQUM3RTtBQUVBLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsVUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLElBQUk7QUFDbEIsV0FBTztNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsTUFBTTtNQUNOLFNBQVMsZUFBZSxHQUFHLEdBQUcsQ0FBQzs7RUFFakM7QUFFQSxTQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLE9BQU8sU0FBUyxDQUFDLEdBQUcsVUFBVSxFQUFDO0FBQzVFO0FBTU0sU0FBVSw0QkFDZixXQUNBLFFBQ0EsV0FBc0M7QUFFdEMsUUFBTSxNQUFNLGdCQUFnQixTQUFTO0FBR3JDLE1BQUksQ0FBQyxJQUFJLFdBQVc7QUFDbkIsUUFBSSxZQUFZLENBQUE7RUFDakI7QUFHQSxRQUFNLGFBQWEsT0FBTyxPQUFPLFNBQVMsRUFDeEMsT0FBTyxDQUFDLE1BQU0sRUFBRSxVQUFVLFVBQVUsS0FBSyxFQUN6QyxLQUFLLENBQUMsR0FBRyxNQUFNLGNBQWMsVUFBVSxPQUFPLEVBQUUsS0FBSyxJQUFJLGNBQWMsVUFBVSxPQUFPLEVBQUUsS0FBSyxDQUFDO0FBRWxHLEVBQUFDLFFBQU8sS0FBSyxtQkFBbUIsVUFBVSxLQUFLLEVBQUU7QUFDaEQsRUFBQUEsUUFBTyxNQUFNLDZCQUE2QixXQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssSUFBSSxDQUFDLEVBQUU7QUFLckYsUUFBTSxtQkFBbUIsb0JBQUksSUFBRztBQUNoQyxhQUFXLEtBQUssWUFBWTtBQUMzQixlQUFXLGFBQWEsRUFBRSxhQUFhLENBQUEsR0FBSTtBQUMxQyxZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxPQUFPO0FBQ3JFLFVBQUksQ0FBQyxVQUFVO0FBQVM7QUFDeEIsWUFBTSxTQUFTLFVBQVU7QUFDekIsWUFBTSxRQUFRLFVBQVU7QUFDeEIsWUFBTSxNQUFNLEdBQUcsS0FBSyxJQUFJLE1BQU07QUFDOUIsVUFBSSxpQkFBaUIsSUFBSSxHQUFHO0FBQUc7QUFFL0IsWUFBTSxnQkFBZ0IsT0FDcEIsT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxLQUFLLE1BQU0sRUFDakQsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLE1BQU0sRUFDeEIsS0FBSyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFFdEIsVUFBSSxTQUFTO0FBQ2IsaUJBQVcsT0FBTyxlQUFlO0FBQ2hDLFlBQUksUUFBUSxTQUFTO0FBQUcsbUJBQVM7aUJBQ3hCLE1BQU0sU0FBUztBQUFHO01BQzVCO0FBQ0EsVUFBSSxTQUFTLEdBQUc7QUFDZix5QkFBaUIsSUFBSSxLQUFLLE1BQU07QUFDaEMsUUFBQUEsUUFBTyxNQUFNLGdDQUFnQyxNQUFNLEtBQUssQ0FBQyxZQUFZLE1BQU0sTUFBTSxDQUFDLG9CQUFlLE1BQU0sRUFBRTtNQUMxRztJQUNEO0VBQ0Q7QUFJQSxRQUFNLFlBQVksb0JBQUksSUFBRztBQUN6QixhQUFXLEVBQUUsUUFBUSxJQUFJLE1BQUssS0FBTSxRQUFRO0FBQzNDLFFBQUksVUFBVTtBQUFXO0FBQ3pCLFVBQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxFQUFFO0FBQzNCLFFBQUksQ0FBQyxVQUFVLElBQUksR0FBRztBQUFHLGdCQUFVLElBQUksS0FBSyxvQkFBSSxJQUFHLENBQUU7QUFDckQsY0FBVSxJQUFJLEdBQUcsRUFBRyxJQUFJLEtBQUs7RUFDOUI7QUFNQSxhQUFXLEVBQUUsUUFBUSxJQUFJLE9BQU8sV0FBVSxLQUFNLFFBQVE7QUFFdkQsVUFBTSxnQkFBZ0IsSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ2xGLFFBQUksZUFBZTtBQUNsQixZQUFNLE1BQU0sY0FBYyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQy9ELFVBQUk7QUFBSyxZQUFJLFVBQVUsbUJBQW1CLFVBQVUsRUFBRTtBQUN0RDtJQUNEO0FBS0EsVUFBTSxZQUFZLElBQUksVUFBVSxLQUFLLENBQUMsTUFBSztBQUMxQyxVQUFJLEVBQUUsV0FBVztBQUFRLGVBQU87QUFDaEMsWUFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUN4RCxVQUFJLENBQUMsVUFBVTtBQUFTLGVBQU87QUFDL0IsVUFBSSxNQUFNLEVBQUU7QUFBSSxlQUFPO0FBQ3ZCLFlBQU0sU0FBUyxLQUFLLEVBQUU7QUFFdEIsYUFBTyxXQUFXLEtBQUssQ0FBQyxNQUFLO0FBQzVCLGNBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUUsRUFBRTtBQUM5RSxjQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLGVBQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO01BQzdELENBQUM7SUFDRixDQUFDO0FBQ0QsUUFBSSxXQUFXO0FBQ2QsWUFBTSxTQUFTLEtBQUssVUFBVTtBQUM5QixZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFVBQUksVUFBVSxXQUFXLENBQUMsU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNLEdBQUc7QUFDN0UsWUFBSSxRQUFRLFdBQVcsU0FBUyxDQUFDO0FBQ2pDLG1CQUFXLEtBQUssWUFBWTtBQUMzQixnQkFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLGdCQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLGdCQUFNLFlBQVksVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO0FBQ3ZFLGNBQUksV0FBVztBQUNkLG9CQUFRLFVBQVU7QUFDbEI7VUFDRDtRQUNEO0FBQ0EsaUJBQVMsUUFBUSxLQUFLLEVBQUUsSUFBSSxRQUFRLE1BQUssQ0FBRTtBQUMzQyxRQUFBQSxRQUFPLEtBQ04saUJBQWlCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsdUJBQXVCLE1BQU0sVUFBVSxFQUFFLENBQUMsY0FBYyxNQUFNLE1BQU0sS0FBSyxJQUFJO01BRTdIO0FBQ0E7SUFDRDtBQUdBLFFBQUk7QUFFSixlQUFXLEtBQUssWUFBWTtBQUMzQixZQUFNLFFBQVEsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ3pFLFVBQUksT0FBTztBQUNWLGlCQUFTLGdCQUFnQixLQUFLO0FBRTlCLGNBQU0sV0FBVyxNQUFNLEtBQUssUUFBUSxxQ0FBcUMsRUFBRSxFQUFFLEtBQUk7QUFDakYsZUFBTyxPQUFPLEdBQUcsUUFBUSx5QkFBeUIsRUFBRSxLQUFLO0FBQ3pELFFBQUFBLFFBQU8sS0FBSyxtQkFBbUIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxVQUFVO0FBQzVGO01BQ0Q7SUFDRDtBQUlBLFFBQUksQ0FBQyxRQUFRO0FBQ1osVUFBSSxjQUFjO0FBQ2xCLGlCQUFXLEtBQUssWUFBWTtBQUMzQixjQUFNLFlBQVksRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFVO0FBQzlDLGNBQUksRUFBRSxXQUFXO0FBQVEsbUJBQU87QUFDaEMsZ0JBQU0sV0FBVyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE9BQU87QUFDN0QsY0FBSSxDQUFDLFVBQVU7QUFBUyxtQkFBTztBQUMvQixjQUFJLE1BQU0sRUFBRTtBQUFJLG1CQUFPO0FBQ3ZCLGdCQUFNLFNBQVMsS0FBSyxFQUFFO0FBQ3RCLGdCQUFNLFNBQVMsaUJBQWlCLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSztBQUM1RCxpQkFBTyxVQUFVO1FBQ2xCLENBQUM7QUFDRCxZQUFJLFdBQVc7QUFDZCx3QkFBYztBQUNkLFVBQUFBLFFBQU8sTUFDTixVQUFVLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsNENBQTRDLE1BQU0sVUFBVSxFQUFFLENBQUMsNkJBQXdCO0FBRS9IO1FBQ0Q7TUFDRDtBQUNBLFVBQUk7QUFBYTtJQUNsQjtBQUdBLFFBQUksQ0FBQyxRQUFRO0FBQ1osZUFBUztRQUNSO1FBQ0E7UUFDQSxNQUFNLGVBQWUsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsRUFBRSxZQUFXLENBQUU7UUFDaEUsU0FBUyxDQUFDLG1CQUFtQixVQUFVLENBQUM7O0FBRXpDLFVBQUksVUFBVTtBQUFXLGVBQU8sUUFBUTtBQUN4QyxNQUFBQSxRQUFPLEtBQUssMEJBQTBCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsRUFBRTtJQUN0RSxPQUFPO0FBSU4sYUFBTyxVQUFVLE9BQU8sU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxLQUFLLENBQUE7QUFDcEUsYUFBTyxPQUFPO0FBRWQsWUFBTSxrQkFBa0IsVUFBVSxJQUFJLEdBQUcsTUFBTSxJQUFJLEVBQUUsRUFBRTtBQUN2RCxVQUFJLG1CQUFtQixnQkFBZ0IsT0FBTyxHQUFHO0FBQ2hELGNBQU0sV0FBVyxLQUFLLElBQUksR0FBRyxlQUFlO0FBQzVDLFlBQUksYUFBYSxHQUFHO0FBRW5CLGlCQUFPLFFBQVE7UUFDaEIsT0FBTztBQUVOLGdCQUFNLGVBQWUsTUFBTSxLQUFLLEVBQUUsUUFBUSxXQUFXLEVBQUMsR0FBSSxDQUFDLEdBQUcsT0FBTztZQUNwRSxJQUFJO1lBQ0osT0FBTyxXQUFXLElBQUksQ0FBQztZQUN0QjtBQUNGLGlCQUFPLFFBQVEsUUFBUTtZQUN0QixJQUFJO1lBQ0osT0FBTztZQUNQLE1BQU07WUFDTixTQUFTO1lBQ1QsU0FBUztXQUNGO1FBQ1Q7TUFDRDtBQU1BLFlBQU0sa0JBQWtCLG1CQUFtQixVQUFVLEVBQUU7QUFDdkQsWUFBTSxXQUFXLE9BQU8sU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUM3RCxVQUFJLFVBQVU7QUFDYixZQUFJLFNBQVMsV0FBVyxNQUFNLFFBQVEsU0FBUyxPQUFPLEdBQUc7QUFDeEQsZ0JBQU0sWUFBWSxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLGVBQWU7QUFDNUUsY0FBSSxDQUFDLFdBQVc7QUFDZixZQUFBQSxRQUFPLEtBQ04sK0JBQStCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsaUNBQWlDLGVBQWUsc0NBQWlDO0FBRzlJLHFCQUFTLE9BQU87QUFDaEIsbUJBQVEsU0FBaUI7VUFDMUI7UUFDRDtBQUNBLGlCQUFTLFVBQVU7TUFDcEI7SUFDRDtBQUVBLFFBQUksVUFBVSxLQUFLLE1BQU07RUFDMUI7QUFTQSxhQUFXLEVBQUUsUUFBUSxHQUFFLEtBQU0sUUFBUTtBQUNwQyxVQUFNLGtCQUFrQixJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDcEYsUUFBSTtBQUFpQjtBQUdyQixVQUFNLFlBQVksSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFLO0FBQzFDLFVBQUksRUFBRSxXQUFXO0FBQVEsZUFBTztBQUNoQyxZQUFNQyxZQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUN4RCxhQUFPLENBQUMsQ0FBQ0EsV0FBVSxXQUFXLEtBQUssRUFBRTtJQUN0QyxDQUFDO0FBQ0QsUUFBSSxDQUFDO0FBQVc7QUFFaEIsVUFBTSxTQUFTLEtBQUssVUFBVTtBQUM5QixVQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFFBQUksQ0FBQyxVQUFVLFdBQVcsU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0FBQUc7QUFJOUUsVUFBTSxlQUFlLFdBQVcsS0FBSyxDQUFDLE1BQUs7QUFDMUMsWUFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsYUFBTyxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07SUFDN0QsQ0FBQztBQUNELFVBQU0sa0JBQWtCLFNBQVMsUUFBUSxJQUFJLENBQUMsTUFBVyxFQUFFLEVBQVksRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUM3RixVQUFNLGVBQWUsZ0JBQWdCLFNBQVMsS0FBSyxXQUFXLGdCQUFnQixnQkFBZ0IsU0FBUyxDQUFDLElBQUk7QUFFNUcsUUFBSSxDQUFDLGdCQUFnQixDQUFDO0FBQWM7QUFHcEMsUUFBSSxRQUFRLFdBQVcsU0FBUyxDQUFDO0FBQ2pDLGVBQVcsS0FBSyxZQUFZO0FBQzNCLFlBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLFVBQVUsRUFBRTtBQUN0RixZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFlBQU0sWUFBWSxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07QUFDdkUsVUFBSSxXQUFXO0FBQ2QsZ0JBQVEsVUFBVTtBQUNsQjtNQUNEO0lBQ0Q7QUFFQSxhQUFTLFFBQVEsS0FBSyxFQUFFLElBQUksUUFBUSxNQUFLLENBQUU7QUFDM0MsSUFBQUQsUUFBTyxLQUNOLHlCQUF5QixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLHVCQUF1QixNQUFNLFVBQVUsRUFBRSxDQUFDLGNBQWMsTUFBTSxNQUFNLEtBQUssSUFBSTtFQUVySTtBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsb0JBQW9CLFVBQWtCLFNBQW9CO0FBQ3pFLE1BQUk7QUFFSCxVQUFNLGFBQWtCLEVBQUUsT0FBTyxRQUFRLE1BQUs7QUFHOUMsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRO0lBQ2hDO0FBR0EsUUFBSSx5QkFBeUIsU0FBUztBQUNyQyxpQkFBVyxzQkFBc0IsUUFBUTtJQUMxQztBQUNBLFFBQUksZUFBZSxTQUFTO0FBQzNCLGlCQUFXLFlBQVksUUFBUSxVQUFVLElBQUksQ0FBQyxVQUFjO0FBRTNELGNBQU0sZUFBb0IsQ0FBQTtBQUMxQixZQUFJLFlBQVk7QUFBTyx1QkFBYSxTQUFTLE1BQU07QUFDbkQsWUFBSSxRQUFRO0FBQU8sdUJBQWEsS0FBSyxNQUFNO0FBQzNDLFlBQUksV0FBVztBQUFPLHVCQUFhLFFBQVEsTUFBTTtBQUNqRCxZQUFJLFVBQVU7QUFBTyx1QkFBYSxPQUFPLE1BQU07QUFDL0MsWUFBSSxhQUFhO0FBQU8sdUJBQWEsVUFBVSxNQUFNO0FBRXJELG1CQUFXLE9BQU8sT0FBTyxLQUFLLEtBQUssR0FBRztBQUNyQyxjQUFJLEVBQUUsT0FBTztBQUFlLHlCQUFhLEdBQUcsSUFBSSxNQUFNLEdBQUc7UUFDMUQ7QUFDQSxlQUFPO01BQ1IsQ0FBQztJQUNGO0FBRUEsZUFBVyxPQUFPLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDdkMsVUFBSSxFQUFFLE9BQU8sYUFBYTtBQUN6QixtQkFBVyxHQUFHLElBQUssUUFBZ0IsR0FBRztNQUN2QztJQUNEO0FBR0EsUUFBSSxPQUFPLEtBQUssVUFBVSxZQUFZLE1BQU0sQ0FBQztBQUs3QyxXQUFPLEtBQUssUUFBUSwwREFBMEQsNkJBQTZCO0FBRTNHLElBQUFFLElBQUcsY0FBYyxVQUFVLE9BQU8sTUFBTSxNQUFNO0VBQy9DLFNBQVMsR0FBRztBQUNYLElBQUFGLFFBQU8sTUFBTSxxQkFBcUIsQ0FBQyxFQUFFO0VBQ3RDO0FBQ0Q7OztBRHZ4QkEsSUFBTUcsVUFBUyxtQkFBbUIsU0FBUztBQUVyQyxTQUFVLGNBQWMsTUFBb0I7QUFDakQsUUFBTSxhQUFhLGlCQUFnQjtBQUNuQyxRQUFNLGFBQWEsYUFBWTtBQUMvQixRQUFNLFVBQVUscUJBQXFCLFVBQVU7QUFDL0MsUUFBTSxlQUFvQixDQUFBO0FBRTFCLFFBQU0sY0FBYyxLQUFLO0FBTXpCLGVBQWEsdUJBQXVCLElBQUk7SUFDdkMsTUFBTTtJQUNOLFNBQVMsQ0FBQTtJQUNULFVBQVUsWUFBVztBQUNwQixZQUFNLFFBQVE7QUFDZCxZQUFNLEtBQUssS0FBSztBQUVoQixZQUFNLE1BQU0sTUFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUU7QUFHekQsVUFBSSxZQUFZLGdCQUFnQixLQUFLO0FBR3JDLFlBQU0sRUFBRSxVQUFVLFFBQVEsa0JBQWlCLElBQUssaUNBQWlDLE9BQU8sR0FBRztBQUMzRixNQUFBQSxRQUFPLE1BQU0saUJBQWlCLEtBQUssVUFBVSxNQUFNLENBQUMsRUFBRTtBQUV0RCxVQUFJLENBQUMsV0FBVztBQUVmLFFBQUFBLFFBQU8sS0FBSyxTQUFTLEtBQUssdURBQWtEO0FBQzVFLG9CQUFZO1VBQ1g7VUFDQSxXQUFXLHFCQUFxQjtVQUNoQyxxQkFBcUI7VUFDckIsV0FBVyxDQUFBOztNQUViLFdBQVcsc0JBQXNCLE1BQU07QUFFdEMsUUFBQUEsUUFBTyxLQUFLLDJCQUEyQixpQkFBaUIsd0JBQXdCO0FBQ2hGLG9CQUFZLEVBQUUsR0FBRyxXQUFXLFdBQVcsa0JBQWlCO01BQ3pEO0FBRUEsWUFBTSxVQUFVLDRCQUE0QixXQUFXLFFBQVEsT0FBTztBQUN0RSxNQUFBQSxRQUFPLE1BQU0scUJBQXFCLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxDQUFDLEVBQUU7QUFHcEUsWUFBTUMsaUJBQWdCLGlCQUFnQjtBQUN0QyxZQUFNLGFBQWFDLE1BQUssS0FBS0QsZ0JBQWUsUUFBUSxLQUFLLE9BQU87QUFDaEUsMEJBQW9CLFlBQVksT0FBTztBQUd2QywwQkFBbUI7QUFFbkIsTUFBQUQsUUFBTyxLQUFLLFNBQVMsS0FBSyx3Q0FBd0M7SUFDbkU7O0FBT0QsYUFBVyxDQUFDLFVBQVUsTUFBTSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDNUQsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxRQUFRO0FBR3hELFFBQUksVUFBVTtBQUFhO0FBRzNCLFVBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsVUFBTSxZQUFZLFFBQVEsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sTUFBTTtBQUUzRixpQkFBYSxRQUFRLElBQUk7TUFDeEIsR0FBRztNQUNILFVBQVUsT0FBTyxVQUFjO0FBQzlCLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBQ3pGLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTztBQUNuQyxjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxjQUFNLFlBQVksU0FBUztBQUUzQixjQUFNLEtBQUssYUFBYSxhQUFhLE9BQU8sT0FBTyxXQUFXLE9BQU8sRUFBRTtNQUN4RTs7RUFFRjtBQUtBLFFBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsTUFBSSxjQUFjO0FBQ2pCLFVBQU0sbUJBQW1CLGFBQWEsYUFBYSxDQUFBLEdBQUksS0FBSyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBRS9GLFFBQUksaUJBQWlCO0FBQ3BCLFlBQU0sV0FBVyxHQUFHLFdBQVc7QUFFL0IsbUJBQWEsUUFBUSxJQUFJO1FBQ3hCLE1BQU0sU0FBUyxXQUFXO1FBQzFCLFNBQVMsQ0FBQTtRQUNULFVBQVUsWUFBVztBQUNwQixnQkFBTSxLQUFLLEtBQUs7QUFDaEIsVUFBQUEsUUFBTyxLQUFLLHlCQUFvQixXQUFXLE1BQU0sRUFBRSxFQUFFO0FBQ3JELGdCQUFNLEtBQUssYUFBYSxjQUFjLEVBQUU7QUFDeEMsZ0JBQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDNUQsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGOztJQUVGO0VBQ0Q7QUFFQSxPQUFLLHFCQUFxQixZQUFZO0FBR3ZDOzs7QUVySEEsU0FBUyxpQkFDUixTQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQWE7QUFFYixRQUFNLFVBQVUscUJBQXFCLFNBQVMsT0FBTyxPQUFPLFNBQVM7QUFDckUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLFFBQVEsUUFBUSxPQUFPO0FBQUcsV0FBTztBQUd4RCxRQUFNLGNBQWMsUUFBUSxRQUFRLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3pFLE1BQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxRQUFRLFlBQVksT0FBTztBQUFHLFdBQU87QUFHaEUsUUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sS0FBSztBQUNsRSxTQUFPLFFBQVEsU0FBUztBQUN6QjtBQU1NLFNBQVUsZ0JBQWdCLE1BQW9CO0FBQ25ELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxlQUFlLGVBQWM7QUFDbkMsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0saUJBQXNCLENBQUE7QUFHNUIsUUFBTSxjQUFjLEtBQUs7QUFNekIsYUFBVyxDQUFDLFlBQVksUUFBUSxLQUFLLE9BQU8sUUFBUSxZQUFZLEdBQUc7QUFDbEUsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxVQUFVO0FBRzFELFFBQUksVUFBVTtBQUFhO0FBRzNCLG1CQUFlLFVBQVUsSUFBSTtNQUM1QixHQUFHO01BQ0gsVUFBVSxDQUFDLGtCQUFzQjtBQUNoQyxjQUFNLEtBQUssS0FBSztBQUNoQixjQUFNLFFBQVEsY0FBYyxRQUFRLE9BQU8sS0FBSztBQUNoRCxjQUFNLFlBQVksU0FBUztBQUczQixZQUFJLFFBQVEsY0FBYyxRQUFRLE9BQU87QUFDekMsWUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQU0sZUFBZSxxQkFBcUIsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUMxRSxjQUFJLGNBQWMsVUFBVSxRQUFXO0FBQ3RDLG9CQUFRLGFBQWE7VUFDdEI7UUFDRDtBQUVBLGNBQU0sVUFBVSxLQUFLLGFBQWEsZ0JBQWdCLElBQUksT0FBTyxXQUFXLEtBQUs7QUFHN0UsY0FBTSxZQUFZLGNBQWMsUUFBUSxXQUFXLEtBQUs7QUFFeEQsWUFBSSxhQUFhLFlBQVksUUFBVztBQUV2QyxpQkFBTyxpQkFBaUIsU0FBUyxPQUFPLE9BQU8sV0FBVyxPQUFPO1FBQ2xFO0FBR0EsZUFBTyxXQUFXO01BQ25COztFQUVGO0FBRUEsT0FBSyx1QkFBdUIsY0FBYztBQUczQzs7O0FDdEZBLE9BQU9HLFlBQVc7OztBQ0FsQixPQUFPLFdBQVc7QUFDbEIsT0FBTyxRQUFRO0FBSWYsSUFBTUMsVUFBUyxtQkFBbUIsT0FBTztBQUtsQyxJQUFNLHlCQUF5QjtBQUUvQixJQUFNLDBCQUEwQjtBQWdCaEMsSUFBTSxxQkFBcUIsTUFBTztBQWlCbkMsU0FBVSx3QkFBcUI7QUFDcEMsUUFBTSxNQUFNLE9BQU8sTUFBTSxJQUFJLENBQUM7QUFDOUIsUUFBTSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU0sSUFBSyxLQUFNO0FBRTdDLE1BQUksY0FBYyxPQUFRLENBQUM7QUFDM0IsTUFBSSxjQUFjLHdCQUF3QixDQUFDO0FBQzNDLE1BQUksY0FBYyxLQUFLLENBQUM7QUFFeEIsUUFBTSxNQUFNLGlCQUFnQjtBQUM1QixNQUFJLEtBQUssS0FBSyxDQUFDO0FBRWYsU0FBTyxLQUFLLFlBQVksT0FBTyxFQUFFLEtBQUssS0FBSyxFQUFFO0FBQzdDLE1BQUksY0FBYyxNQUFRLEVBQUU7QUFDNUIsTUFBSSxjQUFjLEtBQVEsRUFBRTtBQUM1QixNQUFJLGNBQWMsS0FBWSxFQUFFO0FBRWhDLFNBQU87QUFDUjtBQUdNLFNBQVUsbUJBQWdCO0FBQy9CLE1BQUk7QUFDSCxVQUFNLFNBQVMsR0FBRyxrQkFBaUI7QUFDbkMsZUFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMsaUJBQVcsUUFBUSxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdEMsWUFBSSxDQUFDLEtBQUssWUFBWSxLQUFLLFdBQVcsVUFBVSxLQUFLLE9BQU8sS0FBSyxRQUFRLHFCQUFxQjtBQUM3RixpQkFBTyxPQUFPLEtBQUssS0FBSyxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFjLFNBQVMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUMzRTtNQUNEO0lBQ0Q7RUFDRCxRQUFRO0VBRVI7QUFDQSxTQUFPLE9BQU8sTUFBTSxHQUFHLENBQUM7QUFDekI7QUFpQk0sU0FBVSx1QkFBdUIsS0FBYSxPQUFhO0FBQ2hFLE1BQUksSUFBSSxTQUFTO0FBQW9CLFdBQU87QUFDNUMsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVEsV0FBTztBQUMzQyxNQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBeUIsV0FBTztBQUM1RCxNQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZLFdBQU87QUFFbEUsUUFBTSxVQUFVLENBQUMsUUFBZ0IsUUFDaEMsSUFDRSxTQUFTLFFBQVEsU0FBUyxHQUFHLEVBQzdCLFNBQVMsT0FBTyxFQUNoQixNQUFNLElBQUksRUFBRSxDQUFDLEVBQ2IsS0FBSTtBQUVQLFFBQU0sUUFBUSxJQUFJLFNBQVMsR0FBRyxFQUFFO0FBQ2hDLFFBQU0sV0FBVyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQzVFLFFBQU0sTUFBTSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUV6RSxRQUFNLE9BQU8sUUFBUSxJQUFNLEVBQUU7QUFDN0IsUUFBTSxlQUFlLFFBQVEsSUFBTSxFQUFFO0FBQ3JDLFFBQU0sV0FBVyxRQUFRLEtBQU0sRUFBRTtBQUNqQyxRQUFNLGdCQUFnQixHQUFHLElBQUksRUFBSSxDQUFDLElBQUksSUFBSSxFQUFJLENBQUM7QUFFL0MsTUFBSSxDQUFDO0FBQVUsV0FBTztBQUl0QixRQUFNLFFBQVEsU0FDWixRQUFRLGNBQWMsRUFBRSxFQUN4QixLQUFJLEVBQ0osTUFBTSxLQUFLLEVBQUUsQ0FBQztBQUVoQixTQUFPO0lBQ04sSUFBSTtJQUNKO0lBQ0E7SUFDQTtJQUNBLFdBQVc7O0lBQ1g7SUFDQTs7QUFFRjtBQU9BLGVBQXNCLHFCQUFxQixRQUFjO0FBQ3hELFNBQU8sSUFBSSxRQUFrQixDQUFDLFNBQVMsV0FBVTtBQUNoRCxVQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFFckMsUUFBSSxLQUFLLFNBQVMsQ0FBQyxRQUFPO0FBQ3pCLFVBQUksTUFBSztBQUNULGFBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQzdDLENBQUM7QUFFRCxRQUFJLFFBQVEsR0FBRyxRQUFRLE1BQUs7QUFDM0IsVUFBSTtBQUNILGNBQU0sT0FBTyxJQUFJLFFBQU87QUFDeEIsY0FBTSxZQUFZLEtBQUs7QUFDdkIsWUFBSSxNQUFLO0FBRVQsY0FBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLG1CQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxxQkFBVyxTQUFTLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN2QyxnQkFDQyxNQUFNLFdBQVcsVUFDakIsTUFBTSxZQUFZLGFBQ2xCLE1BQU0sT0FDTixNQUFNLFFBQVEscUJBQ2I7QUFDRCxxQkFBTyxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxTQUFTLEdBQUcsRUFBRSxJQUFJLEdBQUksQ0FBQztZQUN2RTtVQUNEO1FBQ0Q7QUFDQSxlQUFPLElBQUksTUFBTSx3Q0FBd0MsU0FBUyxFQUFFLENBQUM7TUFDdEUsU0FBUyxJQUFJO0FBQ1osZUFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztNQUM3QjtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7QUFNQSxlQUFzQiw4QkFBOEIsUUFBYztBQUNqRSxTQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksV0FBVztBQUNmLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLENBQUMsVUFBVTtBQUNkLG1CQUFXO0FBQ1gsWUFBSSxNQUFLO0FBQ1QsZUFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDN0M7SUFDRCxDQUFDO0FBR0QsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxrQkFBUSxTQUFTO1FBQ2xCO01BQ0QsU0FBUyxJQUFJO0FBQ1osWUFBSSxDQUFDLFVBQVU7QUFDZCxxQkFBVztBQUNYLGNBQUksTUFBSztBQUNULGlCQUFPLElBQUksTUFBTSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQzdCO01BQ0Q7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBV0EsZUFBc0IsZ0JBQ3JCLFVBQ0Esa0JBQ0EsWUFBWSxLQUFJO0FBRWhCLFFBQU0sdUJBQXVCO0FBQzdCLFFBQU0sc0JBQXNCO0FBQzVCLFFBQU0sZUFBZTtBQUVyQixRQUFNLGFBQWEsb0JBQUksSUFBRztBQUUxQixTQUFPLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDcEMsVUFBTSxpQkFBaUIsTUFBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBRTNFLFVBQU0sVUFBVSxNQUFLO0FBQ3BCLFVBQUk7QUFDSCx1QkFBZSxlQUFlLG9CQUFvQjtNQUNuRCxRQUFRO01BRVI7QUFDQSxVQUFJO0FBQ0gsdUJBQWUsTUFBSztNQUNyQixRQUFRO01BRVI7QUFDQSxjQUFPO0lBQ1I7QUFFQSxVQUFNLFFBQVEsV0FBVyxTQUFTLFNBQVM7QUFDM0MsVUFBTSxRQUFPO0FBRWIsbUJBQWUsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNsQyxNQUFBQSxRQUFPLEtBQUssMEJBQTBCLElBQUksT0FBTyxFQUFFO0lBQ3BELENBQUM7QUFFRCxtQkFBZSxHQUFHLFdBQVcsQ0FBQyxLQUFLLFVBQVM7QUFDM0MsWUFBTSxRQUFRLE1BQU07QUFFcEIsVUFBSSxJQUFJLFNBQVM7QUFBSTtBQUNyQixVQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBUTtBQUNwQyxVQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBRTNELFVBQUksV0FBVyxJQUFJLEtBQUs7QUFBRztBQUMzQixpQkFBVyxJQUFJLEtBQUs7QUFDcEIsTUFBQUEsUUFBTyxNQUFNLGlCQUFpQixLQUFLLCtCQUEwQjtBQUs3RCxZQUFNLFlBQVksWUFBVztBQUM1QixjQUFNLGlCQUFpQixLQUFLO0FBQzVCLGNBQU0sUUFBUSxzQkFBcUI7QUFDbkMsaUJBQVMsS0FBSyxPQUFPLGNBQWMsT0FBTyxDQUFDLFFBQU87QUFDakQsY0FBSTtBQUFLLFlBQUFBLFFBQU8sS0FBSyxvQkFBb0IsS0FBSyxZQUFZLElBQUksT0FBTyxFQUFFO1FBQ3hFLENBQUM7TUFDRjtBQUNBLGdCQUFTLEVBQUcsTUFBTSxDQUFDLFFBQVFBLFFBQU8sS0FBSyx1QkFBdUIsR0FBRyxFQUFFLENBQUM7SUFDckUsQ0FBQztBQUVELG1CQUFlLEtBQUsscUJBQXFCLE1BQUs7QUFDN0MsVUFBSTtBQUNILHVCQUFlLGNBQWMsb0JBQW9CO0FBQ2pELFFBQUFBLFFBQU8sS0FBSyxvQ0FBb0Msb0JBQW9CLElBQUksbUJBQW1CLEVBQUU7TUFDOUYsU0FBUyxLQUFLO0FBQ2IsUUFBQUEsUUFBTyxLQUFLLDRDQUE0QyxHQUFHLEVBQUU7TUFDOUQ7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGOzs7QURuUUEsSUFBTUMsVUFBUyxtQkFBbUIsY0FBYztBQUUxQyxJQUFPLGVBQVAsTUFBTyxjQUFZO0VBQ1AsY0FBc0I7RUFDdEIsaUJBQWlCO0VBQ2pCLFNBQVM7RUFFbEI7RUFDQTs7RUFDQSxjQUdKLG9CQUFJLElBQUc7RUFDSCxtQkFBZ0Msb0JBQUksSUFBRzs7O0VBR3ZDLFlBQTJCLFFBQVEsUUFBTzs7RUFHMUMsc0JBQXNCOztFQUd0Qjs7RUFHQSxRQUFnQjtFQUNoQixVQUFzQixDQUFBO0VBQ3RCLHNCQUErQjs7Ozs7Ozs7RUFRL0IsY0FBZ0Qsb0JBQUksSUFBRzs7Ozs7OztFQVF2RCxnQkFBNkIsb0JBQUksSUFBRzs7RUFHcEMscUJBQWdFLG9CQUFJLElBQUc7O0VBR3ZFOztFQUdBLFdBQWtDLG9CQUFJLElBQUc7RUFFakQsY0FBQTtBQUNDLElBQUFBLFFBQU8sS0FBSywwQkFBMEI7QUFJdEMsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDcEUsU0FBSyxVQUFVLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDNUMsV0FBSyxTQUFTLEtBQUssR0FBRyxNQUFLO0FBQzFCLFFBQUFELFFBQU8sTUFBTSwyQkFBNEIsS0FBSyxTQUFTLFFBQU8sRUFBd0IsSUFBSSxFQUFFO0FBQzVGLGdCQUFPO01BQ1IsQ0FBQztJQUNGLENBQUM7QUFDRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBR0QsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFcEUsU0FBSyxTQUFTLEdBQUcsYUFBYSxNQUFLO0FBQ2xDLFlBQU0sT0FBTyxLQUFLLFNBQVMsUUFBTztBQUNsQyxNQUFBRCxRQUFPLE1BQU0sMEJBQTBCLEtBQUssVUFBVSxJQUFJLENBQUMsRUFBRTtBQUM3RCxVQUFJO0FBQ0gsYUFBSyxTQUFTLHFCQUFxQixJQUFJO01BQ3hDLFNBQVMsSUFBSTtNQUViO0lBQ0QsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzFDLFVBQUk7QUFDSCxhQUFLLGVBQWUsS0FBSyxNQUFNLE9BQU87TUFDdkMsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxFQUFFLEVBQUU7TUFDdEQ7SUFDRCxDQUFDO0FBR0QsU0FBSyxTQUFTLEtBQUssRUFBRSxTQUFTLFdBQVcsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2xFLE1BQUFBLFFBQU8sTUFBTSw4QkFBOEIsS0FBSyxNQUFNLEVBQUU7SUFDekQsQ0FBQztFQUNGO0VBRU8sUUFBSztBQUNYLFFBQUk7QUFDSCxpQkFBVyxhQUFhLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixHQUFHO0FBQzFELFlBQUk7QUFDSCxlQUFLLFNBQVMsZUFBZSxLQUFLLGdCQUFnQixTQUFTO1FBQzVELFFBQVE7UUFFUjtNQUNEO0lBQ0QsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7RUFDRDs7Ozs7RUFNTyxTQUFTLE9BQWUsU0FBcUIsc0JBQStCLE1BQUk7QUFDdEYsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVO0FBQ2YsU0FBSyxzQkFBc0I7RUFDNUI7Ozs7O0VBTU8sb0JBQW9CLFVBQXNDO0FBQ2hFLFNBQUssbUJBQW1CO0VBQ3pCOztFQUdPLG1CQUFtQixJQUFVO0FBQ25DLFdBQU8sS0FBSyxjQUFjLElBQUksRUFBRTtFQUNqQzs7RUFHTyxnQkFBZ0IsSUFBVTtBQUNoQyxTQUFLLGNBQWMsSUFBSSxFQUFFO0FBQ3pCLElBQUFBLFFBQU8sTUFBTSx3QkFBd0IsRUFBRSxFQUFFO0VBQzFDOztFQUdPLGFBQWEsSUFBVTtBQUM3QixTQUFLLGNBQWMsT0FBTyxFQUFFO0FBQzVCLFNBQUssWUFBWSxPQUFPLEVBQUU7QUFDMUIsU0FBSyxTQUFTLE9BQU8sRUFBRTtBQUN2QixJQUFBQSxRQUFPLE1BQU0scUJBQXFCLEVBQUUsRUFBRTtFQUN2Qzs7Ozs7OztFQVFPLE1BQU0sWUFBWSxJQUFZLFlBQVksS0FBSTtBQUNwRCxXQUFPLElBQUksUUFBMkIsQ0FBQyxZQUFXO0FBQ2pELFlBQU0sTUFBTSxXQUFXLEVBQUU7QUFDekIsVUFBSSxXQUFXO0FBRWYsWUFBTSxTQUFTLENBQUMsV0FBNkI7QUFDNUMsWUFBSTtBQUFVO0FBQ2QsbUJBQVc7QUFDWCxhQUFLLG1CQUFtQixPQUFPLEdBQUc7QUFDbEMsZ0JBQVEsTUFBTTtNQUNmO0FBRUEsV0FBSyxtQkFBbUIsSUFBSSxLQUFLLENBQUMsV0FBc0I7QUFDdkQsWUFBSSxPQUFPLE9BQU87QUFBSSxpQkFBTyxNQUFNO01BQ3BDLENBQUM7QUFFRCxZQUFNLFFBQVEsV0FBVyxNQUFNLE9BQU8sSUFBSSxHQUFHLFNBQVM7QUFDdEQsWUFBTSxRQUFPO0FBRWIsWUFBTSxNQUFNLFlBQVc7QUFDdEIsY0FBTSxLQUFLLG9CQUFvQixFQUFFO0FBQ2pDLGNBQU0sS0FBSztBQUNYLGNBQU0sUUFBUSxzQkFBcUI7QUFDbkMsYUFBSyxTQUFTLEtBQUssT0FBTyxLQUFLLGFBQWEsSUFBSSxDQUFDLFFBQU87QUFDdkQsY0FBSSxLQUFLO0FBQ1IsWUFBQUEsUUFBTyxLQUFLLFlBQVksRUFBRSxZQUFZLElBQUksT0FBTyxFQUFFO0FBQ25ELHlCQUFhLEtBQUs7QUFDbEIsbUJBQU8sSUFBSTtVQUNaO1FBQ0QsQ0FBQztNQUNGO0FBRUEsVUFBRyxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQ2pCLFFBQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsRUFBRTtBQUN0RCxxQkFBYSxLQUFLO0FBQ2xCLGVBQU8sSUFBSTtNQUNaLENBQUM7SUFDRixDQUFDO0VBQ0Y7Ozs7O0VBTU8sTUFBTSxtQkFBbUIsVUFBZ0I7QUFDL0MsSUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxRQUFRLEVBQUU7QUFDdEQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLHNCQUFzQixRQUFXLFFBQVcsUUFBVyxVQUFVLEtBQUs7QUFFL0csV0FBTztFQUNSOzs7Ozs7Ozs7OztFQVlPLE1BQU0sZ0JBQWdCLFlBQVksS0FBSTtBQUU1QyxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLGVBQTZCLENBQUE7QUFFbkMsVUFBTSxnQkFBZ0IsQ0FBQyxXQUFzQjtBQUM1QyxVQUFJLENBQUMsYUFBYSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxFQUFFLEdBQUc7QUFDbEQscUJBQWEsS0FBSyxNQUFNO01BQ3pCO0lBQ0Q7QUFHQSxTQUFLLG1CQUFtQixJQUFJLGVBQWUsYUFBYTtBQUV4RCxRQUFJO0FBQ0gsWUFBTSxLQUFLO0FBR1gsWUFBTSxnQkFBZ0IsS0FBSyxVQUFVLE9BQU8sV0FBVyxLQUFLLG9CQUFvQixNQUFNLEdBQUcsU0FBUztBQUNsRyxhQUFPO0lBQ1I7QUFDQyxXQUFLLG1CQUFtQixPQUFPLGFBQWE7SUFDN0M7RUFDRDs7Ozs7RUFNTyxNQUFNLHVCQUF1QixVQUFnQjtBQUNuRCxJQUFBQSxRQUFPLEtBQUssb0NBQW9DLFFBQVEsRUFBRTtBQUMxRCxVQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsa0JBQWtCLFFBQVcsUUFBVyxRQUFXLFVBQVUsS0FBSztBQUkzRyxVQUFNLFlBQVk7QUFFbEIsUUFBSSxTQUFTLFNBQVMsWUFBWSxHQUFHO0FBQ3BDLE1BQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsU0FBUyxNQUFNLFFBQVE7QUFDbkUsYUFBTztJQUNSO0FBR0EsVUFBTSxRQUFRLFNBQVMsWUFBWSxDQUFDO0FBQ3BDLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUVwQyxVQUFNLFdBQ0wsUUFBUSxLQUNMLE1BQU0sU0FBUSxFQUFHLFNBQVMsR0FBRyxHQUFHLElBQ2hDLE1BQU0sU0FBUTtBQUVsQixVQUFNLFdBQVcsR0FBRyxLQUFLLElBQUksUUFBUTtBQUVyQyxJQUFBQSxRQUFPLEtBQUsscUJBQXFCLFFBQVEsRUFBRTtBQUMzQyxXQUFPO0VBQ1I7Ozs7O0VBTVEsTUFBTSxvQkFBb0IsUUFBYztBQUMvQyxRQUFJO0FBQ0gsWUFBTSxZQUFZLE1BQU0sOEJBQThCLE1BQU07QUFDNUQsVUFBSSxDQUFDLFdBQVc7QUFDZixRQUFBQSxRQUFPLEtBQUsscURBQXFELE1BQU0sRUFBRTtBQUN6RTtNQUNEO0FBRUEsVUFBSSxLQUFLLGlCQUFpQixJQUFJLFNBQVMsR0FBRztBQUV6QztNQUNEO0FBRUEsVUFBSTtBQUNILGFBQUssU0FBUyxjQUFjLEtBQUssZ0JBQWdCLFNBQVM7QUFDMUQsYUFBSyxpQkFBaUIsSUFBSSxTQUFTO0FBQ25DLFFBQUFBLFFBQU8sS0FBSyxvQkFBb0IsS0FBSyxjQUFjLE9BQU8sU0FBUyxFQUFFO01BQ3RFLFNBQVMsSUFBSTtBQUNaLFFBQUFBLFFBQU8sS0FBSywrQkFBK0IsU0FBUyxLQUFLLE9BQU8sRUFBRSxDQUFDLEVBQUU7TUFDdEU7SUFDRCxTQUFTLElBQUk7QUFDWixNQUFBQSxRQUFPLEtBQUssK0JBQStCLEVBQUUsRUFBRTtJQUNoRDtFQUNEO0VBRU8sTUFBTSxhQUNaLE9BQ0EsT0FDQSxXQUNBLE9BQ0EsUUFDQSxTQUFTLE1BQUk7QUFFYixTQUFLO0FBQ0wsV0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFdBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxZQUNwQyxLQUFLLGNBQWMsT0FBTyxPQUFPLFdBQVcsT0FBTyxRQUFRLE1BQU0sRUFDL0QsS0FBSyxDQUFDLFFBQU87QUFDYixhQUFLO0FBR0wsWUFBSSxLQUFLLHdCQUF3QixLQUFLLEtBQUssdUJBQXVCLFVBQVUsUUFBVztBQUN0RixlQUFLLG1CQUFtQixNQUFNLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDN0MsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGO0FBQ0EsZ0JBQVEsR0FBRztNQUNaLENBQUMsRUFDQSxNQUFNLENBQUMsUUFBTztBQUNkLGFBQUs7QUFDTCxlQUFPLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzNELENBQUMsQ0FBQztJQUVMLENBQUM7RUFDRjtFQUVRLE1BQU0sY0FDYixPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUFJO0FBRWIsVUFBTSxZQUFZO0FBRWxCLFVBQU0sWUFBc0IsQ0FBQTtBQUM1QixRQUFJLGNBQWM7QUFBVyxnQkFBVSxLQUFLLFlBQVksR0FBSTtBQUM1RCxRQUFJLFVBQVU7QUFBVyxnQkFBVSxLQUFLLEdBQUcsY0FBYSxnQkFBZ0IsS0FBSyxDQUFDO0FBRTlFLFVBQU0sY0FBd0IsQ0FBQyxJQUFNLFFBQVEsR0FBSTtBQUVqRCxRQUFJLFVBQVUsZUFBZSxVQUFVLFVBQWEsY0FBYyxVQUFhLFVBQVUsUUFBVztBQUluRyxVQUFJLENBQUMsS0FBSyxZQUFZLElBQUksTUFBTTtBQUFHLGFBQUssWUFBWSxJQUFJLFFBQVEsb0JBQUksSUFBRyxDQUFFO0FBQ3pFLFlBQU0sVUFBVSxLQUFLLFlBQVksSUFBSSxNQUFNO0FBQzNDLFlBQU0sZUFBZTtBQUNyQixZQUFNLFlBQXNCLENBQUE7QUFDNUIsZUFBUyxJQUFJLEdBQUcsSUFBSSxjQUFjLEtBQUs7QUFDdEMsY0FBTSxXQUFXLGNBQWMsS0FBSyxPQUFPLGFBQWEsR0FBRyxLQUFLO0FBQ2hFLGNBQU0sTUFBTSxNQUFNLFlBQVksT0FBTyxLQUFLLElBQUssUUFBUSxJQUFJLFFBQVEsS0FBSztBQUN4RSxrQkFBVSxLQUFLLEdBQUc7QUFDbEIsZ0JBQVEsSUFBSSxVQUFVLEdBQUc7TUFDMUI7QUFDQSxrQkFBWSxLQUFLLFFBQVEsS0FBTSxHQUFHLFNBQVM7SUFDNUMsT0FBTztBQUNOLFVBQUksVUFBVTtBQUFXLG9CQUFZLEtBQUssUUFBUSxHQUFJO0FBQ3RELFVBQUk7QUFBUSxvQkFBWSxLQUFLLFVBQVUsTUFBTTtBQUM3QyxVQUFJLFVBQVUsU0FBUztBQUFHLG9CQUFZLEtBQUssR0FBRyxTQUFTO0lBQ3hEO0FBRUEsVUFBTSxNQUFNLGNBQWEsVUFBVSxXQUFXO0FBQzlDLFVBQU0saUJBQWlCLE9BQU8sS0FBSyxDQUFDLEdBQUcsYUFBYSxHQUFHLENBQUM7QUFHeEQsUUFBSSxjQUFjLFVBQWEsVUFBVSxRQUFXO0FBQ25ELFlBQU0sYUFBYSxjQUFhLGdCQUFnQixLQUFLO0FBQ3JELFlBQU0sVUFBeUI7UUFDOUIsUUFBUTtRQUNSLElBQUk7UUFDSjtRQUNBOztBQUVELE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxvQkFBb0IsU0FBUyxLQUFLLE9BQU8sQ0FBQyxFQUFFO0lBQzNFLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sZUFBZSxLQUFLLENBQUMsRUFBRTtJQUN0RDtBQUlBLFFBQUksQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEdBQUc7QUFDcEMsTUFBQUEsUUFBTyxNQUFNLHFEQUFnRCxNQUFNLEtBQUssZUFBZSxTQUFTLEtBQUssQ0FBQyxFQUFFO0FBQ3hHLFlBQU0sSUFBSSxNQUFNLGFBQWEsTUFBTSxpRkFBNEU7SUFDaEg7QUFHQSxVQUFNLEtBQUssb0JBQW9CLE1BQU07QUFFckMsVUFBTSxXQUFXLEtBQUssZUFBZTtBQUNyQyxVQUFNLFNBQVMsTUFBTSxLQUFLLFlBQVksVUFBVSxNQUFNO0FBQ3RELFVBQU0sU0FBUyxPQUFPLE9BQU8sQ0FBQyxRQUFRLGNBQWMsQ0FBQztBQUVyRCxJQUFBQSxRQUFPLE1BQU0scUJBQXFCLE1BQU0sS0FBSyxPQUFPLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFFckUsVUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLEtBQUs7QUFFOUIsV0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFlBQU0sUUFBUSxXQUFXLE1BQUs7QUFDN0IsYUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQixlQUFPLElBQUksTUFBTSxzQ0FBc0MsS0FBSyxLQUFLLE9BQU8sTUFBTSxPQUFPLENBQUM7TUFDdkYsR0FBRyxTQUFTO0FBRVosV0FBSyxZQUFZLElBQUksS0FBSztRQUN6QixTQUFTLENBQUMsUUFBTztBQUNoQix1QkFBYSxLQUFLO0FBQ2xCLGtCQUFRLEdBQUc7UUFDWjtRQUNBLFFBQVEsQ0FBQyxRQUFPO0FBQ2YsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxHQUFHO1FBQ1g7UUFDQTtPQUNBO0FBRUQsV0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLGFBQWEsUUFBUSxDQUFDLFFBQU87QUFDNUQsWUFBSSxLQUFLO0FBQ1IsZUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUM3QztNQUNELENBQUM7SUFDRixDQUFDO0VBQ0Y7RUFFUSxlQUFlLEtBQWEsT0FBYTtBQUNoRCxRQUFJLElBQUksU0FBUztBQUFHO0FBQ3BCLFFBQUksSUFBSSxDQUFDLE1BQU0sT0FBUSxJQUFJLENBQUMsTUFBTTtBQUFNO0FBRXhDLFVBQU0sVUFBVSxJQUFJLGFBQWEsQ0FBQztBQUtsQyxRQUFJLFlBQVksMkJBQTJCLEtBQUssbUJBQW1CLE9BQU8sR0FBRztBQUM1RSxZQUFNLFNBQVMsdUJBQXVCLEtBQUssS0FBSztBQUNoRCxVQUFJLFFBQVE7QUFDWCxRQUFBQSxRQUFPLE1BQ04sNEJBQTRCLEtBQUssZUFDbkIsT0FBTyxJQUFJLGFBQ2QsT0FBTyxLQUFLLGlCQUNSLE9BQU8sU0FBUyxvQkFDYixPQUFPLFlBQVksR0FBRztBQUl6QyxZQUFJLE9BQU8sU0FBUyxZQUFZO0FBQy9CLHFCQUFXLE1BQU0sS0FBSyxtQkFBbUIsT0FBTSxHQUFJO0FBQ2xELGdCQUFJO0FBQ0gsaUJBQUcsTUFBTTtZQUNWLFFBQVE7WUFFUjtVQUNEO1FBQ0QsT0FBTztBQUNOLFVBQUFBLFFBQU8sTUFBTSxzREFBc0QsT0FBTyxJQUFJLE9BQU8sS0FBSyxFQUFFO1FBQzdGO01BQ0Q7QUFDQTtJQUNEO0FBRUEsUUFBSSxJQUFJLFNBQVM7QUFBSTtBQUdyQixVQUFNLE1BQU0sSUFBSSxTQUFTLElBQUksRUFBRTtBQUMvQixRQUFJLElBQUksU0FBUyxPQUFPLE1BQU07QUFBWTtBQUkxQyxVQUFNLFlBQVksSUFBSSxTQUFTLEVBQUU7QUFDakMsUUFBSSxVQUFVLFNBQVM7QUFBRztBQUMxQixRQUFJLFVBQVUsQ0FBQyxNQUFNO0FBQU07QUFHM0IsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLGNBQWMsWUFBWSxTQUFVO0FBQzFDLFVBQU0sZ0JBQWdCLFlBQVk7QUFHbEMsUUFBSSxjQUFjLGtCQUFrQixzQkFBc0I7QUFDekQsTUFBQUEsUUFBTyxNQUFNLHdCQUF3QixLQUFLLEtBQUssSUFBSSxTQUFTLEtBQUssQ0FBQyxFQUFFO0lBQ3JFO0FBR0EsU0FBSyxhQUFhLE9BQU8sZUFBZSxLQUFLLFNBQVM7QUFHdEQsUUFBSSxZQUFZO0FBQ2YsWUFBTSxNQUFNLEdBQUcsS0FBSyxJQUFJLGFBQWE7QUFDckMsWUFBTSxVQUFVLEtBQUssWUFBWSxJQUFJLEdBQUc7QUFDeEMsVUFBSSxTQUFTO0FBQ1osYUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQixnQkFBUSxRQUFRLEdBQUc7TUFDcEI7SUFDRDtFQUVEOzs7Ozs7Ozs7Ozs7RUFhUSxhQUFhLE9BQWUsT0FBZSxLQUFhLFdBQWlCO0FBQ2hGLFVBQU0sVUFBVSxlQUFlLEtBQUs7QUFDcEMsVUFBTSxPQUFPLFVBQVUsU0FBUyxHQUFHLFVBQVUsU0FBUyxDQUFDO0FBR3ZELFVBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsVUFBTSxNQUFNLFVBQVUsVUFBVSxTQUFTLENBQUM7QUFDMUMsVUFBTSxnQkFBZ0IsUUFBUSxNQUFNLFNBQVMsQ0FBQyxTQUFTLEtBQUssU0FBUyxLQUFLLENBQUMsUUFBUSxNQUFNLEdBQUcsQ0FBQztBQUs3RixRQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQUksQ0FBQyxLQUFLLE9BQU87QUFDaEIsUUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7QUFDekQ7TUFDRDtBQUNBLFVBQUk7QUFDSCxjQUFNLFdBQ0wsVUFBVSxvQkFDUCxzQkFBc0IsS0FBSyxPQUFPLEdBQUcsSUFDckMsNEJBQTRCLEtBQUssT0FBTyxHQUFHO0FBRS9DLGNBQU0sWUFBWSxLQUFLLFlBQVksSUFBSSxLQUFLLEtBQUssb0JBQUksSUFBRztBQUN4RCxjQUFNLFdBQVcsSUFBSSxJQUFvQixTQUFTO0FBRWxELG1CQUFXLEtBQUssVUFBVTtBQUN6QixnQkFBTSxXQUFXLGNBQWMsS0FBSyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLO0FBRWxFLGdCQUFNLFdBQ0wsRUFBRSxXQUFXLFdBQVcsSUFDcEIsRUFBRSxXQUFXLENBQUMsS0FBSyxLQUFPLEVBQUUsV0FBVyxDQUFDLEtBQUssSUFBSyxFQUFFLFdBQVcsQ0FBQyxJQUNoRSxFQUFFLFdBQVcsQ0FBQyxLQUFLO0FBQ3hCLGdCQUFNLFlBQVksVUFBVSxJQUFJLFFBQVE7QUFDeEMsZ0JBQU0sVUFBVSxjQUFjLFVBQWEsY0FBYztBQUV6RCxtQkFBUyxJQUFJLFVBQVUsUUFBUTtBQUUvQixnQkFBTSxZQUFZLG9CQUFvQixHQUFHLEtBQUssT0FBTztBQUNyRCxjQUFJLFNBQVM7QUFDWixZQUFBQSxRQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUyxFQUFFO0FBRXhDLGdCQUFJLEtBQUssa0JBQWtCO0FBQzFCLGtCQUFJLFNBQVMsRUFBRTtBQUNmLG9CQUFNLGFBQWEsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQzFDLG9CQUFJLEVBQUUsV0FBVyxFQUFFO0FBQVEseUJBQU87QUFDbEMsb0JBQUksRUFBRSxPQUFPLEVBQUU7QUFBSSx5QkFBTztBQUMxQixzQkFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUMzRCxvQkFBSSxDQUFDLGFBQWE7QUFBUyx5QkFBTztBQUNsQyxzQkFBTSxTQUFTLEVBQUUsS0FBSyxFQUFFO0FBQ3hCLHVCQUFPLFNBQVMsS0FBSyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE1BQU07Y0FDckUsQ0FBQztBQUNELGtCQUFJO0FBQVkseUJBQVMsV0FBVztBQUNwQyxvQkFBTSxrQkFBa0IsY0FBYyxLQUFLLE9BQU8sRUFBRSxRQUFRLE1BQU07QUFDbEUsbUJBQUssaUJBQWlCLGVBQWU7WUFDdEMsT0FBTztBQUNOLGNBQUFBLFFBQU8sS0FBSyxnRUFBMkQsUUFBUSxFQUFFO1lBQ2xGO1VBQ0QsT0FBTztBQUNOLFlBQUFBLFFBQU8sTUFBTSxNQUFNLEtBQUssTUFBTSxTQUFTLEVBQUU7VUFDMUM7UUFDRDtBQUNBLGFBQUssWUFBWSxJQUFJLE9BQU8sUUFBUTtNQUNyQyxTQUFTLEdBQUc7QUFDWCxRQUFBQSxRQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sT0FBTyxvQkFBb0IsQ0FBQyxNQUFNLGFBQWEsRUFBRTtNQUMvRTtBQUNBO0lBQ0Q7QUFHQSxVQUFNLFVBQVUsS0FBSyxhQUFhLE9BQU8sSUFBSTtBQUU3QyxVQUFNLFFBQVEsVUFBVSxjQUFjQSxRQUFPLE1BQU0sS0FBS0EsT0FBTSxJQUFJQSxRQUFPLEtBQUssS0FBS0EsT0FBTTtBQUN6RixRQUFJLFNBQVM7QUFDWixZQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLE1BQU0sT0FBTyxFQUFFO0lBQ2pFLE9BQU87QUFDTixZQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7SUFDcEQ7RUFDRDs7Ozs7RUFNUSxhQUFhLE9BQWUsTUFBWTtBQUMvQyxRQUFJLEtBQUssV0FBVztBQUFHLGFBQU87QUFHOUIsUUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixVQUFJLEtBQUssQ0FBQyxNQUFNLEdBQU07QUFDckIsZUFBTztNQUNSLE9BQU87QUFDTixlQUFPLFNBQVMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO01BQy9CO0lBQ0Q7QUFFQSxZQUFRLE9BQU87OztNQUdkLEtBQUssYUFBYTtBQUNqQixjQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGNBQU0sT0FBTyxNQUFNLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQyxFQUN0QyxJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUNqRSxLQUFLLEdBQUc7QUFDVixlQUFPLE1BQU0sS0FBSyxJQUFJLElBQUk7TUFDM0I7Ozs7O01BTUEsS0FBSyxjQUFjO0FBQ2xCLFlBQUksS0FBSyxXQUFXLEdBQUc7QUFDdEIsaUJBQU8sS0FBSyxDQUFDLE1BQU0sSUFBTyxXQUFXLFdBQVcsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQy9EO0FBQ0EsWUFBSSxLQUFLLFVBQVUsR0FBRztBQUNyQixnQkFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixnQkFBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixnQkFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO0FBQ2xDLGdCQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBQ2hGLGdCQUFNLGNBQWMsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLENBQUM7QUFDL0QsZ0JBQU0sVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0FBQ3RDLGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGNBQWMsR0FBRyxXQUFXLEtBQUssTUFBTSxRQUFTLENBQUMsTUFBTSxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUM7QUFDekcsZ0JBQU0sU0FBUyxJQUFJLE1BQU0sS0FBSyxDQUFDLElBQUksTUFBTSxTQUFTLENBQUMsS0FBSyxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUMsQ0FBQztBQUMxRixpQkFBTyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUSxJQUFJLE1BQU07UUFDaEU7QUFDQSxlQUFPLFFBQVEsS0FBSyxTQUFTLEtBQUssQ0FBQztNQUNwQzs7TUFHQSxLQUFLLGlCQUFpQjtBQUVyQixZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLFVBQVUsUUFBUSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEdBQUc7QUFDaEUsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGVBQWUsS0FBSyxXQUFXLFNBQVMsS0FBSyxDQUFDO0FBQy9ELGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRO1FBQ3REO0FBQ0EsZUFBTztNQUNSOztNQUdBLEtBQUs7TUFDTCxLQUFLLGFBQWE7QUFDakIsWUFBSSxLQUFLLFNBQVM7QUFBRyxpQkFBTztBQUM1QixjQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGNBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsY0FBTSxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQzdCLGVBQU8sTUFBTSxLQUFLLFlBQVksTUFBTSxTQUFTLENBQUMsVUFBVSxNQUFNLFNBQVMsS0FBSyxDQUFDO01BQzlFO01BRUE7QUFDQyxlQUFPO0lBQ1Q7RUFDRDtFQUVRLE9BQU8sZ0JBQWdCLE9BQWM7QUFDNUMsUUFBSSxPQUFPLFVBQVU7QUFBVyxhQUFPLENBQUMsUUFBUSxJQUFJLENBQUM7QUFDckQsUUFBSSxNQUFNLFFBQVEsS0FBSztBQUFHLGFBQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxPQUFPLENBQUMsSUFBSSxHQUFJO0FBQ2xFLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDOUIsVUFBSSxRQUFRO0FBQU0sZUFBTyxDQUFFLFNBQVMsS0FBTSxLQUFPLFNBQVMsSUFBSyxLQUFNLFFBQVEsR0FBSTtBQUNqRixhQUFPLENBQUMsUUFBUSxHQUFJO0lBQ3JCO0FBQ0EsVUFBTSxJQUFJLE1BQU0sNENBQTRDLEtBQUssRUFBRTtFQUNwRTtFQUVRLE1BQU0sWUFBWSxVQUFrQixRQUFjO0FBQ3pELFFBQUksTUFBTSxLQUFLLFNBQVMsSUFBSSxNQUFNO0FBQ2xDLFFBQUksQ0FBQyxLQUFLO0FBQ1QsWUFBTSxNQUFNLHFCQUFxQixNQUFNO0FBQ3ZDLFdBQUssU0FBUyxJQUFJLFFBQVEsR0FBRztJQUM5QjtBQUVBLFdBQU8sT0FBTyxPQUFPO01BQ3BCLE9BQU8sS0FBSyxDQUFDLEtBQU0sS0FBTSxHQUFNLFdBQVcsS0FBTSxHQUFNLEtBQU0sR0FBTSxHQUFNLEdBQUcsS0FBSyxHQUFNLENBQUksQ0FBQztNQUMzRixPQUFPLEtBQUssWUFBWSxNQUFNO0tBQzlCO0VBQ0Y7RUFFUSxPQUFPLFVBQVUsTUFBYztBQUN0QyxRQUFJLE1BQU07QUFDVixlQUFXLEtBQUssTUFBTTtBQUNyQixhQUFPO0FBQ1AsZUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDM0IsZUFBTyxNQUFNLFNBQVUsS0FBTSxPQUFPLElBQUssT0FBUSxNQUFRLE9BQU8sSUFBSztNQUN0RTtJQUNEO0FBQ0EsV0FBTztFQUNSOzs7Ozs7Ozs7O0VBV08sZ0JBQWdCLElBQVksT0FBZSxXQUFtQixPQUFjO0FBQ2xGLFVBQU0sTUFBTSxjQUFjLEtBQUssT0FBTyxPQUFPLFdBQVcsS0FBSztBQUM3RCxXQUFPLEtBQUssWUFBWSxJQUFJLEVBQUUsR0FBRyxJQUFJLEdBQUc7RUFDekM7RUFFTyxNQUFNLFlBQVksUUFBYztBQUN0QyxXQUFPLEtBQUssYUFBYSxrQkFBa0IsUUFBVyxHQUFNLFFBQVcsUUFBUSxLQUFLO0VBQ3JGO0VBRU8sTUFBTSxjQUFjLFFBQWM7QUFDeEMsV0FBTyxLQUFLLGFBQWEscUJBQXFCLFFBQVcsUUFBVyxRQUFXLFFBQVEsS0FBSztFQUM3Rjs7OztBRWx3QkQsSUFBTUUsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBTWxELElBQXFCLGlCQUFyQixjQUE0QyxhQUF5QjtFQUNwRTs7RUFDQTs7O0VBSVEsb0JBQWtDLENBQUE7OztFQUkxQyxjQUFzQjtFQUV0QixZQUFZLFVBQWlCO0FBQzVCLFVBQU0sUUFBUTtFQUNmO0VBRUEsTUFBTSxLQUFLLFFBQW9CO0FBQzlCLFNBQUssU0FBUztBQUNkLFFBQUksQ0FBQyxLQUFLLGNBQWM7QUFDdkIsV0FBSyxlQUFlLElBQUksYUFBWTtJQUNyQztBQUNBLFNBQUssYUFBYSxlQUFlLFlBQVksd0JBQXdCO0FBR3JFLFNBQUssYUFBYSxvQkFBb0IsQ0FBQyxlQUFzQjtBQUM1RCxXQUFLLGVBQWUsVUFBVTtJQUMvQixDQUFDO0FBSUQsU0FBSyxhQUFZLEVBQUcsTUFBTSxDQUFDLE1BQUs7QUFDL0IsTUFBQUEsUUFBTyxNQUFNLHFCQUFxQixDQUFDLEVBQUU7SUFDdEMsQ0FBQztFQUNGOzs7Ozs7O0VBUVEsTUFBTSxlQUFZO0FBQ3pCLElBQUFBLFFBQU8sS0FBSyw4QkFBOEI7QUFFMUMsU0FBSyxvQkFBb0IsTUFBTSxLQUFLLGFBQWEsZ0JBQWU7QUFHaEUsUUFBSTtBQUNKLFFBQUksS0FBSyxrQkFBa0IsV0FBVyxHQUFHO0FBRXhDLFVBQUksS0FBSyxPQUFPLFdBQVc7QUFDMUIsY0FBTSxhQUFhLEtBQUssT0FBTyxjQUFjLFNBQVMsS0FBSyxPQUFPLFdBQVcsTUFBTTtBQUNuRixRQUFBQSxRQUFPLEtBQUsscUJBQXFCLEtBQUssT0FBTyxTQUFTLDhDQUF5QztBQUMvRixhQUFLLGFBQWEsZUFBZSxtQkFBbUIsR0FBRyxVQUFVLElBQUksS0FBSyxPQUFPLFNBQVMsYUFBYTtBQUN2RztNQUNEO0FBQ0EsWUFBTSxjQUFjLEtBQUssT0FBTztBQUNoQyxVQUFJLENBQUMsS0FBSyxPQUFPLFFBQVEsQ0FBQyxhQUFhO0FBQ3RDLFFBQUFBLFFBQU8sS0FBSyx5REFBeUQ7QUFDckU7TUFDRDtBQUNBLE1BQUFBLFFBQU8sS0FBSyx3RUFBbUU7QUFDL0UsdUJBQWlCO0lBQ2xCLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssY0FBYyxLQUFLLGtCQUFrQixNQUFNLGFBQWE7QUFDcEUsaUJBQVcsS0FBSyxLQUFLLG1CQUFtQjtBQUN2QyxRQUFBQSxRQUFPLEtBQUssYUFBYSxFQUFFLEtBQUssSUFBSSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUU7TUFDckU7QUFLQSxpQkFBVyxVQUFVLEtBQUssbUJBQW1CO0FBQzVDLGFBQUssYUFBYSxnQkFBZ0IsT0FBTyxFQUFFO01BQzVDO0FBR0EsaUJBQVcsVUFBVSxLQUFLLG1CQUFtQjtBQUM1QyxZQUFJO0FBQ0gsZ0JBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSx1QkFBdUIsT0FBTyxFQUFFO0FBQ3pFLGlCQUFPLGVBQWU7QUFDdEIsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLGNBQWMsUUFBUSxXQUFXLE9BQU8sYUFBYSxFQUFFO1FBQ3BGLFNBQVMsR0FBRztBQUNYLFVBQUFBLFFBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSw2QkFBNkIsQ0FBQyxFQUFFO0FBQzVELGlCQUFPLGVBQWU7UUFDdkI7TUFDRDtBQUVBLHVCQUFpQixhQUFhLEtBQUssUUFBUSxLQUFLLGlCQUFpQjtBQUdqRSxVQUFJLENBQUMsa0JBQWtCLEtBQUssT0FBTyxXQUFXO0FBQzdDLGNBQU0sYUFBYSxLQUFLLE9BQU8sY0FBYyxTQUFTLEtBQUssT0FBTyxXQUFXLE1BQU07QUFDbkYsUUFBQUEsUUFBTyxLQUFLLHFCQUFxQixLQUFLLE9BQU8sU0FBUyxzREFBaUQ7QUFDdkcsYUFBSyxhQUFhLGVBQWUsbUJBQW1CLEdBQUcsVUFBVSxJQUFJLEtBQUssT0FBTyxTQUFTLGFBQWE7QUFDdkc7TUFDRDtJQUNEO0FBR0EsU0FBSyxVQUFVLGNBQWM7QUFJN0IsVUFBTSxhQUFhLEtBQUs7QUFDeEIsVUFBTSxLQUFLLG9CQUFvQixJQUFJLFVBQVU7QUFHN0MsU0FBSyxjQUFhO0FBQ2xCLFNBQUssZ0JBQWU7QUFDcEIsU0FBSywwQkFBeUI7QUFDOUIsU0FBSyxxQkFBb0I7QUFFekIsU0FBSyxhQUFhLGVBQWUsRUFBRTtBQUNuQyxJQUFBQSxRQUFPLEtBQUssMkJBQTJCO0VBQ3hDOztFQUdBLE1BQU0sVUFBTztBQUNaLFNBQUssY0FBYyxNQUFLO0FBQ3hCLElBQUFBLFFBQU8sTUFBTSxTQUFTO0VBQ3ZCO0VBRUEsTUFBTSxjQUFjLFFBQW9CO0FBQ3ZDLFVBQU0sZUFBZSxLQUFLO0FBQzFCLFNBQUssU0FBUztBQUNkLFVBQU0saUJBQWlCLGFBQWEsUUFBUSxLQUFLLGlCQUFpQjtBQUNsRSxTQUFLLFVBQVUsY0FBYztBQUk3QixTQUFLLHFCQUFvQjtBQUV6QixVQUFNLFVBQVUsS0FBSztBQUlyQixVQUFNLEtBQUssb0JBQW9CLGNBQWMsT0FBTztBQUdwRCxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtFQUMxQjs7Ozs7Ozs7Ozs7O0VBYVEsTUFBTSxvQkFBb0IsY0FBc0IsU0FBZTtBQUN0RSxRQUFJLENBQUMsU0FBUztBQUNiLFVBQUk7QUFBYyxhQUFLLGFBQWEsYUFBYSxZQUFZO0FBQzdEO0lBQ0Q7QUFFQSxRQUFJLEtBQUssT0FBTyxXQUFXO0FBRTFCLFlBQU0sU0FBUyxLQUFLLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsS0FBSyxPQUFPLFNBQVM7QUFDakYsVUFBSSxDQUFDLFFBQVE7QUFDWixRQUFBQSxRQUFPLEtBQUssZUFBZSxLQUFLLE9BQU8sU0FBUyx5REFBb0Q7QUFDcEcsWUFBSTtBQUFjLGVBQUssYUFBYSxhQUFhLFlBQVk7QUFDN0Q7TUFDRDtBQUVBLFVBQUksZ0JBQWdCLGlCQUFpQixTQUFTO0FBQzdDLGFBQUssYUFBYSxhQUFhLFlBQVk7TUFDNUM7QUFDQSxZQUFNLGdCQUFnQixLQUFLLGFBQWEsbUJBQW1CLE9BQU87QUFDbEUsVUFBSSxDQUFDLGVBQWU7QUFDbkIsYUFBSyxhQUFhLGdCQUFnQixPQUFPO01BQzFDO0FBQ0EsVUFBSSxZQUFZLGdCQUFnQixDQUFDLGVBQWU7QUFDL0MsY0FBTSxLQUFLLDZCQUE2QixPQUFPLE9BQU8sT0FBTztNQUM5RDtBQUNBO0lBQ0Q7QUFHQSxVQUFNLGNBQWMsT0FBTyxLQUFLLE9BQU8sZUFBZSxFQUFFO0FBQ3hELFVBQU0saUJBQWlCLEtBQUssa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBRTFFLFFBQUksZ0JBQWdCO0FBQ25CLFVBQUksZUFBZSxVQUFVLGFBQWE7QUFDekMsWUFBSSxnQkFBZ0IsaUJBQWlCO0FBQVMsZUFBSyxhQUFhLGFBQWEsWUFBWTtBQUN6RixjQUFNLGdCQUFnQixLQUFLLGFBQWEsbUJBQW1CLE9BQU87QUFDbEUsWUFBSSxDQUFDLGVBQWU7QUFDbkIsZUFBSyxhQUFhLGdCQUFnQixPQUFPO1FBQzFDO0FBQ0EsWUFBSSxZQUFZLGdCQUFnQixDQUFDLGVBQWU7QUFDL0MsZ0JBQU0sS0FBSyw2QkFBNkIsYUFBYSxPQUFPO1FBQzdEO01BQ0QsT0FBTztBQUNOLFFBQUFBLFFBQU8sTUFDTiwwQkFBMEIsV0FBVywyQ0FBMkMsZUFBZSxLQUFLLFFBQVEsT0FBTywwQkFBcUI7QUFFekksYUFBSyxhQUFhLGFBQWEsT0FBTztBQUN0QyxhQUFLLGFBQ0osZUFBZSxtQkFDZiw0QkFBNEIsV0FBVyxTQUFTLGVBQWUsS0FBSyxFQUFFO01BRXhFO0FBQ0E7SUFDRDtBQUdBLElBQUFBLFFBQU8sS0FBSyxHQUFHLE9BQU8sd0NBQW1DO0FBQ3pELFFBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLFdBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsU0FBSyxhQUFhLGFBQWEsT0FBTztBQUV0QyxVQUFNLFNBQVMsTUFBTSxLQUFLLGFBQWEsWUFBWSxPQUFPO0FBQzFELFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxNQUFNLDBCQUEwQixPQUFPLDBCQUFxQjtBQUNuRSxXQUFLLGFBQWEsZUFBZSxnQkFBZ0IsbUJBQW1CLE9BQU8sRUFBRTtJQUM5RSxXQUFXLE9BQU8sVUFBVSxhQUFhO0FBQ3hDLE1BQUFBLFFBQU8sTUFDTiwwQkFBMEIsV0FBVywyQ0FBMkMsT0FBTyxLQUFLLFFBQVEsT0FBTywwQkFBcUI7QUFFakksV0FBSyxhQUNKLGVBQWUsbUJBQ2YsNEJBQTRCLFdBQVcsU0FBUyxPQUFPLEtBQUssRUFBRTtJQUVoRSxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGtCQUFrQixPQUFPLEtBQUssT0FBTyxPQUFPLEVBQUU7QUFDMUQsV0FBSyxhQUFhLGdCQUFnQixPQUFPO0FBQ3pDLFlBQU0sS0FBSyw2QkFBNkIsYUFBYSxPQUFPO0FBQzVELFdBQUssYUFBYSxlQUFlLEVBQUU7SUFDcEM7RUFDRDs7Ozs7RUFNUSxNQUFNLDZCQUE2QixPQUFlLElBQVU7QUFDbkUsUUFBSTtBQUNILFlBQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFO0FBRTdDLFVBQUksQ0FBQyxnQkFBZ0IsS0FBSyxHQUFHO0FBRzVCLFFBQUFBLFFBQU8sS0FBSyw2QkFBNkIsS0FBSyxzREFBaUQ7QUFDL0Y7TUFDRDtJQUNELFNBQVMsR0FBRztBQUNYLE1BQUFBLFFBQU8sS0FBSyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsRUFBRTtJQUN4RDtFQUNEOztFQUdRLFVBQVUsT0FBYTtBQUM5QixTQUFLLGNBQWM7QUFDbkIsVUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxLQUFLLFVBQVUsS0FBSywrQkFBK0I7QUFDMUQsV0FBSyxhQUFhLFNBQVMsT0FBTyxDQUFBLEdBQUksSUFBSTtBQUMxQztJQUNEO0FBRUEsVUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSSxPQUFPLFlBQVksQ0FBQTtBQUNyRSxVQUFNLHNCQUFzQixPQUFPLHVCQUF1QjtBQUUxRCxTQUFLLGFBQWEsU0FBUyxPQUFPLFNBQVMsbUJBQW1CO0FBQzlELFFBQUksUUFBUSxXQUFXLEdBQUc7QUFDekIsTUFBQUEsUUFBTyxLQUFLLCtCQUErQixLQUFLLDZDQUF3QztJQUN6RixPQUFPO0FBQ04sTUFBQUEsUUFBTyxNQUNOLFVBQVUsUUFBUSxNQUFNLHVCQUF1QixLQUFLLGdCQUFnQixPQUFPLFNBQVMseUJBQXlCLG1CQUFtQixFQUFFO0lBRXBJO0VBQ0Q7RUFFQSxrQkFBZTtBQUNkLFdBQU8sZ0JBQWdCLEtBQUssaUJBQWlCO0VBQzlDOztFQUdBLElBQUksT0FBSTtBQUNQLFdBQU8sWUFBWSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7RUFDdkQ7O0VBR0EsSUFBSSxVQUFPO0FBQ1YsV0FBTyxLQUFLO0VBQ2I7RUFFQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSxrQkFBZTtBQUNkLG9CQUFnQixJQUFJO0VBQ3JCO0VBRUEsNEJBQXlCO0FBQ3hCLDhCQUEwQixJQUFJO0VBQy9CO0VBRUEsdUJBQW9CO0FBQ25CLHlCQUFxQixJQUFJO0VBQzFCOzsiLAogICJuYW1lcyI6IFsicGF0aCIsICJJbnN0YW5jZVN0YXR1cyIsICJSZWdleCIsICJwYXRoIiwgImZzIiwgImxvZ2dlciIsICJsb2dnZXIiLCAiaWRBZGRPcHQiLCAiZnMiLCAibG9nZ2VyIiwgImRldmljZXNGb2xkZXIiLCAicGF0aCIsICJkZ3JhbSIsICJsb2dnZXIiLCAibG9nZ2VyIiwgImRncmFtIiwgImxvZ2dlciJdCn0K
