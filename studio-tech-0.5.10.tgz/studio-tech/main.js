import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual (enter IP + model below)" },
    ...discoveredDevices.map((d) => ({
      id: d.mac ?? "",
      label: `Model ${d.model} [${d.mac}] @ ${d.ip}`
    }))
  ];
  return [
    // ── Device selection dropdown ────────────────────────────────────────
    // Stores the MAC so re-discovery with a changed IP still matches.
    {
      type: "dropdown",
      id: "deviceMac",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry — only visible in manual mode ────────────────────
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Manual model selector — only visible in manual mode ──────────────
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Select which Studio Technologies model is active for actions and feedbacks."
    }
  ];
}
function resolveHost(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    return device?.ip ?? "";
  }
  return String(config.host ?? "");
}
function resolveModel(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    logger.debug(`resolveModel: deviceMac="${config.deviceMac}", found device: ${device?.model ?? "none"}`);
    return device?.model ?? "";
  }
  logger.debug(`resolveModel: manual mode, activeModel="${config.activeModel}"`);
  return String(config.activeModel ?? "");
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_MIC_PRE = 2;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_MIC_PRE:
      return "Mic Preamp";
    case CMD_BUS_GET:
      return "Heartbeat";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "static-text":
      return { ...base, value: o.value ?? "" };
    case "textinput":
    case "colorpicker":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  const commandsRawValue = [CMD_MIC_PRE];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    const isRawValue = commandsRawValue.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (isRawValue) {
      busCh = buf[p + 2];
      const rawBytes = buf.subarray(p + 3, sectionEnd);
      const micPreRemap = [1, 2];
      for (let i = 0; i < rawBytes.length; i++) {
        if (sectionCmdId === CMD_MIC_PRE) {
          const remappedId = i < micPreRemap.length ? micPreRemap[i] : null;
          if (remappedId !== null) {
            out.push({ cmd_id: CMD_MIC_PRE_BUS, id: remappedId, busCh, valueBytes: [rawBytes[i]] });
          }
        } else {
          out.push({ cmd_id: sectionCmdId, id: i, busCh, valueBytes: [rawBytes[i]] });
        }
      }
      p = sectionEnd;
      continue;
    } else if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    const qStart = q;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    if (q === qStart && sectionEnd > p + 3) {
      let pos = hasBusCh ? p + 3 : p + 2;
      let posId = 0;
      while (pos < sectionEnd) {
        const setting = { cmd_id: sectionCmdId, id: posId++, valueBytes: [buf[pos++]] };
        if (busCh !== void 0)
          setting.busCh = busCh;
        out.push(setting);
      }
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  const idAddDeferRanges = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    for (const baseEntry of c.cmdSchema ?? []) {
      const idAddOpt = baseEntry.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        continue;
      const baseId = baseEntry.id;
      const cmdId = baseEntry.cmd_id;
      const key = `${cmdId}_${baseId}`;
      if (idAddDeferRanges.has(key))
        continue;
      const parsedOffsets = parsed.filter((p) => p.cmd_id === cmdId && p.id > baseId).map((p) => p.id - baseId).sort((a, b) => a - b);
      let maxSeq = 0;
      for (const off of parsedOffsets) {
        if (off === maxSeq + 1)
          maxSeq = off;
        else if (off > maxSeq + 1)
          break;
      }
      if (maxSeq > 0) {
        idAddDeferRanges.set(key, maxSeq);
        logger2.debug(`idAdd defer range for cmd_id=${toHex(cmdId)} base_id=${toHex(baseId)}: offsets 1\u2013${maxSeq}`);
      }
    }
  }
  const busChSeen = /* @__PURE__ */ new Map();
  for (const { cmd_id, id, busCh } of parsed) {
    if (busCh === void 0)
      continue;
    const key = `${cmd_id}_${id}`;
    if (!busChSeen.has(key))
      busChSeen.set(key, /* @__PURE__ */ new Set());
    busChSeen.get(key).add(busCh);
  }
  for (const { cmd_id, id, busCh, valueBytes } of parsed) {
    const existingExact = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (existingExact) {
      const opt = existingExact.options?.find((o) => o.id === "value");
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
      continue;
    }
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt = a.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        return false;
      if (id <= a.id)
        return false;
      const offset = id - a.id;
      return candidates.some((c) => {
        const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === a.id);
        const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
        return refIdAdd?.choices?.some((ch) => ch.id === offset);
      });
    });
    if (idAddBase) {
      const offset = id - idAddBase.id;
      const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
      if (idAddOpt?.choices && !idAddOpt.choices.some((c) => c.id === offset)) {
        let label = `Channel ${offset + 1}`;
        for (const c of candidates) {
          const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
          const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
          const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
          if (refChoice) {
            label = refChoice.label;
            break;
          }
        }
        idAddOpt.choices.push({ id: offset, label });
        logger2.info(`Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
      }
      continue;
    }
    let action;
    for (const c of candidates) {
      const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
      if (match) {
        action = structuredClone(match);
        const baseName = match.name.replace(/\s*\(inferred from Model [^)]+\)/g, "").trim();
        action.name = `${baseName} (inferred from Model ${c.model})`;
        logger2.info(`Inferred cmd_id=${toHex(cmd_id)} id=${toHex(id)} from Model ${c.model} (exact)`);
        break;
      }
    }
    if (!action) {
      let shouldDefer = false;
      for (const c of candidates) {
        const baseEntry = c.cmdSchema?.find((a) => {
          if (a.cmd_id !== cmd_id)
            return false;
          const idAddOpt = a.options?.find((o) => o.id === "idAdd");
          if (!idAddOpt?.choices)
            return false;
          if (id <= a.id)
            return false;
          const offset = id - a.id;
          const maxSeq = idAddDeferRanges.get(`${cmd_id}_${a.id}`) ?? 0;
          return offset <= maxSeq;
        });
        if (baseEntry) {
          shouldDefer = true;
          logger2.debug(`cmd_id=${toHex(cmd_id)} id=${toHex(id)} is an idAdd offset of candidate base id=${toHex(baseEntry.id)} \u2014 deferring to pass 2`);
          break;
        }
      }
      if (shouldDefer)
        continue;
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown cmd:${toHex(cmd_id)} id:${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      if (busCh !== void 0)
        action.busCh = busCh;
      logger2.warn(`Could not infer cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
    } else {
      action.options = action.options?.filter((o) => o.id !== "busCh") ?? [];
      delete action.busCh;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        if (maxBusCh === 0) {
          action.busCh = 0;
        } else {
          const busChChoices = Array.from({ length: maxBusCh + 1 }, (_, i) => ({
            id: i,
            label: `Channel ${i + 1}`
          }));
          action.options.unshift({
            id: "busCh",
            label: "Channel",
            type: "dropdown",
            choices: busChChoices,
            default: 0
          });
        }
      }
      const observedDefault = valueBytesToOption(valueBytes).default;
      const valueOpt = action.options?.find((o) => o.id === "value");
      if (valueOpt) {
        if (valueOpt.choices && Array.isArray(valueOpt.choices)) {
          const inChoices = valueOpt.choices.some((c) => c.id === observedDefault);
          if (!inChoices) {
            logger2.warn(`Inferred choices for cmd_id=${toHex(cmd_id)} id=${toHex(id)} don't contain observed value ${observedDefault} \u2014 discarding inherited choices`);
            valueOpt.type = "number";
            delete valueOpt.choices;
          }
        }
        valueOpt.default = observedDefault;
      }
    }
    out.cmdSchema.push(action);
  }
  for (const { cmd_id, id } of parsed) {
    const alreadyTopLevel = out.cmdSchema.some((a) => a.cmd_id === cmd_id && a.id === id);
    if (alreadyTopLevel)
      continue;
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt2 = a.options?.find((o) => o.id === "idAdd");
      return !!idAddOpt2?.choices && id > a.id;
    });
    if (!idAddBase)
      continue;
    const offset = id - idAddBase.id;
    const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
    if (!idAddOpt?.choices || idAddOpt.choices.some((c) => c.id === offset))
      continue;
    const refHasOffset = candidates.some((c) => {
      const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      return refIdAdd?.choices?.some((ch) => ch.id === offset);
    });
    const existingOffsets = idAddOpt.choices.map((c) => c.id).sort((a, b) => a - b);
    const isSequential = existingOffsets.length > 0 && offset === existingOffsets[existingOffsets.length - 1] + 1;
    if (!refHasOffset && !isSequential)
      continue;
    let label = `Channel ${offset + 1}`;
    for (const c of candidates) {
      const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
      if (refChoice) {
        label = refChoice.label;
        break;
      }
    }
    idAddOpt.choices.push({ id: offset, label });
    logger2.info(`Pass 2: Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("refreshAfterCommand" in jsonObj) {
      orderedObj.refreshAfterCommand = jsonObj.refreshAfterCommand;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema.map((entry) => {
        const orderedEntry = {};
        if ("cmd_id" in entry)
          orderedEntry.cmd_id = entry.cmd_id;
        if ("id" in entry)
          orderedEntry.id = entry.id;
        if ("busCh" in entry)
          orderedEntry.busCh = entry.busCh;
        if ("name" in entry)
          orderedEntry.name = entry.name;
        if ("options" in entry)
          orderedEntry.options = entry.options;
        for (const key of Object.keys(entry)) {
          if (!(key in orderedEntry))
            orderedEntry[key] = entry[key];
        }
        return orderedEntry;
      });
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  wiredActions["global_getAllSettings"] = {
    name: "GLOBAL: Get All Settings (Auto-Update JSON)",
    options: [],
    callback: async () => {
      const model = activeModel;
      const ip = self.host;
      const buf = await self.stController.requestAllSettings(ip);
      let modelJson = getDeviceSchema(model);
      const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
      logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
      if (!modelJson) {
        logger3.info(`Model ${model} has no schema \u2014 creating new JSON from settings`);
        modelJson = {
          model,
          sectioned: detectedSectioned ?? false,
          refreshAfterCommand: true,
          cmdSchema: []
        };
      } else if (detectedSectioned !== null) {
        logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
        modelJson = { ...modelJson, sectioned: detectedSectioned };
      }
      const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
      logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
      const devicesFolder2 = getDevicesFolder();
      const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
      saveModelJsonPretty(schemaPath, updated);
      reloadDeviceSchemas();
      logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
    }
  };
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
          await self.stController.requestAllSettings(ip).catch((err) => {
            logger3.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
}

// dist/feedbacks.js
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        let busCh = feedbackEvent.options["busCh"];
        if (busCh === void 0) {
          const schemaAction = findActionForSetting(schemas, model, cmdId, settingId);
          if (schemaAction?.busCh !== void 0) {
            busCh = schemaAction.busCh;
          }
        }
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
}

// dist/stcontroller.js
import dgram2 from "dgram";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger4 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger4.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger4.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger4.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger4.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger4.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger4.warn(`Could not join announce multicast group: ${err}`);
      }
    });
  });
}

// dist/stcontroller.js
var logger5 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  constructor() {
    logger5.info("StController initialized");
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger5.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger5.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger5.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger5.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger5.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger5.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger5.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    logger5.debug(`Revoked device at ${ip}`);
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    return new Promise((resolve) => {
      const key = `__probe_${ip}__`;
      let resolved = false;
      const finish = (result) => {
        if (resolved)
          return;
        resolved = true;
        this.discoveryListeners.delete(key);
        resolve(result);
      };
      this.discoveryListeners.set(key, (device) => {
        if (device.ip === ip)
          finish(device);
      });
      const timer = setTimeout(() => finish(null), timeoutMs);
      timer.unref?.();
      const run = async () => {
        await this.ensureMembershipFor(ip);
        await this.txReady;
        const query = buildDanteInfoRequest();
        this.txSocket.send(query, this.defaultPort, ip, (err) => {
          if (err) {
            logger5.warn(`Probe to ${ip} failed: ${err.message}`);
            clearTimeout(timer);
            finish(null);
          }
        });
      };
      run().catch((e) => {
        logger5.warn(`probeDevice setup failed for ${ip}: ${e}`);
        clearTimeout(timer);
        finish(null);
      });
    });
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger5.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger5.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger5.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger5.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger5.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger5.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger5.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger5.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && this.refreshAfterCommand && value !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger5.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (cmdId === CMD_MIC_PRE && busCh !== void 0 && settingId !== void 0 && value !== void 0) {
      if (!this.deviceState.has(destIp))
        this.deviceState.set(destIp, /* @__PURE__ */ new Map());
      const ipState = this.deviceState.get(destIp);
      const numPositions = 3;
      const positions = [];
      for (let i = 0; i < numPositions; i++) {
        const stateKey = makeSettingId(this.model, CMD_MIC_PRE, i, busCh);
        const val = i === settingId ? Number(value) : ipState.get(stateKey) ?? 0;
        positions.push(val);
        ipState.set(stateKey, val);
      }
      payloadBody.push(busCh & 255, ...positions);
    } else {
      if (busCh !== void 0)
        payloadBody.push(busCh & 255);
      if (addLen)
        payloadBody.push(dataBlock.length);
      if (dataBlock.length > 0)
        payloadBody.push(...dataBlock);
    }
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger5.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger5.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    if (!this.authorizedIps.has(destIp)) {
      logger5.debug(`Packet (not sent \u2014 device not authorized) to ${destIp}: ${payloadWithCrc.toString("hex")}`);
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    await this.ensureMembershipFor(destIp);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    logger5.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger5.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger5.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse && originalCmdId === CMD_GET_ALL_SETTINGS) {
      logger5.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
    }
    this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger5.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger5.info(`RX ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              let baseId = s.id;
              const baseAction = this.actions.find((a) => {
                if (a.cmd_id !== s.cmd_id)
                  return false;
                if (a.id === s.id)
                  return true;
                const idAddOption = a.options?.find((o) => o.id === "idAdd");
                if (!idAddOption?.choices)
                  return false;
                const offset = s.id - a.id;
                return offset > 0 && idAddOption.choices.some((c) => c.id === offset);
              });
              if (baseAction)
                baseId = baseAction.id;
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, baseId);
              this.feedbackCallback(baseFeedbackKey);
            } else {
              logger5.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger5.debug(`RX ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger5.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    const logFn = cmdId === CMD_BUS_GET ? logger5.debug.bind(logger5) : logger5.info.bind(logger5);
    if (decoded) {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_MIC_PRE (0x02): raw preamp echo — positional bytes, no setting IDs ──
      // Device echoes [busCh][val0][val1]... confirming the applied values.
      case CMD_MIC_PRE: {
        const busCh = data[0];
        const vals = Array.from(data.subarray(1)).map((b, i) => `[${i}]=0x${b.toString(16).padStart(2, "0")}(${b})`).join(" ");
        return `ch=${busCh} ${vals}`;
      }
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger6 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Connecting, "Discovering devices...");
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger6.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger6.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      if (this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found during discovery \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger6.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger6.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger6.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger6.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger6.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger6.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
      if (!effectiveModel && this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found among discovered devices \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    this.updateStatus(InstanceStatus.Ok);
    logger6.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger6.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current config is authorized to send commands.
   *
   * Auto mode (deviceMac set):
   *   - Find the discovered device with matching MAC → get its current IP
   *   - Revoke the previous IP, authorize the new IP
   *   - If MAC not found in discovery, revoke and block
   *
   * Manual mode (deviceMac empty):
   *   - Check discovered list by IP+model match, or probe directly
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.deviceMac) {
      const device = this.discoveredDevices.find((d) => d.mac === this.config.deviceMac);
      if (!device) {
        logger6.warn(`Device MAC "${this.config.deviceMac}" not found in current discovery \u2014 not authorizing`);
        if (previousHost)
          this.stController.revokeDevice(previousHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        await this.fetchSettingsAndEnsureSchema(device.model, newHost);
      }
      return;
    }
    const manualModel = String(this.config.activeModel ?? "");
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
      } else {
        logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
        this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${discoveredAtIp.model}`);
      }
      return;
    }
    logger6.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger6.error(`No device responded at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.UnknownWarning, `Device offline: ${newHost}`);
    } else if (probed.model !== manualModel) {
      logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${probed.model}`);
    } else {
      logger6.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
      this.updateStatus(InstanceStatus.Ok);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger6.warn(`No schema found for Model ${model} \u2014 run "GLOBAL: Get All Settings" to create one`);
        return;
      }
    } catch (e) {
      logger6.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger6.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, [], true);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    const refreshAfterCommand = schema.refreshAfterCommand ?? true;
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger6.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger6.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}, refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, resolved from MAC→IP via discoveredDevices (auto) or config.host (manual). */
  get host() {
    return resolveHost(this.config, this.discoveredDevices);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0LyoqIE1BQyBvZiB0aGUgc2VsZWN0ZWQgZGlzY292ZXJlZCBkZXZpY2UgKGUuZy4gXCIwMDoxZDpjMTo5YjphNjpjZFwiKSwgb3IgJycgZm9yIG1hbnVhbCBtb2RlICovXG5cdGRldmljZU1hYzogc3RyaW5nXG5cdC8qKiBNYW51YWwgSVAgYWRkcmVzcyBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGhvc3Q6IHN0cmluZ1xuXHQvKiogTWFudWFsIG1vZGVsIHNlbGVjdGlvbiBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcbn1cblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQ0VOVFJBTElaRUQgREVWSUNFIFNDSEVNQSBDQUNIRVxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQWxsIGRldmljZSBKU09OIGZpbGVzIGFyZSBsb2FkZWQgb25jZSBpbnRvIG1lbW9yeSBoZXJlLiBPdGhlciBtb2R1bGVzIHNob3VsZFxuLy8gdXNlIGdldERldmljZXNGb2xkZXIoKSwgZ2V0RGV2aWNlU2NoZW1hcygpLCBhbmQgZ2V0RGV2aWNlU2NoZW1hKCkgaW5zdGVhZCBvZlxuLy8gcmVhZGluZyBmaWxlcyBkaXJlY3RseS4gQ2FsbCByZWxvYWREZXZpY2VTY2hlbWFzKCkgYWZ0ZXIgd3JpdGluZyB0byBhIGZpbGUuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB0aGUgY29ycmVjdCBkZXZpY2VzIGZvbGRlciBwYXRoIHdpdGggZmFsbGJhY2sgc3VwcG9ydC5cbiAqIENoZWNrcyBwcmltYXJ5IHBhdGggZmlyc3QsIHRoZW4gZmFsbGJhY2ssIHRoZW4gdGhyb3dzIGVycm9yIGlmIG5laXRoZXIgZXhpc3RzLlxuICovXG5mdW5jdGlvbiByZXNvbHZlRGV2aWNlc0ZvbGRlcigpOiBzdHJpbmcge1xuXHRjb25zdCBwcmltYXJ5UGF0aCA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi4vZGV2aWNlcycpXG5cdGNvbnN0IGZhbGxiYWNrUGF0aCA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi9kZXZpY2VzJylcblxuXHQvLyBDaGVjayBwcmltYXJ5IHBhdGhcblx0aWYgKGZzLmV4aXN0c1N5bmMocHJpbWFyeVBhdGgpKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBVc2luZyBkZXZpY2VzIGZvbGRlcjogJHtwcmltYXJ5UGF0aH1gKVxuXHRcdHJldHVybiBwcmltYXJ5UGF0aFxuXHR9XG5cblx0Ly8gQ2hlY2sgZmFsbGJhY2sgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhmYWxsYmFja1BhdGgpKSB7XG5cdFx0bG9nZ2VyLndhcm4oYFByaW1hcnkgZGV2aWNlcyBmb2xkZXIgbm90IGZvdW5kLCB1c2luZyBmYWxsYmFjazogJHtmYWxsYmFja1BhdGh9YClcblx0XHRyZXR1cm4gZmFsbGJhY2tQYXRoXG5cdH1cblxuXHQvLyBOZWl0aGVyIHBhdGggZXhpc3RzIC0gZmF0YWwgZXJyb3Jcblx0Y29uc3QgZXJyb3JNc2cgPSBgRGV2aWNlcyBmb2xkZXIgbm90IGZvdW5kIVxcblRyaWVkOlxcbiAgLSAke3ByaW1hcnlQYXRofVxcbiAgLSAke2ZhbGxiYWNrUGF0aH1cXG5Nb2R1bGUgY2Fubm90IGNvbnRpbnVlIHdpdGhvdXQgZGV2aWNlIHNjaGVtYXMuYFxuXHRsb2dnZXIuZXJyb3IoZXJyb3JNc2cpXG5cdHRocm93IG5ldyBFcnJvcihlcnJvck1zZylcbn1cblxuLy8gUmVzb2x2ZSB0aGUgZGV2aWNlcyBmb2xkZXIgcGF0aCAod2l0aCBleGlzdGVuY2UgY2hlY2sgYW5kIGZhbGxiYWNrKVxuY29uc3QgZGV2aWNlc0ZvbGRlciA9IHJlc29sdmVEZXZpY2VzRm9sZGVyKClcblxuLy8gSW4tbWVtb3J5IGNhY2hlIG9mIGFsbCBkZXZpY2Ugc2NoZW1hcywga2V5ZWQgYnkgbW9kZWwgbnVtYmVyXG5sZXQgZGV2aWNlU2NoZW1hc0NhY2hlOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgbnVsbCA9IG51bGxcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBhYnNvbHV0ZSBwYXRoIHRvIHRoZSBkZXZpY2VzIGZvbGRlci5cbiAqIFVzZSB0aGlzIGluc3RlYWQgb2YgcmVkZWZpbmluZyB0aGUgcGF0aCBpbiBldmVyeSBmaWxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlc0ZvbGRlcigpOiBzdHJpbmcge1xuXHRyZXR1cm4gZGV2aWNlc0ZvbGRlclxufVxuXG4vKipcbiAqIExvYWRzIGFsbCBkZXZpY2UgSlNPTiBmaWxlcyBmcm9tIHRoZSBkZXZpY2VzIGZvbGRlciBpbnRvIG1lbW9yeS5cbiAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uY2UgYXQgaW5pdGlhbGl6YXRpb24sIG9yIGFmdGVyIGEgZmlsZSBpcyB3cml0dGVuLlxuICovXG5mdW5jdGlvbiBsb2FkRGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0Y29uc3Qgc2NoZW1hczogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9XG5cdHRyeSB7XG5cdFx0Y29uc3QgZmlsZXMgPSBmcy5yZWFkZGlyU3luYyhkZXZpY2VzRm9sZGVyKS5maWx0ZXIoKGYpID0+IGYuZW5kc1dpdGgoJy5qc29uJykpXG5cblx0XHRmb3IgKGNvbnN0IGYgb2YgZmlsZXMpIHtcblx0XHRcdGNvbnN0IGZ1bGxQYXRoID0gcGF0aC5qb2luKGRldmljZXNGb2xkZXIsIGYpXG5cdFx0XHRjb25zdCBqc29uID0gSlNPTi5wYXJzZShmcy5yZWFkRmlsZVN5bmMoZnVsbFBhdGgsICd1dGY4JykpXG5cdFx0XHRpZiAoanNvbj8ubW9kZWwpIHtcblx0XHRcdFx0c2NoZW1hc1tTdHJpbmcoanNvbi5tb2RlbCldID0ganNvblxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGxvZ2dlci5kZWJ1ZyhgTG9hZGVkICR7T2JqZWN0LmtleXMoc2NoZW1hcykubGVuZ3RofSBkZXZpY2Ugc2NoZW1hcyBpbnRvIGNhY2hlYClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmFpbGVkIHRvIGxvYWQgZGV2aWNlIHNjaGVtYXM6ICR7ZX1gKVxuXHR9XG5cdHJldHVybiBzY2hlbWFzXG59XG5cbi8qKlxuICogUmV0dXJucyBhbGwgZGV2aWNlIHNjaGVtYXMgZnJvbSB0aGUgY2FjaGUuXG4gKiBJbml0aWFsaXplcyB0aGUgY2FjaGUgb24gZmlyc3QgY2FsbC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZVNjaGVtYXMoKTogUmVjb3JkPHN0cmluZywgYW55PiB7XG5cdGlmICghZGV2aWNlU2NoZW1hc0NhY2hlKSB7XG5cdFx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxuXHR9XG5cdHJldHVybiBkZXZpY2VTY2hlbWFzQ2FjaGVcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgc3BlY2lmaWMgZGV2aWNlIHNjaGVtYSBieSBtb2RlbCBudW1iZXIuXG4gKiBSZXR1cm5zIHVuZGVmaW5lZCBpZiB0aGUgbW9kZWwgZG9lc24ndCBleGlzdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZVNjaGVtYShtb2RlbDogc3RyaW5nKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRyZXR1cm4gc2NoZW1hc1ttb2RlbF1cbn1cblxuLyoqXG4gKiBSZWxvYWRzIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIGRpc2suXG4gKiBDYWxsIHRoaXMgYWZ0ZXIgd3JpdGluZyB0byBhIGRldmljZSBKU09OIGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZWxvYWREZXZpY2VTY2hlbWFzKCk6IHZvaWQge1xuXHRsb2dnZXIuaW5mbygnUmVsb2FkaW5nIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay4uLicpXG5cdGRldmljZVNjaGVtYXNDYWNoZSA9IGxvYWREZXZpY2VTY2hlbWFzKClcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgbGlzdCBvZiBhdmFpbGFibGUgbW9kZWwgbnVtYmVycywgc29ydGVkLlxuICovXG5mdW5jdGlvbiBsb2FkQXZhaWxhYmxlTW9kZWxzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRyZXR1cm4gT2JqZWN0LmtleXMoc2NoZW1hcykuc29ydCgpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBHZXRDb25maWdGaWVsZHMoZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSA9IFtdKTogU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkW10ge1xuXHRjb25zdCBtb2RlbHMgPSBsb2FkQXZhaWxhYmxlTW9kZWxzKClcblxuXHQvLyBEcm9wZG93biBpZCBpcyB0aGUgZGV2aWNlIE1BQyBcdTIwMTQgc3RhYmxlIGFjcm9zcyBJUCBjaGFuZ2VzLlxuXHQvLyBFbXB0eSBpZCA9IE1hbnVhbCBtb2RlLlxuXHRjb25zdCBkZXZpY2VDaG9pY2VzID0gW1xuXHRcdHsgaWQ6ICcnLCBsYWJlbDogJ01hbnVhbCAoZW50ZXIgSVAgKyBtb2RlbCBiZWxvdyknIH0sXG5cdFx0Li4uZGlzY292ZXJlZERldmljZXMubWFwKChkKSA9PiAoe1xuXHRcdFx0aWQ6IGQubWFjID8/ICcnLFxuXHRcdFx0bGFiZWw6IGBNb2RlbCAke2QubW9kZWx9IFske2QubWFjfV0gQCAke2QuaXB9YCxcblx0XHR9KSksXG5cdF1cblxuXHRyZXR1cm4gW1xuXHRcdC8vIFx1MjUwMFx1MjUwMCBEZXZpY2Ugc2VsZWN0aW9uIGRyb3Bkb3duIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFN0b3JlcyB0aGUgTUFDIHNvIHJlLWRpc2NvdmVyeSB3aXRoIGEgY2hhbmdlZCBJUCBzdGlsbCBtYXRjaGVzLlxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2RldmljZU1hYycsXG5cdFx0XHRsYWJlbDogJ0RldmljZScsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0Y2hvaWNlczogZGV2aWNlQ2hvaWNlcyxcblx0XHRcdHRvb2x0aXA6ICdTZWxlY3QgYW4gYXV0by1kaXNjb3ZlcmVkIFN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlLCBvciBjaG9vc2UgTWFudWFsIHRvIGVudGVyIGFuIElQIGFkZHJlc3MuJyxcblx0XHR9LFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIE1hbnVhbCBJUCBlbnRyeSBcdTIwMTQgb25seSB2aXNpYmxlIGluIG1hbnVhbCBtb2RlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdHtcblx0XHRcdHR5cGU6ICd0ZXh0aW5wdXQnLFxuXHRcdFx0aWQ6ICdob3N0Jyxcblx0XHRcdGxhYmVsOiAnVGFyZ2V0IElQJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRyZWdleDogUmVnZXguSVAsXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkZXZpY2VNYWMpYCxcblx0XHRcdHRvb2x0aXA6ICdFbnRlciB0aGUgSVAgYWRkcmVzcyBvZiB0aGUgZGV2aWNlIG1hbnVhbGx5LicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNYW51YWwgbW9kZWwgc2VsZWN0b3IgXHUyMDE0IG9ubHkgdmlzaWJsZSBpbiBtYW51YWwgbW9kZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHR7XG5cdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0aWQ6ICdhY3RpdmVNb2RlbCcsXG5cdFx0XHRsYWJlbDogJ0FjdGl2ZSBEZXZpY2UgTW9kZWwnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiBtb2RlbHNbMF0gPz8gJycsXG5cdFx0XHRjaG9pY2VzOiBtb2RlbHMubWFwKChtb2RlbCkgPT4gKHtcblx0XHRcdFx0aWQ6IG1vZGVsLFxuXHRcdFx0XHRsYWJlbDogYE1vZGVsICR7bW9kZWx9YCxcblx0XHRcdH0pKSxcblx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246IGAhJChvcHRpb25zOmRldmljZU1hYylgLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCB3aGljaCBTdHVkaW8gVGVjaG5vbG9naWVzIG1vZGVsIGlzIGFjdGl2ZSBmb3IgYWN0aW9ucyBhbmQgZmVlZGJhY2tzLicsXG5cdFx0fSxcblx0XVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLlxuICogQXV0byBtb2RlIChkZXZpY2VNYWMgc2V0KTogZmluZHMgdGhlIGN1cnJlbnQgSVAgb2YgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIHdpdGggdGhhdCBNQUMuXG4gKiBNYW51YWwgbW9kZSAoZGV2aWNlTWFjIGVtcHR5KTogcmV0dXJucyB0aGUgbWFudWFsbHkgZW50ZXJlZCBob3N0IElQLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUhvc3QoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRldmljZU1hYykge1xuXHRcdGNvbnN0IGRldmljZSA9IGRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQubWFjID09PSBjb25maWcuZGV2aWNlTWFjKVxuXHRcdHJldHVybiBkZXZpY2U/LmlwID8/ICcnXG5cdH1cblx0cmV0dXJuIFN0cmluZyhjb25maWcuaG9zdCA/PyAnJylcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgbW9kZWwuXG4gKiBBdXRvIG1vZGU6IHVzZXMgdGhlIG1vZGVsIGZyb20gdGhlIGRpc2NvdmVyZWQgZGV2aWNlIG1hdGNoaW5nIHRoZSBzdG9yZWQgTUFDLlxuICogTWFudWFsIG1vZGU6IHVzZXMgdGhlIG1hbnVhbGx5IHNlbGVjdGVkIGFjdGl2ZU1vZGVsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZU1vZGVsKGNvbmZpZzogTW9kdWxlQ29uZmlnLCBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdKTogc3RyaW5nIHtcblx0aWYgKGNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRjb25zdCBkZXZpY2UgPSBkaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gY29uZmlnLmRldmljZU1hYylcblx0XHRsb2dnZXIuZGVidWcoYHJlc29sdmVNb2RlbDogZGV2aWNlTWFjPVwiJHtjb25maWcuZGV2aWNlTWFjfVwiLCBmb3VuZCBkZXZpY2U6ICR7ZGV2aWNlPy5tb2RlbCA/PyAnbm9uZSd9YClcblx0XHRyZXR1cm4gZGV2aWNlPy5tb2RlbCA/PyAnJ1xuXHR9XG5cdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBtYW51YWwgbW9kZSwgYWN0aXZlTW9kZWw9XCIke2NvbmZpZy5hY3RpdmVNb2RlbH1cImApXG5cdHJldHVybiBTdHJpbmcoY29uZmlnLmFjdGl2ZU1vZGVsID8/ICcnKVxufVxuIiwgImltcG9ydCB0eXBlIE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcblxuLyoqXG4gKiBEZWZpbmUgQ29tcGFuaW9uIHZhcmlhYmxlcyBmb3IgdGhpcyBtb2R1bGUuXG4gKiBWYXJpYWJsZXMgY2FuIGJlIHVzZWQgdG8gZGlzcGxheSBkeW5hbWljIHN0YXRlIGluIGJ1dHRvbiBsYWJlbHMsIHRyaWdnZXJzLCBldGMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh7XG5cdFx0bW9kZWw6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOdW1iZXInIH0sXG5cdFx0bW9kZWxOYW1lOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTmFtZSAoRnVsbCBEZXNjcmlwdGlvbiknIH0sXG5cdFx0bWFudWZhY3R1cmVyOiB7IG5hbWU6ICdEZXZpY2UgTWFudWZhY3R1cmVyJyB9LFxuXHRcdGZpcm13YXJlOiB7IG5hbWU6ICdEZXZpY2UgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRkYW50ZUZXOiB7IG5hbWU6ICdEYW50ZSBNb2R1bGUgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRtYWM6IHsgbmFtZTogJ0RldmljZSBNQUMgQWRkcmVzcycgfSxcblx0XHRpcDogeyBuYW1lOiAnRGV2aWNlIElQIEFkZHJlc3MnIH0sXG5cdH0pXG59XG5cbmNvbnN0IENMRUFSRURfVkFSSUFCTEVTID0ge1xuXHRtb2RlbDogJycsXG5cdG1vZGVsTmFtZTogJycsXG5cdG1hbnVmYWN0dXJlcjogJycsXG5cdGZpcm13YXJlOiAnJyxcblx0ZGFudGVGVzogJycsXG5cdG1hYzogJycsXG5cdGlwOiAnJyxcbn1cblxuLyoqXG4gKiBVcGRhdGUgdmFyaWFibGUgdmFsdWVzIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaW5mb3JtYXRpb24uXG4gKiBPbmx5IHBvcHVsYXRlcyB2YXJpYWJsZXMgd2hlbiB0aGUgY3VycmVudCBob3N0IGlzIGF1dGhvcml6ZWQuXG4gKiBDbGVhcnMgYWxsIHZhcmlhYmxlcyBpZiB0aGUgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkIG9yIG5vdCBmb3VuZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IGN1cnJlbnRIb3N0ID0gc2VsZi5ob3N0XG5cblx0Ly8gQ2xlYXIgdmFyaWFibGVzIGlmIG5vIGhvc3QgY29uZmlndXJlZCBvciBkZXZpY2UgaXMgbm90IGF1dGhvcml6ZWRcblx0aWYgKCFjdXJyZW50SG9zdCB8fCAhc2VsZi5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKGN1cnJlbnRIb3N0KSkge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoQ0xFQVJFRF9WQVJJQUJMRVMpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBkZXZpY2UgPSBzZWxmLmRldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY3VycmVudEhvc3QpXG5cdGlmIChkZXZpY2UpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdG1vZGVsOiBkZXZpY2UubW9kZWwgfHwgJycsXG5cdFx0XHRtb2RlbE5hbWU6IGRldmljZS5tb2RlbE5hbWUgfHwgJycsXG5cdFx0XHRtYW51ZmFjdHVyZXI6IGRldmljZS5tYW51ZmFjdHVyZXIgfHwgJycsXG5cdFx0XHRmaXJtd2FyZTogZGV2aWNlLmZpcm13YXJlTWFpbiB8fCAnJyxcblx0XHRcdGRhbnRlRlc6IGRldmljZS5kYW50ZUZpcm13YXJlIHx8ICcnLFxuXHRcdFx0bWFjOiBkZXZpY2UubWFjIHx8ICcnLFxuXHRcdFx0aXA6IGRldmljZS5pcCxcblx0XHR9KVxuXHR9IGVsc2Uge1xuXHRcdC8vIEF1dGhvcml6ZWQgYnV0IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgKG1hbnVhbCBJUCB0aGF0IHByb2JlZCBzdWNjZXNzZnVsbHkpXG5cdFx0Ly8gV2Uga25vdyBpdCdzIHRoZSByaWdodCBkZXZpY2UgYnV0IGRvbid0IGhhdmUgZnVsbCBpbmZvIHlldFxuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0Li4uQ0xFQVJFRF9WQVJJQUJMRVMsXG5cdFx0XHRpcDogY3VycmVudEhvc3QsXG5cdFx0fSlcblx0fVxufVxuIiwgImltcG9ydCB0eXBlIHsgQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG5leHBvcnQgY29uc3QgVXBncmFkZVNjcmlwdHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQ8TW9kdWxlQ29uZmlnPltdID0gW1xuXHQvKlxuXHQgKiBQbGFjZSB5b3VyIHVwZ3JhZGUgc2NyaXB0cyBoZXJlXG5cdCAqIFJlbWVtYmVyIHRoYXQgb25jZSBpdCBoYXMgYmVlbiBhZGRlZCBpdCBjYW5ub3QgYmUgcmVtb3ZlZCFcblx0ICovXG5cdC8vIGZ1bmN0aW9uIChjb250ZXh0LCBwcm9wcykge1xuXHQvLyBcdHJldHVybiB7XG5cdC8vIFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHQvLyBcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHQvLyBcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdC8vIFx0fVxuXHQvLyB9LFxuXVxuIiwgImV4cG9ydCB0eXBlIENvbXBhbmlvbklucHV0Q2hvaWNlID0ge1xuXHRpZDogc3RyaW5nIHwgbnVtYmVyXG5cdGxhYmVsOiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgRGV2aWNlU2V0dGluZyA9IHtcblx0dHlwZTogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVmYXVsdDogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhblxuXHRjaG9pY2VzPzogQ29tcGFuaW9uSW5wdXRDaG9pY2VbXVxufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFID0gMHgwMiAvLyBNaWMgcHJlYW1wIHJhdyBzZXQgKGdhaW4sIHBoYW50b20pIFx1MjAxNCBwb3NpdGlvbmFsIGJ5dGVzLCBubyBzZXR0aW5nIElEc1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBIZWFydGJlYXQgLyBrZWVwYWxpdmUgcGluZ1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfU0VUID0gMHgwNCAvLyBTZXQgc2V0dGluZyBvbiBzcGVjaWZpYyBidXMvY2hhbm5lbFxuZXhwb3J0IGNvbnN0IENNRF9IRUFEUEhPTkUgPSAweDA1IC8vIEhlYWRwaG9uZSBjb250cm9sc1xuZXhwb3J0IGNvbnN0IENNRF9CVVRUT05fTU9ERSA9IDB4MDcgLy8gQnV0dG9uIG1vZGUgY29uZmlndXJhdGlvblxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kc1xuZXhwb3J0IGNvbnN0IENNRF9HRVRfQUxMX1NFVFRJTkdTID0gMHgwYSAvLyBSZXF1ZXN0IGFsbCBjdXJyZW50IHNldHRpbmdzIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX1NFVFRJTkdTX1BVU0ggPSAweDBiIC8vIFVuc29saWNpdGVkIHNldHRpbmdzIHVwZGF0ZSBmcm9tIGRldmljZVxuZXhwb3J0IGNvbnN0IENNRF9ERVZfU1BFQyA9IDB4MGQgLy8gRGV2aWNlLXNwZWNpZmljIHNldHRpbmcgZ2V0L3NldCB3aXRoIEFDS1xuZXhwb3J0IGNvbnN0IENNRF9SRVNFVF9ERVZJQ0UgPSAweDBlIC8vIEZhY3RvcnkgcmVzZXQgY29tbWFuZFxuZXhwb3J0IGNvbnN0IENNRF9HTE9CQUxfTUlDX0tJTEwgPSAweDEwIC8vIEVtZXJnZW5jeSBtaWMga2lsbCAoYWxsIGNoYW5uZWxzKVxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFX0JVUyA9IDB4MTIgLy8gTWljL3ByZWFtcCBzZXR0aW5ncyBwZXIgYnVzIChnYWluLCBwaGFudG9tLCBldGMpXG5leHBvcnQgY29uc3QgQ01EX0NIQU5ORUwgPSAweDE0IC8vIENoYW5uZWwtc3BlY2lmaWMgY29udHJvbHNcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIENvbW1hbmQgTmFtZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29tbWFuZE5hbWUoY21kSWQ6IG51bWJlcik6IHN0cmluZyB7XG5cdHN3aXRjaCAoY21kSWQpIHtcblx0XHRjYXNlIENNRF9HRVRfRklSTVdBUkU6XG5cdFx0XHRyZXR1cm4gJ0dldCBGaXJtd2FyZSBWZXJzaW9uJ1xuXHRcdGNhc2UgQ01EX01JQ19QUkU6XG5cdFx0XHRyZXR1cm4gJ01pYyBQcmVhbXAnXG5cdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdHJldHVybiAnSGVhcnRiZWF0J1xuXHRcdGNhc2UgQ01EX0JVU19TRVQ6XG5cdFx0XHRyZXR1cm4gJ1NldCBCdXMgU2V0dGluZydcblx0XHRjYXNlIENNRF9IRUFEUEhPTkU6XG5cdFx0XHRyZXR1cm4gJ0hlYWRwaG9uZSBDb250cm9sJ1xuXHRcdGNhc2UgQ01EX0JVVFRPTl9NT0RFOlxuXHRcdFx0cmV0dXJuICdCdXR0b24gTW9kZSdcblx0XHRjYXNlIENNRF9TWVNURU06XG5cdFx0XHRyZXR1cm4gJ1N5c3RlbSBDb21tYW5kJ1xuXHRcdGNhc2UgQ01EX0dFVF9BTExfU0VUVElOR1M6XG5cdFx0XHRyZXR1cm4gJ1JlcXVlc3QgQWxsIFNldHRpbmdzJ1xuXHRcdGNhc2UgQ01EX1NFVFRJTkdTX1BVU0g6XG5cdFx0XHRyZXR1cm4gJ1NldHRpbmdzIFB1c2gnXG5cdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6XG5cdFx0XHRyZXR1cm4gJ01pYy9QcmUgQnVzJ1xuXHRcdGNhc2UgQ01EX0RFVl9TUEVDOlxuXHRcdFx0cmV0dXJuICdEZXZpY2UgU2V0dGluZydcblx0XHRjYXNlIENNRF9DSEFOTkVMOlxuXHRcdFx0cmV0dXJuICdDaGFubmVsIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfUkVTRVRfREVWSUNFOlxuXHRcdFx0cmV0dXJuICdSZXNldCBEZXZpY2UnXG5cdFx0Y2FzZSBDTURfR0xPQkFMX01JQ19LSUxMOlxuXHRcdFx0cmV0dXJuICdHbG9iYWwgTWljIEtpbGwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgY21kXzB4JHtjbWRJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIEdlbmVyYXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDcmVhdGVzIGEgY29uc2lzdGVudCBJRCBmb3IgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgc3RhdGUga2V5cy5cbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2J1c0NofV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKGUuZy4sIFwiNTMwNF8xNF8wXzBcIilcbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGhvdXQgYnVzQ2ggKGUuZy4sIFwiNTMwNF8xMl9kXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWtlU2V0dGluZ0lkKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRzZXR0aW5nSWQ6IG51bWJlciB8IHN0cmluZyxcblx0YnVzQ2g/OiBudW1iZXIgfCBzdHJpbmcsXG4pOiBzdHJpbmcge1xuXHRjb25zdCBjbWQgPSB0eXBlb2YgY21kSWQgPT09ICdudW1iZXInID8gY21kSWQudG9TdHJpbmcoMTYpIDogY21kSWRcblx0Y29uc3QgaWQgPSB0eXBlb2Ygc2V0dGluZ0lkID09PSAnbnVtYmVyJyA/IHNldHRpbmdJZC50b1N0cmluZygxNikgOiBzZXR0aW5nSWRcblxuXHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IGNoID0gdHlwZW9mIGJ1c0NoID09PSAnbnVtYmVyJyA/IGJ1c0NoLnRvU3RyaW5nKDE2KSA6IGJ1c0NoXG5cdFx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtjaH1fJHtpZH1gXG5cdH1cblxuXHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2lkfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEhleCBGb3JtYXR0aW5nIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENvbnZlcnRzIGEgbnVtYmVyIHRvIGEgaGV4IHN0cmluZyB3aXRoIDB4IHByZWZpeCBhbmQgcGFkZGluZy5cbiAqIEBwYXJhbSB2YWx1ZSAtIFRoZSBudW1iZXIgdG8gY29udmVydFxuICogQHBhcmFtIHBhZExlbmd0aCAtIE51bWJlciBvZiBoZXggZGlnaXRzIHRvIHBhZCB0byAoZGVmYXVsdDogMilcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGRcIiwgXCIweGZmXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0hleCh2YWx1ZTogbnVtYmVyLCBwYWRMZW5ndGggPSAyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAweCR7dmFsdWUudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KHBhZExlbmd0aCwgJzAnKX1gXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gYXJyYXkgb2YgYnl0ZXMgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4LlxuICogQHBhcmFtIGJ5dGVzIC0gQXJyYXkgb2YgYnl0ZXMgb3IgQnVmZmVyXG4gKiBAcmV0dXJucyBGb3JtYXR0ZWQgaGV4IHN0cmluZyAoZS5nLiwgXCIweDBhZmYxMlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnl0ZXNUb0hleChieXRlczogbnVtYmVyW10gfCBCdWZmZXIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHtBcnJheS5mcm9tKGJ5dGVzKVxuXHRcdC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0LmpvaW4oJycpfWBcbn1cblxuLyoqXG4gKiBGb3JtYXRzIFJHQiBjb2xvciBieXRlcyBhcyBhIENTUyBoZXggY29sb3Igc3RyaW5nLlxuICogQHBhcmFtIHIgLSBSZWQgY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBnIC0gR3JlZW4gY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBiIC0gQmx1ZSBjb21wb25lbnQgKDAtMjU1KVxuICogQHJldHVybnMgQ1NTIGhleCBjb2xvciBzdHJpbmcgKGUuZy4sIFwiI0ZGMDBBQlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UmdiQ29sb3IocjogbnVtYmVyLCBnOiBudW1iZXIsIGI6IG51bWJlcik6IHN0cmluZyB7XG5cdHJldHVybiBgIyR7W3IsIGcsIGJdXG5cdFx0Lm1hcCgodikgPT4gdi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJylcblx0XHQudG9VcHBlckNhc2UoKX1gXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBJRCBQYXJzaW5nIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogUGFyc2VzIGEgc2V0dGluZyBJRCBzdHJpbmcgaW50byBpdHMgY29tcG9uZW50cy5cbiAqIEBwYXJhbSBpZCAtIFNldHRpbmcgSUQgc3RyaW5nIChlLmcuLCBcIjM5MV9kXzBcIiBvciBcIjUzMDRfMTRfMF8xXCIpXG4gKiBAcmV0dXJucyBQYXJzZWQgY29tcG9uZW50cyB3aXRoIGhleCBzdHJpbmdzIGNvbnZlcnRlZCB0byBudW1iZXJzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdJZChpZDogc3RyaW5nKTogeyBtb2RlbDogc3RyaW5nOyBjbWRJZDogbnVtYmVyOyBiYXNlSWQ6IG51bWJlciB9IHtcblx0Y29uc3QgW21vZGVsLCBjbWRJZFN0ciwgaWRTdHJdID0gaWQuc3BsaXQoJ18nKVxuXHRyZXR1cm4ge1xuXHRcdG1vZGVsLFxuXHRcdGNtZElkOiBwYXJzZUludChjbWRJZFN0ciwgMTYpLFxuXHRcdGJhc2VJZDogcGFyc2VJbnQoaWRTdHIsIDE2KSxcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgTW9kZWwgRGlzdGFuY2UgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDYWxjdWxhdGVzIG51bWVyaWMgZGlzdGFuY2UgYmV0d2VlbiB0d28gbW9kZWwgbnVtYmVycy5cbiAqIFVzZWQgZm9yIGZpbmRpbmcgc2ltaWxhciBtb2RlbHMgZm9yIHNldHRpbmcgaW5mZXJlbmNlLlxuICogQHBhcmFtIG1vZGVsQSAtIEZpcnN0IG1vZGVsIG51bWJlciAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBtb2RlbEIgLSBTZWNvbmQgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MlwiKVxuICogQHJldHVybnMgTnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIG1vZGVscywgb3IgSW5maW5pdHkgaWYgZWl0aGVyIGlzIG5vbi1udW1lcmljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb2RlbERpc3RhbmNlKG1vZGVsQTogc3RyaW5nLCBtb2RlbEI6IHN0cmluZyk6IG51bWJlciB7XG5cdGNvbnN0IG5hID0gcGFyc2VJbnQobW9kZWxBLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRjb25zdCBuYiA9IHBhcnNlSW50KG1vZGVsQi5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0aWYgKE51bWJlci5pc05hTihuYSkgfHwgTnVtYmVyLmlzTmFOKG5iKSkgcmV0dXJuIEluZmluaXR5XG5cdHJldHVybiBNYXRoLmFicyhuYSAtIG5iKVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU2NoZW1hIE5vcm1hbGl6YXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBOb3JtYWxpemVzIGRldmljZSBzY2hlbWFzIHRvIGVuc3VyZSBjbWRTY2hlbWEgaXMgYWx3YXlzIGFuIGFycmF5LlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgc2NoZW1hIHRyYW5zZm9ybWF0aW9uIGNvZGUuXG4gKiBAcGFyYW0gc2NoZW1hc1JhdyAtIFJhdyBzY2hlbWFzIGZyb20gZ2V0RGV2aWNlU2NoZW1hcygpXG4gKiBAcmV0dXJucyBOb3JtYWxpemVkIHNjaGVtYXMgd2l0aCBndWFyYW50ZWVkIGNtZFNjaGVtYSBhcnJheXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldE5vcm1hbGl6ZWRTY2hlbWFzKFxuXHRzY2hlbWFzUmF3OiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuKTogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+IHtcblx0Y29uc3Qgbm9ybWFsaXplZDogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+ID0ge31cblx0Zm9yIChjb25zdCBbbW9kZWwsIGpzb25dIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXNSYXcpKSB7XG5cdFx0bm9ybWFsaXplZFttb2RlbF0gPSB7XG5cdFx0XHRtb2RlbDoganNvbi5tb2RlbCxcblx0XHRcdGNtZFNjaGVtYTogQXJyYXkuaXNBcnJheShqc29uLmNtZFNjaGVtYSkgPyBqc29uLmNtZFNjaGVtYSA6IFtdLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4gbm9ybWFsaXplZFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQWN0aW9uIExvb2t1cCBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIEZpbmRzIGFuIGFjdGlvbi9zZXR0aW5nIGluIHRoZSBzY2hlbWEsIHN1cHBvcnRpbmcgYm90aCBleGFjdCBtYXRjaGVzIGFuZCBpZEFkZCBvZmZzZXRzLlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgYWN0aW9uIGxvb2t1cCBsb2dpYyBhY3Jvc3MgbXVsdGlwbGUgZmlsZXMuXG4gKiBAcGFyYW0gc2NoZW1hcyAtIE5vcm1hbGl6ZWQgZGV2aWNlIHNjaGVtYXNcbiAqIEBwYXJhbSBtb2RlbCAtIERldmljZSBtb2RlbCAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBjbWRJZCAtIENvbW1hbmQgSURcbiAqIEBwYXJhbSBzZXR0aW5nSWQgLSBTZXR0aW5nIElEIChtYXkgaW5jbHVkZSBpZEFkZCBvZmZzZXQpXG4gKiBAcmV0dXJucyBNYXRjaGluZyBhY3Rpb24vc2V0dGluZyBvciB1bmRlZmluZWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmRBY3Rpb25Gb3JTZXR0aW5nKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0aWYgKCFzY2hlbWEgfHwgIUFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkpIHJldHVybiB1bmRlZmluZWRcblxuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IHNjaGVtYS5jbWRTY2hlbWEuZmluZCgoczogYW55KSA9PiBzLmNtZF9pZCA9PT0gY21kSWQgJiYgcy5pZCA9PT0gc2V0dGluZ0lkKVxuXG5cdC8vIElmIG5vIGV4YWN0IG1hdGNoLCB0cnkgdG8gZmluZCBiYXNlIGFjdGlvbiB3aXRoIGlkQWRkXG5cdGlmICghYWN0aW9uKSB7XG5cdFx0YWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHtcblx0XHRcdGlmIChzLmNtZF9pZCAhPT0gY21kSWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBzLm9wdGlvbnM/LmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHNldHRpbmdJZCBtYXRjaGVzIGJhc2UgKyBhbnkgaWRBZGQgb2Zmc2V0XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBzZXR0aW5nSWQgLSBzLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvblxufVxuIiwgIi8qKlxuICogYnVpbGQtY29tbWFuZHMudHNcbiAqIC0gVXNlcyBjZW50cmFsaXplZCBkZXZpY2Ugc2NoZW1hIGNhY2hlIGZyb20gY29uZmlnLnRzXG4gKiAtIFByb2R1Y2VzIENvbXBhbmlvbiBhY3Rpb24gZGVmaW5pdGlvbnMgYW5kIGZlZWRiYWNrc1xuICovXG5cbmltcG9ydCB7XG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zLFxuXHRDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uLFxuXHRDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgbWFrZVNldHRpbmdJZCB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0gT3B0aW9uIEJ1aWxkZXIgLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZnVuY3Rpb24gYnVpbGRPcHRpb24obzogYW55KTogYW55IHtcblx0Y29uc3QgYmFzZSA9IHtcblx0XHR0eXBlOiBvLnR5cGUsXG5cdFx0aWQ6IG8uaWQsXG5cdFx0bGFiZWw6IG8ubGFiZWwsXG5cdFx0ZGVmYXVsdDogby5kZWZhdWx0LFxuXHRcdHRvb2x0aXA6IG8udG9vbHRpcCxcblx0fVxuXG5cdHN3aXRjaCAoby50eXBlKSB7XG5cdFx0Y2FzZSAnZHJvcGRvd24nOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgY2hvaWNlczogby5jaG9pY2VzID8/IFtdIH1cblxuXHRcdGNhc2UgJ251bWJlcic6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5iYXNlLFxuXHRcdFx0XHRtaW46IG8ubWluLFxuXHRcdFx0XHRtYXg6IG8ubWF4LFxuXHRcdFx0XHRzdGVwOiBvLnN0ZXAgPz8gMSxcblx0XHRcdFx0cmFuZ2U6IHRydWUsXG5cdFx0XHR9XG5cblx0XHRjYXNlICdjaGVja2JveCc6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBkZWZhdWx0OiBvLmRlZmF1bHQgPz8gZmFsc2UgfVxuXG5cdFx0Y2FzZSAnc3RhdGljLXRleHQnOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgdmFsdWU6IG8udmFsdWUgPz8gJycgfVxuXG5cdFx0Y2FzZSAndGV4dGlucHV0Jzpcblx0XHRjYXNlICdjb2xvcnBpY2tlcic6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIGEuY21kX2lkLCBhLmlkKVxuXG5cdFx0XHRjb25zdCBvcHRpb25zID0gKGEub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHRjb25zdCBhY3Rpb246IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHthLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVBY3Rpb25zICovXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGFjdGlvbnNbYWN0aW9uSWRdID0gYWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvbnNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBGZWVkYmFja3MgLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGZWVkYmFja3MoKTogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgZmVlZGJhY2tzOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3Qgc2V0dGluZyBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0lkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgc2V0dGluZy5jbWRfaWQsIHNldHRpbmcuaWQpXG5cblx0XHRcdC8vIEJ1aWxkIG9wdGlvbnNcblx0XHRcdGNvbnN0IGFsbE9wdGlvbnMgPSAoc2V0dGluZy5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdC8vIEZpbHRlciBvdXQgJ3ZhbHVlJyBvcHRpb24gZm9yIHZhbHVlIGZlZWRiYWNrIChrZWVwIG9ubHkgYnVzQ2gvaWRBZGQpXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbnMgPSBhbGxPcHRpb25zLmZpbHRlcigob3B0OiBhbnkpID0+IG9wdC5pZCAhPT0gJ3ZhbHVlJylcblxuXHRcdFx0Ly8gQWRkIGEgY2hlY2tib3ggb3B0aW9uIHRvIHJldHVybiBsYWJlbCBpbnN0ZWFkIG9mIHZhbHVlXG5cdFx0XHR2YWx1ZU9wdGlvbnMucHVzaCh7XG5cdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0bGFiZWw6ICdTaG93IExhYmVsJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHR9KVxuXG5cdFx0XHQvLyBWYWx1ZSBmZWVkYmFjayBmb3IgYWxsIHNldHRpbmdzIChhcHBlYXJzIGluIFZhcmlhYmxlcyBsaXN0KVxuXHRcdFx0Y29uc3QgdmFsdWVGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHR0eXBlOiAndmFsdWUnLFxuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnM6IHZhbHVlT3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRyZXR1cm4gMFxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRmZWVkYmFja3NbYmFzZUZlZWRiYWNrSWRdID0gdmFsdWVGZWVkYmFja1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IGdldERldmljZXNGb2xkZXIsIGdldERldmljZVNjaGVtYSwgZ2V0RGV2aWNlU2NoZW1hcywgcmVsb2FkRGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuXG5pbXBvcnQgeyBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbiwgc2F2ZU1vZGVsSnNvblByZXR0eSwgdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzIH0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdBY3Rpb25zJylcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUFjdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdBY3Rpb25zID0gYnVpbGRBY3Rpb25zKClcblx0Y29uc3Qgc2NoZW1hcyA9IGdldE5vcm1hbGl6ZWRTY2hlbWFzKHNjaGVtYXNSYXcpXG5cdGNvbnN0IHdpcmVkQWN0aW9uczogYW55ID0ge31cblxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEdMT0JBTDogR0VUIEFMTCBTRVRUSU5HUyAoQVVUTyBKU09OIFVQREFURSlcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0d2lyZWRBY3Rpb25zWydnbG9iYWxfZ2V0QWxsU2V0dGluZ3MnXSA9IHtcblx0XHRuYW1lOiAnR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzIChBdXRvLVVwZGF0ZSBKU09OKScsXG5cdFx0b3B0aW9uczogW10sXG5cdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdGNvbnN0IG1vZGVsID0gYWN0aXZlTW9kZWxcblx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cblx0XHRcdGNvbnN0IGJ1ZiA9IGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIHRvIGdldCB0aGUgc2NoZW1hIChtYXkgYmUgbnVsbCBmb3IgbmV3L3Vua25vd24gZGV2aWNlcylcblx0XHRcdGxldCBtb2RlbEpzb24gPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cblx0XHRcdC8vIFBhcnNlIHdpdGggYXV0by1kZXRlY3Rpb25cblx0XHRcdGNvbnN0IHsgc2V0dGluZ3M6IHBhcnNlZCwgZGV0ZWN0ZWRTZWN0aW9uZWQgfSA9IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uKG1vZGVsLCBidWYpXG5cdFx0XHRsb2dnZXIuZGVidWcoYHBhcnNlZCByZXBseTogJHtKU09OLnN0cmluZ2lmeShwYXJzZWQpfWApXG5cblx0XHRcdGlmICghbW9kZWxKc29uKSB7XG5cdFx0XHRcdC8vIE5vIHNjaGVtYSB5ZXQgXHUyMDE0IGNyZWF0ZSBhIG1pbmltYWwgb25lIGZyb20gdGhlIHBhcnNlZCBzZXR0aW5nc1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gaGFzIG5vIHNjaGVtYSBcdTIwMTQgY3JlYXRpbmcgbmV3IEpTT04gZnJvbSBzZXR0aW5nc2ApXG5cdFx0XHRcdG1vZGVsSnNvbiA9IHtcblx0XHRcdFx0XHRtb2RlbCxcblx0XHRcdFx0XHRzZWN0aW9uZWQ6IGRldGVjdGVkU2VjdGlvbmVkID8/IGZhbHNlLFxuXHRcdFx0XHRcdHJlZnJlc2hBZnRlckNvbW1hbmQ6IHRydWUsXG5cdFx0XHRcdFx0Y21kU2NoZW1hOiBbXSxcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIGlmIChkZXRlY3RlZFNlY3Rpb25lZCAhPT0gbnVsbCkge1xuXHRcdFx0XHQvLyBJZiB3ZSBhdXRvLWRldGVjdGVkIHRoZSBmb3JtYXQsIGFkZCBpdCB0byB0aGUgSlNPTlxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBzZWN0aW9uZWQ9JHtkZXRlY3RlZFNlY3Rpb25lZH0sIGFkZGluZyB0byBtb2RlbCBKU09OYClcblx0XHRcdFx0bW9kZWxKc29uID0geyAuLi5tb2RlbEpzb24sIHNlY3Rpb25lZDogZGV0ZWN0ZWRTZWN0aW9uZWQgfVxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCB1cGRhdGVkID0gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKG1vZGVsSnNvbiwgcGFyc2VkLCBzY2hlbWFzKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBuZXcgQWN0aW9ucyBqc29uOiAke0pTT04uc3RyaW5naWZ5KHVwZGF0ZWQsIG51bGwsIDIpfWApXG5cblx0XHRcdC8vIFNhdmUgdGhlIHVwZGF0ZWQgSlNPTiB0byBkaXNrXG5cdFx0XHRjb25zdCBkZXZpY2VzRm9sZGVyID0gZ2V0RGV2aWNlc0ZvbGRlcigpXG5cdFx0XHRjb25zdCBzY2hlbWFQYXRoID0gcGF0aC5qb2luKGRldmljZXNGb2xkZXIsIGBNb2RlbCR7bW9kZWx9Lmpzb25gKVxuXHRcdFx0c2F2ZU1vZGVsSnNvblByZXR0eShzY2hlbWFQYXRoLCB1cGRhdGVkKVxuXG5cdFx0XHQvLyBSZWxvYWQgdGhlIGNhY2hlIGFmdGVyIHdyaXRpbmcgdG8gZmlsZVxuXHRcdFx0cmVsb2FkRGV2aWNlU2NoZW1hcygpXG5cblx0XHRcdGxvZ2dlci5pbmZvKGBNb2RlbCAke21vZGVsfSBKU09OIGF1dG8tdXBkYXRlZCBmcm9tIGdldEFsbFNldHRpbmdzYClcblx0XHR9LFxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBCVUlMRCBQRVItU0VUVElORyBBQ1RJT05TIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2FjdGlvbklkLCBhY3Rpb25dIG9mIE9iamVjdC5lbnRyaWVzKHJhd0FjdGlvbnMpKSB7XG5cdFx0Y29uc3QgeyBtb2RlbCwgY21kSWQsIGJhc2VJZCB9ID0gcGFyc2VTZXR0aW5nSWQoYWN0aW9uSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgYWN0aW9ucyBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgbW9kZWxcblx0XHRpZiAobW9kZWwgIT09IGFjdGl2ZU1vZGVsKSBjb250aW51ZVxuXG5cdFx0Ly8gR2V0IHRoZSByYXcgYWN0aW9uIHNjaGVtYSB0byBhY2Nlc3MgZml4ZWQgYnVzQ2ggdmFsdWVcblx0XHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRcdGNvbnN0IHJhd0FjdGlvbiA9IHNjaGVtYT8uY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBiYXNlSWQpXG5cblx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0Li4uYWN0aW9uLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jIChldmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSAhPT0gdW5kZWZpbmVkID8gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSA6IHJhd0FjdGlvbj8uYnVzQ2hcblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBldmVudC5vcHRpb25zWyd2YWx1ZSddXG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cblx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIuc2VuZEF3YWl0QWNrKGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgaXApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgTUlDIEtJTEwgKE9OTFkgSUYgQUNUSVZFIE1PREVMIFNVUFBPUlRTIElUKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Y29uc3QgYWN0aXZlU2NoZW1hID0gc2NoZW1hc1thY3RpdmVNb2RlbF1cblx0aWYgKGFjdGl2ZVNjaGVtYSkge1xuXHRcdGNvbnN0IHN1cHBvcnRzTWljS2lsbCA9IChhY3RpdmVTY2hlbWEuY21kU2NoZW1hID8/IFtdKS5zb21lKChhOiBhbnkpID0+IGEubmFtZS5pbmNsdWRlcygnS2lsbCcpKVxuXG5cdFx0aWYgKHN1cHBvcnRzTWljS2lsbCkge1xuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBgJHthY3RpdmVNb2RlbH1fbWljS2lsbGBcblxuXHRcdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7YWN0aXZlTW9kZWx9XSBNaWMgS2lsbGAsXG5cdFx0XHRcdG9wdGlvbnM6IFtdLFxuXHRcdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYE1pYyBLaWxsIFx1MjE5MiBNb2RlbCAke2FjdGl2ZU1vZGVsfSBAICR7aXB9YClcblx0XHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5nbG9iYWxNaWNLaWxsKGlwKVxuXHRcdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcCkuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byByZWZyZXNoIHNldHRpbmdzIGFmdGVyIGNvbW1hbmQ6ICR7ZXJyfWApXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSxcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEFjdGlvbkRlZmluaXRpb25zKHdpcmVkQWN0aW9ucylcblxuXHQvL2NvbnNvbGUubG9nKCdBY3Rpb25zOlxcbicsIEpTT04uc3RyaW5naWZ5KHdpcmVkQWN0aW9ucywgbnVsbCwgMikpXG59XG4iLCAiaW1wb3J0IGZzIGZyb20gJ2ZzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHtcblx0Q01EX01JQ19QUkUsXG5cdENNRF9CVVNfU0VULFxuXHRDTURfQ0hBTk5FTCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdGZvcm1hdFJnYkNvbG9yLFxuXHRtb2RlbERpc3RhbmNlLFxufSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1NldHRpbmdzUGFyc2VyJylcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVFlQRVNcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IHR5cGUgUGFyc2VkU2V0dGluZyA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRidXNDaD86IG51bWJlciAvLyBPcHRpb25hbDogb25seSBwcmVzZW50IGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoICgweDA0LCAweDEyLCAweDE0KVxuXHR2YWx1ZUJ5dGVzOiBudW1iZXJbXVxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbk9wdGlvbiA9IHtcblx0aWQ/OiBzdHJpbmdcblx0bGFiZWw6IHN0cmluZ1xuXHR0eXBlOiBzdHJpbmdcblx0ZGVmYXVsdDogdW5rbm93blxuXHR0b29sdGlwPzogc3RyaW5nXG5cdGNob2ljZXM/OiBBcnJheTx7IGlkOiBudW1iZXI7IGxhYmVsOiBzdHJpbmcgfT5cbn1cblxuZXhwb3J0IHR5cGUgU3RBY3Rpb24gPSB7XG5cdGNtZF9pZDogbnVtYmVyXG5cdGlkOiBudW1iZXJcblx0bmFtZTogc3RyaW5nXG5cdG9wdGlvbnM6IFN0QWN0aW9uT3B0aW9uW11cblx0YnVzQ2g/OiBudW1iZXIgLy8gRml4ZWQgY2hhbm5lbCB2YWx1ZSBmb3IgYWN0aW9ucyB0aGF0IGRvbid0IGhhdmUgYSBjaGFubmVsIG9wdGlvblxufVxuXG5leHBvcnQgdHlwZSBTdE1vZGVsSnNvbiA9IHtcblx0bW9kZWw6IHN0cmluZ1xuXHRzZWN0aW9uZWQ/OiBib29sZWFuXG5cdHJlZnJlc2hBZnRlckNvbW1hbmQ/OiBib29sZWFuXG5cdGNtZFNjaGVtYTogU3RBY3Rpb25bXVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGT1JNQVQgSEVMUEVSU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBnZXRNb2RlbENvbmZpZyhtb2RlbDogc3RyaW5nKTogeyBzZWN0aW9uZWQ6IGJvb2xlYW47IHJnYklkczogU2V0PG51bWJlcj4gfSB7XG5cdGNvbnN0IHJnYklkcyA9IG5ldyBTZXQ8bnVtYmVyPigpXG5cdGxldCBzZWN0aW9uZWQgPSBmYWxzZVxuXG5cdHRyeSB7XG5cdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIGluc3RlYWQgb2YgcmVhZGluZyBmcm9tIGRpc2tcblx0XHRjb25zdCBqc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghanNvbikge1xuXHRcdFx0Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgc2NoZW1hLCByZXR1cm4gZGVmYXVsdHNcblx0XHRcdHJldHVybiB7IHNlY3Rpb25lZCwgcmdiSWRzIH1cblx0XHR9XG5cblx0XHQvLyBSZWFkIHNlY3Rpb25lZCBwcm9wZXJ0eSAoZGVmYXVsdCB0byBmYWxzZSBpZiBub3Qgc3BlY2lmaWVkKVxuXHRcdHNlY3Rpb25lZCA9IGpzb24uc2VjdGlvbmVkID8/IGZhbHNlXG5cblx0XHQvLyBCdWlsZCBSR0IgSURzIHNldFxuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHQvLyBBZGQgdGhlIGJhc2UgSURcblx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQpXG5cblx0XHRcdFx0Ly8gSWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkIGNob2ljZXMsIGFkZCBhbGwgdGhlIG9mZnNldCBJRHMgdG9vXG5cdFx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjaG9pY2Ugb2YgaWRBZGRPcHRpb24uY2hvaWNlcykge1xuXHRcdFx0XHRcdFx0aWYgKHR5cGVvZiBjaG9pY2UuaWQgPT09ICdudW1iZXInKSB7XG5cdFx0XHRcdFx0XHRcdHJnYklkcy5hZGQoYWN0aW9uLmlkICsgY2hvaWNlLmlkKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCAoX2Vycikge1xuXHRcdC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHNjaGVtYSwgcmV0dXJuIGRlZmF1bHRzXG5cdH1cblxuXHRyZXR1cm4geyBzZWN0aW9uZWQsIHJnYklkcyB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZJTkQgVEhFIFJFQUwgNUEgUEFZTE9BRCBJTkRFWFxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmOiBCdWZmZXIpOiBudW1iZXIge1xuXHRjb25zdCBzaWdJbmRleCA9IGJ1Zi5pbmRleE9mKEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcpKVxuXHRpZiAoc2lnSW5kZXggPCAwKSB0aHJvdyBuZXcgRXJyb3IoJ05vIFN0dWRpby1UIHNpZ25hdHVyZSBpbiBwYWNrZXQnKVxuXG5cdGNvbnN0IHBheWxvYWRJbmRleCA9IHNpZ0luZGV4ICsgOFxuXHRpZiAoYnVmW3BheWxvYWRJbmRleF0gIT09IDB4NWEpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIDB4NUEgYWZ0ZXIgU3R1ZGlvLVQsIGZvdW5kICR7YnVmW3BheWxvYWRJbmRleF0udG9TdHJpbmcoMTYpfWApXG5cdH1cblxuXHRyZXR1cm4gcGF5bG9hZEluZGV4XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZMQVQgUEFSU0VSXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYmxvY2s6IEJ1ZmZlciwgcmdiSWRzOiBTZXQ8bnVtYmVyPiA9IG5ldyBTZXQoKSk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGxldCBwID0gMFxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0d2hpbGUgKHAgPCBibG9jay5sZW5ndGgpIHtcblx0XHRjb25zdCBpZCA9IGJsb2NrW3BdXG5cdFx0aWYgKHAgKyAxID49IGJsb2NrLmxlbmd0aCkgYnJlYWtcblxuXHRcdC8vIFJHQiBjYXNlIC0gY2hlY2sgaWYgdGhpcyBJRCBpcyBhIGtub3duIGNvbG9ycGlja2VyXG5cdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHAgKyAzIDwgYmxvY2subGVuZ3RoKSB7XG5cdFx0XHRvdXQucHVzaCh7XG5cdFx0XHRcdGNtZF9pZDogQ01EX0RFVl9TUEVDLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXSwgYmxvY2tbcCArIDJdLCBibG9ja1twICsgM11dLFxuXHRcdFx0fSlcblx0XHRcdHAgKz0gNFxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHRvdXQucHVzaCh7IGNtZF9pZDogQ01EX0RFVl9TUEVDLCBpZCwgdmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXV0gfSlcblx0XHRwICs9IDJcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Y29uc3QgYmxvY2tMZW4gPSBidWZbaWR4ICsgMl1cblx0Y29uc3Qgc3RhcnQgPSBpZHggKyAzXG5cdGNvbnN0IGVuZCA9IHN0YXJ0ICsgYmxvY2tMZW5cblx0aWYgKGVuZCA+IGJ1Zi5sZW5ndGgpIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBibG9jayBsZW5ndGgnKVxuXG5cdGNvbnN0IHsgcmdiSWRzIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYnVmLnN1YmFycmF5KHN0YXJ0LCBlbmQpLCByZ2JJZHMpXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNFQ1RJT05FRCBQQVJTRVJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZjogQnVmZmVyLCBtb2RlbDogc3RyaW5nKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgYSBnZXRBbGxTZXR0aW5ncyByZXBseScpXG5cdH1cblxuXHQvLyBDTURfR0VUX0FMTF9TRVRUSU5HUyBoYXMgYSB0b3RhbC1sZW5ndGggYnl0ZSBhdCBpZHgrMiBiZWZvcmUgdGhlIHNlY3Rpb25zOyBDTURfU0VUVElOR1NfUFVTSCBkb2VzIG5vdC5cblx0bGV0IHAgPSBjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgPyBpZHggKyAzIDogaWR4ICsgMlxuXHRjb25zdCBlbmQgPSBidWYubGVuZ3RoIC0gMVxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0Ly8gR2V0IFJHQiBJRHMgZm9yIHRoaXMgbW9kZWxcblx0Y29uc3QgeyByZ2JJZHMgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgaW4gdGhlaXIgc2VjdGlvbiBzdHJ1Y3R1cmUsXG5cdC8vIGZvbGxvd2VkIGJ5IGEgZGF0YUxlbiBieXRlIGFuZCB0aGVuIGlkOnZhbCBwYWlycy5cblx0Y29uc3QgY29tbWFuZHNXaXRoQnVzQ2ggPSBbQ01EX0JVU19TRVQsIENNRF9NSUNfUFJFX0JVUywgQ01EX0NIQU5ORUxdXG5cblx0Ly8gQ29tbWFuZCBJRHMgdGhhdCBpbmNsdWRlIGEgYnVzQ2ggYnl0ZSBidXQgc3RvcmUgcmF3IHBvc2l0aW9uYWwgdmFsdWUgYnl0ZXNcblx0Ly8gcmF0aGVyIHRoYW4gaWQ6dmFsIHBhaXJzIChubyBkYXRhTGVuIGJ5dGUsIG5vIHNldHRpbmcgSURzKS5cblx0Ly8gRm9ybWF0OiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW3ZhbDBdIFt2YWwxXSAuLi5cblx0Y29uc3QgY29tbWFuZHNSYXdWYWx1ZSA9IFtDTURfTUlDX1BSRV0gLy8gY21kPTB4MDJcblxuXHR3aGlsZSAocCArIDIgPCBlbmQpIHtcblx0XHRjb25zdCBjbWRMZW4gPSBidWZbcF1cblx0XHRjb25zdCBzZWN0aW9uQ21kSWQgPSBidWZbcCArIDFdXG5cblx0XHRjb25zdCBzZWN0aW9uRW5kID0gcCArIDEgKyBjbWRMZW5cblx0XHRpZiAoc2VjdGlvbkVuZCA+IGVuZCkgYnJlYWtcblxuXHRcdGNvbnN0IGhhc0J1c0NoID0gY29tbWFuZHNXaXRoQnVzQ2guaW5jbHVkZXMoc2VjdGlvbkNtZElkKVxuXHRcdGNvbnN0IGlzUmF3VmFsdWUgPSBjb21tYW5kc1Jhd1ZhbHVlLmluY2x1ZGVzKHNlY3Rpb25DbWRJZClcblxuXHRcdGxldCBidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkXG5cdFx0bGV0IGRhdGFMZW46IG51bWJlclxuXHRcdGxldCBxOiBudW1iZXJcblxuXHRcdGlmIChpc1Jhd1ZhbHVlKSB7XG5cdFx0XHQvLyBTdHJ1Y3R1cmU6IFtjbWRMZW5dIFtjbWRJZF0gW2J1c0NoXSBbdmFsMF0gW3ZhbDFdIC4uLlxuXHRcdFx0Ly8gRW1pdCBlYWNoIHZhbHVlIGJ5dGUgYXMgYSBzZXBhcmF0ZSBQYXJzZWRTZXR0aW5nIHdpdGggcG9zaXRpb25hbCBpZC5cblx0XHRcdC8vIENNRF9NSUNfUFJFICgweDAyKSBwb3NpdGlvbmFsIHNsb3RzIGFyZSByZW1hcHBlZCB0byBDTURfTUlDX1BSRV9CVVMgKDB4MTIpXG5cdFx0XHQvLyBpZDp2YWwgZm9ybWF0IHNvIHRoYXQgc3RhdGUga2V5cyBtYXRjaCB0aGUgU0VUIGNvbW1hbmQgc3RydWN0dXJlIHVzZWQgYnlcblx0XHRcdC8vIGZlZWRiYWNrcyBhbmQgYWN0aW9ucy4gTWFwcGluZzogcG9zMFx1MjE5MmlkMSAoZ2FpbiksIHBvczFcdTIxOTJpZDIgKHBoYW50b20vZWxlY3RyZXQpLFxuXHRcdFx0Ly8gcG9zMisgYXJlIHVua25vd24vdW51c2VkIGFuZCBkcm9wcGVkLlxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRjb25zdCByYXdCeXRlcyA9IGJ1Zi5zdWJhcnJheShwICsgMywgc2VjdGlvbkVuZClcblx0XHRcdGNvbnN0IG1pY1ByZVJlbWFwOiBBcnJheTxudW1iZXIgfCBudWxsPiA9IFsxLCAyXSAvLyBwb3MwXHUyMTkyaWQxLCBwb3MxXHUyMTkyaWQyLCBwb3MyK1x1MjE5MmRyb3Bcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgcmF3Qnl0ZXMubGVuZ3RoOyBpKyspIHtcblx0XHRcdFx0aWYgKHNlY3Rpb25DbWRJZCA9PT0gQ01EX01JQ19QUkUpIHtcblx0XHRcdFx0XHRjb25zdCByZW1hcHBlZElkID0gaSA8IG1pY1ByZVJlbWFwLmxlbmd0aCA/IG1pY1ByZVJlbWFwW2ldIDogbnVsbFxuXHRcdFx0XHRcdGlmIChyZW1hcHBlZElkICE9PSBudWxsKSB7XG5cdFx0XHRcdFx0XHRvdXQucHVzaCh7IGNtZF9pZDogQ01EX01JQ19QUkVfQlVTLCBpZDogcmVtYXBwZWRJZCwgYnVzQ2gsIHZhbHVlQnl0ZXM6IFtyYXdCeXRlc1tpXV0gfSlcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0b3V0LnB1c2goeyBjbWRfaWQ6IHNlY3Rpb25DbWRJZCwgaWQ6IGksIGJ1c0NoLCB2YWx1ZUJ5dGVzOiBbcmF3Qnl0ZXNbaV1dIH0pXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHAgPSBzZWN0aW9uRW5kXG5cdFx0XHRjb250aW51ZVxuXHRcdH0gZWxzZSBpZiAoaGFzQnVzQ2gpIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRkYXRhTGVuID0gYnVmW3AgKyAzXVxuXHRcdFx0cSA9IHAgKyA0XG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbZGF0YUxlbl0gW2lkOnZhbCBwYWlyc11cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDJdXG5cdFx0XHRxID0gcCArIDNcblx0XHR9XG5cblx0XHRjb25zdCBxRW5kID0gcSArIGRhdGFMZW5cblx0XHRjb25zdCBxU3RhcnQgPSBxXG5cblx0XHR3aGlsZSAocSArIDEgPCBxRW5kKSB7XG5cdFx0XHRjb25zdCBpZCA9IGJ1ZltxXVxuXHRcdFx0bGV0IHZhbHVlQnl0ZXM6IG51bWJlcltdXG5cblx0XHRcdC8vIENoZWNrIGlmIHRoaXMgSUQgaXMgYW4gUkdCIGNvbG9ycGlja2VyIChuZWVkcyAzIGJ5dGVzKVxuXHRcdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHEgKyAzIDwgcUVuZCkge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV0sIGJ1ZltxICsgMl0sIGJ1ZltxICsgM11dXG5cdFx0XHRcdHEgKz0gNFxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0dmFsdWVCeXRlcyA9IFtidWZbcSArIDFdXVxuXHRcdFx0XHRxICs9IDJcblx0XHRcdH1cblxuXHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHtcblx0XHRcdFx0Y21kX2lkOiBzZWN0aW9uQ21kSWQsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHR2YWx1ZUJ5dGVzLFxuXHRcdFx0fVxuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0c2V0dGluZy5idXNDaCA9IGJ1c0NoXG5cdFx0XHR9XG5cdFx0XHRvdXQucHVzaChzZXR0aW5nKVxuXHRcdH1cblxuXHRcdC8vIFBvc2l0aW9uYWwgZmFsbGJhY2s6IGlmIHRoZSBieXRlIHdlIHJlYWQgYXMgZGF0YUxlbiB3YXMgMHgwMCBidXQgdGhlIHNlY3Rpb25cblx0XHQvLyBzdGlsbCBjb250YWlucyBkYXRhIGJ5dGVzLCB0aGlzIHNlY3Rpb24gbGlrZWx5IHVzZXMgYSBuby1kYXRhTGVuIGZvcm1hdCB3aGVyZVxuXHRcdC8vIGVhY2ggYnl0ZSBhZnRlciBjbWRJZCBpcyBhIHJhdyB2YWx1ZSBhdCBhIGZpeGVkIHBvc2l0aW9uIChwb3NpdGlvbiA9IGlkKS5cblx0XHQvLyBSZS1wYXJzZSBmcm9tIHArMiAocmlnaHQgYWZ0ZXIgY21kSWQpLCB0cmVhdGluZyB0aGUgXCJkYXRhTGVuXCIgYnl0ZSBhcyBpZD0wLlxuXHRcdC8vIE9ubHkgZmlyZSBpZiBubyBieXRlcyB3ZXJlIGNvbnN1bWVkIGJ5IHRoZSBtYWluIGxvb3AgKHEgPT09IHFTdGFydCksIHRvIGF2b2lkXG5cdFx0Ly8gcmUtcGFyc2luZyBieXRlcyB0aGF0IHdlcmUgYWxyZWFkeSBzdWNjZXNzZnVsbHkgcGFyc2VkLlxuXHRcdGlmIChxID09PSBxU3RhcnQgJiYgc2VjdGlvbkVuZCA+IHAgKyAzKSB7XG5cdFx0XHRsZXQgcG9zID0gaGFzQnVzQ2ggPyBwICsgMyA6IHAgKyAyIC8vIHNraXAgY21kSWQgKGFuZCBidXNDaCBpZiBwcmVzZW50KVxuXHRcdFx0bGV0IHBvc0lkID0gMFxuXHRcdFx0d2hpbGUgKHBvcyA8IHNlY3Rpb25FbmQpIHtcblx0XHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHsgY21kX2lkOiBzZWN0aW9uQ21kSWQsIGlkOiBwb3NJZCsrLCB2YWx1ZUJ5dGVzOiBbYnVmW3BvcysrXV0gfVxuXHRcdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgc2V0dGluZy5idXNDaCA9IGJ1c0NoXG5cdFx0XHRcdG91dC5wdXNoKHNldHRpbmcpXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cCA9IHNlY3Rpb25FbmRcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgR0VORVJJQyBTRVRUSU5HUyBSRVNQT05TRSBQQVJTRVIgKDB4MGEgZ2V0LWFsbCArIDB4MGIgdW5zb2xpY2l0ZWQgcHVzaClcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBQYXJzZXMgYW55IGZ1bGwgc2V0dGluZ3MgYmxvY2sgcmVnYXJkbGVzcyBvZiB3aGV0aGVyIHRoZSBjbWRJZCBpcyAweDBhXG4gKiAocmVzcG9uc2UgdG8gR2V0IEFsbCBTZXR0aW5ncykgb3IgMHgwYiAodW5zb2xpY2l0ZWQgcHVzaCBhZnRlciBhIHNldCkuXG4gKiBCb3RoIHVzZSB0aGUgc2FtZSBzZWN0aW9uZWQgb3IgZmxhdCBibG9jayBsYXlvdXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdzUmVzcG9uc2UobW9kZWw6IHN0cmluZywgYnVmOiBCdWZmZXIpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYE5vdCBhIHNldHRpbmdzIGJsb2NrIChjbWRJZD0weCR7Y21kSWQudG9TdHJpbmcoMTYpfSlgKVxuXHR9XG5cdGNvbnN0IHsgc2VjdGlvbmVkIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHNlY3Rpb25lZCA/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpIDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG59XG5cbi8qKlxuICogRm9ybWF0cyBhIHNpbmdsZSBwYXJzZWQgc2V0dGluZyBpbnRvIGEgaHVtYW4tcmVhZGFibGUgc3RyaW5nIHVzaW5nIGFjdGlvblxuICogZGVmaW5pdGlvbnMgZnJvbSB0aGUgZGV2aWNlIEpTT04uIEZhbGxzIGJhY2sgdG8gaGV4IElEcyB3aGVuIHVua25vd24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmc6IFBhcnNlZFNldHRpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiBzdHJpbmcge1xuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IHNldHRpbmcuY21kX2lkICYmIGEuaWQgPT09IHNldHRpbmcuaWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2ggYW5kIGlkID4gYmFzZSBpZCwgdHJ5IHRvIGZpbmQgYWN0aW9uIHdpdGggaWRBZGQgb3B0aW9uXG5cdC8vIFRoaXMgaGFuZGxlcyBjYXNlcyBsaWtlIENNRF9IRUFEUEhPTkUgKDB4MDUsIGUuZy4gUGhvbmVzIFJvdXRpbmcpIGFuZFxuXHQvLyBDTURfQlVUVE9OX01PREUgKDB4MDcsIGUuZy4gQnV0dG9ucykgd2hlcmUgaWQgMC0zIHJlcHJlc2VudHMgY2hhbm5lbHMgMS00XG5cdGlmICghYWN0aW9uKSB7XG5cdFx0Y29uc3QgYmFzZUFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBzZXR0aW5nLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIGFjdGlvbiBoYXMgYW4gaWRBZGQgb3B0aW9uIChpbmRpY2F0aW5nIGNoYW5uZWwgc2VsZWN0aW9uKVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGUgc2V0dGluZy5pZCBvZmZzZXQgbWF0Y2hlcyBvbmUgb2YgdGhlIGlkQWRkIGNob2ljZSBJRHNcblx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYS5pZFxuXHRcdFx0cmV0dXJuIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHR9KVxuXHRcdGlmIChiYXNlQWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSBiYXNlQWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0Y29uc3QgY21kSGV4ID0gdG9IZXgoc2V0dGluZy5jbWRfaWQpXG5cdGNvbnN0IGlkSGV4ID0gdG9IZXgoc2V0dGluZy5pZClcblx0Y29uc3QgdmFsSGV4ID0gYnl0ZXNUb0hleChzZXR0aW5nLnZhbHVlQnl0ZXMpXG5cdGNvbnN0IHZhbERlYyA9XG5cdFx0c2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0PyBmb3JtYXRSZ2JDb2xvcihzZXR0aW5nLnZhbHVlQnl0ZXNbMF0sIHNldHRpbmcudmFsdWVCeXRlc1sxXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzJdKVxuXHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxXG5cdFx0XHRcdD8gc2V0dGluZy52YWx1ZUJ5dGVzWzBdXG5cdFx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmpvaW4oJywnKVxuXG5cdC8vIEJ1aWxkIHRoZSBwcmVmaXg6IGNtZDoweDEyIGNoOjAgaWQ6MHgwMSB2YWw6MHgxNCAoY2ggb25seSBmb3IgY29tbWFuZHMgd2l0aCBidXNDaClcblx0Y29uc3QgYnVzQ2hTdHIgPSBzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQgPyBgIGNoOiR7c2V0dGluZy5idXNDaH1gIDogJydcblx0Y29uc3QgcHJlZml4ID0gYGNtZDoke2NtZEhleH0ke2J1c0NoU3RyfSBpZDoke2lkSGV4fSB2YWw6JHt2YWxIZXh9YFxuXG5cdC8vIElmIHdlIGhhdmUgYW4gYWN0aW9uIHdpdGggYSBuYW1lIGFuZCBjaG9pY2UgbGFiZWwsIHVzZSBpdFxuXHRpZiAoYWN0aW9uKSB7XG5cdFx0bGV0IG5hbWUgPSBhY3Rpb24ubmFtZVxuXG5cdFx0Ly8gSWYgc2V0dGluZyBoYXMgYnVzQ2gsIGFkZCBjaGFubmVsIGluZm8gdG8gbmFtZVxuXHRcdGlmIChzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdG5hbWUgPSBgJHtuYW1lfSBDaCR7c2V0dGluZy5idXNDaCArIDF9YFxuXHRcdH1cblx0XHQvLyBPdGhlcndpc2UsIGlmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCwgaW5jbHVkZSB0aGUgaWRBZGQgbGFiZWxcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYWN0aW9uLmlkXG5cdFx0XHRcdGNvbnN0IGlkQWRkQ2hvaWNlID0gaWRBZGRPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdFx0XHRpZiAoaWRBZGRDaG9pY2UpIHtcblx0XHRcdFx0XHRuYW1lID0gYCR7bmFtZX0gJHtpZEFkZENob2ljZS5sYWJlbH1gXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBMb29rIGZvciB0aGUgdmFsdWUgb3B0aW9uIChub3QgYnVzQ2ggb3IgaWRBZGQpXG5cdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdFx0aWYgKHZhbHVlT3B0aW9uPy5jaG9pY2VzICYmIHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRcdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gc2V0dGluZy52YWx1ZUJ5dGVzWzBdKVxuXHRcdFx0aWYgKGNob2ljZSkge1xuXHRcdFx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7Y2hvaWNlLmxhYmVsfSAoJHt2YWxEZWN9KWBcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke3ZhbERlY31gXG5cdH1cblxuXHQvLyBObyBhY3Rpb24gZm91bmQgLSBqdXN0IHNob3cgdGhlIHJhdyB2YWx1ZXNcblx0cmV0dXJuIGAke3ByZWZpeH0gfCBVbmtub3duIFNldHRpbmdgXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFBBUlNFUiBESVNQQVRDSCBXSVRIIEFVVE8tREVURUNUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogUGFyc2VzIGdldEFsbFNldHRpbmdzIHJlc3BvbnNlIHdpdGggYXV0b21hdGljIGZvcm1hdCBkZXRlY3Rpb24uXG4gKlxuICogU3RyYXRlZ3k6XG4gKiAxLiBJZiBtb2RlbCBoYXMgZXhwbGljaXQgXCJzZWN0aW9uZWRcIiBwcm9wZXJ0eSwgdXNlIHRoYXRcbiAqIDIuIE90aGVyd2lzZSwgdHJ5IEZMQVQgcGFyc2VyIGZpcnN0IChpdCdzIHNpbXBsZXIpXG4gKiAzLiBJZiBGTEFUIHJldHVybnMgMCBzZXR0aW5ncywgdHJ5IFNFQ1RJT05FRCBwYXJzZXJcbiAqIDQuIFVzZSB3aGljaGV2ZXIgcGFyc2VyIHJldHVybnMgbW9yZSBzZXR0aW5nc1xuICpcbiAqIEByZXR1cm5zIHtzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdLCBkZXRlY3RlZFNlY3Rpb25lZDogYm9vbGVhbiB8IG51bGx9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbihcblx0bW9kZWw6IHN0cmluZyxcblx0YnVmOiBCdWZmZXIsXG4pOiB7IHNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW107IGRldGVjdGVkU2VjdGlvbmVkOiBib29sZWFuIHwgbnVsbCB9IHtcblx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRjb25zdCBkZWNsYXJlZFNlY3Rpb25lZCA9IHNjaGVtYT8uc2VjdGlvbmVkXG5cblx0Ly8gSWYgZXhwbGljaXRseSBkZWNsYXJlZCBpbiBKU09OLCB1c2UgdGhhdFxuXHRpZiAoZGVjbGFyZWRTZWN0aW9uZWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IHNldHRpbmdzID0gZGVjbGFyZWRTZWN0aW9uZWRcblx0XHRcdD8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbClcblx0XHRcdDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiBudWxsIH0gLy8gbnVsbCA9IHVzZWQgZGVjbGFyZWQgdmFsdWVcblx0fVxuXG5cdC8vIE5vIGRlY2xhcmF0aW9uIC0gdHJ5IGJvdGggcGFyc2VycyBhbmQgcGljayB0aGUgYmVzdCBvbmVcblx0bGV0IGZsYXRTZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdID0gW11cblx0bGV0IHNlY3Rpb25lZFNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdHRyeSB7XG5cdFx0ZmxhdFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZGVidWcoYEZsYXQgcGFyc2VyIGZhaWxlZDogJHtlfWApXG5cdH1cblxuXHR0cnkge1xuXHRcdHNlY3Rpb25lZFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5kZWJ1ZyhgU2VjdGlvbmVkIHBhcnNlciBmYWlsZWQ6ICR7ZX1gKVxuXHR9XG5cblx0Ly8gUGljayB0aGUgcGFyc2VyIHRoYXQgcmV0dXJuZWQgbW9yZSBzZXR0aW5nc1xuXHRpZiAoc2VjdGlvbmVkU2V0dGluZ3MubGVuZ3RoID4gZmxhdFNldHRpbmdzLmxlbmd0aCkge1xuXHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIFNFQ1RJT05FRCBmb3JtYXQgKHNlY3Rpb25lZD0ke3NlY3Rpb25lZFNldHRpbmdzLmxlbmd0aH0gdnMgZmxhdD0ke2ZsYXRTZXR0aW5ncy5sZW5ndGh9KWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IHNlY3Rpb25lZFNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogdHJ1ZSB9XG5cdH0gZWxzZSBpZiAoZmxhdFNldHRpbmdzLmxlbmd0aCA+IDApIHtcblx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBGTEFUIGZvcm1hdCAoZmxhdD0ke2ZsYXRTZXR0aW5ncy5sZW5ndGh9IHZzIHNlY3Rpb25lZD0ke3NlY3Rpb25lZFNldHRpbmdzLmxlbmd0aH0pYClcblx0XHRyZXR1cm4geyBzZXR0aW5nczogZmxhdFNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogZmFsc2UgfVxuXHR9IGVsc2Uge1xuXHRcdC8vIEJvdGggcGFyc2VycyByZXR1cm5lZCAwIHNldHRpbmdzXG5cdFx0bG9nZ2VyLndhcm4oYFdhcm5pbmc6IEJvdGggcGFyc2VycyByZXR1cm5lZCAwIHNldHRpbmdzIGZvciBtb2RlbCAke21vZGVsfWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IFtdLCBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9XG5cdH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbChtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IHsgc2VjdGlvbmVkIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHNlY3Rpb25lZCA/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpIDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG59XG5cbi8qIFx1MjcwNSBiYWNrd2FyZC1jb21wYXRpYmxlIGV4cG9ydCAqL1xuZXhwb3J0IGNvbnN0IHBhcnNlR2V0QWxsU2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWxcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVkFMVUUgXHUyMTkyIE9QVElPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlczogbnVtYmVyW10pOiBTdEFjdGlvbk9wdGlvbiB7XG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdHJldHVybiB7IGlkOiAndmFsdWUnLCBsYWJlbDogJ1ZhbHVlJywgdHlwZTogJ251bWJlcicsIGRlZmF1bHQ6IHZhbHVlQnl0ZXNbMF0gfVxuXHR9XG5cblx0aWYgKHZhbHVlQnl0ZXMubGVuZ3RoID09PSAzKSB7XG5cdFx0Y29uc3QgW3IsIGcsIGJdID0gdmFsdWVCeXRlc1xuXHRcdHJldHVybiB7XG5cdFx0XHRpZDogJ3ZhbHVlJyxcblx0XHRcdGxhYmVsOiAnQ29sb3InLFxuXHRcdFx0dHlwZTogJ2NvbG9ycGlja2VyJyxcblx0XHRcdGRlZmF1bHQ6IGZvcm1hdFJnYkNvbG9yKHIsIGcsIGIpLFxuXHRcdH1cblx0fVxuXG5cdHJldHVybiB7IGlkOiAndmFsdWUnLCBsYWJlbDogJ1ZhbHVlJywgdHlwZTogJ3JhdycsIGRlZmF1bHQ6IFsuLi52YWx1ZUJ5dGVzXSB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNNQVJUIEpTT04gVVBEQVRFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MoXG5cdG1vZGVsSnNvbjogU3RNb2RlbEpzb24sXG5cdHBhcnNlZDogUGFyc2VkU2V0dGluZ1tdLFxuXHRhbGxNb2RlbHM6IFJlY29yZDxzdHJpbmcsIFN0TW9kZWxKc29uPixcbik6IFN0TW9kZWxKc29uIHtcblx0Y29uc3Qgb3V0ID0gc3RydWN0dXJlZENsb25lKG1vZGVsSnNvbilcblxuXHQvLyBFbnN1cmUgY21kU2NoZW1hIGFycmF5IGV4aXN0c1xuXHRpZiAoIW91dC5jbWRTY2hlbWEpIHtcblx0XHRvdXQuY21kU2NoZW1hID0gW11cblx0fVxuXG5cdC8vIFNvcnQgb3RoZXIgbW9kZWxzIGJ5IG51bWVyaWMgZGlzdGFuY2UgdG8gY3VycmVudCBtb2RlbFxuXHRjb25zdCBjYW5kaWRhdGVzID0gT2JqZWN0LnZhbHVlcyhhbGxNb2RlbHMpXG5cdFx0LmZpbHRlcigobSkgPT4gbS5tb2RlbCAhPT0gbW9kZWxKc29uLm1vZGVsKSAvLyBleGNsdWRlIHNlbGZcblx0XHQuc29ydCgoYSwgYikgPT4gbW9kZWxEaXN0YW5jZShtb2RlbEpzb24ubW9kZWwsIGEubW9kZWwpIC0gbW9kZWxEaXN0YW5jZShtb2RlbEpzb24ubW9kZWwsIGIubW9kZWwpKVxuXG5cdGxvZ2dlci5pbmZvKGBVcGRhdGluZyBtb2RlbDogJHttb2RlbEpzb24ubW9kZWx9YClcblx0bG9nZ2VyLmRlYnVnKGBDYW5kaWRhdGVzIGZvciBpbmZlcmVuY2U6ICR7Y2FuZGlkYXRlcy5tYXAoKGMpID0+IGMubW9kZWwpLmpvaW4oJywgJyl9YClcblxuXHQvLyBQcmUtc2NhbjogZm9yIGVhY2ggY2FuZGlkYXRlIGlkQWRkIGJhc2UgZW50cnksIGZpbmQgdGhlIG1heGltdW0gc2VxdWVudGlhbFxuXHQvLyBvZmZzZXQgdGhlIHBhY2tldCBjb250YWlucyAoZXZlbiBiZXlvbmQgd2hhdCB0aGUgcmVmZXJlbmNlIG1vZGVsIGtub3dzKS5cblx0Ly8gS2V5OiBgJHtjbWRfaWR9XyR7YmFzZV9pZH1gLCB2YWx1ZTogbWF4IHNlcXVlbnRpYWwgb2Zmc2V0IHNlZW4gaW4gcGFyc2VkIGRhdGEuXG5cdGNvbnN0IGlkQWRkRGVmZXJSYW5nZXMgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpXG5cdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0Zm9yIChjb25zdCBiYXNlRW50cnkgb2YgYy5jbWRTY2hlbWEgPz8gW10pIHtcblx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gYmFzZUVudHJ5Lm9wdGlvbnM/LmZpbmQoKG86IGFueSkgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMpIGNvbnRpbnVlXG5cdFx0XHRjb25zdCBiYXNlSWQgPSBiYXNlRW50cnkuaWRcblx0XHRcdGNvbnN0IGNtZElkID0gYmFzZUVudHJ5LmNtZF9pZFxuXHRcdFx0Y29uc3Qga2V5ID0gYCR7Y21kSWR9XyR7YmFzZUlkfWBcblx0XHRcdGlmIChpZEFkZERlZmVyUmFuZ2VzLmhhcyhrZXkpKSBjb250aW51ZVxuXHRcdFx0Ly8gRmluZCB0aGUgbWF4IHNlcXVlbnRpYWwgb2Zmc2V0IHByZXNlbnQgaW4gdGhlIHBhcnNlZCBwYWNrZXQgZm9yIHRoaXMgYmFzZVxuXHRcdFx0Y29uc3QgcGFyc2VkT2Zmc2V0cyA9IHBhcnNlZFxuXHRcdFx0XHQuZmlsdGVyKChwKSA9PiBwLmNtZF9pZCA9PT0gY21kSWQgJiYgcC5pZCA+IGJhc2VJZClcblx0XHRcdFx0Lm1hcCgocCkgPT4gcC5pZCAtIGJhc2VJZClcblx0XHRcdFx0LnNvcnQoKGEsIGIpID0+IGEgLSBiKVxuXHRcdFx0Ly8gV2FsayBmcm9tIDEgdXB3YXJkIFx1MjAxNCBzdG9wIGF0IGZpcnN0IGdhcFxuXHRcdFx0bGV0IG1heFNlcSA9IDBcblx0XHRcdGZvciAoY29uc3Qgb2ZmIG9mIHBhcnNlZE9mZnNldHMpIHtcblx0XHRcdFx0aWYgKG9mZiA9PT0gbWF4U2VxICsgMSkgbWF4U2VxID0gb2ZmXG5cdFx0XHRcdGVsc2UgaWYgKG9mZiA+IG1heFNlcSArIDEpIGJyZWFrXG5cdFx0XHR9XG5cdFx0XHRpZiAobWF4U2VxID4gMCkge1xuXHRcdFx0XHRpZEFkZERlZmVyUmFuZ2VzLnNldChrZXksIG1heFNlcSlcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBpZEFkZCBkZWZlciByYW5nZSBmb3IgY21kX2lkPSR7dG9IZXgoY21kSWQpfSBiYXNlX2lkPSR7dG9IZXgoYmFzZUlkKX06IG9mZnNldHMgMVx1MjAxMyR7bWF4U2VxfWApXG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0Ly8gUHJlLWNvbXB1dGUgdGhlIHNldCBvZiBhbGwgYnVzQ2ggdmFsdWVzIHNlZW4gcGVyIChjbWRfaWQsIGlkKSBwYWlyIGFjcm9zcyB0aGUgZnVsbFxuXHQvLyBwYXJzZWQgcmVzcG9uc2UgXHUyMDE0IHVzZWQgbGF0ZXIgdG8gZGVjaWRlIGZpeGVkIHZzLiBzZWxlY3RhYmxlIGJ1c0NoLlxuXHRjb25zdCBidXNDaFNlZW4gPSBuZXcgTWFwPHN0cmluZywgU2V0PG51bWJlcj4+KClcblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQsIGJ1c0NoIH0gb2YgcGFyc2VkKSB7XG5cdFx0aWYgKGJ1c0NoID09PSB1bmRlZmluZWQpIGNvbnRpbnVlXG5cdFx0Y29uc3Qga2V5ID0gYCR7Y21kX2lkfV8ke2lkfWBcblx0XHRpZiAoIWJ1c0NoU2Vlbi5oYXMoa2V5KSkgYnVzQ2hTZWVuLnNldChrZXksIG5ldyBTZXQoKSlcblx0XHRidXNDaFNlZW4uZ2V0KGtleSkhLmFkZChidXNDaClcblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gUEFTUyAxOiByZXNvbHZlIGVhY2ggcGFyc2VkIGVudHJ5IFx1MjAxNCBleGFjdCBtYXRjaCwgaW5mZXJyZWQsXG5cdC8vIGlkQWRkLWZvbGQgKG9mZnNldCBpbnRvIGFuIGFscmVhZHktYWRkZWQgYmFzZSBlbnRyeSksIG9yIHVua25vd25cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCwgYnVzQ2gsIHZhbHVlQnl0ZXMgfSBvZiBwYXJzZWQpIHtcblx0XHQvLyAxYS4gRXhhY3QgbWF0Y2ggYWxyZWFkeSBpbiBvdXRwdXQgc2NoZW1hIFx1MjAxNCBqdXN0IHJlZnJlc2ggdGhlIGRlZmF1bHRcblx0XHRjb25zdCBleGlzdGluZ0V4YWN0ID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdGlmIChleGlzdGluZ0V4YWN0KSB7XG5cdFx0XHRjb25zdCBvcHQgPSBleGlzdGluZ0V4YWN0Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdFx0XHRpZiAob3B0KSBvcHQuZGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cdFx0XHRjb250aW51ZVxuXHRcdH1cblxuXHRcdC8vIDFiLiBDaGVjayBpZiB0aGlzIGlkIGZvbGRzIGludG8gYW4gYWxyZWFkeS1hZGRlZCBiYXNlIGVudHJ5IHZpYSBpZEFkZC5cblx0XHQvLyAgICAgR2F0ZTogdGhlIG9mZnNldCBtdXN0IGFjdHVhbGx5IGV4aXN0IGluIHRoZSByZWZlcmVuY2UgbW9kZWwncyBpZEFkZCBjaG9pY2VzXG5cdFx0Ly8gICAgIHRvIGF2b2lkIHN3YWxsb3dpbmcgdW5yZWxhdGVkIHNhbWUtY21kX2lkIGVudHJpZXMgKGUuZy4gU2lkZXRvbmUgYXQgaWQ9MjEpLlxuXHRcdGNvbnN0IGlkQWRkQmFzZSA9IG91dC5jbWRTY2hlbWEuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBjbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdGlmIChpZCA8PSBhLmlkKSByZXR1cm4gZmFsc2Vcblx0XHRcdGNvbnN0IG9mZnNldCA9IGlkIC0gYS5pZFxuXHRcdFx0Ly8gT25seSBmb2xkIGlmIGEgcmVmZXJlbmNlIG1vZGVsIGV4cGxpY2l0bHkgbGlzdHMgdGhpcyBvZmZzZXQgaW4gaXRzIGlkQWRkIGNob2ljZXNcblx0XHRcdHJldHVybiBjYW5kaWRhdGVzLnNvbWUoKGMpID0+IHtcblx0XHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgocikgPT4gci5jbWRfaWQgPT09IGNtZF9pZCAmJiByLmlkID09PSBhLmlkKVxuXHRcdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRyZXR1cm4gcmVmSWRBZGQ/LmNob2ljZXM/LnNvbWUoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0XHR9KVxuXHRcdH0pXG5cdFx0aWYgKGlkQWRkQmFzZSkge1xuXHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBpZEFkZEJhc2UuaWRcblx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gaWRBZGRCYXNlLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoaWRBZGRPcHQ/LmNob2ljZXMgJiYgIWlkQWRkT3B0LmNob2ljZXMuc29tZSgoYzogYW55KSA9PiBjLmlkID09PSBvZmZzZXQpKSB7XG5cdFx0XHRcdGxldCBsYWJlbCA9IGBDaGFubmVsICR7b2Zmc2V0ICsgMX1gXG5cdFx0XHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZEFkZEJhc2UuaWQpXG5cdFx0XHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRjb25zdCByZWZDaG9pY2UgPSByZWZJZEFkZD8uY2hvaWNlcz8uZmluZCgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHRcdFx0XHRpZiAocmVmQ2hvaWNlKSB7XG5cdFx0XHRcdFx0XHRsYWJlbCA9IHJlZkNob2ljZS5sYWJlbFxuXHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0aWRBZGRPcHQuY2hvaWNlcy5wdXNoKHsgaWQ6IG9mZnNldCwgbGFiZWwgfSlcblx0XHRcdFx0bG9nZ2VyLmluZm8oXG5cdFx0XHRcdFx0YEZvbGRlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gaW50byBpZEFkZCBiYXNlIGlkPSR7dG9IZXgoaWRBZGRCYXNlLmlkKX0gYXMgb2Zmc2V0ICR7b2Zmc2V0fSAoXCIke2xhYmVsfVwiKWAsXG5cdFx0XHRcdClcblx0XHRcdH1cblx0XHRcdGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0Ly8gMWMuIE5vIGV4YWN0IG1hdGNoIFx1MjAxNCB0cnkgaW5mZXJlbmNlIGZyb20gY2FuZGlkYXRlIG1vZGVsc1xuXHRcdGxldCBhY3Rpb246IFN0QWN0aW9uIHwgdW5kZWZpbmVkXG5cblx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0Y29uc3QgbWF0Y2ggPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZClcblx0XHRcdGlmIChtYXRjaCkge1xuXHRcdFx0XHRhY3Rpb24gPSBzdHJ1Y3R1cmVkQ2xvbmUobWF0Y2gpXG5cdFx0XHRcdC8vIFN0cmlwIGFueSBleGlzdGluZyBcIihpbmZlcnJlZCBmcm9tIE1vZGVsIFgpXCIgc3VmZml4ZXMgYmVmb3JlIGFkZGluZyBvdXIgb3duXG5cdFx0XHRcdGNvbnN0IGJhc2VOYW1lID0gbWF0Y2gubmFtZS5yZXBsYWNlKC9cXHMqXFwoaW5mZXJyZWQgZnJvbSBNb2RlbCBbXildK1xcKS9nLCAnJykudHJpbSgpXG5cdFx0XHRcdGFjdGlvbi5uYW1lID0gYCR7YmFzZU5hbWV9IChpbmZlcnJlZCBmcm9tIE1vZGVsICR7Yy5tb2RlbH0pYFxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgSW5mZXJyZWQgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGZyb20gTW9kZWwgJHtjLm1vZGVsfSAoZXhhY3QpYClcblx0XHRcdFx0YnJlYWtcblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBDaGVjayBpZiB0aGlzIGlkIHNob3VsZCBiZSBkZWZlcnJlZCB0byBwYXNzIDIgXHUyMDE0XG5cdFx0Ly8gaXQncyBhIHNlcXVlbnRpYWwgaWRBZGQgb2Zmc2V0IG9mIGEga25vd24gY2FuZGlkYXRlIGJhc2UgZW50cnkuXG5cdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdGxldCBzaG91bGREZWZlciA9IGZhbHNlXG5cdFx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0XHRjb25zdCBiYXNlRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgoYTogYW55KSA9PiB7XG5cdFx0XHRcdFx0aWYgKGEuY21kX2lkICE9PSBjbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gYS5vcHRpb25zPy5maW5kKChvOiBhbnkpID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0aWYgKGlkIDw9IGEuaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdGNvbnN0IG9mZnNldCA9IGlkIC0gYS5pZFxuXHRcdFx0XHRcdGNvbnN0IG1heFNlcSA9IGlkQWRkRGVmZXJSYW5nZXMuZ2V0KGAke2NtZF9pZH1fJHthLmlkfWApID8/IDBcblx0XHRcdFx0XHRyZXR1cm4gb2Zmc2V0IDw9IG1heFNlcVxuXHRcdFx0XHR9KVxuXHRcdFx0XHRpZiAoYmFzZUVudHJ5KSB7XG5cdFx0XHRcdFx0c2hvdWxkRGVmZXIgPSB0cnVlXG5cdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKFxuXHRcdFx0XHRcdFx0YGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBpcyBhbiBpZEFkZCBvZmZzZXQgb2YgY2FuZGlkYXRlIGJhc2UgaWQ9JHt0b0hleChiYXNlRW50cnkuaWQpfSBcdTIwMTQgZGVmZXJyaW5nIHRvIHBhc3MgMmAsXG5cdFx0XHRcdFx0KVxuXHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmIChzaG91bGREZWZlcikgY29udGludWVcblx0XHR9XG5cblx0XHQvLyBGYWxsYmFjazogdW5rbm93biBzZXR0aW5nXG5cdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdGFjdGlvbiA9IHtcblx0XHRcdFx0Y21kX2lkLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0bmFtZTogYFVua25vd24gY21kOiR7dG9IZXgoY21kX2lkKX0gaWQ6JHt0b0hleChpZCkudG9VcHBlckNhc2UoKX1gLFxuXHRcdFx0XHRvcHRpb25zOiBbdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpXSxcblx0XHRcdH1cblx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBhY3Rpb24uYnVzQ2ggPSBidXNDaFxuXHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBpbmZlciBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgRml4IDE6IGJ1c0NoIGhhbmRsaW5nIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gU3RyaXAgYW55IGluaGVyaXRlZCBidXNDaCBvcHRpb24gZnJvbSB0aGUgY2FuZGlkYXRlIFx1MjAxNCB3ZSdsbCByZS1kZXJpdmVcblx0XHRcdC8vIGl0IGZyb20gd2hhdCB0aGUgcGFja2V0IGFjdHVhbGx5IHJlcG9ydGVkIGZvciB0aGlzIGRldmljZS5cblx0XHRcdGFjdGlvbi5vcHRpb25zID0gYWN0aW9uLm9wdGlvbnM/LmZpbHRlcigobykgPT4gby5pZCAhPT0gJ2J1c0NoJykgPz8gW11cblx0XHRcdGRlbGV0ZSBhY3Rpb24uYnVzQ2hcblxuXHRcdFx0Y29uc3Qgc2VlbkJ1c0NoVmFsdWVzID0gYnVzQ2hTZWVuLmdldChgJHtjbWRfaWR9XyR7aWR9YClcblx0XHRcdGlmIChzZWVuQnVzQ2hWYWx1ZXMgJiYgc2VlbkJ1c0NoVmFsdWVzLnNpemUgPiAwKSB7XG5cdFx0XHRcdGNvbnN0IG1heEJ1c0NoID0gTWF0aC5tYXgoLi4uc2VlbkJ1c0NoVmFsdWVzKVxuXHRcdFx0XHRpZiAobWF4QnVzQ2ggPT09IDApIHtcblx0XHRcdFx0XHQvLyBPbmx5IGV2ZXIgc2F3IGJ1c0NoPTAgXHUyMTkyIGZpeGVkIHByb3BlcnR5LCBub3QgYW4gb3B0aW9uXG5cdFx0XHRcdFx0YWN0aW9uLmJ1c0NoID0gMFxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdC8vIE11bHRpcGxlIGNoYW5uZWxzIG9ic2VydmVkIFx1MjE5MiBzZWxlY3RhYmxlIG9wdGlvblxuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoQ2hvaWNlcyA9IEFycmF5LmZyb20oeyBsZW5ndGg6IG1heEJ1c0NoICsgMSB9LCAoXywgaSkgPT4gKHtcblx0XHRcdFx0XHRcdGlkOiBpLFxuXHRcdFx0XHRcdFx0bGFiZWw6IGBDaGFubmVsICR7aSArIDF9YCxcblx0XHRcdFx0XHR9KSlcblx0XHRcdFx0XHRhY3Rpb24ub3B0aW9ucy51bnNoaWZ0KHtcblx0XHRcdFx0XHRcdGlkOiAnYnVzQ2gnLFxuXHRcdFx0XHRcdFx0bGFiZWw6ICdDaGFubmVsJyxcblx0XHRcdFx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRcdFx0XHRjaG9pY2VzOiBidXNDaENob2ljZXMsXG5cdFx0XHRcdFx0XHRkZWZhdWx0OiAwLFxuXHRcdFx0XHRcdH0gYXMgYW55KVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBGaXggMjogZGVmYXVsdCBtdXN0IGV4aXN0IGluIGNob2ljZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBTZXQgdGhlIGRlZmF1bHQgdG8gdGhlIG9ic2VydmVkIHZhbHVlLiBJZiB0aGF0IHZhbHVlIGlzbid0IGluIHRoZVxuXHRcdFx0Ly8gaW5oZXJpdGVkIGNob2ljZXMgbGlzdCwgdGhlIGNob2ljZXMgYXJlIGZyb20gYSBzdHJ1Y3R1cmFsbHkgZGlmZmVyZW50XG5cdFx0XHQvLyBtb2RlbCBhbmQgY2FuJ3QgYmUgdHJ1c3RlZCBcdTIwMTQgZGlzY2FyZCB0aGVtIGFuZCBmYWxsIGJhY2sgdG8gYSBwbGFpbiBudW1iZXIuXG5cdFx0XHRjb25zdCBvYnNlcnZlZERlZmF1bHQgPSB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcykuZGVmYXVsdFxuXHRcdFx0Y29uc3QgdmFsdWVPcHQgPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJylcblx0XHRcdGlmICh2YWx1ZU9wdCkge1xuXHRcdFx0XHRpZiAodmFsdWVPcHQuY2hvaWNlcyAmJiBBcnJheS5pc0FycmF5KHZhbHVlT3B0LmNob2ljZXMpKSB7XG5cdFx0XHRcdFx0Y29uc3QgaW5DaG9pY2VzID0gdmFsdWVPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9ic2VydmVkRGVmYXVsdClcblx0XHRcdFx0XHRpZiAoIWluQ2hvaWNlcykge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oXG5cdFx0XHRcdFx0XHRcdGBJbmZlcnJlZCBjaG9pY2VzIGZvciBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gZG9uJ3QgY29udGFpbiBvYnNlcnZlZCB2YWx1ZSAke29ic2VydmVkRGVmYXVsdH0gXHUyMDE0IGRpc2NhcmRpbmcgaW5oZXJpdGVkIGNob2ljZXNgLFxuXHRcdFx0XHRcdFx0KVxuXHRcdFx0XHRcdFx0Ly8gS2VlcCBsYWJlbC90b29sdGlwIGJ1dCBkcm9wIGNob2ljZXMsIHN3aXRjaCB0byBwbGFpbiBudW1iZXJcblx0XHRcdFx0XHRcdHZhbHVlT3B0LnR5cGUgPSAnbnVtYmVyJ1xuXHRcdFx0XHRcdFx0ZGVsZXRlICh2YWx1ZU9wdCBhcyBhbnkpLmNob2ljZXNcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0dmFsdWVPcHQuZGVmYXVsdCA9IG9ic2VydmVkRGVmYXVsdFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdG91dC5jbWRTY2hlbWEucHVzaChhY3Rpb24pXG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFBBU1MgMjogZm9sZCBhbnkgZGVmZXJyZWQgaWRBZGQgb2Zmc2V0cyB3aG9zZSBiYXNlIGVudHJ5XG5cdC8vIGlzIG5vdyBwcmVzZW50IGluIHRoZSBvdXRwdXQgc2NoZW1hLlxuXHQvLyBHYXRlOiB0aGUgb2Zmc2V0IG11c3QgZWl0aGVyIGV4aXN0IGluIGEgcmVmZXJlbmNlIG1vZGVsJ3MgY2hvaWNlcyxcblx0Ly8gT1IgdGhlIGJhc2UgZW50cnkgaXRzZWxmIHdhcyBpbmZlcnJlZCAoaGFzIGlkQWRkKSBhbmQgdGhlIG9mZnNldFxuXHQvLyBjb250aW51ZXMgc2VxdWVudGlhbGx5IGJleW9uZCB0aGUgcmVmZXJlbmNlIG1vZGVsJ3Mga25vd24gcmFuZ2UuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQgfSBvZiBwYXJzZWQpIHtcblx0XHRjb25zdCBhbHJlYWR5VG9wTGV2ZWwgPSBvdXQuY21kU2NoZW1hLnNvbWUoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0aWYgKGFscmVhZHlUb3BMZXZlbCkgY29udGludWVcblxuXHRcdC8vIEZpbmQgYSBiYXNlIGVudHJ5IGluIHRoZSBvdXRwdXQgdGhhdCBoYXMgaWRBZGQgYW5kIHdob3NlIGlkIDwgdGhpcyBpZFxuXHRcdGNvbnN0IGlkQWRkQmFzZSA9IG91dC5jbWRTY2hlbWEuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBjbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRyZXR1cm4gISFpZEFkZE9wdD8uY2hvaWNlcyAmJiBpZCA+IGEuaWRcblx0XHR9KVxuXHRcdGlmICghaWRBZGRCYXNlKSBjb250aW51ZVxuXG5cdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBpZEFkZEJhc2UuaWRcblx0XHRjb25zdCBpZEFkZE9wdCA9IGlkQWRkQmFzZS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMgfHwgaWRBZGRPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldCkpIGNvbnRpbnVlXG5cblx0XHQvLyBBY2NlcHQgdGhlIGZvbGQgaWY6IGEgcmVmZXJlbmNlIG1vZGVsIGV4cGxpY2l0bHkgaGFzIHRoaXMgb2Zmc2V0LFxuXHRcdC8vIE9SIHRoZSBvZmZzZXRzIGFyZSBzdHJpY3RseSBzZXF1ZW50aWFsIGZyb20gMCAoZGV2aWNlIGhhcyBtb3JlIGNoYW5uZWxzIHRoYW4gcmVmZXJlbmNlKVxuXHRcdGNvbnN0IHJlZkhhc09mZnNldCA9IGNhbmRpZGF0ZXMuc29tZSgoYykgPT4ge1xuXHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgocikgPT4gci5jbWRfaWQgPT09IGNtZF9pZCAmJiByLmlkID09PSBpZEFkZEJhc2UuaWQpXG5cdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0cmV0dXJuIHJlZklkQWRkPy5jaG9pY2VzPy5zb21lKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdH0pXG5cdFx0Y29uc3QgZXhpc3RpbmdPZmZzZXRzID0gaWRBZGRPcHQuY2hvaWNlcy5tYXAoKGM6IGFueSkgPT4gYy5pZCBhcyBudW1iZXIpLnNvcnQoKGEsIGIpID0+IGEgLSBiKVxuXHRcdGNvbnN0IGlzU2VxdWVudGlhbCA9IGV4aXN0aW5nT2Zmc2V0cy5sZW5ndGggPiAwICYmIG9mZnNldCA9PT0gZXhpc3RpbmdPZmZzZXRzW2V4aXN0aW5nT2Zmc2V0cy5sZW5ndGggLSAxXSArIDFcblxuXHRcdGlmICghcmVmSGFzT2Zmc2V0ICYmICFpc1NlcXVlbnRpYWwpIGNvbnRpbnVlXG5cblx0XHQvLyBJbmhlcml0IGxhYmVsIGZyb20gcmVmZXJlbmNlIG1vZGVsIGlmIGF2YWlsYWJsZSwgb3RoZXJ3aXNlIGdlbmVyYXRlIG9uZVxuXHRcdGxldCBsYWJlbCA9IGBDaGFubmVsICR7b2Zmc2V0ICsgMX1gXG5cdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWRBZGRCYXNlLmlkKVxuXHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGNvbnN0IHJlZkNob2ljZSA9IHJlZklkQWRkPy5jaG9pY2VzPy5maW5kKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0aWYgKHJlZkNob2ljZSkge1xuXHRcdFx0XHRsYWJlbCA9IHJlZkNob2ljZS5sYWJlbFxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlkQWRkT3B0LmNob2ljZXMucHVzaCh7IGlkOiBvZmZzZXQsIGxhYmVsIH0pXG5cdFx0bG9nZ2VyLmluZm8oXG5cdFx0XHRgUGFzcyAyOiBGb2xkZWQgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGludG8gaWRBZGQgYmFzZSBpZD0ke3RvSGV4KGlkQWRkQmFzZS5pZCl9IGFzIG9mZnNldCAke29mZnNldH0gKFwiJHtsYWJlbH1cIilgLFxuXHRcdClcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0FWRVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gc2F2ZU1vZGVsSnNvblByZXR0eShmaWxlUGF0aDogc3RyaW5nLCBqc29uT2JqOiBTdE1vZGVsSnNvbik6IHZvaWQge1xuXHR0cnkge1xuXHRcdC8vIEVuc3VyZSBwcm9wZXIga2V5IG9yZGVyaW5nOiBtb2RlbCwgc2VjdGlvbmVkIChpZiBwcmVzZW50KSwgcmVmcmVzaEFmdGVyQ29tbWFuZCwgY21kU2NoZW1hXG5cdFx0Y29uc3Qgb3JkZXJlZE9iajogYW55ID0geyBtb2RlbDoganNvbk9iai5tb2RlbCB9XG5cblx0XHQvLyBBZGQgc2VjdGlvbmVkIGtleSBpZiBwcmVzZW50IChyaWdodCBhZnRlciBtb2RlbClcblx0XHRpZiAoJ3NlY3Rpb25lZCcgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5zZWN0aW9uZWQgPSBqc29uT2JqLnNlY3Rpb25lZFxuXHRcdH1cblxuXHRcdC8vIEFkZCBvdGhlciBrZXlzIGluIG9yZGVyXG5cdFx0aWYgKCdyZWZyZXNoQWZ0ZXJDb21tYW5kJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLnJlZnJlc2hBZnRlckNvbW1hbmQgPSBqc29uT2JqLnJlZnJlc2hBZnRlckNvbW1hbmRcblx0XHR9XG5cdFx0aWYgKCdjbWRTY2hlbWEnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmouY21kU2NoZW1hID0ganNvbk9iai5jbWRTY2hlbWEubWFwKChlbnRyeTogYW55KSA9PiB7XG5cdFx0XHRcdC8vIEVuZm9yY2Uga2V5IG9yZGVyIHdpdGhpbiBlYWNoIHNjaGVtYSBlbnRyeTogY21kX2lkLCBpZCwgYnVzQ2gsIG5hbWUsIG9wdGlvbnNcblx0XHRcdFx0Y29uc3Qgb3JkZXJlZEVudHJ5OiBhbnkgPSB7fVxuXHRcdFx0XHRpZiAoJ2NtZF9pZCcgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5jbWRfaWQgPSBlbnRyeS5jbWRfaWRcblx0XHRcdFx0aWYgKCdpZCcgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5pZCA9IGVudHJ5LmlkXG5cdFx0XHRcdGlmICgnYnVzQ2gnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkuYnVzQ2ggPSBlbnRyeS5idXNDaFxuXHRcdFx0XHRpZiAoJ25hbWUnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkubmFtZSA9IGVudHJ5Lm5hbWVcblx0XHRcdFx0aWYgKCdvcHRpb25zJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5Lm9wdGlvbnMgPSBlbnRyeS5vcHRpb25zXG5cdFx0XHRcdC8vIENvcHkgYW55IHJlbWFpbmluZyBrZXlzXG5cdFx0XHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGVudHJ5KSkge1xuXHRcdFx0XHRcdGlmICghKGtleSBpbiBvcmRlcmVkRW50cnkpKSBvcmRlcmVkRW50cnlba2V5XSA9IGVudHJ5W2tleV1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gb3JkZXJlZEVudHJ5XG5cdFx0XHR9KVxuXHRcdH1cblx0XHQvLyBDb3B5IGFueSBvdGhlciBrZXlzIHRoYXQgbWlnaHQgZXhpc3Rcblx0XHRmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhqc29uT2JqKSkge1xuXHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRPYmopKSB7XG5cdFx0XHRcdG9yZGVyZWRPYmpba2V5XSA9IChqc29uT2JqIGFzIGFueSlba2V5XVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIEN1c3RvbSBmb3JtYXR0ZXI6IGtlZXAgY2hvaWNlIG9iamVjdHMgY29tcGFjdCBvbiBvbmUgbGluZVxuXHRcdGxldCBqc29uID0gSlNPTi5zdHJpbmdpZnkob3JkZXJlZE9iaiwgbnVsbCwgMilcblxuXHRcdC8vIFJlcGxhY2UgZXhwYW5kZWQgY2hvaWNlIG9iamVjdHMgd2l0aCBjb21wYWN0IHNpbmdsZS1saW5lIGZvcm1hdFxuXHRcdC8vIE1hdGNoZXM6IHtcXG4gICAgICAgICAgICBcImlkXCI6IFgsXFxuICAgICAgICAgICAgXCJsYWJlbFwiOiBcIllcIlxcbiAgICAgICAgICB9XG5cdFx0Ly8gUmVwbGFjZXMgd2l0aDogeyBcImlkXCI6IFgsIFwibGFiZWxcIjogXCJZXCIgfVxuXHRcdGpzb24gPSBqc29uLnJlcGxhY2UoL1xce1xcblxccytcImlkXCI6XFxzKihcXGQrKSxcXG5cXHMrXCJsYWJlbFwiOlxccypcIihbXlwiXSopXCJcXG5cXHMrXFx9L2csICd7IFwiaWRcIjogJDEsIFwibGFiZWxcIjogXCIkMlwiIH0nKVxuXG5cdFx0ZnMud3JpdGVGaWxlU3luYyhmaWxlUGF0aCwganNvbiArICdcXG4nLCAndXRmOCcpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZXJyb3IoYEZpbGUgV3JpdGUgRXJyb3I6ICR7ZX1gKVxuXHR9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIExPQUQgREVWSUNFIEpTT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBMb2FkcyB0aGUgYWN0aW9ucyBhcnJheSBmb3IgYSBnaXZlbiBtb2RlbCBmcm9tIHRoZSBjZW50cmFsaXplZCBjYWNoZS5cbiAqIFJldHVybnMgYW4gZW1wdHkgYXJyYXkgaWYgdGhlIG1vZGVsIGlzIG5vdCBmb3VuZC5cbiAqIEBkZXByZWNhdGVkIC0gVGhpcyBmdW5jdGlvbiBpcyBubyBsb25nZXIgbmVlZGVkLiBVc2UgZ2V0RGV2aWNlU2NoZW1hKCkgZnJvbSBjb25maWcudHMgaW5zdGVhZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxvYWRBY3Rpb25zRm9yTW9kZWwoX2RldmljZXNGb2xkZXI6IHN0cmluZywgbW9kZWw6IHN0cmluZyk6IFN0QWN0aW9uW10ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdHJldHVybiBzY2hlbWE/LmNtZFNjaGVtYSA/PyBbXVxufVxuXG4vKipcbiAqIExvYWRzIHRoZSBtb2RlbCBjb25maWd1cmF0aW9uIGZyb20gdGhlIGNlbnRyYWxpemVkIGNhY2hlLlxuICogQGRlcHJlY2F0ZWQgLSBUaGlzIGZ1bmN0aW9uIGlzIG5vIGxvbmdlciBuZWVkZWQuIFVzZSBnZXREZXZpY2VTY2hlbWEoKSBmcm9tIGNvbmZpZy50cyBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZE1vZGVsQ29uZmlnKFxuXHRfZGV2aWNlc0ZvbGRlcjogc3RyaW5nLFxuXHRtb2RlbDogc3RyaW5nLFxuKTogeyBhY3Rpb25zOiBTdEFjdGlvbltdOyByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuIH0ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdHJldHVybiB7XG5cdFx0YWN0aW9uczogc2NoZW1hPy5jbWRTY2hlbWEgPz8gW10sXG5cdFx0cmVmcmVzaEFmdGVyQ29tbWFuZDogc2NoZW1hPy5yZWZyZXNoQWZ0ZXJDb21tYW5kID8/IHRydWUsIC8vIERlZmF1bHQgdG8gdHJ1ZSBpZiBub3Qgc3BlY2lmaWVkXG5cdH1cbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRGZWVkYmFja3MgfSBmcm9tICcuL2J1aWxkLWNvbW1hbmRzLmpzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzLCBmaW5kQWN0aW9uRm9yU2V0dGluZyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbi8qKlxuICogSGVscGVyIGZ1bmN0aW9uIHRvIGdldCBsYWJlbCBmcm9tIGNob2ljZXMgYmFzZWQgb24gdmFsdWVcbiAqL1xuZnVuY3Rpb24gZ2V0TGFiZWxGb3JWYWx1ZShcblx0c2NoZW1hczogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+LFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyLFxuXHRzZXR0aW5nSWQ6IG51bWJlcixcblx0dmFsdWU6IG51bWJlcixcbik6IHN0cmluZyB8IG51bWJlciB7XG5cdGNvbnN0IHNldHRpbmcgPSBmaW5kQWN0aW9uRm9yU2V0dGluZyhzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZClcblx0aWYgKCFzZXR0aW5nIHx8ICFBcnJheS5pc0FycmF5KHNldHRpbmcub3B0aW9ucykpIHJldHVybiB2YWx1ZVxuXG5cdC8vIEZpbmQgdGhlICd2YWx1ZScgb3B0aW9uIHdoaWNoIGNvbnRhaW5zIHRoZSBjaG9pY2VzXG5cdGNvbnN0IHZhbHVlT3B0aW9uID0gc2V0dGluZy5vcHRpb25zLmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdGlmICghdmFsdWVPcHRpb24gfHwgIUFycmF5LmlzQXJyYXkodmFsdWVPcHRpb24uY2hvaWNlcykpIHJldHVybiB2YWx1ZVxuXG5cdC8vIEZpbmQgdGhlIGNob2ljZSB3aXRoIG1hdGNoaW5nIGlkXG5cdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYzogYW55KSA9PiBjLmlkID09PSB2YWx1ZSlcblx0cmV0dXJuIGNob2ljZT8ubGFiZWwgPz8gdmFsdWVcbn1cblxuLyoqXG4gKiBCdWlsZCBhbmQgd2lyZSBDb21wYW5pb24gZmVlZGJhY2sgZGVmaW5pdGlvbnNcbiAqIFBhdHRlcm4gbWF0Y2hlcyBhY3Rpb25zLnRzIC0gZmlsdGVycyBieSBhY3RpdmUgbW9kZWwgYW5kIHdpcmVzIGNhbGxiYWNrc1xuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlRmVlZGJhY2tzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IHNjaGVtYXNSYXcgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgcmF3RmVlZGJhY2tzID0gYnVpbGRGZWVkYmFja3MoKVxuXHRjb25zdCBzY2hlbWFzID0gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoc2NoZW1hc1Jhdylcblx0Y29uc3Qgd2lyZWRGZWVkYmFja3M6IGFueSA9IHt9XG5cblx0Ly8gR2V0IHRoZSBhY3RpdmUgbW9kZWwgZnJvbSB0aGUgY2FjaGVkIHZhbHVlIHNldCBieSBzeW5jTW9kZWwoKVxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEZFRURCQUNLUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFtmZWVkYmFja0lkLCBmZWVkYmFja10gb2YgT2JqZWN0LmVudHJpZXMocmF3RmVlZGJhY2tzKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGZlZWRiYWNrSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgZmVlZGJhY2tzIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBtb2RlbFxuXHRcdGlmIChtb2RlbCAhPT0gYWN0aXZlTW9kZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBWQUxVRSBGRUVEQkFDSzogUmV0dXJucyBjdXJyZW50IHZhbHVlIGZvciBsb2NhbCB2YXJpYWJsZVxuXHRcdHdpcmVkRmVlZGJhY2tzW2ZlZWRiYWNrSWRdID0ge1xuXHRcdFx0Li4uZmVlZGJhY2ssXG5cdFx0XHRjYWxsYmFjazogKGZlZWRiYWNrRXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cblx0XHRcdFx0Ly8gYnVzQ2ggZnJvbSBvcHRpb25zIHRha2VzIHByaW9yaXR5OyBmYWxsIGJhY2sgdG8gZml4ZWQgYnVzQ2ggaW4gc2NoZW1hXG5cdFx0XHRcdGxldCBidXNDaCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snYnVzQ2gnXVxuXHRcdFx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdGNvbnN0IHNjaGVtYUFjdGlvbiA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGlmIChzY2hlbWFBY3Rpb24/LmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdGJ1c0NoID0gc2NoZW1hQWN0aW9uLmJ1c0NoXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Y29uc3QgY3VycmVudCA9IHNlbGYuc3RDb250cm9sbGVyLmdldFNldHRpbmdWYWx1ZShpcCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cblx0XHRcdFx0Ly8gQ2hlY2sgaWYgdXNlciB3YW50cyBsYWJlbCBpbnN0ZWFkIG9mIG51bWVyaWMgdmFsdWVcblx0XHRcdFx0Y29uc3Qgc2hvd0xhYmVsID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydzaG93TGFiZWwnXSA/PyBmYWxzZVxuXG5cdFx0XHRcdGlmIChzaG93TGFiZWwgJiYgY3VycmVudCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Ly8gUmV0dXJuIHRoZSBsYWJlbCBmcm9tIGNob2ljZXNcblx0XHRcdFx0XHRyZXR1cm4gZ2V0TGFiZWxGb3JWYWx1ZShzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgY3VycmVudClcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFJldHVybiBudW1lcmljIHZhbHVlIGRpcmVjdGx5IGZvciBsb2NhbCB2YXJpYWJsZSAodHlwZTogJ3ZhbHVlJylcblx0XHRcdFx0cmV0dXJuIGN1cnJlbnQgPz8gMFxuXHRcdFx0fSxcblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEZlZWRiYWNrRGVmaW5pdGlvbnMod2lyZWRGZWVkYmFja3MpXG5cblx0Ly9jb25zb2xlLmxvZygnRmVlZGJhY2tzOlxcbicsIEpTT04uc3RyaW5naWZ5KHdpcmVkRmVlZGJhY2tzLCBudWxsLCAyKSlcbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHtcblx0Q01EX0JVU19HRVQsXG5cdENNRF9CVVNfU0VULFxuXHRDTURfREVWX1NQRUMsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfR0VUX0ZJUk1XQVJFLFxuXHRDTURfR0xPQkFMX01JQ19LSUxMLFxuXHRDTURfTUlDX1BSRSxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfUkVTRVRfREVWSUNFLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0Z2V0Q29tbWFuZE5hbWUsXG5cdG1ha2VTZXR0aW5nSWQsXG5cdHRvSGV4LFxuXHRieXRlc1RvSGV4LFxuXHR0eXBlIERldmljZUluZm8sXG59IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQge1xuXHRwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwsXG5cdHBhcnNlU2V0dGluZ3NSZXNwb25zZSxcblx0Zm9ybWF0UGFyc2VkU2V0dGluZyxcblx0dHlwZSBTdEFjdGlvbixcblx0dHlwZSBQYXJzZWRTZXR0aW5nLFxufSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuaW1wb3J0IHtcblx0REFOVEVfTVNHX0lORk9fUkVTUE9OU0UsXG5cdHBhcnNlRGFudGVJbmZvUmVzcG9uc2UsXG5cdGRpc2NvdmVyRGV2aWNlcyxcblx0YnVpbGREYW50ZUluZm9SZXF1ZXN0LFxuXHRnZXRNYWNGb3JEZXN0aW5hdGlvbixcblx0Z2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24sXG59IGZyb20gJy4vZGFudGUuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU3RDb250cm9sbGVyJylcblxuZXhwb3J0IGNsYXNzIFN0Q29udHJvbGxlciB7XG5cdHByaXZhdGUgcmVhZG9ubHkgZGVmYXVsdFBvcnQ6IG51bWJlciA9IDg3MDBcblx0cHJpdmF0ZSByZWFkb25seSBtdWx0aWNhc3RHcm91cCA9ICcyMjQuMC4wLjIzMSdcblx0cHJpdmF0ZSByZWFkb25seSByeFBvcnQgPSA4NzAyXG5cblx0cHJpdmF0ZSB0eFNvY2tldDogZGdyYW0uU29ja2V0XG5cdHByaXZhdGUgcnhTb2NrZXQ6IGRncmFtLlNvY2tldCAvLyBmb3IgcmVjZWl2aW5nIHJlc3BvbnNlcyAoODcwMilcblx0cHJpdmF0ZSBwZW5kaW5nQWNrczogTWFwPFxuXHRcdHN0cmluZyxcblx0XHR7IHJlc29sdmU6IChidWY6IEJ1ZmZlcikgPT4gdm9pZDsgcmVqZWN0OiAoZTogRXJyb3IpID0+IHZvaWQ7IHRpbWVyOiBOb2RlSlMuVGltZW91dCB9XG5cdD4gPSBuZXcgTWFwKClcblx0cHJpdmF0ZSBqb2luZWRJbnRlcmZhY2VzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKSAvLyBsb2NhbCBJUHMgd2UndmUgam9pbmVkIG11bHRpY2FzdCBvblxuXG5cdC8qKiBTZXJpYWxpemVzIG91dGdvaW5nIGNvbW1hbmRzIHNvIGVhY2ggd2FpdHMgZm9yIEFDSyBiZWZvcmUgdGhlIG5leHQgaXMgc2VudCAqL1xuXHRwcml2YXRlIHNlbmRRdWV1ZTogUHJvbWlzZTx2b2lkPiA9IFByb21pc2UucmVzb2x2ZSgpXG5cblx0LyoqIFRyYWNrcyBob3cgbWFueSBjb21tYW5kcyBhcmUgcXVldWVkL2luLWZsaWdodCwgdG8gZGVmZXIgcmVxdWVzdEFsbFNldHRpbmdzICovXG5cdHByaXZhdGUgcGVuZGluZ0NvbW1hbmRDb3VudCA9IDBcblxuXHQvKiogUmVzb2x2ZXMgb25jZSB0eFNvY2tldCBpcyBib3VuZCBhbmQgcmVhZHkgdG8gc2VuZCAqL1xuXHRwcml2YXRlIHR4UmVhZHk6IFByb21pc2U8dm9pZD5cblxuXHQvKiogQWN0aXZlIGRldmljZSBtb2RlbCBhbmQgYWN0aW9uIGRlZmluaXRpb25zIGZvciBzZXR0aW5ncyBkZWNvZGluZyAqL1xuXHRwcml2YXRlIG1vZGVsOiBzdHJpbmcgPSAnJ1xuXHRwcml2YXRlIGFjdGlvbnM6IFN0QWN0aW9uW10gPSBbXVxuXHRwcml2YXRlIHJlZnJlc2hBZnRlckNvbW1hbmQ6IGJvb2xlYW4gPSB0cnVlIC8vIERlZmF1bHQgdG8gdHJ1ZSAobW9zdCBkZXZpY2VzIG5lZWQgaXQpXG5cblx0LyoqXG5cdCAqIEtub3duIHN0YXRlIG9mIGV2ZXJ5IHNldHRpbmcgcGVyIGRldmljZSBJUC5cblx0ICogS2V5ZWQgYnkgSVAgXHUyMTkyIE1hcCBvZiBcIiR7Y21kSWR9LyR7c2V0dGluZ0lkfVwiIFx1MjE5MiBjdXJyZW50IHZhbHVlIGJ5dGUuXG5cdCAqIFBvcHVsYXRlZCBvbiBjb25uZWN0IHZpYSByZXF1ZXN0QWxsU2V0dGluZ3MoKSwgdXBkYXRlZCBvbiBldmVyeSBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikuXG5cdCAqIFVzZWQgdG8gZGlmZiBpbmNvbWluZyBwdXNoZXMgKGNoYW5nZWQgPSBpbmZvLCB1bmNoYW5nZWQgPSBkZWJ1ZykgYW5kIGZvciBmZWVkYmFja3MuXG5cdCAqL1xuXHRwcml2YXRlIGRldmljZVN0YXRlOiBNYXA8c3RyaW5nLCBNYXA8c3RyaW5nLCBudW1iZXI+PiA9IG5ldyBNYXAoKVxuXG5cdC8qKlxuXHQgKiBJUHMgdGhhdCBoYXZlIGJlZW4gdmVyaWZpZWQgYWdhaW5zdCB0aGUgY29uZmlndXJlZCBtb2RlbCBhbmQgYXJlIGFsbG93ZWRcblx0ICogdG8gcmVjZWl2ZSBTdHVkaW8tVCBjb21tYW5kcy4gUG9wdWxhdGVkIGJ5IGF1dGhvcml6ZURldmljZSgpIGFmdGVyIGFcblx0ICogc3VjY2Vzc2Z1bCBwcm9iZURldmljZSgpIG1vZGVsIG1hdGNoLCBvciBhZnRlciBtdWx0aWNhc3QgZGlzY292ZXJ5LlxuXHQgKiBfc2VuZEF3YWl0QWNrKCkgcmVqZWN0cyBhbnkgZGVzdElwIG5vdCBpbiB0aGlzIHNldC5cblx0ICovXG5cdHByaXZhdGUgYXV0aG9yaXplZElwczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KClcblxuXHQvKiogQ2FsbGJhY2tzIHJlZ2lzdGVyZWQgYnkgZGlzY292ZXJEZXZpY2VzKCkgXHUyMDE0IGtleWVkIGJ5IHNvdXJjZSBJUCAqL1xuXHRwcml2YXRlIGRpc2NvdmVyeUxpc3RlbmVyczogTWFwPHN0cmluZywgKGRldmljZTogRGV2aWNlSW5mbykgPT4gdm9pZD4gPSBuZXcgTWFwKClcblxuXHQvKiogQ2FsbGJhY2sgdG8gdHJpZ2dlciBmZWVkYmFjayB1cGRhdGVzIHdoZW4gc3RhdGUgY2hhbmdlcyAqL1xuXHRwcml2YXRlIGZlZWRiYWNrQ2FsbGJhY2s/OiAoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB2b2lkXG5cblx0LyoqIENhY2hlIG9mIGxvY2FsIGludGVyZmFjZSBNQUMgYnl0ZXMgcGVyIGRlc3RpbmF0aW9uIElQLCB0byBhdm9pZCByZXBlYXRlZCBPUyBsb29rdXBzICovXG5cdHByaXZhdGUgbWFjQ2FjaGU6IE1hcDxzdHJpbmcsIG51bWJlcltdPiA9IG5ldyBNYXAoKVxuXG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdGxvZ2dlci5pbmZvKCdTdENvbnRyb2xsZXIgaW5pdGlhbGl6ZWQnKVxuXG5cdFx0Ly8gU2VuZCBzb2NrZXQgXHUyMDE0IGJpbmQgdG8gZXBoZW1lcmFsIHBvcnQuIFJlc3BvbnNlcyBhbHdheXMgZ28gdG8gcnhTb2NrZXQgb25cblx0XHQvLyBwb3J0IDg3MDIgKERhbnRlIGhhcmRjb2RlcyB0aGUgcmVzcG9uc2UgZGVzdGluYXRpb24gcG9ydCB0byA4NzAyKS5cblx0XHR0aGlzLnR4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnR4UmVhZHkgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0dGhpcy50eFNvY2tldC5iaW5kKDAsICgpID0+IHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBUWCBzb2NrZXQgYm91bmQgdG8gcG9ydCAkeyh0aGlzLnR4U29ja2V0LmFkZHJlc3MoKSBhcyB7IHBvcnQ6IG51bWJlciB9KS5wb3J0fWApXG5cdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdHRoaXMudHhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBUWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdC8vIFJlY2VpdmUgc29ja2V0IC0gYmluZCB0byBhbGwgYWRkcmVzc2VzIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0c1xuXHRcdHRoaXMucnhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbGlzdGVuaW5nJywgKCkgPT4ge1xuXHRcdFx0Y29uc3QgYWRkciA9IHRoaXMucnhTb2NrZXQuYWRkcmVzcygpXG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBsaXN0ZW5pbmcgb24gJHtKU09OLnN0cmluZ2lmeShhZGRyKX1gKVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5zZXRNdWx0aWNhc3RMb29wYmFjayh0cnVlKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBSWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5oYW5kbGVJbmNvbWluZyhtc2csIHJpbmZvLmFkZHJlc3MpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoYEVycm9yIGhhbmRsaW5nIGluY29taW5nIG1lc3NhZ2U6ICR7X2V9YClcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gQmluZCB0byB3aWxkY2FyZCBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHMgZm9yIGpvaW5lZCBpbnRlcmZhY2VzXG5cdFx0dGhpcy5yeFNvY2tldC5iaW5kKHsgYWRkcmVzczogJzAuMC4wLjAnLCBwb3J0OiB0aGlzLnJ4UG9ydCB9LCAoKSA9PiB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBib3VuZCB0byAwLjAuMC4wOiR7dGhpcy5yeFBvcnR9YClcblx0XHR9KVxuXHR9XG5cblx0cHVibGljIGNsb3NlKCk6IHZvaWQge1xuXHRcdHRyeSB7XG5cdFx0XHRmb3IgKGNvbnN0IGxvY2FsQWRkciBvZiBBcnJheS5mcm9tKHRoaXMuam9pbmVkSW50ZXJmYWNlcykpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR0aGlzLnJ4U29ja2V0LmRyb3BNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy5yeFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFByb3ZpZGUgdGhlIGFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBzbyBpbmNvbWluZyBtZXNzYWdlc1xuXHQgKiBjYW4gYmUgZGVjb2RlZCBpbnRvIGh1bWFuLXJlYWRhYmxlIG5hbWVzLiBDYWxsIGZyb20gbWFpbi50cyBhZnRlciBjb25maWcgbG9hZC5cblx0ICovXG5cdHB1YmxpYyBzZXRNb2RlbChtb2RlbDogc3RyaW5nLCBhY3Rpb25zOiBTdEFjdGlvbltdLCByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xuXHRcdHRoaXMubW9kZWwgPSBtb2RlbFxuXHRcdHRoaXMuYWN0aW9ucyA9IGFjdGlvbnNcblx0XHR0aGlzLnJlZnJlc2hBZnRlckNvbW1hbmQgPSByZWZyZXNoQWZ0ZXJDb21tYW5kXG5cdH1cblxuXHQvKipcblx0ICogU2V0IGNhbGxiYWNrIHRvIHRyaWdnZXIgd2hlbiBkZXZpY2Ugc3RhdGUgY2hhbmdlcyAoZm9yIGZlZWRiYWNrcykuXG5cdCAqIENhbGwgZnJvbSBtYWluLnRzIHRvIHdpcmUgdXAgY2hlY2tGZWVkYmFja3MuXG5cdCAqL1xuXHRwdWJsaWMgc2V0RmVlZGJhY2tDYWxsYmFjayhjYWxsYmFjazogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZCk6IHZvaWQge1xuXHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayA9IGNhbGxiYWNrXG5cdH1cblxuXHQvKiogUmV0dXJucyB0cnVlIGlmIHRoZSBkZXZpY2UgYXQgdGhlIGdpdmVuIElQIGhhcyBiZWVuIGF1dGhvcml6ZWQgdG8gcmVjZWl2ZSBjb21tYW5kcy4gKi9cblx0cHVibGljIGlzRGV2aWNlQXV0aG9yaXplZChpcDogc3RyaW5nKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuYXV0aG9yaXplZElwcy5oYXMoaXApXG5cdH1cblxuXHQvKiogTWFyayBhbiBJUCBhcyB2ZXJpZmllZCBhbmQgYWxsb3dlZCB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgYXV0aG9yaXplRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuYWRkKGlwKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgQXV0aG9yaXplZCBkZXZpY2UgYXQgJHtpcH1gKVxuXHR9XG5cblx0LyoqIFJlbW92ZSBhdXRob3JpemF0aW9uIGZvciBhbiBJUCAoZS5nLiBvbiBjb25maWcgY2hhbmdlIG9yIG1vZGVsIG1pc21hdGNoKS4gKi9cblx0cHVibGljIHJldm9rZURldmljZShpcDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hdXRob3JpemVkSXBzLmRlbGV0ZShpcClcblx0XHR0aGlzLmRldmljZVN0YXRlLmRlbGV0ZShpcClcblx0XHR0aGlzLm1hY0NhY2hlLmRlbGV0ZShpcClcblx0XHRsb2dnZXIuZGVidWcoYFJldm9rZWQgZGV2aWNlIGF0ICR7aXB9YClcblx0fVxuXG5cdC8qKlxuXHQgKiBTZW5kcyBhIHVuaWNhc3QgRGFudGUgaW5mbyByZXF1ZXN0IHRvIGEgc3BlY2lmaWMgSVAgYW5kIHdhaXRzIGZvciB0aGVcblx0ICogZGV2aWNlIGluZm8gcmVzcG9uc2UuIFJldHVybnMgdGhlIERldmljZUluZm8gaWYgdGhlIGRldmljZSByZXNwb25kcyB3aXRoaW5cblx0ICogdGltZW91dE1zLCBvciBudWxsIGlmIG5vIHJlc3BvbnNlLiBVc2VkIHRvIHZlcmlmeSBhIG1hbnVhbGx5IGNvbmZpZ3VyZWQgSVAuXG5cdCAqIERvZXMgTk9UIHJlcXVpcmUgYXV0aG9yaXphdGlvbiBcdTIwMTQgdGhpcyBpcyBob3cgYXV0aG9yaXphdGlvbiBpcyBlc3RhYmxpc2hlZC5cblx0ICovXG5cdHB1YmxpYyBhc3luYyBwcm9iZURldmljZShpcDogc3RyaW5nLCB0aW1lb3V0TXMgPSAzMDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4oKHJlc29sdmUpID0+IHtcblx0XHRcdGNvbnN0IGtleSA9IGBfX3Byb2JlXyR7aXB9X19gXG5cdFx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXG5cdFx0XHRjb25zdCBmaW5pc2ggPSAocmVzdWx0OiBEZXZpY2VJbmZvIHwgbnVsbCkgPT4ge1xuXHRcdFx0XHRpZiAocmVzb2x2ZWQpIHJldHVyblxuXHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKGtleSlcblx0XHRcdFx0cmVzb2x2ZShyZXN1bHQpXG5cdFx0XHR9XG5cblx0XHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChrZXksIChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdFx0aWYgKGRldmljZS5pcCA9PT0gaXApIGZpbmlzaChkZXZpY2UpXG5cdFx0XHR9KVxuXG5cdFx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gZmluaXNoKG51bGwpLCB0aW1lb3V0TXMpXG5cdFx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdFx0Y29uc3QgcnVuID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRhd2FpdCB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoaXApXG5cdFx0XHRcdGF3YWl0IHRoaXMudHhSZWFkeVxuXHRcdFx0XHRjb25zdCBxdWVyeSA9IGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpXG5cdFx0XHRcdHRoaXMudHhTb2NrZXQuc2VuZChxdWVyeSwgdGhpcy5kZWZhdWx0UG9ydCwgaXAsIChlcnIpID0+IHtcblx0XHRcdFx0XHRpZiAoZXJyKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2FybihgUHJvYmUgdG8gJHtpcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0XHRmaW5pc2gobnVsbClcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cblx0XHRcdHJ1bigpLmNhdGNoKChlKSA9PiB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBwcm9iZURldmljZSBzZXR1cCBmYWlsZWQgZm9yICR7aXB9OiAke2V9YClcblx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRmaW5pc2gobnVsbClcblx0XHRcdH0pXG5cdFx0fSlcblx0fVxuXG5cdC8qKlxuXHQgKiBTZW5kIGEgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIHJlcXVlc3QgdG8gdGhlIGRldmljZSBhbmQgc3RvcmUgdGhlIHJlc3BvbnNlXG5cdCAqIGluIGRldmljZVN0YXRlLiBSZXR1cm5zIHRoZSByYXcgcmVzcG9uc2UgYnVmZmVyIGZvciBwYXJzaW5nLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHJlcXVlc3RBbGxTZXR0aW5ncyhkZXZpY2VJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRsb2dnZXIuaW5mbyhgUmVxdWVzdGluZyBhbGwgc2V0dGluZ3MgZnJvbSAke2RldmljZUlwfWApXG5cdFx0Y29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0VUX0FMTF9TRVRUSU5HUywgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGV2aWNlSXAsIGZhbHNlKVxuXHRcdC8vIGRldmljZVN0YXRlIGlzIHBvcHVsYXRlZCBieSBsb2dTdFBheWxvYWQgd2hlbiB0aGUgQ01EX0dFVF9BTExfU0VUVElOR1MgcmVzcG9uc2UgYXJyaXZlc1xuXHRcdHJldHVybiByZXNwb25zZVxuXHR9XG5cblx0LyoqXG5cdCAqIERpc2NvdmVycyBTdHVkaW8gVGVjaG5vbG9naWVzIERhbnRlIGRldmljZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsuXG5cdCAqXG5cdCAqIFN0cmF0ZWd5OlxuXHQgKiAgRGFudGUgZGV2aWNlcyBicm9hZGNhc3QgYSAxLXNlY29uZCBhbm5vdW5jZSB0byBtdWx0aWNhc3QgMjI0LjAuMC4yMzM6ODcwOC5cblx0ICogIFdlIGxpc3RlbiBvbiB0aGF0IGdyb3VwLCBjb2xsZWN0IHNvdXJjZSBJUHMsIHRoZW4gc2VuZCBhIHVuaWNhc3QgZGV2aWNlIGluZm9cblx0ICogIHJlcXVlc3QgKDB4MDAyMCkgdG8gZWFjaCBuZXcgSVAgb24gcG9ydCA4NzAwLiBUaGUgZGV2aWNlIHJlc3BvbmRzIHRvIG91ciBJUFxuXHQgKiAgb24gcG9ydCA4NzAyIChyeFNvY2tldCksIHdoZXJlIGhhbmRsZUluY29taW5nKCkgcGlja3MgaXQgdXAgYW5kIGZpcmVzIHRoZVxuXHQgKiAgZGlzY292ZXJ5TGlzdGVuZXJzIGNhbGxiYWNrLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIGRpc2NvdmVyRGV2aWNlcyh0aW1lb3V0TXMgPSA1MDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvW10+IHtcblx0XHQvLyBSZWdpc3RlciBsaXN0ZW5lciBcdTIwMTQgaGFuZGxlSW5jb21pbmcoKSBmaXJlcyB0aGlzIGZvciBlYWNoIDB4MDE3MCByZXNwb25zZVxuXHRcdGNvbnN0IERJU0NPVkVSWV9LRVkgPSAnX19kaXNjb3ZlcnlfXydcblx0XHRjb25zdCBmb3VuZERldmljZXM6IERldmljZUluZm9bXSA9IFtdXG5cblx0XHRjb25zdCBvbkRldmljZUZvdW5kID0gKGRldmljZTogRGV2aWNlSW5mbykgPT4ge1xuXHRcdFx0aWYgKCFmb3VuZERldmljZXMuc29tZSgoZCkgPT4gZC5pcCA9PT0gZGV2aWNlLmlwKSkge1xuXHRcdFx0XHRmb3VuZERldmljZXMucHVzaChkZXZpY2UpXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gUmVnaXN0ZXIgdGhlIGNhbGxiYWNrIHNvIGhhbmRsZUluY29taW5nKCkgY2FuIGludm9rZSBpdCB3aGVuIDB4MDE3MCBhcnJpdmVzXG5cdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KERJU0NPVkVSWV9LRVksIG9uRGV2aWNlRm91bmQpXG5cblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0XHQvLyBkaXNjb3ZlckRldmljZXMoKSBpbiBkYW50ZS50cyBoYW5kbGVzIHRoZSBhbm5vdW5jZSBsaXN0ZW5pbmcgYW5kIHF1ZXJ5IHNlbmRpbmcuXG5cdFx0XHQvLyBSZXNwb25zZXMgY29tZSBiYWNrIHRvIHJ4U29ja2V0IFx1MjE5MiBoYW5kbGVJbmNvbWluZygpIFx1MjE5MiBkaXNjb3ZlcnlMaXN0ZW5lcnMuXG5cdFx0XHRhd2FpdCBkaXNjb3ZlckRldmljZXModGhpcy50eFNvY2tldCwgYXN5bmMgKGRlc3RJcCkgPT4gdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcCksIHRpbWVvdXRNcylcblx0XHRcdHJldHVybiBmb3VuZERldmljZXNcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKERJU0NPVkVSWV9LRVkpXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFJlcXVlc3RzIGRldmljZSBmaXJtd2FyZSB2ZXJzaW9uIHZpYSBTdHVkaW8tVCBwcm90b2NvbCAoQ01EX0dFVF9GSVJNV0FSRSkuXG5cdCAqIFJldHVybnMgdGhlIGZpcm13YXJlIHZlcnNpb24gc3RyaW5nIChlLmcuLCBcIjMuMDFcIiwgXCIyLjJcIiwgXCIxLjA1XCIpLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHJlcXVlc3RGaXJtd2FyZVZlcnNpb24oZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgZmlybXdhcmUgdmVyc2lvbiBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HRVRfRklSTVdBUkUsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRldmljZUlwLCBmYWxzZSlcblxuXHRcdC8vIFJlc3BvbnNlIHN0cnVjdHVyZTogW2hlYWRlcl0gMHg1YSAweDgwIFtmaXJtd2FyZV9kYXRhXSBDUkNcblx0XHQvLyBGaXJtd2FyZSBkYXRhIHN0YXJ0cyBhdCBieXRlIDI2ICgyNC1ieXRlIGhlYWRlciArIDB4NWEgKyAweDgwKVxuXHRcdGNvbnN0IGRhdGFTdGFydCA9IDI2XG5cblx0XHRpZiAocmVzcG9uc2UubGVuZ3RoIDwgZGF0YVN0YXJ0ICsgMykge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEZpcm13YXJlIHJlc3BvbnNlIHRvbyBzaG9ydDogJHtyZXNwb25zZS5sZW5ndGh9IGJ5dGVzYClcblx0XHRcdHJldHVybiAnVW5rbm93bidcblx0XHR9XG5cblx0XHQvLyBGaXJtd2FyZSBmb3JtYXQ6IFt1bmtub3duX2J5dGUsIG1ham9yLCBtaW5vcl1cblx0XHRjb25zdCBtYWpvciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDFdXG5cdFx0Y29uc3QgbWlub3IgPSByZXNwb25zZVtkYXRhU3RhcnQgKyAyXVxuXG5cdFx0Y29uc3QgbWlub3JTdHIgPVxuXHRcdFx0bWlub3IgPCAxMFxuXHRcdFx0XHQ/IG1pbm9yLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKSAvLyBlLmcuIDEgXHUyMTkyIFwiMDFcIiwgNSBcdTIxOTIgXCIwNVwiXG5cdFx0XHRcdDogbWlub3IudG9TdHJpbmcoKSAvLyBlLmcuIDEwIFx1MjE5MiBcIjEwXCJcblxuXHRcdGNvbnN0IGZpcm13YXJlID0gYCR7bWFqb3J9LiR7bWlub3JTdHJ9YFxuXG5cdFx0bG9nZ2VyLmluZm8oYEZpcm13YXJlIHZlcnNpb246ICR7ZmlybXdhcmV9YClcblx0XHRyZXR1cm4gZmlybXdhcmVcblx0fVxuXG5cdC8qKlxuXHQgKiBKb2lucyB0aGUgbXVsdGljYXN0IHJlc3BvbnNlIGdyb3VwIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gZGVzdElwLlxuXHQgKiBPbmx5IGpvaW5zIHRoZSBzcGVjaWZpYyBpbnRlcmZhY2UgdXNlZCB0byByZWFjaCB0aGUgZGV2aWNlLCBhbmQgb25seSBvbmNlIHBlciBpbnRlcmZhY2UuXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIGVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYXdhaXQgZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24oZGVzdElwKVxuXHRcdFx0aWYgKCFsb2NhbEFkZHIpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBkZXRlcm1pbmUgbG9jYWwgYWRkcmVzcyBmb3IgZGVzdGluYXRpb24gJHtkZXN0SXB9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdGlmICh0aGlzLmpvaW5lZEludGVyZmFjZXMuaGFzKGxvY2FsQWRkcikpIHtcblx0XHRcdFx0Ly8gYWxyZWFkeSBqb2luZWRcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMucnhTb2NrZXQuYWRkTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBsb2NhbEFkZHIpXG5cdFx0XHRcdHRoaXMuam9pbmVkSW50ZXJmYWNlcy5hZGQobG9jYWxBZGRyKVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgSm9pbmVkIG11bHRpY2FzdCAke3RoaXMubXVsdGljYXN0R3JvdXB9IG9uICR7bG9jYWxBZGRyfWApXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIGpvaW4gbXVsdGljYXN0IG9uICR7bG9jYWxBZGRyfTogJHtTdHJpbmcoX2UpfWApXG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBlbnN1cmVNZW1iZXJzaGlwRm9yIGZhaWxlZDogJHtfZX1gKVxuXHRcdH1cblx0fVxuXG5cdHB1YmxpYyBhc3luYyBzZW5kQXdhaXRBY2soXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0dGhpcy5wZW5kaW5nQ29tbWFuZENvdW50Kytcblx0XHRyZXR1cm4gbmV3IFByb21pc2U8QnVmZmVyPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHR0aGlzLnNlbmRRdWV1ZSA9IHRoaXMuc2VuZFF1ZXVlLnRoZW4oYXN5bmMgKCkgPT5cblx0XHRcdFx0dGhpcy5fc2VuZEF3YWl0QWNrKGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgZGVzdElwLCBhZGRMZW4pXG5cdFx0XHRcdFx0LnRoZW4oKGJ1ZikgPT4ge1xuXHRcdFx0XHRcdFx0dGhpcy5wZW5kaW5nQ29tbWFuZENvdW50LS1cblx0XHRcdFx0XHRcdC8vIE9ubHkgdHJpZ2dlciByZXF1ZXN0QWxsU2V0dGluZ3MgYWZ0ZXIgYSB3cml0ZSAoU0VUKSBjb21tYW5kLCBub3QgYSByZWFkL3BvbGwuXG5cdFx0XHRcdFx0XHQvLyBBIHdyaXRlIGFsd2F5cyBoYXMgYSB2YWx1ZTsgcmVhZHMgKEdFVCwgQlVTX0dFVCkgbmV2ZXIgZG8uXG5cdFx0XHRcdFx0XHRpZiAodGhpcy5wZW5kaW5nQ29tbWFuZENvdW50ID09PSAwICYmIHRoaXMucmVmcmVzaEFmdGVyQ29tbWFuZCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRcdHRoaXMucmVxdWVzdEFsbFNldHRpbmdzKGRlc3RJcCkuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gcmVmcmVzaCBzZXR0aW5ncyBhZnRlciBjb21tYW5kOiAke2Vycn1gKVxuXHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0cmVzb2x2ZShidWYpXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0XHQuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0dGhpcy5wZW5kaW5nQ29tbWFuZENvdW50LS1cblx0XHRcdFx0XHRcdHJlamVjdChlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyciA6IG5ldyBFcnJvcihTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdFx0fSksXG5cdFx0XHQpXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgYXN5bmMgX3NlbmRBd2FpdEFjayhcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0KTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRjb25zdCB0aW1lb3V0TXMgPSAyMDAwXG5cblx0XHRjb25zdCBkYXRhQmxvY2s6IG51bWJlcltdID0gW11cblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKHNldHRpbmdJZCAmIDB4ZmYpXG5cdFx0aWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKC4uLlN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpKVxuXG5cdFx0Y29uc3QgcGF5bG9hZEJvZHk6IG51bWJlcltdID0gWzB4NWEsIGNtZElkICYgMHhmZl1cblxuXHRcdGlmIChjbWRJZCA9PT0gQ01EX01JQ19QUkUgJiYgYnVzQ2ggIT09IHVuZGVmaW5lZCAmJiBzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHQvLyBQb3NpdGlvbmFsIGZvcm1hdDogWzB4NWFdIFsweDAyXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gW3ZhbDJdIC4uLlxuXHRcdFx0Ly8gUmVhZCBhbGwgcG9zaXRpb25zIGZyb20gZGV2aWNlU3RhdGUsIG92ZXJyaWRlIHRoZSB0YXJnZXQgcG9zaXRpb24gd2l0aCBuZXcgdmFsdWUuXG5cdFx0XHQvLyBBbHNvIHVwZGF0ZSBkZXZpY2VTdGF0ZSBvcHRpbWlzdGljYWxseSBzbyBjb25zZWN1dGl2ZSBDTURfTUlDX1BSRSBjb21tYW5kcyBjaGFpbiBjb3JyZWN0bHkuXG5cdFx0XHRpZiAoIXRoaXMuZGV2aWNlU3RhdGUuaGFzKGRlc3RJcCkpIHRoaXMuZGV2aWNlU3RhdGUuc2V0KGRlc3RJcCwgbmV3IE1hcCgpKVxuXHRcdFx0Y29uc3QgaXBTdGF0ZSA9IHRoaXMuZGV2aWNlU3RhdGUuZ2V0KGRlc3RJcCkhXG5cdFx0XHRjb25zdCBudW1Qb3NpdGlvbnMgPSAzIC8vIGdhaW4sIGVsZWN0cmV0L3BoYW50b20sIHVua25vd25cblx0XHRcdGNvbnN0IHBvc2l0aW9uczogbnVtYmVyW10gPSBbXVxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBudW1Qb3NpdGlvbnM7IGkrKykge1xuXHRcdFx0XHRjb25zdCBzdGF0ZUtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgQ01EX01JQ19QUkUsIGksIGJ1c0NoKVxuXHRcdFx0XHRjb25zdCB2YWwgPSBpID09PSBzZXR0aW5nSWQgPyBOdW1iZXIodmFsdWUpIDogKGlwU3RhdGUuZ2V0KHN0YXRlS2V5KSA/PyAwKVxuXHRcdFx0XHRwb3NpdGlvbnMucHVzaCh2YWwpXG5cdFx0XHRcdGlwU3RhdGUuc2V0KHN0YXRlS2V5LCB2YWwpIC8vIG9wdGltaXN0aWMgdXBkYXRlXG5cdFx0XHR9XG5cdFx0XHRwYXlsb2FkQm9keS5wdXNoKGJ1c0NoICYgMHhmZiwgLi4ucG9zaXRpb25zKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgcGF5bG9hZEJvZHkucHVzaChidXNDaCAmIDB4ZmYpXG5cdFx0XHRpZiAoYWRkTGVuKSBwYXlsb2FkQm9keS5wdXNoKGRhdGFCbG9jay5sZW5ndGgpXG5cdFx0XHRpZiAoZGF0YUJsb2NrLmxlbmd0aCA+IDApIHBheWxvYWRCb2R5LnB1c2goLi4uZGF0YUJsb2NrKVxuXHRcdH1cblxuXHRcdGNvbnN0IGNyYyA9IFN0Q29udHJvbGxlci5jcmM4RHZiUzIocGF5bG9hZEJvZHkpXG5cdFx0Y29uc3QgcGF5bG9hZFdpdGhDcmMgPSBCdWZmZXIuZnJvbShbLi4ucGF5bG9hZEJvZHksIGNyY10pXG5cblx0XHQvLyBIdW1hbi1yZWFkYWJsZSBpbmZvIGxvZyBmb3IgdGhlIG91dGdvaW5nIGNvbW1hbmRcblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IFN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IGNtZElkLFxuXHRcdFx0XHRpZDogc2V0dGluZ0lkLFxuXHRcdFx0XHRidXNDaCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKGBUWCAke2Rlc3RJcH0gfCAke2Zvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZywgdGhpcy5hY3Rpb25zKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtnZXRDb21tYW5kTmFtZShjbWRJZCl9YClcblx0XHR9XG5cblx0XHQvLyBSZWplY3QgY29tbWFuZHMgdG8gdW52ZXJpZmllZCBkZXZpY2VzIFx1MjAxNCBsb2cgdGhlIHdvdWxkLWJlIHBhY2tldCBmaXJzdCBhdCBkZWJ1Z1xuXHRcdC8vIHNvIHRoZSBieXRlcyBhcmUgdmlzaWJsZSBldmVuIHdoZW4gdGhlIGRldmljZSBpcyBvZmZsaW5lLlxuXHRcdGlmICghdGhpcy5hdXRob3JpemVkSXBzLmhhcyhkZXN0SXApKSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFBhY2tldCAobm90IHNlbnQgXHUyMDE0IGRldmljZSBub3QgYXV0aG9yaXplZCkgdG8gJHtkZXN0SXB9OiAke3BheWxvYWRXaXRoQ3JjLnRvU3RyaW5nKCdoZXgnKX1gKVxuXHRcdFx0dGhyb3cgbmV3IEVycm9yKGBEZXZpY2UgYXQgJHtkZXN0SXB9IGlzIG5vdCBhdXRob3JpemVkIFx1MjAxNCB2ZXJpZnkgdGhlIElQIGFuZCBtb2RlbCBtYXRjaCBiZWZvcmUgc2VuZGluZyBjb21tYW5kc2ApXG5cdFx0fVxuXG5cdFx0Ly8gRW5zdXJlIHdlIGFyZSBsaXN0ZW5pbmcgZm9yIHJlcGxpZXMgb24gdGhlIGludGVyZmFjZSB0aGF0IHdpbGwgcmVjZWl2ZSB0aGVtXG5cdFx0YXdhaXQgdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcClcblxuXHRcdGNvbnN0IHRvdGFsTGVuID0gMjQgKyBwYXlsb2FkV2l0aENyYy5sZW5ndGhcblx0XHRjb25zdCBoZWFkZXIgPSBhd2FpdCB0aGlzLmJ1aWxkSGVhZGVyKHRvdGFsTGVuLCBkZXN0SXApXG5cdFx0Y29uc3QgcGFja2V0ID0gQnVmZmVyLmNvbmNhdChbaGVhZGVyLCBwYXlsb2FkV2l0aENyY10pXG5cblx0XHRsb2dnZXIuZGVidWcoYFNlbmRpbmcgcGFja2V0IHRvICR7ZGVzdElwfTogJHtwYWNrZXQudG9TdHJpbmcoJ2hleCcpfWApXG5cblx0XHRjb25zdCBrZXkgPSBgJHtkZXN0SXB9OiR7Y21kSWR9YFxuXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPEJ1ZmZlcj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGBUaW1lb3V0IHdhaXRpbmcgZm9yIEFDSyBmcm9tIE1vZGVsICR7dGhpcy5tb2RlbH0gYXQgJHtkZXN0SXB9Ojg3MDBgKSlcblx0XHRcdH0sIHRpbWVvdXRNcylcblxuXHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5zZXQoa2V5LCB7XG5cdFx0XHRcdHJlc29sdmU6IChidWYpID0+IHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVzb2x2ZShidWYpXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHJlamVjdDogKGVycikgPT4ge1xuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZWplY3QoZXJyKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHR0aW1lcixcblx0XHRcdH0pXG5cblx0XHRcdHRoaXMudHhTb2NrZXQuc2VuZChwYWNrZXQsIHRoaXMuZGVmYXVsdFBvcnQsIGRlc3RJcCwgKGVycikgPT4ge1xuXHRcdFx0XHRpZiAoZXJyKSB7XG5cdFx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHRcdFx0fVxuXHRcdFx0fSlcblx0XHR9KVxuXHR9XG5cblx0cHJpdmF0ZSBoYW5kbGVJbmNvbWluZyhtc2c6IEJ1ZmZlciwgc3JjSXA6IHN0cmluZykge1xuXHRcdGlmIChtc2cubGVuZ3RoIDwgNCkgcmV0dXJuXG5cdFx0aWYgKG1zZ1swXSAhPT0gMHhmZiB8fCBtc2dbMV0gIT09IDB4ZmYpIHJldHVyblxuXG5cdFx0Y29uc3QgbXNnVHlwZSA9IG1zZy5yZWFkVUludDE2QkUoMilcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSAoMHgwMTcwKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBUaGVzZSBoYXZlIFwiQXVkaW5hdGVcIiBhdCBvZmZzZXQgMTYsIG5vdCBcIlN0dWRpby1UXCIgXHUyMDE0IGhhbmRsZSBiZWZvcmVcblx0XHQvLyB0aGUgU3R1ZGlvLVQgc2lnbmF0dXJlIGNoZWNrIGJlbG93LlxuXHRcdGlmIChtc2dUeXBlID09PSBEQU5URV9NU0dfSU5GT19SRVNQT05TRSAmJiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5zaXplID4gMCkge1xuXHRcdFx0Y29uc3QgZGV2aWNlID0gcGFyc2VEYW50ZUluZm9SZXNwb25zZShtc2csIHNyY0lwKVxuXHRcdFx0aWYgKGRldmljZSkge1xuXHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0YERhbnRlIGluZm8gcmVzcG9uc2UgZnJvbSAke3NyY0lwfTogYCArXG5cdFx0XHRcdFx0XHRgRGV2aWNlSUQ9XCIke2RldmljZS5uYW1lfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNb2RlbD1cIiR7ZGV2aWNlLm1vZGVsfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNb2RlbE5hbWU9XCIke2RldmljZS5tb2RlbE5hbWV9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1hbnVmYWN0dXJlcj1cIiR7ZGV2aWNlLm1hbnVmYWN0dXJlcn1cImAsXG5cdFx0XHRcdClcblxuXHRcdFx0XHQvLyBPbmx5IGFjY2VwdCBTdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZXMgKGlkZW50aWZpZWQgYnkgRGV2aWNlSUQgXCJTdHVkaW8tVFwiKVxuXHRcdFx0XHRpZiAoZGV2aWNlLm5hbWUgPT09ICdTdHVkaW8tVCcpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGNiIG9mIHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnZhbHVlcygpKSB7XG5cdFx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0XHRjYihkZXZpY2UpXG5cdFx0XHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgSWdub3Jpbmcgbm9uLVN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlOiBEZXZpY2VJRD1cIiR7ZGV2aWNlLm5hbWV9XCIgQCAke3NyY0lwfWApXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGlmIChtc2cubGVuZ3RoIDwgMjUpIHJldHVyblxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIFN0dWRpby1UIGNvbnRyb2wgcHJvdG9jb2wgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Y29uc3Qgc2lnID0gbXNnLnN1YmFycmF5KDE2LCAyNClcblx0XHRpZiAoc2lnLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnU3R1ZGlvLVQnKSByZXR1cm5cblxuXHRcdC8vIFBheWxvYWQgc3RhcnRzIGF0IG9mZnNldCAyNFxuXHRcdC8vIExheW91dDogWzB4NWFdIFtjbWRJZHwweDgwXSBbZGF0YS4uLl0gW2NyY11cblx0XHRjb25zdCBzdFBheWxvYWQgPSBtc2cuc3ViYXJyYXkoMjQpXG5cdFx0aWYgKHN0UGF5bG9hZC5sZW5ndGggPCAyKSByZXR1cm5cblx0XHRpZiAoc3RQYXlsb2FkWzBdICE9PSAweDVhKSByZXR1cm5cblxuXHRcdC8vIERldmljZSByZXBsaWVzIHdpdGggY21kIHwgMHg4MFxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGlzUmVzcG9uc2UgPSAocmVzcENtZElkICYgMHg4MCkgIT09IDBcblx0XHRjb25zdCBvcmlnaW5hbENtZElkID0gcmVzcENtZElkICYgMHg3ZiAvLyBzdHJpcCB0aGUgcmVzcG9uc2UgZmxhZ1xuXG5cdFx0Ly8gTG9nIHJhdyBwYWNrZXQgZm9yIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSByZXNwb25zZXMgYmVmb3JlIHBhcnNpbmdcblx0XHRpZiAoaXNSZXNwb25zZSAmJiBvcmlnaW5hbENtZElkID09PSBDTURfR0VUX0FMTF9TRVRUSU5HUykge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSZWNlaXZlZCBwYWNrZXQgZnJvbSAke3NyY0lwfTogJHttc2cudG9TdHJpbmcoJ2hleCcpfWApXG5cdFx0fVxuXG5cdFx0Ly8gTG9nIHRoZSBwYXlsb2FkICh3b3JrcyBmb3IgYm90aCByZXF1ZXN0cyBhbmQgcmVzcG9uc2VzKVxuXHRcdHRoaXMubG9nU3RQYXlsb2FkKHNyY0lwLCBvcmlnaW5hbENtZElkLCBtc2csIHN0UGF5bG9hZClcblxuXHRcdC8vIE9ubHkgcHJvY2VzcyBhcyBBQ0sgaWYgdGhpcyBpcyBhIHJlc3BvbnNlIHRvIG91ciByZXF1ZXN0XG5cdFx0aWYgKGlzUmVzcG9uc2UpIHtcblx0XHRcdGNvbnN0IGtleSA9IGAke3NyY0lwfToke29yaWdpbmFsQ21kSWR9YFxuXHRcdFx0Y29uc3QgcGVuZGluZyA9IHRoaXMucGVuZGluZ0Fja3MuZ2V0KGtleSlcblx0XHRcdGlmIChwZW5kaW5nKSB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cGVuZGluZy5yZXNvbHZlKG1zZylcblx0XHRcdH1cblx0XHR9XG5cdFx0Ly8gVW5zb2xpY2l0ZWQgbWVzc2FnZXMgYW5kIHJlcXVlc3RzIGZyb20gb3RoZXIgc291cmNlcyBhcmUgbG9nZ2VkIGFib3ZlXG5cdH1cblxuXHQvKipcblx0ICogRGVjb2RlcyBhbmQgbG9ncyBhIFN0dWRpby1UIHJlc3BvbnNlIHBheWxvYWQuXG5cdCAqIFJlY2VpdmVzIGJvdGggdGhlIGZ1bGwgbXNnIChmb3IgcGFyc2VycyB0aGF0IG5lZWQgdGhlIFN0dWRpby1UIGhlYWRlcilcblx0ICogYW5kIHN0UGF5bG9hZCAobXNnLnN1YmFycmF5KDI0KSwgZm9yIGRpcmVjdCBieXRlIGFjY2VzcykuXG5cdCAqXG5cdCAqIHN0UGF5bG9hZCBsYXlvdXQ6XG5cdCAqICAgWzBdICAgICAgMHg1YSAgbWFnaWNcblx0ICogICBbMV0gICAgICBjbWRJZCB8IDB4ODBcblx0ICogICBbMi4uLTJdICBkYXRhIGJ5dGVzXG5cdCAqICAgWy0xXSAgICAgQ1JDLTgvRFZCLVMyXG5cdCAqL1xuXHRwcml2YXRlIGxvZ1N0UGF5bG9hZChzcmNJcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBtc2c6IEJ1ZmZlciwgc3RQYXlsb2FkOiBCdWZmZXIpOiB2b2lkIHtcblx0XHRjb25zdCBjbWROYW1lID0gZ2V0Q29tbWFuZE5hbWUoY21kSWQpXG5cdFx0Y29uc3QgZGF0YSA9IHN0UGF5bG9hZC5zdWJhcnJheSgyLCBzdFBheWxvYWQubGVuZ3RoIC0gMSkgLy8gc3RyaXAgbWFnaWMrY21kSWQgaGVhZGVyIGFuZCBDUkNcblxuXHRcdC8vIFBheWxvYWQgc3RydWN0dXJlOiBbY21kOjB4OGRdIFtkYXRhIGJ5dGVzLi4uXSBbY3JjXVxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGNyYyA9IHN0UGF5bG9hZFtzdFBheWxvYWQubGVuZ3RoIC0gMV1cblx0XHRjb25zdCBmdWxsU3RydWN0dXJlID0gYFtjbWQ6JHt0b0hleChyZXNwQ21kSWQpfSBkYXRhOiR7ZGF0YS50b1N0cmluZygnaGV4Jyl9IGNyYzoke3RvSGV4KGNyYyl9XWBcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgYW5kIENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBQYXJzZSBhbGwgc2V0dGluZ3MsIGRpZmYgYWdhaW5zdCBkZXZpY2VTdGF0ZSwgbG9nIGNoYW5nZWQgYXQgaW5mbyAvIHVuY2hhbmdlZCBhdCBkZWJ1Zyxcblx0XHQvLyB0aGVuIHVwZGF0ZSBkZXZpY2VTdGF0ZS4gQ01EX0dFVF9BTExfU0VUVElOR1MgYWxzbyBzZXJ2ZXMgYXMgdGhlIGluaXRpYWwgc3RhdGUgcG9wdWxhdGlvbiBvbiBjb25uZWN0LlxuXHRcdGlmIChjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgfHwgY21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0XHRpZiAoIXRoaXMubW9kZWwpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IHNldHRpbmdzID1cblx0XHRcdFx0XHRjbWRJZCA9PT0gQ01EX1NFVFRJTkdTX1BVU0hcblx0XHRcdFx0XHRcdD8gcGFyc2VTZXR0aW5nc1Jlc3BvbnNlKHRoaXMubW9kZWwsIG1zZylcblx0XHRcdFx0XHRcdDogcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsKHRoaXMubW9kZWwsIG1zZylcblxuXHRcdFx0XHRjb25zdCBwcmV2U3RhdGUgPSB0aGlzLmRldmljZVN0YXRlLmdldChzcmNJcCkgPz8gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKVxuXHRcdFx0XHRjb25zdCBuZXdTdGF0ZSA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KHByZXZTdGF0ZSkgLy8gY29weSBcdTIwMTQgdXBkYXRlIGluIHBsYWNlXG5cblx0XHRcdFx0Zm9yIChjb25zdCBzIG9mIHNldHRpbmdzKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc3RhdGVLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIHMuY21kX2lkLCBzLmlkLCBzLmJ1c0NoKVxuXHRcdFx0XHRcdC8vIEZvciBSR0IgY29sb3JzICgzIGJ5dGVzKSwgcGFjayBpbnRvIHNpbmdsZSBudW1iZXI6IChSIDw8IDE2KSB8IChHIDw8IDgpIHwgQlxuXHRcdFx0XHRcdGNvbnN0IG5ld1ZhbHVlID1cblx0XHRcdFx0XHRcdHMudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdFx0XHRcdFx0PyAocy52YWx1ZUJ5dGVzWzBdIDw8IDE2KSB8IChzLnZhbHVlQnl0ZXNbMV0gPDwgOCkgfCBzLnZhbHVlQnl0ZXNbMl1cblx0XHRcdFx0XHRcdFx0OiAocy52YWx1ZUJ5dGVzWzBdID8/IDApXG5cdFx0XHRcdFx0Y29uc3QgcHJldlZhbHVlID0gcHJldlN0YXRlLmdldChzdGF0ZUtleSlcblx0XHRcdFx0XHRjb25zdCBjaGFuZ2VkID0gcHJldlZhbHVlID09PSB1bmRlZmluZWQgfHwgcHJldlZhbHVlICE9PSBuZXdWYWx1ZVxuXG5cdFx0XHRcdFx0bmV3U3RhdGUuc2V0KHN0YXRlS2V5LCBuZXdWYWx1ZSlcblxuXHRcdFx0XHRcdGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdFBhcnNlZFNldHRpbmcocywgdGhpcy5hY3Rpb25zKVxuXHRcdFx0XHRcdGlmIChjaGFuZ2VkKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgUlggJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdFx0Ly8gVHJpZ2dlciBmZWVkYmFjayB1cGRhdGUgXHUyMDE0IHVzZSBiYXNlIGtleSB3aXRob3V0IGJ1c0NoIHNvIGl0IG1hdGNoZXMgdGhlIGZlZWRiYWNrIGRlZmluaXRpb24gSURcblx0XHRcdFx0XHRcdGlmICh0aGlzLmZlZWRiYWNrQ2FsbGJhY2spIHtcblx0XHRcdFx0XHRcdFx0bGV0IGJhc2VJZCA9IHMuaWRcblx0XHRcdFx0XHRcdFx0Y29uc3QgYmFzZUFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0aWYgKGEuY21kX2lkICE9PSBzLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0XHRcdFx0aWYgKGEuaWQgPT09IHMuaWQpIHJldHVybiB0cnVlXG5cdFx0XHRcdFx0XHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdFx0XHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0XHRcdFx0Y29uc3Qgb2Zmc2V0ID0gcy5pZCAtIGEuaWRcblx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gb2Zmc2V0ID4gMCAmJiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGMpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0aWYgKGJhc2VBY3Rpb24pIGJhc2VJZCA9IGJhc2VBY3Rpb24uaWRcblx0XHRcdFx0XHRcdFx0Y29uc3QgYmFzZUZlZWRiYWNrS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgYmFzZUlkKVxuXHRcdFx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soYmFzZUZlZWRiYWNrS2V5KVxuXHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYGZlZWRiYWNrQ2FsbGJhY2sgbm90IHNldCBcdTIwMTQgc2tpcHBpbmcgZmVlZGJhY2sgdXBkYXRlIGZvciAke3N0YXRlS2V5fWApXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLmRldmljZVN0YXRlLnNldChzcmNJcCwgbmV3U3RhdGUpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCBwYXJzZSBmYWlsZWQ6ICR7ZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBBbGwgb3RoZXIgY29tbWFuZHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Y29uc3QgZGVjb2RlZCA9IHRoaXMuZGVjb2RlU3REYXRhKGNtZElkLCBkYXRhKVxuXHRcdC8vIENNRF9CVVNfR0VUIChrZWVwYWxpdmUpIGlzIGhpZ2gtZnJlcXVlbmN5IG5vaXNlIFx1MjAxNCBsb2cgYXQgZGVidWcgb25seVxuXHRcdGNvbnN0IGxvZ0ZuID0gY21kSWQgPT09IENNRF9CVVNfR0VUID8gbG9nZ2VyLmRlYnVnLmJpbmQobG9nZ2VyKSA6IGxvZ2dlci5pbmZvLmJpbmQobG9nZ2VyKVxuXHRcdGlmIChkZWNvZGVkKSB7XG5cdFx0XHRsb2dGbihgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfSB8ICR7ZGVjb2RlZH1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dGbihgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEF0dGVtcHRzIHRvIGRlY29kZSB0aGUgZGF0YSBieXRlcyBvZiBhIFN0dWRpby1UIHJlc3BvbnNlIGludG8gYVxuXHQgKiBodW1hbi1yZWFkYWJsZSBzdHJpbmcuIFJldHVybnMgbnVsbCB0byBmYWxsIGJhY2sgdG8gcmF3IGhleC5cblx0ICovXG5cdHByaXZhdGUgZGVjb2RlU3REYXRhKGNtZElkOiBudW1iZXIsIGRhdGE6IEJ1ZmZlcik6IHN0cmluZyB8IG51bGwge1xuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMCkgcmV0dXJuICdBQ0snXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ2hlY2sgZm9yIHNpbmdsZS1ieXRlIHJlc3BvbnNlcyAoQUNLIG9yIGVycm9yKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdGlmIChkYXRhWzBdID09PSAweDAwKSB7XG5cdFx0XHRcdHJldHVybiAnQUNLIG9rJ1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0cmV0dXJuIGBFUlJPUiAke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdH1cblx0XHR9XG5cblx0XHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX01JQ19QUkUgKDB4MDIpOiByYXcgcHJlYW1wIGVjaG8gXHUyMDE0IHBvc2l0aW9uYWwgYnl0ZXMsIG5vIHNldHRpbmcgSURzIFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gRGV2aWNlIGVjaG9lcyBbYnVzQ2hdW3ZhbDBdW3ZhbDFdLi4uIGNvbmZpcm1pbmcgdGhlIGFwcGxpZWQgdmFsdWVzLlxuXHRcdFx0Y2FzZSBDTURfTUlDX1BSRToge1xuXHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0Y29uc3QgdmFscyA9IEFycmF5LmZyb20oZGF0YS5zdWJhcnJheSgxKSlcblx0XHRcdFx0XHQubWFwKChiLCBpKSA9PiBgWyR7aX1dPTB4JHtiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfSgke2J9KWApXG5cdFx0XHRcdFx0LmpvaW4oJyAnKVxuXHRcdFx0XHRyZXR1cm4gYGNoPSR7YnVzQ2h9ICR7dmFsc31gXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfREVWX1NQRUMgKDB4MGQpOiBzaW5nbGUtYnl0ZSBBQ0sgb3IgZWNobyBvZiBhcHBsaWVkIHNldHRpbmcgXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBEZXZpY2Ugc2VuZHMgdHdvIENNRF9ERVZfU1BFQyBwYWNrZXRzIGluIHJlc3BvbnNlIHRvIGEgc2V0OlxuXHRcdFx0Ly8gICAxLiBBQ0s6ICBbc3RhdHVzXSAgICAgICAgICAgICAgICgxIGJ5dGUsIDB4MDAgPSBvaylcblx0XHRcdC8vICAgMi4gRWNobzogW2J1c0NoXSBbc2V0dGluZ0lkXSBbdmFsdWUuLi5dICAoY29uZmlybWluZyB3aGF0IHdhcyBhcHBsaWVkKVxuXHRcdFx0Y2FzZSBDTURfREVWX1NQRUM6IHtcblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGRhdGFbMF0gPT09IDB4MDAgPyAnQUNLIG9rJyA6IGBBQ0sgZXJyPSR7dG9IZXgoZGF0YVswXSl9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfWBcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VzID0gYWN0aW9uPy5vcHRpb25zPy5bMF0/LmNob2ljZXNcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID1cblx0XHRcdFx0XHRcdGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlU3RyID0gY2hvaWNlTGFiZWwgPyBgJHtjaG9pY2VMYWJlbH0gKCR7dG9IZXgodmFsdWVOdW0hKX0pYCA6IGJ5dGVzVG9IZXgoQXJyYXkuZnJvbSh2YWx1ZUJ5dGVzKSlcblx0XHRcdFx0XHRjb25zdCByYXdUYWcgPSBgWyR7dG9IZXgoY21kSWQpfS8ke3RvSGV4KHNldHRpbmdJZCl9XT0ke2J5dGVzVG9IZXgoQXJyYXkuZnJvbSh2YWx1ZUJ5dGVzKSl9YFxuXHRcdFx0XHRcdHJldHVybiBgZWNobyBjaD0ke2J1c0NofSB8ICR7c2V0dGluZ05hbWV9OiAke3ZhbHVlU3RyfSAke3Jhd1RhZ31gXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGByYXc6ICR7ZGF0YS50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0fVxuXG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX01JQ19QUkVfQlVTICgweDEyKTogTXVsdGktYnl0ZSBlY2hvIHJlc3BvbnNlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdGNhc2UgQ01EX01JQ19QUkVfQlVTOiB7XG5cdFx0XHRcdC8vIEFscmVhZHkgaGFuZGxlZCBzaW5nbGUtYnl0ZSBhYm92ZSwgc28gbXVsdGktYnl0ZSBtdXN0IGJlIGVjaG9cblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID49IDMpIHtcblx0XHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0XHRjb25zdCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyBgc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9YFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlTnVtID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlcyA9IGFjdGlvbj8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJyk/LmNob2ljZXNcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9XG5cdFx0XHRcdFx0XHRjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVN0ciA9IGNob2ljZUxhYmVsID8/IGAweCR7dmFsdWVCeXRlcy50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0XHRcdHJldHVybiBgZWNobyBjaD0ke2J1c0NofSB8ICR7c2V0dGluZ05hbWV9OiAke3ZhbHVlU3RyfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gbnVsbFxuXHRcdFx0fVxuXG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQnVzLXNjb3BlZCBnZXQvc2V0IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdGNhc2UgQ01EX0JVU19TRVQ6IHtcblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoIDwgMikgcmV0dXJuIG51bGxcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdHJldHVybiBgY2g9JHtidXNDaH0gc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9IHZhbHVlPSR7dmFsdWUudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0cmV0dXJuIG51bGwgLy8gZmFsbCB0aHJvdWdoIHRvIHJhdyBoZXhcblx0XHR9XG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBidWlsZFZhbHVlQnl0ZXModmFsdWU6IHVua25vd24pOiBudW1iZXJbXSB7XG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gW3ZhbHVlID8gMSA6IDBdXG5cdFx0aWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSByZXR1cm4gdmFsdWUubWFwKCh2KSA9PiBOdW1iZXIodikgJiAweGZmKVxuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG5cdFx0XHRpZiAodmFsdWUgPiAweGZmKSByZXR1cm4gWyh2YWx1ZSA+PiAxNikgJiAweGZmLCAodmFsdWUgPj4gOCkgJiAweGZmLCB2YWx1ZSAmIDB4ZmZdXG5cdFx0XHRyZXR1cm4gW3ZhbHVlICYgMHhmZl1cblx0XHR9XG5cdFx0dGhyb3cgbmV3IEVycm9yKGBVbnN1cHBvcnRlZCB2YWx1ZSB0eXBlIGZvciBTVGNvbnRyb2xsZXI6ICR7dmFsdWV9YClcblx0fVxuXG5cdHByaXZhdGUgYXN5bmMgYnVpbGRIZWFkZXIodG90YWxMZW46IG51bWJlciwgZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGxldCBtYWMgPSB0aGlzLm1hY0NhY2hlLmdldChkZXN0SXApXG5cdFx0aWYgKCFtYWMpIHtcblx0XHRcdG1hYyA9IGF3YWl0IGdldE1hY0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblx0XHRcdHRoaXMubWFjQ2FjaGUuc2V0KGRlc3RJcCwgbWFjKVxuXHRcdH1cblxuXHRcdHJldHVybiBCdWZmZXIuY29uY2F0KFtcblx0XHRcdEJ1ZmZlci5mcm9tKFsweGZmLCAweGZmLCAweDAwLCB0b3RhbExlbiAmIDB4ZmYsIDB4MDcsIDB4ZTEsIDB4MDAsIDB4MDAsIC4uLm1hYywgMHgwMCwgMHgwMF0pLFxuXHRcdFx0QnVmZmVyLmZyb20oJ1N0dWRpby1UJywgJ3V0ZjgnKSxcblx0XHRdKVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgY3JjOER2YlMyKGRhdGE6IG51bWJlcltdKTogbnVtYmVyIHtcblx0XHRsZXQgY3JjID0gMFxuXHRcdGZvciAoY29uc3QgYiBvZiBkYXRhKSB7XG5cdFx0XHRjcmMgXj0gYlxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCA4OyBpKyspIHtcblx0XHRcdFx0Y3JjID0gKGNyYyAmIDB4ODApICE9PSAwID8gKChjcmMgPDwgMSkgXiAweGQ1KSAmIDB4ZmYgOiAoY3JjIDw8IDEpICYgMHhmZlxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gY3JjXG5cdH1cblxuXHQvKipcblx0ICogUmV0dXJucyB0aGUgY3VycmVudCBrbm93biB2YWx1ZSBmb3IgYSBzZXR0aW5nIG9uIGEgZGV2aWNlLCBvciB1bmRlZmluZWQgaWYgdW5rbm93bi5cblx0ICogVXNlIGZvciBmZWVkYmFja3MgXHUyMDE0IHZhbHVlIGlzIHVwZGF0ZWQgb24gZXZlcnkgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpIGZyb20gdGhlIGRldmljZS5cblx0ICpcblx0ICogQHBhcmFtIGlwICAgICAgICBEZXZpY2UgSVAgYWRkcmVzc1xuXHQgKiBAcGFyYW0gY21kSWQgICAgIENvbW1hbmQgSUQgKGUuZy4gQ01EX0RFVl9TUEVDKVxuXHQgKiBAcGFyYW0gc2V0dGluZ0lkIFNldHRpbmcgSUQgKGUuZy4gMHgwMiBmb3IgQ29udHJvbCBTb3VyY2UpXG5cdCAqIEBwYXJhbSBidXNDaCAgICAgT3B0aW9uYWwgYnVzL2NoYW5uZWwgSUQgZm9yIG11bHRpLWNoYW5uZWwgY29tbWFuZHNcblx0ICovXG5cdHB1YmxpYyBnZXRTZXR0aW5nVmFsdWUoaXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgc2V0dGluZ0lkOiBudW1iZXIsIGJ1c0NoPzogbnVtYmVyKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcblx0XHRjb25zdCBrZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXHRcdHJldHVybiB0aGlzLmRldmljZVN0YXRlLmdldChpcCk/LmdldChrZXkpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgcmVzZXREZXZpY2UoZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHJldHVybiB0aGlzLnNlbmRBd2FpdEFjayhDTURfUkVTRVRfREVWSUNFLCB1bmRlZmluZWQsIDB4MDAsIHVuZGVmaW5lZCwgZGVzdElwLCBmYWxzZSlcblx0fVxuXG5cdHB1YmxpYyBhc3luYyBnbG9iYWxNaWNLaWxsKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5zZW5kQXdhaXRBY2soQ01EX0dMT0JBTF9NSUNfS0lMTCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGVzdElwLCBmYWxzZSlcblx0fVxufVxuIiwgImltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSdcbmltcG9ydCBvcyBmcm9tICdvcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IERldmljZUluZm8gfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ0RhbnRlJylcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIERhbnRlIGRpc2NvdmVyeSBjb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKiBEYW50ZSBkZXZpY2UgaW5mbyByZXF1ZXN0IG1lc3NhZ2UgdHlwZSAoc2VudCB0byBwb3J0IDg3MDApICovXG5leHBvcnQgY29uc3QgREFOVEVfTVNHX0lORk9fUkVRVUVTVCA9IDB4MDAyMFxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlIG1lc3NhZ2UgdHlwZSAocmVjZWl2ZWQgb24gcG9ydCA4NzAyKSAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX01TR19JTkZPX1JFU1BPTlNFID0gMHgwMTcwXG5cbi8qKlxuICogRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgbGF5b3V0IChhbGwgb2Zmc2V0cyBhcmUgaW50byB0aGUgVURQIHBheWxvYWQpOlxuICogICAweDAwICB1aW50MTZCRSAgTWFnaWMgKDB4ZmZmZilcbiAqICAgMHgwMiAgdWludDE2QkUgIE1lc3NhZ2UgdHlwZSAoMHgwMTcwKVxuICogICAweDA0ICB1aW50MTZCRSAgU2VxdWVuY2UgbnVtYmVyXG4gKiAgIDB4MDYgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MDggIDggYnl0ZXMgICBFVUktNjQgKHNvdXJjZSBNQUMgd2l0aCBmZjpmZSBpbnNlcnRlZCBtaWQpXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgQVNDSUkgaWRlbnRpZmllclxuICogICAweDE4ICAyIGJ5dGVzICAgRGFudGUgbW9kdWxlIGZpcm13YXJlIHZlcnNpb24gKG1ham9yLCBtaW5vcilcbiAqICAgMHgyMCAgMzEgYnl0ZXMgIERldmljZSBuYW1lLCBudWxsLXBhZGRlZCBBU0NJSSAobWF4IDMxIGNoYXJzIHBlciBEYW50ZSBzcGVjKVxuICogICAweDJlICB1aW50MTZCRSAgUHJvZHVjdCBJRFxuICogICAweDRjICA2NCBieXRlcyAgTWFudWZhY3R1cmVyIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqICAgMHhjYyAgNjQgYnl0ZXMgIE1vZGVsIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX0lORk9fTUlOX0xFTiA9IDB4Y2MgKyA2NCAvLyAyNjggYnl0ZXMgXHUyMDE0IG5lZWQgZnVsbCBtb2RlbCBmaWVsZFxuXG4vKipcbiAqIEJ1aWxkcyBhIERhbnRlIGRldmljZSBpbmZvIHJlcXVlc3QgcGFja2V0ICh0eXBlIDB4MDAyMCkuXG4gKlxuICogUGFja2V0IGxheW91dCAoMzIgYnl0ZXMpIFx1MjAxNCBkZXJpdmVkIGZyb20gbGl2ZSBjYXB0dXJlIGFuYWx5c2lzOlxuICogICAweDAwICB1aW50MTZCRSAgTWFnaWMgKDB4ZmZmZilcbiAqICAgMHgwMiAgdWludDE2QkUgIE1lc3NhZ2UgdHlwZSAoMHgwMDIwID0gZGV2aWNlIGluZm8gcmVxdWVzdClcbiAqICAgMHgwNCAgdWludDE2QkUgIFNlcXVlbmNlIG51bWJlciAocmFuZG9tKVxuICogICAweDA2ICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDA4ICA2IGJ5dGVzICAgU291cmNlIE1BQ1xuICogICAweDBlICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIEFTQ0lJIGlkZW50aWZpZXJcbiAqICAgMHgxOCAgMiBieXRlcyAgIFByb3RvY29sIHZlcnNpb24gKDB4MDczOSlcbiAqICAgMHgxYSAgMiBieXRlcyAgIFN1Yi10eXBlICgweDAwYzEpXG4gKiAgIDB4MWMgIHVpbnQzMkJFICBDYXBhYmlsaXR5IG1hc2sgKDB4MDAwZjQyNDApXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidWlsZERhbnRlSW5mb1JlcXVlc3QoKTogQnVmZmVyIHtcblx0Y29uc3QgYnVmID0gQnVmZmVyLmFsbG9jKDMyLCAwKVxuXHRjb25zdCBzZXEgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAweGZmZmYpXG5cblx0YnVmLndyaXRlVUludDE2QkUoMHhmZmZmLCAwKVxuXHRidWYud3JpdGVVSW50MTZCRShEQU5URV9NU0dfSU5GT19SRVFVRVNULCAyKVxuXHRidWYud3JpdGVVSW50MTZCRShzZXEsIDQpXG5cblx0Y29uc3QgbWFjID0gZ2V0Rmlyc3RMb2NhbE1hYygpXG5cdG1hYy5jb3B5KGJ1ZiwgOClcblxuXHRCdWZmZXIuZnJvbSgnQXVkaW5hdGUnLCAnYXNjaWknKS5jb3B5KGJ1ZiwgMTYpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4MDczOSwgMjQpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4MDBjMSwgMjYpXG5cdGJ1Zi53cml0ZVVJbnQzMkJFKDB4MDAwZjQyNDAsIDI4KVxuXG5cdHJldHVybiBidWZcbn1cblxuLyoqIFJldHVybnMgdGhlIGZpcnN0IG5vbi1sb29wYmFjayBNQUMgYXMgYSA2LWJ5dGUgQnVmZmVyLCBvciB6ZXJvcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRGaXJzdExvY2FsTWFjKCk6IEJ1ZmZlciB7XG5cdHRyeSB7XG5cdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRmb3IgKGNvbnN0IGFkZHIgb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdGlmICghYWRkci5pbnRlcm5hbCAmJiBhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmIGFkZHIubWFjICYmIGFkZHIubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnKSB7XG5cdFx0XHRcdFx0cmV0dXJuIEJ1ZmZlci5mcm9tKGFkZHIubWFjLnNwbGl0KCc6JykubWFwKChoOiBzdHJpbmcpID0+IHBhcnNlSW50KGgsIDE2KSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH0gY2F0Y2gge1xuXHRcdC8qIGlnbm9yZSAqL1xuXHR9XG5cdHJldHVybiBCdWZmZXIuYWxsb2MoNiwgMClcbn1cblxuLyoqXG4gKiBQYXJzZXMgYSBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSAodHlwZSAweDAxNzApIGludG8gYSBEZXZpY2VJbmZvLlxuICpcbiAqIFJlc3BvbnNlIGxheW91dCAoa2V5IG9mZnNldHMpOlxuICogICAweDA4ICA4IGJ5dGVzICAgRVVJLTY0IFx1MjAxNCBjb252ZXJ0IHRvIE1BQyBieSBkcm9wcGluZyBieXRlcyBbM10gYW5kIFs0XSAoZmY6ZmUpXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgaWRlbnRpZmllciAodXNlZCB0byB2ZXJpZnkgdGhpcyBpcyBhIHJlYWwgcmVzcG9uc2UpXG4gKiAgIDB4MTggIDEgYnl0ZSAgICBEYW50ZSBGVyBtYWpvclxuICogICAweDE5ICAxIGJ5dGUgICAgRGFudGUgRlcgbWlub3JcbiAqICAgMHgyMCAgMzEgYnl0ZXMgIERldmljZSBuYW1lIChEYW50ZSBsYWJlbCksIG51bGwtcGFkZGVkIEFTQ0lJIChtYXggMzEgY2hhcnMpXG4gKiAgIDB4MmUgIHVpbnQxNkJFICBQcm9kdWN0IElEXG4gKiAgIDB4NGMgIDY0IGJ5dGVzICBNYW51ZmFjdHVyZXIsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKiAgIDB4Y2MgIDY0IGJ5dGVzICBNb2RlbCBzdHJpbmcsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKlxuICogUmV0dXJucyBudWxsIGlmIGJ1ZmZlciBpcyB0b28gc2hvcnQsIHdyb25nIG1hZ2ljLCBvciBtaXNzaW5nIG1vZGVsIHN0cmluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpOiBEZXZpY2VJbmZvIHwgbnVsbCB7XG5cdGlmIChtc2cubGVuZ3RoIDwgREFOVEVfSU5GT19NSU5fTEVOKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgwKSAhPT0gMHhmZmZmKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgyKSAhPT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UpIHJldHVybiBudWxsXG5cdGlmIChtc2cuc3ViYXJyYXkoMTYsIDI0KS50b1N0cmluZygnYXNjaWknKSAhPT0gJ0F1ZGluYXRlJykgcmV0dXJuIG51bGxcblxuXHRjb25zdCByZWFkU3RyID0gKG9mZnNldDogbnVtYmVyLCBsZW46IG51bWJlcik6IHN0cmluZyA9PlxuXHRcdG1zZ1xuXHRcdFx0LnN1YmFycmF5KG9mZnNldCwgb2Zmc2V0ICsgbGVuKVxuXHRcdFx0LnRvU3RyaW5nKCdhc2NpaScpXG5cdFx0XHQuc3BsaXQoJ1xcMCcpWzBdXG5cdFx0XHQudHJpbSgpXG5cblx0Y29uc3QgZXVpNjQgPSBtc2cuc3ViYXJyYXkoOCwgMTYpXG5cdGNvbnN0IG1hY0J5dGVzID0gW2V1aTY0WzBdLCBldWk2NFsxXSwgZXVpNjRbMl0sIGV1aTY0WzVdLCBldWk2NFs2XSwgZXVpNjRbN11dXG5cdGNvbnN0IG1hYyA9IG1hY0J5dGVzLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSkuam9pbignOicpXG5cblx0Y29uc3QgbmFtZSA9IHJlYWRTdHIoMHgyMCwgMzEpIC8vIERhbnRlIGRldmljZSBsYWJlbCAoY2FuIGJlIHVwIHRvIDMxIGNoYXJzIHBlciBEYW50ZSBzcGVjKVxuXHRjb25zdCBtYW51ZmFjdHVyZXIgPSByZWFkU3RyKDB4NGMsIDY0KSAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGNvbnN0IG1vZGVsUmF3ID0gcmVhZFN0cigweGNjLCA2NClcblx0Y29uc3QgZGFudGVGaXJtd2FyZSA9IGAke21zZ1sweDE4XX0uJHttc2dbMHgxOV19YFxuXG5cdGlmICghbW9kZWxSYXcpIHJldHVybiBudWxsXG5cblx0Ly8gRXh0cmFjdCBqdXN0IHRoZSBtb2RlbCBudW1iZXIvY29kZSAoZS5nLiBcIk1vZGVsIDM5MSBBbGVydGluZyBVbml0XCIgXHUyMTkyIFwiMzkxXCIpXG5cdC8vIFN0cmlwIFwiTW9kZWwgXCIgcHJlZml4LCB0aGVuIHRha2Ugb25seSB0aGUgZmlyc3Qgd29yZCAodGhlIG1vZGVsIG51bWJlcilcblx0Y29uc3QgbW9kZWwgPSBtb2RlbFJhd1xuXHRcdC5yZXBsYWNlKC9eTW9kZWxcXHMrL2ksICcnKVxuXHRcdC50cmltKClcblx0XHQuc3BsaXQoL1xccysvKVswXVxuXG5cdHJldHVybiB7XG5cdFx0aXA6IHNyY0lwLFxuXHRcdG5hbWUsXG5cdFx0bWFudWZhY3R1cmVyLFxuXHRcdG1vZGVsLFxuXHRcdG1vZGVsTmFtZTogbW9kZWxSYXcsIC8vIEZ1bGwgbW9kZWwgZGVzY3JpcHRpb25cblx0XHRtYWMsXG5cdFx0ZGFudGVGaXJtd2FyZSxcblx0fVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIE1BQyBhZGRyZXNzIGJ5dGVzIG9mIHRoZSBsb2NhbCBpbnRlcmZhY2UgdXNlZCB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBjb25uZWN0IHRvIGxldCB0aGUgT1Mgc2VsZWN0IHRoZSBvdXRnb2luZyBpbnRlcmZhY2UsXG4gKiB0aGVuIGZpbmRzIHRoZSBtYXRjaGluZyBNQUMgZnJvbSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPG51bWJlcltdPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTxudW1iZXJbXT4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHR0bXAub25jZSgnZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0fSlcblxuXHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgYWRkciA9IHRtcC5hZGRyZXNzKCkgYXMgeyBhZGRyZXNzOiBzdHJpbmcgfVxuXHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3Ncblx0XHRcdFx0dG1wLmNsb3NlKClcblxuXHRcdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0XHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBpZmFjZSBvZiBpZmFjZXNbbmFtZV0gPz8gW10pIHtcblx0XHRcdFx0XHRcdGlmIChcblx0XHRcdFx0XHRcdFx0aWZhY2UuZmFtaWx5ID09PSAnSVB2NCcgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UuYWRkcmVzcyA9PT0gbG9jYWxBZGRyICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCdcblx0XHRcdFx0XHRcdCkge1xuXHRcdFx0XHRcdFx0XHRyZXR1cm4gcmVzb2x2ZShpZmFjZS5tYWMuc3BsaXQoJzonKS5tYXAoKGIpID0+IHBhcnNlSW50KGIsIDE2KSAmIDB4ZmYpKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGBObyBpbnRlcmZhY2UgZm91bmQgZm9yIGxvY2FsIGFkZHJlc3MgJHtsb2NhbEFkZHJ9YCkpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgbG9jYWwgSVAgYWRkcmVzcyB1c2VkIGJ5IHRoZSBPUyB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBzb2NrZXQgY29ubmVjdCB0byBsZXQgdGhlIE9TIHNlbGVjdCB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8c3RyaW5nPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdGxldCByZXNvbHZlZCA9IGZhbHNlXG5cdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIFVzZSBhbiBhcmJpdHJhcnkgcG9ydCBmb3IgY29ubmVjdDsgd2Ugb25seSBuZWVkIHRoZSBrZXJuZWwgdG8gYXNzaWduIGEgbG9jYWwgYWRkcmVzcy5cblx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cdFx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRcdHJlc29sdmUobG9jYWxBZGRyKVxuXHRcdFx0XHR9XG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cblxuLyoqXG4gKiBMaXN0ZW5zIGZvciBEYW50ZSBkZXZpY2UgYW5ub3VuY2VzIG9uIHRoZSBsb2NhbCBuZXR3b3JrIGFuZCBzZW5kcyB1bmljYXN0XG4gKiBpbmZvIHJlcXVlc3RzIHRvIGVhY2ggZGlzY292ZXJlZCBJUC4gUmVzcG9uc2VzIGFycml2ZSBvbiB0aGUgY2FsbGVyJ3MgcnhTb2NrZXRcbiAqIHZpYSBoYW5kbGVJbmNvbWluZygpIFx1MjE5MiBkaXNjb3ZlcnlMaXN0ZW5lcnMuXG4gKlxuICogQHBhcmFtIHR4U29ja2V0IC0gVGhlIHNvY2tldCB0byB1c2UgZm9yIHNlbmRpbmcgZGlzY292ZXJ5IHJlcXVlc3RzXG4gKiBAcGFyYW0gZW5zdXJlTWVtYmVyc2hpcCAtIENhbGxiYWNrIHRvIGVuc3VyZSBtdWx0aWNhc3QgbWVtYmVyc2hpcCBiZWZvcmUgcXVlcnlpbmdcbiAqIEBwYXJhbSB0aW1lb3V0TXMgLSBIb3cgbG9uZyB0byBsaXN0ZW4gZm9yIGFubm91bmNlcyBiZWZvcmUgcmVzb2x2aW5nXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkaXNjb3ZlckRldmljZXMoXG5cdHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXQsXG5cdGVuc3VyZU1lbWJlcnNoaXA6IChkZXN0SXA6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPixcblx0dGltZW91dE1zID0gNTAwMCxcbik6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBEQU5URV9BTk5PVU5DRV9HUk9VUCA9ICcyMjQuMC4wLjIzMydcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfUE9SVCA9IDg3MDhcblx0Y29uc3QgREVGQVVMVF9QT1JUID0gODcwMFxuXG5cdGNvbnN0IHF1ZXJpZWRJcHMgPSBuZXcgU2V0PHN0cmluZz4oKVxuXG5cdHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdGNvbnN0IGFubm91bmNlU29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblxuXHRcdGNvbnN0IGNsZWFudXAgPSAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhbm5vdW5jZVNvY2tldC5kcm9wTWVtYmVyc2hpcChEQU5URV9BTk5PVU5DRV9HUk9VUClcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmNsb3NlKClcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHRcdHJlc29sdmUoKVxuXHRcdH1cblxuXHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dChjbGVhbnVwLCB0aW1lb3V0TXMpXG5cdFx0dGltZXIudW5yZWY/LigpXG5cblx0XHRhbm5vdW5jZVNvY2tldC5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIud2FybihgQW5ub3VuY2Ugc29ja2V0IGVycm9yOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0fSlcblxuXHRcdGFubm91bmNlU29ja2V0Lm9uKCdtZXNzYWdlJywgKG1zZywgcmluZm8pID0+IHtcblx0XHRcdGNvbnN0IHNyY0lwID0gcmluZm8uYWRkcmVzc1xuXHRcdFx0Ly8gVmFsaWRhdGUgaXQncyBhIERhbnRlIGFubm91bmNlIChtYWdpYyAweGZmZmUgKyBcIkF1ZGluYXRlXCIgYXQgb2Zmc2V0IDE2KVxuXHRcdFx0aWYgKG1zZy5sZW5ndGggPCAyNCkgcmV0dXJuXG5cdFx0XHRpZiAobXNnLnJlYWRVSW50MTZCRSgwKSAhPT0gMHhmZmZlKSByZXR1cm5cblx0XHRcdGlmIChtc2cuc3ViYXJyYXkoMTYsIDI0KS50b1N0cmluZygnYXNjaWknKSAhPT0gJ0F1ZGluYXRlJykgcmV0dXJuXG5cblx0XHRcdGlmIChxdWVyaWVkSXBzLmhhcyhzcmNJcCkpIHJldHVyblxuXHRcdFx0cXVlcmllZElwcy5hZGQoc3JjSXApXG5cdFx0XHRsb2dnZXIuZGVidWcoYEFubm91bmNlIGZyb20gJHtzcmNJcH0gXHUyMDE0IHNlbmRpbmcgdW5pY2FzdCBxdWVyeWApXG5cblx0XHRcdC8vIEpvaW4gMjI0LjAuMC4yMzEgb24gdGhlIGludGVyZmFjZSB0aGF0IHJvdXRlcyB0byB0aGlzIGRldmljZSBCRUZPUkUgc2VuZGluZ1xuXHRcdFx0Ly8gdGhlIHF1ZXJ5LiBUaGUgZGV2aWNlIG11bHRpY2FzdHMgaXRzIDB4MDE3MCByZXNwb25zZSB0byAyMjQuMC4wLjIzMTo4NzAyXG5cdFx0XHQvLyBpbiBhZGRpdGlvbiB0byB1bmljYXN0aW5nIGl0IFx1MjAxNCByeFNvY2tldCBtdXN0IGJlIGEgbWVtYmVyIHRvIHJlY2VpdmUgaXQuXG5cdFx0XHRjb25zdCBzZW5kUXVlcnkgPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdGF3YWl0IGVuc3VyZU1lbWJlcnNoaXAoc3JjSXApXG5cdFx0XHRcdGNvbnN0IHF1ZXJ5ID0gYnVpbGREYW50ZUluZm9SZXF1ZXN0KClcblx0XHRcdFx0dHhTb2NrZXQuc2VuZChxdWVyeSwgREVGQVVMVF9QT1JULCBzcmNJcCwgKGVycikgPT4ge1xuXHRcdFx0XHRcdGlmIChlcnIpIGxvZ2dlci53YXJuKGBVbmljYXN0IHF1ZXJ5IHRvICR7c3JjSXB9IGZhaWxlZDogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0XHR9KVxuXHRcdFx0fVxuXHRcdFx0c2VuZFF1ZXJ5KCkuY2F0Y2goKGVycikgPT4gbG9nZ2VyLndhcm4oYFF1ZXJ5IHNldHVwIGZhaWxlZDogJHtlcnJ9YCkpXG5cdFx0fSlcblxuXHRcdGFubm91bmNlU29ja2V0LmJpbmQoREFOVEVfQU5OT1VOQ0VfUE9SVCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuYWRkTWVtYmVyc2hpcChEQU5URV9BTk5PVU5DRV9HUk9VUClcblx0XHRcdFx0bG9nZ2VyLmluZm8oYExpc3RlbmluZyBmb3IgRGFudGUgYW5ub3VuY2VzIG9uICR7REFOVEVfQU5OT1VOQ0VfR1JPVVB9OiR7REFOVEVfQU5OT1VOQ0VfUE9SVH1gKVxuXHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3Qgam9pbiBhbm5vdW5jZSBtdWx0aWNhc3QgZ3JvdXA6ICR7ZXJyfWApXG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cbiIsICJpbXBvcnQge1xuXHRJbnN0YW5jZVR5cGVzLFxuXHRJbnN0YW5jZUJhc2UsXG5cdEluc3RhbmNlU3RhdHVzLFxuXHRTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsXG5cdGNyZWF0ZU1vZHVsZUxvZ2dlcixcbn0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7IEdldENvbmZpZ0ZpZWxkcywgcmVzb2x2ZUhvc3QsIHJlc29sdmVNb2RlbCwgZ2V0RGV2aWNlU2NoZW1hLCB0eXBlIE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucywgVXBkYXRlVmFyaWFibGVWYWx1ZXMgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcbmltcG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH0gZnJvbSAnLi91cGdyYWRlcy5qcydcbmltcG9ydCB7IFVwZGF0ZUFjdGlvbnMgfSBmcm9tICcuL2FjdGlvbnMuanMnXG5pbXBvcnQgeyBVcGRhdGVGZWVkYmFja3MgfSBmcm9tICcuL2ZlZWRiYWNrcy5qcydcbmltcG9ydCB7IFN0Q29udHJvbGxlciB9IGZyb20gJy4vc3Rjb250cm9sbGVyLmpzJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdNb2R1bGVJbnN0YW5jZScpXG5cbmV4cG9ydCB0eXBlIE1vZHVsZVR5cGVzID0gSW5zdGFuY2VUeXBlcyAmIHtcblx0Y29uZmlnOiBNb2R1bGVDb25maWdcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTW9kdWxlSW5zdGFuY2UgZXh0ZW5kcyBJbnN0YW5jZUJhc2U8TW9kdWxlVHlwZXM+IHtcblx0Y29uZmlnITogTW9kdWxlQ29uZmlnIC8vIFNldHVwIGluIGluaXQoKVxuXHRzdENvbnRyb2xsZXIhOiBTdENvbnRyb2xsZXJcblxuXHQvKiogQ2FjaGVkIGRpc2NvdmVyeSByZXN1bHRzIFx1MjAxNCBwYXNzZWQgaW50byBnZXRDb25maWdGaWVsZHMoKSBzbyB0aGUgVUlcblx0ICogIGNhbiBzaG93IHRoZSBkaXNjb3ZlcmVkIGRldmljZSBkcm9wZG93biBvbiBzdWJzZXF1ZW50IGNvbmZpZyBvcGVucy4gKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHQvKiogQ3VycmVudGx5IGFjdGl2ZSBtb2RlbCBcdTIwMTQgcmVzb2x2ZWQgb25jZSBpbiBzeW5jTW9kZWwoKSBhbmQgY2FjaGVkIGhlcmVcblx0ICogIHNvIFVwZGF0ZUFjdGlvbnMsIFVwZGF0ZUZlZWRiYWNrcyBldGMuIGRvbid0IGVhY2ggY2FsbCByZXNvbHZlTW9kZWwgaW5kZXBlbmRlbnRseS4gKi9cblx0YWN0aXZlTW9kZWw6IHN0cmluZyA9ICcnXG5cblx0Y29uc3RydWN0b3IoaW50ZXJuYWw6IHVua25vd24pIHtcblx0XHRzdXBlcihpbnRlcm5hbClcblx0fVxuXG5cdGFzeW5jIGluaXQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGlmICghdGhpcy5zdENvbnRyb2xsZXIpIHtcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyID0gbmV3IFN0Q29udHJvbGxlcigpXG5cdFx0fVxuXHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkNvbm5lY3RpbmcsICdEaXNjb3ZlcmluZyBkZXZpY2VzLi4uJylcblxuXHRcdC8vIFdpcmUgZmVlZGJhY2sgY2FsbGJhY2sgc28gc3RDb250cm9sbGVyIGNhbiB0cmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZXNcblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRGZWVkYmFja0NhbGxiYWNrKChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHtcblx0XHRcdHRoaXMuY2hlY2tGZWVkYmFja3MoZmVlZGJhY2tJZClcblx0XHR9KVxuXG5cdFx0Ly8gU3RhcnQgZGlzY292ZXJ5IGluIHRoZSBiYWNrZ3JvdW5kIFx1MjAxNCBhbGwgbW9kZWwgcmVzb2x1dGlvbiwgc2NoZW1hIHN5bmMsXG5cdFx0Ly8gYW5kIFVJIHVwZGF0ZXMgaGFwcGVuIGluc2lkZSBydW5EaXNjb3ZlcnkoKSBvbmNlIHRoZSBkZXZpY2UgbGlzdCBpcyBrbm93bi5cblx0XHR0aGlzLnJ1bkRpc2NvdmVyeSgpLmNhdGNoKChlKSA9PiB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYERpc2NvdmVyeSBmYWlsZWQ6ICR7ZX1gKVxuXHRcdH0pXG5cdH1cblxuXHQvKipcblx0ICogUnVuIGRldmljZSBkaXNjb3ZlcnksIHRoZW4gcmVzb2x2ZSB0aGUgbW9kZWwgYW5kIHVwZGF0ZSBhbGwgVUkuXG5cdCAqIC0gSWYgZGlzY292ZXJ5IGZpbmRzIGRldmljZXMsIHJlc29sdmVNb2RlbCBwaWNrcyBmcm9tIHRob3NlLlxuXHQgKiAtIE9ubHkgaWYgdGhlIGxpc3QgaXMgZW1wdHkgZG8gd2UgZmFsbCBiYWNrIHRvIHRoZSBtYW51YWwgY29uZmlnIHNlbGVjdGlvbi5cblx0ICogQWxsIGFjdGlvbnMvZmVlZGJhY2tzL3ZhcmlhYmxlcyBhcmUgYnVpbHQgYWZ0ZXIgdGhlIG1vZGVsIGlzIGtub3duLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBydW5EaXNjb3ZlcnkoKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0bG9nZ2VyLmluZm8oJ1N0YXJ0aW5nIGRldmljZSBkaXNjb3ZlcnkuLi4nKVxuXG5cdFx0dGhpcy5kaXNjb3ZlcmVkRGV2aWNlcyA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLmRpc2NvdmVyRGV2aWNlcygpXG5cblx0XHQvLyBEZXRlcm1pbmUgZWZmZWN0aXZlIG1vZGVsIFx1MjAxNCBmcm9tIGRpc2NvdmVyZWQgZGV2aWNlcyBmaXJzdCwgbWFudWFsIGNvbmZpZyBvbmx5IGFzIGZhbGxiYWNrXG5cdFx0bGV0IGVmZmVjdGl2ZU1vZGVsOiBzdHJpbmdcblx0XHRpZiAodGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGggPT09IDApIHtcblx0XHRcdC8vIElmIGEgc3BlY2lmaWMgZGV2aWNlIE1BQyB3YXMgc2F2ZWQgaW4gY29uZmlnLCBpdCB3YXNuJ3QgZm91bmQgXHUyMDE0IHN0b3AgaGVyZS5cblx0XHRcdGlmICh0aGlzLmNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRcdFx0Y29uc3QgbW9kZWxMYWJlbCA9IHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsID8gYE1vZGVsICR7dGhpcy5jb25maWcuYWN0aXZlTW9kZWx9IGAgOiAnJ1xuXHRcdFx0XHRsb2dnZXIud2FybihgU2F2ZWQgZGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBkdXJpbmcgZGlzY292ZXJ5IFx1MjAxNCBzdG9wcGluZ2ApXG5cdFx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLCBgJHttb2RlbExhYmVsfVske3RoaXMuY29uZmlnLmRldmljZU1hY31dIG5vdCBmb3VuZGApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0Y29uc3QgbWFudWFsTW9kZWwgPSB0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbFxuXHRcdFx0aWYgKCF0aGlzLmNvbmZpZy5ob3N0IHx8ICFtYW51YWxNb2RlbCkge1xuXHRcdFx0XHRsb2dnZXIud2FybignTm8gZGV2aWNlcyBkaXNjb3ZlcmVkIGFuZCBubyBtYW51YWwgSVAvbW9kZWwgY29uZmlndXJlZCcpXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0bG9nZ2VyLmluZm8oJ05vIGRldmljZXMgZGlzY292ZXJlZCBcdTIwMTQgd2lsbCBwcm9iZSBtYW51YWwgSVAgZHVyaW5nIGF1dGhvcml6YXRpb24nKVxuXHRcdFx0ZWZmZWN0aXZlTW9kZWwgPSBtYW51YWxNb2RlbFxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgRGlzY292ZXJlZCAke3RoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RofSBkZXZpY2Uocyk6YClcblx0XHRcdGZvciAoY29uc3QgZCBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGAgIC0gTW9kZWwgJHtkLm1vZGVsfSAke2QubWFudWZhY3R1cmVyID8/ICcnfSBAICR7ZC5pcH1gKVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBBdXRob3JpemUgYWxsIGRpc2NvdmVyZWQgZGV2aWNlcyBzbyBmaXJtd2FyZSByZXF1ZXN0cyBjYW4gcHJvY2VlZC5cblx0XHRcdC8vIHZlcmlmeUF1dGhvcml6YXRpb24gKGNhbGxlZCBiZWxvdykgd2lsbCByZXZva2UgYW55IHRoYXQgZG9uJ3QgbWF0Y2hcblx0XHRcdC8vIHRoZSBjdXJyZW50IGNvbmZpZyBzZWxlY3Rpb24uXG5cdFx0XHRmb3IgKGNvbnN0IGRldmljZSBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShkZXZpY2UuaXApXG5cdFx0XHR9XG5cblx0XHRcdC8vIFJlcXVlc3QgZmlybXdhcmUgdmVyc2lvbiBmcm9tIGVhY2ggZGlzY292ZXJlZCBkZXZpY2Vcblx0XHRcdGZvciAoY29uc3QgZGV2aWNlIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRjb25zdCBmaXJtd2FyZSA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RGaXJtd2FyZVZlcnNpb24oZGV2aWNlLmlwKVxuXHRcdFx0XHRcdGRldmljZS5maXJtd2FyZU1haW4gPSBmaXJtd2FyZVxuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGAgIC0gJHtkZXZpY2UuaXB9OiBGaXJtd2FyZSAke2Zpcm13YXJlfSwgRGFudGUgJHtkZXZpY2UuZGFudGVGaXJtd2FyZX1gKVxuXHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLndhcm4oYCAgLSAke2RldmljZS5pcH06IEZhaWxlZCB0byBnZXQgZmlybXdhcmU6ICR7ZX1gKVxuXHRcdFx0XHRcdGRldmljZS5maXJtd2FyZU1haW4gPSAnVW5rbm93bidcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblxuXHRcdFx0Ly8gSWYgYSBzcGVjaWZpYyBNQUMgd2FzIHNhdmVkIGJ1dCBpc24ndCBpbiB0aGUgZGlzY292ZXJlZCBsaXN0LCBzdG9wLlxuXHRcdFx0aWYgKCFlZmZlY3RpdmVNb2RlbCAmJiB0aGlzLmNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRcdFx0Y29uc3QgbW9kZWxMYWJlbCA9IHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsID8gYE1vZGVsICR7dGhpcy5jb25maWcuYWN0aXZlTW9kZWx9IGAgOiAnJ1xuXHRcdFx0XHRsb2dnZXIud2FybihgU2F2ZWQgZGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBhbW9uZyBkaXNjb3ZlcmVkIGRldmljZXMgXHUyMDE0IHN0b3BwaW5nYClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsIGAke21vZGVsTGFiZWx9WyR7dGhpcy5jb25maWcuZGV2aWNlTWFjfV0gbm90IGZvdW5kYClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gU3luYyBtb2RlbCBzY2hlbWEgdG8gY29udHJvbGxlclxuXHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXG5cdFx0Ly8gVmVyaWZ5IHRoYXQgdGhlIGN1cnJlbnRseSBjb25maWd1cmVkIGhvc3QrbW9kZWwgaXMgdmFsaWQgbm93IHRoYXRcblx0XHQvLyBkaXNjb3ZlcnkgcmVzdWx0cyBhcmUga25vd24uIFRoaXMgaXMgdGhlIHNhbWUgY2hlY2sgY29uZmlnVXBkYXRlZCB1c2VzLlxuXHRcdGNvbnN0IHRhcmdldEhvc3QgPSB0aGlzLmhvc3Rcblx0XHRhd2FpdCB0aGlzLnZlcmlmeUF1dGhvcml6YXRpb24oJycsIHRhcmdldEhvc3QpXG5cblx0XHQvLyBCdWlsZCBhbGwgVUkgbm93IHRoYXQgbW9kZWwgYW5kIGF1dGhvcml6YXRpb24gc3RhdGUgYXJlIGtub3duXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblxuXHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLk9rKVxuXHRcdGxvZ2dlci5pbmZvKCdEZXZpY2UgZGlzY292ZXJ5IGNvbXBsZXRlJylcblx0fVxuXG5cdC8vIFdoZW4gbW9kdWxlIGdldHMgZGVsZXRlZFxuXHRhc3luYyBkZXN0cm95KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuc3RDb250cm9sbGVyPy5jbG9zZSgpXG5cdFx0bG9nZ2VyLmRlYnVnKCdkZXN0cm95Jylcblx0fVxuXG5cdGFzeW5jIGNvbmZpZ1VwZGF0ZWQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRjb25zdCBwcmV2aW91c0hvc3QgPSB0aGlzLmhvc3Rcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGNvbnN0IGVmZmVjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKGNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIENsZWFyIHZhcmlhYmxlcyBpbW1lZGlhdGVseSBcdTIwMTQgdGhlIG5ldyBzZWxlY3Rpb24gaXNuJ3QgYXV0aG9yaXplZCB5ZXQuXG5cdFx0Ly8gVGhleSdsbCBiZSByZXBvcHVsYXRlZCBiZWxvdyBvbmNlIHZlcmlmeUF1dGhvcml6YXRpb24gY29tcGxldGVzLlxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXG5cdFx0Y29uc3QgbmV3SG9zdCA9IHRoaXMuaG9zdFxuXG5cdFx0Ly8gUmUtdmVyaWZ5IGF1dGhvcml6YXRpb24gb24gZXZlcnkgY29uZmlnIGNoYW5nZSAobW9kZWwgb3IgSVApLlxuXHRcdC8vIFRoaXMgaGFuZGxlcyBzd2l0Y2hpbmcgZnJvbSBhIHZhbGlkIGRldmljZSB0byBhbiBpbnZhbGlkIG9uZSBhbmQgYmFjay5cblx0XHRhd2FpdCB0aGlzLnZlcmlmeUF1dGhvcml6YXRpb24ocHJldmlvdXNIb3N0LCBuZXdIb3N0KVxuXG5cdFx0Ly8gUmVidWlsZCBVSSBhZnRlciBhdXRob3JpemF0aW9uIHN0YXRlIGlzIHNldHRsZWRcblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXHR9XG5cblx0LyoqXG5cdCAqIFJlLWV2YWx1YXRlcyB3aGV0aGVyIHRoZSBjdXJyZW50IGNvbmZpZyBpcyBhdXRob3JpemVkIHRvIHNlbmQgY29tbWFuZHMuXG5cdCAqXG5cdCAqIEF1dG8gbW9kZSAoZGV2aWNlTWFjIHNldCk6XG5cdCAqICAgLSBGaW5kIHRoZSBkaXNjb3ZlcmVkIGRldmljZSB3aXRoIG1hdGNoaW5nIE1BQyBcdTIxOTIgZ2V0IGl0cyBjdXJyZW50IElQXG5cdCAqICAgLSBSZXZva2UgdGhlIHByZXZpb3VzIElQLCBhdXRob3JpemUgdGhlIG5ldyBJUFxuXHQgKiAgIC0gSWYgTUFDIG5vdCBmb3VuZCBpbiBkaXNjb3ZlcnksIHJldm9rZSBhbmQgYmxvY2tcblx0ICpcblx0ICogTWFudWFsIG1vZGUgKGRldmljZU1hYyBlbXB0eSk6XG5cdCAqICAgLSBDaGVjayBkaXNjb3ZlcmVkIGxpc3QgYnkgSVArbW9kZWwgbWF0Y2gsIG9yIHByb2JlIGRpcmVjdGx5XG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIHZlcmlmeUF1dGhvcml6YXRpb24ocHJldmlvdXNIb3N0OiBzdHJpbmcsIG5ld0hvc3Q6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGlmICghbmV3SG9zdCkge1xuXHRcdFx0aWYgKHByZXZpb3VzSG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRcdC8vIEF1dG8gbW9kZSBcdTIwMTQgbWF0Y2ggYnkgTUFDLCB1c2Ugd2hhdGV2ZXIgSVAgZGlzY292ZXJ5IGZvdW5kIGl0IGF0XG5cdFx0XHRjb25zdCBkZXZpY2UgPSB0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQubWFjID09PSB0aGlzLmNvbmZpZy5kZXZpY2VNYWMpXG5cdFx0XHRpZiAoIWRldmljZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgRGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBpbiBjdXJyZW50IGRpc2NvdmVyeSBcdTIwMTQgbm90IGF1dGhvcml6aW5nYClcblx0XHRcdFx0aWYgKHByZXZpb3VzSG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRjb25zdCB3YXNBdXRob3JpemVkID0gdGhpcy5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKG5ld0hvc3QpXG5cdFx0XHRpZiAoIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRpZiAobmV3SG9zdCAhPT0gcHJldmlvdXNIb3N0IHx8ICF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMuZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShkZXZpY2UubW9kZWwsIG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBNYW51YWwgbW9kZSBcdTIwMTQgY29uZmlnLmhvc3QgKyBjb25maWcuYWN0aXZlTW9kZWwgbXVzdCBtYXRjaFxuXHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gU3RyaW5nKHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsID8/ICcnKVxuXHRcdGNvbnN0IGRpc2NvdmVyZWRBdElwID0gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLmlwID09PSBuZXdIb3N0KVxuXG5cdFx0aWYgKGRpc2NvdmVyZWRBdElwKSB7XG5cdFx0XHRpZiAoZGlzY292ZXJlZEF0SXAubW9kZWwgPT09IG1hbnVhbE1vZGVsKSB7XG5cdFx0XHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0XHRjb25zdCB3YXNBdXRob3JpemVkID0gdGhpcy5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKG5ld0hvc3QpXG5cdFx0XHRcdGlmICghd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChuZXdIb3N0ICE9PSBwcmV2aW91c0hvc3QgfHwgIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobWFudWFsTW9kZWwsIG5ld0hvc3QpXG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGxvZ2dlci5lcnJvcihcblx0XHRcdFx0XHRgRGV2aWNlIHNlbGVjdGVkIChNb2RlbCAke21hbnVhbE1vZGVsfSkgZG9lcyBub3QgbWF0Y2ggZGV0ZWN0ZWQgZGV2aWNlIChNb2RlbCAke2Rpc2NvdmVyZWRBdElwLm1vZGVsfSkgYXQgJHtuZXdIb3N0fSBcdTIwMTQgY29tbWFuZHMgYmxvY2tlZGAsXG5cdFx0XHRcdClcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKFxuXHRcdFx0XHRcdEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLFxuXHRcdFx0XHRcdGBNb2RlbCBtaXNtYXRjaDogZXhwZWN0ZWQgJHttYW51YWxNb2RlbH0sIGdvdCAke2Rpc2NvdmVyZWRBdElwLm1vZGVsfWAsXG5cdFx0XHRcdClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIElQIG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgXHUyMDE0IHByb2JlIGl0IGRpcmVjdGx5IHZpYSBEYW50ZVxuXHRcdGxvZ2dlci5pbmZvKGAke25ld0hvc3R9IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgXHUyMDE0IHByb2JpbmdgKVxuXHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KVxuXG5cdFx0Y29uc3QgcHJvYmVkID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucHJvYmVEZXZpY2UobmV3SG9zdClcblx0XHRpZiAoIXByb2JlZCkge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBObyBkZXZpY2UgcmVzcG9uZGVkIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgKVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuVW5rbm93bldhcm5pbmcsIGBEZXZpY2Ugb2ZmbGluZTogJHtuZXdIb3N0fWApXG5cdFx0fSBlbHNlIGlmIChwcm9iZWQubW9kZWwgIT09IG1hbnVhbE1vZGVsKSB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdGBEZXZpY2Ugc2VsZWN0ZWQgKE1vZGVsICR7bWFudWFsTW9kZWx9KSBkb2VzIG5vdCBtYXRjaCBkZXRlY3RlZCBkZXZpY2UgKE1vZGVsICR7cHJvYmVkLm1vZGVsfSkgYXQgJHtuZXdIb3N0fSBcdTIwMTQgY29tbWFuZHMgYmxvY2tlZGAsXG5cdFx0XHQpXG5cdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhcblx0XHRcdFx0SW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsXG5cdFx0XHRcdGBNb2RlbCBtaXNtYXRjaDogZXhwZWN0ZWQgJHttYW51YWxNb2RlbH0sIGdvdCAke3Byb2JlZC5tb2RlbH1gLFxuXHRcdFx0KVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgVmVyaWZpZWQgTW9kZWwgJHtwcm9iZWQubW9kZWx9IGF0ICR7bmV3SG9zdH1gKVxuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobWFudWFsTW9kZWwsIG5ld0hvc3QpXG5cdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Paylcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogRmV0Y2hlcyBhbGwgc2V0dGluZ3MgZnJvbSB0aGUgZGV2aWNlLiBJZiBubyBzY2hlbWEgZXhpc3RzIGZvciB0aGUgbW9kZWwsXG5cdCAqIGNyZWF0ZXMgb25lIGZyb20gdGhlIHJlc3BvbnNlIGFuZCByZWxvYWRzIHRoZSBzY2hlbWEgY2FjaGUuXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIGZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobW9kZWw6IHN0cmluZywgaXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApXG5cblx0XHRcdGlmICghZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKSkge1xuXHRcdFx0XHQvLyBObyBzY2hlbWEgZXhpc3RzIFx1MjAxNCBkbyBOT1QgYXV0by1jcmVhdGUgb25lIGhlcmUuXG5cdFx0XHRcdC8vIFRoZSB1c2VyIG11c3QgcnVuIFwiR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzXCIgdG8gY3JlYXRlIGl0LlxuXHRcdFx0XHRsb2dnZXIud2FybihgTm8gc2NoZW1hIGZvdW5kIGZvciBNb2RlbCAke21vZGVsfSBcdTIwMTQgcnVuIFwiR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzXCIgdG8gY3JlYXRlIG9uZWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZmV0Y2ggc2V0dGluZ3MgZnJvbSAke2lwfTogJHtlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqIExvYWRzIHRoZSBkZXZpY2UgSlNPTiBmb3IgdGhlIGdpdmVuIG1vZGVsLCBjYWNoZXMgaXQgYXMgYWN0aXZlTW9kZWwsIGFuZCBwdXNoZXMgaXQgdG8gdGhlIGNvbnRyb2xsZXIuICovXG5cdHByaXZhdGUgc3luY01vZGVsKG1vZGVsOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmFjdGl2ZU1vZGVsID0gbW9kZWxcblx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0aWYgKCFzY2hlbWEpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBNb2RlbCBcIiR7bW9kZWx9XCIgbm90IGZvdW5kIGluIGRldmljZSBzY2hlbWFzYClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBbXSwgdHJ1ZSlcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGNvbnN0IGFjdGlvbnMgPSBBcnJheS5pc0FycmF5KHNjaGVtYS5jbWRTY2hlbWEpID8gc2NoZW1hLmNtZFNjaGVtYSA6IFtdXG5cdFx0Y29uc3QgcmVmcmVzaEFmdGVyQ29tbWFuZCA9IHNjaGVtYS5yZWZyZXNoQWZ0ZXJDb21tYW5kID8/IHRydWVcblxuXHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBhY3Rpb25zLCByZWZyZXNoQWZ0ZXJDb21tYW5kKVxuXHRcdGlmIChhY3Rpb25zLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYE5vIGFjdGlvbnMgZm91bmQgZm9yIG1vZGVsIFwiJHttb2RlbH1cIiBcdTIwMTQgc2V0dGluZ3MgZGVjb2Rpbmcgd2lsbCB1c2UgcmF3IElEc2ApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0YExvYWRlZCAke2FjdGlvbnMubGVuZ3RofSBhY3Rpb25zIGZvciBtb2RlbCBcIiR7bW9kZWx9XCIsIHNlY3Rpb25lZD0ke3NjaGVtYS5zZWN0aW9uZWR9LCByZWZyZXNoQWZ0ZXJDb21tYW5kPSR7cmVmcmVzaEFmdGVyQ29tbWFuZH1gLFxuXHRcdFx0KVxuXHRcdH1cblx0fVxuXG5cdGdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdFx0cmV0dXJuIEdldENvbmZpZ0ZpZWxkcyh0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLCByZXNvbHZlZCBmcm9tIE1BQ1x1MjE5MklQIHZpYSBkaXNjb3ZlcmVkRGV2aWNlcyAoYXV0bykgb3IgY29uZmlnLmhvc3QgKG1hbnVhbCkuICovXG5cdGdldCBob3N0KCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIHJlc29sdmVIb3N0KHRoaXMuY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgZGlzY292ZXJlZCBkZXZpY2VzIGZvciB1c2UgaW4gYWN0aW9ucy9jb25maWcgKi9cblx0Z2V0IGRldmljZXMoKTogRGV2aWNlSW5mb1tdIHtcblx0XHRyZXR1cm4gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlc1xuXHR9XG5cblx0dXBkYXRlQWN0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVBY3Rpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVGZWVkYmFja3MoKTogdm9pZCB7XG5cdFx0VXBkYXRlRmVlZGJhY2tzKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlVmFsdWVzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHRoaXMpXG5cdH1cbn1cblxuZXhwb3J0IHsgVXBncmFkZVNjcmlwdHMgfVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7QUFrQkEsSUFBTSxxQkFBa0MsQ0FBQyxRQUFRLE9BQU8sWUFBVztBQUVsRSxVQUFRLElBQUksSUFBSSxNQUFNLFlBQVcsQ0FBRSxJQUFJLFNBQVMsS0FBSyxNQUFNLE1BQU0sRUFBRSxJQUFJLE9BQU8sRUFBRTtBQUNqRjtBQUVBLFNBQVMsVUFBVSxRQUE0QixPQUFpQixTQUFlO0FBQzlFLFFBQU0sT0FBTyxPQUFPLE9BQU8scUJBQXFCLGFBQWEsT0FBTyxtQkFBbUI7QUFDdkYsT0FBSyxRQUFRLE9BQU8sT0FBTztBQUM1QjtBQU9NLFNBQVUsbUJBQW1CLFFBQWU7QUFDakQsU0FBTztJQUNOLE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPO0lBQzlELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPOztBQUVoRTs7O0FDVE0sU0FBVSxZQUFZLE1BQVc7QUFFdkM7OztBQ2hDQSxTQUFTLG9CQUFvQjtBQTJFdkIsSUFBTyxzQkFBUCxjQUFtQyxhQUFtQztFQUNsRTtFQUNBO0VBRVQsSUFBVyxXQUFRO0FBQ2xCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBQ0EsSUFBVyxhQUFVO0FBQ3BCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBRUEsSUFBWSxhQUFVO0FBQ3JCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7QUFDbkQsYUFBTyxLQUFLO0lBQ2IsT0FBTztBQUNOLGFBQU87SUFDUjtFQUNEO0VBRUEsU0FBdUU7RUFFdkUsWUFBWSxTQUF5QyxTQUErQjtBQUNuRixVQUFLO0FBRUwsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVyxFQUFFLEdBQUcsUUFBTztFQUM3QjtFQUVBLEtBQUssTUFBYyxVQUFtQixVQUFxQjtBQUMxRCxRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLHlCQUF5QjtBQUM3RixZQUFRLEtBQUssUUFBUTtNQUNwQixLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sb0NBQW9DO01BQ3JELEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSx5QkFBeUI7TUFDMUMsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtNQUNwQyxLQUFLO0FBQ0o7TUFDRDtBQUNDLG9CQUFZLEtBQUssTUFBTTtBQUN2QixjQUFNLElBQUksTUFBTSxzQkFBc0I7SUFDeEM7QUFFQSxTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLGFBQWEsUUFBUTtBQUUzQyxTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFFBQVEsS0FBSyxTQUFTO01BQ3RCLFlBQVk7O0tBRVosRUFDQSxLQUNBLENBQUMsYUFBWTtBQUNaLFdBQUssU0FBUyxFQUFFLFlBQVksTUFBTSxTQUFRO0FBQzFDLFdBQUssU0FBUyx3QkFBd0IsSUFBSSxVQUFVLElBQUk7QUFDeEQsV0FBSyxLQUFLLFdBQVc7SUFDdEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVM7QUFDZCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLE1BQU0sVUFBcUI7QUFDMUIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtJQUVwRCxPQUFPO0FBQ04sY0FBUSxLQUFLLFFBQVE7UUFDcEIsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQ0FBb0M7UUFDckQsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9CQUFvQjtRQUNyQztBQUNDLHNCQUFZLEtBQUssTUFBTTtBQUN2QixnQkFBTSxJQUFJLE1BQU0sc0JBQXNCO01BQ3hDO0lBQ0Q7QUFFQSxVQUFNLFdBQVcsS0FBSyxPQUFPO0FBQzdCLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsU0FBUyxRQUFRO0FBRXZDLFNBQUssU0FDSCxxQkFBcUI7TUFDckI7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxPQUFPO0lBQ2xCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFXQSxLQUNDLGNBQ0EsY0FDQSxpQkFDQSxnQkFDQSxTQUNBLFVBQXFCO0FBRXJCLFFBQUksT0FBTyxpQkFBaUI7QUFBVSxZQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDekUsUUFBSSxPQUFPLG9CQUFvQixVQUFVO0FBQ3hDLFVBQUksT0FBTyxtQkFBbUIsWUFBWSxPQUFPLFlBQVk7QUFBVSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDMUcsVUFBSSxhQUFhLFVBQWEsT0FBTyxhQUFhO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRWpHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxjQUFjLGVBQWU7QUFDOUUsV0FBSyxXQUFXLFFBQVEsZ0JBQWdCLFNBQVMsUUFBUTtJQUMxRCxXQUFXLE9BQU8sb0JBQW9CLFVBQVU7QUFDL0MsVUFBSSxtQkFBbUIsVUFBYSxPQUFPLG1CQUFtQjtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUU3RyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsR0FBRyxNQUFTO0FBQzdELFdBQUssV0FBVyxRQUFRLGNBQWMsaUJBQWlCLGNBQWM7SUFDdEUsT0FBTztBQUNOLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtJQUNwQztFQUNEO0VBRUEsZUFDQyxjQUNBLFFBQ0EsUUFBMEI7QUFFMUIsUUFBSTtBQUNKLFFBQUksT0FBTyxpQkFBaUIsVUFBVTtBQUNyQyxlQUFTLE9BQU8sS0FBSyxjQUFjLE9BQU87SUFDM0MsV0FBVyxPQUFPLFNBQVMsWUFBWSxHQUFHO0FBQ3pDLGVBQVM7SUFDVixXQUFXLE1BQU0sUUFBUSxZQUFZLEdBQUc7QUFFdkMsYUFBTyxPQUFPLEtBQUssWUFBWTtJQUNoQyxPQUFPO0FBQ04sZUFBUyxPQUFPLEtBQUssYUFBYSxRQUFRLGFBQWEsWUFBWSxhQUFhLFVBQVU7SUFDM0Y7QUFFQSxXQUFPLE9BQU8sU0FBUyxRQUFRLFdBQVcsU0FBWSxTQUFTLFNBQVMsTUFBUztFQUNsRjtFQUVBLFdBQVcsUUFBZ0IsTUFBYyxTQUFpQixVQUFxQjtBQUM5RSxRQUFJLENBQUMsS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0sb0JBQW9CO0FBRXpGLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsVUFBVSxLQUFLLE9BQU87TUFDdEIsU0FBUztNQUVUO01BQ0E7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLGlCQUFVO0lBQ1gsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLHFCQUFxQixTQUErQjtBQUNuRCxRQUFJO0FBQ0gsV0FBSyxLQUFLLFdBQVcsUUFBUSxTQUFTLFFBQVEsTUFBTTtJQUNyRCxTQUFTLElBQUk7SUFFYjtFQUNEO0VBQ0EsbUJBQW1CLE9BQVk7QUFDOUIsU0FBSyxTQUFTO0FBRWQsVUFBTSxhQUFhLEtBQUs7QUFDeEIsUUFBSTtBQUFZLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxXQUFXLFFBQVE7QUFFaEYsUUFBSTtBQUNILFdBQUssS0FBSyxTQUFTLEtBQUs7SUFDekIsU0FBUyxJQUFJO0lBRWI7RUFDRDs7OztBQzlQSyxTQUFVLGtCQUFtRCxLQUFZO0FBQzlFLFFBQU0sT0FBTztBQUNiLFNBQU8sQ0FBQyxDQUFDLFFBQVEsT0FBTyxTQUFTLFlBQVksT0FBTyxLQUFLLE9BQU8sWUFBWSxLQUFLLHVCQUF1QjtBQUN6Rzs7O0FDNkJNLElBQWdCLGVBQWhCLE1BQTRCO0VBQ3hCO0VBQ0E7RUFFQTtFQUVULElBQVcsS0FBRTtBQUNaLFdBQU8sS0FBSyxTQUFTO0VBQ3RCO0VBRUEsSUFBVyxrQkFBZTtBQUN6QixXQUFPLEtBQUs7RUFDYjs7Ozs7RUFNQSxJQUFXLFFBQUs7QUFDZixXQUFPLEtBQUssU0FBUztFQUN0Qjs7OztFQUtBLFlBQVksVUFBaUI7QUFDNUIsUUFBSSxDQUFDLGtCQUE2QixRQUFRLEtBQUssQ0FBQyxTQUFTO0FBQ3hELFlBQU0sSUFBSSxNQUNULG1HQUFtRztBQUdyRyxTQUFLLFdBQVc7QUFFaEIsU0FBSyxVQUFVLG1CQUFrQjtBQUVqQyxTQUFLLHdCQUF3QixLQUFLLHNCQUFzQixLQUFLLElBQUk7QUFFakUsU0FBSyxXQUFXO01BQ2YsMkJBQTJCO01BQzNCLHdCQUF3Qjs7QUFHekIsU0FBSyxJQUFJLFNBQVMsY0FBYztFQUNqQztFQStCQSxXQUFXLFdBQTRDLFlBQWlDO0FBQ3ZGLFNBQUssU0FBUyxXQUFXLFdBQVcsVUFBVTtFQUMvQzs7Ozs7RUF1QkEscUJBQXFCLFNBQXlEO0FBQzdFLFNBQUssU0FBUyxxQkFBcUIsT0FBTztFQUMzQzs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7Ozs7RUFPQSxxQkFDQyxXQUNBLFNBQThDO0FBRTlDLFNBQUssU0FBUyxxQkFBcUIsV0FBVyxPQUFPO0VBQ3REOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixRQUFJLE1BQU0sUUFBUSxTQUFTO0FBQUcsWUFBTSxJQUFJLE1BQU0sd0RBQXdEO0FBRXRHLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7RUFNQSxrQkFBa0IsUUFBdUM7QUFDeEQsU0FBSyxTQUFTLGtCQUFrQixNQUFNO0VBQ3ZDOzs7Ozs7RUFPQSxpQkFBbUMsWUFBYTtBQUMvQyxXQUFPLEtBQUssU0FBUyxpQkFBaUIsVUFBVTtFQUNqRDs7OztFQUtBLG9CQUFpQjtBQUNoQixTQUFLLFNBQVMsa0JBQWlCO0VBQ2hDOzs7Ozs7O0VBUUEsZUFDQyxpQkFDRyxlQUFtRDtBQUV0RCxTQUFLLFNBQVMsZUFBZSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUM7RUFDOUQ7Ozs7O0VBTUEsc0JBQXNCLGFBQXFCO0FBQzFDLFNBQUssU0FBUyxtQkFBbUIsV0FBVztFQUM3Qzs7Ozs7O0VBT0Esb0JBQW9CLFdBQW1CO0FBQ3RDLFNBQUssU0FBUyxpQkFBaUIsU0FBUztFQUN6Qzs7Ozs7O0VBTUEsc0JBQXNCLFdBQW1CO0FBQ3hDLFNBQUssU0FBUyxtQkFBbUIsU0FBUztFQUMzQzs7Ozs7O0VBT0Esd0JBQXdCLGFBQXFCO0FBQzVDLFNBQUssU0FBUyxxQkFBcUIsV0FBVztFQUMvQzs7Ozs7O0VBT0EsYUFBYSxRQUFpQyxjQUFxQjtBQUNsRSxTQUFLLFNBQVMsYUFBYSxRQUFRLFlBQVk7RUFDaEQ7Ozs7Ozs7O0VBU0EsUUFBUSxNQUFjLE1BQWNBLE9BQWMsTUFBc0I7QUFDdkUsU0FBSyxTQUFTLFFBQVEsTUFBTSxNQUFNQSxPQUFNLElBQUk7RUFDN0M7Ozs7Ozs7Ozs7O0VBWUEsYUFBYSxRQUF3QixTQUF1QjtBQUMzRCxTQUFLLFNBQVMsYUFBYSxRQUFRLFdBQVcsSUFBSTtFQUNuRDs7Ozs7O0VBT0EsSUFBSSxPQUFpQixTQUFlO0FBQ25DLFlBQVEsT0FBTztNQUNkLEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0Q7QUFDQyxvQkFBWSxLQUFLO0FBQ2pCLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7SUFDRjtFQUNEO0VBWUEsc0JBQ0MsZUFDQSxVQUF5QztBQUV6QyxVQUFNLFVBQWtDLE9BQU8sa0JBQWtCLFdBQVcsRUFBRSxNQUFNLGNBQWEsSUFBSztBQUV0RyxVQUFNLFNBQVMsSUFBSSxvQkFBb0IsS0FBSyxVQUFVLE9BQU87QUFDN0QsUUFBSTtBQUFVLGFBQU8sR0FBRyxXQUFXLFFBQVE7QUFFM0MsV0FBTztFQUNSOzs7O0FDL1VELElBQVk7Q0FBWixTQUFZQyxpQkFBYztBQUN6QixFQUFBQSxnQkFBQSxJQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxZQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxtQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsV0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsZ0JBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHVCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx5QkFBQSxJQUFBO0FBQ0QsR0FWWSxtQkFBQSxpQkFBYyxDQUFBLEVBQUE7QUFhcEIsSUFBVztDQUFqQixTQUFpQkMsUUFBSztBQUVSLEVBQUFBLE9BQUEsS0FBSztBQUNMLEVBQUFBLE9BQUEsV0FDWjtBQUNZLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsT0FDWjtBQUNZLEVBQUFBLE9BQUEsY0FBYztBQUNkLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsUUFBUTtBQUNSLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsU0FBUztBQUNULEVBQUFBLE9BQUEsZ0JBQWdCO0FBQ2hCLEVBQUFBLE9BQUEsWUFBWTtBQUNaLEVBQUFBLE9BQUEsV0FDWjtBQUNGLEdBbEJpQixVQUFBLFFBQUssQ0FBQSxFQUFBOzs7QUNqQnRCLE9BQU8sUUFBUTtBQUNmLE9BQU8sVUFBVTtBQUlqQixJQUFNLFNBQVMsbUJBQW1CLFFBQVE7QUF1QjFDLFNBQVMsdUJBQW9CO0FBQzVCLFFBQU0sY0FBYyxLQUFLLEtBQUssWUFBWSxTQUFTLFlBQVk7QUFDL0QsUUFBTSxlQUFlLEtBQUssS0FBSyxZQUFZLFNBQVMsV0FBVztBQUcvRCxNQUFJLEdBQUcsV0FBVyxXQUFXLEdBQUc7QUFDL0IsV0FBTyxNQUFNLHlCQUF5QixXQUFXLEVBQUU7QUFDbkQsV0FBTztFQUNSO0FBR0EsTUFBSSxHQUFHLFdBQVcsWUFBWSxHQUFHO0FBQ2hDLFdBQU8sS0FBSyxxREFBcUQsWUFBWSxFQUFFO0FBQy9FLFdBQU87RUFDUjtBQUdBLFFBQU0sV0FBVzs7TUFBMEMsV0FBVztNQUFTLFlBQVk7O0FBQzNGLFNBQU8sTUFBTSxRQUFRO0FBQ3JCLFFBQU0sSUFBSSxNQUFNLFFBQVE7QUFDekI7QUFHQSxJQUFNLGdCQUFnQixxQkFBb0I7QUFHMUMsSUFBSSxxQkFBaUQ7QUFNL0MsU0FBVSxtQkFBZ0I7QUFDL0IsU0FBTztBQUNSO0FBTUEsU0FBUyxvQkFBaUI7QUFDekIsUUFBTSxVQUErQixDQUFBO0FBQ3JDLE1BQUk7QUFDSCxVQUFNLFFBQVEsR0FBRyxZQUFZLGFBQWEsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsT0FBTyxDQUFDO0FBRTdFLGVBQVcsS0FBSyxPQUFPO0FBQ3RCLFlBQU0sV0FBVyxLQUFLLEtBQUssZUFBZSxDQUFDO0FBQzNDLFlBQU0sT0FBTyxLQUFLLE1BQU0sR0FBRyxhQUFhLFVBQVUsTUFBTSxDQUFDO0FBQ3pELFVBQUksTUFBTSxPQUFPO0FBQ2hCLGdCQUFRLE9BQU8sS0FBSyxLQUFLLENBQUMsSUFBSTtNQUMvQjtJQUNEO0FBRUEsV0FBTyxNQUFNLFVBQVUsT0FBTyxLQUFLLE9BQU8sRUFBRSxNQUFNLDRCQUE0QjtFQUMvRSxTQUFTLEdBQUc7QUFDWCxXQUFPLE1BQU0sa0NBQWtDLENBQUMsRUFBRTtFQUNuRDtBQUNBLFNBQU87QUFDUjtBQU1NLFNBQVUsbUJBQWdCO0FBQy9CLE1BQUksQ0FBQyxvQkFBb0I7QUFDeEIseUJBQXFCLGtCQUFpQjtFQUN2QztBQUNBLFNBQU87QUFDUjtBQU1NLFNBQVUsZ0JBQWdCLE9BQWE7QUFDNUMsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxTQUFPLFFBQVEsS0FBSztBQUNyQjtBQU1NLFNBQVUsc0JBQW1CO0FBQ2xDLFNBQU8sS0FBSyx1Q0FBdUM7QUFDbkQsdUJBQXFCLGtCQUFpQjtBQUN2QztBQUtBLFNBQVMsc0JBQW1CO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsU0FBTyxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUk7QUFDakM7QUFFTSxTQUFVLGdCQUFnQixvQkFBa0MsQ0FBQSxHQUFFO0FBQ25FLFFBQU0sU0FBUyxvQkFBbUI7QUFJbEMsUUFBTSxnQkFBZ0I7SUFDckIsRUFBRSxJQUFJLElBQUksT0FBTyxrQ0FBaUM7SUFDbEQsR0FBRyxrQkFBa0IsSUFBSSxDQUFDLE9BQU87TUFDaEMsSUFBSSxFQUFFLE9BQU87TUFDYixPQUFPLFNBQVMsRUFBRSxLQUFLLEtBQUssRUFBRSxHQUFHLE9BQU8sRUFBRSxFQUFFO01BQzNDOztBQUdILFNBQU87OztJQUdOO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxTQUFTO01BQ1QsU0FBUzs7O0lBSVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULE9BQU8sTUFBTTtNQUNiLHFCQUFxQjtNQUNyQixTQUFTOzs7SUFJVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTLE9BQU8sQ0FBQyxLQUFLO01BQ3RCLFNBQVMsT0FBTyxJQUFJLENBQUMsV0FBVztRQUMvQixJQUFJO1FBQ0osT0FBTyxTQUFTLEtBQUs7UUFDcEI7TUFDRixxQkFBcUI7TUFDckIsU0FBUzs7O0FBR1o7QUFPTSxTQUFVLFlBQVksUUFBc0IsbUJBQStCO0FBQ2hGLE1BQUksT0FBTyxXQUFXO0FBQ3JCLFVBQU0sU0FBUyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE9BQU8sU0FBUztBQUN2RSxXQUFPLFFBQVEsTUFBTTtFQUN0QjtBQUNBLFNBQU8sT0FBTyxPQUFPLFFBQVEsRUFBRTtBQUNoQztBQU9NLFNBQVUsYUFBYSxRQUFzQixtQkFBK0I7QUFDakYsTUFBSSxPQUFPLFdBQVc7QUFDckIsVUFBTSxTQUFTLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsT0FBTyxTQUFTO0FBQ3ZFLFdBQU8sTUFBTSw0QkFBNEIsT0FBTyxTQUFTLG9CQUFvQixRQUFRLFNBQVMsTUFBTSxFQUFFO0FBQ3RHLFdBQU8sUUFBUSxTQUFTO0VBQ3pCO0FBQ0EsU0FBTyxNQUFNLDJDQUEyQyxPQUFPLFdBQVcsR0FBRztBQUM3RSxTQUFPLE9BQU8sT0FBTyxlQUFlLEVBQUU7QUFDdkM7OztBQ3hNTSxTQUFVLDBCQUEwQixNQUFvQjtBQUM3RCxPQUFLLHVCQUF1QjtJQUMzQixPQUFPLEVBQUUsTUFBTSxzQkFBcUI7SUFDcEMsV0FBVyxFQUFFLE1BQU0sdUNBQXNDO0lBQ3pELGNBQWMsRUFBRSxNQUFNLHNCQUFxQjtJQUMzQyxVQUFVLEVBQUUsTUFBTSwwQkFBeUI7SUFDM0MsU0FBUyxFQUFFLE1BQU0sZ0NBQStCO0lBQ2hELEtBQUssRUFBRSxNQUFNLHFCQUFvQjtJQUNqQyxJQUFJLEVBQUUsTUFBTSxvQkFBbUI7R0FDL0I7QUFDRjtBQUVBLElBQU0sb0JBQW9CO0VBQ3pCLE9BQU87RUFDUCxXQUFXO0VBQ1gsY0FBYztFQUNkLFVBQVU7RUFDVixTQUFTO0VBQ1QsS0FBSztFQUNMLElBQUk7O0FBUUMsU0FBVSxxQkFBcUIsTUFBb0I7QUFDeEQsUUFBTSxjQUFjLEtBQUs7QUFHekIsTUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLGFBQWEsbUJBQW1CLFdBQVcsR0FBRztBQUN2RSxTQUFLLGtCQUFrQixpQkFBaUI7QUFDeEM7RUFDRDtBQUVBLFFBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFdBQVc7QUFDNUQsTUFBSSxRQUFRO0FBQ1gsU0FBSyxrQkFBa0I7TUFDdEIsT0FBTyxPQUFPLFNBQVM7TUFDdkIsV0FBVyxPQUFPLGFBQWE7TUFDL0IsY0FBYyxPQUFPLGdCQUFnQjtNQUNyQyxVQUFVLE9BQU8sZ0JBQWdCO01BQ2pDLFNBQVMsT0FBTyxpQkFBaUI7TUFDakMsS0FBSyxPQUFPLE9BQU87TUFDbkIsSUFBSSxPQUFPO0tBQ1g7RUFDRixPQUFPO0FBR04sU0FBSyxrQkFBa0I7TUFDdEIsR0FBRztNQUNILElBQUk7S0FDSjtFQUNGO0FBQ0Q7OztBQzFETyxJQUFNLGlCQUErRDs7Ozs7Ozs7Ozs7Ozs7O0FDcUJyRSxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGNBQWM7QUFDcEIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sY0FBYztBQUNwQixJQUFNLGdCQUFnQjtBQUN0QixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGFBQWE7QUFDbkIsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxvQkFBb0I7QUFDMUIsSUFBTSxlQUFlO0FBQ3JCLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sY0FBYztBQUdyQixTQUFVLGVBQWUsT0FBYTtBQUMzQyxVQUFRLE9BQU87SUFDZCxLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1I7QUFDQyxhQUFPLFNBQVMsTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDO0VBQ3JEO0FBQ0Q7QUFRTSxTQUFVLGNBQ2YsT0FDQSxPQUNBLFdBQ0EsT0FBdUI7QUFFdkIsUUFBTSxNQUFNLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUyxFQUFFLElBQUk7QUFDN0QsUUFBTSxLQUFLLE9BQU8sY0FBYyxXQUFXLFVBQVUsU0FBUyxFQUFFLElBQUk7QUFFcEUsTUFBSSxVQUFVLFFBQVc7QUFDeEIsVUFBTSxLQUFLLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUyxFQUFFLElBQUk7QUFDNUQsV0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRSxJQUFJLEVBQUU7RUFDbkM7QUFFQSxTQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxFQUFFO0FBQzdCO0FBU00sU0FBVSxNQUFNLE9BQWUsWUFBWSxHQUFDO0FBQ2pELFNBQU8sS0FBSyxNQUFNLFNBQVMsRUFBRSxFQUFFLFNBQVMsV0FBVyxHQUFHLENBQUM7QUFDeEQ7QUFPTSxTQUFVLFdBQVcsT0FBd0I7QUFDbEQsU0FBTyxLQUFLLE1BQU0sS0FBSyxLQUFLLEVBQzFCLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUUsQ0FBQztBQUNYO0FBU00sU0FBVSxlQUFlLEdBQVcsR0FBVyxHQUFTO0FBQzdELFNBQU8sSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQ2pCLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUUsRUFDUCxZQUFXLENBQUU7QUFDaEI7QUFRTSxTQUFVLGVBQWUsSUFBVTtBQUN4QyxRQUFNLENBQUMsT0FBTyxVQUFVLEtBQUssSUFBSSxHQUFHLE1BQU0sR0FBRztBQUM3QyxTQUFPO0lBQ047SUFDQSxPQUFPLFNBQVMsVUFBVSxFQUFFO0lBQzVCLFFBQVEsU0FBUyxPQUFPLEVBQUU7O0FBRTVCO0FBVU0sU0FBVSxjQUFjLFFBQWdCLFFBQWM7QUFDM0QsUUFBTSxLQUFLLFNBQVMsT0FBTyxRQUFRLE9BQU8sRUFBRSxHQUFHLEVBQUU7QUFDakQsUUFBTSxLQUFLLFNBQVMsT0FBTyxRQUFRLE9BQU8sRUFBRSxHQUFHLEVBQUU7QUFDakQsTUFBSSxPQUFPLE1BQU0sRUFBRSxLQUFLLE9BQU8sTUFBTSxFQUFFO0FBQUcsV0FBTztBQUNqRCxTQUFPLEtBQUssSUFBSSxLQUFLLEVBQUU7QUFDeEI7QUFTTSxTQUFVLHFCQUNmLFlBQStCO0FBRS9CLFFBQU0sYUFBa0UsQ0FBQTtBQUN4RSxhQUFXLENBQUMsT0FBTyxJQUFJLEtBQUssT0FBTyxRQUFRLFVBQVUsR0FBRztBQUN2RCxlQUFXLEtBQUssSUFBSTtNQUNuQixPQUFPLEtBQUs7TUFDWixXQUFXLE1BQU0sUUFBUSxLQUFLLFNBQVMsSUFBSSxLQUFLLFlBQVksQ0FBQTs7RUFFOUQ7QUFDQSxTQUFPO0FBQ1I7QUFZTSxTQUFVLHFCQUNmLFNBQ0EsT0FDQSxPQUNBLFdBQWlCO0FBRWpCLFFBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsTUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLFFBQVEsT0FBTyxTQUFTO0FBQUcsV0FBTztBQUd4RCxNQUFJLFNBQVMsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFXLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBR3ZGLE1BQUksQ0FBQyxRQUFRO0FBQ1osYUFBUyxPQUFPLFVBQVUsS0FBSyxDQUFDLE1BQVU7QUFDekMsVUFBSSxFQUFFLFdBQVc7QUFBTyxlQUFPO0FBQy9CLFlBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFDcEUsVUFBSSxDQUFDLGFBQWE7QUFBUyxlQUFPO0FBRWxDLFlBQU0sU0FBUyxZQUFZLEVBQUU7QUFDN0IsYUFBTyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU07SUFDNUQsQ0FBQztFQUNGO0FBRUEsU0FBTztBQUNSOzs7QUN6TUEsU0FBUyxZQUFZLEdBQU07QUFDMUIsUUFBTSxPQUFPO0lBQ1osTUFBTSxFQUFFO0lBQ1IsSUFBSSxFQUFFO0lBQ04sT0FBTyxFQUFFO0lBQ1QsU0FBUyxFQUFFO0lBQ1gsU0FBUyxFQUFFOztBQUdaLFVBQVEsRUFBRSxNQUFNO0lBQ2YsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sU0FBUyxFQUFFLFdBQVcsQ0FBQSxFQUFFO0lBRTNDLEtBQUs7QUFDSixhQUFPO1FBQ04sR0FBRztRQUNILEtBQUssRUFBRTtRQUNQLEtBQUssRUFBRTtRQUNQLE1BQU0sRUFBRSxRQUFRO1FBQ2hCLE9BQU87O0lBR1QsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sU0FBUyxFQUFFLFdBQVcsTUFBSztJQUU5QyxLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxPQUFPLEVBQUUsU0FBUyxHQUFFO0lBRXZDLEtBQUs7SUFDTCxLQUFLO0lBQ0w7QUFDQyxhQUFPO0VBQ1Q7QUFDRDtBQU1NLFNBQVUsZUFBWTtBQUMzQixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sVUFBc0MsQ0FBQTtBQUU1QyxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLEtBQUssV0FBVztBQUMxQixZQUFNLFdBQVcsY0FBYyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7QUFFcEQsWUFBTSxXQUFXLEVBQUUsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRWpELFlBQU0sU0FBb0M7UUFDekMsTUFBTSxTQUFTLEtBQUssS0FBSyxFQUFFLElBQUk7UUFDL0I7UUFDQSxVQUFVLFlBQVc7UUFFckI7O0FBR0QsY0FBUSxRQUFRLElBQUk7SUFDckI7RUFDRDtBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsaUJBQWM7QUFDN0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxRQUFNLFlBQTBDLENBQUE7QUFFaEQsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxXQUFXLFdBQVc7QUFDaEMsWUFBTSxpQkFBaUIsY0FBYyxPQUFPLFFBQVEsUUFBUSxRQUFRLEVBQUU7QUFHdEUsWUFBTSxjQUFjLFFBQVEsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRzFELFlBQU0sZUFBZSxXQUFXLE9BQU8sQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBR3ZFLG1CQUFhLEtBQUs7UUFDakIsTUFBTTtRQUNOLElBQUk7UUFDSixPQUFPO1FBQ1AsU0FBUztRQUNULFNBQVM7T0FDVDtBQUdELFlBQU0sZ0JBQXFCO1FBQzFCLE1BQU07UUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtRQUNyQyxTQUFTO1FBQ1QsVUFBVSxNQUFLO0FBRWQsaUJBQU87UUFDUjs7QUFHRCxnQkFBVSxjQUFjLElBQUk7SUFDN0I7RUFDRDtBQUVBLFNBQU87QUFDUjs7O0FDOUhBLE9BQU9DLFdBQVU7OztBQ0xqQixPQUFPQyxTQUFRO0FBaUJmLElBQU1DLFVBQVMsbUJBQW1CLGdCQUFnQjtBQXlDbEQsU0FBUyxlQUFlLE9BQWE7QUFDcEMsUUFBTSxTQUFTLG9CQUFJLElBQUc7QUFDdEIsTUFBSSxZQUFZO0FBRWhCLE1BQUk7QUFFSCxVQUFNLE9BQU8sZ0JBQWdCLEtBQUs7QUFDbEMsUUFBSSxDQUFDLE1BQU07QUFFVixhQUFPLEVBQUUsV0FBVyxPQUFNO0lBQzNCO0FBR0EsZ0JBQVksS0FBSyxhQUFhO0FBRzlCLGVBQVcsVUFBVSxLQUFLLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0saUJBQWlCLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBd0IsSUFBSSxTQUFTLGFBQWE7QUFDL0YsVUFBSSxnQkFBZ0I7QUFFbkIsZUFBTyxJQUFJLE9BQU8sRUFBRTtBQUdwQixjQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLE9BQU8sT0FBTztBQUNwRixZQUFJLGFBQWEsU0FBUztBQUN6QixxQkFBVyxVQUFVLFlBQVksU0FBUztBQUN6QyxnQkFBSSxPQUFPLE9BQU8sT0FBTyxVQUFVO0FBQ2xDLHFCQUFPLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRTtZQUNqQztVQUNEO1FBQ0Q7TUFDRDtJQUNEO0VBQ0QsU0FBUyxNQUFNO0VBRWY7QUFFQSxTQUFPLEVBQUUsV0FBVyxPQUFNO0FBQzNCO0FBTUEsU0FBUyxzQkFBc0IsS0FBVztBQUN6QyxRQUFNLFdBQVcsSUFBSSxRQUFRLE9BQU8sS0FBSyxVQUFVLENBQUM7QUFDcEQsTUFBSSxXQUFXO0FBQUcsVUFBTSxJQUFJLE1BQU0saUNBQWlDO0FBRW5FLFFBQU0sZUFBZSxXQUFXO0FBQ2hDLE1BQUksSUFBSSxZQUFZLE1BQU0sSUFBTTtBQUMvQixVQUFNLElBQUksTUFBTSx1Q0FBdUMsSUFBSSxZQUFZLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRTtFQUN4RjtBQUVBLFNBQU87QUFDUjtBQU1BLFNBQVMsdUJBQXVCLE9BQWUsU0FBc0Isb0JBQUksSUFBRyxHQUFFO0FBQzdFLE1BQUksSUFBSTtBQUNSLFFBQU0sTUFBdUIsQ0FBQTtBQUU3QixTQUFPLElBQUksTUFBTSxRQUFRO0FBQ3hCLFVBQU0sS0FBSyxNQUFNLENBQUM7QUFDbEIsUUFBSSxJQUFJLEtBQUssTUFBTTtBQUFRO0FBRzNCLFFBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTSxRQUFRO0FBQzNDLFVBQUksS0FBSztRQUNSLFFBQVE7UUFDUjtRQUNBLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQztPQUNyRDtBQUNELFdBQUs7QUFDTDtJQUNEO0FBRUEsUUFBSSxLQUFLLEVBQUUsUUFBUSxjQUFjLElBQUksWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFFO0FBQ2pFLFNBQUs7RUFDTjtBQUVBLFNBQU87QUFDUjtBQUVNLFNBQVUseUJBQXlCLEtBQWEsT0FBYTtBQUNsRSxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSw0QkFBNEI7RUFDN0M7QUFFQSxRQUFNLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFDNUIsUUFBTSxRQUFRLE1BQU07QUFDcEIsUUFBTSxNQUFNLFFBQVE7QUFDcEIsTUFBSSxNQUFNLElBQUk7QUFBUSxVQUFNLElBQUksTUFBTSxzQkFBc0I7QUFFNUQsUUFBTSxFQUFFLE9BQU0sSUFBSyxlQUFlLEtBQUs7QUFDdkMsU0FBTyx1QkFBdUIsSUFBSSxTQUFTLE9BQU8sR0FBRyxHQUFHLE1BQU07QUFDL0Q7QUFNTSxTQUFVLDhCQUE4QixLQUFhLE9BQWE7QUFDdkUsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0sNEJBQTRCO0VBQzdDO0FBR0EsTUFBSSxJQUFJLFVBQVUsdUJBQXVCLE1BQU0sSUFBSSxNQUFNO0FBQ3pELFFBQU0sTUFBTSxJQUFJLFNBQVM7QUFDekIsUUFBTSxNQUF1QixDQUFBO0FBRzdCLFFBQU0sRUFBRSxPQUFNLElBQUssZUFBZSxLQUFLO0FBSXZDLFFBQU0sb0JBQW9CLENBQUMsYUFBYSxpQkFBaUIsV0FBVztBQUtwRSxRQUFNLG1CQUFtQixDQUFDLFdBQVc7QUFFckMsU0FBTyxJQUFJLElBQUksS0FBSztBQUNuQixVQUFNLFNBQVMsSUFBSSxDQUFDO0FBQ3BCLFVBQU0sZUFBZSxJQUFJLElBQUksQ0FBQztBQUU5QixVQUFNLGFBQWEsSUFBSSxJQUFJO0FBQzNCLFFBQUksYUFBYTtBQUFLO0FBRXRCLFVBQU0sV0FBVyxrQkFBa0IsU0FBUyxZQUFZO0FBQ3hELFVBQU0sYUFBYSxpQkFBaUIsU0FBUyxZQUFZO0FBRXpELFFBQUk7QUFDSixRQUFJO0FBQ0osUUFBSTtBQUVKLFFBQUksWUFBWTtBQU9mLGNBQVEsSUFBSSxJQUFJLENBQUM7QUFDakIsWUFBTSxXQUFXLElBQUksU0FBUyxJQUFJLEdBQUcsVUFBVTtBQUMvQyxZQUFNLGNBQW9DLENBQUMsR0FBRyxDQUFDO0FBQy9DLGVBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDekMsWUFBSSxpQkFBaUIsYUFBYTtBQUNqQyxnQkFBTSxhQUFhLElBQUksWUFBWSxTQUFTLFlBQVksQ0FBQyxJQUFJO0FBQzdELGNBQUksZUFBZSxNQUFNO0FBQ3hCLGdCQUFJLEtBQUssRUFBRSxRQUFRLGlCQUFpQixJQUFJLFlBQVksT0FBTyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBQyxDQUFFO1VBQ3ZGO1FBQ0QsT0FBTztBQUNOLGNBQUksS0FBSyxFQUFFLFFBQVEsY0FBYyxJQUFJLEdBQUcsT0FBTyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBQyxDQUFFO1FBQzNFO01BQ0Q7QUFDQSxVQUFJO0FBQ0o7SUFDRCxXQUFXLFVBQVU7QUFFcEIsY0FBUSxJQUFJLElBQUksQ0FBQztBQUNqQixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVCxPQUFPO0FBRU4sZ0JBQVUsSUFBSSxJQUFJLENBQUM7QUFDbkIsVUFBSSxJQUFJO0lBQ1Q7QUFFQSxVQUFNLE9BQU8sSUFBSTtBQUNqQixVQUFNLFNBQVM7QUFFZixXQUFPLElBQUksSUFBSSxNQUFNO0FBQ3BCLFlBQU0sS0FBSyxJQUFJLENBQUM7QUFDaEIsVUFBSTtBQUdKLFVBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTTtBQUNuQyxxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ2hELGFBQUs7TUFDTixPQUFPO0FBQ04scUJBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ3hCLGFBQUs7TUFDTjtBQUVBLFlBQU0sVUFBeUI7UUFDOUIsUUFBUTtRQUNSO1FBQ0E7O0FBRUQsVUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQVEsUUFBUTtNQUNqQjtBQUNBLFVBQUksS0FBSyxPQUFPO0lBQ2pCO0FBUUEsUUFBSSxNQUFNLFVBQVUsYUFBYSxJQUFJLEdBQUc7QUFDdkMsVUFBSSxNQUFNLFdBQVcsSUFBSSxJQUFJLElBQUk7QUFDakMsVUFBSSxRQUFRO0FBQ1osYUFBTyxNQUFNLFlBQVk7QUFDeEIsY0FBTSxVQUF5QixFQUFFLFFBQVEsY0FBYyxJQUFJLFNBQVMsWUFBWSxDQUFDLElBQUksS0FBSyxDQUFDLEVBQUM7QUFDNUYsWUFBSSxVQUFVO0FBQVcsa0JBQVEsUUFBUTtBQUN6QyxZQUFJLEtBQUssT0FBTztNQUNqQjtJQUNEO0FBRUEsUUFBSTtFQUNMO0FBRUEsU0FBTztBQUNSO0FBV00sU0FBVSxzQkFBc0IsT0FBZSxLQUFXO0FBQy9ELFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLGlDQUFpQyxNQUFNLFNBQVMsRUFBRSxDQUFDLEdBQUc7RUFDdkU7QUFDQSxRQUFNLEVBQUUsVUFBUyxJQUFLLGVBQWUsS0FBSztBQUMxQyxTQUFPLFlBQVksOEJBQThCLEtBQUssS0FBSyxJQUFJLHlCQUF5QixLQUFLLEtBQUs7QUFDbkc7QUFNTSxTQUFVLG9CQUFvQixTQUF3QixTQUFtQjtBQUU5RSxNQUFJLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsUUFBUSxVQUFVLEVBQUUsT0FBTyxRQUFRLEVBQUU7QUFLbkYsTUFBSSxDQUFDLFFBQVE7QUFDWixVQUFNLGFBQWEsUUFBUSxLQUFLLENBQUMsTUFBSztBQUNyQyxVQUFJLEVBQUUsV0FBVyxRQUFRO0FBQVEsZUFBTztBQUV4QyxZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQy9ELFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLGdCQUFnQixRQUFRLEtBQUssRUFBRTtBQUNyQyxhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtJQUM5RCxDQUFDO0FBQ0QsUUFBSSxZQUFZO0FBQ2YsZUFBUztJQUNWO0VBQ0Q7QUFFQSxRQUFNLFNBQVMsTUFBTSxRQUFRLE1BQU07QUFDbkMsUUFBTSxRQUFRLE1BQU0sUUFBUSxFQUFFO0FBQzlCLFFBQU0sU0FBUyxXQUFXLFFBQVEsVUFBVTtBQUM1QyxRQUFNLFNBQ0wsUUFBUSxXQUFXLFdBQVcsSUFDM0IsZUFBZSxRQUFRLFdBQVcsQ0FBQyxHQUFHLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsQ0FBQyxJQUNsRixRQUFRLFdBQVcsV0FBVyxJQUM3QixRQUFRLFdBQVcsQ0FBQyxJQUNwQixRQUFRLFdBQVcsS0FBSyxHQUFHO0FBR2hDLFFBQU0sV0FBVyxRQUFRLFVBQVUsU0FBWSxPQUFPLFFBQVEsS0FBSyxLQUFLO0FBQ3hFLFFBQU0sU0FBUyxPQUFPLE1BQU0sR0FBRyxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU07QUFHakUsTUFBSSxRQUFRO0FBQ1gsUUFBSSxPQUFPLE9BQU87QUFHbEIsUUFBSSxRQUFRLFVBQVUsUUFBVztBQUNoQyxhQUFPLEdBQUcsSUFBSSxNQUFNLFFBQVEsUUFBUSxDQUFDO0lBQ3RDLE9BRUs7QUFDSixZQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksYUFBYSxTQUFTO0FBQ3pCLGNBQU0sZ0JBQWdCLFFBQVEsS0FBSyxPQUFPO0FBQzFDLGNBQU0sY0FBYyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGFBQWE7QUFDMUUsWUFBSSxhQUFhO0FBQ2hCLGlCQUFPLEdBQUcsSUFBSSxJQUFJLFlBQVksS0FBSztRQUNwQztNQUNEO0lBQ0Q7QUFHQSxVQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFFBQUksYUFBYSxXQUFXLFFBQVEsV0FBVyxXQUFXLEdBQUc7QUFDNUQsWUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxXQUFXLENBQUMsQ0FBQztBQUM3RSxVQUFJLFFBQVE7QUFDWCxlQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNO01BQ3ZEO0lBQ0Q7QUFDQSxXQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxNQUFNO0VBQ3RDO0FBR0EsU0FBTyxHQUFHLE1BQU07QUFDakI7QUFpQk0sU0FBVSxpQ0FDZixPQUNBLEtBQVc7QUFFWCxRQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsUUFBTSxvQkFBb0IsUUFBUTtBQUdsQyxNQUFJLHNCQUFzQixRQUFXO0FBQ3BDLFVBQU0sV0FBVyxvQkFDZCw4QkFBOEIsS0FBSyxLQUFLLElBQ3hDLHlCQUF5QixLQUFLLEtBQUs7QUFDdEMsV0FBTyxFQUFFLFVBQVUsbUJBQW1CLEtBQUk7RUFDM0M7QUFHQSxNQUFJLGVBQWdDLENBQUE7QUFDcEMsTUFBSSxvQkFBcUMsQ0FBQTtBQUV6QyxNQUFJO0FBQ0gsbUJBQWUseUJBQXlCLEtBQUssS0FBSztFQUNuRCxTQUFTLEdBQUc7QUFDWCxJQUFBQSxRQUFPLE1BQU0sdUJBQXVCLENBQUMsRUFBRTtFQUN4QztBQUVBLE1BQUk7QUFDSCx3QkFBb0IsOEJBQThCLEtBQUssS0FBSztFQUM3RCxTQUFTLEdBQUc7QUFDWCxJQUFBQSxRQUFPLE1BQU0sNEJBQTRCLENBQUMsRUFBRTtFQUM3QztBQUdBLE1BQUksa0JBQWtCLFNBQVMsYUFBYSxRQUFRO0FBQ25ELElBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsa0JBQWtCLE1BQU0sWUFBWSxhQUFhLE1BQU0sR0FBRztBQUNuSCxXQUFPLEVBQUUsVUFBVSxtQkFBbUIsbUJBQW1CLEtBQUk7RUFDOUQsV0FBVyxhQUFhLFNBQVMsR0FBRztBQUNuQyxJQUFBQSxRQUFPLEtBQUssbUNBQW1DLGFBQWEsTUFBTSxpQkFBaUIsa0JBQWtCLE1BQU0sR0FBRztBQUM5RyxXQUFPLEVBQUUsVUFBVSxjQUFjLG1CQUFtQixNQUFLO0VBQzFELE9BQU87QUFFTixJQUFBQSxRQUFPLEtBQUssdURBQXVELEtBQUssRUFBRTtBQUMxRSxXQUFPLEVBQUUsVUFBVSxDQUFBLEdBQUksbUJBQW1CLEtBQUk7RUFDL0M7QUFDRDtBQUVNLFNBQVUsNEJBQTRCLE9BQWUsS0FBVztBQUNyRSxRQUFNLEVBQUUsVUFBUyxJQUFLLGVBQWUsS0FBSztBQUMxQyxTQUFPLFlBQVksOEJBQThCLEtBQUssS0FBSyxJQUFJLHlCQUF5QixLQUFLLEtBQUs7QUFDbkc7QUFTQSxTQUFTLG1CQUFtQixZQUFvQjtBQUMvQyxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFdBQU8sRUFBRSxJQUFJLFNBQVMsT0FBTyxTQUFTLE1BQU0sVUFBVSxTQUFTLFdBQVcsQ0FBQyxFQUFDO0VBQzdFO0FBRUEsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUM1QixVQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsSUFBSTtBQUNsQixXQUFPO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxNQUFNO01BQ04sU0FBUyxlQUFlLEdBQUcsR0FBRyxDQUFDOztFQUVqQztBQUVBLFNBQU8sRUFBRSxJQUFJLFNBQVMsT0FBTyxTQUFTLE1BQU0sT0FBTyxTQUFTLENBQUMsR0FBRyxVQUFVLEVBQUM7QUFDNUU7QUFNTSxTQUFVLDRCQUNmLFdBQ0EsUUFDQSxXQUFzQztBQUV0QyxRQUFNLE1BQU0sZ0JBQWdCLFNBQVM7QUFHckMsTUFBSSxDQUFDLElBQUksV0FBVztBQUNuQixRQUFJLFlBQVksQ0FBQTtFQUNqQjtBQUdBLFFBQU0sYUFBYSxPQUFPLE9BQU8sU0FBUyxFQUN4QyxPQUFPLENBQUMsTUFBTSxFQUFFLFVBQVUsVUFBVSxLQUFLLEVBQ3pDLEtBQUssQ0FBQyxHQUFHLE1BQU0sY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLElBQUksY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLENBQUM7QUFFbEcsRUFBQUMsUUFBTyxLQUFLLG1CQUFtQixVQUFVLEtBQUssRUFBRTtBQUNoRCxFQUFBQSxRQUFPLE1BQU0sNkJBQTZCLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxJQUFJLENBQUMsRUFBRTtBQUtyRixRQUFNLG1CQUFtQixvQkFBSSxJQUFHO0FBQ2hDLGFBQVcsS0FBSyxZQUFZO0FBQzNCLGVBQVcsYUFBYSxFQUFFLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE9BQU87QUFDckUsVUFBSSxDQUFDLFVBQVU7QUFBUztBQUN4QixZQUFNLFNBQVMsVUFBVTtBQUN6QixZQUFNLFFBQVEsVUFBVTtBQUN4QixZQUFNLE1BQU0sR0FBRyxLQUFLLElBQUksTUFBTTtBQUM5QixVQUFJLGlCQUFpQixJQUFJLEdBQUc7QUFBRztBQUUvQixZQUFNLGdCQUFnQixPQUNwQixPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLEtBQUssTUFBTSxFQUNqRCxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssTUFBTSxFQUN4QixLQUFLLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUV0QixVQUFJLFNBQVM7QUFDYixpQkFBVyxPQUFPLGVBQWU7QUFDaEMsWUFBSSxRQUFRLFNBQVM7QUFBRyxtQkFBUztpQkFDeEIsTUFBTSxTQUFTO0FBQUc7TUFDNUI7QUFDQSxVQUFJLFNBQVMsR0FBRztBQUNmLHlCQUFpQixJQUFJLEtBQUssTUFBTTtBQUNoQyxRQUFBQSxRQUFPLE1BQU0sZ0NBQWdDLE1BQU0sS0FBSyxDQUFDLFlBQVksTUFBTSxNQUFNLENBQUMsb0JBQWUsTUFBTSxFQUFFO01BQzFHO0lBQ0Q7RUFDRDtBQUlBLFFBQU0sWUFBWSxvQkFBSSxJQUFHO0FBQ3pCLGFBQVcsRUFBRSxRQUFRLElBQUksTUFBSyxLQUFNLFFBQVE7QUFDM0MsUUFBSSxVQUFVO0FBQVc7QUFDekIsVUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLEVBQUU7QUFDM0IsUUFBSSxDQUFDLFVBQVUsSUFBSSxHQUFHO0FBQUcsZ0JBQVUsSUFBSSxLQUFLLG9CQUFJLElBQUcsQ0FBRTtBQUNyRCxjQUFVLElBQUksR0FBRyxFQUFHLElBQUksS0FBSztFQUM5QjtBQU1BLGFBQVcsRUFBRSxRQUFRLElBQUksT0FBTyxXQUFVLEtBQU0sUUFBUTtBQUV2RCxVQUFNLGdCQUFnQixJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDbEYsUUFBSSxlQUFlO0FBQ2xCLFlBQU0sTUFBTSxjQUFjLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDL0QsVUFBSTtBQUFLLFlBQUksVUFBVSxtQkFBbUIsVUFBVSxFQUFFO0FBQ3REO0lBQ0Q7QUFLQSxVQUFNLFlBQVksSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFLO0FBQzFDLFVBQUksRUFBRSxXQUFXO0FBQVEsZUFBTztBQUNoQyxZQUFNLFdBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3hELFVBQUksQ0FBQyxVQUFVO0FBQVMsZUFBTztBQUMvQixVQUFJLE1BQU0sRUFBRTtBQUFJLGVBQU87QUFDdkIsWUFBTSxTQUFTLEtBQUssRUFBRTtBQUV0QixhQUFPLFdBQVcsS0FBSyxDQUFDLE1BQUs7QUFDNUIsY0FBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRSxFQUFFO0FBQzlFLGNBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsZUFBTyxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07TUFDN0QsQ0FBQztJQUNGLENBQUM7QUFDRCxRQUFJLFdBQVc7QUFDZCxZQUFNLFNBQVMsS0FBSyxVQUFVO0FBQzlCLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsVUFBSSxVQUFVLFdBQVcsQ0FBQyxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU0sR0FBRztBQUM3RSxZQUFJLFFBQVEsV0FBVyxTQUFTLENBQUM7QUFDakMsbUJBQVcsS0FBSyxZQUFZO0FBQzNCLGdCQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUU7QUFDdEYsZ0JBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsZ0JBQU0sWUFBWSxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07QUFDdkUsY0FBSSxXQUFXO0FBQ2Qsb0JBQVEsVUFBVTtBQUNsQjtVQUNEO1FBQ0Q7QUFDQSxpQkFBUyxRQUFRLEtBQUssRUFBRSxJQUFJLFFBQVEsTUFBSyxDQUFFO0FBQzNDLFFBQUFBLFFBQU8sS0FDTixpQkFBaUIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyx1QkFBdUIsTUFBTSxVQUFVLEVBQUUsQ0FBQyxjQUFjLE1BQU0sTUFBTSxLQUFLLElBQUk7TUFFN0g7QUFDQTtJQUNEO0FBR0EsUUFBSTtBQUVKLGVBQVcsS0FBSyxZQUFZO0FBQzNCLFlBQU0sUUFBUSxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDekUsVUFBSSxPQUFPO0FBQ1YsaUJBQVMsZ0JBQWdCLEtBQUs7QUFFOUIsY0FBTSxXQUFXLE1BQU0sS0FBSyxRQUFRLHFDQUFxQyxFQUFFLEVBQUUsS0FBSTtBQUNqRixlQUFPLE9BQU8sR0FBRyxRQUFRLHlCQUF5QixFQUFFLEtBQUs7QUFDekQsUUFBQUEsUUFBTyxLQUFLLG1CQUFtQixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLGVBQWUsRUFBRSxLQUFLLFVBQVU7QUFDNUY7TUFDRDtJQUNEO0FBSUEsUUFBSSxDQUFDLFFBQVE7QUFDWixVQUFJLGNBQWM7QUFDbEIsaUJBQVcsS0FBSyxZQUFZO0FBQzNCLGNBQU0sWUFBWSxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQVU7QUFDOUMsY0FBSSxFQUFFLFdBQVc7QUFBUSxtQkFBTztBQUNoQyxnQkFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTztBQUM3RCxjQUFJLENBQUMsVUFBVTtBQUFTLG1CQUFPO0FBQy9CLGNBQUksTUFBTSxFQUFFO0FBQUksbUJBQU87QUFDdkIsZ0JBQU0sU0FBUyxLQUFLLEVBQUU7QUFDdEIsZ0JBQU0sU0FBUyxpQkFBaUIsSUFBSSxHQUFHLE1BQU0sSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLO0FBQzVELGlCQUFPLFVBQVU7UUFDbEIsQ0FBQztBQUNELFlBQUksV0FBVztBQUNkLHdCQUFjO0FBQ2QsVUFBQUEsUUFBTyxNQUNOLFVBQVUsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyw0Q0FBNEMsTUFBTSxVQUFVLEVBQUUsQ0FBQyw2QkFBd0I7QUFFL0g7UUFDRDtNQUNEO0FBQ0EsVUFBSTtBQUFhO0lBQ2xCO0FBR0EsUUFBSSxDQUFDLFFBQVE7QUFDWixlQUFTO1FBQ1I7UUFDQTtRQUNBLE1BQU0sZUFBZSxNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxFQUFFLFlBQVcsQ0FBRTtRQUNoRSxTQUFTLENBQUMsbUJBQW1CLFVBQVUsQ0FBQzs7QUFFekMsVUFBSSxVQUFVO0FBQVcsZUFBTyxRQUFRO0FBQ3hDLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxFQUFFO0lBQ3RFLE9BQU87QUFJTixhQUFPLFVBQVUsT0FBTyxTQUFTLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEtBQUssQ0FBQTtBQUNwRSxhQUFPLE9BQU87QUFFZCxZQUFNLGtCQUFrQixVQUFVLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxFQUFFO0FBQ3ZELFVBQUksbUJBQW1CLGdCQUFnQixPQUFPLEdBQUc7QUFDaEQsY0FBTSxXQUFXLEtBQUssSUFBSSxHQUFHLGVBQWU7QUFDNUMsWUFBSSxhQUFhLEdBQUc7QUFFbkIsaUJBQU8sUUFBUTtRQUNoQixPQUFPO0FBRU4sZ0JBQU0sZUFBZSxNQUFNLEtBQUssRUFBRSxRQUFRLFdBQVcsRUFBQyxHQUFJLENBQUMsR0FBRyxPQUFPO1lBQ3BFLElBQUk7WUFDSixPQUFPLFdBQVcsSUFBSSxDQUFDO1lBQ3RCO0FBQ0YsaUJBQU8sUUFBUSxRQUFRO1lBQ3RCLElBQUk7WUFDSixPQUFPO1lBQ1AsTUFBTTtZQUNOLFNBQVM7WUFDVCxTQUFTO1dBQ0Y7UUFDVDtNQUNEO0FBTUEsWUFBTSxrQkFBa0IsbUJBQW1CLFVBQVUsRUFBRTtBQUN2RCxZQUFNLFdBQVcsT0FBTyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQzdELFVBQUksVUFBVTtBQUNiLFlBQUksU0FBUyxXQUFXLE1BQU0sUUFBUSxTQUFTLE9BQU8sR0FBRztBQUN4RCxnQkFBTSxZQUFZLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sZUFBZTtBQUM1RSxjQUFJLENBQUMsV0FBVztBQUNmLFlBQUFBLFFBQU8sS0FDTiwrQkFBK0IsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxpQ0FBaUMsZUFBZSxzQ0FBaUM7QUFHOUkscUJBQVMsT0FBTztBQUNoQixtQkFBUSxTQUFpQjtVQUMxQjtRQUNEO0FBQ0EsaUJBQVMsVUFBVTtNQUNwQjtJQUNEO0FBRUEsUUFBSSxVQUFVLEtBQUssTUFBTTtFQUMxQjtBQVNBLGFBQVcsRUFBRSxRQUFRLEdBQUUsS0FBTSxRQUFRO0FBQ3BDLFVBQU0sa0JBQWtCLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUNwRixRQUFJO0FBQWlCO0FBR3JCLFVBQU0sWUFBWSxJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQUs7QUFDMUMsVUFBSSxFQUFFLFdBQVc7QUFBUSxlQUFPO0FBQ2hDLFlBQU1DLFlBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3hELGFBQU8sQ0FBQyxDQUFDQSxXQUFVLFdBQVcsS0FBSyxFQUFFO0lBQ3RDLENBQUM7QUFDRCxRQUFJLENBQUM7QUFBVztBQUVoQixVQUFNLFNBQVMsS0FBSyxVQUFVO0FBQzlCLFVBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsUUFBSSxDQUFDLFVBQVUsV0FBVyxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU07QUFBRztBQUk5RSxVQUFNLGVBQWUsV0FBVyxLQUFLLENBQUMsTUFBSztBQUMxQyxZQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUU7QUFDdEYsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxhQUFPLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtJQUM3RCxDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsU0FBUyxRQUFRLElBQUksQ0FBQyxNQUFXLEVBQUUsRUFBWSxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBQzdGLFVBQU0sZUFBZSxnQkFBZ0IsU0FBUyxLQUFLLFdBQVcsZ0JBQWdCLGdCQUFnQixTQUFTLENBQUMsSUFBSTtBQUU1RyxRQUFJLENBQUMsZ0JBQWdCLENBQUM7QUFBYztBQUdwQyxRQUFJLFFBQVEsV0FBVyxTQUFTLENBQUM7QUFDakMsZUFBVyxLQUFLLFlBQVk7QUFDM0IsWUFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsWUFBTSxZQUFZLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtBQUN2RSxVQUFJLFdBQVc7QUFDZCxnQkFBUSxVQUFVO0FBQ2xCO01BQ0Q7SUFDRDtBQUVBLGFBQVMsUUFBUSxLQUFLLEVBQUUsSUFBSSxRQUFRLE1BQUssQ0FBRTtBQUMzQyxJQUFBRCxRQUFPLEtBQ04seUJBQXlCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsdUJBQXVCLE1BQU0sVUFBVSxFQUFFLENBQUMsY0FBYyxNQUFNLE1BQU0sS0FBSyxJQUFJO0VBRXJJO0FBRUEsU0FBTztBQUNSO0FBTU0sU0FBVSxvQkFBb0IsVUFBa0IsU0FBb0I7QUFDekUsTUFBSTtBQUVILFVBQU0sYUFBa0IsRUFBRSxPQUFPLFFBQVEsTUFBSztBQUc5QyxRQUFJLGVBQWUsU0FBUztBQUMzQixpQkFBVyxZQUFZLFFBQVE7SUFDaEM7QUFHQSxRQUFJLHlCQUF5QixTQUFTO0FBQ3JDLGlCQUFXLHNCQUFzQixRQUFRO0lBQzFDO0FBQ0EsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRLFVBQVUsSUFBSSxDQUFDLFVBQWM7QUFFM0QsY0FBTSxlQUFvQixDQUFBO0FBQzFCLFlBQUksWUFBWTtBQUFPLHVCQUFhLFNBQVMsTUFBTTtBQUNuRCxZQUFJLFFBQVE7QUFBTyx1QkFBYSxLQUFLLE1BQU07QUFDM0MsWUFBSSxXQUFXO0FBQU8sdUJBQWEsUUFBUSxNQUFNO0FBQ2pELFlBQUksVUFBVTtBQUFPLHVCQUFhLE9BQU8sTUFBTTtBQUMvQyxZQUFJLGFBQWE7QUFBTyx1QkFBYSxVQUFVLE1BQU07QUFFckQsbUJBQVcsT0FBTyxPQUFPLEtBQUssS0FBSyxHQUFHO0FBQ3JDLGNBQUksRUFBRSxPQUFPO0FBQWUseUJBQWEsR0FBRyxJQUFJLE1BQU0sR0FBRztRQUMxRDtBQUNBLGVBQU87TUFDUixDQUFDO0lBQ0Y7QUFFQSxlQUFXLE9BQU8sT0FBTyxLQUFLLE9BQU8sR0FBRztBQUN2QyxVQUFJLEVBQUUsT0FBTyxhQUFhO0FBQ3pCLG1CQUFXLEdBQUcsSUFBSyxRQUFnQixHQUFHO01BQ3ZDO0lBQ0Q7QUFHQSxRQUFJLE9BQU8sS0FBSyxVQUFVLFlBQVksTUFBTSxDQUFDO0FBSzdDLFdBQU8sS0FBSyxRQUFRLDBEQUEwRCw2QkFBNkI7QUFFM0csSUFBQUUsSUFBRyxjQUFjLFVBQVUsT0FBTyxNQUFNLE1BQU07RUFDL0MsU0FBUyxHQUFHO0FBQ1gsSUFBQUYsUUFBTyxNQUFNLHFCQUFxQixDQUFDLEVBQUU7RUFDdEM7QUFDRDs7O0FEbnhCQSxJQUFNRyxVQUFTLG1CQUFtQixTQUFTO0FBRXJDLFNBQVUsY0FBYyxNQUFvQjtBQUNqRCxRQUFNLGFBQWEsaUJBQWdCO0FBQ25DLFFBQU0sYUFBYSxhQUFZO0FBQy9CLFFBQU0sVUFBVSxxQkFBcUIsVUFBVTtBQUMvQyxRQUFNLGVBQW9CLENBQUE7QUFFMUIsUUFBTSxjQUFjLEtBQUs7QUFNekIsZUFBYSx1QkFBdUIsSUFBSTtJQUN2QyxNQUFNO0lBQ04sU0FBUyxDQUFBO0lBQ1QsVUFBVSxZQUFXO0FBQ3BCLFlBQU0sUUFBUTtBQUNkLFlBQU0sS0FBSyxLQUFLO0FBRWhCLFlBQU0sTUFBTSxNQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUd6RCxVQUFJLFlBQVksZ0JBQWdCLEtBQUs7QUFHckMsWUFBTSxFQUFFLFVBQVUsUUFBUSxrQkFBaUIsSUFBSyxpQ0FBaUMsT0FBTyxHQUFHO0FBQzNGLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSyxVQUFVLE1BQU0sQ0FBQyxFQUFFO0FBRXRELFVBQUksQ0FBQyxXQUFXO0FBRWYsUUFBQUEsUUFBTyxLQUFLLFNBQVMsS0FBSyx1REFBa0Q7QUFDNUUsb0JBQVk7VUFDWDtVQUNBLFdBQVcscUJBQXFCO1VBQ2hDLHFCQUFxQjtVQUNyQixXQUFXLENBQUE7O01BRWIsV0FBVyxzQkFBc0IsTUFBTTtBQUV0QyxRQUFBQSxRQUFPLEtBQUssMkJBQTJCLGlCQUFpQix3QkFBd0I7QUFDaEYsb0JBQVksRUFBRSxHQUFHLFdBQVcsV0FBVyxrQkFBaUI7TUFDekQ7QUFFQSxZQUFNLFVBQVUsNEJBQTRCLFdBQVcsUUFBUSxPQUFPO0FBQ3RFLE1BQUFBLFFBQU8sTUFBTSxxQkFBcUIsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLENBQUMsRUFBRTtBQUdwRSxZQUFNQyxpQkFBZ0IsaUJBQWdCO0FBQ3RDLFlBQU0sYUFBYUMsTUFBSyxLQUFLRCxnQkFBZSxRQUFRLEtBQUssT0FBTztBQUNoRSwwQkFBb0IsWUFBWSxPQUFPO0FBR3ZDLDBCQUFtQjtBQUVuQixNQUFBRCxRQUFPLEtBQUssU0FBUyxLQUFLLHdDQUF3QztJQUNuRTs7QUFPRCxhQUFXLENBQUMsVUFBVSxNQUFNLEtBQUssT0FBTyxRQUFRLFVBQVUsR0FBRztBQUM1RCxVQUFNLEVBQUUsT0FBTyxPQUFPLE9BQU0sSUFBSyxlQUFlLFFBQVE7QUFHeEQsUUFBSSxVQUFVO0FBQWE7QUFHM0IsVUFBTSxTQUFTLFFBQVEsS0FBSztBQUM1QixVQUFNLFlBQVksUUFBUSxXQUFXLEtBQUssQ0FBQyxNQUFXLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxNQUFNO0FBRTNGLGlCQUFhLFFBQVEsSUFBSTtNQUN4QixHQUFHO01BQ0gsVUFBVSxPQUFPLFVBQWM7QUFDOUIsY0FBTSxLQUFLLEtBQUs7QUFDaEIsY0FBTSxRQUFRLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBWSxNQUFNLFFBQVEsT0FBTyxJQUFJLFdBQVc7QUFDekYsY0FBTSxRQUFRLE1BQU0sUUFBUSxPQUFPO0FBQ25DLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxLQUFLO0FBQ3hDLGNBQU0sWUFBWSxTQUFTO0FBRTNCLGNBQU0sS0FBSyxhQUFhLGFBQWEsT0FBTyxPQUFPLFdBQVcsT0FBTyxFQUFFO01BQ3hFOztFQUVGO0FBS0EsUUFBTSxlQUFlLFFBQVEsV0FBVztBQUN4QyxNQUFJLGNBQWM7QUFDakIsVUFBTSxtQkFBbUIsYUFBYSxhQUFhLENBQUEsR0FBSSxLQUFLLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxNQUFNLENBQUM7QUFFL0YsUUFBSSxpQkFBaUI7QUFDcEIsWUFBTSxXQUFXLEdBQUcsV0FBVztBQUUvQixtQkFBYSxRQUFRLElBQUk7UUFDeEIsTUFBTSxTQUFTLFdBQVc7UUFDMUIsU0FBUyxDQUFBO1FBQ1QsVUFBVSxZQUFXO0FBQ3BCLGdCQUFNLEtBQUssS0FBSztBQUNoQixVQUFBQSxRQUFPLEtBQUsseUJBQW9CLFdBQVcsTUFBTSxFQUFFLEVBQUU7QUFDckQsZ0JBQU0sS0FBSyxhQUFhLGNBQWMsRUFBRTtBQUN4QyxnQkFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUUsRUFBRSxNQUFNLENBQUMsUUFBTztBQUM1RCxZQUFBQSxRQUFPLEtBQUssNkNBQTZDLEdBQUcsRUFBRTtVQUMvRCxDQUFDO1FBQ0Y7O0lBRUY7RUFDRDtBQUVBLE9BQUsscUJBQXFCLFlBQVk7QUFHdkM7OztBRXJIQSxTQUFTLGlCQUNSLFNBQ0EsT0FDQSxPQUNBLFdBQ0EsT0FBYTtBQUViLFFBQU0sVUFBVSxxQkFBcUIsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUNyRSxNQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sUUFBUSxRQUFRLE9BQU87QUFBRyxXQUFPO0FBR3hELFFBQU0sY0FBYyxRQUFRLFFBQVEsS0FBSyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFDekUsTUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLFFBQVEsWUFBWSxPQUFPO0FBQUcsV0FBTztBQUdoRSxRQUFNLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxLQUFLO0FBQ2xFLFNBQU8sUUFBUSxTQUFTO0FBQ3pCO0FBTU0sU0FBVSxnQkFBZ0IsTUFBb0I7QUFDbkQsUUFBTSxhQUFhLGlCQUFnQjtBQUNuQyxRQUFNLGVBQWUsZUFBYztBQUNuQyxRQUFNLFVBQVUscUJBQXFCLFVBQVU7QUFDL0MsUUFBTSxpQkFBc0IsQ0FBQTtBQUc1QixRQUFNLGNBQWMsS0FBSztBQU16QixhQUFXLENBQUMsWUFBWSxRQUFRLEtBQUssT0FBTyxRQUFRLFlBQVksR0FBRztBQUNsRSxVQUFNLEVBQUUsT0FBTyxPQUFPLE9BQU0sSUFBSyxlQUFlLFVBQVU7QUFHMUQsUUFBSSxVQUFVO0FBQWE7QUFHM0IsbUJBQWUsVUFBVSxJQUFJO01BQzVCLEdBQUc7TUFDSCxVQUFVLENBQUMsa0JBQXNCO0FBQ2hDLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxjQUFjLFFBQVEsT0FBTyxLQUFLO0FBQ2hELGNBQU0sWUFBWSxTQUFTO0FBRzNCLFlBQUksUUFBUSxjQUFjLFFBQVEsT0FBTztBQUN6QyxZQUFJLFVBQVUsUUFBVztBQUN4QixnQkFBTSxlQUFlLHFCQUFxQixTQUFTLE9BQU8sT0FBTyxTQUFTO0FBQzFFLGNBQUksY0FBYyxVQUFVLFFBQVc7QUFDdEMsb0JBQVEsYUFBYTtVQUN0QjtRQUNEO0FBRUEsY0FBTSxVQUFVLEtBQUssYUFBYSxnQkFBZ0IsSUFBSSxPQUFPLFdBQVcsS0FBSztBQUc3RSxjQUFNLFlBQVksY0FBYyxRQUFRLFdBQVcsS0FBSztBQUV4RCxZQUFJLGFBQWEsWUFBWSxRQUFXO0FBRXZDLGlCQUFPLGlCQUFpQixTQUFTLE9BQU8sT0FBTyxXQUFXLE9BQU87UUFDbEU7QUFHQSxlQUFPLFdBQVc7TUFDbkI7O0VBRUY7QUFFQSxPQUFLLHVCQUF1QixjQUFjO0FBRzNDOzs7QUN0RkEsT0FBT0csWUFBVzs7O0FDQWxCLE9BQU8sV0FBVztBQUNsQixPQUFPLFFBQVE7QUFJZixJQUFNQyxVQUFTLG1CQUFtQixPQUFPO0FBS2xDLElBQU0seUJBQXlCO0FBRS9CLElBQU0sMEJBQTBCO0FBZ0JoQyxJQUFNLHFCQUFxQixNQUFPO0FBaUJuQyxTQUFVLHdCQUFxQjtBQUNwQyxRQUFNLE1BQU0sT0FBTyxNQUFNLElBQUksQ0FBQztBQUM5QixRQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTSxJQUFLLEtBQU07QUFFN0MsTUFBSSxjQUFjLE9BQVEsQ0FBQztBQUMzQixNQUFJLGNBQWMsd0JBQXdCLENBQUM7QUFDM0MsTUFBSSxjQUFjLEtBQUssQ0FBQztBQUV4QixRQUFNLE1BQU0saUJBQWdCO0FBQzVCLE1BQUksS0FBSyxLQUFLLENBQUM7QUFFZixTQUFPLEtBQUssWUFBWSxPQUFPLEVBQUUsS0FBSyxLQUFLLEVBQUU7QUFDN0MsTUFBSSxjQUFjLE1BQVEsRUFBRTtBQUM1QixNQUFJLGNBQWMsS0FBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFZLEVBQUU7QUFFaEMsU0FBTztBQUNSO0FBR00sU0FBVSxtQkFBZ0I7QUFDL0IsTUFBSTtBQUNILFVBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxlQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxpQkFBVyxRQUFRLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN0QyxZQUFJLENBQUMsS0FBSyxZQUFZLEtBQUssV0FBVyxVQUFVLEtBQUssT0FBTyxLQUFLLFFBQVEscUJBQXFCO0FBQzdGLGlCQUFPLE9BQU8sS0FBSyxLQUFLLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQWMsU0FBUyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQzNFO01BQ0Q7SUFDRDtFQUNELFFBQVE7RUFFUjtBQUNBLFNBQU8sT0FBTyxNQUFNLEdBQUcsQ0FBQztBQUN6QjtBQWlCTSxTQUFVLHVCQUF1QixLQUFhLE9BQWE7QUFDaEUsTUFBSSxJQUFJLFNBQVM7QUFBb0IsV0FBTztBQUM1QyxNQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBUSxXQUFPO0FBQzNDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUF5QixXQUFPO0FBQzVELE1BQUksSUFBSSxTQUFTLElBQUksRUFBRSxFQUFFLFNBQVMsT0FBTyxNQUFNO0FBQVksV0FBTztBQUVsRSxRQUFNLFVBQVUsQ0FBQyxRQUFnQixRQUNoQyxJQUNFLFNBQVMsUUFBUSxTQUFTLEdBQUcsRUFDN0IsU0FBUyxPQUFPLEVBQ2hCLE1BQU0sSUFBSSxFQUFFLENBQUMsRUFDYixLQUFJO0FBRVAsUUFBTSxRQUFRLElBQUksU0FBUyxHQUFHLEVBQUU7QUFDaEMsUUFBTSxXQUFXLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDNUUsUUFBTSxNQUFNLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHO0FBRXpFLFFBQU0sT0FBTyxRQUFRLElBQU0sRUFBRTtBQUM3QixRQUFNLGVBQWUsUUFBUSxJQUFNLEVBQUU7QUFDckMsUUFBTSxXQUFXLFFBQVEsS0FBTSxFQUFFO0FBQ2pDLFFBQU0sZ0JBQWdCLEdBQUcsSUFBSSxFQUFJLENBQUMsSUFBSSxJQUFJLEVBQUksQ0FBQztBQUUvQyxNQUFJLENBQUM7QUFBVSxXQUFPO0FBSXRCLFFBQU0sUUFBUSxTQUNaLFFBQVEsY0FBYyxFQUFFLEVBQ3hCLEtBQUksRUFDSixNQUFNLEtBQUssRUFBRSxDQUFDO0FBRWhCLFNBQU87SUFDTixJQUFJO0lBQ0o7SUFDQTtJQUNBO0lBQ0EsV0FBVzs7SUFDWDtJQUNBOztBQUVGO0FBT0EsZUFBc0IscUJBQXFCLFFBQWM7QUFDeEQsU0FBTyxJQUFJLFFBQWtCLENBQUMsU0FBUyxXQUFVO0FBQ2hELFVBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUVyQyxRQUFJLEtBQUssU0FBUyxDQUFDLFFBQU87QUFDekIsVUFBSSxNQUFLO0FBQ1QsYUFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7SUFDN0MsQ0FBQztBQUVELFFBQUksUUFBUSxHQUFHLFFBQVEsTUFBSztBQUMzQixVQUFJO0FBQ0gsY0FBTSxPQUFPLElBQUksUUFBTztBQUN4QixjQUFNLFlBQVksS0FBSztBQUN2QixZQUFJLE1BQUs7QUFFVCxjQUFNLFNBQVMsR0FBRyxrQkFBaUI7QUFDbkMsbUJBQVcsUUFBUSxPQUFPLEtBQUssTUFBTSxHQUFHO0FBQ3ZDLHFCQUFXLFNBQVMsT0FBTyxJQUFJLEtBQUssQ0FBQSxHQUFJO0FBQ3ZDLGdCQUNDLE1BQU0sV0FBVyxVQUNqQixNQUFNLFlBQVksYUFDbEIsTUFBTSxPQUNOLE1BQU0sUUFBUSxxQkFDYjtBQUNELHFCQUFPLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLFNBQVMsR0FBRyxFQUFFLElBQUksR0FBSSxDQUFDO1lBQ3ZFO1VBQ0Q7UUFDRDtBQUNBLGVBQU8sSUFBSSxNQUFNLHdDQUF3QyxTQUFTLEVBQUUsQ0FBQztNQUN0RSxTQUFTLElBQUk7QUFDWixlQUFPLElBQUksTUFBTSxPQUFPLEVBQUUsQ0FBQyxDQUFDO01BQzdCO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQU1BLGVBQXNCLDhCQUE4QixRQUFjO0FBQ2pFLFNBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxVQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFFckMsUUFBSSxXQUFXO0FBQ2YsUUFBSSxLQUFLLFNBQVMsQ0FBQyxRQUFPO0FBQ3pCLFVBQUksQ0FBQyxVQUFVO0FBQ2QsbUJBQVc7QUFDWCxZQUFJLE1BQUs7QUFDVCxlQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztNQUM3QztJQUNELENBQUM7QUFHRCxRQUFJLFFBQVEsR0FBRyxRQUFRLE1BQUs7QUFDM0IsVUFBSTtBQUNILGNBQU0sT0FBTyxJQUFJLFFBQU87QUFDeEIsY0FBTSxZQUFZLEtBQUs7QUFDdkIsWUFBSSxDQUFDLFVBQVU7QUFDZCxxQkFBVztBQUNYLGNBQUksTUFBSztBQUNULGtCQUFRLFNBQVM7UUFDbEI7TUFDRCxTQUFTLElBQUk7QUFDWixZQUFJLENBQUMsVUFBVTtBQUNkLHFCQUFXO0FBQ1gsY0FBSSxNQUFLO0FBQ1QsaUJBQU8sSUFBSSxNQUFNLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDN0I7TUFDRDtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7QUFXQSxlQUFzQixnQkFDckIsVUFDQSxrQkFDQSxZQUFZLEtBQUk7QUFFaEIsUUFBTSx1QkFBdUI7QUFDN0IsUUFBTSxzQkFBc0I7QUFDNUIsUUFBTSxlQUFlO0FBRXJCLFFBQU0sYUFBYSxvQkFBSSxJQUFHO0FBRTFCLFNBQU8sSUFBSSxRQUFjLENBQUMsWUFBVztBQUNwQyxVQUFNLGlCQUFpQixNQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFM0UsVUFBTSxVQUFVLE1BQUs7QUFDcEIsVUFBSTtBQUNILHVCQUFlLGVBQWUsb0JBQW9CO01BQ25ELFFBQVE7TUFFUjtBQUNBLFVBQUk7QUFDSCx1QkFBZSxNQUFLO01BQ3JCLFFBQVE7TUFFUjtBQUNBLGNBQU87SUFDUjtBQUVBLFVBQU0sUUFBUSxXQUFXLFNBQVMsU0FBUztBQUMzQyxVQUFNLFFBQU87QUFFYixtQkFBZSxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2xDLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsSUFBSSxPQUFPLEVBQUU7SUFDcEQsQ0FBQztBQUVELG1CQUFlLEdBQUcsV0FBVyxDQUFDLEtBQUssVUFBUztBQUMzQyxZQUFNLFFBQVEsTUFBTTtBQUVwQixVQUFJLElBQUksU0FBUztBQUFJO0FBQ3JCLFVBQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRO0FBQ3BDLFVBQUksSUFBSSxTQUFTLElBQUksRUFBRSxFQUFFLFNBQVMsT0FBTyxNQUFNO0FBQVk7QUFFM0QsVUFBSSxXQUFXLElBQUksS0FBSztBQUFHO0FBQzNCLGlCQUFXLElBQUksS0FBSztBQUNwQixNQUFBQSxRQUFPLE1BQU0saUJBQWlCLEtBQUssK0JBQTBCO0FBSzdELFlBQU0sWUFBWSxZQUFXO0FBQzVCLGNBQU0saUJBQWlCLEtBQUs7QUFDNUIsY0FBTSxRQUFRLHNCQUFxQjtBQUNuQyxpQkFBUyxLQUFLLE9BQU8sY0FBYyxPQUFPLENBQUMsUUFBTztBQUNqRCxjQUFJO0FBQUssWUFBQUEsUUFBTyxLQUFLLG9CQUFvQixLQUFLLFlBQVksSUFBSSxPQUFPLEVBQUU7UUFDeEUsQ0FBQztNQUNGO0FBQ0EsZ0JBQVMsRUFBRyxNQUFNLENBQUMsUUFBUUEsUUFBTyxLQUFLLHVCQUF1QixHQUFHLEVBQUUsQ0FBQztJQUNyRSxDQUFDO0FBRUQsbUJBQWUsS0FBSyxxQkFBcUIsTUFBSztBQUM3QyxVQUFJO0FBQ0gsdUJBQWUsY0FBYyxvQkFBb0I7QUFDakQsUUFBQUEsUUFBTyxLQUFLLG9DQUFvQyxvQkFBb0IsSUFBSSxtQkFBbUIsRUFBRTtNQUM5RixTQUFTLEtBQUs7QUFDYixRQUFBQSxRQUFPLEtBQUssNENBQTRDLEdBQUcsRUFBRTtNQUM5RDtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7OztBRG5RQSxJQUFNQyxVQUFTLG1CQUFtQixjQUFjO0FBRTFDLElBQU8sZUFBUCxNQUFPLGNBQVk7RUFDUCxjQUFzQjtFQUN0QixpQkFBaUI7RUFDakIsU0FBUztFQUVsQjtFQUNBOztFQUNBLGNBR0osb0JBQUksSUFBRztFQUNILG1CQUFnQyxvQkFBSSxJQUFHOzs7RUFHdkMsWUFBMkIsUUFBUSxRQUFPOztFQUcxQyxzQkFBc0I7O0VBR3RCOztFQUdBLFFBQWdCO0VBQ2hCLFVBQXNCLENBQUE7RUFDdEIsc0JBQStCOzs7Ozs7OztFQVEvQixjQUFnRCxvQkFBSSxJQUFHOzs7Ozs7O0VBUXZELGdCQUE2QixvQkFBSSxJQUFHOztFQUdwQyxxQkFBZ0Usb0JBQUksSUFBRzs7RUFHdkU7O0VBR0EsV0FBa0Msb0JBQUksSUFBRztFQUVqRCxjQUFBO0FBQ0MsSUFBQUEsUUFBTyxLQUFLLDBCQUEwQjtBQUl0QyxTQUFLLFdBQVdDLE9BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUNwRSxTQUFLLFVBQVUsSUFBSSxRQUFjLENBQUMsWUFBVztBQUM1QyxXQUFLLFNBQVMsS0FBSyxHQUFHLE1BQUs7QUFDMUIsUUFBQUQsUUFBTyxNQUFNLDJCQUE0QixLQUFLLFNBQVMsUUFBTyxFQUF3QixJQUFJLEVBQUU7QUFDNUYsZ0JBQU87TUFDUixDQUFDO0lBQ0YsQ0FBQztBQUNELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFHRCxTQUFLLFdBQVdDLE9BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUVwRSxTQUFLLFNBQVMsR0FBRyxhQUFhLE1BQUs7QUFDbEMsWUFBTSxPQUFPLEtBQUssU0FBUyxRQUFPO0FBQ2xDLE1BQUFELFFBQU8sTUFBTSwwQkFBMEIsS0FBSyxVQUFVLElBQUksQ0FBQyxFQUFFO0FBQzdELFVBQUk7QUFDSCxhQUFLLFNBQVMscUJBQXFCLElBQUk7TUFDeEMsU0FBUyxJQUFJO01BRWI7SUFDRCxDQUFDO0FBRUQsU0FBSyxTQUFTLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDakMsTUFBQUEsUUFBTyxNQUFNLG9CQUFvQixHQUFHLEVBQUU7SUFDdkMsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFdBQVcsQ0FBQyxLQUFLLFVBQVM7QUFDMUMsVUFBSTtBQUNILGFBQUssZUFBZSxLQUFLLE1BQU0sT0FBTztNQUN2QyxTQUFTLElBQUk7QUFDWixRQUFBQSxRQUFPLE1BQU0sb0NBQW9DLEVBQUUsRUFBRTtNQUN0RDtJQUNELENBQUM7QUFHRCxTQUFLLFNBQVMsS0FBSyxFQUFFLFNBQVMsV0FBVyxNQUFNLEtBQUssT0FBTSxHQUFJLE1BQUs7QUFDbEUsTUFBQUEsUUFBTyxNQUFNLDhCQUE4QixLQUFLLE1BQU0sRUFBRTtJQUN6RCxDQUFDO0VBQ0Y7RUFFTyxRQUFLO0FBQ1gsUUFBSTtBQUNILGlCQUFXLGFBQWEsTUFBTSxLQUFLLEtBQUssZ0JBQWdCLEdBQUc7QUFDMUQsWUFBSTtBQUNILGVBQUssU0FBUyxlQUFlLEtBQUssZ0JBQWdCLFNBQVM7UUFDNUQsUUFBUTtRQUVSO01BQ0Q7SUFDRCxRQUFRO0lBRVI7QUFDQSxRQUFJO0FBQ0gsV0FBSyxTQUFTLE1BQUs7SUFDcEIsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtFQUNEOzs7OztFQU1PLFNBQVMsT0FBZSxTQUFxQixzQkFBK0IsTUFBSTtBQUN0RixTQUFLLFFBQVE7QUFDYixTQUFLLFVBQVU7QUFDZixTQUFLLHNCQUFzQjtFQUM1Qjs7Ozs7RUFNTyxvQkFBb0IsVUFBc0M7QUFDaEUsU0FBSyxtQkFBbUI7RUFDekI7O0VBR08sbUJBQW1CLElBQVU7QUFDbkMsV0FBTyxLQUFLLGNBQWMsSUFBSSxFQUFFO0VBQ2pDOztFQUdPLGdCQUFnQixJQUFVO0FBQ2hDLFNBQUssY0FBYyxJQUFJLEVBQUU7QUFDekIsSUFBQUEsUUFBTyxNQUFNLHdCQUF3QixFQUFFLEVBQUU7RUFDMUM7O0VBR08sYUFBYSxJQUFVO0FBQzdCLFNBQUssY0FBYyxPQUFPLEVBQUU7QUFDNUIsU0FBSyxZQUFZLE9BQU8sRUFBRTtBQUMxQixTQUFLLFNBQVMsT0FBTyxFQUFFO0FBQ3ZCLElBQUFBLFFBQU8sTUFBTSxxQkFBcUIsRUFBRSxFQUFFO0VBQ3ZDOzs7Ozs7O0VBUU8sTUFBTSxZQUFZLElBQVksWUFBWSxLQUFJO0FBQ3BELFdBQU8sSUFBSSxRQUEyQixDQUFDLFlBQVc7QUFDakQsWUFBTSxNQUFNLFdBQVcsRUFBRTtBQUN6QixVQUFJLFdBQVc7QUFFZixZQUFNLFNBQVMsQ0FBQyxXQUE2QjtBQUM1QyxZQUFJO0FBQVU7QUFDZCxtQkFBVztBQUNYLGFBQUssbUJBQW1CLE9BQU8sR0FBRztBQUNsQyxnQkFBUSxNQUFNO01BQ2Y7QUFFQSxXQUFLLG1CQUFtQixJQUFJLEtBQUssQ0FBQyxXQUFzQjtBQUN2RCxZQUFJLE9BQU8sT0FBTztBQUFJLGlCQUFPLE1BQU07TUFDcEMsQ0FBQztBQUVELFlBQU0sUUFBUSxXQUFXLE1BQU0sT0FBTyxJQUFJLEdBQUcsU0FBUztBQUN0RCxZQUFNLFFBQU87QUFFYixZQUFNLE1BQU0sWUFBVztBQUN0QixjQUFNLEtBQUssb0JBQW9CLEVBQUU7QUFDakMsY0FBTSxLQUFLO0FBQ1gsY0FBTSxRQUFRLHNCQUFxQjtBQUNuQyxhQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssYUFBYSxJQUFJLENBQUMsUUFBTztBQUN2RCxjQUFJLEtBQUs7QUFDUixZQUFBQSxRQUFPLEtBQUssWUFBWSxFQUFFLFlBQVksSUFBSSxPQUFPLEVBQUU7QUFDbkQseUJBQWEsS0FBSztBQUNsQixtQkFBTyxJQUFJO1VBQ1o7UUFDRCxDQUFDO01BQ0Y7QUFFQSxVQUFHLEVBQUcsTUFBTSxDQUFDLE1BQUs7QUFDakIsUUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxFQUFFO0FBQ3RELHFCQUFhLEtBQUs7QUFDbEIsZUFBTyxJQUFJO01BQ1osQ0FBQztJQUNGLENBQUM7RUFDRjs7Ozs7RUFNTyxNQUFNLG1CQUFtQixVQUFnQjtBQUMvQyxJQUFBQSxRQUFPLEtBQUssZ0NBQWdDLFFBQVEsRUFBRTtBQUN0RCxVQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsc0JBQXNCLFFBQVcsUUFBVyxRQUFXLFVBQVUsS0FBSztBQUUvRyxXQUFPO0VBQ1I7Ozs7Ozs7Ozs7O0VBWU8sTUFBTSxnQkFBZ0IsWUFBWSxLQUFJO0FBRTVDLFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sZUFBNkIsQ0FBQTtBQUVuQyxVQUFNLGdCQUFnQixDQUFDLFdBQXNCO0FBQzVDLFVBQUksQ0FBQyxhQUFhLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEVBQUUsR0FBRztBQUNsRCxxQkFBYSxLQUFLLE1BQU07TUFDekI7SUFDRDtBQUdBLFNBQUssbUJBQW1CLElBQUksZUFBZSxhQUFhO0FBRXhELFFBQUk7QUFDSCxZQUFNLEtBQUs7QUFHWCxZQUFNLGdCQUFnQixLQUFLLFVBQVUsT0FBTyxXQUFXLEtBQUssb0JBQW9CLE1BQU0sR0FBRyxTQUFTO0FBQ2xHLGFBQU87SUFDUjtBQUNDLFdBQUssbUJBQW1CLE9BQU8sYUFBYTtJQUM3QztFQUNEOzs7OztFQU1PLE1BQU0sdUJBQXVCLFVBQWdCO0FBQ25ELElBQUFBLFFBQU8sS0FBSyxvQ0FBb0MsUUFBUSxFQUFFO0FBQzFELFVBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSxrQkFBa0IsUUFBVyxRQUFXLFFBQVcsVUFBVSxLQUFLO0FBSTNHLFVBQU0sWUFBWTtBQUVsQixRQUFJLFNBQVMsU0FBUyxZQUFZLEdBQUc7QUFDcEMsTUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxTQUFTLE1BQU0sUUFBUTtBQUNuRSxhQUFPO0lBQ1I7QUFHQSxVQUFNLFFBQVEsU0FBUyxZQUFZLENBQUM7QUFDcEMsVUFBTSxRQUFRLFNBQVMsWUFBWSxDQUFDO0FBRXBDLFVBQU0sV0FDTCxRQUFRLEtBQ0wsTUFBTSxTQUFRLEVBQUcsU0FBUyxHQUFHLEdBQUcsSUFDaEMsTUFBTSxTQUFRO0FBRWxCLFVBQU0sV0FBVyxHQUFHLEtBQUssSUFBSSxRQUFRO0FBRXJDLElBQUFBLFFBQU8sS0FBSyxxQkFBcUIsUUFBUSxFQUFFO0FBQzNDLFdBQU87RUFDUjs7Ozs7RUFNUSxNQUFNLG9CQUFvQixRQUFjO0FBQy9DLFFBQUk7QUFDSCxZQUFNLFlBQVksTUFBTSw4QkFBOEIsTUFBTTtBQUM1RCxVQUFJLENBQUMsV0FBVztBQUNmLFFBQUFBLFFBQU8sS0FBSyxxREFBcUQsTUFBTSxFQUFFO0FBQ3pFO01BQ0Q7QUFFQSxVQUFJLEtBQUssaUJBQWlCLElBQUksU0FBUyxHQUFHO0FBRXpDO01BQ0Q7QUFFQSxVQUFJO0FBQ0gsYUFBSyxTQUFTLGNBQWMsS0FBSyxnQkFBZ0IsU0FBUztBQUMxRCxhQUFLLGlCQUFpQixJQUFJLFNBQVM7QUFDbkMsUUFBQUEsUUFBTyxLQUFLLG9CQUFvQixLQUFLLGNBQWMsT0FBTyxTQUFTLEVBQUU7TUFDdEUsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxLQUFLLCtCQUErQixTQUFTLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRTtNQUN0RTtJQUNELFNBQVMsSUFBSTtBQUNaLE1BQUFBLFFBQU8sS0FBSywrQkFBK0IsRUFBRSxFQUFFO0lBQ2hEO0VBQ0Q7RUFFTyxNQUFNLGFBQ1osT0FDQSxPQUNBLFdBQ0EsT0FDQSxRQUNBLFNBQVMsTUFBSTtBQUViLFNBQUs7QUFDTCxXQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsV0FBSyxZQUFZLEtBQUssVUFBVSxLQUFLLFlBQ3BDLEtBQUssY0FBYyxPQUFPLE9BQU8sV0FBVyxPQUFPLFFBQVEsTUFBTSxFQUMvRCxLQUFLLENBQUMsUUFBTztBQUNiLGFBQUs7QUFHTCxZQUFJLEtBQUssd0JBQXdCLEtBQUssS0FBSyx1QkFBdUIsVUFBVSxRQUFXO0FBQ3RGLGVBQUssbUJBQW1CLE1BQU0sRUFBRSxNQUFNLENBQUMsUUFBTztBQUM3QyxZQUFBQSxRQUFPLEtBQUssNkNBQTZDLEdBQUcsRUFBRTtVQUMvRCxDQUFDO1FBQ0Y7QUFDQSxnQkFBUSxHQUFHO01BQ1osQ0FBQyxFQUNBLE1BQU0sQ0FBQyxRQUFPO0FBQ2QsYUFBSztBQUNMLGVBQU8sZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDM0QsQ0FBQyxDQUFDO0lBRUwsQ0FBQztFQUNGO0VBRVEsTUFBTSxjQUNiLE9BQ0EsT0FDQSxXQUNBLE9BQ0EsUUFDQSxTQUFTLE1BQUk7QUFFYixVQUFNLFlBQVk7QUFFbEIsVUFBTSxZQUFzQixDQUFBO0FBQzVCLFFBQUksY0FBYztBQUFXLGdCQUFVLEtBQUssWUFBWSxHQUFJO0FBQzVELFFBQUksVUFBVTtBQUFXLGdCQUFVLEtBQUssR0FBRyxjQUFhLGdCQUFnQixLQUFLLENBQUM7QUFFOUUsVUFBTSxjQUF3QixDQUFDLElBQU0sUUFBUSxHQUFJO0FBRWpELFFBQUksVUFBVSxlQUFlLFVBQVUsVUFBYSxjQUFjLFVBQWEsVUFBVSxRQUFXO0FBSW5HLFVBQUksQ0FBQyxLQUFLLFlBQVksSUFBSSxNQUFNO0FBQUcsYUFBSyxZQUFZLElBQUksUUFBUSxvQkFBSSxJQUFHLENBQUU7QUFDekUsWUFBTSxVQUFVLEtBQUssWUFBWSxJQUFJLE1BQU07QUFDM0MsWUFBTSxlQUFlO0FBQ3JCLFlBQU0sWUFBc0IsQ0FBQTtBQUM1QixlQUFTLElBQUksR0FBRyxJQUFJLGNBQWMsS0FBSztBQUN0QyxjQUFNLFdBQVcsY0FBYyxLQUFLLE9BQU8sYUFBYSxHQUFHLEtBQUs7QUFDaEUsY0FBTSxNQUFNLE1BQU0sWUFBWSxPQUFPLEtBQUssSUFBSyxRQUFRLElBQUksUUFBUSxLQUFLO0FBQ3hFLGtCQUFVLEtBQUssR0FBRztBQUNsQixnQkFBUSxJQUFJLFVBQVUsR0FBRztNQUMxQjtBQUNBLGtCQUFZLEtBQUssUUFBUSxLQUFNLEdBQUcsU0FBUztJQUM1QyxPQUFPO0FBQ04sVUFBSSxVQUFVO0FBQVcsb0JBQVksS0FBSyxRQUFRLEdBQUk7QUFDdEQsVUFBSTtBQUFRLG9CQUFZLEtBQUssVUFBVSxNQUFNO0FBQzdDLFVBQUksVUFBVSxTQUFTO0FBQUcsb0JBQVksS0FBSyxHQUFHLFNBQVM7SUFDeEQ7QUFFQSxVQUFNLE1BQU0sY0FBYSxVQUFVLFdBQVc7QUFDOUMsVUFBTSxpQkFBaUIsT0FBTyxLQUFLLENBQUMsR0FBRyxhQUFhLEdBQUcsQ0FBQztBQUd4RCxRQUFJLGNBQWMsVUFBYSxVQUFVLFFBQVc7QUFDbkQsWUFBTSxhQUFhLGNBQWEsZ0JBQWdCLEtBQUs7QUFDckQsWUFBTSxVQUF5QjtRQUM5QixRQUFRO1FBQ1IsSUFBSTtRQUNKO1FBQ0E7O0FBRUQsTUFBQUEsUUFBTyxLQUFLLE1BQU0sTUFBTSxNQUFNLG9CQUFvQixTQUFTLEtBQUssT0FBTyxDQUFDLEVBQUU7SUFDM0UsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxlQUFlLEtBQUssQ0FBQyxFQUFFO0lBQ3REO0FBSUEsUUFBSSxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sR0FBRztBQUNwQyxNQUFBQSxRQUFPLE1BQU0scURBQWdELE1BQU0sS0FBSyxlQUFlLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFDeEcsWUFBTSxJQUFJLE1BQU0sYUFBYSxNQUFNLGlGQUE0RTtJQUNoSDtBQUdBLFVBQU0sS0FBSyxvQkFBb0IsTUFBTTtBQUVyQyxVQUFNLFdBQVcsS0FBSyxlQUFlO0FBQ3JDLFVBQU0sU0FBUyxNQUFNLEtBQUssWUFBWSxVQUFVLE1BQU07QUFDdEQsVUFBTSxTQUFTLE9BQU8sT0FBTyxDQUFDLFFBQVEsY0FBYyxDQUFDO0FBRXJELElBQUFBLFFBQU8sTUFBTSxxQkFBcUIsTUFBTSxLQUFLLE9BQU8sU0FBUyxLQUFLLENBQUMsRUFBRTtBQUVyRSxVQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksS0FBSztBQUU5QixXQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsWUFBTSxRQUFRLFdBQVcsTUFBSztBQUM3QixhQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLGVBQU8sSUFBSSxNQUFNLHNDQUFzQyxLQUFLLEtBQUssT0FBTyxNQUFNLE9BQU8sQ0FBQztNQUN2RixHQUFHLFNBQVM7QUFFWixXQUFLLFlBQVksSUFBSSxLQUFLO1FBQ3pCLFNBQVMsQ0FBQyxRQUFPO0FBQ2hCLHVCQUFhLEtBQUs7QUFDbEIsa0JBQVEsR0FBRztRQUNaO1FBQ0EsUUFBUSxDQUFDLFFBQU87QUFDZix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLEdBQUc7UUFDWDtRQUNBO09BQ0E7QUFFRCxXQUFLLFNBQVMsS0FBSyxRQUFRLEtBQUssYUFBYSxRQUFRLENBQUMsUUFBTztBQUM1RCxZQUFJLEtBQUs7QUFDUixlQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQzdDO01BQ0QsQ0FBQztJQUNGLENBQUM7RUFDRjtFQUVRLGVBQWUsS0FBYSxPQUFhO0FBQ2hELFFBQUksSUFBSSxTQUFTO0FBQUc7QUFDcEIsUUFBSSxJQUFJLENBQUMsTUFBTSxPQUFRLElBQUksQ0FBQyxNQUFNO0FBQU07QUFFeEMsVUFBTSxVQUFVLElBQUksYUFBYSxDQUFDO0FBS2xDLFFBQUksWUFBWSwyQkFBMkIsS0FBSyxtQkFBbUIsT0FBTyxHQUFHO0FBQzVFLFlBQU0sU0FBUyx1QkFBdUIsS0FBSyxLQUFLO0FBQ2hELFVBQUksUUFBUTtBQUNYLFFBQUFBLFFBQU8sTUFDTiw0QkFBNEIsS0FBSyxlQUNuQixPQUFPLElBQUksYUFDZCxPQUFPLEtBQUssaUJBQ1IsT0FBTyxTQUFTLG9CQUNiLE9BQU8sWUFBWSxHQUFHO0FBSXpDLFlBQUksT0FBTyxTQUFTLFlBQVk7QUFDL0IscUJBQVcsTUFBTSxLQUFLLG1CQUFtQixPQUFNLEdBQUk7QUFDbEQsZ0JBQUk7QUFDSCxpQkFBRyxNQUFNO1lBQ1YsUUFBUTtZQUVSO1VBQ0Q7UUFDRCxPQUFPO0FBQ04sVUFBQUEsUUFBTyxNQUFNLHNEQUFzRCxPQUFPLElBQUksT0FBTyxLQUFLLEVBQUU7UUFDN0Y7TUFDRDtBQUNBO0lBQ0Q7QUFFQSxRQUFJLElBQUksU0FBUztBQUFJO0FBR3JCLFVBQU0sTUFBTSxJQUFJLFNBQVMsSUFBSSxFQUFFO0FBQy9CLFFBQUksSUFBSSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBSTFDLFVBQU0sWUFBWSxJQUFJLFNBQVMsRUFBRTtBQUNqQyxRQUFJLFVBQVUsU0FBUztBQUFHO0FBQzFCLFFBQUksVUFBVSxDQUFDLE1BQU07QUFBTTtBQUczQixVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sY0FBYyxZQUFZLFNBQVU7QUFDMUMsVUFBTSxnQkFBZ0IsWUFBWTtBQUdsQyxRQUFJLGNBQWMsa0JBQWtCLHNCQUFzQjtBQUN6RCxNQUFBQSxRQUFPLE1BQU0sd0JBQXdCLEtBQUssS0FBSyxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7SUFDckU7QUFHQSxTQUFLLGFBQWEsT0FBTyxlQUFlLEtBQUssU0FBUztBQUd0RCxRQUFJLFlBQVk7QUFDZixZQUFNLE1BQU0sR0FBRyxLQUFLLElBQUksYUFBYTtBQUNyQyxZQUFNLFVBQVUsS0FBSyxZQUFZLElBQUksR0FBRztBQUN4QyxVQUFJLFNBQVM7QUFDWixhQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLGdCQUFRLFFBQVEsR0FBRztNQUNwQjtJQUNEO0VBRUQ7Ozs7Ozs7Ozs7OztFQWFRLGFBQWEsT0FBZSxPQUFlLEtBQWEsV0FBaUI7QUFDaEYsVUFBTSxVQUFVLGVBQWUsS0FBSztBQUNwQyxVQUFNLE9BQU8sVUFBVSxTQUFTLEdBQUcsVUFBVSxTQUFTLENBQUM7QUFHdkQsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLE1BQU0sVUFBVSxVQUFVLFNBQVMsQ0FBQztBQUMxQyxVQUFNLGdCQUFnQixRQUFRLE1BQU0sU0FBUyxDQUFDLFNBQVMsS0FBSyxTQUFTLEtBQUssQ0FBQyxRQUFRLE1BQU0sR0FBRyxDQUFDO0FBSzdGLFFBQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBSSxDQUFDLEtBQUssT0FBTztBQUNoQixRQUFBQSxRQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsRUFBRTtBQUN6RDtNQUNEO0FBQ0EsVUFBSTtBQUNILGNBQU0sV0FDTCxVQUFVLG9CQUNQLHNCQUFzQixLQUFLLE9BQU8sR0FBRyxJQUNyQyw0QkFBNEIsS0FBSyxPQUFPLEdBQUc7QUFFL0MsY0FBTSxZQUFZLEtBQUssWUFBWSxJQUFJLEtBQUssS0FBSyxvQkFBSSxJQUFHO0FBQ3hELGNBQU0sV0FBVyxJQUFJLElBQW9CLFNBQVM7QUFFbEQsbUJBQVcsS0FBSyxVQUFVO0FBQ3pCLGdCQUFNLFdBQVcsY0FBYyxLQUFLLE9BQU8sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUs7QUFFbEUsZ0JBQU0sV0FDTCxFQUFFLFdBQVcsV0FBVyxJQUNwQixFQUFFLFdBQVcsQ0FBQyxLQUFLLEtBQU8sRUFBRSxXQUFXLENBQUMsS0FBSyxJQUFLLEVBQUUsV0FBVyxDQUFDLElBQ2hFLEVBQUUsV0FBVyxDQUFDLEtBQUs7QUFDeEIsZ0JBQU0sWUFBWSxVQUFVLElBQUksUUFBUTtBQUN4QyxnQkFBTSxVQUFVLGNBQWMsVUFBYSxjQUFjO0FBRXpELG1CQUFTLElBQUksVUFBVSxRQUFRO0FBRS9CLGdCQUFNLFlBQVksb0JBQW9CLEdBQUcsS0FBSyxPQUFPO0FBQ3JELGNBQUksU0FBUztBQUNaLFlBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxTQUFTLEVBQUU7QUFFeEMsZ0JBQUksS0FBSyxrQkFBa0I7QUFDMUIsa0JBQUksU0FBUyxFQUFFO0FBQ2Ysb0JBQU0sYUFBYSxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQUs7QUFDMUMsb0JBQUksRUFBRSxXQUFXLEVBQUU7QUFBUSx5QkFBTztBQUNsQyxvQkFBSSxFQUFFLE9BQU8sRUFBRTtBQUFJLHlCQUFPO0FBQzFCLHNCQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQzNELG9CQUFJLENBQUMsYUFBYTtBQUFTLHlCQUFPO0FBQ2xDLHNCQUFNLFNBQVMsRUFBRSxLQUFLLEVBQUU7QUFDeEIsdUJBQU8sU0FBUyxLQUFLLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sTUFBTTtjQUNyRSxDQUFDO0FBQ0Qsa0JBQUk7QUFBWSx5QkFBUyxXQUFXO0FBQ3BDLG9CQUFNLGtCQUFrQixjQUFjLEtBQUssT0FBTyxFQUFFLFFBQVEsTUFBTTtBQUNsRSxtQkFBSyxpQkFBaUIsZUFBZTtZQUN0QyxPQUFPO0FBQ04sY0FBQUEsUUFBTyxLQUFLLGdFQUEyRCxRQUFRLEVBQUU7WUFDbEY7VUFDRCxPQUFPO0FBQ04sWUFBQUEsUUFBTyxNQUFNLE1BQU0sS0FBSyxNQUFNLFNBQVMsRUFBRTtVQUMxQztRQUNEO0FBQ0EsYUFBSyxZQUFZLElBQUksT0FBTyxRQUFRO01BQ3JDLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLG9CQUFvQixDQUFDLE1BQU0sYUFBYSxFQUFFO01BQy9FO0FBQ0E7SUFDRDtBQUdBLFVBQU0sVUFBVSxLQUFLLGFBQWEsT0FBTyxJQUFJO0FBRTdDLFVBQU0sUUFBUSxVQUFVLGNBQWNBLFFBQU8sTUFBTSxLQUFLQSxPQUFNLElBQUlBLFFBQU8sS0FBSyxLQUFLQSxPQUFNO0FBQ3pGLFFBQUksU0FBUztBQUNaLFlBQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsTUFBTSxPQUFPLEVBQUU7SUFDakUsT0FBTztBQUNOLFlBQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsRUFBRTtJQUNwRDtFQUNEOzs7OztFQU1RLGFBQWEsT0FBZSxNQUFZO0FBQy9DLFFBQUksS0FBSyxXQUFXO0FBQUcsYUFBTztBQUc5QixRQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLFVBQUksS0FBSyxDQUFDLE1BQU0sR0FBTTtBQUNyQixlQUFPO01BQ1IsT0FBTztBQUNOLGVBQU8sU0FBUyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7TUFDL0I7SUFDRDtBQUVBLFlBQVEsT0FBTzs7O01BR2QsS0FBSyxhQUFhO0FBQ2pCLGNBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsY0FBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLEVBQ3RDLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQ2pFLEtBQUssR0FBRztBQUNWLGVBQU8sTUFBTSxLQUFLLElBQUksSUFBSTtNQUMzQjs7Ozs7TUFNQSxLQUFLLGNBQWM7QUFDbEIsWUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixpQkFBTyxLQUFLLENBQUMsTUFBTSxJQUFPLFdBQVcsV0FBVyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDL0Q7QUFDQSxZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxVQUFVLFFBQVEsVUFBVSxDQUFDLEdBQUc7QUFDdEMsZ0JBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxnQkFBTSxjQUNMLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBQ3JGLGdCQUFNLFdBQVcsY0FBYyxHQUFHLFdBQVcsS0FBSyxNQUFNLFFBQVMsQ0FBQyxNQUFNLFdBQVcsTUFBTSxLQUFLLFVBQVUsQ0FBQztBQUN6RyxnQkFBTSxTQUFTLElBQUksTUFBTSxLQUFLLENBQUMsSUFBSSxNQUFNLFNBQVMsQ0FBQyxLQUFLLFdBQVcsTUFBTSxLQUFLLFVBQVUsQ0FBQyxDQUFDO0FBQzFGLGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRLElBQUksTUFBTTtRQUNoRTtBQUNBLGVBQU8sUUFBUSxLQUFLLFNBQVMsS0FBSyxDQUFDO01BQ3BDOztNQUdBLEtBQUssaUJBQWlCO0FBRXJCLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDckIsZ0JBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsZ0JBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsZ0JBQU0sYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNsQyxnQkFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUNoRixnQkFBTSxjQUFjLFFBQVEsUUFBUSxXQUFXLE1BQU0sU0FBUyxDQUFDO0FBQy9ELGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sVUFBVSxRQUFRLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sR0FBRztBQUNoRSxnQkFBTSxjQUNMLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBQ3JGLGdCQUFNLFdBQVcsZUFBZSxLQUFLLFdBQVcsU0FBUyxLQUFLLENBQUM7QUFDL0QsaUJBQU8sV0FBVyxLQUFLLE1BQU0sV0FBVyxLQUFLLFFBQVE7UUFDdEQ7QUFDQSxlQUFPO01BQ1I7O01BR0EsS0FBSztNQUNMLEtBQUssYUFBYTtBQUNqQixZQUFJLEtBQUssU0FBUztBQUFHLGlCQUFPO0FBQzVCLGNBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsY0FBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixjQUFNLFFBQVEsS0FBSyxTQUFTLENBQUM7QUFDN0IsZUFBTyxNQUFNLEtBQUssWUFBWSxNQUFNLFNBQVMsQ0FBQyxVQUFVLE1BQU0sU0FBUyxLQUFLLENBQUM7TUFDOUU7TUFFQTtBQUNDLGVBQU87SUFDVDtFQUNEO0VBRVEsT0FBTyxnQkFBZ0IsT0FBYztBQUM1QyxRQUFJLE9BQU8sVUFBVTtBQUFXLGFBQU8sQ0FBQyxRQUFRLElBQUksQ0FBQztBQUNyRCxRQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUcsYUFBTyxNQUFNLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxJQUFJLEdBQUk7QUFDbEUsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM5QixVQUFJLFFBQVE7QUFBTSxlQUFPLENBQUUsU0FBUyxLQUFNLEtBQU8sU0FBUyxJQUFLLEtBQU0sUUFBUSxHQUFJO0FBQ2pGLGFBQU8sQ0FBQyxRQUFRLEdBQUk7SUFDckI7QUFDQSxVQUFNLElBQUksTUFBTSw0Q0FBNEMsS0FBSyxFQUFFO0VBQ3BFO0VBRVEsTUFBTSxZQUFZLFVBQWtCLFFBQWM7QUFDekQsUUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLE1BQU07QUFDbEMsUUFBSSxDQUFDLEtBQUs7QUFDVCxZQUFNLE1BQU0scUJBQXFCLE1BQU07QUFDdkMsV0FBSyxTQUFTLElBQUksUUFBUSxHQUFHO0lBQzlCO0FBRUEsV0FBTyxPQUFPLE9BQU87TUFDcEIsT0FBTyxLQUFLLENBQUMsS0FBTSxLQUFNLEdBQU0sV0FBVyxLQUFNLEdBQU0sS0FBTSxHQUFNLEdBQU0sR0FBRyxLQUFLLEdBQU0sQ0FBSSxDQUFDO01BQzNGLE9BQU8sS0FBSyxZQUFZLE1BQU07S0FDOUI7RUFDRjtFQUVRLE9BQU8sVUFBVSxNQUFjO0FBQ3RDLFFBQUksTUFBTTtBQUNWLGVBQVcsS0FBSyxNQUFNO0FBQ3JCLGFBQU87QUFDUCxlQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUMzQixlQUFPLE1BQU0sU0FBVSxLQUFNLE9BQU8sSUFBSyxPQUFRLE1BQVEsT0FBTyxJQUFLO01BQ3RFO0lBQ0Q7QUFDQSxXQUFPO0VBQ1I7Ozs7Ozs7Ozs7RUFXTyxnQkFBZ0IsSUFBWSxPQUFlLFdBQW1CLE9BQWM7QUFDbEYsVUFBTSxNQUFNLGNBQWMsS0FBSyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQzdELFdBQU8sS0FBSyxZQUFZLElBQUksRUFBRSxHQUFHLElBQUksR0FBRztFQUN6QztFQUVPLE1BQU0sWUFBWSxRQUFjO0FBQ3RDLFdBQU8sS0FBSyxhQUFhLGtCQUFrQixRQUFXLEdBQU0sUUFBVyxRQUFRLEtBQUs7RUFDckY7RUFFTyxNQUFNLGNBQWMsUUFBYztBQUN4QyxXQUFPLEtBQUssYUFBYSxxQkFBcUIsUUFBVyxRQUFXLFFBQVcsUUFBUSxLQUFLO0VBQzdGOzs7O0FFbHdCRCxJQUFNRSxVQUFTLG1CQUFtQixnQkFBZ0I7QUFNbEQsSUFBcUIsaUJBQXJCLGNBQTRDLGFBQXlCO0VBQ3BFOztFQUNBOzs7RUFJUSxvQkFBa0MsQ0FBQTs7O0VBSTFDLGNBQXNCO0VBRXRCLFlBQVksVUFBaUI7QUFDNUIsVUFBTSxRQUFRO0VBQ2Y7RUFFQSxNQUFNLEtBQUssUUFBb0I7QUFDOUIsU0FBSyxTQUFTO0FBQ2QsUUFBSSxDQUFDLEtBQUssY0FBYztBQUN2QixXQUFLLGVBQWUsSUFBSSxhQUFZO0lBQ3JDO0FBQ0EsU0FBSyxhQUFhLGVBQWUsWUFBWSx3QkFBd0I7QUFHckUsU0FBSyxhQUFhLG9CQUFvQixDQUFDLGVBQXNCO0FBQzVELFdBQUssZUFBZSxVQUFVO0lBQy9CLENBQUM7QUFJRCxTQUFLLGFBQVksRUFBRyxNQUFNLENBQUMsTUFBSztBQUMvQixNQUFBQSxRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtJQUN0QyxDQUFDO0VBQ0Y7Ozs7Ozs7RUFRUSxNQUFNLGVBQVk7QUFDekIsSUFBQUEsUUFBTyxLQUFLLDhCQUE4QjtBQUUxQyxTQUFLLG9CQUFvQixNQUFNLEtBQUssYUFBYSxnQkFBZTtBQUdoRSxRQUFJO0FBQ0osUUFBSSxLQUFLLGtCQUFrQixXQUFXLEdBQUc7QUFFeEMsVUFBSSxLQUFLLE9BQU8sV0FBVztBQUMxQixjQUFNLGFBQWEsS0FBSyxPQUFPLGNBQWMsU0FBUyxLQUFLLE9BQU8sV0FBVyxNQUFNO0FBQ25GLFFBQUFBLFFBQU8sS0FBSyxxQkFBcUIsS0FBSyxPQUFPLFNBQVMsOENBQXlDO0FBQy9GLGFBQUssYUFBYSxlQUFlLG1CQUFtQixHQUFHLFVBQVUsSUFBSSxLQUFLLE9BQU8sU0FBUyxhQUFhO0FBQ3ZHO01BQ0Q7QUFDQSxZQUFNLGNBQWMsS0FBSyxPQUFPO0FBQ2hDLFVBQUksQ0FBQyxLQUFLLE9BQU8sUUFBUSxDQUFDLGFBQWE7QUFDdEMsUUFBQUEsUUFBTyxLQUFLLHlEQUF5RDtBQUNyRTtNQUNEO0FBQ0EsTUFBQUEsUUFBTyxLQUFLLHdFQUFtRTtBQUMvRSx1QkFBaUI7SUFDbEIsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxjQUFjLEtBQUssa0JBQWtCLE1BQU0sYUFBYTtBQUNwRSxpQkFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3ZDLFFBQUFBLFFBQU8sS0FBSyxhQUFhLEVBQUUsS0FBSyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRTtNQUNyRTtBQUtBLGlCQUFXLFVBQVUsS0FBSyxtQkFBbUI7QUFDNUMsYUFBSyxhQUFhLGdCQUFnQixPQUFPLEVBQUU7TUFDNUM7QUFHQSxpQkFBVyxVQUFVLEtBQUssbUJBQW1CO0FBQzVDLFlBQUk7QUFDSCxnQkFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLHVCQUF1QixPQUFPLEVBQUU7QUFDekUsaUJBQU8sZUFBZTtBQUN0QixVQUFBQSxRQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsY0FBYyxRQUFRLFdBQVcsT0FBTyxhQUFhLEVBQUU7UUFDcEYsU0FBUyxHQUFHO0FBQ1gsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLDZCQUE2QixDQUFDLEVBQUU7QUFDNUQsaUJBQU8sZUFBZTtRQUN2QjtNQUNEO0FBRUEsdUJBQWlCLGFBQWEsS0FBSyxRQUFRLEtBQUssaUJBQWlCO0FBR2pFLFVBQUksQ0FBQyxrQkFBa0IsS0FBSyxPQUFPLFdBQVc7QUFDN0MsY0FBTSxhQUFhLEtBQUssT0FBTyxjQUFjLFNBQVMsS0FBSyxPQUFPLFdBQVcsTUFBTTtBQUNuRixRQUFBQSxRQUFPLEtBQUsscUJBQXFCLEtBQUssT0FBTyxTQUFTLHNEQUFpRDtBQUN2RyxhQUFLLGFBQWEsZUFBZSxtQkFBbUIsR0FBRyxVQUFVLElBQUksS0FBSyxPQUFPLFNBQVMsYUFBYTtBQUN2RztNQUNEO0lBQ0Q7QUFHQSxTQUFLLFVBQVUsY0FBYztBQUk3QixVQUFNLGFBQWEsS0FBSztBQUN4QixVQUFNLEtBQUssb0JBQW9CLElBQUksVUFBVTtBQUc3QyxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtBQUV6QixTQUFLLGFBQWEsZUFBZSxFQUFFO0FBQ25DLElBQUFBLFFBQU8sS0FBSywyQkFBMkI7RUFDeEM7O0VBR0EsTUFBTSxVQUFPO0FBQ1osU0FBSyxjQUFjLE1BQUs7QUFDeEIsSUFBQUEsUUFBTyxNQUFNLFNBQVM7RUFDdkI7RUFFQSxNQUFNLGNBQWMsUUFBb0I7QUFDdkMsVUFBTSxlQUFlLEtBQUs7QUFDMUIsU0FBSyxTQUFTO0FBQ2QsVUFBTSxpQkFBaUIsYUFBYSxRQUFRLEtBQUssaUJBQWlCO0FBQ2xFLFNBQUssVUFBVSxjQUFjO0FBSTdCLFNBQUsscUJBQW9CO0FBRXpCLFVBQU0sVUFBVSxLQUFLO0FBSXJCLFVBQU0sS0FBSyxvQkFBb0IsY0FBYyxPQUFPO0FBR3BELFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0VBQzFCOzs7Ozs7Ozs7Ozs7RUFhUSxNQUFNLG9CQUFvQixjQUFzQixTQUFlO0FBQ3RFLFFBQUksQ0FBQyxTQUFTO0FBQ2IsVUFBSTtBQUFjLGFBQUssYUFBYSxhQUFhLFlBQVk7QUFDN0Q7SUFDRDtBQUVBLFFBQUksS0FBSyxPQUFPLFdBQVc7QUFFMUIsWUFBTSxTQUFTLEtBQUssa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxLQUFLLE9BQU8sU0FBUztBQUNqRixVQUFJLENBQUMsUUFBUTtBQUNaLFFBQUFBLFFBQU8sS0FBSyxlQUFlLEtBQUssT0FBTyxTQUFTLHlEQUFvRDtBQUNwRyxZQUFJO0FBQWMsZUFBSyxhQUFhLGFBQWEsWUFBWTtBQUM3RDtNQUNEO0FBRUEsVUFBSSxnQkFBZ0IsaUJBQWlCLFNBQVM7QUFDN0MsYUFBSyxhQUFhLGFBQWEsWUFBWTtNQUM1QztBQUNBLFlBQU0sZ0JBQWdCLEtBQUssYUFBYSxtQkFBbUIsT0FBTztBQUNsRSxVQUFJLENBQUMsZUFBZTtBQUNuQixhQUFLLGFBQWEsZ0JBQWdCLE9BQU87TUFDMUM7QUFDQSxVQUFJLFlBQVksZ0JBQWdCLENBQUMsZUFBZTtBQUMvQyxjQUFNLEtBQUssNkJBQTZCLE9BQU8sT0FBTyxPQUFPO01BQzlEO0FBQ0E7SUFDRDtBQUdBLFVBQU0sY0FBYyxPQUFPLEtBQUssT0FBTyxlQUFlLEVBQUU7QUFDeEQsVUFBTSxpQkFBaUIsS0FBSyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFFMUUsUUFBSSxnQkFBZ0I7QUFDbkIsVUFBSSxlQUFlLFVBQVUsYUFBYTtBQUN6QyxZQUFJLGdCQUFnQixpQkFBaUI7QUFBUyxlQUFLLGFBQWEsYUFBYSxZQUFZO0FBQ3pGLGNBQU0sZ0JBQWdCLEtBQUssYUFBYSxtQkFBbUIsT0FBTztBQUNsRSxZQUFJLENBQUMsZUFBZTtBQUNuQixlQUFLLGFBQWEsZ0JBQWdCLE9BQU87UUFDMUM7QUFDQSxZQUFJLFlBQVksZ0JBQWdCLENBQUMsZUFBZTtBQUMvQyxnQkFBTSxLQUFLLDZCQUE2QixhQUFhLE9BQU87UUFDN0Q7TUFDRCxPQUFPO0FBQ04sUUFBQUEsUUFBTyxNQUNOLDBCQUEwQixXQUFXLDJDQUEyQyxlQUFlLEtBQUssUUFBUSxPQUFPLDBCQUFxQjtBQUV6SSxhQUFLLGFBQWEsYUFBYSxPQUFPO0FBQ3RDLGFBQUssYUFDSixlQUFlLG1CQUNmLDRCQUE0QixXQUFXLFNBQVMsZUFBZSxLQUFLLEVBQUU7TUFFeEU7QUFDQTtJQUNEO0FBR0EsSUFBQUEsUUFBTyxLQUFLLEdBQUcsT0FBTyx3Q0FBbUM7QUFDekQsUUFBSSxnQkFBZ0IsaUJBQWlCO0FBQVMsV0FBSyxhQUFhLGFBQWEsWUFBWTtBQUN6RixTQUFLLGFBQWEsYUFBYSxPQUFPO0FBRXRDLFVBQU0sU0FBUyxNQUFNLEtBQUssYUFBYSxZQUFZLE9BQU87QUFDMUQsUUFBSSxDQUFDLFFBQVE7QUFDWixNQUFBQSxRQUFPLE1BQU0sMEJBQTBCLE9BQU8sMEJBQXFCO0FBQ25FLFdBQUssYUFBYSxlQUFlLGdCQUFnQixtQkFBbUIsT0FBTyxFQUFFO0lBQzlFLFdBQVcsT0FBTyxVQUFVLGFBQWE7QUFDeEMsTUFBQUEsUUFBTyxNQUNOLDBCQUEwQixXQUFXLDJDQUEyQyxPQUFPLEtBQUssUUFBUSxPQUFPLDBCQUFxQjtBQUVqSSxXQUFLLGFBQ0osZUFBZSxtQkFDZiw0QkFBNEIsV0FBVyxTQUFTLE9BQU8sS0FBSyxFQUFFO0lBRWhFLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssa0JBQWtCLE9BQU8sS0FBSyxPQUFPLE9BQU8sRUFBRTtBQUMxRCxXQUFLLGFBQWEsZ0JBQWdCLE9BQU87QUFDekMsWUFBTSxLQUFLLDZCQUE2QixhQUFhLE9BQU87QUFDNUQsV0FBSyxhQUFhLGVBQWUsRUFBRTtJQUNwQztFQUNEOzs7OztFQU1RLE1BQU0sNkJBQTZCLE9BQWUsSUFBVTtBQUNuRSxRQUFJO0FBQ0gsWUFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUU7QUFFN0MsVUFBSSxDQUFDLGdCQUFnQixLQUFLLEdBQUc7QUFHNUIsUUFBQUEsUUFBTyxLQUFLLDZCQUE2QixLQUFLLHNEQUFpRDtBQUMvRjtNQUNEO0lBQ0QsU0FBUyxHQUFHO0FBQ1gsTUFBQUEsUUFBTyxLQUFLLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxFQUFFO0lBQ3hEO0VBQ0Q7O0VBR1EsVUFBVSxPQUFhO0FBQzlCLFNBQUssY0FBYztBQUNuQixVQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsUUFBSSxDQUFDLFFBQVE7QUFDWixNQUFBQSxRQUFPLEtBQUssVUFBVSxLQUFLLCtCQUErQjtBQUMxRCxXQUFLLGFBQWEsU0FBUyxPQUFPLENBQUEsR0FBSSxJQUFJO0FBQzFDO0lBQ0Q7QUFFQSxVQUFNLFVBQVUsTUFBTSxRQUFRLE9BQU8sU0FBUyxJQUFJLE9BQU8sWUFBWSxDQUFBO0FBQ3JFLFVBQU0sc0JBQXNCLE9BQU8sdUJBQXVCO0FBRTFELFNBQUssYUFBYSxTQUFTLE9BQU8sU0FBUyxtQkFBbUI7QUFDOUQsUUFBSSxRQUFRLFdBQVcsR0FBRztBQUN6QixNQUFBQSxRQUFPLEtBQUssK0JBQStCLEtBQUssNkNBQXdDO0lBQ3pGLE9BQU87QUFDTixNQUFBQSxRQUFPLE1BQ04sVUFBVSxRQUFRLE1BQU0sdUJBQXVCLEtBQUssZ0JBQWdCLE9BQU8sU0FBUyx5QkFBeUIsbUJBQW1CLEVBQUU7SUFFcEk7RUFDRDtFQUVBLGtCQUFlO0FBQ2QsV0FBTyxnQkFBZ0IsS0FBSyxpQkFBaUI7RUFDOUM7O0VBR0EsSUFBSSxPQUFJO0FBQ1AsV0FBTyxZQUFZLEtBQUssUUFBUSxLQUFLLGlCQUFpQjtFQUN2RDs7RUFHQSxJQUFJLFVBQU87QUFDVixXQUFPLEtBQUs7RUFDYjtFQUVBLGdCQUFhO0FBQ1osa0JBQWMsSUFBSTtFQUNuQjtFQUVBLGtCQUFlO0FBQ2Qsb0JBQWdCLElBQUk7RUFDckI7RUFFQSw0QkFBeUI7QUFDeEIsOEJBQTBCLElBQUk7RUFDL0I7RUFFQSx1QkFBb0I7QUFDbkIseUJBQXFCLElBQUk7RUFDMUI7OyIsCiAgIm5hbWVzIjogWyJwYXRoIiwgIkluc3RhbmNlU3RhdHVzIiwgIlJlZ2V4IiwgInBhdGgiLCAiZnMiLCAibG9nZ2VyIiwgImxvZ2dlciIsICJpZEFkZE9wdCIsICJmcyIsICJsb2dnZXIiLCAiZGV2aWNlc0ZvbGRlciIsICJwYXRoIiwgImRncmFtIiwgImxvZ2dlciIsICJsb2dnZXIiLCAiZGdyYW0iLCAibG9nZ2VyIl0KfQo=
