import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual" },
    ...discoveredDevices.map((d) => ({
      id: d.ip,
      label: `Model ${d.model} (${d.ip})`
    }))
  ];
  return [
    // ── Device discovery dropdown ────────────────────────────────────────
    // Mirrors the bonjour-device field: selecting a device populates the
    // host automatically; selecting 'Manual' shows the textinput below.
    {
      type: "dropdown",
      id: "discoveredHost",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies Dante device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry ──────────────────────────────────────────────────
    // Only visible when discoveredHost is '' (Manual selected).
    // Matches the pattern from the bonjour-device docs.
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Model selector ───────────────────────────────────────────────────
    // Only visible when Manual mode is selected (no discovered device).
    // When a discovered device is selected, the model is auto-detected.
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Select which Studio Technologies model is active for actions and Get All Settings"
    }
  ];
}
function resolveHost(config) {
  return config.discoveredHost || config.host;
}
function resolveModel(config, discoveredDevices) {
  if (config.discoveredHost) {
    const device = discoveredDevices.find((d) => d.ip === config.discoveredHost);
    logger.debug(`resolveModel: discoveredHost="${config.discoveredHost}", found device: ${device?.model ?? "none"}`);
    if (device?.model) {
      return device.model;
    }
    if (discoveredDevices.length === 0) {
      logger.warn(`resolveModel: No devices discovered, cannot determine model`);
      return "";
    }
  }
  logger.debug(`resolveModel: falling back to activeModel="${config.activeModel}"`);
  return config.activeModel;
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
function UpdateVariableValues(self) {
  const currentHost = self.host;
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "Unknown",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "Unknown",
      danteFW: device.danteFirmware || "Unknown",
      mac: device.mac || "",
      ip: device.ip || currentHost
    });
  } else {
    self.setVariableValues({
      model: self.config.activeModel || "Unknown",
      modelName: "",
      manufacturer: "",
      firmware: "Unknown",
      danteFW: "Unknown",
      mac: "",
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_BUS_GET:
      return "Get Bus Setting";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "textinput":
    case "colorpicker":
    case "static-text":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  for (const { cmd_id, id, valueBytes } of parsed) {
    let action = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (!action) {
      for (const c of candidates) {
        const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
        if (match) {
          action = structuredClone(match);
          action.name = `${match.name} (inferred from Model ${c.model})`;
          logger2.info(`Inferred setting ${toHex(id)} from Model ${c.model}`);
          break;
        }
      }
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown Setting ${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      logger2.warn(`Could not infer setting ${toHex(id)}`);
    } else {
      const opt = action.options?.[0];
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
    }
    const exists = out.cmdSchema.some((a) => a.cmd_id === action.cmd_id && a.id === action.id);
    if (!exists)
      out.cmdSchema.push(action);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("refreshAfterCommand" in jsonObj) {
      orderedObj.refreshAfterCommand = jsonObj.refreshAfterCommand;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema;
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = resolveModel(self.config, self.devices);
  logger3.info(`UpdateActions: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  wiredActions["global_getAllSettings"] = {
    name: "GLOBAL: Get All Settings (Auto-Update JSON)",
    options: [],
    callback: async () => {
      const model = activeModel;
      const ip = self.host;
      const buf = await self.stController.requestAllSettings(ip);
      let modelJson = getDeviceSchema(model);
      if (!modelJson) {
        logger3.error(`Model ${model} schema not found in cache`);
        return;
      }
      const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
      logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
      if (detectedSectioned !== null) {
        logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
        modelJson = { ...modelJson, sectioned: detectedSectioned };
      }
      const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
      logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
      const devicesFolder2 = getDevicesFolder();
      const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
      saveModelJsonPretty(schemaPath, updated);
      reloadDeviceSchemas();
      logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
    }
  };
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(activeModel, cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(activeModel, ip);
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
  logger3.info(`UpdateActions: wired actions: ${Object.keys(wiredActions).length}`);
}

// dist/feedbacks.js
var logger4 = createModuleLogger("Feedbacks");
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = resolveModel(self.config, self.devices);
  logger4.info(`UpdateFeedbacks: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const busCh = feedbackEvent.options["busCh"];
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
  logger4.info(`UpdateFeedbacks: wired feedbacks: ${Object.keys(wiredFeedbacks).length}`);
}

// dist/stcontroller.js
import dgram2 from "dgram";
import os2 from "os";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger5 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, _onDeviceFound, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const found = /* @__PURE__ */ new Map();
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve(Array.from(found.values()));
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger5.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger5.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      ensureMembership(srcIp).then(() => {
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger5.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      }).catch((err) => logger5.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger5.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger5.warn(`Could not join announce multicast group: ${err}`);
      }
    });
  });
}

// dist/stcontroller.js
var logger6 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks;
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  constructor() {
    logger6.info("StController initialized");
    this.pendingAcks = /* @__PURE__ */ new Map();
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger6.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger6.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger6.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger6.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger6.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger6.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger6.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(this.model, CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    logger6.debug(`Raw response buffer: ${response.toString("hex")}`);
    logger6.debug(`Response length: ${response.length}`);
    const parsed = parseGetAllSettingsForModel(this.model, response);
    logger6.debug(`Parsed settings count: ${parsed.length}`);
    if (parsed.length > 0) {
      logger6.debug(`First few settings: ${JSON.stringify(parsed.slice(0, 3))}`);
    }
    const stateMap = /* @__PURE__ */ new Map();
    for (const setting of parsed) {
      const key = makeSettingId(this.model, setting.cmd_id, setting.id, setting.busCh);
      const value = setting.valueBytes.length === 3 ? setting.valueBytes[0] << 16 | setting.valueBytes[1] << 8 | setting.valueBytes[2] : setting.valueBytes[0] ?? 0;
      stateMap.set(key, value);
    }
    this.deviceState.set(deviceIp, stateMap);
    return response;
  }
  /** Return a snapshot of the current device state for a given IP (for feedbacks). */
  getDeviceState(deviceIp) {
    return this.deviceState.get(deviceIp) ?? /* @__PURE__ */ new Map();
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      foundDevices.push(device);
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(
        this.txSocket,
        onDeviceFound,
        // dante.ts doesn't actually use this, but kept for compatibility
        async (destIp) => this.ensureMembershipFor(destIp),
        timeoutMs
      );
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger6.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(this.model, CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false, 27);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger6.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    let minorStr;
    if (minor === 2) {
      minorStr = "2";
    } else if (minor < 10) {
      minorStr = minor.toString().padStart(2, "0");
    } else {
      minorStr = minor.toString();
    }
    const firmware = `${major}.${minorStr}`;
    logger6.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Ensure we've joined the multicast group on the interface that routes to destIp.
   * Option B behavior: join ONLY the interface used to reach the device.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger6.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger6.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger6.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger6.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(model, cmdId, busCh, settingId, value, destIp, addLen = true, msgType = 32) {
    const timeoutMs = 2e3;
    await this.ensureMembershipFor(destIp);
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (busCh !== void 0)
      payloadBody.push(busCh & 255);
    if (addLen)
      payloadBody.push(dataBlock.length);
    if (dataBlock.length > 0)
      payloadBody.push(...dataBlock);
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    const header = await _StController.buildHeader(destIp, msgType);
    const packet = Buffer.concat([header, payloadWithCrc]);
    const cmdName = getCommandName(cmdId);
    if (settingId !== void 0 && value !== void 0) {
      let action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
      if (!action) {
        action = this.actions.find((a) => {
          if (a.cmd_id !== cmdId)
            return false;
          const hasIdAdd = a.options?.some((opt) => opt.id === "idAdd");
          if (!hasIdAdd)
            return false;
          return settingId >= a.id && settingId < a.id + 10;
        });
      }
      let settingName = action?.name ?? "Unknown Setting";
      if (action) {
        const hasIdAdd = action.options?.some((opt) => opt.id === "idAdd");
        if (hasIdAdd && settingId !== action.id) {
          const channelOffset = settingId - action.id;
          settingName = `${settingName} Ch${channelOffset + 1}`;
        }
      }
      const valueOption = action?.options?.find((opt) => opt.id === "value");
      const choices = valueOption?.choices;
      const valueBytes = _StController.buildValueBytes(value);
      const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
      const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
      const cmdHex = toHex(cmdId);
      const idHex = toHex(settingId);
      const valHex = bytesToHex(valueBytes);
      const valDec = valueBytes.length === 1 ? valueBytes[0] : valueBytes.join(",");
      const prefix = `cmd:${cmdHex} id:${idHex} val:${valHex}`;
      const suffix = choiceLabel ? `${settingName}: ${choiceLabel} (${valDec})` : `${settingName}: ${valDec}`;
      logger6.info(`TX ${destIp} | ${prefix} | ${suffix}`);
    } else {
      logger6.info(`TX ${destIp} | ${cmdName}`);
    }
    logger6.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    await this.txReady;
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model${model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          if (this.refreshAfterCommand && settingId !== void 0) {
            this.requestAllSettings(destIp).catch((err) => {
              logger6.warn(`Failed to refresh settings after command: ${err}`);
            });
          }
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        for (const cb of this.discoveryListeners.values()) {
          try {
            cb(device);
          } catch {
          }
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    this.logStPayload(srcIp, originalCmdId, msg, stPayload, isResponse);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload, isResponse = true) {
    const cmdName = `cmd_${toHex(cmdId)}`;
    const data = stPayload.subarray(2, stPayload.length - 1);
    const magic = stPayload[0];
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[magic:${toHex(magic)} cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    const direction = isResponse ? "RX" : "SNIFF";
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue !== void 0 && prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger6.info(`${direction} ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              this.feedbackCallback(stateKey);
            }
          } else {
            logger6.debug(`${direction} ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger6.warn(`${direction} ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    if (decoded) {
      logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   *
   * msg is the full packet buffer — required by the settings parsers which
   * locate the Studio-T signature themselves.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  static async getMacForDestination(destIp) {
    return new Promise((resolve, reject) => {
      const tmp = dgram2.createSocket("udp4");
      tmp.once("error", (err) => {
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      });
      tmp.connect(9, destIp, () => {
        try {
          const addr = tmp.address();
          const localAddr = addr.address;
          tmp.close();
          const ifaces = os2.networkInterfaces();
          for (const name of Object.keys(ifaces)) {
            for (const iface of ifaces[name] ?? []) {
              if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
                return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
              }
            }
          }
          reject(new Error(`No interface found for local address ${localAddr}`));
        } catch (_e) {
          reject(new Error(String(_e)));
        }
      });
    });
  }
  static async buildHeader(destIp, msgType = 32) {
    const mac = await _StController.getMacForDestination(destIp);
    const msgTypeMsb = msgType >> 8 & 255;
    const msgTypeLsb = msgType & 255;
    return Buffer.concat([
      Buffer.from([255, 255, msgTypeMsb, msgTypeLsb, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(model, destIp) {
    return this.sendAwaitAck(model, CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(model, destIp) {
    return this.sendAwaitAck(model, CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger7 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Ok);
    this.runDiscovery().catch((e) => {
      logger7.error(`Discovery failed: ${e}`);
    });
    const effectiveModel = resolveModel(this.config, this.discoveredDevices);
    if (effectiveModel) {
      this.syncModel(effectiveModel);
    } else {
      logger7.warn("No model available - skipping model sync");
    }
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    const targetHost = this.host;
    if (targetHost && effectiveModel) {
      try {
        await this.stController.requestAllSettings(targetHost);
      } catch (e) {
        logger7.warn(`Failed to get all settings from ${targetHost}: ${e}`);
      }
    }
  }
  /**
   * Run device discovery in the background.
   * Updates discoveredDevices and refreshes config options when complete.
   */
  async runDiscovery() {
    logger7.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    if (this.discoveredDevices.length === 0) {
      logger7.warn("No devices discovered");
    } else {
      logger7.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger7.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger7.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger7.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
    }
    const effectiveModel = resolveModel(this.config, this.discoveredDevices);
    if (effectiveModel) {
      this.syncModel(effectiveModel);
    }
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableValues();
    logger7.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger7.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    const newHost = this.host;
    if (newHost && newHost !== previousHost) {
      try {
        await this.stController.requestAllSettings(newHost);
      } catch (e) {
        logger7.warn(`Failed to get all settings from ${newHost}: ${e}`);
      }
    }
  }
  /** Loads the device JSON for the given model and pushes it to the controller. */
  syncModel(model) {
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger7.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, [], true);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    const refreshAfterCommand = schema.refreshAfterCommand ?? true;
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger7.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger7.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}, refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  // Return config fields for web config — include discovered devices so the
  // dropdown is populated. Called by Companion on first load and after
  // setConfigSchemaVersion() triggers a refresh.
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, preferring the discovered device selection. */
  get host() {
    return resolveHost(this.config);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0aG9zdDogc3RyaW5nXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcblx0LyoqIElQIG9mIGEgZGlzY292ZXJlZCBEYW50ZSBkZXZpY2UsIG9yICcnIHdoZW4gdGhlIHVzZXIgY2hvb3NlcyBNYW51YWwgKi9cblx0ZGlzY292ZXJlZEhvc3Q6IHN0cmluZ1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBDRU5UUkFMSVpFRCBERVZJQ0UgU0NIRU1BIENBQ0hFXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBBbGwgZGV2aWNlIEpTT04gZmlsZXMgYXJlIGxvYWRlZCBvbmNlIGludG8gbWVtb3J5IGhlcmUuIE90aGVyIG1vZHVsZXMgc2hvdWxkXG4vLyB1c2UgZ2V0RGV2aWNlc0ZvbGRlcigpLCBnZXREZXZpY2VTY2hlbWFzKCksIGFuZCBnZXREZXZpY2VTY2hlbWEoKSBpbnN0ZWFkIG9mXG4vLyByZWFkaW5nIGZpbGVzIGRpcmVjdGx5LiBDYWxsIHJlbG9hZERldmljZVNjaGVtYXMoKSBhZnRlciB3cml0aW5nIHRvIGEgZmlsZS5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuLyoqXG4gKiBEZXRlcm1pbmVzIHRoZSBjb3JyZWN0IGRldmljZXMgZm9sZGVyIHBhdGggd2l0aCBmYWxsYmFjayBzdXBwb3J0LlxuICogQ2hlY2tzIHByaW1hcnkgcGF0aCBmaXJzdCwgdGhlbiBmYWxsYmFjaywgdGhlbiB0aHJvd3MgZXJyb3IgaWYgbmVpdGhlciBleGlzdHMuXG4gKi9cbmZ1bmN0aW9uIHJlc29sdmVEZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdGNvbnN0IHByaW1hcnlQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuLi9kZXZpY2VzJylcblx0Y29uc3QgZmFsbGJhY2tQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuL2RldmljZXMnKVxuXG5cdC8vIENoZWNrIHByaW1hcnkgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhwcmltYXJ5UGF0aCkpIHtcblx0XHRsb2dnZXIuZGVidWcoYFVzaW5nIGRldmljZXMgZm9sZGVyOiAke3ByaW1hcnlQYXRofWApXG5cdFx0cmV0dXJuIHByaW1hcnlQYXRoXG5cdH1cblxuXHQvLyBDaGVjayBmYWxsYmFjayBwYXRoXG5cdGlmIChmcy5leGlzdHNTeW5jKGZhbGxiYWNrUGF0aCkpIHtcblx0XHRsb2dnZXIud2FybihgUHJpbWFyeSBkZXZpY2VzIGZvbGRlciBub3QgZm91bmQsIHVzaW5nIGZhbGxiYWNrOiAke2ZhbGxiYWNrUGF0aH1gKVxuXHRcdHJldHVybiBmYWxsYmFja1BhdGhcblx0fVxuXG5cdC8vIE5laXRoZXIgcGF0aCBleGlzdHMgLSBmYXRhbCBlcnJvclxuXHRjb25zdCBlcnJvck1zZyA9IGBEZXZpY2VzIGZvbGRlciBub3QgZm91bmQhXFxuVHJpZWQ6XFxuICAtICR7cHJpbWFyeVBhdGh9XFxuICAtICR7ZmFsbGJhY2tQYXRofVxcbk1vZHVsZSBjYW5ub3QgY29udGludWUgd2l0aG91dCBkZXZpY2Ugc2NoZW1hcy5gXG5cdGxvZ2dlci5lcnJvcihlcnJvck1zZylcblx0dGhyb3cgbmV3IEVycm9yKGVycm9yTXNnKVxufVxuXG4vLyBSZXNvbHZlIHRoZSBkZXZpY2VzIGZvbGRlciBwYXRoICh3aXRoIGV4aXN0ZW5jZSBjaGVjayBhbmQgZmFsbGJhY2spXG5jb25zdCBkZXZpY2VzRm9sZGVyID0gcmVzb2x2ZURldmljZXNGb2xkZXIoKVxuXG4vLyBJbi1tZW1vcnkgY2FjaGUgb2YgYWxsIGRldmljZSBzY2hlbWFzLCBrZXllZCBieSBtb2RlbCBudW1iZXJcbmxldCBkZXZpY2VTY2hlbWFzQ2FjaGU6IFJlY29yZDxzdHJpbmcsIGFueT4gfCBudWxsID0gbnVsbFxuXG4vKipcbiAqIFJldHVybnMgdGhlIGFic29sdXRlIHBhdGggdG8gdGhlIGRldmljZXMgZm9sZGVyLlxuICogVXNlIHRoaXMgaW5zdGVhZCBvZiByZWRlZmluaW5nIHRoZSBwYXRoIGluIGV2ZXJ5IGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdHJldHVybiBkZXZpY2VzRm9sZGVyXG59XG5cbi8qKlxuICogTG9hZHMgYWxsIGRldmljZSBKU09OIGZpbGVzIGZyb20gdGhlIGRldmljZXMgZm9sZGVyIGludG8gbWVtb3J5LlxuICogVGhpcyBzaG91bGQgb25seSBiZSBjYWxsZWQgb25jZSBhdCBpbml0aWFsaXphdGlvbiwgb3IgYWZ0ZXIgYSBmaWxlIGlzIHdyaXR0ZW4uXG4gKi9cbmZ1bmN0aW9uIGxvYWREZXZpY2VTY2hlbWFzKCk6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRjb25zdCBzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge31cblx0dHJ5IHtcblx0XHRjb25zdCBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKGRldmljZXNGb2xkZXIpLmZpbHRlcigoZikgPT4gZi5lbmRzV2l0aCgnLmpzb24nKSlcblxuXHRcdGZvciAoY29uc3QgZiBvZiBmaWxlcykge1xuXHRcdFx0Y29uc3QgZnVsbFBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgZilcblx0XHRcdGNvbnN0IGpzb24gPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCwgJ3V0ZjgnKSlcblx0XHRcdGlmIChqc29uPy5tb2RlbCkge1xuXHRcdFx0XHRzY2hlbWFzW1N0cmluZyhqc29uLm1vZGVsKV0gPSBqc29uXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBMb2FkZWQgJHtPYmplY3Qua2V5cyhzY2hlbWFzKS5sZW5ndGh9IGRldmljZSBzY2hlbWFzIGludG8gY2FjaGVgKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmVycm9yKGBGYWlsZWQgdG8gbG9hZCBkZXZpY2Ugc2NoZW1hczogJHtlfWApXG5cdH1cblx0cmV0dXJuIHNjaGVtYXNcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIHRoZSBjYWNoZS5cbiAqIEluaXRpYWxpemVzIHRoZSBjYWNoZSBvbiBmaXJzdCBjYWxsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0aWYgKCFkZXZpY2VTY2hlbWFzQ2FjaGUpIHtcblx0XHRkZXZpY2VTY2hlbWFzQ2FjaGUgPSBsb2FkRGV2aWNlU2NoZW1hcygpXG5cdH1cblx0cmV0dXJuIGRldmljZVNjaGVtYXNDYWNoZVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBzcGVjaWZpYyBkZXZpY2Ugc2NoZW1hIGJ5IG1vZGVsIG51bWJlci5cbiAqIFJldHVybnMgdW5kZWZpbmVkIGlmIHRoZSBtb2RlbCBkb2Vzbid0IGV4aXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsOiBzdHJpbmcpOiBhbnkge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBzY2hlbWFzW21vZGVsXVxufVxuXG4vKipcbiAqIFJlbG9hZHMgYWxsIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay5cbiAqIENhbGwgdGhpcyBhZnRlciB3cml0aW5nIHRvIGEgZGV2aWNlIEpTT04gZmlsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbG9hZERldmljZVNjaGVtYXMoKTogdm9pZCB7XG5cdGxvZ2dlci5pbmZvKCdSZWxvYWRpbmcgZGV2aWNlIHNjaGVtYXMgZnJvbSBkaXNrLi4uJylcblx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBsaXN0IG9mIGF2YWlsYWJsZSBtb2RlbCBudW1iZXJzLCBzb3J0ZWQuXG4gKi9cbmZ1bmN0aW9uIGxvYWRBdmFpbGFibGVNb2RlbHMoKTogc3RyaW5nW10ge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBPYmplY3Qua2V5cyhzY2hlbWFzKS5zb3J0KClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEdldENvbmZpZ0ZpZWxkcyhkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW10pOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdGNvbnN0IG1vZGVscyA9IGxvYWRBdmFpbGFibGVNb2RlbHMoKVxuXG5cdC8vIEJ1aWxkIGNob2ljZXMgbWlycm9yaW5nIHRoZSBib25qb3VyLWRldmljZSBwYXR0ZXJuOlxuXHQvLyAgIGZpcnN0IGVudHJ5IGlzIGFsd2F5cyAnTWFudWFsJyAoZW1wdHkgdmFsdWUpXG5cdC8vICAgdGhlbiBvbmUgZW50cnkgcGVyIGRpc2NvdmVyZWQgZGV2aWNlXG5cdGNvbnN0IGRldmljZUNob2ljZXMgPSBbXG5cdFx0eyBpZDogJycsIGxhYmVsOiAnTWFudWFsJyB9LFxuXHRcdC4uLmRpc2NvdmVyZWREZXZpY2VzLm1hcCgoZCkgPT4gKHtcblx0XHRcdGlkOiBkLmlwLFxuXHRcdFx0bGFiZWw6IGBNb2RlbCAke2QubW9kZWx9ICgke2QuaXB9KWAsXG5cdFx0fSkpLFxuXHRdXG5cblx0cmV0dXJuIFtcblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2aWNlIGRpc2NvdmVyeSBkcm9wZG93biBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBNaXJyb3JzIHRoZSBib25qb3VyLWRldmljZSBmaWVsZDogc2VsZWN0aW5nIGEgZGV2aWNlIHBvcHVsYXRlcyB0aGVcblx0XHQvLyBob3N0IGF1dG9tYXRpY2FsbHk7IHNlbGVjdGluZyAnTWFudWFsJyBzaG93cyB0aGUgdGV4dGlucHV0IGJlbG93LlxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2Rpc2NvdmVyZWRIb3N0Jyxcblx0XHRcdGxhYmVsOiAnRGV2aWNlJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRjaG9pY2VzOiBkZXZpY2VDaG9pY2VzLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCBhbiBhdXRvLWRpc2NvdmVyZWQgU3R1ZGlvIFRlY2hub2xvZ2llcyBEYW50ZSBkZXZpY2UsIG9yIGNob29zZSBNYW51YWwgdG8gZW50ZXIgYW4gSVAgYWRkcmVzcy4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgTWFudWFsIElQIGVudHJ5IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIE9ubHkgdmlzaWJsZSB3aGVuIGRpc2NvdmVyZWRIb3N0IGlzICcnIChNYW51YWwgc2VsZWN0ZWQpLlxuXHRcdC8vIE1hdGNoZXMgdGhlIHBhdHRlcm4gZnJvbSB0aGUgYm9uam91ci1kZXZpY2UgZG9jcy5cblx0XHR7XG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGlkOiAnaG9zdCcsXG5cdFx0XHRsYWJlbDogJ1RhcmdldCBJUCcsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0cmVnZXg6IFJlZ2V4LklQLFxuXHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogYCEkKG9wdGlvbnM6ZGlzY292ZXJlZEhvc3QpYCxcblx0XHRcdHRvb2x0aXA6ICdFbnRlciB0aGUgSVAgYWRkcmVzcyBvZiB0aGUgZGV2aWNlIG1hbnVhbGx5LicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNb2RlbCBzZWxlY3RvciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBPbmx5IHZpc2libGUgd2hlbiBNYW51YWwgbW9kZSBpcyBzZWxlY3RlZCAobm8gZGlzY292ZXJlZCBkZXZpY2UpLlxuXHRcdC8vIFdoZW4gYSBkaXNjb3ZlcmVkIGRldmljZSBpcyBzZWxlY3RlZCwgdGhlIG1vZGVsIGlzIGF1dG8tZGV0ZWN0ZWQuXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnYWN0aXZlTW9kZWwnLFxuXHRcdFx0bGFiZWw6ICdBY3RpdmUgRGV2aWNlIE1vZGVsJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogbW9kZWxzWzBdID8/ICcnLFxuXHRcdFx0Y2hvaWNlczogbW9kZWxzLm1hcCgobW9kZWwpID0+ICh7XG5cdFx0XHRcdGlkOiBtb2RlbCxcblx0XHRcdFx0bGFiZWw6IGBNb2RlbCAke21vZGVsfWAsXG5cdFx0XHR9KSksXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkaXNjb3ZlcmVkSG9zdClgLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCB3aGljaCBTdHVkaW8gVGVjaG5vbG9naWVzIG1vZGVsIGlzIGFjdGl2ZSBmb3IgYWN0aW9ucyBhbmQgR2V0IEFsbCBTZXR0aW5ncycsXG5cdFx0fSxcblx0XVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQIGZyb20gY29uZmlnIFx1MjAxNCBwcmVmZXJzIHRoZSBkaXNjb3ZlcmVkIGRldmljZVxuICogSVAgd2hlbiBvbmUgaXMgc2VsZWN0ZWQsIGZhbGxzIGJhY2sgdG8gdGhlIG1hbnVhbGx5IGVudGVyZWQgaG9zdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVIb3N0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogc3RyaW5nIHtcblx0cmV0dXJuIGNvbmZpZy5kaXNjb3ZlcmVkSG9zdCB8fCBjb25maWcuaG9zdFxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBtb2RlbCBcdTIwMTQgaWYgYSBkaXNjb3ZlcmVkIGRldmljZSBpcyBzZWxlY3RlZCwgZXh0cmFjdHNcbiAqIGl0cyBtb2RlbCBmcm9tIHRoZSBkaXNjb3ZlcmVkRGV2aWNlcyBsaXN0OyBvdGhlcndpc2UgdXNlcyBhY3RpdmVNb2RlbC5cbiAqIFJldHVybnMgZW1wdHkgc3RyaW5nIGlmIG5vIGRldmljZXMgYXJlIGRpc2NvdmVyZWQgYW5kIHVzaW5nIGRpc2NvdmVyZWRIb3N0IG1vZGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlTW9kZWwoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRpc2NvdmVyZWRIb3N0KSB7XG5cdFx0Y29uc3QgZGV2aWNlID0gZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY29uZmlnLmRpc2NvdmVyZWRIb3N0KVxuXHRcdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBkaXNjb3ZlcmVkSG9zdD1cIiR7Y29uZmlnLmRpc2NvdmVyZWRIb3N0fVwiLCBmb3VuZCBkZXZpY2U6ICR7ZGV2aWNlPy5tb2RlbCA/PyAnbm9uZSd9YClcblx0XHRpZiAoZGV2aWNlPy5tb2RlbCkge1xuXHRcdFx0cmV0dXJuIGRldmljZS5tb2RlbFxuXHRcdH1cblx0XHQvLyBJZiB1c2luZyBkaXNjb3ZlcmVkSG9zdCBtb2RlIGJ1dCBubyBkZXZpY2UgZm91bmQsIGRvbid0IGZhbGwgYmFjayB0byBhY3RpdmVNb2RlbFxuXHRcdGlmIChkaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGggPT09IDApIHtcblx0XHRcdGxvZ2dlci53YXJuKGByZXNvbHZlTW9kZWw6IE5vIGRldmljZXMgZGlzY292ZXJlZCwgY2Fubm90IGRldGVybWluZSBtb2RlbGApXG5cdFx0XHRyZXR1cm4gJydcblx0XHR9XG5cdH1cblx0bG9nZ2VyLmRlYnVnKGByZXNvbHZlTW9kZWw6IGZhbGxpbmcgYmFjayB0byBhY3RpdmVNb2RlbD1cIiR7Y29uZmlnLmFjdGl2ZU1vZGVsfVwiYClcblx0cmV0dXJuIGNvbmZpZy5hY3RpdmVNb2RlbFxufVxuIiwgImltcG9ydCB0eXBlIE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcblxuLyoqXG4gKiBEZWZpbmUgQ29tcGFuaW9uIHZhcmlhYmxlcyBmb3IgdGhpcyBtb2R1bGUuXG4gKiBWYXJpYWJsZXMgY2FuIGJlIHVzZWQgdG8gZGlzcGxheSBkeW5hbWljIHN0YXRlIGluIGJ1dHRvbiBsYWJlbHMsIHRyaWdnZXJzLCBldGMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh7XG5cdFx0bW9kZWw6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOdW1iZXInIH0sXG5cdFx0bW9kZWxOYW1lOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTmFtZSAoRnVsbCBEZXNjcmlwdGlvbiknIH0sXG5cdFx0bWFudWZhY3R1cmVyOiB7IG5hbWU6ICdEZXZpY2UgTWFudWZhY3R1cmVyJyB9LFxuXHRcdGZpcm13YXJlOiB7IG5hbWU6ICdEZXZpY2UgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRkYW50ZUZXOiB7IG5hbWU6ICdEYW50ZSBNb2R1bGUgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRtYWM6IHsgbmFtZTogJ0RldmljZSBNQUMgQWRkcmVzcycgfSxcblx0XHRpcDogeyBuYW1lOiAnRGV2aWNlIElQIEFkZHJlc3MnIH0sXG5cdH0pXG59XG5cbi8qKlxuICogVXBkYXRlIHZhcmlhYmxlIHZhbHVlcyBmcm9tIGRpc2NvdmVyZWQgZGV2aWNlIGluZm9ybWF0aW9uLlxuICogQ2FsbCB0aGlzIGFmdGVyIGRldmljZSBkaXNjb3Zlcnkgb3Igd2hlbiBkZXZpY2UgaW5mbyBjaGFuZ2VzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlVmFyaWFibGVWYWx1ZXMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Ly8gRmluZCB0aGUgZGV2aWNlIGluZm8gZm9yIHRoZSBjdXJyZW50IGhvc3Rcblx0Y29uc3QgY3VycmVudEhvc3QgPSBzZWxmLmhvc3Rcblx0Y29uc3QgZGV2aWNlID0gc2VsZi5kZXZpY2VzLmZpbmQoKGQpID0+IGQuaXAgPT09IGN1cnJlbnRIb3N0KVxuXG5cdGlmIChkZXZpY2UpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdG1vZGVsOiBkZXZpY2UubW9kZWwgfHwgJ1Vua25vd24nLFxuXHRcdFx0bW9kZWxOYW1lOiBkZXZpY2UubW9kZWxOYW1lIHx8ICcnLFxuXHRcdFx0bWFudWZhY3R1cmVyOiBkZXZpY2UubWFudWZhY3R1cmVyIHx8ICcnLFxuXHRcdFx0ZmlybXdhcmU6IGRldmljZS5maXJtd2FyZU1haW4gfHwgJ1Vua25vd24nLFxuXHRcdFx0ZGFudGVGVzogZGV2aWNlLmRhbnRlRmlybXdhcmUgfHwgJ1Vua25vd24nLFxuXHRcdFx0bWFjOiBkZXZpY2UubWFjIHx8ICcnLFxuXHRcdFx0aXA6IGRldmljZS5pcCB8fCBjdXJyZW50SG9zdCxcblx0XHR9KVxuXHR9IGVsc2Uge1xuXHRcdC8vIE5vIGRldmljZSBpbmZvIGF2YWlsYWJsZSAtIHNob3cgbWluaW1hbCBpbmZvXG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7XG5cdFx0XHRtb2RlbDogc2VsZi5jb25maWcuYWN0aXZlTW9kZWwgfHwgJ1Vua25vd24nLFxuXHRcdFx0bW9kZWxOYW1lOiAnJyxcblx0XHRcdG1hbnVmYWN0dXJlcjogJycsXG5cdFx0XHRmaXJtd2FyZTogJ1Vua25vd24nLFxuXHRcdFx0ZGFudGVGVzogJ1Vua25vd24nLFxuXHRcdFx0bWFjOiAnJyxcblx0XHRcdGlwOiBjdXJyZW50SG9zdCxcblx0XHR9KVxuXHR9XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBDb21wYW5pb25TdGF0aWNVcGdyYWRlU2NyaXB0IH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbmV4cG9ydCBjb25zdCBVcGdyYWRlU2NyaXB0czogQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdDxNb2R1bGVDb25maWc+W10gPSBbXG5cdC8qXG5cdCAqIFBsYWNlIHlvdXIgdXBncmFkZSBzY3JpcHRzIGhlcmVcblx0ICogUmVtZW1iZXIgdGhhdCBvbmNlIGl0IGhhcyBiZWVuIGFkZGVkIGl0IGNhbm5vdCBiZSByZW1vdmVkIVxuXHQgKi9cblx0Ly8gZnVuY3Rpb24gKGNvbnRleHQsIHByb3BzKSB7XG5cdC8vIFx0cmV0dXJuIHtcblx0Ly8gXHRcdHVwZGF0ZWRDb25maWc6IG51bGwsXG5cdC8vIFx0XHR1cGRhdGVkQWN0aW9uczogW10sXG5cdC8vIFx0XHR1cGRhdGVkRmVlZGJhY2tzOiBbXSxcblx0Ly8gXHR9XG5cdC8vIH0sXG5dXG4iLCAiZXhwb3J0IHR5cGUgQ29tcGFuaW9uSW5wdXRDaG9pY2UgPSB7XG5cdGlkOiBzdHJpbmcgfCBudW1iZXJcblx0bGFiZWw6IHN0cmluZ1xufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VTZXR0aW5nID0ge1xuXHR0eXBlOiBzdHJpbmdcblx0bGFiZWw6IHN0cmluZ1xuXHRkZWZhdWx0OiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuXG5cdGNob2ljZXM/OiBDb21wYW5pb25JbnB1dENob2ljZVtdXG59XG5cbmV4cG9ydCB0eXBlIERldmljZUluZm8gPSB7XG5cdG1vZGVsOiBzdHJpbmcgLy8gTW9kZWwgbnVtYmVyIChlLmcuLCBcIjM3NEFcIilcblx0bW9kZWxOYW1lPzogc3RyaW5nIC8vIEZ1bGwgbW9kZWwgZGVzY3JpcHRpb24gKGUuZy4sIFwiTW9kZWwgMzc0QSBJbnRlcmNvbSBCZWx0cGFja1wiKVxuXHRpcDogc3RyaW5nXG5cdG5hbWU/OiBzdHJpbmcgLy8gRGFudGUgZGV2aWNlIG5hbWUgKHVzZXItY29uZmlndXJhYmxlIGxhYmVsLCBlLmcuIFwiU1QtTTM3NEEtQmVsdHBhY2tcIilcblx0bWFudWZhY3R1cmVyPzogc3RyaW5nIC8vIGUuZy4gXCJTdHVkaW8gVGVjaG5vbG9naWVzLCBJbmMuXCJcblx0ZmlybXdhcmVNYWluPzogc3RyaW5nIC8vIERldmljZSBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gRGFudGUgZGlzY292ZXJ5IChlLmcuLCBcIjQuOS4wXCIpXG5cdGRhbnRlRmlybXdhcmU/OiBzdHJpbmcgLy8gRGFudGUgbW9kdWxlIGZpcm13YXJlIHZlcnNpb25cblx0bWFjPzogc3RyaW5nXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBTdHVkaW8tVCBDb21tYW5kIElEIENvbnN0YW50cyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbmV4cG9ydCBjb25zdCBDTURfR0VUX0ZJUk1XQVJFID0gMHgwMCAvLyBSZXF1ZXN0IGRldmljZSBmaXJtd2FyZSB2ZXJzaW9uXG5leHBvcnQgY29uc3QgQ01EX0JVU19HRVQgPSAweDAzIC8vIEdldCBzZXR0aW5nIGZyb20gc3BlY2lmaWMgYnVzL2NoYW5uZWxcbmV4cG9ydCBjb25zdCBDTURfQlVTX1NFVCA9IDB4MDQgLy8gU2V0IHNldHRpbmcgb24gc3BlY2lmaWMgYnVzL2NoYW5uZWxcbmV4cG9ydCBjb25zdCBDTURfSEVBRFBIT05FID0gMHgwNSAvLyBIZWFkcGhvbmUgY29udHJvbHMgKHJlc2VydmVkIGZvciBmdXR1cmUgdXNlKVxuZXhwb3J0IGNvbnN0IENNRF9CVVRUT05fTU9ERSA9IDB4MDcgLy8gQnV0dG9uIG1vZGUgY29uZmlndXJhdGlvbiAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5leHBvcnQgY29uc3QgQ01EX1NZU1RFTSA9IDB4MDkgLy8gU3lzdGVtLWxldmVsIGNvbW1hbmRzIChyZXNlcnZlZCBmb3IgZnV0dXJlIHVzZSlcbmV4cG9ydCBjb25zdCBDTURfR0VUX0FMTF9TRVRUSU5HUyA9IDB4MGEgLy8gUmVxdWVzdCBhbGwgY3VycmVudCBzZXR0aW5ncyBmcm9tIGRldmljZVxuZXhwb3J0IGNvbnN0IENNRF9TRVRUSU5HU19QVVNIID0gMHgwYiAvLyBVbnNvbGljaXRlZCBzZXR0aW5ncyB1cGRhdGUgZnJvbSBkZXZpY2VcbmV4cG9ydCBjb25zdCBDTURfREVWX1NQRUMgPSAweDBkIC8vIERldmljZS1zcGVjaWZpYyBzZXR0aW5nIGdldC9zZXQgd2l0aCBBQ0tcbmV4cG9ydCBjb25zdCBDTURfUkVTRVRfREVWSUNFID0gMHgwZSAvLyBGYWN0b3J5IHJlc2V0IGNvbW1hbmRcbmV4cG9ydCBjb25zdCBDTURfR0xPQkFMX01JQ19LSUxMID0gMHgxMCAvLyBFbWVyZ2VuY3kgbWljIGtpbGwgKGFsbCBjaGFubmVscylcbmV4cG9ydCBjb25zdCBDTURfTUlDX1BSRV9CVVMgPSAweDEyIC8vIE1pYy9wcmVhbXAgc2V0dGluZ3MgcGVyIGJ1cyAoZ2FpbiwgcGhhbnRvbSwgZXRjKVxuZXhwb3J0IGNvbnN0IENNRF9DSEFOTkVMID0gMHgxNCAvLyBDaGFubmVsLXNwZWNpZmljIGNvbnRyb2xzIChyZXNlcnZlZCBmb3IgZnV0dXJlIHVzZSlcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIENvbW1hbmQgTmFtZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29tbWFuZE5hbWUoY21kSWQ6IG51bWJlcik6IHN0cmluZyB7XG5cdHN3aXRjaCAoY21kSWQpIHtcblx0XHRjYXNlIENNRF9HRVRfRklSTVdBUkU6XG5cdFx0XHRyZXR1cm4gJ0dldCBGaXJtd2FyZSBWZXJzaW9uJ1xuXHRcdGNhc2UgQ01EX0JVU19HRVQ6XG5cdFx0XHRyZXR1cm4gJ0dldCBCdXMgU2V0dGluZydcblx0XHRjYXNlIENNRF9CVVNfU0VUOlxuXHRcdFx0cmV0dXJuICdTZXQgQnVzIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfSEVBRFBIT05FOlxuXHRcdFx0cmV0dXJuICdIZWFkcGhvbmUgQ29udHJvbCdcblx0XHRjYXNlIENNRF9CVVRUT05fTU9ERTpcblx0XHRcdHJldHVybiAnQnV0dG9uIE1vZGUnXG5cdFx0Y2FzZSBDTURfU1lTVEVNOlxuXHRcdFx0cmV0dXJuICdTeXN0ZW0gQ29tbWFuZCdcblx0XHRjYXNlIENNRF9HRVRfQUxMX1NFVFRJTkdTOlxuXHRcdFx0cmV0dXJuICdSZXF1ZXN0IEFsbCBTZXR0aW5ncydcblx0XHRjYXNlIENNRF9TRVRUSU5HU19QVVNIOlxuXHRcdFx0cmV0dXJuICdTZXR0aW5ncyBQdXNoJ1xuXHRcdGNhc2UgQ01EX01JQ19QUkVfQlVTOlxuXHRcdFx0cmV0dXJuICdNaWMvUHJlIEJ1cydcblx0XHRjYXNlIENNRF9ERVZfU1BFQzpcblx0XHRcdHJldHVybiAnRGV2aWNlIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfQ0hBTk5FTDpcblx0XHRcdHJldHVybiAnQ2hhbm5lbCBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX1JFU0VUX0RFVklDRTpcblx0XHRcdHJldHVybiAnUmVzZXQgRGV2aWNlJ1xuXHRcdGNhc2UgQ01EX0dMT0JBTF9NSUNfS0lMTDpcblx0XHRcdHJldHVybiAnR2xvYmFsIE1pYyBLaWxsJ1xuXHRcdGRlZmF1bHQ6XG5cdFx0XHRyZXR1cm4gYGNtZF8weCR7Y21kSWQudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9YFxuXHR9XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBJRCBHZW5lcmF0aW9uIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogQ3JlYXRlcyBhIGNvbnNpc3RlbnQgSUQgZm9yIGFjdGlvbnMsIGZlZWRiYWNrcywgYW5kIHN0YXRlIGtleXMuXG4gKiBGb3JtYXQ6IGAke21vZGVsfV8ke2NtZF9pZH1fJHtidXNDaH1fJHtpZH1gIGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoIChlLmcuLCBcIjUzMDRfMTRfMF8wXCIpXG4gKiBGb3JtYXQ6IGAke21vZGVsfV8ke2NtZF9pZH1fJHtpZH1gIGZvciBjb21tYW5kcyB3aXRob3V0IGJ1c0NoIChlLmcuLCBcIjUzMDRfMTJfZFwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWFrZVNldHRpbmdJZChcblx0bW9kZWw6IHN0cmluZyxcblx0Y21kSWQ6IG51bWJlciB8IHN0cmluZyxcblx0c2V0dGluZ0lkOiBudW1iZXIgfCBzdHJpbmcsXG5cdGJ1c0NoPzogbnVtYmVyIHwgc3RyaW5nLFxuKTogc3RyaW5nIHtcblx0Y29uc3QgY21kID0gdHlwZW9mIGNtZElkID09PSAnbnVtYmVyJyA/IGNtZElkLnRvU3RyaW5nKDE2KSA6IGNtZElkXG5cdGNvbnN0IGlkID0gdHlwZW9mIHNldHRpbmdJZCA9PT0gJ251bWJlcicgPyBzZXR0aW5nSWQudG9TdHJpbmcoMTYpIDogc2V0dGluZ0lkXG5cblx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRjb25zdCBjaCA9IHR5cGVvZiBidXNDaCA9PT0gJ251bWJlcicgPyBidXNDaC50b1N0cmluZygxNikgOiBidXNDaFxuXHRcdHJldHVybiBgJHttb2RlbH1fJHtjbWR9XyR7Y2h9XyR7aWR9YFxuXHR9XG5cblx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtpZH1gXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBIZXggRm9ybWF0dGluZyBIZWxwZXJzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDb252ZXJ0cyBhIG51bWJlciB0byBhIGhleCBzdHJpbmcgd2l0aCAweCBwcmVmaXggYW5kIHBhZGRpbmcuXG4gKiBAcGFyYW0gdmFsdWUgLSBUaGUgbnVtYmVyIHRvIGNvbnZlcnRcbiAqIEBwYXJhbSBwYWRMZW5ndGggLSBOdW1iZXIgb2YgaGV4IGRpZ2l0cyB0byBwYWQgdG8gKGRlZmF1bHQ6IDIpXG4gKiBAcmV0dXJucyBGb3JtYXR0ZWQgaGV4IHN0cmluZyAoZS5nLiwgXCIweDBkXCIsIFwiMHhmZlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gdG9IZXgodmFsdWU6IG51bWJlciwgcGFkTGVuZ3RoID0gMik6IHN0cmluZyB7XG5cdHJldHVybiBgMHgke3ZhbHVlLnRvU3RyaW5nKDE2KS5wYWRTdGFydChwYWRMZW5ndGgsICcwJyl9YFxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIGFycmF5IG9mIGJ5dGVzIHRvIGEgaGV4IHN0cmluZyB3aXRoIDB4IHByZWZpeC5cbiAqIEBwYXJhbSBieXRlcyAtIEFycmF5IG9mIGJ5dGVzIG9yIEJ1ZmZlclxuICogQHJldHVybnMgRm9ybWF0dGVkIGhleCBzdHJpbmcgKGUuZy4sIFwiMHgwYWZmMTJcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJ5dGVzVG9IZXgoYnl0ZXM6IG51bWJlcltdIHwgQnVmZmVyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAweCR7QXJyYXkuZnJvbShieXRlcylcblx0XHQubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuXHRcdC5qb2luKCcnKX1gXG59XG5cbi8qKlxuICogRm9ybWF0cyBSR0IgY29sb3IgYnl0ZXMgYXMgYSBDU1MgaGV4IGNvbG9yIHN0cmluZy5cbiAqIEBwYXJhbSByIC0gUmVkIGNvbXBvbmVudCAoMC0yNTUpXG4gKiBAcGFyYW0gZyAtIEdyZWVuIGNvbXBvbmVudCAoMC0yNTUpXG4gKiBAcGFyYW0gYiAtIEJsdWUgY29tcG9uZW50ICgwLTI1NSlcbiAqIEByZXR1cm5zIENTUyBoZXggY29sb3Igc3RyaW5nIChlLmcuLCBcIiNGRjAwQUJcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFJnYkNvbG9yKHI6IG51bWJlciwgZzogbnVtYmVyLCBiOiBudW1iZXIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYCMke1tyLCBnLCBiXVxuXHRcdC5tYXAoKHYpID0+IHYudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0LmpvaW4oJycpXG5cdFx0LnRvVXBwZXJDYXNlKCl9YFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSUQgUGFyc2luZyBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIFBhcnNlcyBhIHNldHRpbmcgSUQgc3RyaW5nIGludG8gaXRzIGNvbXBvbmVudHMuXG4gKiBAcGFyYW0gaWQgLSBTZXR0aW5nIElEIHN0cmluZyAoZS5nLiwgXCIzOTFfZF8wXCIgb3IgXCI1MzA0XzE0XzBfMVwiKVxuICogQHJldHVybnMgUGFyc2VkIGNvbXBvbmVudHMgd2l0aCBoZXggc3RyaW5ncyBjb252ZXJ0ZWQgdG8gbnVtYmVyc1xuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VTZXR0aW5nSWQoaWQ6IHN0cmluZyk6IHsgbW9kZWw6IHN0cmluZzsgY21kSWQ6IG51bWJlcjsgYmFzZUlkOiBudW1iZXIgfSB7XG5cdGNvbnN0IFttb2RlbCwgY21kSWRTdHIsIGlkU3RyXSA9IGlkLnNwbGl0KCdfJylcblx0cmV0dXJuIHtcblx0XHRtb2RlbCxcblx0XHRjbWRJZDogcGFyc2VJbnQoY21kSWRTdHIsIDE2KSxcblx0XHRiYXNlSWQ6IHBhcnNlSW50KGlkU3RyLCAxNiksXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIE1vZGVsIERpc3RhbmNlIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogQ2FsY3VsYXRlcyBudW1lcmljIGRpc3RhbmNlIGJldHdlZW4gdHdvIG1vZGVsIG51bWJlcnMuXG4gKiBVc2VkIGZvciBmaW5kaW5nIHNpbWlsYXIgbW9kZWxzIGZvciBzZXR0aW5nIGluZmVyZW5jZS5cbiAqIEBwYXJhbSBtb2RlbEEgLSBGaXJzdCBtb2RlbCBudW1iZXIgKGUuZy4sIFwiMzkxXCIpXG4gKiBAcGFyYW0gbW9kZWxCIC0gU2Vjb25kIG1vZGVsIG51bWJlciAoZS5nLiwgXCIzOTJcIilcbiAqIEByZXR1cm5zIE51bWVyaWMgZGlzdGFuY2UgYmV0d2VlbiBtb2RlbHMsIG9yIEluZmluaXR5IGlmIGVpdGhlciBpcyBub24tbnVtZXJpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gbW9kZWxEaXN0YW5jZShtb2RlbEE6IHN0cmluZywgbW9kZWxCOiBzdHJpbmcpOiBudW1iZXIge1xuXHRjb25zdCBuYSA9IHBhcnNlSW50KG1vZGVsQS5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0Y29uc3QgbmIgPSBwYXJzZUludChtb2RlbEIucmVwbGFjZSgvXFxEL2csICcnKSwgMTApXG5cdGlmIChOdW1iZXIuaXNOYU4obmEpIHx8IE51bWJlci5pc05hTihuYikpIHJldHVybiBJbmZpbml0eVxuXHRyZXR1cm4gTWF0aC5hYnMobmEgLSBuYilcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFNjaGVtYSBOb3JtYWxpemF0aW9uIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogTm9ybWFsaXplcyBkZXZpY2Ugc2NoZW1hcyB0byBlbnN1cmUgY21kU2NoZW1hIGlzIGFsd2F5cyBhbiBhcnJheS5cbiAqIFRoaXMgaGVscGVyIGVsaW1pbmF0ZXMgZHVwbGljYXRlIHNjaGVtYSB0cmFuc2Zvcm1hdGlvbiBjb2RlLlxuICogQHBhcmFtIHNjaGVtYXNSYXcgLSBSYXcgc2NoZW1hcyBmcm9tIGdldERldmljZVNjaGVtYXMoKVxuICogQHJldHVybnMgTm9ybWFsaXplZCBzY2hlbWFzIHdpdGggZ3VhcmFudGVlZCBjbWRTY2hlbWEgYXJyYXlzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXROb3JtYWxpemVkU2NoZW1hcyhcblx0c2NoZW1hc1JhdzogUmVjb3JkPHN0cmluZywgYW55Pixcbik6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9PiB7XG5cdGNvbnN0IG5vcm1hbGl6ZWQ6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9PiA9IHt9XG5cdGZvciAoY29uc3QgW21vZGVsLCBqc29uXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzUmF3KSkge1xuXHRcdG5vcm1hbGl6ZWRbbW9kZWxdID0ge1xuXHRcdFx0bW9kZWw6IGpzb24ubW9kZWwsXG5cdFx0XHRjbWRTY2hlbWE6IEFycmF5LmlzQXJyYXkoanNvbi5jbWRTY2hlbWEpID8ganNvbi5jbWRTY2hlbWEgOiBbXSxcblx0XHR9XG5cdH1cblx0cmV0dXJuIG5vcm1hbGl6ZWRcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEFjdGlvbiBMb29rdXAgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBGaW5kcyBhbiBhY3Rpb24vc2V0dGluZyBpbiB0aGUgc2NoZW1hLCBzdXBwb3J0aW5nIGJvdGggZXhhY3QgbWF0Y2hlcyBhbmQgaWRBZGQgb2Zmc2V0cy5cbiAqIFRoaXMgaGVscGVyIGVsaW1pbmF0ZXMgZHVwbGljYXRlIGFjdGlvbiBsb29rdXAgbG9naWMgYWNyb3NzIG11bHRpcGxlIGZpbGVzLlxuICogQHBhcmFtIHNjaGVtYXMgLSBOb3JtYWxpemVkIGRldmljZSBzY2hlbWFzXG4gKiBAcGFyYW0gbW9kZWwgLSBEZXZpY2UgbW9kZWwgKGUuZy4sIFwiMzkxXCIpXG4gKiBAcGFyYW0gY21kSWQgLSBDb21tYW5kIElEXG4gKiBAcGFyYW0gc2V0dGluZ0lkIC0gU2V0dGluZyBJRCAobWF5IGluY2x1ZGUgaWRBZGQgb2Zmc2V0KVxuICogQHJldHVybnMgTWF0Y2hpbmcgYWN0aW9uL3NldHRpbmcgb3IgdW5kZWZpbmVkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmaW5kQWN0aW9uRm9yU2V0dGluZyhcblx0c2NoZW1hczogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+LFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyLFxuXHRzZXR0aW5nSWQ6IG51bWJlcixcbik6IGFueSB7XG5cdGNvbnN0IHNjaGVtYSA9IHNjaGVtYXNbbW9kZWxdXG5cdGlmICghc2NoZW1hIHx8ICFBcnJheS5pc0FycmF5KHNjaGVtYS5jbWRTY2hlbWEpKSByZXR1cm4gdW5kZWZpbmVkXG5cblx0Ly8gVHJ5IGV4YWN0IG1hdGNoIGZpcnN0XG5cdGxldCBhY3Rpb24gPSBzY2hlbWEuY21kU2NoZW1hLmZpbmQoKHM6IGFueSkgPT4gcy5jbWRfaWQgPT09IGNtZElkICYmIHMuaWQgPT09IHNldHRpbmdJZClcblxuXHQvLyBJZiBubyBleGFjdCBtYXRjaCwgdHJ5IHRvIGZpbmQgYmFzZSBhY3Rpb24gd2l0aCBpZEFkZFxuXHRpZiAoIWFjdGlvbikge1xuXHRcdGFjdGlvbiA9IHNjaGVtYS5jbWRTY2hlbWEuZmluZCgoczogYW55KSA9PiB7XG5cdFx0XHRpZiAocy5jbWRfaWQgIT09IGNtZElkKSByZXR1cm4gZmFsc2Vcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gcy5vcHRpb25zPy5maW5kKChvcHQ6IGFueSkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiBzZXR0aW5nSWQgbWF0Y2hlcyBiYXNlICsgYW55IGlkQWRkIG9mZnNldFxuXHRcdFx0Y29uc3Qgb2Zmc2V0ID0gc2V0dGluZ0lkIC0gcy5pZFxuXHRcdFx0cmV0dXJuIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYzogYW55KSA9PiBjLmlkID09PSBvZmZzZXQpXG5cdFx0fSlcblx0fVxuXG5cdHJldHVybiBhY3Rpb25cbn1cbiIsICIvKipcbiAqIGJ1aWxkLWNvbW1hbmRzLnRzXG4gKiAtIFVzZXMgY2VudHJhbGl6ZWQgZGV2aWNlIHNjaGVtYSBjYWNoZSBmcm9tIGNvbmZpZy50c1xuICogLSBQcm9kdWNlcyBDb21wYW5pb24gYWN0aW9uIGRlZmluaXRpb25zIGFuZCBmZWVkYmFja3NcbiAqL1xuXG5pbXBvcnQge1xuXHRDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyxcblx0Q29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbixcblx0Q29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyxcbn0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7IG1ha2VTZXR0aW5nSWQgfSBmcm9tICcuL3R5cGVzLmpzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuLyogLS0tLS0tIE9wdGlvbiBCdWlsZGVyIC0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbmZ1bmN0aW9uIGJ1aWxkT3B0aW9uKG86IGFueSk6IGFueSB7XG5cdGNvbnN0IGJhc2UgPSB7XG5cdFx0dHlwZTogby50eXBlLFxuXHRcdGlkOiBvLmlkLFxuXHRcdGxhYmVsOiBvLmxhYmVsLFxuXHRcdGRlZmF1bHQ6IG8uZGVmYXVsdCxcblx0XHR0b29sdGlwOiBvLnRvb2x0aXAsXG5cdH1cblxuXHRzd2l0Y2ggKG8udHlwZSkge1xuXHRcdGNhc2UgJ2Ryb3Bkb3duJzpcblx0XHRcdHJldHVybiB7IC4uLmJhc2UsIGNob2ljZXM6IG8uY2hvaWNlcyA/PyBbXSB9XG5cblx0XHRjYXNlICdudW1iZXInOlxuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0Li4uYmFzZSxcblx0XHRcdFx0bWluOiBvLm1pbixcblx0XHRcdFx0bWF4OiBvLm1heCxcblx0XHRcdFx0c3RlcDogby5zdGVwID8/IDEsXG5cdFx0XHRcdHJhbmdlOiB0cnVlLFxuXHRcdFx0fVxuXG5cdFx0Y2FzZSAnY2hlY2tib3gnOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgZGVmYXVsdDogby5kZWZhdWx0ID8/IGZhbHNlIH1cblxuXHRcdGNhc2UgJ3RleHRpbnB1dCc6XG5cdFx0Y2FzZSAnY29sb3JwaWNrZXInOlxuXHRcdGNhc2UgJ3N0YXRpYy10ZXh0Jzpcblx0XHRkZWZhdWx0OlxuXHRcdFx0cmV0dXJuIGJhc2Vcblx0fVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tIEFjdGlvbnMgLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEFjdGlvbnMoKTogQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IGFjdGlvbnM6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3QgYSBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdGNvbnN0IGFjdGlvbklkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgYS5jbWRfaWQsIGEuaWQpXG5cblx0XHRcdGNvbnN0IG9wdGlvbnMgPSAoYS5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdGNvbnN0IGFjdGlvbjogQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbiA9IHtcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7bW9kZWx9XSAke2EubmFtZX1gLFxuXHRcdFx0XHRvcHRpb25zLFxuXHRcdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRcdC8qIHdpcmVkIGxhdGVyIGluIFVwZGF0ZUFjdGlvbnMgKi9cblx0XHRcdFx0fSxcblx0XHRcdH1cblxuXHRcdFx0YWN0aW9uc1thY3Rpb25JZF0gPSBhY3Rpb25cblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gYWN0aW9uc1xufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tIEZlZWRiYWNrcyAtLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEZlZWRiYWNrcygpOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBmZWVkYmFja3M6IENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMgPSB7fVxuXG5cdGZvciAoY29uc3QgW21vZGVsLCBzY2hlbWFdIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXMpKSB7XG5cdFx0Y29uc3QgY21kU2NoZW1hID0gc2NoZW1hLmNtZFNjaGVtYVxuXHRcdGlmICghQXJyYXkuaXNBcnJheShjbWRTY2hlbWEpKSBjb250aW51ZVxuXG5cdFx0Zm9yIChjb25zdCBzZXR0aW5nIG9mIGNtZFNjaGVtYSkge1xuXHRcdFx0Y29uc3QgYmFzZUZlZWRiYWNrSWQgPSBtYWtlU2V0dGluZ0lkKG1vZGVsLCBzZXR0aW5nLmNtZF9pZCwgc2V0dGluZy5pZClcblxuXHRcdFx0Ly8gQnVpbGQgb3B0aW9uc1xuXHRcdFx0Y29uc3QgYWxsT3B0aW9ucyA9IChzZXR0aW5nLm9wdGlvbnMgPz8gW10pLm1hcChidWlsZE9wdGlvbilcblxuXHRcdFx0Ly8gRmlsdGVyIG91dCAndmFsdWUnIG9wdGlvbiBmb3IgdmFsdWUgZmVlZGJhY2sgKGtlZXAgb25seSBidXNDaC9pZEFkZClcblx0XHRcdGNvbnN0IHZhbHVlT3B0aW9ucyA9IGFsbE9wdGlvbnMuZmlsdGVyKChvcHQ6IGFueSkgPT4gb3B0LmlkICE9PSAndmFsdWUnKVxuXG5cdFx0XHQvLyBBZGQgYSBjaGVja2JveCBvcHRpb24gdG8gcmV0dXJuIGxhYmVsIGluc3RlYWQgb2YgdmFsdWVcblx0XHRcdHZhbHVlT3B0aW9ucy5wdXNoKHtcblx0XHRcdFx0dHlwZTogJ2NoZWNrYm94Jyxcblx0XHRcdFx0aWQ6ICdzaG93TGFiZWwnLFxuXHRcdFx0XHRsYWJlbDogJ1Nob3cgTGFiZWwnLFxuXHRcdFx0XHRkZWZhdWx0OiBmYWxzZSxcblx0XHRcdFx0dG9vbHRpcDogJ1JldHVybiB0aGUgbGFiZWwgdGV4dCBpbnN0ZWFkIG9mIHRoZSBudW1lcmljIHZhbHVlJyxcblx0XHRcdH0pXG5cblx0XHRcdC8vIFZhbHVlIGZlZWRiYWNrIGZvciBhbGwgc2V0dGluZ3MgKGFwcGVhcnMgaW4gVmFyaWFibGVzIGxpc3QpXG5cdFx0XHRjb25zdCB2YWx1ZUZlZWRiYWNrOiBhbnkgPSB7XG5cdFx0XHRcdHR5cGU6ICd2YWx1ZScsXG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHtzZXR0aW5nLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9uczogdmFsdWVPcHRpb25zLFxuXHRcdFx0XHRjYWxsYmFjazogKCkgPT4ge1xuXHRcdFx0XHRcdC8qIHdpcmVkIGxhdGVyIGluIFVwZGF0ZUZlZWRiYWNrcyAqL1xuXHRcdFx0XHRcdHJldHVybiAwXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGZlZWRiYWNrc1tiYXNlRmVlZGJhY2tJZF0gPSB2YWx1ZUZlZWRiYWNrXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGZlZWRiYWNrc1xufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQgeyBidWlsZEFjdGlvbnMgfSBmcm9tICcuL2J1aWxkLWNvbW1hbmRzLmpzJ1xuaW1wb3J0IHsgcmVzb2x2ZU1vZGVsLCBnZXREZXZpY2VzRm9sZGVyLCBnZXREZXZpY2VTY2hlbWEsIGdldERldmljZVNjaGVtYXMsIHJlbG9hZERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IHBhcnNlU2V0dGluZ0lkLCBnZXROb3JtYWxpemVkU2NoZW1hcyB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcblxuaW1wb3J0IHsgcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24sIHNhdmVNb2RlbEpzb25QcmV0dHksIHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyB9IGZyb20gJy4vc2V0dGluZ3NQYXJzZXIuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQWN0aW9ucycpXG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVBY3Rpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IHNjaGVtYXNSYXcgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgcmF3QWN0aW9ucyA9IGJ1aWxkQWN0aW9ucygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEFjdGlvbnM6IGFueSA9IHt9XG5cblx0Ly8gR2V0IHRoZSBhY3RpdmUgbW9kZWwgdXNpbmcgcmVzb2x2ZU1vZGVsXG5cdGNvbnN0IGFjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKHNlbGYuY29uZmlnLCBzZWxmLmRldmljZXMpXG5cdGxvZ2dlci5pbmZvKFxuXHRcdGBVcGRhdGVBY3Rpb25zOiBhY3RpdmVNb2RlbD1cIiR7YWN0aXZlTW9kZWx9XCIsIGRpc2NvdmVyZWRIb3N0PVwiJHtzZWxmLmNvbmZpZy5kaXNjb3ZlcmVkSG9zdH1cIiwgZGV2aWNlcyBjb3VudD0ke3NlbGYuZGV2aWNlcy5sZW5ndGh9YCxcblx0KVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgR0xPQkFMOiBHRVQgQUxMIFNFVFRJTkdTIChBVVRPIEpTT04gVVBEQVRFKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHR3aXJlZEFjdGlvbnNbJ2dsb2JhbF9nZXRBbGxTZXR0aW5ncyddID0ge1xuXHRcdG5hbWU6ICdHTE9CQUw6IEdldCBBbGwgU2V0dGluZ3MgKEF1dG8tVXBkYXRlIEpTT04pJyxcblx0XHRvcHRpb25zOiBbXSxcblx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0Y29uc3QgbW9kZWwgPSBhY3RpdmVNb2RlbFxuXHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3RcblxuXHRcdFx0Y29uc3QgYnVmID0gYXdhaXQgc2VsZi5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKGlwKVxuXG5cdFx0XHQvLyBVc2UgY2VudHJhbGl6ZWQgY2FjaGUgdG8gZ2V0IHRoZSBzY2hlbWFcblx0XHRcdGxldCBtb2RlbEpzb24gPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0XHRpZiAoIW1vZGVsSnNvbikge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoYE1vZGVsICR7bW9kZWx9IHNjaGVtYSBub3QgZm91bmQgaW4gY2FjaGVgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0Ly8gUGFyc2Ugd2l0aCBhdXRvLWRldGVjdGlvblxuXHRcdFx0Y29uc3QgeyBzZXR0aW5nczogcGFyc2VkLCBkZXRlY3RlZFNlY3Rpb25lZCB9ID0gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24obW9kZWwsIGJ1Zilcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgcGFyc2VkIHJlcGx5OiAke0pTT04uc3RyaW5naWZ5KHBhcnNlZCl9YClcblxuXHRcdFx0Ly8gSWYgd2UgYXV0by1kZXRlY3RlZCB0aGUgZm9ybWF0LCBhZGQgaXQgdG8gdGhlIEpTT05cblx0XHRcdGlmIChkZXRlY3RlZFNlY3Rpb25lZCAhPT0gbnVsbCkge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBzZWN0aW9uZWQ9JHtkZXRlY3RlZFNlY3Rpb25lZH0sIGFkZGluZyB0byBtb2RlbCBKU09OYClcblx0XHRcdFx0bW9kZWxKc29uID0geyAuLi5tb2RlbEpzb24sIHNlY3Rpb25lZDogZGV0ZWN0ZWRTZWN0aW9uZWQgfVxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCB1cGRhdGVkID0gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKG1vZGVsSnNvbiwgcGFyc2VkLCBzY2hlbWFzKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBuZXcgQWN0aW9ucyBqc29uOiAke0pTT04uc3RyaW5naWZ5KHVwZGF0ZWQsIG51bGwsIDIpfWApXG5cblx0XHRcdC8vIFNhdmUgdGhlIHVwZGF0ZWQgSlNPTiB0byBkaXNrXG5cdFx0XHRjb25zdCBkZXZpY2VzRm9sZGVyID0gZ2V0RGV2aWNlc0ZvbGRlcigpXG5cdFx0XHRjb25zdCBzY2hlbWFQYXRoID0gcGF0aC5qb2luKGRldmljZXNGb2xkZXIsIGBNb2RlbCR7bW9kZWx9Lmpzb25gKVxuXHRcdFx0c2F2ZU1vZGVsSnNvblByZXR0eShzY2hlbWFQYXRoLCB1cGRhdGVkKVxuXG5cdFx0XHQvLyBSZWxvYWQgdGhlIGNhY2hlIGFmdGVyIHdyaXRpbmcgdG8gZmlsZVxuXHRcdFx0cmVsb2FkRGV2aWNlU2NoZW1hcygpXG5cblx0XHRcdGxvZ2dlci5pbmZvKGBNb2RlbCAke21vZGVsfSBKU09OIGF1dG8tdXBkYXRlZCBmcm9tIGdldEFsbFNldHRpbmdzYClcblx0XHR9LFxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBCVUlMRCBQRVItU0VUVElORyBBQ1RJT05TIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2FjdGlvbklkLCBhY3Rpb25dIG9mIE9iamVjdC5lbnRyaWVzKHJhd0FjdGlvbnMpKSB7XG5cdFx0Y29uc3QgeyBtb2RlbCwgY21kSWQsIGJhc2VJZCB9ID0gcGFyc2VTZXR0aW5nSWQoYWN0aW9uSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgYWN0aW9ucyBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgbW9kZWxcblx0XHRpZiAobW9kZWwgIT09IGFjdGl2ZU1vZGVsKSBjb250aW51ZVxuXG5cdFx0Ly8gR2V0IHRoZSByYXcgYWN0aW9uIHNjaGVtYSB0byBhY2Nlc3MgZml4ZWQgYnVzQ2ggdmFsdWVcblx0XHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRcdGNvbnN0IHJhd0FjdGlvbiA9IHNjaGVtYT8uY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBiYXNlSWQpXG5cblx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0Li4uYWN0aW9uLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jIChldmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdC8vIFVzZSBidXNDaCBmcm9tIG9wdGlvbnMgaWYgcHJlc2VudCwgb3RoZXJ3aXNlIHVzZSBmaXhlZCB2YWx1ZSBmcm9tIHNjaGVtYVxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGV2ZW50Lm9wdGlvbnNbJ2J1c0NoJ10gIT09IHVuZGVmaW5lZCA/IGV2ZW50Lm9wdGlvbnNbJ2J1c0NoJ10gOiByYXdBY3Rpb24/LmJ1c0NoXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZXZlbnQub3B0aW9uc1sndmFsdWUnXVxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGV2ZW50Lm9wdGlvbnNbJ2lkQWRkJ10gPz8gMFxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBiYXNlSWQgKyBpZEFkZFxuXG5cdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnNlbmRBd2FpdEFjayhhY3RpdmVNb2RlbCwgY21kSWQsIGJ1c0NoLCBzZXR0aW5nSWQsIHZhbHVlLCBpcClcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBNSUMgS0lMTCAoT05MWSBJRiBBQ1RJVkUgTU9ERUwgU1VQUE9SVFMgSVQpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRjb25zdCBhY3RpdmVTY2hlbWEgPSBzY2hlbWFzW2FjdGl2ZU1vZGVsXVxuXHRpZiAoYWN0aXZlU2NoZW1hKSB7XG5cdFx0Y29uc3Qgc3VwcG9ydHNNaWNLaWxsID0gKGFjdGl2ZVNjaGVtYS5jbWRTY2hlbWEgPz8gW10pLnNvbWUoKGE6IGFueSkgPT4gYS5uYW1lLmluY2x1ZGVzKCdLaWxsJykpXG5cblx0XHRpZiAoc3VwcG9ydHNNaWNLaWxsKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IGAke2FjdGl2ZU1vZGVsfV9taWNLaWxsYFxuXG5cdFx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHthY3RpdmVNb2RlbH1dIE1pYyBLaWxsYCxcblx0XHRcdFx0b3B0aW9uczogW10sXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgTWljIEtpbGwgXHUyMTkyIE1vZGVsICR7YWN0aXZlTW9kZWx9IEAgJHtpcH1gKVxuXHRcdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLmdsb2JhbE1pY0tpbGwoYWN0aXZlTW9kZWwsIGlwKVxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdHNlbGYuc2V0QWN0aW9uRGVmaW5pdGlvbnMod2lyZWRBY3Rpb25zKVxuXG5cdGxvZ2dlci5pbmZvKGBVcGRhdGVBY3Rpb25zOiB3aXJlZCBhY3Rpb25zOiAke09iamVjdC5rZXlzKHdpcmVkQWN0aW9ucykubGVuZ3RofWApXG59XG4iLCAiaW1wb3J0IGZzIGZyb20gJ2ZzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHtcblx0Q01EX0JVU19TRVQsXG5cdENNRF9DSEFOTkVMLFxuXHRDTURfREVWX1NQRUMsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHR0b0hleCxcblx0Ynl0ZXNUb0hleCxcblx0Zm9ybWF0UmdiQ29sb3IsXG5cdG1vZGVsRGlzdGFuY2UsXG59IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU2V0dGluZ3NQYXJzZXInKVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBUWVBFU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgdHlwZSBQYXJzZWRTZXR0aW5nID0ge1xuXHRjbWRfaWQ6IG51bWJlclxuXHRpZDogbnVtYmVyXG5cdGJ1c0NoPzogbnVtYmVyIC8vIE9wdGlvbmFsOiBvbmx5IHByZXNlbnQgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKDB4MDQsIDB4MTIsIDB4MTQpXG5cdHZhbHVlQnl0ZXM6IG51bWJlcltdXG59XG5cbmV4cG9ydCB0eXBlIFN0QWN0aW9uT3B0aW9uID0ge1xuXHRpZD86IHN0cmluZ1xuXHRsYWJlbDogc3RyaW5nXG5cdHR5cGU6IHN0cmluZ1xuXHRkZWZhdWx0OiB1bmtub3duXG5cdHRvb2x0aXA/OiBzdHJpbmdcblx0Y2hvaWNlcz86IEFycmF5PHsgaWQ6IG51bWJlcjsgbGFiZWw6IHN0cmluZyB9PlxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbiA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRuYW1lOiBzdHJpbmdcblx0b3B0aW9uczogU3RBY3Rpb25PcHRpb25bXVxuXHRidXNDaD86IG51bWJlciAvLyBGaXhlZCBjaGFubmVsIHZhbHVlIGZvciBhY3Rpb25zIHRoYXQgZG9uJ3QgaGF2ZSBhIGNoYW5uZWwgb3B0aW9uXG59XG5cbmV4cG9ydCB0eXBlIFN0TW9kZWxKc29uID0ge1xuXHRtb2RlbDogc3RyaW5nXG5cdHNlY3Rpb25lZD86IGJvb2xlYW5cblx0cmVmcmVzaEFmdGVyQ29tbWFuZD86IGJvb2xlYW5cblx0Y21kU2NoZW1hOiBTdEFjdGlvbltdXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZPUk1BVCBIRUxQRVJTXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIGdldE1vZGVsQ29uZmlnKG1vZGVsOiBzdHJpbmcpOiB7IHNlY3Rpb25lZDogYm9vbGVhbjsgcmdiSWRzOiBTZXQ8bnVtYmVyPiB9IHtcblx0Y29uc3QgcmdiSWRzID0gbmV3IFNldDxudW1iZXI+KClcblx0bGV0IHNlY3Rpb25lZCA9IGZhbHNlXG5cblx0dHJ5IHtcblx0XHQvLyBVc2UgY2VudHJhbGl6ZWQgY2FjaGUgaW5zdGVhZCBvZiByZWFkaW5nIGZyb20gZGlza1xuXHRcdGNvbnN0IGpzb24gPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0aWYgKCFqc29uKSB7XG5cdFx0XHQvLyBJZiB3ZSBjYW4ndCBsb2FkIHRoZSBzY2hlbWEsIHJldHVybiBkZWZhdWx0c1xuXHRcdFx0cmV0dXJuIHsgc2VjdGlvbmVkLCByZ2JJZHMgfVxuXHRcdH1cblxuXHRcdC8vIFJlYWQgc2VjdGlvbmVkIHByb3BlcnR5IChkZWZhdWx0IHRvIGZhbHNlIGlmIG5vdCBzcGVjaWZpZWQpXG5cdFx0c2VjdGlvbmVkID0ganNvbi5zZWN0aW9uZWQgPz8gZmFsc2VcblxuXHRcdC8vIEJ1aWxkIFJHQiBJRHMgc2V0XG5cdFx0Zm9yIChjb25zdCBhY3Rpb24gb2YganNvbi5jbWRTY2hlbWEgfHwgW10pIHtcblx0XHRcdGNvbnN0IGhhc0NvbG9ycGlja2VyID0gYWN0aW9uLm9wdGlvbnM/LnNvbWUoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC50eXBlID09PSAnY29sb3JwaWNrZXInKVxuXHRcdFx0aWYgKGhhc0NvbG9ycGlja2VyKSB7XG5cdFx0XHRcdC8vIEFkZCB0aGUgYmFzZSBJRFxuXHRcdFx0XHRyZ2JJZHMuYWRkKGFjdGlvbi5pZClcblxuXHRcdFx0XHQvLyBJZiB0aGlzIGFjdGlvbiBoYXMgaWRBZGQgY2hvaWNlcywgYWRkIGFsbCB0aGUgb2Zmc2V0IElEcyB0b29cblx0XHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0OiBTdEFjdGlvbk9wdGlvbikgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRpZiAoaWRBZGRPcHRpb24/LmNob2ljZXMpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGNob2ljZSBvZiBpZEFkZE9wdGlvbi5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0XHRpZiAodHlwZW9mIGNob2ljZS5pZCA9PT0gJ251bWJlcicpIHtcblx0XHRcdFx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQgKyBjaG9pY2UuaWQpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIChfZXJyKSB7XG5cdFx0Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgc2NoZW1hLCByZXR1cm4gZGVmYXVsdHNcblx0fVxuXG5cdHJldHVybiB7IHNlY3Rpb25lZCwgcmdiSWRzIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRklORCBUSEUgUkVBTCA1QSBQQVlMT0FEIElOREVYXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIGV4dHJhY3RTdFBheWxvYWRJbmRleChidWY6IEJ1ZmZlcik6IG51bWJlciB7XG5cdGNvbnN0IHNpZ0luZGV4ID0gYnVmLmluZGV4T2YoQnVmZmVyLmZyb20oJ1N0dWRpby1UJykpXG5cdGlmIChzaWdJbmRleCA8IDApIHRocm93IG5ldyBFcnJvcignTm8gU3R1ZGlvLVQgc2lnbmF0dXJlIGluIHBhY2tldCcpXG5cblx0Y29uc3QgcGF5bG9hZEluZGV4ID0gc2lnSW5kZXggKyA4XG5cdGlmIChidWZbcGF5bG9hZEluZGV4XSAhPT0gMHg1YSkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgMHg1QSBhZnRlciBTdHVkaW8tVCwgZm91bmQgJHtidWZbcGF5bG9hZEluZGV4XS50b1N0cmluZygxNil9YClcblx0fVxuXG5cdHJldHVybiBwYXlsb2FkSW5kZXhcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRkxBVCBQQVJTRVJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gcGFyc2VGbGF0SWRWYWxTZXF1ZW5jZShibG9jazogQnVmZmVyLCByZ2JJZHM6IFNldDxudW1iZXI+ID0gbmV3IFNldCgpKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0bGV0IHAgPSAwXG5cdGNvbnN0IG91dDogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHR3aGlsZSAocCA8IGJsb2NrLmxlbmd0aCkge1xuXHRcdGNvbnN0IGlkID0gYmxvY2tbcF1cblx0XHRpZiAocCArIDEgPj0gYmxvY2subGVuZ3RoKSBicmVha1xuXG5cdFx0Ly8gUkdCIGNhc2UgLSBjaGVjayBpZiB0aGlzIElEIGlzIGEga25vd24gY29sb3JwaWNrZXJcblx0XHRpZiAocmdiSWRzLmhhcyhpZCkgJiYgcCArIDMgPCBibG9jay5sZW5ndGgpIHtcblx0XHRcdG91dC5wdXNoKHtcblx0XHRcdFx0Y21kX2lkOiBDTURfREVWX1NQRUMsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHR2YWx1ZUJ5dGVzOiBbYmxvY2tbcCArIDFdLCBibG9ja1twICsgMl0sIGJsb2NrW3AgKyAzXV0sXG5cdFx0XHR9KVxuXHRcdFx0cCArPSA0XG5cdFx0XHRjb250aW51ZVxuXHRcdH1cblxuXHRcdG91dC5wdXNoKHsgY21kX2lkOiBDTURfREVWX1NQRUMsIGlkLCB2YWx1ZUJ5dGVzOiBbYmxvY2tbcCArIDFdXSB9KVxuXHRcdHAgKz0gMlxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZjogQnVmZmVyLCBtb2RlbDogc3RyaW5nKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgYSBnZXRBbGxTZXR0aW5ncyByZXBseScpXG5cdH1cblxuXHRjb25zdCBibG9ja0xlbiA9IGJ1ZltpZHggKyAyXVxuXHRjb25zdCBzdGFydCA9IGlkeCArIDNcblx0Y29uc3QgZW5kID0gc3RhcnQgKyBibG9ja0xlblxuXHRpZiAoZW5kID4gYnVmLmxlbmd0aCkgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGJsb2NrIGxlbmd0aCcpXG5cblx0Y29uc3QgeyByZ2JJZHMgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gcGFyc2VGbGF0SWRWYWxTZXF1ZW5jZShidWYuc3ViYXJyYXkoc3RhcnQsIGVuZCksIHJnYklkcylcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0VDVElPTkVEIFBBUlNFUlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmOiBCdWZmZXIsIG1vZGVsOiBzdHJpbmcpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ05vdCBhIGdldEFsbFNldHRpbmdzIHJlcGx5Jylcblx0fVxuXG5cdC8vIENNRF9HRVRfQUxMX1NFVFRJTkdTIGhhcyBhIHRvdGFsLWxlbmd0aCBieXRlIGF0IGlkeCsyIGJlZm9yZSB0aGUgc2VjdGlvbnM7IENNRF9TRVRUSU5HU19QVVNIIGRvZXMgbm90LlxuXHRsZXQgcCA9IGNtZElkID09PSBDTURfR0VUX0FMTF9TRVRUSU5HUyA/IGlkeCArIDMgOiBpZHggKyAyXG5cdGNvbnN0IGVuZCA9IGJ1Zi5sZW5ndGggLSAxXG5cdGNvbnN0IG91dDogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHQvLyBHZXQgUkdCIElEcyBmb3IgdGhpcyBtb2RlbFxuXHRjb25zdCB7IHJnYklkcyB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cblx0Ly8gQ29tbWFuZCBJRHMgdGhhdCBpbmNsdWRlIGEgYnVzQ2ggYnl0ZSBpbiB0aGVpciBzZWN0aW9uIHN0cnVjdHVyZVxuXHRjb25zdCBjb21tYW5kc1dpdGhCdXNDaCA9IFtDTURfQlVTX1NFVCwgQ01EX01JQ19QUkVfQlVTLCBDTURfQ0hBTk5FTF1cblxuXHR3aGlsZSAocCArIDIgPCBlbmQpIHtcblx0XHRjb25zdCBjbWRMZW4gPSBidWZbcF1cblx0XHRjb25zdCBzZWN0aW9uQ21kSWQgPSBidWZbcCArIDFdXG5cblx0XHRjb25zdCBzZWN0aW9uRW5kID0gcCArIDEgKyBjbWRMZW5cblx0XHRpZiAoc2VjdGlvbkVuZCA+IGVuZCkgYnJlYWtcblxuXHRcdC8vIENoZWNrIGlmIHRoaXMgY29tbWFuZCBpbmNsdWRlcyBhIGJ1c0NoIGJ5dGVcblx0XHRjb25zdCBoYXNCdXNDaCA9IGNvbW1hbmRzV2l0aEJ1c0NoLmluY2x1ZGVzKHNlY3Rpb25DbWRJZClcblxuXHRcdGxldCBidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkXG5cdFx0bGV0IGRhdGFMZW46IG51bWJlclxuXHRcdGxldCBxOiBudW1iZXJcblxuXHRcdGlmIChoYXNCdXNDaCkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW2RhdGFMZW5dIFtpZDp2YWwgcGFpcnNdXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDNdXG5cdFx0XHRxID0gcCArIDQgLy8gRGF0YSBzdGFydHMgYWZ0ZXIgY21kTGVuLCBjbWRJZCwgYnVzQ2gsIGRhdGFMZW5cblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0ZGF0YUxlbiA9IGJ1ZltwICsgMl1cblx0XHRcdHEgPSBwICsgMyAvLyBEYXRhIHN0YXJ0cyBhZnRlciBjbWRMZW4sIGNtZElkLCBkYXRhTGVuXG5cdFx0fVxuXG5cdFx0Y29uc3QgcUVuZCA9IHEgKyBkYXRhTGVuXG5cblx0XHR3aGlsZSAocSArIDEgPCBxRW5kKSB7XG5cdFx0XHRjb25zdCBpZCA9IGJ1ZltxXVxuXHRcdFx0bGV0IHZhbHVlQnl0ZXM6IG51bWJlcltdXG5cblx0XHRcdC8vIENoZWNrIGlmIHRoaXMgSUQgaXMgYW4gUkdCIGNvbG9ycGlja2VyIChuZWVkcyAzIGJ5dGVzKVxuXHRcdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHEgKyAzIDwgcUVuZCkge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV0sIGJ1ZltxICsgMl0sIGJ1ZltxICsgM11dXG5cdFx0XHRcdHEgKz0gNFxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0dmFsdWVCeXRlcyA9IFtidWZbcSArIDFdXVxuXHRcdFx0XHRxICs9IDJcblx0XHRcdH1cblxuXHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHtcblx0XHRcdFx0Y21kX2lkOiBzZWN0aW9uQ21kSWQsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHR2YWx1ZUJ5dGVzLFxuXHRcdFx0fVxuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0c2V0dGluZy5idXNDaCA9IGJ1c0NoXG5cdFx0XHR9XG5cdFx0XHRvdXQucHVzaChzZXR0aW5nKVxuXHRcdH1cblxuXHRcdHAgPSBzZWN0aW9uRW5kXG5cdH1cblxuXHRyZXR1cm4gb3V0XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEdFTkVSSUMgU0VUVElOR1MgUkVTUE9OU0UgUEFSU0VSICgweDBhIGdldC1hbGwgKyAweDBiIHVuc29saWNpdGVkIHB1c2gpXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogUGFyc2VzIGFueSBmdWxsIHNldHRpbmdzIGJsb2NrIHJlZ2FyZGxlc3Mgb2Ygd2hldGhlciB0aGUgY21kSWQgaXMgMHgwYVxuICogKHJlc3BvbnNlIHRvIEdldCBBbGwgU2V0dGluZ3MpIG9yIDB4MGIgKHVuc29saWNpdGVkIHB1c2ggYWZ0ZXIgYSBzZXQpLlxuICogQm90aCB1c2UgdGhlIHNhbWUgc2VjdGlvbmVkIG9yIGZsYXQgYmxvY2sgbGF5b3V0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VTZXR0aW5nc1Jlc3BvbnNlKG1vZGVsOiBzdHJpbmcsIGJ1ZjogQnVmZmVyKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKGBOb3QgYSBzZXR0aW5ncyBibG9jayAoY21kSWQ9MHgke2NtZElkLnRvU3RyaW5nKDE2KX0pYClcblx0fVxuXHRjb25zdCB7IHNlY3Rpb25lZCB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cdHJldHVybiBzZWN0aW9uZWQgPyBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKSA6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxufVxuXG4vKipcbiAqIEZvcm1hdHMgYSBzaW5nbGUgcGFyc2VkIHNldHRpbmcgaW50byBhIGh1bWFuLXJlYWRhYmxlIHN0cmluZyB1c2luZyBhY3Rpb25cbiAqIGRlZmluaXRpb25zIGZyb20gdGhlIGRldmljZSBKU09OLiBGYWxscyBiYWNrIHRvIGhleCBJRHMgd2hlbiB1bmtub3duLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UGFyc2VkU2V0dGluZyhzZXR0aW5nOiBQYXJzZWRTZXR0aW5nLCBhY3Rpb25zOiBTdEFjdGlvbltdKTogc3RyaW5nIHtcblx0Ly8gVHJ5IGV4YWN0IG1hdGNoIGZpcnN0XG5cdGxldCBhY3Rpb24gPSBhY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBzZXR0aW5nLmNtZF9pZCAmJiBhLmlkID09PSBzZXR0aW5nLmlkKVxuXG5cdC8vIElmIG5vIGV4YWN0IG1hdGNoIGFuZCBpZCA+IGJhc2UgaWQsIHRyeSB0byBmaW5kIGFjdGlvbiB3aXRoIGlkQWRkIG9wdGlvblxuXHQvLyBUaGlzIGhhbmRsZXMgY2FzZXMgbGlrZSBjbWRfaWQgNSAoUGhvbmVzIFJvdXRpbmcpIGFuZCBjbWRfaWQgNyAoQnV0dG9ucylcblx0Ly8gd2hlcmUgaWQgMC0zIHJlcHJlc2VudHMgY2hhbm5lbHMgMS00XG5cdGlmICghYWN0aW9uKSB7XG5cdFx0Y29uc3QgYmFzZUFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBzZXR0aW5nLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIGFjdGlvbiBoYXMgYW4gaWRBZGQgb3B0aW9uIChpbmRpY2F0aW5nIGNoYW5uZWwgc2VsZWN0aW9uKVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGUgc2V0dGluZy5pZCBvZmZzZXQgbWF0Y2hlcyBvbmUgb2YgdGhlIGlkQWRkIGNob2ljZSBJRHNcblx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYS5pZFxuXHRcdFx0cmV0dXJuIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHR9KVxuXHRcdGlmIChiYXNlQWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSBiYXNlQWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0Y29uc3QgY21kSGV4ID0gdG9IZXgoc2V0dGluZy5jbWRfaWQpXG5cdGNvbnN0IGlkSGV4ID0gdG9IZXgoc2V0dGluZy5pZClcblx0Y29uc3QgdmFsSGV4ID0gYnl0ZXNUb0hleChzZXR0aW5nLnZhbHVlQnl0ZXMpXG5cdGNvbnN0IHZhbERlYyA9XG5cdFx0c2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0PyBmb3JtYXRSZ2JDb2xvcihzZXR0aW5nLnZhbHVlQnl0ZXNbMF0sIHNldHRpbmcudmFsdWVCeXRlc1sxXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzJdKVxuXHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxXG5cdFx0XHRcdD8gc2V0dGluZy52YWx1ZUJ5dGVzWzBdXG5cdFx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmpvaW4oJywnKVxuXG5cdC8vIEJ1aWxkIHRoZSBwcmVmaXg6IGNtZDoweDEyIGNoOjAgaWQ6MHgwMSB2YWw6MHgxNCAoY2ggb25seSBmb3IgY29tbWFuZHMgd2l0aCBidXNDaClcblx0Y29uc3QgYnVzQ2hTdHIgPSBzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQgPyBgIGNoOiR7c2V0dGluZy5idXNDaH1gIDogJydcblx0Y29uc3QgcHJlZml4ID0gYGNtZDoke2NtZEhleH0ke2J1c0NoU3RyfSBpZDoke2lkSGV4fSB2YWw6JHt2YWxIZXh9YFxuXG5cdC8vIElmIHdlIGhhdmUgYW4gYWN0aW9uIHdpdGggYSBuYW1lIGFuZCBjaG9pY2UgbGFiZWwsIHVzZSBpdFxuXHRpZiAoYWN0aW9uKSB7XG5cdFx0bGV0IG5hbWUgPSBhY3Rpb24ubmFtZVxuXG5cdFx0Ly8gSWYgc2V0dGluZyBoYXMgYnVzQ2gsIGFkZCBjaGFubmVsIGluZm8gdG8gbmFtZVxuXHRcdGlmIChzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdG5hbWUgPSBgJHtuYW1lfSBDaCR7c2V0dGluZy5idXNDaCArIDF9YFxuXHRcdH1cblx0XHQvLyBPdGhlcndpc2UsIGlmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCwgaW5jbHVkZSB0aGUgaWRBZGQgbGFiZWxcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYWN0aW9uLmlkXG5cdFx0XHRcdGNvbnN0IGlkQWRkQ2hvaWNlID0gaWRBZGRPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdFx0XHRpZiAoaWRBZGRDaG9pY2UpIHtcblx0XHRcdFx0XHRuYW1lID0gYCR7bmFtZX0gJHtpZEFkZENob2ljZS5sYWJlbH1gXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBMb29rIGZvciB0aGUgdmFsdWUgb3B0aW9uIChub3QgYnVzQ2ggb3IgaWRBZGQpXG5cdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdFx0aWYgKHZhbHVlT3B0aW9uPy5jaG9pY2VzICYmIHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRcdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gc2V0dGluZy52YWx1ZUJ5dGVzWzBdKVxuXHRcdFx0aWYgKGNob2ljZSkge1xuXHRcdFx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7Y2hvaWNlLmxhYmVsfSAoJHt2YWxEZWN9KWBcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke3ZhbERlY31gXG5cdH1cblxuXHQvLyBObyBhY3Rpb24gZm91bmQgLSBqdXN0IHNob3cgdGhlIHJhdyB2YWx1ZXNcblx0cmV0dXJuIGAke3ByZWZpeH0gfCBVbmtub3duIFNldHRpbmdgXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFBBUlNFUiBESVNQQVRDSCBXSVRIIEFVVE8tREVURUNUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogUGFyc2VzIGdldEFsbFNldHRpbmdzIHJlc3BvbnNlIHdpdGggYXV0b21hdGljIGZvcm1hdCBkZXRlY3Rpb24uXG4gKlxuICogU3RyYXRlZ3k6XG4gKiAxLiBJZiBtb2RlbCBoYXMgZXhwbGljaXQgXCJzZWN0aW9uZWRcIiBwcm9wZXJ0eSwgdXNlIHRoYXRcbiAqIDIuIE90aGVyd2lzZSwgdHJ5IEZMQVQgcGFyc2VyIGZpcnN0IChpdCdzIHNpbXBsZXIpXG4gKiAzLiBJZiBGTEFUIHJldHVybnMgMCBzZXR0aW5ncywgdHJ5IFNFQ1RJT05FRCBwYXJzZXJcbiAqIDQuIFVzZSB3aGljaGV2ZXIgcGFyc2VyIHJldHVybnMgbW9yZSBzZXR0aW5nc1xuICpcbiAqIEByZXR1cm5zIHtzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdLCBkZXRlY3RlZFNlY3Rpb25lZDogYm9vbGVhbiB8IG51bGx9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbihcblx0bW9kZWw6IHN0cmluZyxcblx0YnVmOiBCdWZmZXIsXG4pOiB7IHNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW107IGRldGVjdGVkU2VjdGlvbmVkOiBib29sZWFuIHwgbnVsbCB9IHtcblx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRjb25zdCBkZWNsYXJlZFNlY3Rpb25lZCA9IHNjaGVtYT8uc2VjdGlvbmVkXG5cblx0Ly8gSWYgZXhwbGljaXRseSBkZWNsYXJlZCBpbiBKU09OLCB1c2UgdGhhdFxuXHRpZiAoZGVjbGFyZWRTZWN0aW9uZWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IHNldHRpbmdzID0gZGVjbGFyZWRTZWN0aW9uZWRcblx0XHRcdD8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbClcblx0XHRcdDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiBudWxsIH0gLy8gbnVsbCA9IHVzZWQgZGVjbGFyZWQgdmFsdWVcblx0fVxuXG5cdC8vIE5vIGRlY2xhcmF0aW9uIC0gdHJ5IGJvdGggcGFyc2VycyBhbmQgcGljayB0aGUgYmVzdCBvbmVcblx0bGV0IGZsYXRTZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdID0gW11cblx0bGV0IHNlY3Rpb25lZFNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdHRyeSB7XG5cdFx0ZmxhdFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZGVidWcoYEZsYXQgcGFyc2VyIGZhaWxlZDogJHtlfWApXG5cdH1cblxuXHR0cnkge1xuXHRcdHNlY3Rpb25lZFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5kZWJ1ZyhgU2VjdGlvbmVkIHBhcnNlciBmYWlsZWQ6ICR7ZX1gKVxuXHR9XG5cblx0Ly8gUGljayB0aGUgcGFyc2VyIHRoYXQgcmV0dXJuZWQgbW9yZSBzZXR0aW5nc1xuXHRpZiAoc2VjdGlvbmVkU2V0dGluZ3MubGVuZ3RoID4gZmxhdFNldHRpbmdzLmxlbmd0aCkge1xuXHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIFNFQ1RJT05FRCBmb3JtYXQgKHNlY3Rpb25lZD0ke3NlY3Rpb25lZFNldHRpbmdzLmxlbmd0aH0gdnMgZmxhdD0ke2ZsYXRTZXR0aW5ncy5sZW5ndGh9KWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IHNlY3Rpb25lZFNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogdHJ1ZSB9XG5cdH0gZWxzZSBpZiAoZmxhdFNldHRpbmdzLmxlbmd0aCA+IDApIHtcblx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBGTEFUIGZvcm1hdCAoZmxhdD0ke2ZsYXRTZXR0aW5ncy5sZW5ndGh9IHZzIHNlY3Rpb25lZD0ke3NlY3Rpb25lZFNldHRpbmdzLmxlbmd0aH0pYClcblx0XHRyZXR1cm4geyBzZXR0aW5nczogZmxhdFNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogZmFsc2UgfVxuXHR9IGVsc2Uge1xuXHRcdC8vIEJvdGggcGFyc2VycyByZXR1cm5lZCAwIHNldHRpbmdzXG5cdFx0bG9nZ2VyLndhcm4oYFdhcm5pbmc6IEJvdGggcGFyc2VycyByZXR1cm5lZCAwIHNldHRpbmdzIGZvciBtb2RlbCAke21vZGVsfWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IFtdLCBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9XG5cdH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbChtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IHsgc2VjdGlvbmVkIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHNlY3Rpb25lZCA/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpIDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG59XG5cbi8qIFx1MjcwNSBiYWNrd2FyZC1jb21wYXRpYmxlIGV4cG9ydCAqL1xuZXhwb3J0IGNvbnN0IHBhcnNlR2V0QWxsU2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWxcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVkFMVUUgXHUyMTkyIE9QVElPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlczogbnVtYmVyW10pOiBTdEFjdGlvbk9wdGlvbiB7XG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdHJldHVybiB7IGlkOiAndmFsdWUnLCBsYWJlbDogJ1ZhbHVlJywgdHlwZTogJ251bWJlcicsIGRlZmF1bHQ6IHZhbHVlQnl0ZXNbMF0gfVxuXHR9XG5cblx0aWYgKHZhbHVlQnl0ZXMubGVuZ3RoID09PSAzKSB7XG5cdFx0Y29uc3QgW3IsIGcsIGJdID0gdmFsdWVCeXRlc1xuXHRcdHJldHVybiB7XG5cdFx0XHRpZDogJ3ZhbHVlJyxcblx0XHRcdGxhYmVsOiAnQ29sb3InLFxuXHRcdFx0dHlwZTogJ2NvbG9ycGlja2VyJyxcblx0XHRcdGRlZmF1bHQ6IGZvcm1hdFJnYkNvbG9yKHIsIGcsIGIpLFxuXHRcdH1cblx0fVxuXG5cdHJldHVybiB7IGlkOiAndmFsdWUnLCBsYWJlbDogJ1ZhbHVlJywgdHlwZTogJ3JhdycsIGRlZmF1bHQ6IFsuLi52YWx1ZUJ5dGVzXSB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNNQVJUIEpTT04gVVBEQVRFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MoXG5cdG1vZGVsSnNvbjogU3RNb2RlbEpzb24sXG5cdHBhcnNlZDogUGFyc2VkU2V0dGluZ1tdLFxuXHRhbGxNb2RlbHM6IFJlY29yZDxzdHJpbmcsIFN0TW9kZWxKc29uPixcbik6IFN0TW9kZWxKc29uIHtcblx0Y29uc3Qgb3V0ID0gc3RydWN0dXJlZENsb25lKG1vZGVsSnNvbilcblxuXHQvLyBFbnN1cmUgY21kU2NoZW1hIGFycmF5IGV4aXN0c1xuXHRpZiAoIW91dC5jbWRTY2hlbWEpIHtcblx0XHRvdXQuY21kU2NoZW1hID0gW11cblx0fVxuXG5cdC8vIFNvcnQgb3RoZXIgbW9kZWxzIGJ5IG51bWVyaWMgZGlzdGFuY2UgdG8gY3VycmVudCBtb2RlbFxuXHRjb25zdCBjYW5kaWRhdGVzID0gT2JqZWN0LnZhbHVlcyhhbGxNb2RlbHMpXG5cdFx0LmZpbHRlcigobSkgPT4gbS5tb2RlbCAhPT0gbW9kZWxKc29uLm1vZGVsKSAvLyBleGNsdWRlIHNlbGZcblx0XHQuc29ydCgoYSwgYikgPT4gbW9kZWxEaXN0YW5jZShtb2RlbEpzb24ubW9kZWwsIGEubW9kZWwpIC0gbW9kZWxEaXN0YW5jZShtb2RlbEpzb24ubW9kZWwsIGIubW9kZWwpKVxuXG5cdGxvZ2dlci5pbmZvKGBVcGRhdGluZyBtb2RlbDogJHttb2RlbEpzb24ubW9kZWx9YClcblx0bG9nZ2VyLmRlYnVnKGBDYW5kaWRhdGVzIGZvciBpbmZlcmVuY2U6ICR7Y2FuZGlkYXRlcy5tYXAoKGMpID0+IGMubW9kZWwpLmpvaW4oJywgJyl9YClcblxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCwgdmFsdWVCeXRlcyB9IG9mIHBhcnNlZCkge1xuXHRcdGxldCBhY3Rpb24gPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0Ly8gVHJ5IGNhbmRpZGF0ZXMgaW4gb3JkZXIgb2YgcHJveGltaXR5XG5cdFx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0XHRjb25zdCBtYXRjaCA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdFx0XHRpZiAobWF0Y2gpIHtcblx0XHRcdFx0XHRhY3Rpb24gPSBzdHJ1Y3R1cmVkQ2xvbmUobWF0Y2gpXG5cdFx0XHRcdFx0YWN0aW9uLm5hbWUgPSBgJHttYXRjaC5uYW1lfSAoaW5mZXJyZWQgZnJvbSBNb2RlbCAke2MubW9kZWx9KWBcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgSW5mZXJyZWQgc2V0dGluZyAke3RvSGV4KGlkKX0gZnJvbSBNb2RlbCAke2MubW9kZWx9YClcblx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdGFjdGlvbiA9IHtcblx0XHRcdFx0Y21kX2lkLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0bmFtZTogYFVua25vd24gU2V0dGluZyAke3RvSGV4KGlkKS50b1VwcGVyQ2FzZSgpfWAsXG5cdFx0XHRcdG9wdGlvbnM6IFt2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcyldLFxuXHRcdFx0fVxuXHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBpbmZlciBzZXR0aW5nICR7dG9IZXgoaWQpfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGNvbnN0IG9wdCA9IGFjdGlvbi5vcHRpb25zPy5bMF1cblx0XHRcdGlmIChvcHQpIG9wdC5kZWZhdWx0ID0gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpLmRlZmF1bHRcblx0XHR9XG5cblx0XHQvLyBBdm9pZCBkdXBsaWNhdGVzXG5cdFx0Y29uc3QgZXhpc3RzID0gb3V0LmNtZFNjaGVtYS5zb21lKChhKSA9PiBhLmNtZF9pZCA9PT0gYWN0aW9uLmNtZF9pZCAmJiBhLmlkID09PSBhY3Rpb24uaWQpXG5cdFx0aWYgKCFleGlzdHMpIG91dC5jbWRTY2hlbWEucHVzaChhY3Rpb24pXG5cdH1cblxuXHRyZXR1cm4gb3V0XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNBVkVcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHNhdmVNb2RlbEpzb25QcmV0dHkoZmlsZVBhdGg6IHN0cmluZywganNvbk9iajogU3RNb2RlbEpzb24pOiB2b2lkIHtcblx0dHJ5IHtcblx0XHQvLyBFbnN1cmUgcHJvcGVyIGtleSBvcmRlcmluZzogbW9kZWwsIHNlY3Rpb25lZCAoaWYgcHJlc2VudCksIHJlZnJlc2hBZnRlckNvbW1hbmQsIGNtZFNjaGVtYVxuXHRcdGNvbnN0IG9yZGVyZWRPYmo6IGFueSA9IHsgbW9kZWw6IGpzb25PYmoubW9kZWwgfVxuXG5cdFx0Ly8gQWRkIHNlY3Rpb25lZCBrZXkgaWYgcHJlc2VudCAocmlnaHQgYWZ0ZXIgbW9kZWwpXG5cdFx0aWYgKCdzZWN0aW9uZWQnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmouc2VjdGlvbmVkID0ganNvbk9iai5zZWN0aW9uZWRcblx0XHR9XG5cblx0XHQvLyBBZGQgb3RoZXIga2V5cyBpbiBvcmRlclxuXHRcdGlmICgncmVmcmVzaEFmdGVyQ29tbWFuZCcgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5yZWZyZXNoQWZ0ZXJDb21tYW5kID0ganNvbk9iai5yZWZyZXNoQWZ0ZXJDb21tYW5kXG5cdFx0fVxuXHRcdGlmICgnY21kU2NoZW1hJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLmNtZFNjaGVtYSA9IGpzb25PYmouY21kU2NoZW1hXG5cdFx0fVxuXHRcdC8vIENvcHkgYW55IG90aGVyIGtleXMgdGhhdCBtaWdodCBleGlzdFxuXHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGpzb25PYmopKSB7XG5cdFx0XHRpZiAoIShrZXkgaW4gb3JkZXJlZE9iaikpIHtcblx0XHRcdFx0b3JkZXJlZE9ialtrZXldID0gKGpzb25PYmogYXMgYW55KVtrZXldXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ3VzdG9tIGZvcm1hdHRlcjoga2VlcCBjaG9pY2Ugb2JqZWN0cyBjb21wYWN0IG9uIG9uZSBsaW5lXG5cdFx0bGV0IGpzb24gPSBKU09OLnN0cmluZ2lmeShvcmRlcmVkT2JqLCBudWxsLCAyKVxuXG5cdFx0Ly8gUmVwbGFjZSBleHBhbmRlZCBjaG9pY2Ugb2JqZWN0cyB3aXRoIGNvbXBhY3Qgc2luZ2xlLWxpbmUgZm9ybWF0XG5cdFx0Ly8gTWF0Y2hlczoge1xcbiAgICAgICAgICAgIFwiaWRcIjogWCxcXG4gICAgICAgICAgICBcImxhYmVsXCI6IFwiWVwiXFxuICAgICAgICAgIH1cblx0XHQvLyBSZXBsYWNlcyB3aXRoOiB7IFwiaWRcIjogWCwgXCJsYWJlbFwiOiBcIllcIiB9XG5cdFx0anNvbiA9IGpzb24ucmVwbGFjZSgvXFx7XFxuXFxzK1wiaWRcIjpcXHMqKFxcZCspLFxcblxccytcImxhYmVsXCI6XFxzKlwiKFteXCJdKilcIlxcblxccytcXH0vZywgJ3sgXCJpZFwiOiAkMSwgXCJsYWJlbFwiOiBcIiQyXCIgfScpXG5cblx0XHRmcy53cml0ZUZpbGVTeW5jKGZpbGVQYXRoLCBqc29uICsgJ1xcbicsICd1dGY4Jylcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmlsZSBXcml0ZSBFcnJvcjogJHtlfWApXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgTE9BRCBERVZJQ0UgSlNPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIExvYWRzIHRoZSBhY3Rpb25zIGFycmF5IGZvciBhIGdpdmVuIG1vZGVsIGZyb20gdGhlIGNlbnRyYWxpemVkIGNhY2hlLlxuICogUmV0dXJucyBhbiBlbXB0eSBhcnJheSBpZiB0aGUgbW9kZWwgaXMgbm90IGZvdW5kLlxuICogQGRlcHJlY2F0ZWQgLSBUaGlzIGZ1bmN0aW9uIGlzIG5vIGxvbmdlciBuZWVkZWQuIFVzZSBnZXREZXZpY2VTY2hlbWEoKSBmcm9tIGNvbmZpZy50cyBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZEFjdGlvbnNGb3JNb2RlbChfZGV2aWNlc0ZvbGRlcjogc3RyaW5nLCBtb2RlbDogc3RyaW5nKTogU3RBY3Rpb25bXSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0cmV0dXJuIHNjaGVtYT8uY21kU2NoZW1hID8/IFtdXG59XG5cbi8qKlxuICogTG9hZHMgdGhlIG1vZGVsIGNvbmZpZ3VyYXRpb24gZnJvbSB0aGUgY2VudHJhbGl6ZWQgY2FjaGUuXG4gKiBAZGVwcmVjYXRlZCAtIFRoaXMgZnVuY3Rpb24gaXMgbm8gbG9uZ2VyIG5lZWRlZC4gVXNlIGdldERldmljZVNjaGVtYSgpIGZyb20gY29uZmlnLnRzIGluc3RlYWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsb2FkTW9kZWxDb25maWcoXG5cdF9kZXZpY2VzRm9sZGVyOiBzdHJpbmcsXG5cdG1vZGVsOiBzdHJpbmcsXG4pOiB7IGFjdGlvbnM6IFN0QWN0aW9uW107IHJlZnJlc2hBZnRlckNvbW1hbmQ6IGJvb2xlYW4gfSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0cmV0dXJuIHtcblx0XHRhY3Rpb25zOiBzY2hlbWE/LmNtZFNjaGVtYSA/PyBbXSxcblx0XHRyZWZyZXNoQWZ0ZXJDb21tYW5kOiBzY2hlbWE/LnJlZnJlc2hBZnRlckNvbW1hbmQgPz8gdHJ1ZSwgLy8gRGVmYXVsdCB0byB0cnVlIGlmIG5vdCBzcGVjaWZpZWRcblx0fVxufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQgeyBidWlsZEZlZWRiYWNrcyB9IGZyb20gJy4vYnVpbGQtY29tbWFuZHMuanMnXG5pbXBvcnQgeyByZXNvbHZlTW9kZWwsIGdldERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IHBhcnNlU2V0dGluZ0lkLCBnZXROb3JtYWxpemVkU2NoZW1hcywgZmluZEFjdGlvbkZvclNldHRpbmcgfSBmcm9tICcuL3R5cGVzLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdGZWVkYmFja3MnKVxuXG4vKipcbiAqIEhlbHBlciBmdW5jdGlvbiB0byBnZXQgbGFiZWwgZnJvbSBjaG9pY2VzIGJhc2VkIG9uIHZhbHVlXG4gKi9cbmZ1bmN0aW9uIGdldExhYmVsRm9yVmFsdWUoXG5cdHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9Pixcblx0bW9kZWw6IHN0cmluZyxcblx0Y21kSWQ6IG51bWJlcixcblx0c2V0dGluZ0lkOiBudW1iZXIsXG5cdHZhbHVlOiBudW1iZXIsXG4pOiBzdHJpbmcgfCBudW1iZXIge1xuXHRjb25zdCBzZXR0aW5nID0gZmluZEFjdGlvbkZvclNldHRpbmcoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQpXG5cdGlmICghc2V0dGluZyB8fCAhQXJyYXkuaXNBcnJheShzZXR0aW5nLm9wdGlvbnMpKSByZXR1cm4gdmFsdWVcblxuXHQvLyBGaW5kIHRoZSAndmFsdWUnIG9wdGlvbiB3aGljaCBjb250YWlucyB0aGUgY2hvaWNlc1xuXHRjb25zdCB2YWx1ZU9wdGlvbiA9IHNldHRpbmcub3B0aW9ucy5maW5kKChvcHQ6IGFueSkgPT4gb3B0LmlkID09PSAndmFsdWUnKVxuXHRpZiAoIXZhbHVlT3B0aW9uIHx8ICFBcnJheS5pc0FycmF5KHZhbHVlT3B0aW9uLmNob2ljZXMpKSByZXR1cm4gdmFsdWVcblxuXHQvLyBGaW5kIHRoZSBjaG9pY2Ugd2l0aCBtYXRjaGluZyBpZFxuXHRjb25zdCBjaG9pY2UgPSB2YWx1ZU9wdGlvbi5jaG9pY2VzLmZpbmQoKGM6IGFueSkgPT4gYy5pZCA9PT0gdmFsdWUpXG5cdHJldHVybiBjaG9pY2U/LmxhYmVsID8/IHZhbHVlXG59XG5cbi8qKlxuICogQnVpbGQgYW5kIHdpcmUgQ29tcGFuaW9uIGZlZWRiYWNrIGRlZmluaXRpb25zXG4gKiBQYXR0ZXJuIG1hdGNoZXMgYWN0aW9ucy50cyAtIGZpbHRlcnMgYnkgYWN0aXZlIG1vZGVsIGFuZCB3aXJlcyBjYWxsYmFja3NcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUZlZWRiYWNrcyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBzY2hlbWFzUmF3ID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IHJhd0ZlZWRiYWNrcyA9IGJ1aWxkRmVlZGJhY2tzKClcblx0Y29uc3Qgc2NoZW1hcyA9IGdldE5vcm1hbGl6ZWRTY2hlbWFzKHNjaGVtYXNSYXcpXG5cdGNvbnN0IHdpcmVkRmVlZGJhY2tzOiBhbnkgPSB7fVxuXG5cdC8vIEdldCB0aGUgYWN0aXZlIG1vZGVsIHVzaW5nIHJlc29sdmVNb2RlbFxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbChzZWxmLmNvbmZpZywgc2VsZi5kZXZpY2VzKVxuXHRsb2dnZXIuaW5mbyhcblx0XHRgVXBkYXRlRmVlZGJhY2tzOiBhY3RpdmVNb2RlbD1cIiR7YWN0aXZlTW9kZWx9XCIsIGRpc2NvdmVyZWRIb3N0PVwiJHtzZWxmLmNvbmZpZy5kaXNjb3ZlcmVkSG9zdH1cIiwgZGV2aWNlcyBjb3VudD0ke3NlbGYuZGV2aWNlcy5sZW5ndGh9YCxcblx0KVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgRkVFREJBQ0tTIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2ZlZWRiYWNrSWQsIGZlZWRiYWNrXSBvZiBPYmplY3QuZW50cmllcyhyYXdGZWVkYmFja3MpKSB7XG5cdFx0Y29uc3QgeyBtb2RlbCwgY21kSWQsIGJhc2VJZCB9ID0gcGFyc2VTZXR0aW5nSWQoZmVlZGJhY2tJZClcblxuXHRcdC8vIE9ubHkgaW5jbHVkZSBmZWVkYmFja3MgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIFZBTFVFIEZFRURCQUNLOiBSZXR1cm5zIGN1cnJlbnQgdmFsdWUgZm9yIGxvY2FsIHZhcmlhYmxlXG5cdFx0d2lyZWRGZWVkYmFja3NbZmVlZGJhY2tJZF0gPSB7XG5cdFx0XHQuLi5mZWVkYmFjayxcblx0XHRcdGNhbGxiYWNrOiAoZmVlZGJhY2tFdmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydidXNDaCddXG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblx0XHRcdFx0Y29uc3QgY3VycmVudCA9IHNlbGYuc3RDb250cm9sbGVyLmdldFNldHRpbmdWYWx1ZShpcCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cblx0XHRcdFx0Ly8gQ2hlY2sgaWYgdXNlciB3YW50cyBsYWJlbCBpbnN0ZWFkIG9mIG51bWVyaWMgdmFsdWVcblx0XHRcdFx0Y29uc3Qgc2hvd0xhYmVsID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydzaG93TGFiZWwnXSA/PyBmYWxzZVxuXG5cdFx0XHRcdGlmIChzaG93TGFiZWwgJiYgY3VycmVudCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Ly8gUmV0dXJuIHRoZSBsYWJlbCBmcm9tIGNob2ljZXNcblx0XHRcdFx0XHRyZXR1cm4gZ2V0TGFiZWxGb3JWYWx1ZShzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgY3VycmVudClcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFJldHVybiBudW1lcmljIHZhbHVlIGRpcmVjdGx5IGZvciBsb2NhbCB2YXJpYWJsZSAodHlwZTogJ3ZhbHVlJylcblx0XHRcdFx0cmV0dXJuIGN1cnJlbnQgPz8gMFxuXHRcdFx0fSxcblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEZlZWRiYWNrRGVmaW5pdGlvbnMod2lyZWRGZWVkYmFja3MpXG5cblx0bG9nZ2VyLmluZm8oYFVwZGF0ZUZlZWRiYWNrczogd2lyZWQgZmVlZGJhY2tzOiAke09iamVjdC5rZXlzKHdpcmVkRmVlZGJhY2tzKS5sZW5ndGh9YClcbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHtcblx0Q01EX0JVU19HRVQsXG5cdENNRF9CVVNfU0VULFxuXHRDTURfREVWX1NQRUMsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfR0VUX0ZJUk1XQVJFLFxuXHRDTURfR0xPQkFMX01JQ19LSUxMLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9SRVNFVF9ERVZJQ0UsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHRnZXRDb21tYW5kTmFtZSxcblx0bWFrZVNldHRpbmdJZCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdHR5cGUgRGV2aWNlSW5mbyxcbn0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7XG5cdHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCxcblx0cGFyc2VTZXR0aW5nc1Jlc3BvbnNlLFxuXHRmb3JtYXRQYXJzZWRTZXR0aW5nLFxuXHR0eXBlIFN0QWN0aW9uLFxufSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuaW1wb3J0IHtcblx0REFOVEVfTVNHX0lORk9fUkVTUE9OU0UsXG5cdHBhcnNlRGFudGVJbmZvUmVzcG9uc2UsXG5cdGRpc2NvdmVyRGV2aWNlcyxcblx0Z2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24sXG59IGZyb20gJy4vZGFudGUuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU3RDb250cm9sbGVyJylcblxuZXhwb3J0IGNsYXNzIFN0Q29udHJvbGxlciB7XG5cdHByaXZhdGUgcmVhZG9ubHkgZGVmYXVsdFBvcnQ6IG51bWJlciA9IDg3MDBcblx0cHJpdmF0ZSByZWFkb25seSBtdWx0aWNhc3RHcm91cCA9ICcyMjQuMC4wLjIzMSdcblx0cHJpdmF0ZSByZWFkb25seSByeFBvcnQgPSA4NzAyXG5cblx0cHJpdmF0ZSB0eFNvY2tldDogZGdyYW0uU29ja2V0XG5cdHByaXZhdGUgcnhTb2NrZXQ6IGRncmFtLlNvY2tldCAvLyBmb3IgcmVjZWl2aW5nIHJlc3BvbnNlcyAoODcwMilcblx0cHJpdmF0ZSBwZW5kaW5nQWNrczogTWFwPFxuXHRcdHN0cmluZyxcblx0XHR7IHJlc29sdmU6IChidWY6IEJ1ZmZlcikgPT4gdm9pZDsgcmVqZWN0OiAoZTogRXJyb3IpID0+IHZvaWQ7IHRpbWVyOiBOb2RlSlMuVGltZW91dCB9XG5cdD5cblx0cHJpdmF0ZSBqb2luZWRJbnRlcmZhY2VzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKSAvLyBsb2NhbCBJUHMgd2UndmUgam9pbmVkIG11bHRpY2FzdCBvblxuXG5cdC8qKiBSZXNvbHZlcyBvbmNlIHR4U29ja2V0IGlzIGJvdW5kIGFuZCByZWFkeSB0byBzZW5kICovXG5cdHByaXZhdGUgdHhSZWFkeTogUHJvbWlzZTx2b2lkPlxuXG5cdC8qKiBBY3RpdmUgZGV2aWNlIG1vZGVsIGFuZCBhY3Rpb24gZGVmaW5pdGlvbnMgZm9yIHNldHRpbmdzIGRlY29kaW5nICovXG5cdHByaXZhdGUgbW9kZWw6IHN0cmluZyA9ICcnXG5cdHByaXZhdGUgYWN0aW9uczogU3RBY3Rpb25bXSA9IFtdXG5cdHByaXZhdGUgcmVmcmVzaEFmdGVyQ29tbWFuZDogYm9vbGVhbiA9IHRydWUgLy8gRGVmYXVsdCB0byB0cnVlIChtb3N0IGRldmljZXMgbmVlZCBpdClcblxuXHQvKipcblx0ICogS25vd24gc3RhdGUgb2YgZXZlcnkgc2V0dGluZyBwZXIgZGV2aWNlIElQLlxuXHQgKiBLZXllZCBieSBJUCBcdTIxOTIgTWFwIG9mIFwiJHtjbWRJZH0vJHtzZXR0aW5nSWR9XCIgXHUyMTkyIGN1cnJlbnQgdmFsdWUgYnl0ZS5cblx0ICogUG9wdWxhdGVkIG9uIGNvbm5lY3QgdmlhIHJlcXVlc3RBbGxTZXR0aW5ncygpLCB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKS5cblx0ICogVXNlZCB0byBkaWZmIGluY29taW5nIHB1c2hlcyAoY2hhbmdlZCA9IGluZm8sIHVuY2hhbmdlZCA9IGRlYnVnKSBhbmQgZm9yIGZlZWRiYWNrcy5cblx0ICovXG5cdHByaXZhdGUgZGV2aWNlU3RhdGU6IE1hcDxzdHJpbmcsIE1hcDxzdHJpbmcsIG51bWJlcj4+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrcyByZWdpc3RlcmVkIGJ5IGRpc2NvdmVyRGV2aWNlcygpIFx1MjAxNCBrZXllZCBieSBzb3VyY2UgSVAgKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcnlMaXN0ZW5lcnM6IE1hcDxzdHJpbmcsIChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQ+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrIHRvIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlcyB3aGVuIHN0YXRlIGNoYW5nZXMgKi9cblx0cHJpdmF0ZSBmZWVkYmFja0NhbGxiYWNrPzogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZFxuXG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdGxvZ2dlci5pbmZvKCdTdENvbnRyb2xsZXIgaW5pdGlhbGl6ZWQnKVxuXG5cdFx0dGhpcy5wZW5kaW5nQWNrcyA9IG5ldyBNYXAoKVxuXG5cdFx0Ly8gU2VuZCBzb2NrZXQgXHUyMDE0IGJpbmQgdG8gZXBoZW1lcmFsIHBvcnQuIFJlc3BvbnNlcyBhbHdheXMgZ28gdG8gcnhTb2NrZXQgb25cblx0XHQvLyBwb3J0IDg3MDIgKERhbnRlIGhhcmRjb2RlcyB0aGUgcmVzcG9uc2UgZGVzdGluYXRpb24gcG9ydCB0byA4NzAyKS5cblx0XHR0aGlzLnR4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnR4UmVhZHkgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0dGhpcy50eFNvY2tldC5iaW5kKDAsICgpID0+IHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBUWCBzb2NrZXQgYm91bmQgdG8gcG9ydCAkeyh0aGlzLnR4U29ja2V0LmFkZHJlc3MoKSBhcyB7IHBvcnQ6IG51bWJlciB9KS5wb3J0fWApXG5cdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdHRoaXMudHhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBUWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdC8vIFJlY2VpdmUgc29ja2V0IC0gYmluZCB0byBhbGwgYWRkcmVzc2VzIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0c1xuXHRcdHRoaXMucnhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbGlzdGVuaW5nJywgKCkgPT4ge1xuXHRcdFx0Y29uc3QgYWRkciA9IHRoaXMucnhTb2NrZXQuYWRkcmVzcygpXG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBsaXN0ZW5pbmcgb24gJHtKU09OLnN0cmluZ2lmeShhZGRyKX1gKVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5zZXRNdWx0aWNhc3RMb29wYmFjayh0cnVlKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBSWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5oYW5kbGVJbmNvbWluZyhtc2csIHJpbmZvLmFkZHJlc3MpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoYEVycm9yIGhhbmRsaW5nIGluY29taW5nIG1lc3NhZ2U6ICR7X2V9YClcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gQmluZCB0byB3aWxkY2FyZCBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHMgZm9yIGpvaW5lZCBpbnRlcmZhY2VzXG5cdFx0dGhpcy5yeFNvY2tldC5iaW5kKHsgYWRkcmVzczogJzAuMC4wLjAnLCBwb3J0OiB0aGlzLnJ4UG9ydCB9LCAoKSA9PiB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBib3VuZCB0byAwLjAuMC4wOiR7dGhpcy5yeFBvcnR9YClcblx0XHR9KVxuXHR9XG5cblx0cHVibGljIGNsb3NlKCk6IHZvaWQge1xuXHRcdHRyeSB7XG5cdFx0XHRmb3IgKGNvbnN0IGxvY2FsQWRkciBvZiBBcnJheS5mcm9tKHRoaXMuam9pbmVkSW50ZXJmYWNlcykpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR0aGlzLnJ4U29ja2V0LmRyb3BNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy5yeFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFByb3ZpZGUgdGhlIGFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBzbyBpbmNvbWluZyBtZXNzYWdlc1xuXHQgKiBjYW4gYmUgZGVjb2RlZCBpbnRvIGh1bWFuLXJlYWRhYmxlIG5hbWVzLiBDYWxsIGZyb20gbWFpbi50cyBhZnRlciBjb25maWcgbG9hZC5cblx0ICovXG5cdHB1YmxpYyBzZXRNb2RlbChtb2RlbDogc3RyaW5nLCBhY3Rpb25zOiBTdEFjdGlvbltdLCByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xuXHRcdHRoaXMubW9kZWwgPSBtb2RlbFxuXHRcdHRoaXMuYWN0aW9ucyA9IGFjdGlvbnNcblx0XHR0aGlzLnJlZnJlc2hBZnRlckNvbW1hbmQgPSByZWZyZXNoQWZ0ZXJDb21tYW5kXG5cdH1cblxuXHQvKipcblx0ICogU2V0IGNhbGxiYWNrIHRvIHRyaWdnZXIgd2hlbiBkZXZpY2Ugc3RhdGUgY2hhbmdlcyAoZm9yIGZlZWRiYWNrcykuXG5cdCAqIENhbGwgZnJvbSBtYWluLnRzIHRvIHdpcmUgdXAgY2hlY2tGZWVkYmFja3MuXG5cdCAqL1xuXHRwdWJsaWMgc2V0RmVlZGJhY2tDYWxsYmFjayhjYWxsYmFjazogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZCk6IHZvaWQge1xuXHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayA9IGNhbGxiYWNrXG5cdH1cblxuXHQvKipcblx0ICogU2VuZCBhIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSByZXF1ZXN0IHRvIHRoZSBkZXZpY2UgYW5kIHN0b3JlIHRoZSByZXNwb25zZVxuXHQgKiBpbiBkZXZpY2VTdGF0ZS4gUmV0dXJucyB0aGUgcmF3IHJlc3BvbnNlIGJ1ZmZlciBmb3IgcGFyc2luZy5cblx0ICovXG5cdHB1YmxpYyBhc3luYyByZXF1ZXN0QWxsU2V0dGluZ3MoZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgYWxsIHNldHRpbmdzIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soXG5cdFx0XHR0aGlzLm1vZGVsLFxuXHRcdFx0Q01EX0dFVF9BTExfU0VUVElOR1MsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHRkZXZpY2VJcCxcblx0XHRcdGZhbHNlLFxuXHRcdClcblxuXHRcdC8vIERlYnVnOiBMb2cgdGhlIHJhdyByZXNwb25zZVxuXHRcdGxvZ2dlci5kZWJ1ZyhgUmF3IHJlc3BvbnNlIGJ1ZmZlcjogJHtyZXNwb25zZS50b1N0cmluZygnaGV4Jyl9YClcblx0XHRsb2dnZXIuZGVidWcoYFJlc3BvbnNlIGxlbmd0aDogJHtyZXNwb25zZS5sZW5ndGh9YClcblxuXHRcdC8vIFBhcnNlIGFuZCBzdG9yZSBpbiBkZXZpY2VTdGF0ZVxuXHRcdGNvbnN0IHBhcnNlZCA9IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCh0aGlzLm1vZGVsLCByZXNwb25zZSlcblx0XHRsb2dnZXIuZGVidWcoYFBhcnNlZCBzZXR0aW5ncyBjb3VudDogJHtwYXJzZWQubGVuZ3RofWApXG5cdFx0aWYgKHBhcnNlZC5sZW5ndGggPiAwKSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYEZpcnN0IGZldyBzZXR0aW5nczogJHtKU09OLnN0cmluZ2lmeShwYXJzZWQuc2xpY2UoMCwgMykpfWApXG5cdFx0fVxuXG5cdFx0Y29uc3Qgc3RhdGVNYXAgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpXG5cdFx0Zm9yIChjb25zdCBzZXR0aW5nIG9mIHBhcnNlZCkge1xuXHRcdFx0Y29uc3Qga2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzZXR0aW5nLmNtZF9pZCwgc2V0dGluZy5pZCwgc2V0dGluZy5idXNDaClcblx0XHRcdC8vIEZvciBSR0IgY29sb3JzICgzIGJ5dGVzKSwgcGFjayBpbnRvIHNpbmdsZSBudW1iZXI6IChSIDw8IDE2KSB8IChHIDw8IDgpIHwgQlxuXHRcdFx0Y29uc3QgdmFsdWUgPVxuXHRcdFx0XHRzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHRcdFx0PyAoc2V0dGluZy52YWx1ZUJ5dGVzWzBdIDw8IDE2KSB8IChzZXR0aW5nLnZhbHVlQnl0ZXNbMV0gPDwgOCkgfCBzZXR0aW5nLnZhbHVlQnl0ZXNbMl1cblx0XHRcdFx0XHQ6IChzZXR0aW5nLnZhbHVlQnl0ZXNbMF0gPz8gMClcblx0XHRcdHN0YXRlTWFwLnNldChrZXksIHZhbHVlKVxuXHRcdH1cblx0XHR0aGlzLmRldmljZVN0YXRlLnNldChkZXZpY2VJcCwgc3RhdGVNYXApIC8vIFJldHVybiBidWZmZXIgZm9yIGNhbGxlciB0byBwYXJzZSBpZiBuZWVkZWRcblx0XHRyZXR1cm4gcmVzcG9uc2Vcblx0fVxuXG5cdC8qKiBSZXR1cm4gYSBzbmFwc2hvdCBvZiB0aGUgY3VycmVudCBkZXZpY2Ugc3RhdGUgZm9yIGEgZ2l2ZW4gSVAgKGZvciBmZWVkYmFja3MpLiAqL1xuXHRwdWJsaWMgZ2V0RGV2aWNlU3RhdGUoZGV2aWNlSXA6IHN0cmluZyk6IE1hcDxzdHJpbmcsIG51bWJlcj4ge1xuXHRcdHJldHVybiB0aGlzLmRldmljZVN0YXRlLmdldChkZXZpY2VJcCkgPz8gbmV3IE1hcCgpXG5cdH1cblxuXHQvKipcblx0ICogRGlzY292ZXJzIFN0dWRpbyBUZWNobm9sb2dpZXMgRGFudGUgZGV2aWNlcyBvbiB0aGUgbG9jYWwgbmV0d29yay5cblx0ICpcblx0ICogU3RyYXRlZ3k6XG5cdCAqICBEYW50ZSBkZXZpY2VzIGJyb2FkY2FzdCBhIDEtc2Vjb25kIGFubm91bmNlIHRvIG11bHRpY2FzdCAyMjQuMC4wLjIzMzo4NzA4LlxuXHQgKiAgV2UgbGlzdGVuIG9uIHRoYXQgZ3JvdXAsIGNvbGxlY3Qgc291cmNlIElQcywgdGhlbiBzZW5kIGEgdW5pY2FzdCBkZXZpY2UgaW5mb1xuXHQgKiAgcmVxdWVzdCAoMHgwMDIwKSB0byBlYWNoIG5ldyBJUCBvbiBwb3J0IDg3MDAuIFRoZSBkZXZpY2UgcmVzcG9uZHMgdG8gb3VyIElQXG5cdCAqICBvbiBwb3J0IDg3MDIgKHJ4U29ja2V0KSwgd2hlcmUgaGFuZGxlSW5jb21pbmcoKSBwaWNrcyBpdCB1cCBhbmQgZmlyZXMgdGhlXG5cdCAqICBkaXNjb3ZlcnlMaXN0ZW5lcnMgY2FsbGJhY2suXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgZGlzY292ZXJEZXZpY2VzKHRpbWVvdXRNcyA9IDUwMDApOiBQcm9taXNlPERldmljZUluZm9bXT4ge1xuXHRcdC8vIFJlZ2lzdGVyIGxpc3RlbmVyIFx1MjAxNCBoYW5kbGVJbmNvbWluZygpIGZpcmVzIHRoaXMgZm9yIGVhY2ggMHgwMTcwIHJlc3BvbnNlXG5cdFx0Y29uc3QgRElTQ09WRVJZX0tFWSA9ICdfX2Rpc2NvdmVyeV9fJ1xuXHRcdGNvbnN0IGZvdW5kRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHRcdGNvbnN0IG9uRGV2aWNlRm91bmQgPSAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB7XG5cdFx0XHRmb3VuZERldmljZXMucHVzaChkZXZpY2UpXG5cdFx0fVxuXG5cdFx0Ly8gUmVnaXN0ZXIgdGhlIGNhbGxiYWNrIHNvIGhhbmRsZUluY29taW5nKCkgY2FuIGludm9rZSBpdCB3aGVuIDB4MDE3MCBhcnJpdmVzXG5cdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KERJU0NPVkVSWV9LRVksIG9uRGV2aWNlRm91bmQpXG5cblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0XHQvLyBkaXNjb3ZlckRldmljZXMoKSBpbiBkYW50ZS50cyBoYW5kbGVzIHRoZSBhbm5vdW5jZSBsaXN0ZW5pbmcgYW5kIHF1ZXJ5IHNlbmRpbmdcblx0XHRcdC8vIFJlc3BvbnNlcyBjb21lIGJhY2sgdG8gcnhTb2NrZXQgXHUyMTkyIGhhbmRsZUluY29taW5nKCkgXHUyMTkyIGRpc2NvdmVyeUxpc3RlbmVyc1xuXHRcdFx0YXdhaXQgZGlzY292ZXJEZXZpY2VzKFxuXHRcdFx0XHR0aGlzLnR4U29ja2V0LFxuXHRcdFx0XHRvbkRldmljZUZvdW5kLCAvLyBkYW50ZS50cyBkb2Vzbid0IGFjdHVhbGx5IHVzZSB0aGlzLCBidXQga2VwdCBmb3IgY29tcGF0aWJpbGl0eVxuXHRcdFx0XHRhc3luYyAoZGVzdElwKSA9PiB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKSxcblx0XHRcdFx0dGltZW91dE1zLFxuXHRcdFx0KVxuXHRcdFx0cmV0dXJuIGZvdW5kRGV2aWNlc1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5kZWxldGUoRElTQ09WRVJZX0tFWSlcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogUmVxdWVzdHMgZGV2aWNlIGZpcm13YXJlIHZlcnNpb24gdmlhIFN0dWRpby1UIHByb3RvY29sIChDTURfR0VUX0ZJUk1XQVJFKS5cblx0ICogUmV0dXJucyB0aGUgZmlybXdhcmUgdmVyc2lvbiBzdHJpbmcgKGUuZy4sIFwiMy4wMVwiLCBcIjIuMlwiLCBcIjEuMDVcIikuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2VJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0XHRsb2dnZXIuaW5mbyhgUmVxdWVzdGluZyBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soXG5cdFx0XHR0aGlzLm1vZGVsLFxuXHRcdFx0Q01EX0dFVF9GSVJNV0FSRSxcblx0XHRcdHVuZGVmaW5lZCxcblx0XHRcdHVuZGVmaW5lZCxcblx0XHRcdHVuZGVmaW5lZCxcblx0XHRcdGRldmljZUlwLFxuXHRcdFx0ZmFsc2UsXG5cdFx0XHQweDAwMWIsIC8vIEZpcm13YXJlIHJlcXVlc3QgbWVzc2FnZSB0eXBlXG5cdFx0KVxuXG5cdFx0Ly8gUmVzcG9uc2Ugc3RydWN0dXJlOiBbaGVhZGVyXSAweDVhIDB4ODAgW2Zpcm13YXJlX2RhdGFdIENSQ1xuXHRcdC8vIEZpcm13YXJlIGRhdGEgc3RhcnRzIGF0IGJ5dGUgMjYgKDI0LWJ5dGUgaGVhZGVyICsgMHg1YSArIDB4ODApXG5cdFx0Y29uc3QgZGF0YVN0YXJ0ID0gMjZcblxuXHRcdGlmIChyZXNwb25zZS5sZW5ndGggPCBkYXRhU3RhcnQgKyAzKSB7XG5cdFx0XHRsb2dnZXIud2FybihgRmlybXdhcmUgcmVzcG9uc2UgdG9vIHNob3J0OiAke3Jlc3BvbnNlLmxlbmd0aH0gYnl0ZXNgKVxuXHRcdFx0cmV0dXJuICdVbmtub3duJ1xuXHRcdH1cblxuXHRcdC8vIEZpcm13YXJlIGZvcm1hdDogW3Vua25vd25fYnl0ZSwgbWFqb3IsIG1pbm9yXVxuXHRcdGNvbnN0IG1ham9yID0gcmVzcG9uc2VbZGF0YVN0YXJ0ICsgMV1cblx0XHRjb25zdCBtaW5vciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDJdXG5cblx0XHQvLyBGb3JtYXQgYXMgbWFqb3IubWlub3Igd2l0aCBubyBzcGVjaWFsIHBhZGRpbmcgcnVsZXNcblx0XHQvLyBFeGFtcGxlczogMy4xXHUyMTkyXCIzLjAxXCIsIDIuMlx1MjE5MlwiMi4yXCIsIDUuNFx1MjE5MlwiNS4wNFwiLCAxLjVcdTIxOTJcIjEuMDVcIlxuXHRcdC8vIFBhdHRlcm46IGlmIG1pbm9yIDwgMTAgYW5kIG1pbm9yICE9IDIsIHBhZCB0byAyIGRpZ2l0c1xuXHRcdC8vIEFjdHVhbGx5IHNpbXBsZXI6IGFsd2F5cyBwYWQgc2luZ2xlIGRpZ2l0cyBFWENFUFQgMlxuXHRcdGxldCBtaW5vclN0cjogc3RyaW5nXG5cdFx0aWYgKG1pbm9yID09PSAyKSB7XG5cdFx0XHRtaW5vclN0ciA9ICcyJyAvLyBTcGVjaWFsIGNhc2U6IDIuMiBub3QgMi4wMlxuXHRcdH0gZWxzZSBpZiAobWlub3IgPCAxMCkge1xuXHRcdFx0bWlub3JTdHIgPSBtaW5vci50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJykgLy8gMVx1MjE5MlwiMDFcIiwgNVx1MjE5MlwiMDVcIlxuXHRcdH0gZWxzZSB7XG5cdFx0XHRtaW5vclN0ciA9IG1pbm9yLnRvU3RyaW5nKCkgLy8gMTArXHUyMTkyXCIxMFwiLCBcIjIwXCIsIGV0Y1xuXHRcdH1cblxuXHRcdGNvbnN0IGZpcm13YXJlID0gYCR7bWFqb3J9LiR7bWlub3JTdHJ9YFxuXG5cdFx0bG9nZ2VyLmluZm8oYEZpcm13YXJlIHZlcnNpb246ICR7ZmlybXdhcmV9YClcblx0XHRyZXR1cm4gZmlybXdhcmVcblx0fVxuXG5cdC8qKlxuXHQgKiBFbnN1cmUgd2UndmUgam9pbmVkIHRoZSBtdWx0aWNhc3QgZ3JvdXAgb24gdGhlIGludGVyZmFjZSB0aGF0IHJvdXRlcyB0byBkZXN0SXAuXG5cdCAqIE9wdGlvbiBCIGJlaGF2aW9yOiBqb2luIE9OTFkgdGhlIGludGVyZmFjZSB1c2VkIHRvIHJlYWNoIHRoZSBkZXZpY2UuXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIGVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYXdhaXQgZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24oZGVzdElwKVxuXHRcdFx0aWYgKCFsb2NhbEFkZHIpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBkZXRlcm1pbmUgbG9jYWwgYWRkcmVzcyBmb3IgZGVzdGluYXRpb24gJHtkZXN0SXB9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdGlmICh0aGlzLmpvaW5lZEludGVyZmFjZXMuaGFzKGxvY2FsQWRkcikpIHtcblx0XHRcdFx0Ly8gYWxyZWFkeSBqb2luZWRcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMucnhTb2NrZXQuYWRkTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBsb2NhbEFkZHIpXG5cdFx0XHRcdHRoaXMuam9pbmVkSW50ZXJmYWNlcy5hZGQobG9jYWxBZGRyKVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgSm9pbmVkIG11bHRpY2FzdCAke3RoaXMubXVsdGljYXN0R3JvdXB9IG9uICR7bG9jYWxBZGRyfWApXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIGpvaW4gbXVsdGljYXN0IG9uICR7bG9jYWxBZGRyfTogJHtTdHJpbmcoX2UpfWApXG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBlbnN1cmVNZW1iZXJzaGlwRm9yIGZhaWxlZDogJHtfZX1gKVxuXHRcdH1cblx0fVxuXG5cdHB1YmxpYyBhc3luYyBzZW5kQXdhaXRBY2soXG5cdFx0bW9kZWw6IHN0cmluZyxcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0XHRtc2dUeXBlID0gMHgwMDIwLCAvLyBEZWZhdWx0IHRvIHN0YW5kYXJkIGNvbW1hbmQgbWVzc2FnZSB0eXBlXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0Y29uc3QgdGltZW91dE1zID0gMjAwMFxuXG5cdFx0Ly8gRW5zdXJlIHdlIGFyZSBsaXN0ZW5pbmcgZm9yIHJlcGxpZXMgb24gdGhlIGludGVyZmFjZSB0aGF0IHdpbGwgcmVjZWl2ZSB0aGVtXG5cdFx0YXdhaXQgdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcClcblxuXHRcdGNvbnN0IGRhdGFCbG9jazogbnVtYmVyW10gPSBbXVxuXHRcdGlmIChzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCkgZGF0YUJsb2NrLnB1c2goc2V0dGluZ0lkICYgMHhmZilcblx0XHRpZiAodmFsdWUgIT09IHVuZGVmaW5lZCkgZGF0YUJsb2NrLnB1c2goLi4uU3RDb250cm9sbGVyLmJ1aWxkVmFsdWVCeXRlcyh2YWx1ZSkpXG5cblx0XHRjb25zdCBwYXlsb2FkQm9keTogbnVtYmVyW10gPSBbMHg1YSwgY21kSWQgJiAweGZmXVxuXG5cdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHBheWxvYWRCb2R5LnB1c2goYnVzQ2ggJiAweGZmKVxuXHRcdGlmIChhZGRMZW4pIHBheWxvYWRCb2R5LnB1c2goZGF0YUJsb2NrLmxlbmd0aClcblxuXHRcdGlmIChkYXRhQmxvY2subGVuZ3RoID4gMCkgcGF5bG9hZEJvZHkucHVzaCguLi5kYXRhQmxvY2spXG5cblx0XHRjb25zdCBjcmMgPSBTdENvbnRyb2xsZXIuY3JjOER2YlMyKHBheWxvYWRCb2R5KVxuXHRcdGNvbnN0IHBheWxvYWRXaXRoQ3JjID0gQnVmZmVyLmZyb20oWy4uLnBheWxvYWRCb2R5LCBjcmNdKVxuXG5cdFx0Y29uc3QgaGVhZGVyID0gYXdhaXQgU3RDb250cm9sbGVyLmJ1aWxkSGVhZGVyKGRlc3RJcCwgbXNnVHlwZSlcblx0XHRjb25zdCBwYWNrZXQgPSBCdWZmZXIuY29uY2F0KFtoZWFkZXIsIHBheWxvYWRXaXRoQ3JjXSlcblxuXHRcdC8vIEh1bWFuLXJlYWRhYmxlIGluZm8gbG9nIGZvciB0aGUgb3V0Z29pbmcgY29tbWFuZFxuXHRcdGNvbnN0IGNtZE5hbWUgPSBnZXRDb21tYW5kTmFtZShjbWRJZClcblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Ly8gVHJ5IGV4YWN0IG1hdGNoIGZpcnN0XG5cdFx0XHRsZXQgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cblx0XHRcdC8vIElmIG5vIGV4YWN0IG1hdGNoLCB0cnkgdG8gZmluZCBhY3Rpb24gd2l0aCBpZEFkZCBvcHRpb25cblx0XHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRcdGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGEuY21kX2lkICE9PSBjbWRJZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3QgaGFzSWRBZGQgPSBhLm9wdGlvbnM/LnNvbWUoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdGlmICghaGFzSWRBZGQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdHJldHVybiBzZXR0aW5nSWQgPj0gYS5pZCAmJiBzZXR0aW5nSWQgPCBhLmlkICsgMTBcblx0XHRcdFx0fSlcblx0XHRcdH1cblxuXHRcdFx0bGV0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/ICdVbmtub3duIFNldHRpbmcnXG5cblx0XHRcdC8vIElmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCBhbmQgdGhlIHNldHRpbmcgaWQgaXMgb2Zmc2V0IGZyb20gYmFzZSwgaW5jbHVkZSBjaGFubmVsIGluZm9cblx0XHRcdGlmIChhY3Rpb24pIHtcblx0XHRcdFx0Y29uc3QgaGFzSWRBZGQgPSBhY3Rpb24ub3B0aW9ucz8uc29tZSgob3B0KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdGlmIChoYXNJZEFkZCAmJiBzZXR0aW5nSWQgIT09IGFjdGlvbi5pZCkge1xuXHRcdFx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nSWQgLSBhY3Rpb24uaWRcblx0XHRcdFx0XHRzZXR0aW5nTmFtZSA9IGAke3NldHRpbmdOYW1lfSBDaCR7Y2hhbm5lbE9mZnNldCArIDF9YFxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIExvb2sgZm9yIHRoZSB2YWx1ZSBvcHRpb24gdG8gZ2V0IGNob2ljZXNcblx0XHRcdGNvbnN0IHZhbHVlT3B0aW9uID0gYWN0aW9uPy5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0XHRcdGNvbnN0IGNob2ljZXMgPSB2YWx1ZU9wdGlvbj8uY2hvaWNlc1xuXHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IFN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpXG5cdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPSBjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblxuXHRcdFx0Y29uc3QgY21kSGV4ID0gdG9IZXgoY21kSWQpXG5cdFx0XHRjb25zdCBpZEhleCA9IHRvSGV4KHNldHRpbmdJZClcblx0XHRcdGNvbnN0IHZhbEhleCA9IGJ5dGVzVG9IZXgodmFsdWVCeXRlcylcblx0XHRcdGNvbnN0IHZhbERlYyA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHZhbHVlQnl0ZXMuam9pbignLCcpXG5cblx0XHRcdGNvbnN0IHByZWZpeCA9IGBjbWQ6JHtjbWRIZXh9IGlkOiR7aWRIZXh9IHZhbDoke3ZhbEhleH1gXG5cdFx0XHRjb25zdCBzdWZmaXggPSBjaG9pY2VMYWJlbCA/IGAke3NldHRpbmdOYW1lfTogJHtjaG9pY2VMYWJlbH0gKCR7dmFsRGVjfSlgIDogYCR7c2V0dGluZ05hbWV9OiAke3ZhbERlY31gXG5cblx0XHRcdGxvZ2dlci5pbmZvKGBUWCAke2Rlc3RJcH0gfCAke3ByZWZpeH0gfCAke3N1ZmZpeH1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtjbWROYW1lfWApXG5cdFx0fVxuXHRcdGxvZ2dlci5kZWJ1ZyhgU2VuZGluZyBwYWNrZXQgdG8gJHtkZXN0SXB9OiAke3BhY2tldC50b1N0cmluZygnaGV4Jyl9YClcblxuXHRcdGF3YWl0IHRoaXMudHhSZWFkeVxuXG5cdFx0Y29uc3Qga2V5ID0gYCR7ZGVzdElwfToke2NtZElkfWBcblxuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgVGltZW91dCB3YWl0aW5nIGZvciBBQ0sgZnJvbSBNb2RlbCR7bW9kZWx9IGF0ICR7ZGVzdElwfTo4NzAwYCkpXG5cdFx0XHR9LCB0aW1lb3V0TXMpXG5cblx0XHRcdHRoaXMucGVuZGluZ0Fja3Muc2V0KGtleSwge1xuXHRcdFx0XHRyZXNvbHZlOiAoYnVmKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXG5cdFx0XHRcdFx0Ly8gSWYgZGV2aWNlIHJlcXVpcmVzIHJlZnJlc2ggYWZ0ZXIgY29tbWFuZCwgcmVxdWVzdCBhbGwgc2V0dGluZ3MgKG5vbi1ibG9ja2luZylcblx0XHRcdFx0XHRpZiAodGhpcy5yZWZyZXNoQWZ0ZXJDb21tYW5kICYmIHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHR0aGlzLnJlcXVlc3RBbGxTZXR0aW5ncyhkZXN0SXApLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byByZWZyZXNoIHNldHRpbmdzIGFmdGVyIGNvbW1hbmQ6ICR7ZXJyfWApXG5cdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHRyZWplY3Q6IChlcnIpID0+IHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KGVycilcblx0XHRcdFx0fSxcblx0XHRcdFx0dGltZXIsXG5cdFx0XHR9KVxuXG5cdFx0XHR0aGlzLnR4U29ja2V0LnNlbmQocGFja2V0LCB0aGlzLmRlZmF1bHRQb3J0LCBkZXN0SXAsIChlcnIpID0+IHtcblx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgaGFuZGxlSW5jb21pbmcobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpIHtcblx0XHRpZiAobXNnLmxlbmd0aCA8IDQpIHJldHVyblxuXHRcdGlmIChtc2dbMF0gIT09IDB4ZmYgfHwgbXNnWzFdICE9PSAweGZmKSByZXR1cm5cblxuXHRcdGNvbnN0IG1zZ1R5cGUgPSBtc2cucmVhZFVJbnQxNkJFKDIpXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgKDB4MDE3MCkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gVGhlc2UgaGF2ZSBcIkF1ZGluYXRlXCIgYXQgb2Zmc2V0IDE2LCBub3QgXCJTdHVkaW8tVFwiIFx1MjAxNCBoYW5kbGUgYmVmb3JlXG5cdFx0Ly8gdGhlIFN0dWRpby1UIHNpZ25hdHVyZSBjaGVjayBiZWxvdy5cblx0XHRpZiAobXNnVHlwZSA9PT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgJiYgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2l6ZSA+IDApIHtcblx0XHRcdGNvbnN0IGRldmljZSA9IHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnLCBzcmNJcClcblx0XHRcdGlmIChkZXZpY2UpIHtcblx0XHRcdFx0Zm9yIChjb25zdCBjYiBvZiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy52YWx1ZXMoKSkge1xuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRjYihkZXZpY2UpXG5cdFx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGlmIChtc2cubGVuZ3RoIDwgMjUpIHJldHVyblxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIFN0dWRpby1UIGNvbnRyb2wgcHJvdG9jb2wgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Y29uc3Qgc2lnID0gbXNnLnN1YmFycmF5KDE2LCAyNClcblx0XHRpZiAoc2lnLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnU3R1ZGlvLVQnKSByZXR1cm5cblxuXHRcdC8vIFBheWxvYWQgc3RhcnRzIGF0IG9mZnNldCAyNFxuXHRcdC8vIExheW91dDogWzB4NWFdIFtjbWRJZHwweDgwXSBbZGF0YS4uLl0gW2NyY11cblx0XHRjb25zdCBzdFBheWxvYWQgPSBtc2cuc3ViYXJyYXkoMjQpXG5cdFx0aWYgKHN0UGF5bG9hZC5sZW5ndGggPCAyKSByZXR1cm5cblx0XHRpZiAoc3RQYXlsb2FkWzBdICE9PSAweDVhKSByZXR1cm5cblxuXHRcdC8vIERldmljZSByZXBsaWVzIHdpdGggY21kIHwgMHg4MFxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGlzUmVzcG9uc2UgPSAocmVzcENtZElkICYgMHg4MCkgIT09IDBcblx0XHRjb25zdCBvcmlnaW5hbENtZElkID0gcmVzcENtZElkICYgMHg3ZiAvLyBzdHJpcCB0aGUgcmVzcG9uc2UgZmxhZ1xuXG5cdFx0Ly8gTG9nIHRoZSBwYXlsb2FkICh3b3JrcyBmb3IgYm90aCByZXF1ZXN0cyBhbmQgcmVzcG9uc2VzKVxuXHRcdHRoaXMubG9nU3RQYXlsb2FkKHNyY0lwLCBvcmlnaW5hbENtZElkLCBtc2csIHN0UGF5bG9hZCwgaXNSZXNwb25zZSlcblxuXHRcdC8vIE9ubHkgcHJvY2VzcyBhcyBBQ0sgaWYgdGhpcyBpcyBhIHJlc3BvbnNlIHRvIG91ciByZXF1ZXN0XG5cdFx0aWYgKGlzUmVzcG9uc2UpIHtcblx0XHRcdGNvbnN0IGtleSA9IGAke3NyY0lwfToke29yaWdpbmFsQ21kSWR9YFxuXHRcdFx0Y29uc3QgcGVuZGluZyA9IHRoaXMucGVuZGluZ0Fja3MuZ2V0KGtleSlcblx0XHRcdGlmIChwZW5kaW5nKSB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cGVuZGluZy5yZXNvbHZlKG1zZylcblx0XHRcdH1cblx0XHR9XG5cdFx0Ly8gVW5zb2xpY2l0ZWQgbWVzc2FnZXMgYW5kIHJlcXVlc3RzIGZyb20gb3RoZXIgc291cmNlcyBhcmUgbG9nZ2VkIGFib3ZlXG5cdH1cblxuXHQvKipcblx0ICogRGVjb2RlcyBhbmQgbG9ncyBhIFN0dWRpby1UIHJlc3BvbnNlIHBheWxvYWQuXG5cdCAqIFJlY2VpdmVzIGJvdGggdGhlIGZ1bGwgbXNnIChmb3IgcGFyc2VycyB0aGF0IG5lZWQgdGhlIFN0dWRpby1UIGhlYWRlcilcblx0ICogYW5kIHN0UGF5bG9hZCAobXNnLnN1YmFycmF5KDI0KSwgZm9yIGRpcmVjdCBieXRlIGFjY2VzcykuXG5cdCAqXG5cdCAqIHN0UGF5bG9hZCBsYXlvdXQ6XG5cdCAqICAgWzBdICAgICAgMHg1YSAgbWFnaWNcblx0ICogICBbMV0gICAgICBjbWRJZCB8IDB4ODBcblx0ICogICBbMi4uLTJdICBkYXRhIGJ5dGVzXG5cdCAqICAgWy0xXSAgICAgQ1JDLTgvRFZCLVMyXG5cdCAqL1xuXHRwcml2YXRlIGxvZ1N0UGF5bG9hZChzcmNJcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBtc2c6IEJ1ZmZlciwgc3RQYXlsb2FkOiBCdWZmZXIsIGlzUmVzcG9uc2UgPSB0cnVlKTogdm9pZCB7XG5cdFx0Y29uc3QgY21kTmFtZSA9IGBjbWRfJHt0b0hleChjbWRJZCl9YFxuXHRcdGNvbnN0IGRhdGEgPSBzdFBheWxvYWQuc3ViYXJyYXkoMiwgc3RQYXlsb2FkLmxlbmd0aCAtIDEpIC8vIHN0cmlwIG1hZ2ljK2NtZElkIGhlYWRlciBhbmQgQ1JDXG5cblx0XHQvLyBTaG93IGNvbXBsZXRlIHBheWxvYWQgc3RydWN0dXJlOiBbMHg1YV0gW2NtZElkfDB4ODBdIFtkYXRhIGJ5dGVzLi4uXSBbY3JjXVxuXHRcdGNvbnN0IG1hZ2ljID0gc3RQYXlsb2FkWzBdXG5cdFx0Y29uc3QgcmVzcENtZElkID0gc3RQYXlsb2FkWzFdXG5cdFx0Y29uc3QgY3JjID0gc3RQYXlsb2FkW3N0UGF5bG9hZC5sZW5ndGggLSAxXVxuXHRcdGNvbnN0IGZ1bGxTdHJ1Y3R1cmUgPSBgW21hZ2ljOiR7dG9IZXgobWFnaWMpfSBjbWQ6JHt0b0hleChyZXNwQ21kSWQpfSBkYXRhOiR7ZGF0YS50b1N0cmluZygnaGV4Jyl9IGNyYzoke3RvSGV4KGNyYyl9XWBcblxuXHRcdC8vIERldGVybWluZSBkaXJlY3Rpb24gcHJlZml4XG5cdFx0Y29uc3QgZGlyZWN0aW9uID0gaXNSZXNwb25zZSA/ICdSWCcgOiAnU05JRkYnXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIGFuZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gUGFyc2UgYWxsIHNldHRpbmdzLCBkaWZmIGFnYWluc3QgZGV2aWNlU3RhdGUsIGxvZyBjaGFuZ2VkIGF0IGluZm8gLyB1bmNoYW5nZWQgYXQgZGVidWcsXG5cdFx0Ly8gdGhlbiB1cGRhdGUgZGV2aWNlU3RhdGUuIENNRF9HRVRfQUxMX1NFVFRJTkdTIGFsc28gc2VydmVzIGFzIHRoZSBpbml0aWFsIHN0YXRlIHBvcHVsYXRpb24gb24gY29ubmVjdC5cblx0XHRpZiAoY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTIHx8IGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0aWYgKCF0aGlzLm1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ3MgPVxuXHRcdFx0XHRcdGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSFxuXHRcdFx0XHRcdFx0PyBwYXJzZVNldHRpbmdzUmVzcG9uc2UodGhpcy5tb2RlbCwgbXNnKVxuXHRcdFx0XHRcdFx0OiBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwodGhpcy5tb2RlbCwgbXNnKVxuXG5cdFx0XHRcdGNvbnN0IHByZXZTdGF0ZSA9IHRoaXMuZGV2aWNlU3RhdGUuZ2V0KHNyY0lwKSA/PyBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpXG5cdFx0XHRcdGNvbnN0IG5ld1N0YXRlID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4ocHJldlN0YXRlKSAvLyBjb3B5IFx1MjAxNCB1cGRhdGUgaW4gcGxhY2VcblxuXHRcdFx0XHRmb3IgKGNvbnN0IHMgb2Ygc2V0dGluZ3MpIHtcblx0XHRcdFx0XHRjb25zdCBzdGF0ZUtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgcy5jbWRfaWQsIHMuaWQsIHMuYnVzQ2gpXG5cdFx0XHRcdFx0Ly8gRm9yIFJHQiBjb2xvcnMgKDMgYnl0ZXMpLCBwYWNrIGludG8gc2luZ2xlIG51bWJlcjogKFIgPDwgMTYpIHwgKEcgPDwgOCkgfCBCXG5cdFx0XHRcdFx0Y29uc3QgbmV3VmFsdWUgPVxuXHRcdFx0XHRcdFx0cy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0XHRcdFx0XHQ/IChzLnZhbHVlQnl0ZXNbMF0gPDwgMTYpIHwgKHMudmFsdWVCeXRlc1sxXSA8PCA4KSB8IHMudmFsdWVCeXRlc1syXVxuXHRcdFx0XHRcdFx0XHQ6IChzLnZhbHVlQnl0ZXNbMF0gPz8gMClcblx0XHRcdFx0XHRjb25zdCBwcmV2VmFsdWUgPSBwcmV2U3RhdGUuZ2V0KHN0YXRlS2V5KVxuXHRcdFx0XHRcdGNvbnN0IGNoYW5nZWQgPSBwcmV2VmFsdWUgIT09IHVuZGVmaW5lZCAmJiBwcmV2VmFsdWUgIT09IG5ld1ZhbHVlXG5cblx0XHRcdFx0XHRuZXdTdGF0ZS5zZXQoc3RhdGVLZXksIG5ld1ZhbHVlKVxuXG5cdFx0XHRcdFx0Y29uc3QgZm9ybWF0dGVkID0gZm9ybWF0UGFyc2VkU2V0dGluZyhzLCB0aGlzLmFjdGlvbnMpXG5cdFx0XHRcdFx0aWYgKGNoYW5nZWQpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5pbmZvKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdFx0Ly8gVHJpZ2dlciBmZWVkYmFjayB1cGRhdGUgZm9yIHRoaXMgc2V0dGluZ1xuXHRcdFx0XHRcdFx0aWYgKHRoaXMuZmVlZGJhY2tDYWxsYmFjaykge1xuXHRcdFx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soc3RhdGVLZXkpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgJHtkaXJlY3Rpb259ICR7c3JjSXB9IHwgJHtmb3JtYXR0ZWR9YClcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy5kZXZpY2VTdGF0ZS5zZXQoc3JjSXAsIG5ld1N0YXRlKVxuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgJHtkaXJlY3Rpb259ICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8IHBhcnNlIGZhaWxlZDogJHtlfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIEFsbCBvdGhlciBjb21tYW5kcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBkZWNvZGVkID0gdGhpcy5kZWNvZGVTdERhdGEoY21kSWQsIGRhdGEpXG5cdFx0aWYgKGRlY29kZWQpIHtcblx0XHRcdGxvZ2dlci5pbmZvKGAke2RpcmVjdGlvbn0gJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfSB8ICR7ZGVjb2RlZH1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgJHtkaXJlY3Rpb259ICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBBdHRlbXB0cyB0byBkZWNvZGUgdGhlIGRhdGEgYnl0ZXMgb2YgYSBTdHVkaW8tVCByZXNwb25zZSBpbnRvIGFcblx0ICogaHVtYW4tcmVhZGFibGUgc3RyaW5nLiBSZXR1cm5zIG51bGwgdG8gZmFsbCBiYWNrIHRvIHJhdyBoZXguXG5cdCAqXG5cdCAqIG1zZyBpcyB0aGUgZnVsbCBwYWNrZXQgYnVmZmVyIFx1MjAxNCByZXF1aXJlZCBieSB0aGUgc2V0dGluZ3MgcGFyc2VycyB3aGljaFxuXHQgKiBsb2NhdGUgdGhlIFN0dWRpby1UIHNpZ25hdHVyZSB0aGVtc2VsdmVzLlxuXHQgKi9cblx0cHJpdmF0ZSBkZWNvZGVTdERhdGEoY21kSWQ6IG51bWJlciwgZGF0YTogQnVmZmVyKTogc3RyaW5nIHwgbnVsbCB7XG5cdFx0aWYgKGRhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gJ0FDSydcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDaGVjayBmb3Igc2luZ2xlLWJ5dGUgcmVzcG9uc2VzIChBQ0sgb3IgZXJyb3IpIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0aWYgKGRhdGFbMF0gPT09IDB4MDApIHtcblx0XHRcdFx0cmV0dXJuICdBQ0sgb2snXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRyZXR1cm4gYEVSUk9SICR7dG9IZXgoZGF0YVswXSl9YFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHN3aXRjaCAoY21kSWQpIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfREVWX1NQRUMgKDB4MGQpOiBzaW5nbGUtYnl0ZSBBQ0sgb3IgZWNobyBvZiBhcHBsaWVkIHNldHRpbmcgXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBEZXZpY2Ugc2VuZHMgdHdvIENNRF9ERVZfU1BFQyBwYWNrZXRzIGluIHJlc3BvbnNlIHRvIGEgc2V0OlxuXHRcdFx0Ly8gICAxLiBBQ0s6ICBbc3RhdHVzXSAgICAgICAgICAgICAgICgxIGJ5dGUsIDB4MDAgPSBvaylcblx0XHRcdC8vICAgMi4gRWNobzogW2J1c0NoXSBbc2V0dGluZ0lkXSBbdmFsdWUuLi5dICAoY29uZmlybWluZyB3aGF0IHdhcyBhcHBsaWVkKVxuXHRcdFx0Y2FzZSBDTURfREVWX1NQRUM6IHtcblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGRhdGFbMF0gPT09IDB4MDAgPyAnQUNLIG9rJyA6IGBBQ0sgZXJyPSR7dG9IZXgoZGF0YVswXSl9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfWBcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VzID0gYWN0aW9uPy5vcHRpb25zPy5bMF0/LmNob2ljZXNcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID1cblx0XHRcdFx0XHRcdGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlU3RyID0gY2hvaWNlTGFiZWwgPyBgJHtjaG9pY2VMYWJlbH0gKCR7dG9IZXgodmFsdWVOdW0hKX0pYCA6IGJ5dGVzVG9IZXgoQXJyYXkuZnJvbSh2YWx1ZUJ5dGVzKSlcblx0XHRcdFx0XHRjb25zdCByYXdUYWcgPSBgWyR7dG9IZXgoY21kSWQpfS8ke3RvSGV4KHNldHRpbmdJZCl9XT0ke2J5dGVzVG9IZXgoQXJyYXkuZnJvbSh2YWx1ZUJ5dGVzKSl9YFxuXHRcdFx0XHRcdHJldHVybiBgZWNobyBjaD0ke2J1c0NofSB8ICR7c2V0dGluZ05hbWV9OiAke3ZhbHVlU3RyfSAke3Jhd1RhZ31gXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGByYXc6ICR7ZGF0YS50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0fVxuXG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX01JQ19QUkVfQlVTICgweDEyKTogTXVsdGktYnl0ZSBlY2hvIHJlc3BvbnNlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdGNhc2UgQ01EX01JQ19QUkVfQlVTOiB7XG5cdFx0XHRcdC8vIEFscmVhZHkgaGFuZGxlZCBzaW5nbGUtYnl0ZSBhYm92ZSwgc28gbXVsdGktYnl0ZSBtdXN0IGJlIGVjaG9cblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID49IDMpIHtcblx0XHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0XHRjb25zdCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyBgc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9YFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlTnVtID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlcyA9IGFjdGlvbj8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJyk/LmNob2ljZXNcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9XG5cdFx0XHRcdFx0XHRjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVN0ciA9IGNob2ljZUxhYmVsID8/IGAweCR7dmFsdWVCeXRlcy50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0XHRcdHJldHVybiBgZWNobyBjaD0ke2J1c0NofSB8ICR7c2V0dGluZ05hbWV9OiAke3ZhbHVlU3RyfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gbnVsbFxuXHRcdFx0fVxuXG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQnVzLXNjb3BlZCBnZXQvc2V0IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdGNhc2UgQ01EX0JVU19TRVQ6IHtcblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoIDwgMikgcmV0dXJuIG51bGxcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdHJldHVybiBgY2g9JHtidXNDaH0gc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9IHZhbHVlPSR7dmFsdWUudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0cmV0dXJuIG51bGwgLy8gZmFsbCB0aHJvdWdoIHRvIHJhdyBoZXhcblx0XHR9XG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBidWlsZFZhbHVlQnl0ZXModmFsdWU6IHVua25vd24pOiBudW1iZXJbXSB7XG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gW3ZhbHVlID8gMSA6IDBdXG5cdFx0aWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSByZXR1cm4gdmFsdWUubWFwKCh2KSA9PiBOdW1iZXIodikgJiAweGZmKVxuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG5cdFx0XHRpZiAodmFsdWUgPiAweGZmKSByZXR1cm4gWyh2YWx1ZSA+PiAxNikgJiAweGZmLCAodmFsdWUgPj4gOCkgJiAweGZmLCB2YWx1ZSAmIDB4ZmZdXG5cdFx0XHRyZXR1cm4gW3ZhbHVlICYgMHhmZl1cblx0XHR9XG5cdFx0dGhyb3cgbmV3IEVycm9yKGBVbnN1cHBvcnRlZCB2YWx1ZSB0eXBlIGZvciBTVGNvbnRyb2xsZXI6ICR7dmFsdWV9YClcblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGFzeW5jIGdldE1hY0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxudW1iZXJbXT4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxudW1iZXJbXT4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHRcdH0pXG5cblx0XHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3NcblxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cblx0XHRcdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0XHRcdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdFx0XHRcdGZvciAoY29uc3QgaWZhY2Ugb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChcblx0XHRcdFx0XHRcdFx0XHRpZmFjZS5mYW1pbHkgPT09ICdJUHY0JyAmJlxuXHRcdFx0XHRcdFx0XHRcdGlmYWNlLmFkZHJlc3MgPT09IGxvY2FsQWRkciAmJlxuXHRcdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAmJlxuXHRcdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAhPT0gJzAwOjAwOjAwOjAwOjAwOjAwJ1xuXHRcdFx0XHRcdFx0XHQpIHtcblx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gcmVzb2x2ZShpZmFjZS5tYWMuc3BsaXQoJzonKS5tYXAoKGIpID0+IHBhcnNlSW50KGIsIDE2KSAmIDB4ZmYpKVxuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgTm8gaW50ZXJmYWNlIGZvdW5kIGZvciBsb2NhbCBhZGRyZXNzICR7bG9jYWxBZGRyfWApKVxuXHRcdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoU3RyaW5nKF9lKSkpXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGFzeW5jIGJ1aWxkSGVhZGVyKGRlc3RJcDogc3RyaW5nLCBtc2dUeXBlID0gMHgwMDIwKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRjb25zdCBtYWMgPSBhd2FpdCBTdENvbnRyb2xsZXIuZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwKVxuXG5cdFx0Ly8gTWVzc2FnZSB0eXBlIGlzIDIgYnl0ZXMgKGJpZy1lbmRpYW4pOiBlLmcuLCAweDAwMjAsIDB4MDAxYiwgMHgwMDFlXG5cdFx0Y29uc3QgbXNnVHlwZU1zYiA9IChtc2dUeXBlID4+IDgpICYgMHhmZlxuXHRcdGNvbnN0IG1zZ1R5cGVMc2IgPSBtc2dUeXBlICYgMHhmZlxuXG5cdFx0cmV0dXJuIEJ1ZmZlci5jb25jYXQoW1xuXHRcdFx0QnVmZmVyLmZyb20oWzB4ZmYsIDB4ZmYsIG1zZ1R5cGVNc2IsIG1zZ1R5cGVMc2IsIDB4MDcsIDB4ZTEsIDB4MDAsIDB4MDAsIC4uLm1hYywgMHgwMCwgMHgwMF0pLFxuXHRcdFx0QnVmZmVyLmZyb20oJ1N0dWRpby1UJywgJ3V0ZjgnKSxcblx0XHRdKVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgY3JjOER2YlMyKGRhdGE6IG51bWJlcltdKTogbnVtYmVyIHtcblx0XHRsZXQgY3JjID0gMFxuXHRcdGZvciAoY29uc3QgYiBvZiBkYXRhKSB7XG5cdFx0XHRjcmMgXj0gYlxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCA4OyBpKyspIHtcblx0XHRcdFx0Y3JjID0gKGNyYyAmIDB4ODApICE9PSAwID8gKChjcmMgPDwgMSkgXiAweGQ1KSAmIDB4ZmYgOiAoY3JjIDw8IDEpICYgMHhmZlxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gY3JjXG5cdH1cblxuXHQvKipcblx0ICogUmV0dXJucyB0aGUgY3VycmVudCBrbm93biB2YWx1ZSBmb3IgYSBzZXR0aW5nIG9uIGEgZGV2aWNlLCBvciB1bmRlZmluZWQgaWYgdW5rbm93bi5cblx0ICogVXNlIGZvciBmZWVkYmFja3MgXHUyMDE0IHZhbHVlIGlzIHVwZGF0ZWQgb24gZXZlcnkgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpIGZyb20gdGhlIGRldmljZS5cblx0ICpcblx0ICogQHBhcmFtIGlwICAgICAgICBEZXZpY2UgSVAgYWRkcmVzc1xuXHQgKiBAcGFyYW0gY21kSWQgICAgIENvbW1hbmQgSUQgKGUuZy4gQ01EX0RFVl9TUEVDKVxuXHQgKiBAcGFyYW0gc2V0dGluZ0lkIFNldHRpbmcgSUQgKGUuZy4gMHgwMiBmb3IgQ29udHJvbCBTb3VyY2UpXG5cdCAqIEBwYXJhbSBidXNDaCAgICAgT3B0aW9uYWwgYnVzL2NoYW5uZWwgSUQgZm9yIG11bHRpLWNoYW5uZWwgY29tbWFuZHNcblx0ICovXG5cdHB1YmxpYyBnZXRTZXR0aW5nVmFsdWUoaXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgc2V0dGluZ0lkOiBudW1iZXIsIGJ1c0NoPzogbnVtYmVyKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcblx0XHRjb25zdCBrZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXHRcdHJldHVybiB0aGlzLmRldmljZVN0YXRlLmdldChpcCk/LmdldChrZXkpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgcmVzZXREZXZpY2UobW9kZWw6IHN0cmluZywgZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHJldHVybiB0aGlzLnNlbmRBd2FpdEFjayhtb2RlbCwgQ01EX1JFU0VUX0RFVklDRSwgdW5kZWZpbmVkLCAweDAwLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgZ2xvYmFsTWljS2lsbChtb2RlbDogc3RyaW5nLCBkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKG1vZGVsLCBDTURfR0xPQkFMX01JQ19LSUxMLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IG9zIGZyb20gJ29zJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRGFudGUnKVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgRGFudGUgZGlzY292ZXJ5IGNvbnN0YW50cyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlcXVlc3QgbWVzc2FnZSB0eXBlIChzZW50IHRvIHBvcnQgODcwMCkgKi9cbmV4cG9ydCBjb25zdCBEQU5URV9NU0dfSU5GT19SRVFVRVNUID0gMHgwMDIwXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgbWVzc2FnZSB0eXBlIChyZWNlaXZlZCBvbiBwb3J0IDg3MDIpICovXG5leHBvcnQgY29uc3QgREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgPSAweDAxNzBcblxuLyoqXG4gKiBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSBsYXlvdXQgKGFsbCBvZmZzZXRzIGFyZSBpbnRvIHRoZSBVRFAgcGF5bG9hZCk6XG4gKiAgIDB4MDAgIHVpbnQxNkJFICBNYWdpYyAoMHhmZmZmKVxuICogICAweDAyICB1aW50MTZCRSAgTWVzc2FnZSB0eXBlICgweDAxNzApXG4gKiAgIDB4MDQgIHVpbnQxNkJFICBTZXF1ZW5jZSBudW1iZXJcbiAqICAgMHgwNiAgMiBieXRlcyAgIFBhZGRpbmdcbiAqICAgMHgwOCAgOCBieXRlcyAgIEVVSS02NCAoc291cmNlIE1BQyB3aXRoIGZmOmZlIGluc2VydGVkIG1pZClcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBBU0NJSSBpZGVudGlmaWVyXG4gKiAgIDB4MTggIDIgYnl0ZXMgICBEYW50ZSBtb2R1bGUgZmlybXdhcmUgdmVyc2lvbiAobWFqb3IsIG1pbm9yKVxuICogICAweDIwICAzMSBieXRlcyAgRGV2aWNlIG5hbWUsIG51bGwtcGFkZGVkIEFTQ0lJIChtYXggMzEgY2hhcnMgcGVyIERhbnRlIHNwZWMpXG4gKiAgIDB4MmUgIHVpbnQxNkJFICBQcm9kdWN0IElEXG4gKiAgIDB4NGMgIDY0IGJ5dGVzICBNYW51ZmFjdHVyZXIgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICogICAweGNjICA2NCBieXRlcyAgTW9kZWwgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICovXG5leHBvcnQgY29uc3QgREFOVEVfSU5GT19NSU5fTEVOID0gMHhjYyArIDY0IC8vIDI2OCBieXRlcyBcdTIwMTQgbmVlZCBmdWxsIG1vZGVsIGZpZWxkXG5cbi8qKlxuICogQnVpbGRzIGEgRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBwYWNrZXQgKHR5cGUgMHgwMDIwKS5cbiAqXG4gKiBQYWNrZXQgbGF5b3V0ICgzMiBieXRlcykgXHUyMDE0IGRlcml2ZWQgZnJvbSBsaXZlIGNhcHR1cmUgYW5hbHlzaXM6XG4gKiAgIDB4MDAgIHVpbnQxNkJFICBNYWdpYyAoMHhmZmZmKVxuICogICAweDAyICB1aW50MTZCRSAgTWVzc2FnZSB0eXBlICgweDAwMjAgPSBkZXZpY2UgaW5mbyByZXF1ZXN0KVxuICogICAweDA0ICB1aW50MTZCRSAgU2VxdWVuY2UgbnVtYmVyIChyYW5kb20pXG4gKiAgIDB4MDYgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MDggIDYgYnl0ZXMgICBTb3VyY2UgTUFDXG4gKiAgIDB4MGUgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgQVNDSUkgaWRlbnRpZmllclxuICogICAweDE4ICAyIGJ5dGVzICAgUHJvdG9jb2wgdmVyc2lvbiAoMHgwNzM5KVxuICogICAweDFhICAyIGJ5dGVzICAgU3ViLXR5cGUgKDB4MDBjMSlcbiAqICAgMHgxYyAgdWludDMyQkUgIENhcGFiaWxpdHkgbWFzayAoMHgwMDBmNDI0MClcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpOiBCdWZmZXIge1xuXHRjb25zdCBidWYgPSBCdWZmZXIuYWxsb2MoMzIsIDApXG5cdGNvbnN0IHNlcSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDB4ZmZmZilcblxuXHRidWYud3JpdGVVSW50MTZCRSgweGZmZmYsIDApXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKERBTlRFX01TR19JTkZPX1JFUVVFU1QsIDIpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKHNlcSwgNClcblxuXHRjb25zdCBtYWMgPSBnZXRGaXJzdExvY2FsTWFjKClcblx0bWFjLmNvcHkoYnVmLCA4KVxuXG5cdEJ1ZmZlci5mcm9tKCdBdWRpbmF0ZScsICdhc2NpaScpLmNvcHkoYnVmLCAxNilcblx0YnVmLndyaXRlVUludDE2QkUoMHgwNzM5LCAyNClcblx0YnVmLndyaXRlVUludDE2QkUoMHgwMGMxLCAyNilcblx0YnVmLndyaXRlVUludDMyQkUoMHgwMDBmNDI0MCwgMjgpXG5cblx0cmV0dXJuIGJ1ZlxufVxuXG4vKiogUmV0dXJucyB0aGUgZmlyc3Qgbm9uLWxvb3BiYWNrIE1BQyBhcyBhIDYtYnl0ZSBCdWZmZXIsIG9yIHplcm9zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEZpcnN0TG9jYWxNYWMoKTogQnVmZmVyIHtcblx0dHJ5IHtcblx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdGZvciAoY29uc3QgYWRkciBvZiBpZmFjZXNbbmFtZV0gPz8gW10pIHtcblx0XHRcdFx0aWYgKCFhZGRyLmludGVybmFsICYmIGFkZHIuZmFtaWx5ID09PSAnSVB2NCcgJiYgYWRkci5tYWMgJiYgYWRkci5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCcpIHtcblx0XHRcdFx0XHRyZXR1cm4gQnVmZmVyLmZyb20oYWRkci5tYWMuc3BsaXQoJzonKS5tYXAoKGg6IHN0cmluZykgPT4gcGFyc2VJbnQoaCwgMTYpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCB7XG5cdFx0LyogaWdub3JlICovXG5cdH1cblx0cmV0dXJuIEJ1ZmZlci5hbGxvYyg2LCAwKVxufVxuXG4vKipcbiAqIFBhcnNlcyBhIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlICh0eXBlIDB4MDE3MCkgaW50byBhIERldmljZUluZm8uXG4gKlxuICogUmVzcG9uc2UgbGF5b3V0IChrZXkgb2Zmc2V0cyk6XG4gKiAgIDB4MDggIDggYnl0ZXMgICBFVUktNjQgXHUyMDE0IGNvbnZlcnQgdG8gTUFDIGJ5IGRyb3BwaW5nIGJ5dGVzIFszXSBhbmQgWzRdIChmZjpmZSlcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBpZGVudGlmaWVyICh1c2VkIHRvIHZlcmlmeSB0aGlzIGlzIGEgcmVhbCByZXNwb25zZSlcbiAqICAgMHgxOCAgMSBieXRlICAgIERhbnRlIEZXIG1ham9yXG4gKiAgIDB4MTkgIDEgYnl0ZSAgICBEYW50ZSBGVyBtaW5vclxuICogICAweDIwICAzMSBieXRlcyAgRGV2aWNlIG5hbWUgKERhbnRlIGxhYmVsKSwgbnVsbC1wYWRkZWQgQVNDSUkgKG1heCAzMSBjaGFycylcbiAqICAgMHgyZSAgdWludDE2QkUgIFByb2R1Y3QgSURcbiAqICAgMHg0YyAgNjQgYnl0ZXMgIE1hbnVmYWN0dXJlciwgbnVsbC1wYWRkZWQgQVNDSUlcbiAqICAgMHhjYyAgNjQgYnl0ZXMgIE1vZGVsIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqXG4gKiBSZXR1cm5zIG51bGwgaWYgYnVmZmVyIGlzIHRvbyBzaG9ydCwgd3JvbmcgbWFnaWMsIG9yIG1pc3NpbmcgbW9kZWwgc3RyaW5nLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VEYW50ZUluZm9SZXNwb25zZShtc2c6IEJ1ZmZlciwgc3JjSXA6IHN0cmluZyk6IERldmljZUluZm8gfCBudWxsIHtcblx0aWYgKG1zZy5sZW5ndGggPCBEQU5URV9JTkZPX01JTl9MRU4pIHJldHVybiBudWxsXG5cdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmYpIHJldHVybiBudWxsXG5cdGlmIChtc2cucmVhZFVJbnQxNkJFKDIpICE9PSBEQU5URV9NU0dfSU5GT19SRVNQT05TRSkgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm4gbnVsbFxuXG5cdGNvbnN0IHJlYWRTdHIgPSAob2Zmc2V0OiBudW1iZXIsIGxlbjogbnVtYmVyKTogc3RyaW5nID0+XG5cdFx0bXNnXG5cdFx0XHQuc3ViYXJyYXkob2Zmc2V0LCBvZmZzZXQgKyBsZW4pXG5cdFx0XHQudG9TdHJpbmcoJ2FzY2lpJylcblx0XHRcdC5zcGxpdCgnXFwwJylbMF1cblx0XHRcdC50cmltKClcblxuXHRjb25zdCBldWk2NCA9IG1zZy5zdWJhcnJheSg4LCAxNilcblx0Y29uc3QgbWFjQnl0ZXMgPSBbZXVpNjRbMF0sIGV1aTY0WzFdLCBldWk2NFsyXSwgZXVpNjRbNV0sIGV1aTY0WzZdLCBldWk2NFs3XV1cblx0Y29uc3QgbWFjID0gbWFjQnl0ZXMubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKS5qb2luKCc6JylcblxuXHRjb25zdCBuYW1lID0gcmVhZFN0cigweDIwLCAzMSkgLy8gRGFudGUgZGV2aWNlIGxhYmVsIChjYW4gYmUgdXAgdG8gMzEgY2hhcnMgcGVyIERhbnRlIHNwZWMpXG5cdGNvbnN0IG1hbnVmYWN0dXJlciA9IHJlYWRTdHIoMHg0YywgNjQpIC8vIGUuZy4gXCJTdHVkaW8gVGVjaG5vbG9naWVzLCBJbmMuXCJcblx0Y29uc3QgbW9kZWxSYXcgPSByZWFkU3RyKDB4Y2MsIDY0KVxuXHRjb25zdCBkYW50ZUZpcm13YXJlID0gYCR7bXNnWzB4MThdfS4ke21zZ1sweDE5XX1gXG5cblx0aWYgKCFtb2RlbFJhdykgcmV0dXJuIG51bGxcblxuXHQvLyBFeHRyYWN0IGp1c3QgdGhlIG1vZGVsIG51bWJlci9jb2RlIChlLmcuIFwiTW9kZWwgMzkxIEFsZXJ0aW5nIFVuaXRcIiBcdTIxOTIgXCIzOTFcIilcblx0Ly8gU3RyaXAgXCJNb2RlbCBcIiBwcmVmaXgsIHRoZW4gdGFrZSBvbmx5IHRoZSBmaXJzdCB3b3JkICh0aGUgbW9kZWwgbnVtYmVyKVxuXHRjb25zdCBtb2RlbCA9IG1vZGVsUmF3XG5cdFx0LnJlcGxhY2UoL15Nb2RlbFxccysvaSwgJycpXG5cdFx0LnRyaW0oKVxuXHRcdC5zcGxpdCgvXFxzKy8pWzBdXG5cblx0cmV0dXJuIHtcblx0XHRpcDogc3JjSXAsXG5cdFx0bmFtZSxcblx0XHRtYW51ZmFjdHVyZXIsXG5cdFx0bW9kZWwsXG5cdFx0bW9kZWxOYW1lOiBtb2RlbFJhdywgLy8gRnVsbCBtb2RlbCBkZXNjcmlwdGlvblxuXHRcdG1hYyxcblx0XHRkYW50ZUZpcm13YXJlLFxuXHR9XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgbG9jYWwgSVAgYWRkcmVzcyB1c2VkIGJ5IHRoZSBPUyB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBzb2NrZXQgY29ubmVjdCB0byBsZXQgdGhlIE9TIHNlbGVjdCB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8c3RyaW5nPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdGxldCByZXNvbHZlZCA9IGZhbHNlXG5cdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIFVzZSBhbiBhcmJpdHJhcnkgcG9ydCBmb3IgY29ubmVjdDsgd2Ugb25seSBuZWVkIHRoZSBrZXJuZWwgdG8gYXNzaWduIGEgbG9jYWwgYWRkcmVzcy5cblx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cdFx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRcdHJlc29sdmUobG9jYWxBZGRyKVxuXHRcdFx0XHR9XG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cblxuLyoqXG4gKiBEaXNjb3ZlcnMgU3R1ZGlvIFRlY2hub2xvZ2llcyBEYW50ZSBkZXZpY2VzIG9uIHRoZSBsb2NhbCBuZXR3b3JrLlxuICpcbiAqIFN0cmF0ZWd5OlxuICogIERhbnRlIGRldmljZXMgYnJvYWRjYXN0IGEgMS1zZWNvbmQgYW5ub3VuY2UgdG8gbXVsdGljYXN0IDIyNC4wLjAuMjMzOjg3MDguXG4gKiAgV2UgbGlzdGVuIG9uIHRoYXQgZ3JvdXAsIGNvbGxlY3Qgc291cmNlIElQcywgdGhlbiBzZW5kIGEgdW5pY2FzdCBkZXZpY2UgaW5mb1xuICogIHJlcXVlc3QgKDB4MDAyMCkgdG8gZWFjaCBuZXcgSVAgb24gcG9ydCA4NzAwLiBUaGUgZGV2aWNlIHJlc3BvbmRzIG9uIHBvcnQgODcwMixcbiAqICB3aGVyZSB0aGUgcHJvdmlkZWQgb25EZXZpY2VGb3VuZCBjYWxsYmFjayBpcyBpbnZva2VkLlxuICpcbiAqIEBwYXJhbSB0eFNvY2tldCAtIFRoZSBzb2NrZXQgdG8gdXNlIGZvciBzZW5kaW5nIGRpc2NvdmVyeSByZXF1ZXN0c1xuICogQHBhcmFtIG9uRGV2aWNlRm91bmQgLSBDYWxsYmFjayBpbnZva2VkIHdoZW4gYSBkZXZpY2UgaW5mbyByZXNwb25zZSAoMHgwMTcwKSBpcyByZWNlaXZlZFxuICogQHBhcmFtIGVuc3VyZU1lbWJlcnNoaXAgLSBDYWxsYmFjayB0byBlbnN1cmUgbXVsdGljYXN0IG1lbWJlcnNoaXAgZm9yIGRldmljZSBJUFxuICogQHBhcmFtIHRpbWVvdXRNcyAtIERpc2NvdmVyeSB0aW1lb3V0IGluIG1pbGxpc2Vjb25kc1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGlzY292ZXJEZXZpY2VzKFxuXHR0eFNvY2tldDogZGdyYW0uU29ja2V0LFxuXHRfb25EZXZpY2VGb3VuZDogKGRldmljZTogRGV2aWNlSW5mbykgPT4gdm9pZCwgLy8gSW52b2tlZCBieSBTdENvbnRyb2xsZXIuaGFuZGxlSW5jb21pbmcoKSwgbm90IGhlcmVcblx0ZW5zdXJlTWVtYmVyc2hpcDogKGRlc3RJcDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+LFxuXHR0aW1lb3V0TXMgPSA1MDAwLFxuKTogUHJvbWlzZTxEZXZpY2VJbmZvW10+IHtcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfR1JPVVAgPSAnMjI0LjAuMC4yMzMnXG5cdGNvbnN0IERBTlRFX0FOTk9VTkNFX1BPUlQgPSA4NzA4XG5cdGNvbnN0IERFRkFVTFRfUE9SVCA9IDg3MDBcblxuXHRjb25zdCBmb3VuZCA9IG5ldyBNYXA8c3RyaW5nLCBEZXZpY2VJbmZvPigpXG5cdGNvbnN0IHF1ZXJpZWRJcHMgPSBuZXcgU2V0PHN0cmluZz4oKVxuXG5cdHJldHVybiBuZXcgUHJvbWlzZTxEZXZpY2VJbmZvW10+KChyZXNvbHZlKSA9PiB7XG5cdFx0Ly8gTm90ZTogb25EZXZpY2VGb3VuZCBjYWxsYmFjayBpcyBpbnZva2VkIGJ5IFN0Q29udHJvbGxlci5oYW5kbGVJbmNvbWluZygpXG5cdFx0Ly8gd2hlbiBpdCByZWNlaXZlcyAweDAxNzAgcmVzcG9uc2VzLiBXZSBkb24ndCBjYWxsIGl0IGhlcmUgdG8gYXZvaWQgZHVwbGljYXRlcy5cblxuXHRcdC8vIE9wZW4gYSBzaG9ydC1saXZlZCBzb2NrZXQganVzdCB0byByZWNlaXZlIHRoZSBEYW50ZSBwZXJpb2RpYyBhbm5vdW5jZXNcblx0XHRjb25zdCBhbm5vdW5jZVNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cblx0XHRjb25zdCBjbGVhbnVwID0gKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuZHJvcE1lbWJlcnNoaXAoREFOVEVfQU5OT1VOQ0VfR1JPVVApXG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhbm5vdW5jZVNvY2tldC5jbG9zZSgpXG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0XHRyZXNvbHZlKEFycmF5LmZyb20oZm91bmQudmFsdWVzKCkpKVxuXHRcdH1cblxuXHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dChjbGVhbnVwLCB0aW1lb3V0TXMpXG5cdFx0dGltZXIudW5yZWY/LigpXG5cblx0XHRhbm5vdW5jZVNvY2tldC5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIud2FybihgQW5ub3VuY2Ugc29ja2V0IGVycm9yOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0fSlcblxuXHRcdGFubm91bmNlU29ja2V0Lm9uKCdtZXNzYWdlJywgKG1zZywgcmluZm8pID0+IHtcblx0XHRcdGNvbnN0IHNyY0lwID0gcmluZm8uYWRkcmVzc1xuXHRcdFx0Ly8gVmFsaWRhdGUgaXQncyBhIERhbnRlIGFubm91bmNlIChtYWdpYyAweGZmZmUgKyBcIkF1ZGluYXRlXCIgYXQgb2Zmc2V0IDE2KVxuXHRcdFx0aWYgKG1zZy5sZW5ndGggPCAyNCkgcmV0dXJuXG5cdFx0XHRpZiAobXNnLnJlYWRVSW50MTZCRSgwKSAhPT0gMHhmZmZlKSByZXR1cm5cblx0XHRcdGlmIChtc2cuc3ViYXJyYXkoMTYsIDI0KS50b1N0cmluZygnYXNjaWknKSAhPT0gJ0F1ZGluYXRlJykgcmV0dXJuXG5cblx0XHRcdGlmIChxdWVyaWVkSXBzLmhhcyhzcmNJcCkpIHJldHVyblxuXHRcdFx0cXVlcmllZElwcy5hZGQoc3JjSXApXG5cdFx0XHRsb2dnZXIuZGVidWcoYEFubm91bmNlIGZyb20gJHtzcmNJcH0gXHUyMDE0IHNlbmRpbmcgdW5pY2FzdCBxdWVyeWApXG5cblx0XHRcdC8vIEpvaW4gMjI0LjAuMC4yMzEgb24gdGhlIGludGVyZmFjZSB0aGF0IHJvdXRlcyB0byB0aGlzIGRldmljZSBCRUZPUkUgc2VuZGluZ1xuXHRcdFx0Ly8gdGhlIHF1ZXJ5LiBUaGUgZGV2aWNlIG11bHRpY2FzdHMgaXRzIDB4MDE3MCByZXNwb25zZSB0byAyMjQuMC4wLjIzMTo4NzAyXG5cdFx0XHQvLyBpbiBhZGRpdGlvbiB0byB1bmljYXN0aW5nIGl0IFx1MjAxNCByeFNvY2tldCBtdXN0IGJlIGEgbWVtYmVyIHRvIHJlY2VpdmUgaXQuXG5cdFx0XHRlbnN1cmVNZW1iZXJzaGlwKHNyY0lwKVxuXHRcdFx0XHQudGhlbigoKSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgcXVlcnkgPSBidWlsZERhbnRlSW5mb1JlcXVlc3QoKVxuXHRcdFx0XHRcdHR4U29ja2V0LnNlbmQocXVlcnksIERFRkFVTFRfUE9SVCwgc3JjSXAsIChlcnIpID0+IHtcblx0XHRcdFx0XHRcdGlmIChlcnIpIGxvZ2dlci53YXJuKGBVbmljYXN0IHF1ZXJ5IHRvICR7c3JjSXB9IGZhaWxlZDogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdH0pXG5cdFx0XHRcdC5jYXRjaCgoZXJyKSA9PiBsb2dnZXIud2FybihgUXVlcnkgc2V0dXAgZmFpbGVkOiAke2Vycn1gKSlcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQuYmluZChEQU5URV9BTk5PVU5DRV9QT1JULCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhbm5vdW5jZVNvY2tldC5hZGRNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQKVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgTGlzdGVuaW5nIGZvciBEYW50ZSBhbm5vdW5jZXMgb24gJHtEQU5URV9BTk5PVU5DRV9HUk9VUH06JHtEQU5URV9BTk5PVU5DRV9QT1JUfWApXG5cdFx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBqb2luIGFubm91bmNlIG11bHRpY2FzdCBncm91cDogJHtlcnJ9YClcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gU3RvcmUgY2FsbGJhY2sgZm9yIGNsZWFudXBcblx0fSlcbn1cbiIsICJpbXBvcnQge1xuXHRJbnN0YW5jZVR5cGVzLFxuXHRJbnN0YW5jZUJhc2UsXG5cdEluc3RhbmNlU3RhdHVzLFxuXHRTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsXG5cdGNyZWF0ZU1vZHVsZUxvZ2dlcixcbn0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7IEdldENvbmZpZ0ZpZWxkcywgcmVzb2x2ZUhvc3QsIHJlc29sdmVNb2RlbCwgZ2V0RGV2aWNlU2NoZW1hLCB0eXBlIE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucywgVXBkYXRlVmFyaWFibGVWYWx1ZXMgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcbmltcG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH0gZnJvbSAnLi91cGdyYWRlcy5qcydcbmltcG9ydCB7IFVwZGF0ZUFjdGlvbnMgfSBmcm9tICcuL2FjdGlvbnMuanMnXG5pbXBvcnQgeyBVcGRhdGVGZWVkYmFja3MgfSBmcm9tICcuL2ZlZWRiYWNrcy5qcydcbmltcG9ydCB7IFN0Q29udHJvbGxlciB9IGZyb20gJy4vc3Rjb250cm9sbGVyLmpzJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdNb2R1bGVJbnN0YW5jZScpXG5cbmV4cG9ydCB0eXBlIE1vZHVsZVR5cGVzID0gSW5zdGFuY2VUeXBlcyAmIHtcblx0Y29uZmlnOiBNb2R1bGVDb25maWdcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTW9kdWxlSW5zdGFuY2UgZXh0ZW5kcyBJbnN0YW5jZUJhc2U8TW9kdWxlVHlwZXM+IHtcblx0Y29uZmlnITogTW9kdWxlQ29uZmlnIC8vIFNldHVwIGluIGluaXQoKVxuXHRzdENvbnRyb2xsZXIhOiBTdENvbnRyb2xsZXJcblxuXHQvKiogQ2FjaGVkIGRpc2NvdmVyeSByZXN1bHRzIFx1MjAxNCBwYXNzZWQgaW50byBnZXRDb25maWdGaWVsZHMoKSBzbyB0aGUgVUlcblx0ICogIGNhbiBzaG93IHRoZSBkaXNjb3ZlcmVkIGRldmljZSBkcm9wZG93biBvbiBzdWJzZXF1ZW50IGNvbmZpZyBvcGVucy4gKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHRjb25zdHJ1Y3RvcihpbnRlcm5hbDogdW5rbm93bikge1xuXHRcdHN1cGVyKGludGVybmFsKVxuXHR9XG5cblx0YXN5bmMgaW5pdChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0aWYgKCF0aGlzLnN0Q29udHJvbGxlcikge1xuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIgPSBuZXcgU3RDb250cm9sbGVyKClcblx0XHR9XG5cdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cblx0XHQvLyBTdGFydCBkaXNjb3ZlcnkgaW4gdGhlIGJhY2tncm91bmQgLSBkb24ndCBibG9jayBpbml0XG5cdFx0dGhpcy5ydW5EaXNjb3ZlcnkoKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBEaXNjb3ZlcnkgZmFpbGVkOiAke2V9YClcblx0XHR9KVxuXG5cdFx0Ly8gTG9hZCBkZXZpY2Ugc2NoZW1hIGFuZCBzeW5jIHRvIGNvbnRyb2xsZXIgZm9yIG1lc3NhZ2UgZGVjb2Rpbmdcblx0XHQvLyBVc2UgcmVzb2x2ZU1vZGVsIHRvIGF1dG8tZGV0ZWN0IG1vZGVsIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaWYgc2VsZWN0ZWRcblx0XHRjb25zdCBlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblxuXHRcdC8vIE9ubHkgc3luYyBtb2RlbCBpZiB3ZSBoYXZlIGEgdmFsaWQgbW9kZWxcblx0XHRpZiAoZWZmZWN0aXZlTW9kZWwpIHtcblx0XHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIud2FybignTm8gbW9kZWwgYXZhaWxhYmxlIC0gc2tpcHBpbmcgbW9kZWwgc3luYycpXG5cdFx0fVxuXG5cdFx0Ly8gV2lyZSBmZWVkYmFjayBjYWxsYmFjayBzbyBzdENvbnRyb2xsZXIgY2FuIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlc1xuXHRcdHRoaXMuc3RDb250cm9sbGVyLnNldEZlZWRiYWNrQ2FsbGJhY2soKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4ge1xuXHRcdFx0dGhpcy5jaGVja0ZlZWRiYWNrcyhmZWVkYmFja0lkKVxuXHRcdH0pXG5cblx0XHQvLyBOT1cgdXBkYXRlIGFjdGlvbnMvZmVlZGJhY2tzL3ZhcmlhYmxlcyBhZnRlciBkaXNjb3ZlcnkgYW5kIG1vZGVsIHJlc29sdXRpb25cblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKSAvLyBTZXQgaW5pdGlhbCB2YXJpYWJsZSB2YWx1ZXMgZnJvbSBkaXNjb3ZlcmVkIGRldmljZVxuXG5cdFx0Ly8gRmV0Y2ggaW5pdGlhbCBzZXR0aW5ncyBzdGF0ZSBmcm9tIHRoZSBjb25maWd1cmVkIGRldmljZSBvbmx5IGlmIHdlIGhhdmUgYSB2YWxpZCBtb2RlbFxuXHRcdGNvbnN0IHRhcmdldEhvc3QgPSB0aGlzLmhvc3Rcblx0XHRpZiAodGFyZ2V0SG9zdCAmJiBlZmZlY3RpdmVNb2RlbCkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKHRhcmdldEhvc3QpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZ2V0IGFsbCBzZXR0aW5ncyBmcm9tICR7dGFyZ2V0SG9zdH06ICR7ZX1gKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBSdW4gZGV2aWNlIGRpc2NvdmVyeSBpbiB0aGUgYmFja2dyb3VuZC5cblx0ICogVXBkYXRlcyBkaXNjb3ZlcmVkRGV2aWNlcyBhbmQgcmVmcmVzaGVzIGNvbmZpZyBvcHRpb25zIHdoZW4gY29tcGxldGUuXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIHJ1bkRpc2NvdmVyeSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRsb2dnZXIuaW5mbygnU3RhcnRpbmcgZGV2aWNlIGRpc2NvdmVyeS4uLicpXG5cblx0XHQvLyBSdW4gZGlzY292ZXJ5IHRvIHBvcHVsYXRlIHRoZSBkZXZpY2UgbGlzdFxuXHRcdHRoaXMuZGlzY292ZXJlZERldmljZXMgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5kaXNjb3ZlckRldmljZXMoKVxuXG5cdFx0aWYgKHRoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRsb2dnZXIud2FybignTm8gZGV2aWNlcyBkaXNjb3ZlcmVkJylcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYERpc2NvdmVyZWQgJHt0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aH0gZGV2aWNlKHMpOmApXG5cdFx0XHRmb3IgKGNvbnN0IGQgb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtIE1vZGVsICR7ZC5tb2RlbH0gJHtkLm1hbnVmYWN0dXJlciA/PyAnJ30gQCAke2QuaXB9YClcblx0XHRcdH1cblxuXHRcdFx0Ly8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgZnJvbSBlYWNoIGRpc2NvdmVyZWQgZGV2aWNlIHZpYSBTdHVkaW8tVCBwcm90b2NvbFxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNvbnN0IGZpcm13YXJlID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2UuaXApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9IGZpcm13YXJlXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSAke2RldmljZS5pcH06IEZpcm13YXJlICR7ZmlybXdhcmV9LCBEYW50ZSAke2RldmljZS5kYW50ZUZpcm13YXJlfWApXG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgICAtICR7ZGV2aWNlLmlwfTogRmFpbGVkIHRvIGdldCBmaXJtd2FyZTogJHtlfWApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9ICdVbmtub3duJ1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQWZ0ZXIgZGlzY292ZXJ5IGNvbXBsZXRlcywgcmVmcmVzaCBhY3Rpb25zL2ZlZWRiYWNrcy92YXJpYWJsZXNcblx0XHQvLyBOb3RlOiBkaXNjb3ZlcmVkIGRldmljZXMgd2lsbCBiZSBhdmFpbGFibGUgaW4gZ2V0Q29uZmlnRmllbGRzKCkgbmV4dCB0aW1lIGNvbmZpZyBpcyBvcGVuZWRcblxuXHRcdC8vIFJlLXJlc29sdmUgbW9kZWwgaW4gY2FzZSBhIGRpc2NvdmVyZWQgZGV2aWNlIGlzIG5vdyBhdmFpbGFibGVcblx0XHRjb25zdCBlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0XHRpZiAoZWZmZWN0aXZlTW9kZWwpIHtcblx0XHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXHRcdH1cblxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXG5cdFx0bG9nZ2VyLmluZm8oJ0RldmljZSBkaXNjb3ZlcnkgY29tcGxldGUnKVxuXHR9XG5cblx0Ly8gV2hlbiBtb2R1bGUgZ2V0cyBkZWxldGVkXG5cdGFzeW5jIGRlc3Ryb3koKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5zdENvbnRyb2xsZXI/LmNsb3NlKClcblx0XHRsb2dnZXIuZGVidWcoJ2Rlc3Ryb3knKVxuXHR9XG5cblx0YXN5bmMgY29uZmlnVXBkYXRlZChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGNvbnN0IHByZXZpb3VzSG9zdCA9IHRoaXMuaG9zdFxuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0Y29uc3QgZWZmZWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwoY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXG5cdFx0Ly8gUmVidWlsZCBhY3Rpb25zLCBmZWVkYmFja3MsIGFuZCB2YXJpYWJsZXMgd2hlbiBjb25maWcgY2hhbmdlcyAobW9kZWwgb3IgZGV2aWNlIHNlbGVjdGlvbiBjaGFuZ2VkKVxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpIC8vIFVwZGF0ZSB2YXJpYWJsZSB2YWx1ZXMgd2hlbiBjb25maWcgY2hhbmdlc1xuXG5cdFx0Ly8gSWYgdGhlIGhvc3QgY2hhbmdlZCwgcmVxdWVzdCBzZXR0aW5ncyBmcm9tIHRoZSBuZXcgZGV2aWNlXG5cdFx0Y29uc3QgbmV3SG9zdCA9IHRoaXMuaG9zdFxuXHRcdGlmIChuZXdIb3N0ICYmIG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKG5ld0hvc3QpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZ2V0IGFsbCBzZXR0aW5ncyBmcm9tICR7bmV3SG9zdH06ICR7ZX1gKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdC8qKiBMb2FkcyB0aGUgZGV2aWNlIEpTT04gZm9yIHRoZSBnaXZlbiBtb2RlbCBhbmQgcHVzaGVzIGl0IHRvIHRoZSBjb250cm9sbGVyLiAqL1xuXHRwcml2YXRlIHN5bmNNb2RlbChtb2RlbDogc3RyaW5nKTogdm9pZCB7XG5cdFx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghc2NoZW1hKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTW9kZWwgXCIke21vZGVsfVwiIG5vdCBmb3VuZCBpbiBkZXZpY2Ugc2NoZW1hc2ApXG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRNb2RlbChtb2RlbCwgW10sIHRydWUpXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRjb25zdCBhY3Rpb25zID0gQXJyYXkuaXNBcnJheShzY2hlbWEuY21kU2NoZW1hKSA/IHNjaGVtYS5jbWRTY2hlbWEgOiBbXVxuXHRcdGNvbnN0IHJlZnJlc2hBZnRlckNvbW1hbmQgPSBzY2hlbWEucmVmcmVzaEFmdGVyQ29tbWFuZCA/PyB0cnVlIC8vIERlZmF1bHQgdG8gdHJ1ZSBpZiBub3Qgc3BlY2lmaWVkXG5cblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRNb2RlbChtb2RlbCwgYWN0aW9ucywgcmVmcmVzaEFmdGVyQ29tbWFuZClcblx0XHRpZiAoYWN0aW9ucy5sZW5ndGggPT09IDApIHtcblx0XHRcdGxvZ2dlci53YXJuKGBObyBhY3Rpb25zIGZvdW5kIGZvciBtb2RlbCBcIiR7bW9kZWx9XCIgXHUyMDE0IHNldHRpbmdzIGRlY29kaW5nIHdpbGwgdXNlIHJhdyBJRHNgKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdGBMb2FkZWQgJHthY3Rpb25zLmxlbmd0aH0gYWN0aW9ucyBmb3IgbW9kZWwgXCIke21vZGVsfVwiLCBzZWN0aW9uZWQ9JHtzY2hlbWEuc2VjdGlvbmVkfSwgcmVmcmVzaEFmdGVyQ29tbWFuZD0ke3JlZnJlc2hBZnRlckNvbW1hbmR9YCxcblx0XHRcdClcblx0XHR9XG5cdH1cblxuXHQvLyBSZXR1cm4gY29uZmlnIGZpZWxkcyBmb3Igd2ViIGNvbmZpZyBcdTIwMTQgaW5jbHVkZSBkaXNjb3ZlcmVkIGRldmljZXMgc28gdGhlXG5cdC8vIGRyb3Bkb3duIGlzIHBvcHVsYXRlZC4gQ2FsbGVkIGJ5IENvbXBhbmlvbiBvbiBmaXJzdCBsb2FkIGFuZCBhZnRlclxuXHQvLyBzZXRDb25maWdTY2hlbWFWZXJzaW9uKCkgdHJpZ2dlcnMgYSByZWZyZXNoLlxuXHRnZXRDb25maWdGaWVsZHMoKTogU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkW10ge1xuXHRcdHJldHVybiBHZXRDb25maWdGaWVsZHModGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0fVxuXG5cdC8qKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgaG9zdCBJUCwgcHJlZmVycmluZyB0aGUgZGlzY292ZXJlZCBkZXZpY2Ugc2VsZWN0aW9uLiAqL1xuXHRnZXQgaG9zdCgpOiBzdHJpbmcge1xuXHRcdHJldHVybiByZXNvbHZlSG9zdCh0aGlzLmNvbmZpZylcblx0fVxuXG5cdC8qKiBSZXR1cm5zIGRpc2NvdmVyZWQgZGV2aWNlcyBmb3IgdXNlIGluIGFjdGlvbnMvY29uZmlnICovXG5cdGdldCBkZXZpY2VzKCk6IERldmljZUluZm9bXSB7XG5cdFx0cmV0dXJuIHRoaXMuZGlzY292ZXJlZERldmljZXNcblx0fVxuXG5cdHVwZGF0ZUFjdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlQWN0aW9ucyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlRmVlZGJhY2tzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZUZlZWRiYWNrcyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZVZhbHVlcygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZVZhbHVlcyh0aGlzKVxuXHR9XG59XG5cbmV4cG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH1cbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7O0FBa0JBLElBQU0scUJBQWtDLENBQUMsUUFBUSxPQUFPLFlBQVc7QUFFbEUsVUFBUSxJQUFJLElBQUksTUFBTSxZQUFXLENBQUUsSUFBSSxTQUFTLEtBQUssTUFBTSxNQUFNLEVBQUUsSUFBSSxPQUFPLEVBQUU7QUFDakY7QUFFQSxTQUFTLFVBQVUsUUFBNEIsT0FBaUIsU0FBZTtBQUM5RSxRQUFNLE9BQU8sT0FBTyxPQUFPLHFCQUFxQixhQUFhLE9BQU8sbUJBQW1CO0FBQ3ZGLE9BQUssUUFBUSxPQUFPLE9BQU87QUFDNUI7QUFPTSxTQUFVLG1CQUFtQixRQUFlO0FBQ2pELFNBQU87SUFDTixPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTztJQUM5RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTzs7QUFFaEU7OztBQ1RNLFNBQVUsWUFBWSxNQUFXO0FBRXZDOzs7QUNoQ0EsU0FBUyxvQkFBb0I7QUEyRXZCLElBQU8sc0JBQVAsY0FBbUMsYUFBbUM7RUFDbEU7RUFDQTtFQUVULElBQVcsV0FBUTtBQUNsQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUNBLElBQVcsYUFBVTtBQUNwQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUVBLElBQVksYUFBVTtBQUNyQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0FBQ25ELGFBQU8sS0FBSztJQUNiLE9BQU87QUFDTixhQUFPO0lBQ1I7RUFDRDtFQUVBLFNBQXVFO0VBRXZFLFlBQVksU0FBeUMsU0FBK0I7QUFDbkYsVUFBSztBQUVMLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVcsRUFBRSxHQUFHLFFBQU87RUFDN0I7RUFFQSxLQUFLLE1BQWMsVUFBbUIsVUFBcUI7QUFDMUQsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSx5QkFBeUI7QUFDN0YsWUFBUSxLQUFLLFFBQVE7TUFDcEIsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG9DQUFvQztNQUNyRCxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0seUJBQXlCO01BQzFDLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxtQkFBbUI7TUFDcEMsS0FBSztBQUNKO01BQ0Q7QUFDQyxvQkFBWSxLQUFLLE1BQU07QUFDdkIsY0FBTSxJQUFJLE1BQU0sc0JBQXNCO0lBQ3hDO0FBRUEsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxhQUFhLFFBQVE7QUFFM0MsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixRQUFRLEtBQUssU0FBUztNQUN0QixZQUFZOztLQUVaLEVBQ0EsS0FDQSxDQUFDLGFBQVk7QUFDWixXQUFLLFNBQVMsRUFBRSxZQUFZLE1BQU0sU0FBUTtBQUMxQyxXQUFLLFNBQVMsd0JBQXdCLElBQUksVUFBVSxJQUFJO0FBQ3hELFdBQUssS0FBSyxXQUFXO0lBQ3RCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTO0FBQ2QsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxNQUFNLFVBQXFCO0FBQzFCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7SUFFcEQsT0FBTztBQUNOLGNBQVEsS0FBSyxRQUFRO1FBQ3BCLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0NBQW9DO1FBQ3JELEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQkFBb0I7UUFDckM7QUFDQyxzQkFBWSxLQUFLLE1BQU07QUFDdkIsZ0JBQU0sSUFBSSxNQUFNLHNCQUFzQjtNQUN4QztJQUNEO0FBRUEsVUFBTSxXQUFXLEtBQUssT0FBTztBQUM3QixTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLFNBQVMsUUFBUTtBQUV2QyxTQUFLLFNBQ0gscUJBQXFCO01BQ3JCO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssT0FBTztJQUNsQixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBV0EsS0FDQyxjQUNBLGNBQ0EsaUJBQ0EsZ0JBQ0EsU0FDQSxVQUFxQjtBQUVyQixRQUFJLE9BQU8saUJBQWlCO0FBQVUsWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ3pFLFFBQUksT0FBTyxvQkFBb0IsVUFBVTtBQUN4QyxVQUFJLE9BQU8sbUJBQW1CLFlBQVksT0FBTyxZQUFZO0FBQVUsY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQzFHLFVBQUksYUFBYSxVQUFhLE9BQU8sYUFBYTtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUVqRyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsY0FBYyxlQUFlO0FBQzlFLFdBQUssV0FBVyxRQUFRLGdCQUFnQixTQUFTLFFBQVE7SUFDMUQsV0FBVyxPQUFPLG9CQUFvQixVQUFVO0FBQy9DLFVBQUksbUJBQW1CLFVBQWEsT0FBTyxtQkFBbUI7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFN0csWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLEdBQUcsTUFBUztBQUM3RCxXQUFLLFdBQVcsUUFBUSxjQUFjLGlCQUFpQixjQUFjO0lBQ3RFLE9BQU87QUFDTixZQUFNLElBQUksTUFBTSxtQkFBbUI7SUFDcEM7RUFDRDtFQUVBLGVBQ0MsY0FDQSxRQUNBLFFBQTBCO0FBRTFCLFFBQUk7QUFDSixRQUFJLE9BQU8saUJBQWlCLFVBQVU7QUFDckMsZUFBUyxPQUFPLEtBQUssY0FBYyxPQUFPO0lBQzNDLFdBQVcsT0FBTyxTQUFTLFlBQVksR0FBRztBQUN6QyxlQUFTO0lBQ1YsV0FBVyxNQUFNLFFBQVEsWUFBWSxHQUFHO0FBRXZDLGFBQU8sT0FBTyxLQUFLLFlBQVk7SUFDaEMsT0FBTztBQUNOLGVBQVMsT0FBTyxLQUFLLGFBQWEsUUFBUSxhQUFhLFlBQVksYUFBYSxVQUFVO0lBQzNGO0FBRUEsV0FBTyxPQUFPLFNBQVMsUUFBUSxXQUFXLFNBQVksU0FBUyxTQUFTLE1BQVM7RUFDbEY7RUFFQSxXQUFXLFFBQWdCLE1BQWMsU0FBaUIsVUFBcUI7QUFDOUUsUUFBSSxDQUFDLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUV6RixTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFVBQVUsS0FBSyxPQUFPO01BQ3RCLFNBQVM7TUFFVDtNQUNBO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixpQkFBVTtJQUNYLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxxQkFBcUIsU0FBK0I7QUFDbkQsUUFBSTtBQUNILFdBQUssS0FBSyxXQUFXLFFBQVEsU0FBUyxRQUFRLE1BQU07SUFDckQsU0FBUyxJQUFJO0lBRWI7RUFDRDtFQUNBLG1CQUFtQixPQUFZO0FBQzlCLFNBQUssU0FBUztBQUVkLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFFBQUk7QUFBWSxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sV0FBVyxRQUFRO0FBRWhGLFFBQUk7QUFDSCxXQUFLLEtBQUssU0FBUyxLQUFLO0lBQ3pCLFNBQVMsSUFBSTtJQUViO0VBQ0Q7Ozs7QUM5UEssU0FBVSxrQkFBbUQsS0FBWTtBQUM5RSxRQUFNLE9BQU87QUFDYixTQUFPLENBQUMsQ0FBQyxRQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSyxPQUFPLFlBQVksS0FBSyx1QkFBdUI7QUFDekc7OztBQzZCTSxJQUFnQixlQUFoQixNQUE0QjtFQUN4QjtFQUNBO0VBRUE7RUFFVCxJQUFXLEtBQUU7QUFDWixXQUFPLEtBQUssU0FBUztFQUN0QjtFQUVBLElBQVcsa0JBQWU7QUFDekIsV0FBTyxLQUFLO0VBQ2I7Ozs7O0VBTUEsSUFBVyxRQUFLO0FBQ2YsV0FBTyxLQUFLLFNBQVM7RUFDdEI7Ozs7RUFLQSxZQUFZLFVBQWlCO0FBQzVCLFFBQUksQ0FBQyxrQkFBNkIsUUFBUSxLQUFLLENBQUMsU0FBUztBQUN4RCxZQUFNLElBQUksTUFDVCxtR0FBbUc7QUFHckcsU0FBSyxXQUFXO0FBRWhCLFNBQUssVUFBVSxtQkFBa0I7QUFFakMsU0FBSyx3QkFBd0IsS0FBSyxzQkFBc0IsS0FBSyxJQUFJO0FBRWpFLFNBQUssV0FBVztNQUNmLDJCQUEyQjtNQUMzQix3QkFBd0I7O0FBR3pCLFNBQUssSUFBSSxTQUFTLGNBQWM7RUFDakM7RUErQkEsV0FBVyxXQUE0QyxZQUFpQztBQUN2RixTQUFLLFNBQVMsV0FBVyxXQUFXLFVBQVU7RUFDL0M7Ozs7O0VBdUJBLHFCQUFxQixTQUF5RDtBQUM3RSxTQUFLLFNBQVMscUJBQXFCLE9BQU87RUFDM0M7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7O0VBT0EscUJBQ0MsV0FDQSxTQUE4QztBQUU5QyxTQUFLLFNBQVMscUJBQXFCLFdBQVcsT0FBTztFQUN0RDs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsUUFBSSxNQUFNLFFBQVEsU0FBUztBQUFHLFlBQU0sSUFBSSxNQUFNLHdEQUF3RDtBQUV0RyxTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7O0VBTUEsa0JBQWtCLFFBQXVDO0FBQ3hELFNBQUssU0FBUyxrQkFBa0IsTUFBTTtFQUN2Qzs7Ozs7O0VBT0EsaUJBQW1DLFlBQWE7QUFDL0MsV0FBTyxLQUFLLFNBQVMsaUJBQWlCLFVBQVU7RUFDakQ7Ozs7RUFLQSxvQkFBaUI7QUFDaEIsU0FBSyxTQUFTLGtCQUFpQjtFQUNoQzs7Ozs7OztFQVFBLGVBQ0MsaUJBQ0csZUFBbUQ7QUFFdEQsU0FBSyxTQUFTLGVBQWUsQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO0VBQzlEOzs7OztFQU1BLHNCQUFzQixhQUFxQjtBQUMxQyxTQUFLLFNBQVMsbUJBQW1CLFdBQVc7RUFDN0M7Ozs7OztFQU9BLG9CQUFvQixXQUFtQjtBQUN0QyxTQUFLLFNBQVMsaUJBQWlCLFNBQVM7RUFDekM7Ozs7OztFQU1BLHNCQUFzQixXQUFtQjtBQUN4QyxTQUFLLFNBQVMsbUJBQW1CLFNBQVM7RUFDM0M7Ozs7OztFQU9BLHdCQUF3QixhQUFxQjtBQUM1QyxTQUFLLFNBQVMscUJBQXFCLFdBQVc7RUFDL0M7Ozs7OztFQU9BLGFBQWEsUUFBaUMsY0FBcUI7QUFDbEUsU0FBSyxTQUFTLGFBQWEsUUFBUSxZQUFZO0VBQ2hEOzs7Ozs7OztFQVNBLFFBQVEsTUFBYyxNQUFjQSxPQUFjLE1BQXNCO0FBQ3ZFLFNBQUssU0FBUyxRQUFRLE1BQU0sTUFBTUEsT0FBTSxJQUFJO0VBQzdDOzs7Ozs7Ozs7OztFQVlBLGFBQWEsUUFBd0IsU0FBdUI7QUFDM0QsU0FBSyxTQUFTLGFBQWEsUUFBUSxXQUFXLElBQUk7RUFDbkQ7Ozs7OztFQU9BLElBQUksT0FBaUIsU0FBZTtBQUNuQyxZQUFRLE9BQU87TUFDZCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNEO0FBQ0Msb0JBQVksS0FBSztBQUNqQixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO0lBQ0Y7RUFDRDtFQVlBLHNCQUNDLGVBQ0EsVUFBeUM7QUFFekMsVUFBTSxVQUFrQyxPQUFPLGtCQUFrQixXQUFXLEVBQUUsTUFBTSxjQUFhLElBQUs7QUFFdEcsVUFBTSxTQUFTLElBQUksb0JBQW9CLEtBQUssVUFBVSxPQUFPO0FBQzdELFFBQUk7QUFBVSxhQUFPLEdBQUcsV0FBVyxRQUFRO0FBRTNDLFdBQU87RUFDUjs7OztBQy9VRCxJQUFZO0NBQVosU0FBWUMsaUJBQWM7QUFDekIsRUFBQUEsZ0JBQUEsSUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsWUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsbUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFdBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGdCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx1QkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEseUJBQUEsSUFBQTtBQUNELEdBVlksbUJBQUEsaUJBQWMsQ0FBQSxFQUFBO0FBYXBCLElBQVc7Q0FBakIsU0FBaUJDLFFBQUs7QUFFUixFQUFBQSxPQUFBLEtBQUs7QUFDTCxFQUFBQSxPQUFBLFdBQ1o7QUFDWSxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLE9BQ1o7QUFDWSxFQUFBQSxPQUFBLGNBQWM7QUFDZCxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLFFBQVE7QUFDUixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLFNBQVM7QUFDVCxFQUFBQSxPQUFBLGdCQUFnQjtBQUNoQixFQUFBQSxPQUFBLFlBQVk7QUFDWixFQUFBQSxPQUFBLFdBQ1o7QUFDRixHQWxCaUIsVUFBQSxRQUFLLENBQUEsRUFBQTs7O0FDakJ0QixPQUFPLFFBQVE7QUFDZixPQUFPLFVBQVU7QUFJakIsSUFBTSxTQUFTLG1CQUFtQixRQUFRO0FBcUIxQyxTQUFTLHVCQUFvQjtBQUM1QixRQUFNLGNBQWMsS0FBSyxLQUFLLFlBQVksU0FBUyxZQUFZO0FBQy9ELFFBQU0sZUFBZSxLQUFLLEtBQUssWUFBWSxTQUFTLFdBQVc7QUFHL0QsTUFBSSxHQUFHLFdBQVcsV0FBVyxHQUFHO0FBQy9CLFdBQU8sTUFBTSx5QkFBeUIsV0FBVyxFQUFFO0FBQ25ELFdBQU87RUFDUjtBQUdBLE1BQUksR0FBRyxXQUFXLFlBQVksR0FBRztBQUNoQyxXQUFPLEtBQUsscURBQXFELFlBQVksRUFBRTtBQUMvRSxXQUFPO0VBQ1I7QUFHQSxRQUFNLFdBQVc7O01BQTBDLFdBQVc7TUFBUyxZQUFZOztBQUMzRixTQUFPLE1BQU0sUUFBUTtBQUNyQixRQUFNLElBQUksTUFBTSxRQUFRO0FBQ3pCO0FBR0EsSUFBTSxnQkFBZ0IscUJBQW9CO0FBRzFDLElBQUkscUJBQWlEO0FBTS9DLFNBQVUsbUJBQWdCO0FBQy9CLFNBQU87QUFDUjtBQU1BLFNBQVMsb0JBQWlCO0FBQ3pCLFFBQU0sVUFBK0IsQ0FBQTtBQUNyQyxNQUFJO0FBQ0gsVUFBTSxRQUFRLEdBQUcsWUFBWSxhQUFhLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLE9BQU8sQ0FBQztBQUU3RSxlQUFXLEtBQUssT0FBTztBQUN0QixZQUFNLFdBQVcsS0FBSyxLQUFLLGVBQWUsQ0FBQztBQUMzQyxZQUFNLE9BQU8sS0FBSyxNQUFNLEdBQUcsYUFBYSxVQUFVLE1BQU0sQ0FBQztBQUN6RCxVQUFJLE1BQU0sT0FBTztBQUNoQixnQkFBUSxPQUFPLEtBQUssS0FBSyxDQUFDLElBQUk7TUFDL0I7SUFDRDtBQUVBLFdBQU8sTUFBTSxVQUFVLE9BQU8sS0FBSyxPQUFPLEVBQUUsTUFBTSw0QkFBNEI7RUFDL0UsU0FBUyxHQUFHO0FBQ1gsV0FBTyxNQUFNLGtDQUFrQyxDQUFDLEVBQUU7RUFDbkQ7QUFDQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLG1CQUFnQjtBQUMvQixNQUFJLENBQUMsb0JBQW9CO0FBQ3hCLHlCQUFxQixrQkFBaUI7RUFDdkM7QUFDQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLGdCQUFnQixPQUFhO0FBQzVDLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsU0FBTyxRQUFRLEtBQUs7QUFDckI7QUFNTSxTQUFVLHNCQUFtQjtBQUNsQyxTQUFPLEtBQUssdUNBQXVDO0FBQ25ELHVCQUFxQixrQkFBaUI7QUFDdkM7QUFLQSxTQUFTLHNCQUFtQjtBQUMzQixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFNBQU8sT0FBTyxLQUFLLE9BQU8sRUFBRSxLQUFJO0FBQ2pDO0FBRU0sU0FBVSxnQkFBZ0Isb0JBQWtDLENBQUEsR0FBRTtBQUNuRSxRQUFNLFNBQVMsb0JBQW1CO0FBS2xDLFFBQU0sZ0JBQWdCO0lBQ3JCLEVBQUUsSUFBSSxJQUFJLE9BQU8sU0FBUTtJQUN6QixHQUFHLGtCQUFrQixJQUFJLENBQUMsT0FBTztNQUNoQyxJQUFJLEVBQUU7TUFDTixPQUFPLFNBQVMsRUFBRSxLQUFLLEtBQUssRUFBRSxFQUFFO01BQy9COztBQUdILFNBQU87Ozs7SUFJTjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsU0FBUztNQUNULFNBQVM7Ozs7O0lBTVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULE9BQU8sTUFBTTtNQUNiLHFCQUFxQjtNQUNyQixTQUFTOzs7OztJQU1WO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVMsT0FBTyxDQUFDLEtBQUs7TUFDdEIsU0FBUyxPQUFPLElBQUksQ0FBQyxXQUFXO1FBQy9CLElBQUk7UUFDSixPQUFPLFNBQVMsS0FBSztRQUNwQjtNQUNGLHFCQUFxQjtNQUNyQixTQUFTOzs7QUFHWjtBQU1NLFNBQVUsWUFBWSxRQUFvQjtBQUMvQyxTQUFPLE9BQU8sa0JBQWtCLE9BQU87QUFDeEM7QUFPTSxTQUFVLGFBQWEsUUFBc0IsbUJBQStCO0FBQ2pGLE1BQUksT0FBTyxnQkFBZ0I7QUFDMUIsVUFBTSxTQUFTLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxjQUFjO0FBQzNFLFdBQU8sTUFBTSxpQ0FBaUMsT0FBTyxjQUFjLG9CQUFvQixRQUFRLFNBQVMsTUFBTSxFQUFFO0FBQ2hILFFBQUksUUFBUSxPQUFPO0FBQ2xCLGFBQU8sT0FBTztJQUNmO0FBRUEsUUFBSSxrQkFBa0IsV0FBVyxHQUFHO0FBQ25DLGFBQU8sS0FBSyw2REFBNkQ7QUFDekUsYUFBTztJQUNSO0VBQ0Q7QUFDQSxTQUFPLE1BQU0sOENBQThDLE9BQU8sV0FBVyxHQUFHO0FBQ2hGLFNBQU8sT0FBTztBQUNmOzs7QUM5TU0sU0FBVSwwQkFBMEIsTUFBb0I7QUFDN0QsT0FBSyx1QkFBdUI7SUFDM0IsT0FBTyxFQUFFLE1BQU0sc0JBQXFCO0lBQ3BDLFdBQVcsRUFBRSxNQUFNLHVDQUFzQztJQUN6RCxjQUFjLEVBQUUsTUFBTSxzQkFBcUI7SUFDM0MsVUFBVSxFQUFFLE1BQU0sMEJBQXlCO0lBQzNDLFNBQVMsRUFBRSxNQUFNLGdDQUErQjtJQUNoRCxLQUFLLEVBQUUsTUFBTSxxQkFBb0I7SUFDakMsSUFBSSxFQUFFLE1BQU0sb0JBQW1CO0dBQy9CO0FBQ0Y7QUFNTSxTQUFVLHFCQUFxQixNQUFvQjtBQUV4RCxRQUFNLGNBQWMsS0FBSztBQUN6QixRQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxXQUFXO0FBRTVELE1BQUksUUFBUTtBQUNYLFNBQUssa0JBQWtCO01BQ3RCLE9BQU8sT0FBTyxTQUFTO01BQ3ZCLFdBQVcsT0FBTyxhQUFhO01BQy9CLGNBQWMsT0FBTyxnQkFBZ0I7TUFDckMsVUFBVSxPQUFPLGdCQUFnQjtNQUNqQyxTQUFTLE9BQU8saUJBQWlCO01BQ2pDLEtBQUssT0FBTyxPQUFPO01BQ25CLElBQUksT0FBTyxNQUFNO0tBQ2pCO0VBQ0YsT0FBTztBQUVOLFNBQUssa0JBQWtCO01BQ3RCLE9BQU8sS0FBSyxPQUFPLGVBQWU7TUFDbEMsV0FBVztNQUNYLGNBQWM7TUFDZCxVQUFVO01BQ1YsU0FBUztNQUNULEtBQUs7TUFDTCxJQUFJO0tBQ0o7RUFDRjtBQUNEOzs7QUM5Q08sSUFBTSxpQkFBK0Q7Ozs7Ozs7Ozs7Ozs7OztBQ3FCckUsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sY0FBYztBQUNwQixJQUFNLGdCQUFnQjtBQUN0QixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGFBQWE7QUFDbkIsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxvQkFBb0I7QUFDMUIsSUFBTSxlQUFlO0FBQ3JCLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sY0FBYztBQUdyQixTQUFVLGVBQWUsT0FBYTtBQUMzQyxVQUFRLE9BQU87SUFDZCxLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSO0FBQ0MsYUFBTyxTQUFTLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztFQUNyRDtBQUNEO0FBUU0sU0FBVSxjQUNmLE9BQ0EsT0FDQSxXQUNBLE9BQXVCO0FBRXZCLFFBQU0sTUFBTSxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzdELFFBQU0sS0FBSyxPQUFPLGNBQWMsV0FBVyxVQUFVLFNBQVMsRUFBRSxJQUFJO0FBRXBFLE1BQUksVUFBVSxRQUFXO0FBQ3hCLFVBQU0sS0FBSyxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzVELFdBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFO0VBQ25DO0FBRUEsU0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRTtBQUM3QjtBQVNNLFNBQVUsTUFBTSxPQUFlLFlBQVksR0FBQztBQUNqRCxTQUFPLEtBQUssTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLFdBQVcsR0FBRyxDQUFDO0FBQ3hEO0FBT00sU0FBVSxXQUFXLE9BQXdCO0FBQ2xELFNBQU8sS0FBSyxNQUFNLEtBQUssS0FBSyxFQUMxQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLENBQUM7QUFDWDtBQVNNLFNBQVUsZUFBZSxHQUFXLEdBQVcsR0FBUztBQUM3RCxTQUFPLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUNqQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLEVBQ1AsWUFBVyxDQUFFO0FBQ2hCO0FBUU0sU0FBVSxlQUFlLElBQVU7QUFDeEMsUUFBTSxDQUFDLE9BQU8sVUFBVSxLQUFLLElBQUksR0FBRyxNQUFNLEdBQUc7QUFDN0MsU0FBTztJQUNOO0lBQ0EsT0FBTyxTQUFTLFVBQVUsRUFBRTtJQUM1QixRQUFRLFNBQVMsT0FBTyxFQUFFOztBQUU1QjtBQVVNLFNBQVUsY0FBYyxRQUFnQixRQUFjO0FBQzNELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELE1BQUksT0FBTyxNQUFNLEVBQUUsS0FBSyxPQUFPLE1BQU0sRUFBRTtBQUFHLFdBQU87QUFDakQsU0FBTyxLQUFLLElBQUksS0FBSyxFQUFFO0FBQ3hCO0FBU00sU0FBVSxxQkFDZixZQUErQjtBQUUvQixRQUFNLGFBQWtFLENBQUE7QUFDeEUsYUFBVyxDQUFDLE9BQU8sSUFBSSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDdkQsZUFBVyxLQUFLLElBQUk7TUFDbkIsT0FBTyxLQUFLO01BQ1osV0FBVyxNQUFNLFFBQVEsS0FBSyxTQUFTLElBQUksS0FBSyxZQUFZLENBQUE7O0VBRTlEO0FBQ0EsU0FBTztBQUNSO0FBWU0sU0FBVSxxQkFDZixTQUNBLE9BQ0EsT0FDQSxXQUFpQjtBQUVqQixRQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLE1BQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxRQUFRLE9BQU8sU0FBUztBQUFHLFdBQU87QUFHeEQsTUFBSSxTQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUd2RixNQUFJLENBQUMsUUFBUTtBQUNaLGFBQVMsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFVO0FBQ3pDLFVBQUksRUFBRSxXQUFXO0FBQU8sZUFBTztBQUMvQixZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLFNBQVMsWUFBWSxFQUFFO0FBQzdCLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0lBQzVELENBQUM7RUFDRjtBQUVBLFNBQU87QUFDUjs7O0FDdE1BLFNBQVMsWUFBWSxHQUFNO0FBQzFCLFFBQU0sT0FBTztJQUNaLE1BQU0sRUFBRTtJQUNSLElBQUksRUFBRTtJQUNOLE9BQU8sRUFBRTtJQUNULFNBQVMsRUFBRTtJQUNYLFNBQVMsRUFBRTs7QUFHWixVQUFRLEVBQUUsTUFBTTtJQUNmLEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLENBQUEsRUFBRTtJQUUzQyxLQUFLO0FBQ0osYUFBTztRQUNOLEdBQUc7UUFDSCxLQUFLLEVBQUU7UUFDUCxLQUFLLEVBQUU7UUFDUCxNQUFNLEVBQUUsUUFBUTtRQUNoQixPQUFPOztJQUdULEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLE1BQUs7SUFFOUMsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0w7QUFDQyxhQUFPO0VBQ1Q7QUFDRDtBQU1NLFNBQVUsZUFBWTtBQUMzQixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sVUFBc0MsQ0FBQTtBQUU1QyxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLEtBQUssV0FBVztBQUMxQixZQUFNLFdBQVcsY0FBYyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7QUFFcEQsWUFBTSxXQUFXLEVBQUUsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRWpELFlBQU0sU0FBb0M7UUFDekMsTUFBTSxTQUFTLEtBQUssS0FBSyxFQUFFLElBQUk7UUFDL0I7UUFDQSxVQUFVLFlBQVc7UUFFckI7O0FBR0QsY0FBUSxRQUFRLElBQUk7SUFDckI7RUFDRDtBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsaUJBQWM7QUFDN0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxRQUFNLFlBQTBDLENBQUE7QUFFaEQsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxXQUFXLFdBQVc7QUFDaEMsWUFBTSxpQkFBaUIsY0FBYyxPQUFPLFFBQVEsUUFBUSxRQUFRLEVBQUU7QUFHdEUsWUFBTSxjQUFjLFFBQVEsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRzFELFlBQU0sZUFBZSxXQUFXLE9BQU8sQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBR3ZFLG1CQUFhLEtBQUs7UUFDakIsTUFBTTtRQUNOLElBQUk7UUFDSixPQUFPO1FBQ1AsU0FBUztRQUNULFNBQVM7T0FDVDtBQUdELFlBQU0sZ0JBQXFCO1FBQzFCLE1BQU07UUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtRQUNyQyxTQUFTO1FBQ1QsVUFBVSxNQUFLO0FBRWQsaUJBQU87UUFDUjs7QUFHRCxnQkFBVSxjQUFjLElBQUk7SUFDN0I7RUFDRDtBQUVBLFNBQU87QUFDUjs7O0FDNUhBLE9BQU9DLFdBQVU7OztBQ0xqQixPQUFPQyxTQUFRO0FBZ0JmLElBQU1DLFVBQVMsbUJBQW1CLGdCQUFnQjtBQXlDbEQsU0FBUyxlQUFlLE9BQWE7QUFDcEMsUUFBTSxTQUFTLG9CQUFJLElBQUc7QUFDdEIsTUFBSSxZQUFZO0FBRWhCLE1BQUk7QUFFSCxVQUFNLE9BQU8sZ0JBQWdCLEtBQUs7QUFDbEMsUUFBSSxDQUFDLE1BQU07QUFFVixhQUFPLEVBQUUsV0FBVyxPQUFNO0lBQzNCO0FBR0EsZ0JBQVksS0FBSyxhQUFhO0FBRzlCLGVBQVcsVUFBVSxLQUFLLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0saUJBQWlCLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBd0IsSUFBSSxTQUFTLGFBQWE7QUFDL0YsVUFBSSxnQkFBZ0I7QUFFbkIsZUFBTyxJQUFJLE9BQU8sRUFBRTtBQUdwQixjQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLE9BQU8sT0FBTztBQUNwRixZQUFJLGFBQWEsU0FBUztBQUN6QixxQkFBVyxVQUFVLFlBQVksU0FBUztBQUN6QyxnQkFBSSxPQUFPLE9BQU8sT0FBTyxVQUFVO0FBQ2xDLHFCQUFPLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRTtZQUNqQztVQUNEO1FBQ0Q7TUFDRDtJQUNEO0VBQ0QsU0FBUyxNQUFNO0VBRWY7QUFFQSxTQUFPLEVBQUUsV0FBVyxPQUFNO0FBQzNCO0FBTUEsU0FBUyxzQkFBc0IsS0FBVztBQUN6QyxRQUFNLFdBQVcsSUFBSSxRQUFRLE9BQU8sS0FBSyxVQUFVLENBQUM7QUFDcEQsTUFBSSxXQUFXO0FBQUcsVUFBTSxJQUFJLE1BQU0saUNBQWlDO0FBRW5FLFFBQU0sZUFBZSxXQUFXO0FBQ2hDLE1BQUksSUFBSSxZQUFZLE1BQU0sSUFBTTtBQUMvQixVQUFNLElBQUksTUFBTSx1Q0FBdUMsSUFBSSxZQUFZLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRTtFQUN4RjtBQUVBLFNBQU87QUFDUjtBQU1BLFNBQVMsdUJBQXVCLE9BQWUsU0FBc0Isb0JBQUksSUFBRyxHQUFFO0FBQzdFLE1BQUksSUFBSTtBQUNSLFFBQU0sTUFBdUIsQ0FBQTtBQUU3QixTQUFPLElBQUksTUFBTSxRQUFRO0FBQ3hCLFVBQU0sS0FBSyxNQUFNLENBQUM7QUFDbEIsUUFBSSxJQUFJLEtBQUssTUFBTTtBQUFRO0FBRzNCLFFBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTSxRQUFRO0FBQzNDLFVBQUksS0FBSztRQUNSLFFBQVE7UUFDUjtRQUNBLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQztPQUNyRDtBQUNELFdBQUs7QUFDTDtJQUNEO0FBRUEsUUFBSSxLQUFLLEVBQUUsUUFBUSxjQUFjLElBQUksWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFFO0FBQ2pFLFNBQUs7RUFDTjtBQUVBLFNBQU87QUFDUjtBQUVNLFNBQVUseUJBQXlCLEtBQWEsT0FBYTtBQUNsRSxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSw0QkFBNEI7RUFDN0M7QUFFQSxRQUFNLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFDNUIsUUFBTSxRQUFRLE1BQU07QUFDcEIsUUFBTSxNQUFNLFFBQVE7QUFDcEIsTUFBSSxNQUFNLElBQUk7QUFBUSxVQUFNLElBQUksTUFBTSxzQkFBc0I7QUFFNUQsUUFBTSxFQUFFLE9BQU0sSUFBSyxlQUFlLEtBQUs7QUFDdkMsU0FBTyx1QkFBdUIsSUFBSSxTQUFTLE9BQU8sR0FBRyxHQUFHLE1BQU07QUFDL0Q7QUFNTSxTQUFVLDhCQUE4QixLQUFhLE9BQWE7QUFDdkUsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0sNEJBQTRCO0VBQzdDO0FBR0EsTUFBSSxJQUFJLFVBQVUsdUJBQXVCLE1BQU0sSUFBSSxNQUFNO0FBQ3pELFFBQU0sTUFBTSxJQUFJLFNBQVM7QUFDekIsUUFBTSxNQUF1QixDQUFBO0FBRzdCLFFBQU0sRUFBRSxPQUFNLElBQUssZUFBZSxLQUFLO0FBR3ZDLFFBQU0sb0JBQW9CLENBQUMsYUFBYSxpQkFBaUIsV0FBVztBQUVwRSxTQUFPLElBQUksSUFBSSxLQUFLO0FBQ25CLFVBQU0sU0FBUyxJQUFJLENBQUM7QUFDcEIsVUFBTSxlQUFlLElBQUksSUFBSSxDQUFDO0FBRTlCLFVBQU0sYUFBYSxJQUFJLElBQUk7QUFDM0IsUUFBSSxhQUFhO0FBQUs7QUFHdEIsVUFBTSxXQUFXLGtCQUFrQixTQUFTLFlBQVk7QUFFeEQsUUFBSTtBQUNKLFFBQUk7QUFDSixRQUFJO0FBRUosUUFBSSxVQUFVO0FBRWIsY0FBUSxJQUFJLElBQUksQ0FBQztBQUNqQixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVCxPQUFPO0FBRU4sZ0JBQVUsSUFBSSxJQUFJLENBQUM7QUFDbkIsVUFBSSxJQUFJO0lBQ1Q7QUFFQSxVQUFNLE9BQU8sSUFBSTtBQUVqQixXQUFPLElBQUksSUFBSSxNQUFNO0FBQ3BCLFlBQU0sS0FBSyxJQUFJLENBQUM7QUFDaEIsVUFBSTtBQUdKLFVBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTTtBQUNuQyxxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ2hELGFBQUs7TUFDTixPQUFPO0FBQ04scUJBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ3hCLGFBQUs7TUFDTjtBQUVBLFlBQU0sVUFBeUI7UUFDOUIsUUFBUTtRQUNSO1FBQ0E7O0FBRUQsVUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQVEsUUFBUTtNQUNqQjtBQUNBLFVBQUksS0FBSyxPQUFPO0lBQ2pCO0FBRUEsUUFBSTtFQUNMO0FBRUEsU0FBTztBQUNSO0FBV00sU0FBVSxzQkFBc0IsT0FBZSxLQUFXO0FBQy9ELFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLGlDQUFpQyxNQUFNLFNBQVMsRUFBRSxDQUFDLEdBQUc7RUFDdkU7QUFDQSxRQUFNLEVBQUUsVUFBUyxJQUFLLGVBQWUsS0FBSztBQUMxQyxTQUFPLFlBQVksOEJBQThCLEtBQUssS0FBSyxJQUFJLHlCQUF5QixLQUFLLEtBQUs7QUFDbkc7QUFNTSxTQUFVLG9CQUFvQixTQUF3QixTQUFtQjtBQUU5RSxNQUFJLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsUUFBUSxVQUFVLEVBQUUsT0FBTyxRQUFRLEVBQUU7QUFLbkYsTUFBSSxDQUFDLFFBQVE7QUFDWixVQUFNLGFBQWEsUUFBUSxLQUFLLENBQUMsTUFBSztBQUNyQyxVQUFJLEVBQUUsV0FBVyxRQUFRO0FBQVEsZUFBTztBQUV4QyxZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQy9ELFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLGdCQUFnQixRQUFRLEtBQUssRUFBRTtBQUNyQyxhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtJQUM5RCxDQUFDO0FBQ0QsUUFBSSxZQUFZO0FBQ2YsZUFBUztJQUNWO0VBQ0Q7QUFFQSxRQUFNLFNBQVMsTUFBTSxRQUFRLE1BQU07QUFDbkMsUUFBTSxRQUFRLE1BQU0sUUFBUSxFQUFFO0FBQzlCLFFBQU0sU0FBUyxXQUFXLFFBQVEsVUFBVTtBQUM1QyxRQUFNLFNBQ0wsUUFBUSxXQUFXLFdBQVcsSUFDM0IsZUFBZSxRQUFRLFdBQVcsQ0FBQyxHQUFHLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsQ0FBQyxJQUNsRixRQUFRLFdBQVcsV0FBVyxJQUM3QixRQUFRLFdBQVcsQ0FBQyxJQUNwQixRQUFRLFdBQVcsS0FBSyxHQUFHO0FBR2hDLFFBQU0sV0FBVyxRQUFRLFVBQVUsU0FBWSxPQUFPLFFBQVEsS0FBSyxLQUFLO0FBQ3hFLFFBQU0sU0FBUyxPQUFPLE1BQU0sR0FBRyxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU07QUFHakUsTUFBSSxRQUFRO0FBQ1gsUUFBSSxPQUFPLE9BQU87QUFHbEIsUUFBSSxRQUFRLFVBQVUsUUFBVztBQUNoQyxhQUFPLEdBQUcsSUFBSSxNQUFNLFFBQVEsUUFBUSxDQUFDO0lBQ3RDLE9BRUs7QUFDSixZQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksYUFBYSxTQUFTO0FBQ3pCLGNBQU0sZ0JBQWdCLFFBQVEsS0FBSyxPQUFPO0FBQzFDLGNBQU0sY0FBYyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGFBQWE7QUFDMUUsWUFBSSxhQUFhO0FBQ2hCLGlCQUFPLEdBQUcsSUFBSSxJQUFJLFlBQVksS0FBSztRQUNwQztNQUNEO0lBQ0Q7QUFHQSxVQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFFBQUksYUFBYSxXQUFXLFFBQVEsV0FBVyxXQUFXLEdBQUc7QUFDNUQsWUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxXQUFXLENBQUMsQ0FBQztBQUM3RSxVQUFJLFFBQVE7QUFDWCxlQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNO01BQ3ZEO0lBQ0Q7QUFDQSxXQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxNQUFNO0VBQ3RDO0FBR0EsU0FBTyxHQUFHLE1BQU07QUFDakI7QUFpQk0sU0FBVSxpQ0FDZixPQUNBLEtBQVc7QUFFWCxRQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsUUFBTSxvQkFBb0IsUUFBUTtBQUdsQyxNQUFJLHNCQUFzQixRQUFXO0FBQ3BDLFVBQU0sV0FBVyxvQkFDZCw4QkFBOEIsS0FBSyxLQUFLLElBQ3hDLHlCQUF5QixLQUFLLEtBQUs7QUFDdEMsV0FBTyxFQUFFLFVBQVUsbUJBQW1CLEtBQUk7RUFDM0M7QUFHQSxNQUFJLGVBQWdDLENBQUE7QUFDcEMsTUFBSSxvQkFBcUMsQ0FBQTtBQUV6QyxNQUFJO0FBQ0gsbUJBQWUseUJBQXlCLEtBQUssS0FBSztFQUNuRCxTQUFTLEdBQUc7QUFDWCxJQUFBQSxRQUFPLE1BQU0sdUJBQXVCLENBQUMsRUFBRTtFQUN4QztBQUVBLE1BQUk7QUFDSCx3QkFBb0IsOEJBQThCLEtBQUssS0FBSztFQUM3RCxTQUFTLEdBQUc7QUFDWCxJQUFBQSxRQUFPLE1BQU0sNEJBQTRCLENBQUMsRUFBRTtFQUM3QztBQUdBLE1BQUksa0JBQWtCLFNBQVMsYUFBYSxRQUFRO0FBQ25ELElBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsa0JBQWtCLE1BQU0sWUFBWSxhQUFhLE1BQU0sR0FBRztBQUNuSCxXQUFPLEVBQUUsVUFBVSxtQkFBbUIsbUJBQW1CLEtBQUk7RUFDOUQsV0FBVyxhQUFhLFNBQVMsR0FBRztBQUNuQyxJQUFBQSxRQUFPLEtBQUssbUNBQW1DLGFBQWEsTUFBTSxpQkFBaUIsa0JBQWtCLE1BQU0sR0FBRztBQUM5RyxXQUFPLEVBQUUsVUFBVSxjQUFjLG1CQUFtQixNQUFLO0VBQzFELE9BQU87QUFFTixJQUFBQSxRQUFPLEtBQUssdURBQXVELEtBQUssRUFBRTtBQUMxRSxXQUFPLEVBQUUsVUFBVSxDQUFBLEdBQUksbUJBQW1CLEtBQUk7RUFDL0M7QUFDRDtBQUVNLFNBQVUsNEJBQTRCLE9BQWUsS0FBVztBQUNyRSxRQUFNLEVBQUUsVUFBUyxJQUFLLGVBQWUsS0FBSztBQUMxQyxTQUFPLFlBQVksOEJBQThCLEtBQUssS0FBSyxJQUFJLHlCQUF5QixLQUFLLEtBQUs7QUFDbkc7QUFTQSxTQUFTLG1CQUFtQixZQUFvQjtBQUMvQyxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFdBQU8sRUFBRSxJQUFJLFNBQVMsT0FBTyxTQUFTLE1BQU0sVUFBVSxTQUFTLFdBQVcsQ0FBQyxFQUFDO0VBQzdFO0FBRUEsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUM1QixVQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsSUFBSTtBQUNsQixXQUFPO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxNQUFNO01BQ04sU0FBUyxlQUFlLEdBQUcsR0FBRyxDQUFDOztFQUVqQztBQUVBLFNBQU8sRUFBRSxJQUFJLFNBQVMsT0FBTyxTQUFTLE1BQU0sT0FBTyxTQUFTLENBQUMsR0FBRyxVQUFVLEVBQUM7QUFDNUU7QUFNTSxTQUFVLDRCQUNmLFdBQ0EsUUFDQSxXQUFzQztBQUV0QyxRQUFNLE1BQU0sZ0JBQWdCLFNBQVM7QUFHckMsTUFBSSxDQUFDLElBQUksV0FBVztBQUNuQixRQUFJLFlBQVksQ0FBQTtFQUNqQjtBQUdBLFFBQU0sYUFBYSxPQUFPLE9BQU8sU0FBUyxFQUN4QyxPQUFPLENBQUMsTUFBTSxFQUFFLFVBQVUsVUFBVSxLQUFLLEVBQ3pDLEtBQUssQ0FBQyxHQUFHLE1BQU0sY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLElBQUksY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLENBQUM7QUFFbEcsRUFBQUMsUUFBTyxLQUFLLG1CQUFtQixVQUFVLEtBQUssRUFBRTtBQUNoRCxFQUFBQSxRQUFPLE1BQU0sNkJBQTZCLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxJQUFJLENBQUMsRUFBRTtBQUVyRixhQUFXLEVBQUUsUUFBUSxJQUFJLFdBQVUsS0FBTSxRQUFRO0FBQ2hELFFBQUksU0FBUyxJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFFekUsUUFBSSxDQUFDLFFBQVE7QUFFWixpQkFBVyxLQUFLLFlBQVk7QUFDM0IsY0FBTSxRQUFRLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUN6RSxZQUFJLE9BQU87QUFDVixtQkFBUyxnQkFBZ0IsS0FBSztBQUM5QixpQkFBTyxPQUFPLEdBQUcsTUFBTSxJQUFJLHlCQUF5QixFQUFFLEtBQUs7QUFDM0QsVUFBQUEsUUFBTyxLQUFLLG9CQUFvQixNQUFNLEVBQUUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxFQUFFO0FBQ2pFO1FBQ0Q7TUFDRDtJQUNEO0FBRUEsUUFBSSxDQUFDLFFBQVE7QUFDWixlQUFTO1FBQ1I7UUFDQTtRQUNBLE1BQU0sbUJBQW1CLE1BQU0sRUFBRSxFQUFFLFlBQVcsQ0FBRTtRQUNoRCxTQUFTLENBQUMsbUJBQW1CLFVBQVUsQ0FBQzs7QUFFekMsTUFBQUEsUUFBTyxLQUFLLDJCQUEyQixNQUFNLEVBQUUsQ0FBQyxFQUFFO0lBQ25ELE9BQU87QUFDTixZQUFNLE1BQU0sT0FBTyxVQUFVLENBQUM7QUFDOUIsVUFBSTtBQUFLLFlBQUksVUFBVSxtQkFBbUIsVUFBVSxFQUFFO0lBQ3ZEO0FBR0EsVUFBTSxTQUFTLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsT0FBTyxVQUFVLEVBQUUsT0FBTyxPQUFPLEVBQUU7QUFDekYsUUFBSSxDQUFDO0FBQVEsVUFBSSxVQUFVLEtBQUssTUFBTTtFQUN2QztBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsb0JBQW9CLFVBQWtCLFNBQW9CO0FBQ3pFLE1BQUk7QUFFSCxVQUFNLGFBQWtCLEVBQUUsT0FBTyxRQUFRLE1BQUs7QUFHOUMsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRO0lBQ2hDO0FBR0EsUUFBSSx5QkFBeUIsU0FBUztBQUNyQyxpQkFBVyxzQkFBc0IsUUFBUTtJQUMxQztBQUNBLFFBQUksZUFBZSxTQUFTO0FBQzNCLGlCQUFXLFlBQVksUUFBUTtJQUNoQztBQUVBLGVBQVcsT0FBTyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3ZDLFVBQUksRUFBRSxPQUFPLGFBQWE7QUFDekIsbUJBQVcsR0FBRyxJQUFLLFFBQWdCLEdBQUc7TUFDdkM7SUFDRDtBQUdBLFFBQUksT0FBTyxLQUFLLFVBQVUsWUFBWSxNQUFNLENBQUM7QUFLN0MsV0FBTyxLQUFLLFFBQVEsMERBQTBELDZCQUE2QjtBQUUzRyxJQUFBQyxJQUFHLGNBQWMsVUFBVSxPQUFPLE1BQU0sTUFBTTtFQUMvQyxTQUFTLEdBQUc7QUFDWCxJQUFBRCxRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtFQUN0QztBQUNEOzs7QURsZ0JBLElBQU1FLFVBQVMsbUJBQW1CLFNBQVM7QUFFckMsU0FBVSxjQUFjLE1BQW9CO0FBQ2pELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxhQUFhLGFBQVk7QUFDL0IsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0sZUFBb0IsQ0FBQTtBQUcxQixRQUFNLGNBQWMsYUFBYSxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQzFELEVBQUFBLFFBQU8sS0FDTiwrQkFBK0IsV0FBVyxzQkFBc0IsS0FBSyxPQUFPLGNBQWMsb0JBQW9CLEtBQUssUUFBUSxNQUFNLEVBQUU7QUFPcEksZUFBYSx1QkFBdUIsSUFBSTtJQUN2QyxNQUFNO0lBQ04sU0FBUyxDQUFBO0lBQ1QsVUFBVSxZQUFXO0FBQ3BCLFlBQU0sUUFBUTtBQUNkLFlBQU0sS0FBSyxLQUFLO0FBRWhCLFlBQU0sTUFBTSxNQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUd6RCxVQUFJLFlBQVksZ0JBQWdCLEtBQUs7QUFDckMsVUFBSSxDQUFDLFdBQVc7QUFDZixRQUFBQSxRQUFPLE1BQU0sU0FBUyxLQUFLLDRCQUE0QjtBQUN2RDtNQUNEO0FBR0EsWUFBTSxFQUFFLFVBQVUsUUFBUSxrQkFBaUIsSUFBSyxpQ0FBaUMsT0FBTyxHQUFHO0FBQzNGLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSyxVQUFVLE1BQU0sQ0FBQyxFQUFFO0FBR3RELFVBQUksc0JBQXNCLE1BQU07QUFDL0IsUUFBQUEsUUFBTyxLQUFLLDJCQUEyQixpQkFBaUIsd0JBQXdCO0FBQ2hGLG9CQUFZLEVBQUUsR0FBRyxXQUFXLFdBQVcsa0JBQWlCO01BQ3pEO0FBRUEsWUFBTSxVQUFVLDRCQUE0QixXQUFXLFFBQVEsT0FBTztBQUN0RSxNQUFBQSxRQUFPLE1BQU0scUJBQXFCLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxDQUFDLEVBQUU7QUFHcEUsWUFBTUMsaUJBQWdCLGlCQUFnQjtBQUN0QyxZQUFNLGFBQWFDLE1BQUssS0FBS0QsZ0JBQWUsUUFBUSxLQUFLLE9BQU87QUFDaEUsMEJBQW9CLFlBQVksT0FBTztBQUd2QywwQkFBbUI7QUFFbkIsTUFBQUQsUUFBTyxLQUFLLFNBQVMsS0FBSyx3Q0FBd0M7SUFDbkU7O0FBT0QsYUFBVyxDQUFDLFVBQVUsTUFBTSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDNUQsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxRQUFRO0FBR3hELFFBQUksVUFBVTtBQUFhO0FBRzNCLFVBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsVUFBTSxZQUFZLFFBQVEsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sTUFBTTtBQUUzRixpQkFBYSxRQUFRLElBQUk7TUFDeEIsR0FBRztNQUNILFVBQVUsT0FBTyxVQUFjO0FBQzlCLGNBQU0sS0FBSyxLQUFLO0FBRWhCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBQ3pGLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTztBQUNuQyxjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxjQUFNLFlBQVksU0FBUztBQUUzQixjQUFNLEtBQUssYUFBYSxhQUFhLGFBQWEsT0FBTyxPQUFPLFdBQVcsT0FBTyxFQUFFO01BQ3JGOztFQUVGO0FBS0EsUUFBTSxlQUFlLFFBQVEsV0FBVztBQUN4QyxNQUFJLGNBQWM7QUFDakIsVUFBTSxtQkFBbUIsYUFBYSxhQUFhLENBQUEsR0FBSSxLQUFLLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxNQUFNLENBQUM7QUFFL0YsUUFBSSxpQkFBaUI7QUFDcEIsWUFBTSxXQUFXLEdBQUcsV0FBVztBQUUvQixtQkFBYSxRQUFRLElBQUk7UUFDeEIsTUFBTSxTQUFTLFdBQVc7UUFDMUIsU0FBUyxDQUFBO1FBQ1QsVUFBVSxZQUFXO0FBQ3BCLGdCQUFNLEtBQUssS0FBSztBQUNoQixVQUFBQSxRQUFPLEtBQUsseUJBQW9CLFdBQVcsTUFBTSxFQUFFLEVBQUU7QUFDckQsZ0JBQU0sS0FBSyxhQUFhLGNBQWMsYUFBYSxFQUFFO1FBQ3REOztJQUVGO0VBQ0Q7QUFFQSxPQUFLLHFCQUFxQixZQUFZO0FBRXRDLEVBQUFBLFFBQU8sS0FBSyxpQ0FBaUMsT0FBTyxLQUFLLFlBQVksRUFBRSxNQUFNLEVBQUU7QUFDaEY7OztBRXBIQSxJQUFNRyxVQUFTLG1CQUFtQixXQUFXO0FBSzdDLFNBQVMsaUJBQ1IsU0FDQSxPQUNBLE9BQ0EsV0FDQSxPQUFhO0FBRWIsUUFBTSxVQUFVLHFCQUFxQixTQUFTLE9BQU8sT0FBTyxTQUFTO0FBQ3JFLE1BQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxRQUFRLFFBQVEsT0FBTztBQUFHLFdBQU87QUFHeEQsUUFBTSxjQUFjLFFBQVEsUUFBUSxLQUFLLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUN6RSxNQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sUUFBUSxZQUFZLE9BQU87QUFBRyxXQUFPO0FBR2hFLFFBQU0sU0FBUyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLEtBQUs7QUFDbEUsU0FBTyxRQUFRLFNBQVM7QUFDekI7QUFNTSxTQUFVLGdCQUFnQixNQUFvQjtBQUNuRCxRQUFNLGFBQWEsaUJBQWdCO0FBQ25DLFFBQU0sZUFBZSxlQUFjO0FBQ25DLFFBQU0sVUFBVSxxQkFBcUIsVUFBVTtBQUMvQyxRQUFNLGlCQUFzQixDQUFBO0FBRzVCLFFBQU0sY0FBYyxhQUFhLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDMUQsRUFBQUEsUUFBTyxLQUNOLGlDQUFpQyxXQUFXLHNCQUFzQixLQUFLLE9BQU8sY0FBYyxvQkFBb0IsS0FBSyxRQUFRLE1BQU0sRUFBRTtBQU90SSxhQUFXLENBQUMsWUFBWSxRQUFRLEtBQUssT0FBTyxRQUFRLFlBQVksR0FBRztBQUNsRSxVQUFNLEVBQUUsT0FBTyxPQUFPLE9BQU0sSUFBSyxlQUFlLFVBQVU7QUFHMUQsUUFBSSxVQUFVO0FBQWE7QUFHM0IsbUJBQWUsVUFBVSxJQUFJO01BQzVCLEdBQUc7TUFDSCxVQUFVLENBQUMsa0JBQXNCO0FBQ2hDLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxjQUFjLFFBQVEsT0FBTztBQUMzQyxjQUFNLFFBQVEsY0FBYyxRQUFRLE9BQU8sS0FBSztBQUNoRCxjQUFNLFlBQVksU0FBUztBQUMzQixjQUFNLFVBQVUsS0FBSyxhQUFhLGdCQUFnQixJQUFJLE9BQU8sV0FBVyxLQUFLO0FBRzdFLGNBQU0sWUFBWSxjQUFjLFFBQVEsV0FBVyxLQUFLO0FBRXhELFlBQUksYUFBYSxZQUFZLFFBQVc7QUFFdkMsaUJBQU8saUJBQWlCLFNBQVMsT0FBTyxPQUFPLFdBQVcsT0FBTztRQUNsRTtBQUdBLGVBQU8sV0FBVztNQUNuQjs7RUFFRjtBQUVBLE9BQUssdUJBQXVCLGNBQWM7QUFFMUMsRUFBQUEsUUFBTyxLQUFLLHFDQUFxQyxPQUFPLEtBQUssY0FBYyxFQUFFLE1BQU0sRUFBRTtBQUN0Rjs7O0FDbkZBLE9BQU9DLFlBQVc7QUFDbEIsT0FBT0MsU0FBUTs7O0FDRGYsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sUUFBUTtBQUlmLElBQU1DLFVBQVMsbUJBQW1CLE9BQU87QUFLbEMsSUFBTSx5QkFBeUI7QUFFL0IsSUFBTSwwQkFBMEI7QUFnQmhDLElBQU0scUJBQXFCLE1BQU87QUFpQm5DLFNBQVUsd0JBQXFCO0FBQ3BDLFFBQU0sTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQzlCLFFBQU0sTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssS0FBTTtBQUU3QyxNQUFJLGNBQWMsT0FBUSxDQUFDO0FBQzNCLE1BQUksY0FBYyx3QkFBd0IsQ0FBQztBQUMzQyxNQUFJLGNBQWMsS0FBSyxDQUFDO0FBRXhCLFFBQU0sTUFBTSxpQkFBZ0I7QUFDNUIsTUFBSSxLQUFLLEtBQUssQ0FBQztBQUVmLFNBQU8sS0FBSyxZQUFZLE9BQU8sRUFBRSxLQUFLLEtBQUssRUFBRTtBQUM3QyxNQUFJLGNBQWMsTUFBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFRLEVBQUU7QUFDNUIsTUFBSSxjQUFjLEtBQVksRUFBRTtBQUVoQyxTQUFPO0FBQ1I7QUFHTSxTQUFVLG1CQUFnQjtBQUMvQixNQUFJO0FBQ0gsVUFBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLGVBQVcsUUFBUSxPQUFPLEtBQUssTUFBTSxHQUFHO0FBQ3ZDLGlCQUFXLFFBQVEsT0FBTyxJQUFJLEtBQUssQ0FBQSxHQUFJO0FBQ3RDLFlBQUksQ0FBQyxLQUFLLFlBQVksS0FBSyxXQUFXLFVBQVUsS0FBSyxPQUFPLEtBQUssUUFBUSxxQkFBcUI7QUFDN0YsaUJBQU8sT0FBTyxLQUFLLEtBQUssSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBYyxTQUFTLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDM0U7TUFDRDtJQUNEO0VBQ0QsUUFBUTtFQUVSO0FBQ0EsU0FBTyxPQUFPLE1BQU0sR0FBRyxDQUFDO0FBQ3pCO0FBaUJNLFNBQVUsdUJBQXVCLEtBQWEsT0FBYTtBQUNoRSxNQUFJLElBQUksU0FBUztBQUFvQixXQUFPO0FBQzVDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRLFdBQU87QUFDM0MsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQXlCLFdBQU87QUFDNUQsTUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWSxXQUFPO0FBRWxFLFFBQU0sVUFBVSxDQUFDLFFBQWdCLFFBQ2hDLElBQ0UsU0FBUyxRQUFRLFNBQVMsR0FBRyxFQUM3QixTQUFTLE9BQU8sRUFDaEIsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUNiLEtBQUk7QUFFUCxRQUFNLFFBQVEsSUFBSSxTQUFTLEdBQUcsRUFBRTtBQUNoQyxRQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztBQUM1RSxRQUFNLE1BQU0sU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUc7QUFFekUsUUFBTSxPQUFPLFFBQVEsSUFBTSxFQUFFO0FBQzdCLFFBQU0sZUFBZSxRQUFRLElBQU0sRUFBRTtBQUNyQyxRQUFNLFdBQVcsUUFBUSxLQUFNLEVBQUU7QUFDakMsUUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEVBQUksQ0FBQyxJQUFJLElBQUksRUFBSSxDQUFDO0FBRS9DLE1BQUksQ0FBQztBQUFVLFdBQU87QUFJdEIsUUFBTSxRQUFRLFNBQ1osUUFBUSxjQUFjLEVBQUUsRUFDeEIsS0FBSSxFQUNKLE1BQU0sS0FBSyxFQUFFLENBQUM7QUFFaEIsU0FBTztJQUNOLElBQUk7SUFDSjtJQUNBO0lBQ0E7SUFDQSxXQUFXOztJQUNYO0lBQ0E7O0FBRUY7QUFNQSxlQUFzQiw4QkFBOEIsUUFBYztBQUNqRSxTQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksV0FBVztBQUNmLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLENBQUMsVUFBVTtBQUNkLG1CQUFXO0FBQ1gsWUFBSSxNQUFLO0FBQ1QsZUFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDN0M7SUFDRCxDQUFDO0FBR0QsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxrQkFBUSxTQUFTO1FBQ2xCO01BQ0QsU0FBUyxJQUFJO0FBQ1osWUFBSSxDQUFDLFVBQVU7QUFDZCxxQkFBVztBQUNYLGNBQUksTUFBSztBQUNULGlCQUFPLElBQUksTUFBTSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQzdCO01BQ0Q7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBZ0JBLGVBQXNCLGdCQUNyQixVQUNBLGdCQUNBLGtCQUNBLFlBQVksS0FBSTtBQUVoQixRQUFNLHVCQUF1QjtBQUM3QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLGVBQWU7QUFFckIsUUFBTSxRQUFRLG9CQUFJLElBQUc7QUFDckIsUUFBTSxhQUFhLG9CQUFJLElBQUc7QUFFMUIsU0FBTyxJQUFJLFFBQXNCLENBQUMsWUFBVztBQUs1QyxVQUFNLGlCQUFpQixNQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFM0UsVUFBTSxVQUFVLE1BQUs7QUFDcEIsVUFBSTtBQUNILHVCQUFlLGVBQWUsb0JBQW9CO01BQ25ELFFBQVE7TUFFUjtBQUNBLFVBQUk7QUFDSCx1QkFBZSxNQUFLO01BQ3JCLFFBQVE7TUFFUjtBQUNBLGNBQVEsTUFBTSxLQUFLLE1BQU0sT0FBTSxDQUFFLENBQUM7SUFDbkM7QUFFQSxVQUFNLFFBQVEsV0FBVyxTQUFTLFNBQVM7QUFDM0MsVUFBTSxRQUFPO0FBRWIsbUJBQWUsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNsQyxNQUFBQSxRQUFPLEtBQUssMEJBQTBCLElBQUksT0FBTyxFQUFFO0lBQ3BELENBQUM7QUFFRCxtQkFBZSxHQUFHLFdBQVcsQ0FBQyxLQUFLLFVBQVM7QUFDM0MsWUFBTSxRQUFRLE1BQU07QUFFcEIsVUFBSSxJQUFJLFNBQVM7QUFBSTtBQUNyQixVQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBUTtBQUNwQyxVQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBRTNELFVBQUksV0FBVyxJQUFJLEtBQUs7QUFBRztBQUMzQixpQkFBVyxJQUFJLEtBQUs7QUFDcEIsTUFBQUEsUUFBTyxNQUFNLGlCQUFpQixLQUFLLCtCQUEwQjtBQUs3RCx1QkFBaUIsS0FBSyxFQUNwQixLQUFLLE1BQUs7QUFDVixjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGlCQUFTLEtBQUssT0FBTyxjQUFjLE9BQU8sQ0FBQyxRQUFPO0FBQ2pELGNBQUk7QUFBSyxZQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssWUFBWSxJQUFJLE9BQU8sRUFBRTtRQUN4RSxDQUFDO01BQ0YsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxRQUFRQSxRQUFPLEtBQUssdUJBQXVCLEdBQUcsRUFBRSxDQUFDO0lBQzNELENBQUM7QUFFRCxtQkFBZSxLQUFLLHFCQUFxQixNQUFLO0FBQzdDLFVBQUk7QUFDSCx1QkFBZSxjQUFjLG9CQUFvQjtBQUNqRCxRQUFBQSxRQUFPLEtBQUssb0NBQW9DLG9CQUFvQixJQUFJLG1CQUFtQixFQUFFO01BQzlGLFNBQVMsS0FBSztBQUNiLFFBQUFBLFFBQU8sS0FBSyw0Q0FBNEMsR0FBRyxFQUFFO01BQzlEO0lBQ0QsQ0FBQztFQUdGLENBQUM7QUFDRjs7O0FEMU9BLElBQU1DLFVBQVMsbUJBQW1CLGNBQWM7QUFFMUMsSUFBTyxlQUFQLE1BQU8sY0FBWTtFQUNQLGNBQXNCO0VBQ3RCLGlCQUFpQjtFQUNqQixTQUFTO0VBRWxCO0VBQ0E7O0VBQ0E7RUFJQSxtQkFBZ0Msb0JBQUksSUFBRzs7O0VBR3ZDOztFQUdBLFFBQWdCO0VBQ2hCLFVBQXNCLENBQUE7RUFDdEIsc0JBQStCOzs7Ozs7OztFQVEvQixjQUFnRCxvQkFBSSxJQUFHOztFQUd2RCxxQkFBZ0Usb0JBQUksSUFBRzs7RUFHdkU7RUFFUixjQUFBO0FBQ0MsSUFBQUEsUUFBTyxLQUFLLDBCQUEwQjtBQUV0QyxTQUFLLGNBQWMsb0JBQUksSUFBRztBQUkxQixTQUFLLFdBQVdDLE9BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUNwRSxTQUFLLFVBQVUsSUFBSSxRQUFjLENBQUMsWUFBVztBQUM1QyxXQUFLLFNBQVMsS0FBSyxHQUFHLE1BQUs7QUFDMUIsUUFBQUQsUUFBTyxNQUFNLDJCQUE0QixLQUFLLFNBQVMsUUFBTyxFQUF3QixJQUFJLEVBQUU7QUFDNUYsZ0JBQU87TUFDUixDQUFDO0lBQ0YsQ0FBQztBQUNELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFHRCxTQUFLLFdBQVdDLE9BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUVwRSxTQUFLLFNBQVMsR0FBRyxhQUFhLE1BQUs7QUFDbEMsWUFBTSxPQUFPLEtBQUssU0FBUyxRQUFPO0FBQ2xDLE1BQUFELFFBQU8sTUFBTSwwQkFBMEIsS0FBSyxVQUFVLElBQUksQ0FBQyxFQUFFO0FBQzdELFVBQUk7QUFDSCxhQUFLLFNBQVMscUJBQXFCLElBQUk7TUFDeEMsU0FBUyxJQUFJO01BRWI7SUFDRCxDQUFDO0FBRUQsU0FBSyxTQUFTLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDakMsTUFBQUEsUUFBTyxNQUFNLG9CQUFvQixHQUFHLEVBQUU7SUFDdkMsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFdBQVcsQ0FBQyxLQUFLLFVBQVM7QUFDMUMsVUFBSTtBQUNILGFBQUssZUFBZSxLQUFLLE1BQU0sT0FBTztNQUN2QyxTQUFTLElBQUk7QUFDWixRQUFBQSxRQUFPLE1BQU0sb0NBQW9DLEVBQUUsRUFBRTtNQUN0RDtJQUNELENBQUM7QUFHRCxTQUFLLFNBQVMsS0FBSyxFQUFFLFNBQVMsV0FBVyxNQUFNLEtBQUssT0FBTSxHQUFJLE1BQUs7QUFDbEUsTUFBQUEsUUFBTyxNQUFNLDhCQUE4QixLQUFLLE1BQU0sRUFBRTtJQUN6RCxDQUFDO0VBQ0Y7RUFFTyxRQUFLO0FBQ1gsUUFBSTtBQUNILGlCQUFXLGFBQWEsTUFBTSxLQUFLLEtBQUssZ0JBQWdCLEdBQUc7QUFDMUQsWUFBSTtBQUNILGVBQUssU0FBUyxlQUFlLEtBQUssZ0JBQWdCLFNBQVM7UUFDNUQsUUFBUTtRQUVSO01BQ0Q7SUFDRCxRQUFRO0lBRVI7QUFDQSxRQUFJO0FBQ0gsV0FBSyxTQUFTLE1BQUs7SUFDcEIsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtFQUNEOzs7OztFQU1PLFNBQVMsT0FBZSxTQUFxQixzQkFBK0IsTUFBSTtBQUN0RixTQUFLLFFBQVE7QUFDYixTQUFLLFVBQVU7QUFDZixTQUFLLHNCQUFzQjtFQUM1Qjs7Ozs7RUFNTyxvQkFBb0IsVUFBc0M7QUFDaEUsU0FBSyxtQkFBbUI7RUFDekI7Ozs7O0VBTU8sTUFBTSxtQkFBbUIsVUFBZ0I7QUFDL0MsSUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxRQUFRLEVBQUU7QUFDdEQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUMzQixLQUFLLE9BQ0wsc0JBQ0EsUUFDQSxRQUNBLFFBQ0EsVUFDQSxLQUFLO0FBSU4sSUFBQUEsUUFBTyxNQUFNLHdCQUF3QixTQUFTLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFDL0QsSUFBQUEsUUFBTyxNQUFNLG9CQUFvQixTQUFTLE1BQU0sRUFBRTtBQUdsRCxVQUFNLFNBQVMsNEJBQTRCLEtBQUssT0FBTyxRQUFRO0FBQy9ELElBQUFBLFFBQU8sTUFBTSwwQkFBMEIsT0FBTyxNQUFNLEVBQUU7QUFDdEQsUUFBSSxPQUFPLFNBQVMsR0FBRztBQUN0QixNQUFBQSxRQUFPLE1BQU0sdUJBQXVCLEtBQUssVUFBVSxPQUFPLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO0lBQ3pFO0FBRUEsVUFBTSxXQUFXLG9CQUFJLElBQUc7QUFDeEIsZUFBVyxXQUFXLFFBQVE7QUFDN0IsWUFBTSxNQUFNLGNBQWMsS0FBSyxPQUFPLFFBQVEsUUFBUSxRQUFRLElBQUksUUFBUSxLQUFLO0FBRS9FLFlBQU0sUUFDTCxRQUFRLFdBQVcsV0FBVyxJQUMxQixRQUFRLFdBQVcsQ0FBQyxLQUFLLEtBQU8sUUFBUSxXQUFXLENBQUMsS0FBSyxJQUFLLFFBQVEsV0FBVyxDQUFDLElBQ2xGLFFBQVEsV0FBVyxDQUFDLEtBQUs7QUFDOUIsZUFBUyxJQUFJLEtBQUssS0FBSztJQUN4QjtBQUNBLFNBQUssWUFBWSxJQUFJLFVBQVUsUUFBUTtBQUN2QyxXQUFPO0VBQ1I7O0VBR08sZUFBZSxVQUFnQjtBQUNyQyxXQUFPLEtBQUssWUFBWSxJQUFJLFFBQVEsS0FBSyxvQkFBSSxJQUFHO0VBQ2pEOzs7Ozs7Ozs7OztFQVlPLE1BQU0sZ0JBQWdCLFlBQVksS0FBSTtBQUU1QyxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLGVBQTZCLENBQUE7QUFFbkMsVUFBTSxnQkFBZ0IsQ0FBQyxXQUFzQjtBQUM1QyxtQkFBYSxLQUFLLE1BQU07SUFDekI7QUFHQSxTQUFLLG1CQUFtQixJQUFJLGVBQWUsYUFBYTtBQUV4RCxRQUFJO0FBQ0gsWUFBTSxLQUFLO0FBR1gsWUFBTTtRQUNMLEtBQUs7UUFDTDs7UUFDQSxPQUFPLFdBQVcsS0FBSyxvQkFBb0IsTUFBTTtRQUNqRDtNQUFTO0FBRVYsYUFBTztJQUNSO0FBQ0MsV0FBSyxtQkFBbUIsT0FBTyxhQUFhO0lBQzdDO0VBQ0Q7Ozs7O0VBTU8sTUFBTSx1QkFBdUIsVUFBZ0I7QUFDbkQsSUFBQUEsUUFBTyxLQUFLLG9DQUFvQyxRQUFRLEVBQUU7QUFDMUQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUMzQixLQUFLLE9BQ0wsa0JBQ0EsUUFDQSxRQUNBLFFBQ0EsVUFDQSxPQUNBLEVBQU07QUFLUCxVQUFNLFlBQVk7QUFFbEIsUUFBSSxTQUFTLFNBQVMsWUFBWSxHQUFHO0FBQ3BDLE1BQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsU0FBUyxNQUFNLFFBQVE7QUFDbkUsYUFBTztJQUNSO0FBR0EsVUFBTSxRQUFRLFNBQVMsWUFBWSxDQUFDO0FBQ3BDLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQU1wQyxRQUFJO0FBQ0osUUFBSSxVQUFVLEdBQUc7QUFDaEIsaUJBQVc7SUFDWixXQUFXLFFBQVEsSUFBSTtBQUN0QixpQkFBVyxNQUFNLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRztJQUM1QyxPQUFPO0FBQ04saUJBQVcsTUFBTSxTQUFRO0lBQzFCO0FBRUEsVUFBTSxXQUFXLEdBQUcsS0FBSyxJQUFJLFFBQVE7QUFFckMsSUFBQUEsUUFBTyxLQUFLLHFCQUFxQixRQUFRLEVBQUU7QUFDM0MsV0FBTztFQUNSOzs7OztFQU1RLE1BQU0sb0JBQW9CLFFBQWM7QUFDL0MsUUFBSTtBQUNILFlBQU0sWUFBWSxNQUFNLDhCQUE4QixNQUFNO0FBQzVELFVBQUksQ0FBQyxXQUFXO0FBQ2YsUUFBQUEsUUFBTyxLQUFLLHFEQUFxRCxNQUFNLEVBQUU7QUFDekU7TUFDRDtBQUVBLFVBQUksS0FBSyxpQkFBaUIsSUFBSSxTQUFTLEdBQUc7QUFFekM7TUFDRDtBQUVBLFVBQUk7QUFDSCxhQUFLLFNBQVMsY0FBYyxLQUFLLGdCQUFnQixTQUFTO0FBQzFELGFBQUssaUJBQWlCLElBQUksU0FBUztBQUNuQyxRQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssY0FBYyxPQUFPLFNBQVMsRUFBRTtNQUN0RSxTQUFTLElBQUk7QUFDWixRQUFBQSxRQUFPLEtBQUssK0JBQStCLFNBQVMsS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFO01BQ3RFO0lBQ0QsU0FBUyxJQUFJO0FBQ1osTUFBQUEsUUFBTyxLQUFLLCtCQUErQixFQUFFLEVBQUU7SUFDaEQ7RUFDRDtFQUVPLE1BQU0sYUFDWixPQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQ0EsUUFDQSxTQUFTLE1BQ1QsVUFBVSxJQUFNO0FBRWhCLFVBQU0sWUFBWTtBQUdsQixVQUFNLEtBQUssb0JBQW9CLE1BQU07QUFFckMsVUFBTSxZQUFzQixDQUFBO0FBQzVCLFFBQUksY0FBYztBQUFXLGdCQUFVLEtBQUssWUFBWSxHQUFJO0FBQzVELFFBQUksVUFBVTtBQUFXLGdCQUFVLEtBQUssR0FBRyxjQUFhLGdCQUFnQixLQUFLLENBQUM7QUFFOUUsVUFBTSxjQUF3QixDQUFDLElBQU0sUUFBUSxHQUFJO0FBRWpELFFBQUksVUFBVTtBQUFXLGtCQUFZLEtBQUssUUFBUSxHQUFJO0FBQ3RELFFBQUk7QUFBUSxrQkFBWSxLQUFLLFVBQVUsTUFBTTtBQUU3QyxRQUFJLFVBQVUsU0FBUztBQUFHLGtCQUFZLEtBQUssR0FBRyxTQUFTO0FBRXZELFVBQU0sTUFBTSxjQUFhLFVBQVUsV0FBVztBQUM5QyxVQUFNLGlCQUFpQixPQUFPLEtBQUssQ0FBQyxHQUFHLGFBQWEsR0FBRyxDQUFDO0FBRXhELFVBQU0sU0FBUyxNQUFNLGNBQWEsWUFBWSxRQUFRLE9BQU87QUFDN0QsVUFBTSxTQUFTLE9BQU8sT0FBTyxDQUFDLFFBQVEsY0FBYyxDQUFDO0FBR3JELFVBQU0sVUFBVSxlQUFlLEtBQUs7QUFDcEMsUUFBSSxjQUFjLFVBQWEsVUFBVSxRQUFXO0FBRW5ELFVBQUksU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFHOUUsVUFBSSxDQUFDLFFBQVE7QUFDWixpQkFBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQUs7QUFDaEMsY0FBSSxFQUFFLFdBQVc7QUFBTyxtQkFBTztBQUMvQixnQkFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUM1RCxjQUFJLENBQUM7QUFBVSxtQkFBTztBQUN0QixpQkFBTyxhQUFhLEVBQUUsTUFBTSxZQUFZLEVBQUUsS0FBSztRQUNoRCxDQUFDO01BQ0Y7QUFFQSxVQUFJLGNBQWMsUUFBUSxRQUFRO0FBR2xDLFVBQUksUUFBUTtBQUNYLGNBQU0sV0FBVyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDakUsWUFBSSxZQUFZLGNBQWMsT0FBTyxJQUFJO0FBQ3hDLGdCQUFNLGdCQUFnQixZQUFZLE9BQU87QUFDekMsd0JBQWMsR0FBRyxXQUFXLE1BQU0sZ0JBQWdCLENBQUM7UUFDcEQ7TUFDRDtBQUdBLFlBQU0sY0FBYyxRQUFRLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDckUsWUFBTSxVQUFVLGFBQWE7QUFDN0IsWUFBTSxhQUFhLGNBQWEsZ0JBQWdCLEtBQUs7QUFDckQsWUFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELFlBQU0sY0FBYyxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUV4RyxZQUFNLFNBQVMsTUFBTSxLQUFLO0FBQzFCLFlBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsWUFBTSxTQUFTLFdBQVcsVUFBVTtBQUNwQyxZQUFNLFNBQVMsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUksV0FBVyxLQUFLLEdBQUc7QUFFNUUsWUFBTSxTQUFTLE9BQU8sTUFBTSxPQUFPLEtBQUssUUFBUSxNQUFNO0FBQ3RELFlBQU0sU0FBUyxjQUFjLEdBQUcsV0FBVyxLQUFLLFdBQVcsS0FBSyxNQUFNLE1BQU0sR0FBRyxXQUFXLEtBQUssTUFBTTtBQUVyRyxNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sRUFBRTtJQUNuRCxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLE1BQU0sTUFBTSxNQUFNLE9BQU8sRUFBRTtJQUN4QztBQUNBLElBQUFBLFFBQU8sTUFBTSxxQkFBcUIsTUFBTSxLQUFLLE9BQU8sU0FBUyxLQUFLLENBQUMsRUFBRTtBQUVyRSxVQUFNLEtBQUs7QUFFWCxVQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksS0FBSztBQUU5QixXQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsWUFBTSxRQUFRLFdBQVcsTUFBSztBQUM3QixhQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLGVBQU8sSUFBSSxNQUFNLHFDQUFxQyxLQUFLLE9BQU8sTUFBTSxPQUFPLENBQUM7TUFDakYsR0FBRyxTQUFTO0FBRVosV0FBSyxZQUFZLElBQUksS0FBSztRQUN6QixTQUFTLENBQUMsUUFBTztBQUNoQix1QkFBYSxLQUFLO0FBR2xCLGNBQUksS0FBSyx1QkFBdUIsY0FBYyxRQUFXO0FBQ3hELGlCQUFLLG1CQUFtQixNQUFNLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDN0MsY0FBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7WUFDL0QsQ0FBQztVQUNGO0FBRUEsa0JBQVEsR0FBRztRQUNaO1FBQ0EsUUFBUSxDQUFDLFFBQU87QUFDZix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLEdBQUc7UUFDWDtRQUNBO09BQ0E7QUFFRCxXQUFLLFNBQVMsS0FBSyxRQUFRLEtBQUssYUFBYSxRQUFRLENBQUMsUUFBTztBQUM1RCxZQUFJLEtBQUs7QUFDUixlQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQzdDO01BQ0QsQ0FBQztJQUNGLENBQUM7RUFDRjtFQUVRLGVBQWUsS0FBYSxPQUFhO0FBQ2hELFFBQUksSUFBSSxTQUFTO0FBQUc7QUFDcEIsUUFBSSxJQUFJLENBQUMsTUFBTSxPQUFRLElBQUksQ0FBQyxNQUFNO0FBQU07QUFFeEMsVUFBTSxVQUFVLElBQUksYUFBYSxDQUFDO0FBS2xDLFFBQUksWUFBWSwyQkFBMkIsS0FBSyxtQkFBbUIsT0FBTyxHQUFHO0FBQzVFLFlBQU0sU0FBUyx1QkFBdUIsS0FBSyxLQUFLO0FBQ2hELFVBQUksUUFBUTtBQUNYLG1CQUFXLE1BQU0sS0FBSyxtQkFBbUIsT0FBTSxHQUFJO0FBQ2xELGNBQUk7QUFDSCxlQUFHLE1BQU07VUFDVixRQUFRO1VBRVI7UUFDRDtNQUNEO0FBQ0E7SUFDRDtBQUVBLFFBQUksSUFBSSxTQUFTO0FBQUk7QUFHckIsVUFBTSxNQUFNLElBQUksU0FBUyxJQUFJLEVBQUU7QUFDL0IsUUFBSSxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQVk7QUFJMUMsVUFBTSxZQUFZLElBQUksU0FBUyxFQUFFO0FBQ2pDLFFBQUksVUFBVSxTQUFTO0FBQUc7QUFDMUIsUUFBSSxVQUFVLENBQUMsTUFBTTtBQUFNO0FBRzNCLFVBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsVUFBTSxjQUFjLFlBQVksU0FBVTtBQUMxQyxVQUFNLGdCQUFnQixZQUFZO0FBR2xDLFNBQUssYUFBYSxPQUFPLGVBQWUsS0FBSyxXQUFXLFVBQVU7QUFHbEUsUUFBSSxZQUFZO0FBQ2YsWUFBTSxNQUFNLEdBQUcsS0FBSyxJQUFJLGFBQWE7QUFDckMsWUFBTSxVQUFVLEtBQUssWUFBWSxJQUFJLEdBQUc7QUFDeEMsVUFBSSxTQUFTO0FBQ1osYUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQixnQkFBUSxRQUFRLEdBQUc7TUFDcEI7SUFDRDtFQUVEOzs7Ozs7Ozs7Ozs7RUFhUSxhQUFhLE9BQWUsT0FBZSxLQUFhLFdBQW1CLGFBQWEsTUFBSTtBQUNuRyxVQUFNLFVBQVUsT0FBTyxNQUFNLEtBQUssQ0FBQztBQUNuQyxVQUFNLE9BQU8sVUFBVSxTQUFTLEdBQUcsVUFBVSxTQUFTLENBQUM7QUFHdkQsVUFBTSxRQUFRLFVBQVUsQ0FBQztBQUN6QixVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxDQUFDO0FBQzFDLFVBQU0sZ0JBQWdCLFVBQVUsTUFBTSxLQUFLLENBQUMsUUFBUSxNQUFNLFNBQVMsQ0FBQyxTQUFTLEtBQUssU0FBUyxLQUFLLENBQUMsUUFBUSxNQUFNLEdBQUcsQ0FBQztBQUduSCxVQUFNLFlBQVksYUFBYSxPQUFPO0FBS3RDLFFBQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBSSxDQUFDLEtBQUssT0FBTztBQUNoQixRQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7QUFDbkU7TUFDRDtBQUNBLFVBQUk7QUFDSCxjQUFNLFdBQ0wsVUFBVSxvQkFDUCxzQkFBc0IsS0FBSyxPQUFPLEdBQUcsSUFDckMsNEJBQTRCLEtBQUssT0FBTyxHQUFHO0FBRS9DLGNBQU0sWUFBWSxLQUFLLFlBQVksSUFBSSxLQUFLLEtBQUssb0JBQUksSUFBRztBQUN4RCxjQUFNLFdBQVcsSUFBSSxJQUFvQixTQUFTO0FBRWxELG1CQUFXLEtBQUssVUFBVTtBQUN6QixnQkFBTSxXQUFXLGNBQWMsS0FBSyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLO0FBRWxFLGdCQUFNLFdBQ0wsRUFBRSxXQUFXLFdBQVcsSUFDcEIsRUFBRSxXQUFXLENBQUMsS0FBSyxLQUFPLEVBQUUsV0FBVyxDQUFDLEtBQUssSUFBSyxFQUFFLFdBQVcsQ0FBQyxJQUNoRSxFQUFFLFdBQVcsQ0FBQyxLQUFLO0FBQ3hCLGdCQUFNLFlBQVksVUFBVSxJQUFJLFFBQVE7QUFDeEMsZ0JBQU0sVUFBVSxjQUFjLFVBQWEsY0FBYztBQUV6RCxtQkFBUyxJQUFJLFVBQVUsUUFBUTtBQUUvQixnQkFBTSxZQUFZLG9CQUFvQixHQUFHLEtBQUssT0FBTztBQUNyRCxjQUFJLFNBQVM7QUFDWixZQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLFNBQVMsRUFBRTtBQUVsRCxnQkFBSSxLQUFLLGtCQUFrQjtBQUMxQixtQkFBSyxpQkFBaUIsUUFBUTtZQUMvQjtVQUNELE9BQU87QUFDTixZQUFBQSxRQUFPLE1BQU0sR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLFNBQVMsRUFBRTtVQUNwRDtRQUNEO0FBQ0EsYUFBSyxZQUFZLElBQUksT0FBTyxRQUFRO01BQ3JDLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxHQUFHLFNBQVMsSUFBSSxLQUFLLE1BQU0sT0FBTyxvQkFBb0IsQ0FBQyxNQUFNLGFBQWEsRUFBRTtNQUN6RjtBQUNBO0lBQ0Q7QUFHQSxVQUFNLFVBQVUsS0FBSyxhQUFhLE9BQU8sSUFBSTtBQUM3QyxRQUFJLFNBQVM7QUFDWixNQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLE1BQU0sT0FBTyxFQUFFO0lBQ2pGLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7SUFDcEU7RUFDRDs7Ozs7Ozs7RUFTUSxhQUFhLE9BQWUsTUFBWTtBQUMvQyxRQUFJLEtBQUssV0FBVztBQUFHLGFBQU87QUFHOUIsUUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixVQUFJLEtBQUssQ0FBQyxNQUFNLEdBQU07QUFDckIsZUFBTztNQUNSLE9BQU87QUFDTixlQUFPLFNBQVMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO01BQy9CO0lBQ0Q7QUFFQSxZQUFRLE9BQU87Ozs7O01BS2QsS0FBSyxjQUFjO0FBQ2xCLFlBQUksS0FBSyxXQUFXLEdBQUc7QUFDdEIsaUJBQU8sS0FBSyxDQUFDLE1BQU0sSUFBTyxXQUFXLFdBQVcsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQy9EO0FBQ0EsWUFBSSxLQUFLLFVBQVUsR0FBRztBQUNyQixnQkFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixnQkFBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixnQkFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO0FBQ2xDLGdCQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBQ2hGLGdCQUFNLGNBQWMsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLENBQUM7QUFDL0QsZ0JBQU0sVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0FBQ3RDLGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGNBQWMsR0FBRyxXQUFXLEtBQUssTUFBTSxRQUFTLENBQUMsTUFBTSxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUM7QUFDekcsZ0JBQU0sU0FBUyxJQUFJLE1BQU0sS0FBSyxDQUFDLElBQUksTUFBTSxTQUFTLENBQUMsS0FBSyxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUMsQ0FBQztBQUMxRixpQkFBTyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUSxJQUFJLE1BQU07UUFDaEU7QUFDQSxlQUFPLFFBQVEsS0FBSyxTQUFTLEtBQUssQ0FBQztNQUNwQzs7TUFHQSxLQUFLLGlCQUFpQjtBQUVyQixZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLFVBQVUsUUFBUSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEdBQUc7QUFDaEUsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGVBQWUsS0FBSyxXQUFXLFNBQVMsS0FBSyxDQUFDO0FBQy9ELGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRO1FBQ3REO0FBQ0EsZUFBTztNQUNSOztNQUdBLEtBQUs7TUFDTCxLQUFLLGFBQWE7QUFDakIsWUFBSSxLQUFLLFNBQVM7QUFBRyxpQkFBTztBQUM1QixjQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGNBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsY0FBTSxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQzdCLGVBQU8sTUFBTSxLQUFLLFlBQVksTUFBTSxTQUFTLENBQUMsVUFBVSxNQUFNLFNBQVMsS0FBSyxDQUFDO01BQzlFO01BRUE7QUFDQyxlQUFPO0lBQ1Q7RUFDRDtFQUVRLE9BQU8sZ0JBQWdCLE9BQWM7QUFDNUMsUUFBSSxPQUFPLFVBQVU7QUFBVyxhQUFPLENBQUMsUUFBUSxJQUFJLENBQUM7QUFDckQsUUFBSSxNQUFNLFFBQVEsS0FBSztBQUFHLGFBQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxPQUFPLENBQUMsSUFBSSxHQUFJO0FBQ2xFLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDOUIsVUFBSSxRQUFRO0FBQU0sZUFBTyxDQUFFLFNBQVMsS0FBTSxLQUFPLFNBQVMsSUFBSyxLQUFNLFFBQVEsR0FBSTtBQUNqRixhQUFPLENBQUMsUUFBUSxHQUFJO0lBQ3JCO0FBQ0EsVUFBTSxJQUFJLE1BQU0sNENBQTRDLEtBQUssRUFBRTtFQUNwRTtFQUVRLGFBQWEscUJBQXFCLFFBQWM7QUFDdkQsV0FBTyxJQUFJLFFBQWtCLENBQUMsU0FBUyxXQUFVO0FBQ2hELFlBQU0sTUFBTUMsT0FBTSxhQUFhLE1BQU07QUFFckMsVUFBSSxLQUFLLFNBQVMsQ0FBQyxRQUFPO0FBQ3pCLFlBQUksTUFBSztBQUNULGVBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzdDLENBQUM7QUFFRCxVQUFJLFFBQVEsR0FBRyxRQUFRLE1BQUs7QUFDM0IsWUFBSTtBQUNILGdCQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGdCQUFNLFlBQVksS0FBSztBQUV2QixjQUFJLE1BQUs7QUFFVCxnQkFBTSxTQUFTQyxJQUFHLGtCQUFpQjtBQUNuQyxxQkFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMsdUJBQVcsU0FBUyxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdkMsa0JBQ0MsTUFBTSxXQUFXLFVBQ2pCLE1BQU0sWUFBWSxhQUNsQixNQUFNLE9BQ04sTUFBTSxRQUFRLHFCQUNiO0FBQ0QsdUJBQU8sUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSSxHQUFJLENBQUM7Y0FDdkU7WUFDRDtVQUNEO0FBRUEsaUJBQU8sSUFBSSxNQUFNLHdDQUF3QyxTQUFTLEVBQUUsQ0FBQztRQUN0RSxTQUFTLElBQUk7QUFDWixpQkFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM3QjtNQUNELENBQUM7SUFDRixDQUFDO0VBQ0Y7RUFFUSxhQUFhLFlBQVksUUFBZ0IsVUFBVSxJQUFNO0FBQ2hFLFVBQU0sTUFBTSxNQUFNLGNBQWEscUJBQXFCLE1BQU07QUFHMUQsVUFBTSxhQUFjLFdBQVcsSUFBSztBQUNwQyxVQUFNLGFBQWEsVUFBVTtBQUU3QixXQUFPLE9BQU8sT0FBTztNQUNwQixPQUFPLEtBQUssQ0FBQyxLQUFNLEtBQU0sWUFBWSxZQUFZLEdBQU0sS0FBTSxHQUFNLEdBQU0sR0FBRyxLQUFLLEdBQU0sQ0FBSSxDQUFDO01BQzVGLE9BQU8sS0FBSyxZQUFZLE1BQU07S0FDOUI7RUFDRjtFQUVRLE9BQU8sVUFBVSxNQUFjO0FBQ3RDLFFBQUksTUFBTTtBQUNWLGVBQVcsS0FBSyxNQUFNO0FBQ3JCLGFBQU87QUFDUCxlQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUMzQixlQUFPLE1BQU0sU0FBVSxLQUFNLE9BQU8sSUFBSyxPQUFRLE1BQVEsT0FBTyxJQUFLO01BQ3RFO0lBQ0Q7QUFDQSxXQUFPO0VBQ1I7Ozs7Ozs7Ozs7RUFXTyxnQkFBZ0IsSUFBWSxPQUFlLFdBQW1CLE9BQWM7QUFDbEYsVUFBTSxNQUFNLGNBQWMsS0FBSyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQzdELFdBQU8sS0FBSyxZQUFZLElBQUksRUFBRSxHQUFHLElBQUksR0FBRztFQUN6QztFQUVPLE1BQU0sWUFBWSxPQUFlLFFBQWM7QUFDckQsV0FBTyxLQUFLLGFBQWEsT0FBTyxrQkFBa0IsUUFBVyxHQUFNLFFBQVcsUUFBUSxLQUFLO0VBQzVGO0VBRU8sTUFBTSxjQUFjLE9BQWUsUUFBYztBQUN2RCxXQUFPLEtBQUssYUFBYSxPQUFPLHFCQUFxQixRQUFXLFFBQVcsUUFBVyxRQUFRLEtBQUs7RUFDcEc7Ozs7QUU3dEJELElBQU1DLFVBQVMsbUJBQW1CLGdCQUFnQjtBQU1sRCxJQUFxQixpQkFBckIsY0FBNEMsYUFBeUI7RUFDcEU7O0VBQ0E7OztFQUlRLG9CQUFrQyxDQUFBO0VBRTFDLFlBQVksVUFBaUI7QUFDNUIsVUFBTSxRQUFRO0VBQ2Y7RUFFQSxNQUFNLEtBQUssUUFBb0I7QUFDOUIsU0FBSyxTQUFTO0FBQ2QsUUFBSSxDQUFDLEtBQUssY0FBYztBQUN2QixXQUFLLGVBQWUsSUFBSSxhQUFZO0lBQ3JDO0FBQ0EsU0FBSyxhQUFhLGVBQWUsRUFBRTtBQUduQyxTQUFLLGFBQVksRUFBRyxNQUFNLENBQUMsTUFBSztBQUMvQixNQUFBQSxRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtJQUN0QyxDQUFDO0FBSUQsVUFBTSxpQkFBaUIsYUFBYSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7QUFHdkUsUUFBSSxnQkFBZ0I7QUFDbkIsV0FBSyxVQUFVLGNBQWM7SUFDOUIsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSywwQ0FBMEM7SUFDdkQ7QUFHQSxTQUFLLGFBQWEsb0JBQW9CLENBQUMsZUFBc0I7QUFDNUQsV0FBSyxlQUFlLFVBQVU7SUFDL0IsQ0FBQztBQUdELFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0FBR3pCLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFFBQUksY0FBYyxnQkFBZ0I7QUFDakMsVUFBSTtBQUNILGNBQU0sS0FBSyxhQUFhLG1CQUFtQixVQUFVO01BQ3RELFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxtQ0FBbUMsVUFBVSxLQUFLLENBQUMsRUFBRTtNQUNsRTtJQUNEO0VBQ0Q7Ozs7O0VBTVEsTUFBTSxlQUFZO0FBQ3pCLElBQUFBLFFBQU8sS0FBSyw4QkFBOEI7QUFHMUMsU0FBSyxvQkFBb0IsTUFBTSxLQUFLLGFBQWEsZ0JBQWU7QUFFaEUsUUFBSSxLQUFLLGtCQUFrQixXQUFXLEdBQUc7QUFDeEMsTUFBQUEsUUFBTyxLQUFLLHVCQUF1QjtJQUNwQyxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGNBQWMsS0FBSyxrQkFBa0IsTUFBTSxhQUFhO0FBQ3BFLGlCQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdkMsUUFBQUEsUUFBTyxLQUFLLGFBQWEsRUFBRSxLQUFLLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFO01BQ3JFO0FBR0EsaUJBQVcsVUFBVSxLQUFLLG1CQUFtQjtBQUM1QyxZQUFJO0FBQ0gsZ0JBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSx1QkFBdUIsT0FBTyxFQUFFO0FBQ3pFLGlCQUFPLGVBQWU7QUFDdEIsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLGNBQWMsUUFBUSxXQUFXLE9BQU8sYUFBYSxFQUFFO1FBQ3BGLFNBQVMsR0FBRztBQUNYLFVBQUFBLFFBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSw2QkFBNkIsQ0FBQyxFQUFFO0FBQzVELGlCQUFPLGVBQWU7UUFDdkI7TUFDRDtJQUNEO0FBTUEsVUFBTSxpQkFBaUIsYUFBYSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7QUFDdkUsUUFBSSxnQkFBZ0I7QUFDbkIsV0FBSyxVQUFVLGNBQWM7SUFDOUI7QUFFQSxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLHFCQUFvQjtBQUV6QixJQUFBQSxRQUFPLEtBQUssMkJBQTJCO0VBQ3hDOztFQUdBLE1BQU0sVUFBTztBQUNaLFNBQUssY0FBYyxNQUFLO0FBQ3hCLElBQUFBLFFBQU8sTUFBTSxTQUFTO0VBQ3ZCO0VBRUEsTUFBTSxjQUFjLFFBQW9CO0FBQ3ZDLFVBQU0sZUFBZSxLQUFLO0FBQzFCLFNBQUssU0FBUztBQUNkLFVBQU0saUJBQWlCLGFBQWEsUUFBUSxLQUFLLGlCQUFpQjtBQUNsRSxTQUFLLFVBQVUsY0FBYztBQUc3QixTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtBQUd6QixVQUFNLFVBQVUsS0FBSztBQUNyQixRQUFJLFdBQVcsWUFBWSxjQUFjO0FBQ3hDLFVBQUk7QUFDSCxjQUFNLEtBQUssYUFBYSxtQkFBbUIsT0FBTztNQUNuRCxTQUFTLEdBQUc7QUFDWCxRQUFBQSxRQUFPLEtBQUssbUNBQW1DLE9BQU8sS0FBSyxDQUFDLEVBQUU7TUFDL0Q7SUFDRDtFQUNEOztFQUdRLFVBQVUsT0FBYTtBQUM5QixVQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsUUFBSSxDQUFDLFFBQVE7QUFDWixNQUFBQSxRQUFPLEtBQUssVUFBVSxLQUFLLCtCQUErQjtBQUMxRCxXQUFLLGFBQWEsU0FBUyxPQUFPLENBQUEsR0FBSSxJQUFJO0FBQzFDO0lBQ0Q7QUFFQSxVQUFNLFVBQVUsTUFBTSxRQUFRLE9BQU8sU0FBUyxJQUFJLE9BQU8sWUFBWSxDQUFBO0FBQ3JFLFVBQU0sc0JBQXNCLE9BQU8sdUJBQXVCO0FBRTFELFNBQUssYUFBYSxTQUFTLE9BQU8sU0FBUyxtQkFBbUI7QUFDOUQsUUFBSSxRQUFRLFdBQVcsR0FBRztBQUN6QixNQUFBQSxRQUFPLEtBQUssK0JBQStCLEtBQUssNkNBQXdDO0lBQ3pGLE9BQU87QUFDTixNQUFBQSxRQUFPLE1BQ04sVUFBVSxRQUFRLE1BQU0sdUJBQXVCLEtBQUssZ0JBQWdCLE9BQU8sU0FBUyx5QkFBeUIsbUJBQW1CLEVBQUU7SUFFcEk7RUFDRDs7OztFQUtBLGtCQUFlO0FBQ2QsV0FBTyxnQkFBZ0IsS0FBSyxpQkFBaUI7RUFDOUM7O0VBR0EsSUFBSSxPQUFJO0FBQ1AsV0FBTyxZQUFZLEtBQUssTUFBTTtFQUMvQjs7RUFHQSxJQUFJLFVBQU87QUFDVixXQUFPLEtBQUs7RUFDYjtFQUVBLGdCQUFhO0FBQ1osa0JBQWMsSUFBSTtFQUNuQjtFQUVBLGtCQUFlO0FBQ2Qsb0JBQWdCLElBQUk7RUFDckI7RUFFQSw0QkFBeUI7QUFDeEIsOEJBQTBCLElBQUk7RUFDL0I7RUFFQSx1QkFBb0I7QUFDbkIseUJBQXFCLElBQUk7RUFDMUI7OyIsCiAgIm5hbWVzIjogWyJwYXRoIiwgIkluc3RhbmNlU3RhdHVzIiwgIlJlZ2V4IiwgInBhdGgiLCAiZnMiLCAibG9nZ2VyIiwgImxvZ2dlciIsICJmcyIsICJsb2dnZXIiLCAiZGV2aWNlc0ZvbGRlciIsICJwYXRoIiwgImxvZ2dlciIsICJkZ3JhbSIsICJvcyIsICJsb2dnZXIiLCAibG9nZ2VyIiwgImRncmFtIiwgIm9zIiwgImxvZ2dlciJdCn0K
