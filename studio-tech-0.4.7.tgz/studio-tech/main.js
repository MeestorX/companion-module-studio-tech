import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path4, args) {
    this.#context.oscSend(host, port, path4, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual" },
    ...discoveredDevices.map((d) => ({
      id: d.ip,
      label: `Model ${d.model} (${d.ip})`
    }))
  ];
  return [
    // ── Device discovery dropdown ────────────────────────────────────────
    // Mirrors the bonjour-device field: selecting a device populates the
    // host automatically; selecting 'Manual' shows the textinput below.
    {
      type: "dropdown",
      id: "discoveredHost",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies Dante device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry ──────────────────────────────────────────────────
    // Only visible when discoveredHost is '' (Manual selected).
    // Matches the pattern from the bonjour-device docs.
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Model selector ───────────────────────────────────────────────────
    // Only visible when Manual mode is selected (no discovered device).
    // When a discovered device is selected, the model is auto-detected.
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Select which Studio Technologies model is active for actions and Get All Settings"
    }
  ];
}
function resolveHost(config) {
  return config.discoveredHost || config.host;
}
function resolveModel(config, discoveredDevices) {
  if (config.discoveredHost) {
    const device = discoveredDevices.find((d) => d.ip === config.discoveredHost);
    logger.debug(`resolveModel: discoveredHost="${config.discoveredHost}", found device: ${device?.model ?? "none"}`);
    if (device?.model) {
      return device.model;
    }
    if (discoveredDevices.length === 0) {
      logger.warn(`resolveModel: No devices discovered, cannot determine model`);
      return "";
    }
  }
  logger.debug(`resolveModel: falling back to activeModel="${config.activeModel}"`);
  return config.activeModel;
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_BUS_GET:
      return "Get Bus Setting";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "textinput":
    case "colorpicker":
    case "static-text":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  for (const { cmd_id, id, valueBytes } of parsed) {
    let action = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (!action) {
      for (const c of candidates) {
        const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
        if (match) {
          action = structuredClone(match);
          action.name = `${match.name} (inferred from Model ${c.model})`;
          logger2.info(`Inferred setting ${toHex(id)} from Model ${c.model}`);
          break;
        }
      }
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown Setting ${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      logger2.warn(`Could not infer setting ${toHex(id)}`);
    } else {
      const opt = action.options?.[0];
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
    }
    const exists = out.cmdSchema.some((a) => a.cmd_id === action.cmd_id && a.id === action.id);
    if (!exists)
      out.cmdSchema.push(action);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("refreshAfterCommand" in jsonObj) {
      orderedObj.refreshAfterCommand = jsonObj.refreshAfterCommand;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema;
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = resolveModel(self.config, self.devices);
  logger3.info(`UpdateActions: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  if (self.stController.isDeviceAuthorized(self.host)) {
    wiredActions["global_getAllSettings"] = {
      name: "GLOBAL: Get All Settings (Auto-Update JSON)",
      options: [],
      callback: async () => {
        const model = activeModel;
        const ip = self.host;
        const buf = await self.stController.requestAllSettings(ip);
        let modelJson = getDeviceSchema(model);
        if (!modelJson) {
          logger3.error(`Model ${model} schema not found in cache`);
          return;
        }
        const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
        logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
        if (detectedSectioned !== null) {
          logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
          modelJson = { ...modelJson, sectioned: detectedSectioned };
        }
        const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
        logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
        const devicesFolder2 = getDevicesFolder();
        const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
        saveModelJsonPretty(schemaPath, updated);
        reloadDeviceSchemas();
        logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
      }
    };
  }
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(activeModel, cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(activeModel, ip);
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
  logger3.info(`UpdateActions: wired actions: ${Object.keys(wiredActions).length}`);
}

// dist/feedbacks.js
var logger4 = createModuleLogger("Feedbacks");
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = resolveModel(self.config, self.devices);
  logger4.info(`UpdateFeedbacks: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const busCh = feedbackEvent.options["busCh"];
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
  logger4.info(`UpdateFeedbacks: wired feedbacks: ${Object.keys(wiredFeedbacks).length}`);
}

// dist/stcontroller.js
import dgram2 from "dgram";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger5 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, _onDeviceFound, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const found = /* @__PURE__ */ new Map();
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve(Array.from(found.values()));
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger5.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger5.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      ensureMembership(srcIp).then(() => {
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger5.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      }).catch((err) => logger5.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger5.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger5.warn(`Could not join announce multicast group: ${err}`);
      }
    });
  });
}

// dist/stcontroller.js
var logger6 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks;
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  constructor() {
    logger6.info("StController initialized");
    this.pendingAcks = /* @__PURE__ */ new Map();
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger6.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger6.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger6.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger6.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger6.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger6.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger6.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    logger6.debug(`Revoked device at ${ip}`);
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    return new Promise((resolve) => {
      const key = `__probe_${ip}__`;
      let resolved = false;
      const finish = (result) => {
        if (resolved)
          return;
        resolved = true;
        this.discoveryListeners.delete(key);
        resolve(result);
      };
      this.discoveryListeners.set(key, (device) => {
        if (device.ip === ip)
          finish(device);
      });
      const timer = setTimeout(() => finish(null), timeoutMs);
      timer.unref?.();
      this.ensureMembershipFor(ip).then(async () => this.txReady).then(() => {
        const query = buildDanteInfoRequest();
        this.txSocket.send(query, this.defaultPort, ip, (err) => {
          if (err) {
            logger6.warn(`Probe to ${ip} failed: ${err.message}`);
            clearTimeout(timer);
            finish(null);
          }
        });
      }).catch((e) => {
        logger6.warn(`probeDevice setup failed for ${ip}: ${e}`);
        clearTimeout(timer);
        finish(null);
      });
    });
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger6.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(this.model, CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /** Return a snapshot of the current device state for a given IP (for feedbacks). */
  getDeviceState(deviceIp) {
    return this.deviceState.get(deviceIp) ?? /* @__PURE__ */ new Map();
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(
        this.txSocket,
        onDeviceFound,
        // dante.ts doesn't actually use this, but kept for compatibility
        async (destIp) => this.ensureMembershipFor(destIp),
        timeoutMs
      );
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger6.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(this.model, CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger6.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    let minorStr;
    if (minor === 2) {
      minorStr = "2";
    } else if (minor < 10) {
      minorStr = minor.toString().padStart(2, "0");
    } else {
      minorStr = minor.toString();
    }
    const firmware = `${major}.${minorStr}`;
    logger6.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Ensure we've joined the multicast group on the interface that routes to destIp.
   * Option B behavior: join ONLY the interface used to reach the device.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger6.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger6.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger6.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger6.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(model, cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(model, cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && this.refreshAfterCommand && settingId !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger6.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(model, cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    if (!this.authorizedIps.has(destIp)) {
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    await this.ensureMembershipFor(destIp);
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (busCh !== void 0)
      payloadBody.push(busCh & 255);
    if (addLen)
      payloadBody.push(dataBlock.length);
    if (dataBlock.length > 0)
      payloadBody.push(...dataBlock);
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await _StController.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    const cmdName = getCommandName(cmdId);
    if (settingId !== void 0 && value !== void 0) {
      let action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
      if (!action) {
        action = this.actions.find((a) => {
          if (a.cmd_id !== cmdId)
            return false;
          const hasIdAdd = a.options?.some((opt) => opt.id === "idAdd");
          if (!hasIdAdd)
            return false;
          return settingId >= a.id && settingId < a.id + 10;
        });
      }
      let settingName = action?.name ?? "Unknown Setting";
      if (action) {
        const hasIdAdd = action.options?.some((opt) => opt.id === "idAdd");
        if (hasIdAdd && settingId !== action.id) {
          const channelOffset = settingId - action.id;
          settingName = `${settingName} Ch${channelOffset + 1}`;
        }
      }
      const valueOption = action?.options?.find((opt) => opt.id === "value");
      const choices = valueOption?.choices;
      const valueBytes = _StController.buildValueBytes(value);
      const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
      const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
      const cmdHex = toHex(cmdId);
      const idHex = toHex(settingId);
      const valHex = bytesToHex(valueBytes);
      const valDec = valueBytes.length === 1 ? valueBytes[0] : valueBytes.join(",");
      const prefix = `cmd:${cmdHex} id:${idHex} val:${valHex}`;
      const suffix = choiceLabel ? `${settingName}: ${choiceLabel} (${valDec})` : `${settingName}: ${valDec}`;
      logger6.info(`TX ${destIp} | ${prefix} | ${suffix}`);
    } else {
      logger6.info(`TX ${destIp} | ${cmdName}`);
    }
    logger6.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    await this.txReady;
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model${model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger6.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger6.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    this.logStPayload(srcIp, originalCmdId, msg, stPayload, isResponse);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload, isResponse = true) {
    const cmdName = `cmd_${toHex(cmdId)}`;
    const data = stPayload.subarray(2, stPayload.length - 1);
    const magic = stPayload[0];
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[magic:${toHex(magic)} cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    const direction = isResponse ? "RX" : "SNIFF";
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger6.info(`${direction} ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, s.id);
              this.feedbackCallback(baseFeedbackKey);
            } else {
              logger6.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger6.debug(`${direction} ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger6.warn(`${direction} ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    if (decoded) {
      logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   *
   * msg is the full packet buffer — required by the settings parsers which
   * locate the Studio-T signature themselves.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  static async buildHeader(totalLen, destIp) {
    const mac = await getMacForDestination(destIp);
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(model, destIp) {
    return this.sendAwaitAck(model, CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(model, destIp) {
    return this.sendAwaitAck(model, CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
import path3 from "path";
var logger7 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Ok);
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger7.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger7.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger7.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger7.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger7.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger7.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger7.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger7.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    logger7.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger7.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current host+model combination is authorized.
   * Called on every config change so that switching model or IP is always validated.
   *
   * Rules:
   * - discoveredHost set → device already verified by Dante, always authorize
   * - manual host → check against discovered list first; probe if unknown
   *   - discovered device at that IP with matching model → authorize
   *   - discovered device at that IP with wrong model → revoke + log error
   *   - not in discovered list → probe; authorize on match, revoke on mismatch/timeout
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.discoveredHost) {
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        const model = resolveModel(this.config, this.discoveredDevices);
        await this.fetchSettingsAndEnsureSchema(model, newHost);
      }
      return;
    }
    const manualModel = this.config.activeModel;
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
      } else {
        logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
      }
      return;
    }
    logger7.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger7.error(`No device responded at ${newHost} \u2014 commands blocked`);
    } else if (probed.model !== manualModel) {
      logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
    } else {
      logger7.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      const buf = await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger7.info(`No schema found for Model ${model} \u2014 creating from device response`);
        const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
        if (parsed.length === 0) {
          logger7.warn(`Could not parse settings for Model ${model} \u2014 schema not created`);
          return;
        }
        const schemas = getNormalizedSchemas(getDeviceSchemas());
        const newSchema = { model, sectioned: detectedSectioned ?? false, cmdSchema: [] };
        if (detectedSectioned !== null) {
          newSchema.sectioned = detectedSectioned;
        }
        const updated = updateModelJsonFromSettings(newSchema, parsed, schemas);
        const schemaPath = path3.join(getDevicesFolder(), `Model${model}.json`);
        saveModelJsonPretty(schemaPath, updated);
        reloadDeviceSchemas();
        logger7.info(`Created schema for Model ${model} at ${schemaPath}`);
        this.syncModel(model);
        this.updateActions();
        this.updateFeedbacks();
        this.updateVariableDefinitions();
      }
    } catch (e) {
      logger7.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model and pushes it to the controller. */
  syncModel(model) {
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger7.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, [], true);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    const refreshAfterCommand = schema.refreshAfterCommand ?? true;
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger7.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger7.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}, refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, preferring the discovered device selection. */
  get host() {
    return resolveHost(this.config);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0aG9zdDogc3RyaW5nXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcblx0LyoqIElQIG9mIGEgZGlzY292ZXJlZCBEYW50ZSBkZXZpY2UsIG9yICcnIHdoZW4gdGhlIHVzZXIgY2hvb3NlcyBNYW51YWwgKi9cblx0ZGlzY292ZXJlZEhvc3Q6IHN0cmluZ1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBDRU5UUkFMSVpFRCBERVZJQ0UgU0NIRU1BIENBQ0hFXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBBbGwgZGV2aWNlIEpTT04gZmlsZXMgYXJlIGxvYWRlZCBvbmNlIGludG8gbWVtb3J5IGhlcmUuIE90aGVyIG1vZHVsZXMgc2hvdWxkXG4vLyB1c2UgZ2V0RGV2aWNlc0ZvbGRlcigpLCBnZXREZXZpY2VTY2hlbWFzKCksIGFuZCBnZXREZXZpY2VTY2hlbWEoKSBpbnN0ZWFkIG9mXG4vLyByZWFkaW5nIGZpbGVzIGRpcmVjdGx5LiBDYWxsIHJlbG9hZERldmljZVNjaGVtYXMoKSBhZnRlciB3cml0aW5nIHRvIGEgZmlsZS5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuLyoqXG4gKiBEZXRlcm1pbmVzIHRoZSBjb3JyZWN0IGRldmljZXMgZm9sZGVyIHBhdGggd2l0aCBmYWxsYmFjayBzdXBwb3J0LlxuICogQ2hlY2tzIHByaW1hcnkgcGF0aCBmaXJzdCwgdGhlbiBmYWxsYmFjaywgdGhlbiB0aHJvd3MgZXJyb3IgaWYgbmVpdGhlciBleGlzdHMuXG4gKi9cbmZ1bmN0aW9uIHJlc29sdmVEZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdGNvbnN0IHByaW1hcnlQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuLi9kZXZpY2VzJylcblx0Y29uc3QgZmFsbGJhY2tQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuL2RldmljZXMnKVxuXG5cdC8vIENoZWNrIHByaW1hcnkgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhwcmltYXJ5UGF0aCkpIHtcblx0XHRsb2dnZXIuZGVidWcoYFVzaW5nIGRldmljZXMgZm9sZGVyOiAke3ByaW1hcnlQYXRofWApXG5cdFx0cmV0dXJuIHByaW1hcnlQYXRoXG5cdH1cblxuXHQvLyBDaGVjayBmYWxsYmFjayBwYXRoXG5cdGlmIChmcy5leGlzdHNTeW5jKGZhbGxiYWNrUGF0aCkpIHtcblx0XHRsb2dnZXIud2FybihgUHJpbWFyeSBkZXZpY2VzIGZvbGRlciBub3QgZm91bmQsIHVzaW5nIGZhbGxiYWNrOiAke2ZhbGxiYWNrUGF0aH1gKVxuXHRcdHJldHVybiBmYWxsYmFja1BhdGhcblx0fVxuXG5cdC8vIE5laXRoZXIgcGF0aCBleGlzdHMgLSBmYXRhbCBlcnJvclxuXHRjb25zdCBlcnJvck1zZyA9IGBEZXZpY2VzIGZvbGRlciBub3QgZm91bmQhXFxuVHJpZWQ6XFxuICAtICR7cHJpbWFyeVBhdGh9XFxuICAtICR7ZmFsbGJhY2tQYXRofVxcbk1vZHVsZSBjYW5ub3QgY29udGludWUgd2l0aG91dCBkZXZpY2Ugc2NoZW1hcy5gXG5cdGxvZ2dlci5lcnJvcihlcnJvck1zZylcblx0dGhyb3cgbmV3IEVycm9yKGVycm9yTXNnKVxufVxuXG4vLyBSZXNvbHZlIHRoZSBkZXZpY2VzIGZvbGRlciBwYXRoICh3aXRoIGV4aXN0ZW5jZSBjaGVjayBhbmQgZmFsbGJhY2spXG5jb25zdCBkZXZpY2VzRm9sZGVyID0gcmVzb2x2ZURldmljZXNGb2xkZXIoKVxuXG4vLyBJbi1tZW1vcnkgY2FjaGUgb2YgYWxsIGRldmljZSBzY2hlbWFzLCBrZXllZCBieSBtb2RlbCBudW1iZXJcbmxldCBkZXZpY2VTY2hlbWFzQ2FjaGU6IFJlY29yZDxzdHJpbmcsIGFueT4gfCBudWxsID0gbnVsbFxuXG4vKipcbiAqIFJldHVybnMgdGhlIGFic29sdXRlIHBhdGggdG8gdGhlIGRldmljZXMgZm9sZGVyLlxuICogVXNlIHRoaXMgaW5zdGVhZCBvZiByZWRlZmluaW5nIHRoZSBwYXRoIGluIGV2ZXJ5IGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdHJldHVybiBkZXZpY2VzRm9sZGVyXG59XG5cbi8qKlxuICogTG9hZHMgYWxsIGRldmljZSBKU09OIGZpbGVzIGZyb20gdGhlIGRldmljZXMgZm9sZGVyIGludG8gbWVtb3J5LlxuICogVGhpcyBzaG91bGQgb25seSBiZSBjYWxsZWQgb25jZSBhdCBpbml0aWFsaXphdGlvbiwgb3IgYWZ0ZXIgYSBmaWxlIGlzIHdyaXR0ZW4uXG4gKi9cbmZ1bmN0aW9uIGxvYWREZXZpY2VTY2hlbWFzKCk6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRjb25zdCBzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge31cblx0dHJ5IHtcblx0XHRjb25zdCBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKGRldmljZXNGb2xkZXIpLmZpbHRlcigoZikgPT4gZi5lbmRzV2l0aCgnLmpzb24nKSlcblxuXHRcdGZvciAoY29uc3QgZiBvZiBmaWxlcykge1xuXHRcdFx0Y29uc3QgZnVsbFBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgZilcblx0XHRcdGNvbnN0IGpzb24gPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCwgJ3V0ZjgnKSlcblx0XHRcdGlmIChqc29uPy5tb2RlbCkge1xuXHRcdFx0XHRzY2hlbWFzW1N0cmluZyhqc29uLm1vZGVsKV0gPSBqc29uXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBMb2FkZWQgJHtPYmplY3Qua2V5cyhzY2hlbWFzKS5sZW5ndGh9IGRldmljZSBzY2hlbWFzIGludG8gY2FjaGVgKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmVycm9yKGBGYWlsZWQgdG8gbG9hZCBkZXZpY2Ugc2NoZW1hczogJHtlfWApXG5cdH1cblx0cmV0dXJuIHNjaGVtYXNcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIHRoZSBjYWNoZS5cbiAqIEluaXRpYWxpemVzIHRoZSBjYWNoZSBvbiBmaXJzdCBjYWxsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0aWYgKCFkZXZpY2VTY2hlbWFzQ2FjaGUpIHtcblx0XHRkZXZpY2VTY2hlbWFzQ2FjaGUgPSBsb2FkRGV2aWNlU2NoZW1hcygpXG5cdH1cblx0cmV0dXJuIGRldmljZVNjaGVtYXNDYWNoZVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBzcGVjaWZpYyBkZXZpY2Ugc2NoZW1hIGJ5IG1vZGVsIG51bWJlci5cbiAqIFJldHVybnMgdW5kZWZpbmVkIGlmIHRoZSBtb2RlbCBkb2Vzbid0IGV4aXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsOiBzdHJpbmcpOiBhbnkge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBzY2hlbWFzW21vZGVsXVxufVxuXG4vKipcbiAqIFJlbG9hZHMgYWxsIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay5cbiAqIENhbGwgdGhpcyBhZnRlciB3cml0aW5nIHRvIGEgZGV2aWNlIEpTT04gZmlsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbG9hZERldmljZVNjaGVtYXMoKTogdm9pZCB7XG5cdGxvZ2dlci5pbmZvKCdSZWxvYWRpbmcgZGV2aWNlIHNjaGVtYXMgZnJvbSBkaXNrLi4uJylcblx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBsaXN0IG9mIGF2YWlsYWJsZSBtb2RlbCBudW1iZXJzLCBzb3J0ZWQuXG4gKi9cbmZ1bmN0aW9uIGxvYWRBdmFpbGFibGVNb2RlbHMoKTogc3RyaW5nW10ge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBPYmplY3Qua2V5cyhzY2hlbWFzKS5zb3J0KClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEdldENvbmZpZ0ZpZWxkcyhkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW10pOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdGNvbnN0IG1vZGVscyA9IGxvYWRBdmFpbGFibGVNb2RlbHMoKVxuXG5cdC8vIEJ1aWxkIGNob2ljZXMgbWlycm9yaW5nIHRoZSBib25qb3VyLWRldmljZSBwYXR0ZXJuOlxuXHQvLyAgIGZpcnN0IGVudHJ5IGlzIGFsd2F5cyAnTWFudWFsJyAoZW1wdHkgdmFsdWUpXG5cdC8vICAgdGhlbiBvbmUgZW50cnkgcGVyIGRpc2NvdmVyZWQgZGV2aWNlXG5cdGNvbnN0IGRldmljZUNob2ljZXMgPSBbXG5cdFx0eyBpZDogJycsIGxhYmVsOiAnTWFudWFsJyB9LFxuXHRcdC4uLmRpc2NvdmVyZWREZXZpY2VzLm1hcCgoZCkgPT4gKHtcblx0XHRcdGlkOiBkLmlwLFxuXHRcdFx0bGFiZWw6IGBNb2RlbCAke2QubW9kZWx9ICgke2QuaXB9KWAsXG5cdFx0fSkpLFxuXHRdXG5cblx0cmV0dXJuIFtcblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2aWNlIGRpc2NvdmVyeSBkcm9wZG93biBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBNaXJyb3JzIHRoZSBib25qb3VyLWRldmljZSBmaWVsZDogc2VsZWN0aW5nIGEgZGV2aWNlIHBvcHVsYXRlcyB0aGVcblx0XHQvLyBob3N0IGF1dG9tYXRpY2FsbHk7IHNlbGVjdGluZyAnTWFudWFsJyBzaG93cyB0aGUgdGV4dGlucHV0IGJlbG93LlxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2Rpc2NvdmVyZWRIb3N0Jyxcblx0XHRcdGxhYmVsOiAnRGV2aWNlJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRjaG9pY2VzOiBkZXZpY2VDaG9pY2VzLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCBhbiBhdXRvLWRpc2NvdmVyZWQgU3R1ZGlvIFRlY2hub2xvZ2llcyBEYW50ZSBkZXZpY2UsIG9yIGNob29zZSBNYW51YWwgdG8gZW50ZXIgYW4gSVAgYWRkcmVzcy4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgTWFudWFsIElQIGVudHJ5IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIE9ubHkgdmlzaWJsZSB3aGVuIGRpc2NvdmVyZWRIb3N0IGlzICcnIChNYW51YWwgc2VsZWN0ZWQpLlxuXHRcdC8vIE1hdGNoZXMgdGhlIHBhdHRlcm4gZnJvbSB0aGUgYm9uam91ci1kZXZpY2UgZG9jcy5cblx0XHR7XG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGlkOiAnaG9zdCcsXG5cdFx0XHRsYWJlbDogJ1RhcmdldCBJUCcsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0cmVnZXg6IFJlZ2V4LklQLFxuXHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogYCEkKG9wdGlvbnM6ZGlzY292ZXJlZEhvc3QpYCxcblx0XHRcdHRvb2x0aXA6ICdFbnRlciB0aGUgSVAgYWRkcmVzcyBvZiB0aGUgZGV2aWNlIG1hbnVhbGx5LicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNb2RlbCBzZWxlY3RvciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBPbmx5IHZpc2libGUgd2hlbiBNYW51YWwgbW9kZSBpcyBzZWxlY3RlZCAobm8gZGlzY292ZXJlZCBkZXZpY2UpLlxuXHRcdC8vIFdoZW4gYSBkaXNjb3ZlcmVkIGRldmljZSBpcyBzZWxlY3RlZCwgdGhlIG1vZGVsIGlzIGF1dG8tZGV0ZWN0ZWQuXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnYWN0aXZlTW9kZWwnLFxuXHRcdFx0bGFiZWw6ICdBY3RpdmUgRGV2aWNlIE1vZGVsJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogbW9kZWxzWzBdID8/ICcnLFxuXHRcdFx0Y2hvaWNlczogbW9kZWxzLm1hcCgobW9kZWwpID0+ICh7XG5cdFx0XHRcdGlkOiBtb2RlbCxcblx0XHRcdFx0bGFiZWw6IGBNb2RlbCAke21vZGVsfWAsXG5cdFx0XHR9KSksXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkaXNjb3ZlcmVkSG9zdClgLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCB3aGljaCBTdHVkaW8gVGVjaG5vbG9naWVzIG1vZGVsIGlzIGFjdGl2ZSBmb3IgYWN0aW9ucyBhbmQgR2V0IEFsbCBTZXR0aW5ncycsXG5cdFx0fSxcblx0XVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQIGZyb20gY29uZmlnIFx1MjAxNCBwcmVmZXJzIHRoZSBkaXNjb3ZlcmVkIGRldmljZVxuICogSVAgd2hlbiBvbmUgaXMgc2VsZWN0ZWQsIGZhbGxzIGJhY2sgdG8gdGhlIG1hbnVhbGx5IGVudGVyZWQgaG9zdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVIb3N0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogc3RyaW5nIHtcblx0cmV0dXJuIGNvbmZpZy5kaXNjb3ZlcmVkSG9zdCB8fCBjb25maWcuaG9zdFxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBtb2RlbCBcdTIwMTQgaWYgYSBkaXNjb3ZlcmVkIGRldmljZSBpcyBzZWxlY3RlZCwgZXh0cmFjdHNcbiAqIGl0cyBtb2RlbCBmcm9tIHRoZSBkaXNjb3ZlcmVkRGV2aWNlcyBsaXN0OyBvdGhlcndpc2UgdXNlcyBhY3RpdmVNb2RlbC5cbiAqIFJldHVybnMgZW1wdHkgc3RyaW5nIGlmIG5vIGRldmljZXMgYXJlIGRpc2NvdmVyZWQgYW5kIHVzaW5nIGRpc2NvdmVyZWRIb3N0IG1vZGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlTW9kZWwoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRpc2NvdmVyZWRIb3N0KSB7XG5cdFx0Y29uc3QgZGV2aWNlID0gZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY29uZmlnLmRpc2NvdmVyZWRIb3N0KVxuXHRcdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBkaXNjb3ZlcmVkSG9zdD1cIiR7Y29uZmlnLmRpc2NvdmVyZWRIb3N0fVwiLCBmb3VuZCBkZXZpY2U6ICR7ZGV2aWNlPy5tb2RlbCA/PyAnbm9uZSd9YClcblx0XHRpZiAoZGV2aWNlPy5tb2RlbCkge1xuXHRcdFx0cmV0dXJuIGRldmljZS5tb2RlbFxuXHRcdH1cblx0XHQvLyBJZiB1c2luZyBkaXNjb3ZlcmVkSG9zdCBtb2RlIGJ1dCBubyBkZXZpY2UgZm91bmQsIGRvbid0IGZhbGwgYmFjayB0byBhY3RpdmVNb2RlbFxuXHRcdGlmIChkaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGggPT09IDApIHtcblx0XHRcdGxvZ2dlci53YXJuKGByZXNvbHZlTW9kZWw6IE5vIGRldmljZXMgZGlzY292ZXJlZCwgY2Fubm90IGRldGVybWluZSBtb2RlbGApXG5cdFx0XHRyZXR1cm4gJydcblx0XHR9XG5cdH1cblx0bG9nZ2VyLmRlYnVnKGByZXNvbHZlTW9kZWw6IGZhbGxpbmcgYmFjayB0byBhY3RpdmVNb2RlbD1cIiR7Y29uZmlnLmFjdGl2ZU1vZGVsfVwiYClcblx0cmV0dXJuIGNvbmZpZy5hY3RpdmVNb2RlbFxufVxuIiwgImltcG9ydCB0eXBlIE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcblxuLyoqXG4gKiBEZWZpbmUgQ29tcGFuaW9uIHZhcmlhYmxlcyBmb3IgdGhpcyBtb2R1bGUuXG4gKiBWYXJpYWJsZXMgY2FuIGJlIHVzZWQgdG8gZGlzcGxheSBkeW5hbWljIHN0YXRlIGluIGJ1dHRvbiBsYWJlbHMsIHRyaWdnZXJzLCBldGMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh7XG5cdFx0bW9kZWw6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOdW1iZXInIH0sXG5cdFx0bW9kZWxOYW1lOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTmFtZSAoRnVsbCBEZXNjcmlwdGlvbiknIH0sXG5cdFx0bWFudWZhY3R1cmVyOiB7IG5hbWU6ICdEZXZpY2UgTWFudWZhY3R1cmVyJyB9LFxuXHRcdGZpcm13YXJlOiB7IG5hbWU6ICdEZXZpY2UgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRkYW50ZUZXOiB7IG5hbWU6ICdEYW50ZSBNb2R1bGUgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRtYWM6IHsgbmFtZTogJ0RldmljZSBNQUMgQWRkcmVzcycgfSxcblx0XHRpcDogeyBuYW1lOiAnRGV2aWNlIElQIEFkZHJlc3MnIH0sXG5cdH0pXG59XG5cbmNvbnN0IENMRUFSRURfVkFSSUFCTEVTID0ge1xuXHRtb2RlbDogJycsXG5cdG1vZGVsTmFtZTogJycsXG5cdG1hbnVmYWN0dXJlcjogJycsXG5cdGZpcm13YXJlOiAnJyxcblx0ZGFudGVGVzogJycsXG5cdG1hYzogJycsXG5cdGlwOiAnJyxcbn1cblxuLyoqXG4gKiBVcGRhdGUgdmFyaWFibGUgdmFsdWVzIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaW5mb3JtYXRpb24uXG4gKiBPbmx5IHBvcHVsYXRlcyB2YXJpYWJsZXMgd2hlbiB0aGUgY3VycmVudCBob3N0IGlzIGF1dGhvcml6ZWQuXG4gKiBDbGVhcnMgYWxsIHZhcmlhYmxlcyBpZiB0aGUgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkIG9yIG5vdCBmb3VuZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IGN1cnJlbnRIb3N0ID0gc2VsZi5ob3N0XG5cblx0Ly8gQ2xlYXIgdmFyaWFibGVzIGlmIG5vIGhvc3QgY29uZmlndXJlZCBvciBkZXZpY2UgaXMgbm90IGF1dGhvcml6ZWRcblx0aWYgKCFjdXJyZW50SG9zdCB8fCAhc2VsZi5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKGN1cnJlbnRIb3N0KSkge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoQ0xFQVJFRF9WQVJJQUJMRVMpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBkZXZpY2UgPSBzZWxmLmRldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY3VycmVudEhvc3QpXG5cdGlmIChkZXZpY2UpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdG1vZGVsOiBkZXZpY2UubW9kZWwgfHwgJycsXG5cdFx0XHRtb2RlbE5hbWU6IGRldmljZS5tb2RlbE5hbWUgfHwgJycsXG5cdFx0XHRtYW51ZmFjdHVyZXI6IGRldmljZS5tYW51ZmFjdHVyZXIgfHwgJycsXG5cdFx0XHRmaXJtd2FyZTogZGV2aWNlLmZpcm13YXJlTWFpbiB8fCAnJyxcblx0XHRcdGRhbnRlRlc6IGRldmljZS5kYW50ZUZpcm13YXJlIHx8ICcnLFxuXHRcdFx0bWFjOiBkZXZpY2UubWFjIHx8ICcnLFxuXHRcdFx0aXA6IGRldmljZS5pcCxcblx0XHR9KVxuXHR9IGVsc2Uge1xuXHRcdC8vIEF1dGhvcml6ZWQgYnV0IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgKG1hbnVhbCBJUCB0aGF0IHByb2JlZCBzdWNjZXNzZnVsbHkpXG5cdFx0Ly8gV2Uga25vdyBpdCdzIHRoZSByaWdodCBkZXZpY2UgYnV0IGRvbid0IGhhdmUgZnVsbCBpbmZvIHlldFxuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0Li4uQ0xFQVJFRF9WQVJJQUJMRVMsXG5cdFx0XHRpcDogY3VycmVudEhvc3QsXG5cdFx0fSlcblx0fVxufVxuIiwgImltcG9ydCB0eXBlIHsgQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG5leHBvcnQgY29uc3QgVXBncmFkZVNjcmlwdHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQ8TW9kdWxlQ29uZmlnPltdID0gW1xuXHQvKlxuXHQgKiBQbGFjZSB5b3VyIHVwZ3JhZGUgc2NyaXB0cyBoZXJlXG5cdCAqIFJlbWVtYmVyIHRoYXQgb25jZSBpdCBoYXMgYmVlbiBhZGRlZCBpdCBjYW5ub3QgYmUgcmVtb3ZlZCFcblx0ICovXG5cdC8vIGZ1bmN0aW9uIChjb250ZXh0LCBwcm9wcykge1xuXHQvLyBcdHJldHVybiB7XG5cdC8vIFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHQvLyBcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHQvLyBcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdC8vIFx0fVxuXHQvLyB9LFxuXVxuIiwgImV4cG9ydCB0eXBlIENvbXBhbmlvbklucHV0Q2hvaWNlID0ge1xuXHRpZDogc3RyaW5nIHwgbnVtYmVyXG5cdGxhYmVsOiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgRGV2aWNlU2V0dGluZyA9IHtcblx0dHlwZTogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVmYXVsdDogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhblxuXHRjaG9pY2VzPzogQ29tcGFuaW9uSW5wdXRDaG9pY2VbXVxufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBHZXQgc2V0dGluZyBmcm9tIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0JVU19TRVQgPSAweDA0IC8vIFNldCBzZXR0aW5nIG9uIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0hFQURQSE9ORSA9IDB4MDUgLy8gSGVhZHBob25lIGNvbnRyb2xzIChyZXNlcnZlZCBmb3IgZnV0dXJlIHVzZSlcbmV4cG9ydCBjb25zdCBDTURfQlVUVE9OX01PREUgPSAweDA3IC8vIEJ1dHRvbiBtb2RlIGNvbmZpZ3VyYXRpb24gKHJlc2VydmVkIGZvciBmdXR1cmUgdXNlKVxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kcyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5leHBvcnQgY29uc3QgQ01EX0dFVF9BTExfU0VUVElOR1MgPSAweDBhIC8vIFJlcXVlc3QgYWxsIGN1cnJlbnQgc2V0dGluZ3MgZnJvbSBkZXZpY2VcbmV4cG9ydCBjb25zdCBDTURfU0VUVElOR1NfUFVTSCA9IDB4MGIgLy8gVW5zb2xpY2l0ZWQgc2V0dGluZ3MgdXBkYXRlIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX0RFVl9TUEVDID0gMHgwZCAvLyBEZXZpY2Utc3BlY2lmaWMgc2V0dGluZyBnZXQvc2V0IHdpdGggQUNLXG5leHBvcnQgY29uc3QgQ01EX1JFU0VUX0RFVklDRSA9IDB4MGUgLy8gRmFjdG9yeSByZXNldCBjb21tYW5kXG5leHBvcnQgY29uc3QgQ01EX0dMT0JBTF9NSUNfS0lMTCA9IDB4MTAgLy8gRW1lcmdlbmN5IG1pYyBraWxsIChhbGwgY2hhbm5lbHMpXG5leHBvcnQgY29uc3QgQ01EX01JQ19QUkVfQlVTID0gMHgxMiAvLyBNaWMvcHJlYW1wIHNldHRpbmdzIHBlciBidXMgKGdhaW4sIHBoYW50b20sIGV0YylcbmV4cG9ydCBjb25zdCBDTURfQ0hBTk5FTCA9IDB4MTQgLy8gQ2hhbm5lbC1zcGVjaWZpYyBjb250cm9scyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBDb21tYW5kIE5hbWUgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbW1hbmROYW1lKGNtZElkOiBudW1iZXIpOiBzdHJpbmcge1xuXHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0Y2FzZSBDTURfR0VUX0ZJUk1XQVJFOlxuXHRcdFx0cmV0dXJuICdHZXQgRmlybXdhcmUgVmVyc2lvbidcblx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0cmV0dXJuICdHZXQgQnVzIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfQlVTX1NFVDpcblx0XHRcdHJldHVybiAnU2V0IEJ1cyBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0hFQURQSE9ORTpcblx0XHRcdHJldHVybiAnSGVhZHBob25lIENvbnRyb2wnXG5cdFx0Y2FzZSBDTURfQlVUVE9OX01PREU6XG5cdFx0XHRyZXR1cm4gJ0J1dHRvbiBNb2RlJ1xuXHRcdGNhc2UgQ01EX1NZU1RFTTpcblx0XHRcdHJldHVybiAnU3lzdGVtIENvbW1hbmQnXG5cdFx0Y2FzZSBDTURfR0VUX0FMTF9TRVRUSU5HUzpcblx0XHRcdHJldHVybiAnUmVxdWVzdCBBbGwgU2V0dGluZ3MnXG5cdFx0Y2FzZSBDTURfU0VUVElOR1NfUFVTSDpcblx0XHRcdHJldHVybiAnU2V0dGluZ3MgUHVzaCdcblx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzpcblx0XHRcdHJldHVybiAnTWljL1ByZSBCdXMnXG5cdFx0Y2FzZSBDTURfREVWX1NQRUM6XG5cdFx0XHRyZXR1cm4gJ0RldmljZSBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0NIQU5ORUw6XG5cdFx0XHRyZXR1cm4gJ0NoYW5uZWwgU2V0dGluZydcblx0XHRjYXNlIENNRF9SRVNFVF9ERVZJQ0U6XG5cdFx0XHRyZXR1cm4gJ1Jlc2V0IERldmljZSdcblx0XHRjYXNlIENNRF9HTE9CQUxfTUlDX0tJTEw6XG5cdFx0XHRyZXR1cm4gJ0dsb2JhbCBNaWMgS2lsbCdcblx0XHRkZWZhdWx0OlxuXHRcdFx0cmV0dXJuIGBjbWRfMHgke2NtZElkLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfWBcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSUQgR2VuZXJhdGlvbiBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENyZWF0ZXMgYSBjb25zaXN0ZW50IElEIGZvciBhY3Rpb25zLCBmZWVkYmFja3MsIGFuZCBzdGF0ZSBrZXlzLlxuICogRm9ybWF0OiBgJHttb2RlbH1fJHtjbWRfaWR9XyR7YnVzQ2h9XyR7aWR9YCBmb3IgY29tbWFuZHMgd2l0aCBidXNDaCAoZS5nLiwgXCI1MzA0XzE0XzBfMFwiKVxuICogRm9ybWF0OiBgJHttb2RlbH1fJHtjbWRfaWR9XyR7aWR9YCBmb3IgY29tbWFuZHMgd2l0aG91dCBidXNDaCAoZS5nLiwgXCI1MzA0XzEyX2RcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1ha2VTZXR0aW5nSWQoXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIgfCBzdHJpbmcsXG5cdHNldHRpbmdJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRidXNDaD86IG51bWJlciB8IHN0cmluZyxcbik6IHN0cmluZyB7XG5cdGNvbnN0IGNtZCA9IHR5cGVvZiBjbWRJZCA9PT0gJ251bWJlcicgPyBjbWRJZC50b1N0cmluZygxNikgOiBjbWRJZFxuXHRjb25zdCBpZCA9IHR5cGVvZiBzZXR0aW5nSWQgPT09ICdudW1iZXInID8gc2V0dGluZ0lkLnRvU3RyaW5nKDE2KSA6IHNldHRpbmdJZFxuXG5cdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0Y29uc3QgY2ggPSB0eXBlb2YgYnVzQ2ggPT09ICdudW1iZXInID8gYnVzQ2gudG9TdHJpbmcoMTYpIDogYnVzQ2hcblx0XHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2NofV8ke2lkfWBcblx0fVxuXG5cdHJldHVybiBgJHttb2RlbH1fJHtjbWR9XyR7aWR9YFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSGV4IEZvcm1hdHRpbmcgSGVscGVycyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogQ29udmVydHMgYSBudW1iZXIgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4IGFuZCBwYWRkaW5nLlxuICogQHBhcmFtIHZhbHVlIC0gVGhlIG51bWJlciB0byBjb252ZXJ0XG4gKiBAcGFyYW0gcGFkTGVuZ3RoIC0gTnVtYmVyIG9mIGhleCBkaWdpdHMgdG8gcGFkIHRvIChkZWZhdWx0OiAyKVxuICogQHJldHVybnMgRm9ybWF0dGVkIGhleCBzdHJpbmcgKGUuZy4sIFwiMHgwZFwiLCBcIjB4ZmZcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSGV4KHZhbHVlOiBudW1iZXIsIHBhZExlbmd0aCA9IDIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHt2YWx1ZS50b1N0cmluZygxNikucGFkU3RhcnQocGFkTGVuZ3RoLCAnMCcpfWBcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBhcnJheSBvZiBieXRlcyB0byBhIGhleCBzdHJpbmcgd2l0aCAweCBwcmVmaXguXG4gKiBAcGFyYW0gYnl0ZXMgLSBBcnJheSBvZiBieXRlcyBvciBCdWZmZXJcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGFmZjEyXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBieXRlc1RvSGV4KGJ5dGVzOiBudW1iZXJbXSB8IEJ1ZmZlcik6IHN0cmluZyB7XG5cdHJldHVybiBgMHgke0FycmF5LmZyb20oYnl0ZXMpXG5cdFx0Lm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJyl9YFxufVxuXG4vKipcbiAqIEZvcm1hdHMgUkdCIGNvbG9yIGJ5dGVzIGFzIGEgQ1NTIGhleCBjb2xvciBzdHJpbmcuXG4gKiBAcGFyYW0gciAtIFJlZCBjb21wb25lbnQgKDAtMjU1KVxuICogQHBhcmFtIGcgLSBHcmVlbiBjb21wb25lbnQgKDAtMjU1KVxuICogQHBhcmFtIGIgLSBCbHVlIGNvbXBvbmVudCAoMC0yNTUpXG4gKiBAcmV0dXJucyBDU1MgaGV4IGNvbG9yIHN0cmluZyAoZS5nLiwgXCIjRkYwMEFCXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRSZ2JDb2xvcihyOiBudW1iZXIsIGc6IG51bWJlciwgYjogbnVtYmVyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAjJHtbciwgZywgYl1cblx0XHQubWFwKCh2KSA9PiB2LnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuXHRcdC5qb2luKCcnKVxuXHRcdC50b1VwcGVyQ2FzZSgpfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIFBhcnNpbmcgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBQYXJzZXMgYSBzZXR0aW5nIElEIHN0cmluZyBpbnRvIGl0cyBjb21wb25lbnRzLlxuICogQHBhcmFtIGlkIC0gU2V0dGluZyBJRCBzdHJpbmcgKGUuZy4sIFwiMzkxX2RfMFwiIG9yIFwiNTMwNF8xNF8wXzFcIilcbiAqIEByZXR1cm5zIFBhcnNlZCBjb21wb25lbnRzIHdpdGggaGV4IHN0cmluZ3MgY29udmVydGVkIHRvIG51bWJlcnNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ0lkKGlkOiBzdHJpbmcpOiB7IG1vZGVsOiBzdHJpbmc7IGNtZElkOiBudW1iZXI7IGJhc2VJZDogbnVtYmVyIH0ge1xuXHRjb25zdCBbbW9kZWwsIGNtZElkU3RyLCBpZFN0cl0gPSBpZC5zcGxpdCgnXycpXG5cdHJldHVybiB7XG5cdFx0bW9kZWwsXG5cdFx0Y21kSWQ6IHBhcnNlSW50KGNtZElkU3RyLCAxNiksXG5cdFx0YmFzZUlkOiBwYXJzZUludChpZFN0ciwgMTYpLFxuXHR9XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBNb2RlbCBEaXN0YW5jZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENhbGN1bGF0ZXMgbnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIHR3byBtb2RlbCBudW1iZXJzLlxuICogVXNlZCBmb3IgZmluZGluZyBzaW1pbGFyIG1vZGVscyBmb3Igc2V0dGluZyBpbmZlcmVuY2UuXG4gKiBAcGFyYW0gbW9kZWxBIC0gRmlyc3QgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MVwiKVxuICogQHBhcmFtIG1vZGVsQiAtIFNlY29uZCBtb2RlbCBudW1iZXIgKGUuZy4sIFwiMzkyXCIpXG4gKiBAcmV0dXJucyBOdW1lcmljIGRpc3RhbmNlIGJldHdlZW4gbW9kZWxzLCBvciBJbmZpbml0eSBpZiBlaXRoZXIgaXMgbm9uLW51bWVyaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1vZGVsRGlzdGFuY2UobW9kZWxBOiBzdHJpbmcsIG1vZGVsQjogc3RyaW5nKTogbnVtYmVyIHtcblx0Y29uc3QgbmEgPSBwYXJzZUludChtb2RlbEEucmVwbGFjZSgvXFxEL2csICcnKSwgMTApXG5cdGNvbnN0IG5iID0gcGFyc2VJbnQobW9kZWxCLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRpZiAoTnVtYmVyLmlzTmFOKG5hKSB8fCBOdW1iZXIuaXNOYU4obmIpKSByZXR1cm4gSW5maW5pdHlcblx0cmV0dXJuIE1hdGguYWJzKG5hIC0gbmIpXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBTY2hlbWEgTm9ybWFsaXphdGlvbiBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIE5vcm1hbGl6ZXMgZGV2aWNlIHNjaGVtYXMgdG8gZW5zdXJlIGNtZFNjaGVtYSBpcyBhbHdheXMgYW4gYXJyYXkuXG4gKiBUaGlzIGhlbHBlciBlbGltaW5hdGVzIGR1cGxpY2F0ZSBzY2hlbWEgdHJhbnNmb3JtYXRpb24gY29kZS5cbiAqIEBwYXJhbSBzY2hlbWFzUmF3IC0gUmF3IHNjaGVtYXMgZnJvbSBnZXREZXZpY2VTY2hlbWFzKClcbiAqIEByZXR1cm5zIE5vcm1hbGl6ZWQgc2NoZW1hcyB3aXRoIGd1YXJhbnRlZWQgY21kU2NoZW1hIGFycmF5c1xuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoXG5cdHNjaGVtYXNSYXc6IFJlY29yZDxzdHJpbmcsIGFueT4sXG4pOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4ge1xuXHRjb25zdCBub3JtYWxpemVkOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4gPSB7fVxuXHRmb3IgKGNvbnN0IFttb2RlbCwganNvbl0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hc1JhdykpIHtcblx0XHRub3JtYWxpemVkW21vZGVsXSA9IHtcblx0XHRcdG1vZGVsOiBqc29uLm1vZGVsLFxuXHRcdFx0Y21kU2NoZW1hOiBBcnJheS5pc0FycmF5KGpzb24uY21kU2NoZW1hKSA/IGpzb24uY21kU2NoZW1hIDogW10sXG5cdFx0fVxuXHR9XG5cdHJldHVybiBub3JtYWxpemVkXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBBY3Rpb24gTG9va3VwIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogRmluZHMgYW4gYWN0aW9uL3NldHRpbmcgaW4gdGhlIHNjaGVtYSwgc3VwcG9ydGluZyBib3RoIGV4YWN0IG1hdGNoZXMgYW5kIGlkQWRkIG9mZnNldHMuXG4gKiBUaGlzIGhlbHBlciBlbGltaW5hdGVzIGR1cGxpY2F0ZSBhY3Rpb24gbG9va3VwIGxvZ2ljIGFjcm9zcyBtdWx0aXBsZSBmaWxlcy5cbiAqIEBwYXJhbSBzY2hlbWFzIC0gTm9ybWFsaXplZCBkZXZpY2Ugc2NoZW1hc1xuICogQHBhcmFtIG1vZGVsIC0gRGV2aWNlIG1vZGVsIChlLmcuLCBcIjM5MVwiKVxuICogQHBhcmFtIGNtZElkIC0gQ29tbWFuZCBJRFxuICogQHBhcmFtIHNldHRpbmdJZCAtIFNldHRpbmcgSUQgKG1heSBpbmNsdWRlIGlkQWRkIG9mZnNldClcbiAqIEByZXR1cm5zIE1hdGNoaW5nIGFjdGlvbi9zZXR0aW5nIG9yIHVuZGVmaW5lZFxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZEFjdGlvbkZvclNldHRpbmcoXG5cdHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9Pixcblx0bW9kZWw6IHN0cmluZyxcblx0Y21kSWQ6IG51bWJlcixcblx0c2V0dGluZ0lkOiBudW1iZXIsXG4pOiBhbnkge1xuXHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRpZiAoIXNjaGVtYSB8fCAhQXJyYXkuaXNBcnJheShzY2hlbWEuY21kU2NoZW1hKSkgcmV0dXJuIHVuZGVmaW5lZFxuXG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHMuY21kX2lkID09PSBjbWRJZCAmJiBzLmlkID09PSBzZXR0aW5nSWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2gsIHRyeSB0byBmaW5kIGJhc2UgYWN0aW9uIHdpdGggaWRBZGRcblx0aWYgKCFhY3Rpb24pIHtcblx0XHRhY3Rpb24gPSBzY2hlbWEuY21kU2NoZW1hLmZpbmQoKHM6IGFueSkgPT4ge1xuXHRcdFx0aWYgKHMuY21kX2lkICE9PSBjbWRJZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IHMub3B0aW9ucz8uZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgc2V0dGluZ0lkIG1hdGNoZXMgYmFzZSArIGFueSBpZEFkZCBvZmZzZXRcblx0XHRcdGNvbnN0IG9mZnNldCA9IHNldHRpbmdJZCAtIHMuaWRcblx0XHRcdHJldHVybiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KVxuXHRcdH0pXG5cdH1cblxuXHRyZXR1cm4gYWN0aW9uXG59XG4iLCAiLyoqXG4gKiBidWlsZC1jb21tYW5kcy50c1xuICogLSBVc2VzIGNlbnRyYWxpemVkIGRldmljZSBzY2hlbWEgY2FjaGUgZnJvbSBjb25maWcudHNcbiAqIC0gUHJvZHVjZXMgQ29tcGFuaW9uIGFjdGlvbiBkZWZpbml0aW9ucyBhbmQgZmVlZGJhY2tzXG4gKi9cblxuaW1wb3J0IHtcblx0Q29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMsXG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24sXG5cdENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBtYWtlU2V0dGluZ0lkIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLSBPcHRpb24gQnVpbGRlciAtLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5mdW5jdGlvbiBidWlsZE9wdGlvbihvOiBhbnkpOiBhbnkge1xuXHRjb25zdCBiYXNlID0ge1xuXHRcdHR5cGU6IG8udHlwZSxcblx0XHRpZDogby5pZCxcblx0XHRsYWJlbDogby5sYWJlbCxcblx0XHRkZWZhdWx0OiBvLmRlZmF1bHQsXG5cdFx0dG9vbHRpcDogby50b29sdGlwLFxuXHR9XG5cblx0c3dpdGNoIChvLnR5cGUpIHtcblx0XHRjYXNlICdkcm9wZG93bic6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBjaG9pY2VzOiBvLmNob2ljZXMgPz8gW10gfVxuXG5cdFx0Y2FzZSAnbnVtYmVyJzpcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdC4uLmJhc2UsXG5cdFx0XHRcdG1pbjogby5taW4sXG5cdFx0XHRcdG1heDogby5tYXgsXG5cdFx0XHRcdHN0ZXA6IG8uc3RlcCA/PyAxLFxuXHRcdFx0XHRyYW5nZTogdHJ1ZSxcblx0XHRcdH1cblxuXHRcdGNhc2UgJ2NoZWNrYm94Jzpcblx0XHRcdHJldHVybiB7IC4uLmJhc2UsIGRlZmF1bHQ6IG8uZGVmYXVsdCA/PyBmYWxzZSB9XG5cblx0XHRjYXNlICd0ZXh0aW5wdXQnOlxuXHRcdGNhc2UgJ2NvbG9ycGlja2VyJzpcblx0XHRjYXNlICdzdGF0aWMtdGV4dCc6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIGEuY21kX2lkLCBhLmlkKVxuXG5cdFx0XHRjb25zdCBvcHRpb25zID0gKGEub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHRjb25zdCBhY3Rpb246IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHthLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVBY3Rpb25zICovXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGFjdGlvbnNbYWN0aW9uSWRdID0gYWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvbnNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBGZWVkYmFja3MgLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGZWVkYmFja3MoKTogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgZmVlZGJhY2tzOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3Qgc2V0dGluZyBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0lkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgc2V0dGluZy5jbWRfaWQsIHNldHRpbmcuaWQpXG5cblx0XHRcdC8vIEJ1aWxkIG9wdGlvbnNcblx0XHRcdGNvbnN0IGFsbE9wdGlvbnMgPSAoc2V0dGluZy5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdC8vIEZpbHRlciBvdXQgJ3ZhbHVlJyBvcHRpb24gZm9yIHZhbHVlIGZlZWRiYWNrIChrZWVwIG9ubHkgYnVzQ2gvaWRBZGQpXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbnMgPSBhbGxPcHRpb25zLmZpbHRlcigob3B0OiBhbnkpID0+IG9wdC5pZCAhPT0gJ3ZhbHVlJylcblxuXHRcdFx0Ly8gQWRkIGEgY2hlY2tib3ggb3B0aW9uIHRvIHJldHVybiBsYWJlbCBpbnN0ZWFkIG9mIHZhbHVlXG5cdFx0XHR2YWx1ZU9wdGlvbnMucHVzaCh7XG5cdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0bGFiZWw6ICdTaG93IExhYmVsJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHR9KVxuXG5cdFx0XHQvLyBWYWx1ZSBmZWVkYmFjayBmb3IgYWxsIHNldHRpbmdzIChhcHBlYXJzIGluIFZhcmlhYmxlcyBsaXN0KVxuXHRcdFx0Y29uc3QgdmFsdWVGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHR0eXBlOiAndmFsdWUnLFxuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnM6IHZhbHVlT3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRyZXR1cm4gMFxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRmZWVkYmFja3NbYmFzZUZlZWRiYWNrSWRdID0gdmFsdWVGZWVkYmFja1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IHJlc29sdmVNb2RlbCwgZ2V0RGV2aWNlc0ZvbGRlciwgZ2V0RGV2aWNlU2NoZW1hLCBnZXREZXZpY2VTY2hlbWFzLCByZWxvYWREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMgfSBmcm9tICcuL3R5cGVzLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5cbmltcG9ydCB7IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uLCBzYXZlTW9kZWxKc29uUHJldHR5LCB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MgfSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ0FjdGlvbnMnKVxuXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlQWN0aW9ucyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBzY2hlbWFzUmF3ID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IHJhd0FjdGlvbnMgPSBidWlsZEFjdGlvbnMoKVxuXHRjb25zdCBzY2hlbWFzID0gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoc2NoZW1hc1Jhdylcblx0Y29uc3Qgd2lyZWRBY3Rpb25zOiBhbnkgPSB7fVxuXG5cdC8vIEdldCB0aGUgYWN0aXZlIG1vZGVsIHVzaW5nIHJlc29sdmVNb2RlbFxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbChzZWxmLmNvbmZpZywgc2VsZi5kZXZpY2VzKVxuXHRsb2dnZXIuaW5mbyhcblx0XHRgVXBkYXRlQWN0aW9uczogYWN0aXZlTW9kZWw9XCIke2FjdGl2ZU1vZGVsfVwiLCBkaXNjb3ZlcmVkSG9zdD1cIiR7c2VsZi5jb25maWcuZGlzY292ZXJlZEhvc3R9XCIsIGRldmljZXMgY291bnQ9JHtzZWxmLmRldmljZXMubGVuZ3RofWAsXG5cdClcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEdMT0JBTDogR0VUIEFMTCBTRVRUSU5HUyAoQVVUTyBKU09OIFVQREFURSlcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0Ly8gT25seSB3aXJlIHRoZSBnZXRBbGxTZXR0aW5ncyBhY3Rpb24gaWYgdGhlIGRldmljZSBpcyBhdXRob3JpemVkXG5cdGlmIChzZWxmLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQoc2VsZi5ob3N0KSkge1xuXHRcdHdpcmVkQWN0aW9uc1snZ2xvYmFsX2dldEFsbFNldHRpbmdzJ10gPSB7XG5cdFx0XHRuYW1lOiAnR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzIChBdXRvLVVwZGF0ZSBKU09OKScsXG5cdFx0XHRvcHRpb25zOiBbXSxcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IG1vZGVsID0gYWN0aXZlTW9kZWxcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3RcblxuXHRcdFx0XHRjb25zdCBidWYgPSBhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApXG5cblx0XHRcdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIHRvIGdldCB0aGUgc2NoZW1hXG5cdFx0XHRcdGxldCBtb2RlbEpzb24gPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0XHRcdGlmICghbW9kZWxKc29uKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmVycm9yKGBNb2RlbCAke21vZGVsfSBzY2hlbWEgbm90IGZvdW5kIGluIGNhY2hlYClcblx0XHRcdFx0XHRyZXR1cm5cblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFBhcnNlIHdpdGggYXV0by1kZXRlY3Rpb25cblx0XHRcdFx0Y29uc3QgeyBzZXR0aW5nczogcGFyc2VkLCBkZXRlY3RlZFNlY3Rpb25lZCB9ID0gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24obW9kZWwsIGJ1Zilcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBwYXJzZWQgcmVwbHk6ICR7SlNPTi5zdHJpbmdpZnkocGFyc2VkKX1gKVxuXG5cdFx0XHRcdC8vIElmIHdlIGF1dG8tZGV0ZWN0ZWQgdGhlIGZvcm1hdCwgYWRkIGl0IHRvIHRoZSBKU09OXG5cdFx0XHRcdGlmIChkZXRlY3RlZFNlY3Rpb25lZCAhPT0gbnVsbCkge1xuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIHNlY3Rpb25lZD0ke2RldGVjdGVkU2VjdGlvbmVkfSwgYWRkaW5nIHRvIG1vZGVsIEpTT05gKVxuXHRcdFx0XHRcdG1vZGVsSnNvbiA9IHsgLi4ubW9kZWxKc29uLCBzZWN0aW9uZWQ6IGRldGVjdGVkU2VjdGlvbmVkIH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IHVwZGF0ZWQgPSB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MobW9kZWxKc29uLCBwYXJzZWQsIHNjaGVtYXMpXG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgbmV3IEFjdGlvbnMganNvbjogJHtKU09OLnN0cmluZ2lmeSh1cGRhdGVkLCBudWxsLCAyKX1gKVxuXG5cdFx0XHRcdC8vIFNhdmUgdGhlIHVwZGF0ZWQgSlNPTiB0byBkaXNrXG5cdFx0XHRcdGNvbnN0IGRldmljZXNGb2xkZXIgPSBnZXREZXZpY2VzRm9sZGVyKClcblx0XHRcdFx0Y29uc3Qgc2NoZW1hUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBgTW9kZWwke21vZGVsfS5qc29uYClcblx0XHRcdFx0c2F2ZU1vZGVsSnNvblByZXR0eShzY2hlbWFQYXRoLCB1cGRhdGVkKVxuXG5cdFx0XHRcdC8vIFJlbG9hZCB0aGUgY2FjaGUgYWZ0ZXIgd3JpdGluZyB0byBmaWxlXG5cdFx0XHRcdHJlbG9hZERldmljZVNjaGVtYXMoKVxuXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBNb2RlbCAke21vZGVsfSBKU09OIGF1dG8tdXBkYXRlZCBmcm9tIGdldEFsbFNldHRpbmdzYClcblx0XHRcdH0sXG5cdFx0fVxuXHR9IC8vIGVuZCBpc0RldmljZUF1dGhvcml6ZWRcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEFDVElPTlMgKEZJTFRFUkVEIEJZIEFDVElWRSBNT0RFTClcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0Zm9yIChjb25zdCBbYWN0aW9uSWQsIGFjdGlvbl0gb2YgT2JqZWN0LmVudHJpZXMocmF3QWN0aW9ucykpIHtcblx0XHRjb25zdCB7IG1vZGVsLCBjbWRJZCwgYmFzZUlkIH0gPSBwYXJzZVNldHRpbmdJZChhY3Rpb25JZClcblxuXHRcdC8vIE9ubHkgaW5jbHVkZSBhY3Rpb25zIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBtb2RlbFxuXHRcdGlmIChtb2RlbCAhPT0gYWN0aXZlTW9kZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBHZXQgdGhlIHJhdyBhY3Rpb24gc2NoZW1hIHRvIGFjY2VzcyBmaXhlZCBidXNDaCB2YWx1ZVxuXHRcdGNvbnN0IHNjaGVtYSA9IHNjaGVtYXNbbW9kZWxdXG5cdFx0Y29uc3QgcmF3QWN0aW9uID0gc2NoZW1hPy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IGJhc2VJZClcblxuXHRcdHdpcmVkQWN0aW9uc1thY3Rpb25JZF0gPSB7XG5cdFx0XHQuLi5hY3Rpb24sXG5cdFx0XHRjYWxsYmFjazogYXN5bmMgKGV2ZW50OiBhbnkpID0+IHtcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBldmVudC5vcHRpb25zWydidXNDaCddICE9PSB1bmRlZmluZWQgPyBldmVudC5vcHRpb25zWydidXNDaCddIDogcmF3QWN0aW9uPy5idXNDaFxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGV2ZW50Lm9wdGlvbnNbJ3ZhbHVlJ11cblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBldmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblxuXHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5zZW5kQXdhaXRBY2soYWN0aXZlTW9kZWwsIGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgaXApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgTUlDIEtJTEwgKE9OTFkgSUYgQUNUSVZFIE1PREVMIFNVUFBPUlRTIElUKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Y29uc3QgYWN0aXZlU2NoZW1hID0gc2NoZW1hc1thY3RpdmVNb2RlbF1cblx0aWYgKGFjdGl2ZVNjaGVtYSkge1xuXHRcdGNvbnN0IHN1cHBvcnRzTWljS2lsbCA9IChhY3RpdmVTY2hlbWEuY21kU2NoZW1hID8/IFtdKS5zb21lKChhOiBhbnkpID0+IGEubmFtZS5pbmNsdWRlcygnS2lsbCcpKVxuXG5cdFx0aWYgKHN1cHBvcnRzTWljS2lsbCkge1xuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBgJHthY3RpdmVNb2RlbH1fbWljS2lsbGBcblxuXHRcdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7YWN0aXZlTW9kZWx9XSBNaWMgS2lsbGAsXG5cdFx0XHRcdG9wdGlvbnM6IFtdLFxuXHRcdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYE1pYyBLaWxsIFx1MjE5MiBNb2RlbCAke2FjdGl2ZU1vZGVsfSBAICR7aXB9YClcblx0XHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5nbG9iYWxNaWNLaWxsKGFjdGl2ZU1vZGVsLCBpcClcblx0XHRcdFx0fSxcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEFjdGlvbkRlZmluaXRpb25zKHdpcmVkQWN0aW9ucylcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRlQWN0aW9uczogd2lyZWQgYWN0aW9uczogJHtPYmplY3Qua2V5cyh3aXJlZEFjdGlvbnMpLmxlbmd0aH1gKVxufVxuIiwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYSB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9CVVNfU0VULFxuXHRDTURfQ0hBTk5FTCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdGZvcm1hdFJnYkNvbG9yLFxuXHRtb2RlbERpc3RhbmNlLFxufSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1NldHRpbmdzUGFyc2VyJylcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVFlQRVNcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IHR5cGUgUGFyc2VkU2V0dGluZyA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRidXNDaD86IG51bWJlciAvLyBPcHRpb25hbDogb25seSBwcmVzZW50IGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoICgweDA0LCAweDEyLCAweDE0KVxuXHR2YWx1ZUJ5dGVzOiBudW1iZXJbXVxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbk9wdGlvbiA9IHtcblx0aWQ/OiBzdHJpbmdcblx0bGFiZWw6IHN0cmluZ1xuXHR0eXBlOiBzdHJpbmdcblx0ZGVmYXVsdDogdW5rbm93blxuXHR0b29sdGlwPzogc3RyaW5nXG5cdGNob2ljZXM/OiBBcnJheTx7IGlkOiBudW1iZXI7IGxhYmVsOiBzdHJpbmcgfT5cbn1cblxuZXhwb3J0IHR5cGUgU3RBY3Rpb24gPSB7XG5cdGNtZF9pZDogbnVtYmVyXG5cdGlkOiBudW1iZXJcblx0bmFtZTogc3RyaW5nXG5cdG9wdGlvbnM6IFN0QWN0aW9uT3B0aW9uW11cblx0YnVzQ2g/OiBudW1iZXIgLy8gRml4ZWQgY2hhbm5lbCB2YWx1ZSBmb3IgYWN0aW9ucyB0aGF0IGRvbid0IGhhdmUgYSBjaGFubmVsIG9wdGlvblxufVxuXG5leHBvcnQgdHlwZSBTdE1vZGVsSnNvbiA9IHtcblx0bW9kZWw6IHN0cmluZ1xuXHRzZWN0aW9uZWQ/OiBib29sZWFuXG5cdHJlZnJlc2hBZnRlckNvbW1hbmQ/OiBib29sZWFuXG5cdGNtZFNjaGVtYTogU3RBY3Rpb25bXVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGT1JNQVQgSEVMUEVSU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBnZXRNb2RlbENvbmZpZyhtb2RlbDogc3RyaW5nKTogeyBzZWN0aW9uZWQ6IGJvb2xlYW47IHJnYklkczogU2V0PG51bWJlcj4gfSB7XG5cdGNvbnN0IHJnYklkcyA9IG5ldyBTZXQ8bnVtYmVyPigpXG5cdGxldCBzZWN0aW9uZWQgPSBmYWxzZVxuXG5cdHRyeSB7XG5cdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIGluc3RlYWQgb2YgcmVhZGluZyBmcm9tIGRpc2tcblx0XHRjb25zdCBqc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghanNvbikge1xuXHRcdFx0Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgc2NoZW1hLCByZXR1cm4gZGVmYXVsdHNcblx0XHRcdHJldHVybiB7IHNlY3Rpb25lZCwgcmdiSWRzIH1cblx0XHR9XG5cblx0XHQvLyBSZWFkIHNlY3Rpb25lZCBwcm9wZXJ0eSAoZGVmYXVsdCB0byBmYWxzZSBpZiBub3Qgc3BlY2lmaWVkKVxuXHRcdHNlY3Rpb25lZCA9IGpzb24uc2VjdGlvbmVkID8/IGZhbHNlXG5cblx0XHQvLyBCdWlsZCBSR0IgSURzIHNldFxuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHQvLyBBZGQgdGhlIGJhc2UgSURcblx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQpXG5cblx0XHRcdFx0Ly8gSWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkIGNob2ljZXMsIGFkZCBhbGwgdGhlIG9mZnNldCBJRHMgdG9vXG5cdFx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjaG9pY2Ugb2YgaWRBZGRPcHRpb24uY2hvaWNlcykge1xuXHRcdFx0XHRcdFx0aWYgKHR5cGVvZiBjaG9pY2UuaWQgPT09ICdudW1iZXInKSB7XG5cdFx0XHRcdFx0XHRcdHJnYklkcy5hZGQoYWN0aW9uLmlkICsgY2hvaWNlLmlkKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCAoX2Vycikge1xuXHRcdC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHNjaGVtYSwgcmV0dXJuIGRlZmF1bHRzXG5cdH1cblxuXHRyZXR1cm4geyBzZWN0aW9uZWQsIHJnYklkcyB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZJTkQgVEhFIFJFQUwgNUEgUEFZTE9BRCBJTkRFWFxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmOiBCdWZmZXIpOiBudW1iZXIge1xuXHRjb25zdCBzaWdJbmRleCA9IGJ1Zi5pbmRleE9mKEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcpKVxuXHRpZiAoc2lnSW5kZXggPCAwKSB0aHJvdyBuZXcgRXJyb3IoJ05vIFN0dWRpby1UIHNpZ25hdHVyZSBpbiBwYWNrZXQnKVxuXG5cdGNvbnN0IHBheWxvYWRJbmRleCA9IHNpZ0luZGV4ICsgOFxuXHRpZiAoYnVmW3BheWxvYWRJbmRleF0gIT09IDB4NWEpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIDB4NUEgYWZ0ZXIgU3R1ZGlvLVQsIGZvdW5kICR7YnVmW3BheWxvYWRJbmRleF0udG9TdHJpbmcoMTYpfWApXG5cdH1cblxuXHRyZXR1cm4gcGF5bG9hZEluZGV4XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZMQVQgUEFSU0VSXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYmxvY2s6IEJ1ZmZlciwgcmdiSWRzOiBTZXQ8bnVtYmVyPiA9IG5ldyBTZXQoKSk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGxldCBwID0gMFxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0d2hpbGUgKHAgPCBibG9jay5sZW5ndGgpIHtcblx0XHRjb25zdCBpZCA9IGJsb2NrW3BdXG5cdFx0aWYgKHAgKyAxID49IGJsb2NrLmxlbmd0aCkgYnJlYWtcblxuXHRcdC8vIFJHQiBjYXNlIC0gY2hlY2sgaWYgdGhpcyBJRCBpcyBhIGtub3duIGNvbG9ycGlja2VyXG5cdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHAgKyAzIDwgYmxvY2subGVuZ3RoKSB7XG5cdFx0XHRvdXQucHVzaCh7XG5cdFx0XHRcdGNtZF9pZDogQ01EX0RFVl9TUEVDLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXSwgYmxvY2tbcCArIDJdLCBibG9ja1twICsgM11dLFxuXHRcdFx0fSlcblx0XHRcdHAgKz0gNFxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHRvdXQucHVzaCh7IGNtZF9pZDogQ01EX0RFVl9TUEVDLCBpZCwgdmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXV0gfSlcblx0XHRwICs9IDJcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Y29uc3QgYmxvY2tMZW4gPSBidWZbaWR4ICsgMl1cblx0Y29uc3Qgc3RhcnQgPSBpZHggKyAzXG5cdGNvbnN0IGVuZCA9IHN0YXJ0ICsgYmxvY2tMZW5cblx0aWYgKGVuZCA+IGJ1Zi5sZW5ndGgpIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBibG9jayBsZW5ndGgnKVxuXG5cdGNvbnN0IHsgcmdiSWRzIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYnVmLnN1YmFycmF5KHN0YXJ0LCBlbmQpLCByZ2JJZHMpXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNFQ1RJT05FRCBQQVJTRVJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZjogQnVmZmVyLCBtb2RlbDogc3RyaW5nKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgYSBnZXRBbGxTZXR0aW5ncyByZXBseScpXG5cdH1cblxuXHQvLyBDTURfR0VUX0FMTF9TRVRUSU5HUyBoYXMgYSB0b3RhbC1sZW5ndGggYnl0ZSBhdCBpZHgrMiBiZWZvcmUgdGhlIHNlY3Rpb25zOyBDTURfU0VUVElOR1NfUFVTSCBkb2VzIG5vdC5cblx0bGV0IHAgPSBjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgPyBpZHggKyAzIDogaWR4ICsgMlxuXHRjb25zdCBlbmQgPSBidWYubGVuZ3RoIC0gMVxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0Ly8gR2V0IFJHQiBJRHMgZm9yIHRoaXMgbW9kZWxcblx0Y29uc3QgeyByZ2JJZHMgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgaW4gdGhlaXIgc2VjdGlvbiBzdHJ1Y3R1cmVcblx0Y29uc3QgY29tbWFuZHNXaXRoQnVzQ2ggPSBbQ01EX0JVU19TRVQsIENNRF9NSUNfUFJFX0JVUywgQ01EX0NIQU5ORUxdXG5cblx0d2hpbGUgKHAgKyAyIDwgZW5kKSB7XG5cdFx0Y29uc3QgY21kTGVuID0gYnVmW3BdXG5cdFx0Y29uc3Qgc2VjdGlvbkNtZElkID0gYnVmW3AgKyAxXVxuXG5cdFx0Y29uc3Qgc2VjdGlvbkVuZCA9IHAgKyAxICsgY21kTGVuXG5cdFx0aWYgKHNlY3Rpb25FbmQgPiBlbmQpIGJyZWFrXG5cblx0XHQvLyBDaGVjayBpZiB0aGlzIGNvbW1hbmQgaW5jbHVkZXMgYSBidXNDaCBieXRlXG5cdFx0Y29uc3QgaGFzQnVzQ2ggPSBjb21tYW5kc1dpdGhCdXNDaC5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cblx0XHRsZXQgYnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZFxuXHRcdGxldCBkYXRhTGVuOiBudW1iZXJcblx0XHRsZXQgcTogbnVtYmVyXG5cblx0XHRpZiAoaGFzQnVzQ2gpIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRkYXRhTGVuID0gYnVmW3AgKyAzXVxuXHRcdFx0cSA9IHAgKyA0IC8vIERhdGEgc3RhcnRzIGFmdGVyIGNtZExlbiwgY21kSWQsIGJ1c0NoLCBkYXRhTGVuXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbZGF0YUxlbl0gW2lkOnZhbCBwYWlyc11cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDJdXG5cdFx0XHRxID0gcCArIDMgLy8gRGF0YSBzdGFydHMgYWZ0ZXIgY21kTGVuLCBjbWRJZCwgZGF0YUxlblxuXHRcdH1cblxuXHRcdGNvbnN0IHFFbmQgPSBxICsgZGF0YUxlblxuXG5cdFx0d2hpbGUgKHEgKyAxIDwgcUVuZCkge1xuXHRcdFx0Y29uc3QgaWQgPSBidWZbcV1cblx0XHRcdGxldCB2YWx1ZUJ5dGVzOiBudW1iZXJbXVxuXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIElEIGlzIGFuIFJHQiBjb2xvcnBpY2tlciAobmVlZHMgMyBieXRlcylcblx0XHRcdGlmIChyZ2JJZHMuaGFzKGlkKSAmJiBxICsgMyA8IHFFbmQpIHtcblx0XHRcdFx0dmFsdWVCeXRlcyA9IFtidWZbcSArIDFdLCBidWZbcSArIDJdLCBidWZbcSArIDNdXVxuXHRcdFx0XHRxICs9IDRcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXV1cblx0XHRcdFx0cSArPSAyXG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHNldHRpbmc6IFBhcnNlZFNldHRpbmcgPSB7XG5cdFx0XHRcdGNtZF9pZDogc2VjdGlvbkNtZElkLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdHNldHRpbmcuYnVzQ2ggPSBidXNDaFxuXHRcdFx0fVxuXHRcdFx0b3V0LnB1c2goc2V0dGluZylcblx0XHR9XG5cblx0XHRwID0gc2VjdGlvbkVuZFxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBHRU5FUklDIFNFVFRJTkdTIFJFU1BPTlNFIFBBUlNFUiAoMHgwYSBnZXQtYWxsICsgMHgwYiB1bnNvbGljaXRlZCBwdXNoKVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBhbnkgZnVsbCBzZXR0aW5ncyBibG9jayByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhlIGNtZElkIGlzIDB4MGFcbiAqIChyZXNwb25zZSB0byBHZXQgQWxsIFNldHRpbmdzKSBvciAweDBiICh1bnNvbGljaXRlZCBwdXNoIGFmdGVyIGEgc2V0KS5cbiAqIEJvdGggdXNlIHRoZSBzYW1lIHNlY3Rpb25lZCBvciBmbGF0IGJsb2NrIGxheW91dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ3NSZXNwb25zZShtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgTm90IGEgc2V0dGluZ3MgYmxvY2sgKGNtZElkPTB4JHtjbWRJZC50b1N0cmluZygxNil9KWApXG5cdH1cblx0Y29uc3QgeyBzZWN0aW9uZWQgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gc2VjdGlvbmVkID8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbCkgOiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcbn1cblxuLyoqXG4gKiBGb3JtYXRzIGEgc2luZ2xlIHBhcnNlZCBzZXR0aW5nIGludG8gYSBodW1hbi1yZWFkYWJsZSBzdHJpbmcgdXNpbmcgYWN0aW9uXG4gKiBkZWZpbml0aW9ucyBmcm9tIHRoZSBkZXZpY2UgSlNPTi4gRmFsbHMgYmFjayB0byBoZXggSURzIHdoZW4gdW5rbm93bi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZzogUGFyc2VkU2V0dGluZywgYWN0aW9uczogU3RBY3Rpb25bXSk6IHN0cmluZyB7XG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gc2V0dGluZy5jbWRfaWQgJiYgYS5pZCA9PT0gc2V0dGluZy5pZClcblxuXHQvLyBJZiBubyBleGFjdCBtYXRjaCBhbmQgaWQgPiBiYXNlIGlkLCB0cnkgdG8gZmluZCBhY3Rpb24gd2l0aCBpZEFkZCBvcHRpb25cblx0Ly8gVGhpcyBoYW5kbGVzIGNhc2VzIGxpa2UgY21kX2lkIDUgKFBob25lcyBSb3V0aW5nKSBhbmQgY21kX2lkIDcgKEJ1dHRvbnMpXG5cdC8vIHdoZXJlIGlkIDAtMyByZXByZXNlbnRzIGNoYW5uZWxzIDEtNFxuXHRpZiAoIWFjdGlvbikge1xuXHRcdGNvbnN0IGJhc2VBY3Rpb24gPSBhY3Rpb25zLmZpbmQoKGEpID0+IHtcblx0XHRcdGlmIChhLmNtZF9pZCAhPT0gc2V0dGluZy5jbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBhY3Rpb24gaGFzIGFuIGlkQWRkIG9wdGlvbiAoaW5kaWNhdGluZyBjaGFubmVsIHNlbGVjdGlvbilcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYS5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhlIHNldHRpbmcuaWQgb2Zmc2V0IG1hdGNoZXMgb25lIG9mIHRoZSBpZEFkZCBjaG9pY2UgSURzXG5cdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZy5pZCAtIGEuaWRcblx0XHRcdHJldHVybiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGMpID0+IGMuaWQgPT09IGNoYW5uZWxPZmZzZXQpXG5cdFx0fSlcblx0XHRpZiAoYmFzZUFjdGlvbikge1xuXHRcdFx0YWN0aW9uID0gYmFzZUFjdGlvblxuXHRcdH1cblx0fVxuXG5cdGNvbnN0IGNtZEhleCA9IHRvSGV4KHNldHRpbmcuY21kX2lkKVxuXHRjb25zdCBpZEhleCA9IHRvSGV4KHNldHRpbmcuaWQpXG5cdGNvbnN0IHZhbEhleCA9IGJ5dGVzVG9IZXgoc2V0dGluZy52YWx1ZUJ5dGVzKVxuXHRjb25zdCB2YWxEZWMgPVxuXHRcdHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdD8gZm9ybWF0UmdiQ29sb3Ioc2V0dGluZy52YWx1ZUJ5dGVzWzBdLCBzZXR0aW5nLnZhbHVlQnl0ZXNbMV0sIHNldHRpbmcudmFsdWVCeXRlc1syXSlcblx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMVxuXHRcdFx0XHQ/IHNldHRpbmcudmFsdWVCeXRlc1swXVxuXHRcdFx0XHQ6IHNldHRpbmcudmFsdWVCeXRlcy5qb2luKCcsJylcblxuXHQvLyBCdWlsZCB0aGUgcHJlZml4OiBjbWQ6MHgxMiBjaDowIGlkOjB4MDEgdmFsOjB4MTQgKGNoIG9ubHkgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2gpXG5cdGNvbnN0IGJ1c0NoU3RyID0gc2V0dGluZy5idXNDaCAhPT0gdW5kZWZpbmVkID8gYCBjaDoke3NldHRpbmcuYnVzQ2h9YCA6ICcnXG5cdGNvbnN0IHByZWZpeCA9IGBjbWQ6JHtjbWRIZXh9JHtidXNDaFN0cn0gaWQ6JHtpZEhleH0gdmFsOiR7dmFsSGV4fWBcblxuXHQvLyBJZiB3ZSBoYXZlIGFuIGFjdGlvbiB3aXRoIGEgbmFtZSBhbmQgY2hvaWNlIGxhYmVsLCB1c2UgaXRcblx0aWYgKGFjdGlvbikge1xuXHRcdGxldCBuYW1lID0gYWN0aW9uLm5hbWVcblxuXHRcdC8vIElmIHNldHRpbmcgaGFzIGJ1c0NoLCBhZGQgY2hhbm5lbCBpbmZvIHRvIG5hbWVcblx0XHRpZiAoc2V0dGluZy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRuYW1lID0gYCR7bmFtZX0gQ2gke3NldHRpbmcuYnVzQ2ggKyAxfWBcblx0XHR9XG5cdFx0Ly8gT3RoZXJ3aXNlLCBpZiB0aGlzIGFjdGlvbiBoYXMgaWRBZGQsIGluY2x1ZGUgdGhlIGlkQWRkIGxhYmVsXG5cdFx0ZWxzZSB7XG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmIChpZEFkZE9wdGlvbj8uY2hvaWNlcykge1xuXHRcdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZy5pZCAtIGFjdGlvbi5pZFxuXHRcdFx0XHRjb25zdCBpZEFkZENob2ljZSA9IGlkQWRkT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHRcdFx0aWYgKGlkQWRkQ2hvaWNlKSB7XG5cdFx0XHRcdFx0bmFtZSA9IGAke25hbWV9ICR7aWRBZGRDaG9pY2UubGFiZWx9YFxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gTG9vayBmb3IgdGhlIHZhbHVlIG9wdGlvbiAobm90IGJ1c0NoIG9yIGlkQWRkKVxuXHRcdGNvbnN0IHZhbHVlT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAndmFsdWUnKVxuXHRcdGlmICh2YWx1ZU9wdGlvbj8uY2hvaWNlcyAmJiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRjb25zdCBjaG9pY2UgPSB2YWx1ZU9wdGlvbi5jaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHNldHRpbmcudmFsdWVCeXRlc1swXSlcblx0XHRcdGlmIChjaG9pY2UpIHtcblx0XHRcdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke2Nob2ljZS5sYWJlbH0gKCR7dmFsRGVjfSlgXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBgJHtwcmVmaXh9IHwgJHtuYW1lfTogJHt2YWxEZWN9YFxuXHR9XG5cblx0Ly8gTm8gYWN0aW9uIGZvdW5kIC0ganVzdCBzaG93IHRoZSByYXcgdmFsdWVzXG5cdHJldHVybiBgJHtwcmVmaXh9IHwgVW5rbm93biBTZXR0aW5nYFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBQQVJTRVIgRElTUEFUQ0ggV0lUSCBBVVRPLURFVEVDVElPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBnZXRBbGxTZXR0aW5ncyByZXNwb25zZSB3aXRoIGF1dG9tYXRpYyBmb3JtYXQgZGV0ZWN0aW9uLlxuICpcbiAqIFN0cmF0ZWd5OlxuICogMS4gSWYgbW9kZWwgaGFzIGV4cGxpY2l0IFwic2VjdGlvbmVkXCIgcHJvcGVydHksIHVzZSB0aGF0XG4gKiAyLiBPdGhlcndpc2UsIHRyeSBGTEFUIHBhcnNlciBmaXJzdCAoaXQncyBzaW1wbGVyKVxuICogMy4gSWYgRkxBVCByZXR1cm5zIDAgc2V0dGluZ3MsIHRyeSBTRUNUSU9ORUQgcGFyc2VyXG4gKiA0LiBVc2Ugd2hpY2hldmVyIHBhcnNlciByZXR1cm5zIG1vcmUgc2V0dGluZ3NcbiAqXG4gKiBAcmV0dXJucyB7c2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGJvb2xlYW4gfCBudWxsfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24oXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGJ1ZjogQnVmZmVyLFxuKTogeyBzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdOyBkZXRlY3RlZFNlY3Rpb25lZDogYm9vbGVhbiB8IG51bGwgfSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0Y29uc3QgZGVjbGFyZWRTZWN0aW9uZWQgPSBzY2hlbWE/LnNlY3Rpb25lZFxuXG5cdC8vIElmIGV4cGxpY2l0bHkgZGVjbGFyZWQgaW4gSlNPTiwgdXNlIHRoYXRcblx0aWYgKGRlY2xhcmVkU2VjdGlvbmVkICE9PSB1bmRlZmluZWQpIHtcblx0XHRjb25zdCBzZXR0aW5ncyA9IGRlY2xhcmVkU2VjdGlvbmVkXG5cdFx0XHQ/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG5cdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxuXHRcdHJldHVybiB7IHNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9IC8vIG51bGwgPSB1c2VkIGRlY2xhcmVkIHZhbHVlXG5cdH1cblxuXHQvLyBObyBkZWNsYXJhdGlvbiAtIHRyeSBib3RoIHBhcnNlcnMgYW5kIHBpY2sgdGhlIGJlc3Qgb25lXG5cdGxldCBmbGF0U2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cdGxldCBzZWN0aW9uZWRTZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHR0cnkge1xuXHRcdGZsYXRTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBGbGF0IHBhcnNlciBmYWlsZWQ6ICR7ZX1gKVxuXHR9XG5cblx0dHJ5IHtcblx0XHRzZWN0aW9uZWRTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZGVidWcoYFNlY3Rpb25lZCBwYXJzZXIgZmFpbGVkOiAke2V9YClcblx0fVxuXG5cdC8vIFBpY2sgdGhlIHBhcnNlciB0aGF0IHJldHVybmVkIG1vcmUgc2V0dGluZ3Ncblx0aWYgKHNlY3Rpb25lZFNldHRpbmdzLmxlbmd0aCA+IGZsYXRTZXR0aW5ncy5sZW5ndGgpIHtcblx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBTRUNUSU9ORUQgZm9ybWF0IChzZWN0aW9uZWQ9JHtzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGh9IHZzIGZsYXQ9JHtmbGF0U2V0dGluZ3MubGVuZ3RofSlgKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBzZWN0aW9uZWRTZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IHRydWUgfVxuXHR9IGVsc2UgaWYgKGZsYXRTZXR0aW5ncy5sZW5ndGggPiAwKSB7XG5cdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgRkxBVCBmb3JtYXQgKGZsYXQ9JHtmbGF0U2V0dGluZ3MubGVuZ3RofSB2cyBzZWN0aW9uZWQ9JHtzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGh9KWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IGZsYXRTZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGZhbHNlIH1cblx0fSBlbHNlIHtcblx0XHQvLyBCb3RoIHBhcnNlcnMgcmV0dXJuZWQgMCBzZXR0aW5nc1xuXHRcdGxvZ2dlci53YXJuKGBXYXJuaW5nOiBCb3RoIHBhcnNlcnMgcmV0dXJuZWQgMCBzZXR0aW5ncyBmb3IgbW9kZWwgJHttb2RlbH1gKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfVxuXHR9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwobW9kZWw6IHN0cmluZywgYnVmOiBCdWZmZXIpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCB7IHNlY3Rpb25lZCB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cdHJldHVybiBzZWN0aW9uZWQgPyBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKSA6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxufVxuXG4vKiBcdTI3MDUgYmFja3dhcmQtY29tcGF0aWJsZSBleHBvcnQgKi9cbmV4cG9ydCBjb25zdCBwYXJzZUdldEFsbFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFZBTFVFIFx1MjE5MiBPUFRJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXM6IG51bWJlcltdKTogU3RBY3Rpb25PcHRpb24ge1xuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdudW1iZXInLCBkZWZhdWx0OiB2YWx1ZUJ5dGVzWzBdIH1cblx0fVxuXG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMykge1xuXHRcdGNvbnN0IFtyLCBnLCBiXSA9IHZhbHVlQnl0ZXNcblx0XHRyZXR1cm4ge1xuXHRcdFx0aWQ6ICd2YWx1ZScsXG5cdFx0XHRsYWJlbDogJ0NvbG9yJyxcblx0XHRcdHR5cGU6ICdjb2xvcnBpY2tlcicsXG5cdFx0XHRkZWZhdWx0OiBmb3JtYXRSZ2JDb2xvcihyLCBnLCBiKSxcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdyYXcnLCBkZWZhdWx0OiBbLi4udmFsdWVCeXRlc10gfVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTTUFSVCBKU09OIFVQREFURVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKFxuXHRtb2RlbEpzb246IFN0TW9kZWxKc29uLFxuXHRwYXJzZWQ6IFBhcnNlZFNldHRpbmdbXSxcblx0YWxsTW9kZWxzOiBSZWNvcmQ8c3RyaW5nLCBTdE1vZGVsSnNvbj4sXG4pOiBTdE1vZGVsSnNvbiB7XG5cdGNvbnN0IG91dCA9IHN0cnVjdHVyZWRDbG9uZShtb2RlbEpzb24pXG5cblx0Ly8gRW5zdXJlIGNtZFNjaGVtYSBhcnJheSBleGlzdHNcblx0aWYgKCFvdXQuY21kU2NoZW1hKSB7XG5cdFx0b3V0LmNtZFNjaGVtYSA9IFtdXG5cdH1cblxuXHQvLyBTb3J0IG90aGVyIG1vZGVscyBieSBudW1lcmljIGRpc3RhbmNlIHRvIGN1cnJlbnQgbW9kZWxcblx0Y29uc3QgY2FuZGlkYXRlcyA9IE9iamVjdC52YWx1ZXMoYWxsTW9kZWxzKVxuXHRcdC5maWx0ZXIoKG0pID0+IG0ubW9kZWwgIT09IG1vZGVsSnNvbi5tb2RlbCkgLy8gZXhjbHVkZSBzZWxmXG5cdFx0LnNvcnQoKGEsIGIpID0+IG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBhLm1vZGVsKSAtIG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBiLm1vZGVsKSlcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRpbmcgbW9kZWw6ICR7bW9kZWxKc29uLm1vZGVsfWApXG5cdGxvZ2dlci5kZWJ1ZyhgQ2FuZGlkYXRlcyBmb3IgaW5mZXJlbmNlOiAke2NhbmRpZGF0ZXMubWFwKChjKSA9PiBjLm1vZGVsKS5qb2luKCcsICcpfWApXG5cblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQsIHZhbHVlQnl0ZXMgfSBvZiBwYXJzZWQpIHtcblx0XHRsZXQgYWN0aW9uID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXG5cdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdC8vIFRyeSBjYW5kaWRhdGVzIGluIG9yZGVyIG9mIHByb3hpbWl0eVxuXHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0Y29uc3QgbWF0Y2ggPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZClcblx0XHRcdFx0aWYgKG1hdGNoKSB7XG5cdFx0XHRcdFx0YWN0aW9uID0gc3RydWN0dXJlZENsb25lKG1hdGNoKVxuXHRcdFx0XHRcdGFjdGlvbi5uYW1lID0gYCR7bWF0Y2gubmFtZX0gKGluZmVycmVkIGZyb20gTW9kZWwgJHtjLm1vZGVsfSlgXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYEluZmVycmVkIHNldHRpbmcgJHt0b0hleChpZCl9IGZyb20gTW9kZWwgJHtjLm1vZGVsfWApXG5cdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSB7XG5cdFx0XHRcdGNtZF9pZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdG5hbWU6IGBVbmtub3duIFNldHRpbmcgJHt0b0hleChpZCkudG9VcHBlckNhc2UoKX1gLFxuXHRcdFx0XHRvcHRpb25zOiBbdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpXSxcblx0XHRcdH1cblx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgaW5mZXIgc2V0dGluZyAke3RvSGV4KGlkKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCBvcHQgPSBhY3Rpb24ub3B0aW9ucz8uWzBdXG5cdFx0XHRpZiAob3B0KSBvcHQuZGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cdFx0fVxuXG5cdFx0Ly8gQXZvaWQgZHVwbGljYXRlc1xuXHRcdGNvbnN0IGV4aXN0cyA9IG91dC5jbWRTY2hlbWEuc29tZSgoYSkgPT4gYS5jbWRfaWQgPT09IGFjdGlvbi5jbWRfaWQgJiYgYS5pZCA9PT0gYWN0aW9uLmlkKVxuXHRcdGlmICghZXhpc3RzKSBvdXQuY21kU2NoZW1hLnB1c2goYWN0aW9uKVxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTQVZFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBzYXZlTW9kZWxKc29uUHJldHR5KGZpbGVQYXRoOiBzdHJpbmcsIGpzb25PYmo6IFN0TW9kZWxKc29uKTogdm9pZCB7XG5cdHRyeSB7XG5cdFx0Ly8gRW5zdXJlIHByb3BlciBrZXkgb3JkZXJpbmc6IG1vZGVsLCBzZWN0aW9uZWQgKGlmIHByZXNlbnQpLCByZWZyZXNoQWZ0ZXJDb21tYW5kLCBjbWRTY2hlbWFcblx0XHRjb25zdCBvcmRlcmVkT2JqOiBhbnkgPSB7IG1vZGVsOiBqc29uT2JqLm1vZGVsIH1cblxuXHRcdC8vIEFkZCBzZWN0aW9uZWQga2V5IGlmIHByZXNlbnQgKHJpZ2h0IGFmdGVyIG1vZGVsKVxuXHRcdGlmICgnc2VjdGlvbmVkJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLnNlY3Rpb25lZCA9IGpzb25PYmouc2VjdGlvbmVkXG5cdFx0fVxuXG5cdFx0Ly8gQWRkIG90aGVyIGtleXMgaW4gb3JkZXJcblx0XHRpZiAoJ3JlZnJlc2hBZnRlckNvbW1hbmQnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmoucmVmcmVzaEFmdGVyQ29tbWFuZCA9IGpzb25PYmoucmVmcmVzaEFmdGVyQ29tbWFuZFxuXHRcdH1cblx0XHRpZiAoJ2NtZFNjaGVtYScgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5jbWRTY2hlbWEgPSBqc29uT2JqLmNtZFNjaGVtYVxuXHRcdH1cblx0XHQvLyBDb3B5IGFueSBvdGhlciBrZXlzIHRoYXQgbWlnaHQgZXhpc3Rcblx0XHRmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhqc29uT2JqKSkge1xuXHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRPYmopKSB7XG5cdFx0XHRcdG9yZGVyZWRPYmpba2V5XSA9IChqc29uT2JqIGFzIGFueSlba2V5XVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIEN1c3RvbSBmb3JtYXR0ZXI6IGtlZXAgY2hvaWNlIG9iamVjdHMgY29tcGFjdCBvbiBvbmUgbGluZVxuXHRcdGxldCBqc29uID0gSlNPTi5zdHJpbmdpZnkob3JkZXJlZE9iaiwgbnVsbCwgMilcblxuXHRcdC8vIFJlcGxhY2UgZXhwYW5kZWQgY2hvaWNlIG9iamVjdHMgd2l0aCBjb21wYWN0IHNpbmdsZS1saW5lIGZvcm1hdFxuXHRcdC8vIE1hdGNoZXM6IHtcXG4gICAgICAgICAgICBcImlkXCI6IFgsXFxuICAgICAgICAgICAgXCJsYWJlbFwiOiBcIllcIlxcbiAgICAgICAgICB9XG5cdFx0Ly8gUmVwbGFjZXMgd2l0aDogeyBcImlkXCI6IFgsIFwibGFiZWxcIjogXCJZXCIgfVxuXHRcdGpzb24gPSBqc29uLnJlcGxhY2UoL1xce1xcblxccytcImlkXCI6XFxzKihcXGQrKSxcXG5cXHMrXCJsYWJlbFwiOlxccypcIihbXlwiXSopXCJcXG5cXHMrXFx9L2csICd7IFwiaWRcIjogJDEsIFwibGFiZWxcIjogXCIkMlwiIH0nKVxuXG5cdFx0ZnMud3JpdGVGaWxlU3luYyhmaWxlUGF0aCwganNvbiArICdcXG4nLCAndXRmOCcpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZXJyb3IoYEZpbGUgV3JpdGUgRXJyb3I6ICR7ZX1gKVxuXHR9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIExPQUQgREVWSUNFIEpTT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBMb2FkcyB0aGUgYWN0aW9ucyBhcnJheSBmb3IgYSBnaXZlbiBtb2RlbCBmcm9tIHRoZSBjZW50cmFsaXplZCBjYWNoZS5cbiAqIFJldHVybnMgYW4gZW1wdHkgYXJyYXkgaWYgdGhlIG1vZGVsIGlzIG5vdCBmb3VuZC5cbiAqIEBkZXByZWNhdGVkIC0gVGhpcyBmdW5jdGlvbiBpcyBubyBsb25nZXIgbmVlZGVkLiBVc2UgZ2V0RGV2aWNlU2NoZW1hKCkgZnJvbSBjb25maWcudHMgaW5zdGVhZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxvYWRBY3Rpb25zRm9yTW9kZWwoX2RldmljZXNGb2xkZXI6IHN0cmluZywgbW9kZWw6IHN0cmluZyk6IFN0QWN0aW9uW10ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdHJldHVybiBzY2hlbWE/LmNtZFNjaGVtYSA/PyBbXVxufVxuXG4vKipcbiAqIExvYWRzIHRoZSBtb2RlbCBjb25maWd1cmF0aW9uIGZyb20gdGhlIGNlbnRyYWxpemVkIGNhY2hlLlxuICogQGRlcHJlY2F0ZWQgLSBUaGlzIGZ1bmN0aW9uIGlzIG5vIGxvbmdlciBuZWVkZWQuIFVzZSBnZXREZXZpY2VTY2hlbWEoKSBmcm9tIGNvbmZpZy50cyBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZE1vZGVsQ29uZmlnKFxuXHRfZGV2aWNlc0ZvbGRlcjogc3RyaW5nLFxuXHRtb2RlbDogc3RyaW5nLFxuKTogeyBhY3Rpb25zOiBTdEFjdGlvbltdOyByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuIH0ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdHJldHVybiB7XG5cdFx0YWN0aW9uczogc2NoZW1hPy5jbWRTY2hlbWEgPz8gW10sXG5cdFx0cmVmcmVzaEFmdGVyQ29tbWFuZDogc2NoZW1hPy5yZWZyZXNoQWZ0ZXJDb21tYW5kID8/IHRydWUsIC8vIERlZmF1bHQgdG8gdHJ1ZSBpZiBub3Qgc3BlY2lmaWVkXG5cdH1cbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRGZWVkYmFja3MgfSBmcm9tICcuL2J1aWxkLWNvbW1hbmRzLmpzJ1xuaW1wb3J0IHsgcmVzb2x2ZU1vZGVsLCBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMsIGZpbmRBY3Rpb25Gb3JTZXR0aW5nIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRmVlZGJhY2tzJylcblxuLyoqXG4gKiBIZWxwZXIgZnVuY3Rpb24gdG8gZ2V0IGxhYmVsIGZyb20gY2hvaWNlcyBiYXNlZCBvbiB2YWx1ZVxuICovXG5mdW5jdGlvbiBnZXRMYWJlbEZvclZhbHVlKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuXHR2YWx1ZTogbnVtYmVyLFxuKTogc3RyaW5nIHwgbnVtYmVyIHtcblx0Y29uc3Qgc2V0dGluZyA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRpZiAoIXNldHRpbmcgfHwgIUFycmF5LmlzQXJyYXkoc2V0dGluZy5vcHRpb25zKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgJ3ZhbHVlJyBvcHRpb24gd2hpY2ggY29udGFpbnMgdGhlIGNob2ljZXNcblx0Y29uc3QgdmFsdWVPcHRpb24gPSBzZXR0aW5nLm9wdGlvbnMuZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0aWYgKCF2YWx1ZU9wdGlvbiB8fCAhQXJyYXkuaXNBcnJheSh2YWx1ZU9wdGlvbi5jaG9pY2VzKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgY2hvaWNlIHdpdGggbWF0Y2hpbmcgaWRcblx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjOiBhbnkpID0+IGMuaWQgPT09IHZhbHVlKVxuXHRyZXR1cm4gY2hvaWNlPy5sYWJlbCA/PyB2YWx1ZVxufVxuXG4vKipcbiAqIEJ1aWxkIGFuZCB3aXJlIENvbXBhbmlvbiBmZWVkYmFjayBkZWZpbml0aW9uc1xuICogUGF0dGVybiBtYXRjaGVzIGFjdGlvbnMudHMgLSBmaWx0ZXJzIGJ5IGFjdGl2ZSBtb2RlbCBhbmQgd2lyZXMgY2FsbGJhY2tzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVGZWVkYmFja3Moc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdGZWVkYmFja3MgPSBidWlsZEZlZWRiYWNrcygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEZlZWRiYWNrczogYW55ID0ge31cblxuXHQvLyBHZXQgdGhlIGFjdGl2ZSBtb2RlbCB1c2luZyByZXNvbHZlTW9kZWxcblx0Y29uc3QgYWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwoc2VsZi5jb25maWcsIHNlbGYuZGV2aWNlcylcblx0bG9nZ2VyLmluZm8oXG5cdFx0YFVwZGF0ZUZlZWRiYWNrczogYWN0aXZlTW9kZWw9XCIke2FjdGl2ZU1vZGVsfVwiLCBkaXNjb3ZlcmVkSG9zdD1cIiR7c2VsZi5jb25maWcuZGlzY292ZXJlZEhvc3R9XCIsIGRldmljZXMgY291bnQ9JHtzZWxmLmRldmljZXMubGVuZ3RofWAsXG5cdClcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEZFRURCQUNLUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFtmZWVkYmFja0lkLCBmZWVkYmFja10gb2YgT2JqZWN0LmVudHJpZXMocmF3RmVlZGJhY2tzKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGZlZWRiYWNrSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgZmVlZGJhY2tzIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBtb2RlbFxuXHRcdGlmIChtb2RlbCAhPT0gYWN0aXZlTW9kZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBWQUxVRSBGRUVEQkFDSzogUmV0dXJucyBjdXJyZW50IHZhbHVlIGZvciBsb2NhbCB2YXJpYWJsZVxuXHRcdHdpcmVkRmVlZGJhY2tzW2ZlZWRiYWNrSWRdID0ge1xuXHRcdFx0Li4uZmVlZGJhY2ssXG5cdFx0XHRjYWxsYmFjazogKGZlZWRiYWNrRXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snYnVzQ2gnXVxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cdFx0XHRcdGNvbnN0IGN1cnJlbnQgPSBzZWxmLnN0Q29udHJvbGxlci5nZXRTZXR0aW5nVmFsdWUoaXAsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXG5cdFx0XHRcdC8vIENoZWNrIGlmIHVzZXIgd2FudHMgbGFiZWwgaW5zdGVhZCBvZiBudW1lcmljIHZhbHVlXG5cdFx0XHRcdGNvbnN0IHNob3dMYWJlbCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snc2hvd0xhYmVsJ10gPz8gZmFsc2VcblxuXHRcdFx0XHRpZiAoc2hvd0xhYmVsICYmIGN1cnJlbnQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdC8vIFJldHVybiB0aGUgbGFiZWwgZnJvbSBjaG9pY2VzXG5cdFx0XHRcdFx0cmV0dXJuIGdldExhYmVsRm9yVmFsdWUoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQsIGN1cnJlbnQpXG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBSZXR1cm4gbnVtZXJpYyB2YWx1ZSBkaXJlY3RseSBmb3IgbG9jYWwgdmFyaWFibGUgKHR5cGU6ICd2YWx1ZScpXG5cdFx0XHRcdHJldHVybiBjdXJyZW50ID8/IDBcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0c2VsZi5zZXRGZWVkYmFja0RlZmluaXRpb25zKHdpcmVkRmVlZGJhY2tzKVxuXG5cdGxvZ2dlci5pbmZvKGBVcGRhdGVGZWVkYmFja3M6IHdpcmVkIGZlZWRiYWNrczogJHtPYmplY3Qua2V5cyh3aXJlZEZlZWRiYWNrcykubGVuZ3RofWApXG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9CVVNfR0VULFxuXHRDTURfQlVTX1NFVCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX0dFVF9GSVJNV0FSRSxcblx0Q01EX0dMT0JBTF9NSUNfS0lMTCxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfUkVTRVRfREVWSUNFLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0Z2V0Q29tbWFuZE5hbWUsXG5cdG1ha2VTZXR0aW5nSWQsXG5cdHRvSGV4LFxuXHRieXRlc1RvSGV4LFxuXHR0eXBlIERldmljZUluZm8sXG59IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQge1xuXHRwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwsXG5cdHBhcnNlU2V0dGluZ3NSZXNwb25zZSxcblx0Zm9ybWF0UGFyc2VkU2V0dGluZyxcblx0dHlwZSBTdEFjdGlvbixcbn0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcbmltcG9ydCB7XG5cdERBTlRFX01TR19JTkZPX1JFU1BPTlNFLFxuXHRwYXJzZURhbnRlSW5mb1Jlc3BvbnNlLFxuXHRkaXNjb3ZlckRldmljZXMsXG5cdGJ1aWxkRGFudGVJbmZvUmVxdWVzdCxcblx0Z2V0TWFjRm9yRGVzdGluYXRpb24sXG5cdGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uLFxufSBmcm9tICcuL2RhbnRlLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1N0Q29udHJvbGxlcicpXG5cbmV4cG9ydCBjbGFzcyBTdENvbnRyb2xsZXIge1xuXHRwcml2YXRlIHJlYWRvbmx5IGRlZmF1bHRQb3J0OiBudW1iZXIgPSA4NzAwXG5cdHByaXZhdGUgcmVhZG9ubHkgbXVsdGljYXN0R3JvdXAgPSAnMjI0LjAuMC4yMzEnXG5cdHByaXZhdGUgcmVhZG9ubHkgcnhQb3J0ID0gODcwMlxuXG5cdHByaXZhdGUgdHhTb2NrZXQ6IGRncmFtLlNvY2tldFxuXHRwcml2YXRlIHJ4U29ja2V0OiBkZ3JhbS5Tb2NrZXQgLy8gZm9yIHJlY2VpdmluZyByZXNwb25zZXMgKDg3MDIpXG5cdHByaXZhdGUgcGVuZGluZ0Fja3M6IE1hcDxcblx0XHRzdHJpbmcsXG5cdFx0eyByZXNvbHZlOiAoYnVmOiBCdWZmZXIpID0+IHZvaWQ7IHJlamVjdDogKGU6IEVycm9yKSA9PiB2b2lkOyB0aW1lcjogTm9kZUpTLlRpbWVvdXQgfVxuXHQ+XG5cdHByaXZhdGUgam9pbmVkSW50ZXJmYWNlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KCkgLy8gbG9jYWwgSVBzIHdlJ3ZlIGpvaW5lZCBtdWx0aWNhc3Qgb25cblxuXHQvKiogU2VyaWFsaXplcyBvdXRnb2luZyBjb21tYW5kcyBzbyBlYWNoIHdhaXRzIGZvciBBQ0sgYmVmb3JlIHRoZSBuZXh0IGlzIHNlbnQgKi9cblx0cHJpdmF0ZSBzZW5kUXVldWU6IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKVxuXG5cdC8qKiBUcmFja3MgaG93IG1hbnkgY29tbWFuZHMgYXJlIHF1ZXVlZC9pbi1mbGlnaHQsIHRvIGRlZmVyIHJlcXVlc3RBbGxTZXR0aW5ncyAqL1xuXHRwcml2YXRlIHBlbmRpbmdDb21tYW5kQ291bnQgPSAwXG5cblx0LyoqIFJlc29sdmVzIG9uY2UgdHhTb2NrZXQgaXMgYm91bmQgYW5kIHJlYWR5IHRvIHNlbmQgKi9cblx0cHJpdmF0ZSB0eFJlYWR5OiBQcm9taXNlPHZvaWQ+XG5cblx0LyoqIEFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBmb3Igc2V0dGluZ3MgZGVjb2RpbmcgKi9cblx0cHJpdmF0ZSBtb2RlbDogc3RyaW5nID0gJydcblx0cHJpdmF0ZSBhY3Rpb25zOiBTdEFjdGlvbltdID0gW11cblx0cHJpdmF0ZSByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuID0gdHJ1ZSAvLyBEZWZhdWx0IHRvIHRydWUgKG1vc3QgZGV2aWNlcyBuZWVkIGl0KVxuXG5cdC8qKlxuXHQgKiBLbm93biBzdGF0ZSBvZiBldmVyeSBzZXR0aW5nIHBlciBkZXZpY2UgSVAuXG5cdCAqIEtleWVkIGJ5IElQIFx1MjE5MiBNYXAgb2YgXCIke2NtZElkfS8ke3NldHRpbmdJZH1cIiBcdTIxOTIgY3VycmVudCB2YWx1ZSBieXRlLlxuXHQgKiBQb3B1bGF0ZWQgb24gY29ubmVjdCB2aWEgcmVxdWVzdEFsbFNldHRpbmdzKCksIHVwZGF0ZWQgb24gZXZlcnkgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpLlxuXHQgKiBVc2VkIHRvIGRpZmYgaW5jb21pbmcgcHVzaGVzIChjaGFuZ2VkID0gaW5mbywgdW5jaGFuZ2VkID0gZGVidWcpIGFuZCBmb3IgZmVlZGJhY2tzLlxuXHQgKi9cblx0cHJpdmF0ZSBkZXZpY2VTdGF0ZTogTWFwPHN0cmluZywgTWFwPHN0cmluZywgbnVtYmVyPj4gPSBuZXcgTWFwKClcblxuXHQvKipcblx0ICogSVBzIHRoYXQgaGF2ZSBiZWVuIHZlcmlmaWVkIGFnYWluc3QgdGhlIGNvbmZpZ3VyZWQgbW9kZWwgYW5kIGFyZSBhbGxvd2VkXG5cdCAqIHRvIHJlY2VpdmUgU3R1ZGlvLVQgY29tbWFuZHMuIFBvcHVsYXRlZCBieSBhdXRob3JpemVEZXZpY2UoKSBhZnRlciBhXG5cdCAqIHN1Y2Nlc3NmdWwgcHJvYmVEZXZpY2UoKSBtb2RlbCBtYXRjaCwgb3IgYWZ0ZXIgbXVsdGljYXN0IGRpc2NvdmVyeS5cblx0ICogX3NlbmRBd2FpdEFjaygpIHJlamVjdHMgYW55IGRlc3RJcCBub3QgaW4gdGhpcyBzZXQuXG5cdCAqL1xuXHRwcml2YXRlIGF1dGhvcml6ZWRJcHM6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpXG5cblx0LyoqIENhbGxiYWNrcyByZWdpc3RlcmVkIGJ5IGRpc2NvdmVyRGV2aWNlcygpIFx1MjAxNCBrZXllZCBieSBzb3VyY2UgSVAgKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcnlMaXN0ZW5lcnM6IE1hcDxzdHJpbmcsIChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQ+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrIHRvIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlcyB3aGVuIHN0YXRlIGNoYW5nZXMgKi9cblx0cHJpdmF0ZSBmZWVkYmFja0NhbGxiYWNrPzogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZFxuXG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdGxvZ2dlci5pbmZvKCdTdENvbnRyb2xsZXIgaW5pdGlhbGl6ZWQnKVxuXG5cdFx0dGhpcy5wZW5kaW5nQWNrcyA9IG5ldyBNYXAoKVxuXG5cdFx0Ly8gU2VuZCBzb2NrZXQgXHUyMDE0IGJpbmQgdG8gZXBoZW1lcmFsIHBvcnQuIFJlc3BvbnNlcyBhbHdheXMgZ28gdG8gcnhTb2NrZXQgb25cblx0XHQvLyBwb3J0IDg3MDIgKERhbnRlIGhhcmRjb2RlcyB0aGUgcmVzcG9uc2UgZGVzdGluYXRpb24gcG9ydCB0byA4NzAyKS5cblx0XHR0aGlzLnR4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnR4UmVhZHkgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0dGhpcy50eFNvY2tldC5iaW5kKDAsICgpID0+IHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBUWCBzb2NrZXQgYm91bmQgdG8gcG9ydCAkeyh0aGlzLnR4U29ja2V0LmFkZHJlc3MoKSBhcyB7IHBvcnQ6IG51bWJlciB9KS5wb3J0fWApXG5cdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdHRoaXMudHhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBUWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdC8vIFJlY2VpdmUgc29ja2V0IC0gYmluZCB0byBhbGwgYWRkcmVzc2VzIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0c1xuXHRcdHRoaXMucnhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbGlzdGVuaW5nJywgKCkgPT4ge1xuXHRcdFx0Y29uc3QgYWRkciA9IHRoaXMucnhTb2NrZXQuYWRkcmVzcygpXG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBsaXN0ZW5pbmcgb24gJHtKU09OLnN0cmluZ2lmeShhZGRyKX1gKVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5zZXRNdWx0aWNhc3RMb29wYmFjayh0cnVlKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBSWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5oYW5kbGVJbmNvbWluZyhtc2csIHJpbmZvLmFkZHJlc3MpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoYEVycm9yIGhhbmRsaW5nIGluY29taW5nIG1lc3NhZ2U6ICR7X2V9YClcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gQmluZCB0byB3aWxkY2FyZCBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHMgZm9yIGpvaW5lZCBpbnRlcmZhY2VzXG5cdFx0dGhpcy5yeFNvY2tldC5iaW5kKHsgYWRkcmVzczogJzAuMC4wLjAnLCBwb3J0OiB0aGlzLnJ4UG9ydCB9LCAoKSA9PiB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBib3VuZCB0byAwLjAuMC4wOiR7dGhpcy5yeFBvcnR9YClcblx0XHR9KVxuXHR9XG5cblx0cHVibGljIGNsb3NlKCk6IHZvaWQge1xuXHRcdHRyeSB7XG5cdFx0XHRmb3IgKGNvbnN0IGxvY2FsQWRkciBvZiBBcnJheS5mcm9tKHRoaXMuam9pbmVkSW50ZXJmYWNlcykpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR0aGlzLnJ4U29ja2V0LmRyb3BNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy5yeFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFByb3ZpZGUgdGhlIGFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBzbyBpbmNvbWluZyBtZXNzYWdlc1xuXHQgKiBjYW4gYmUgZGVjb2RlZCBpbnRvIGh1bWFuLXJlYWRhYmxlIG5hbWVzLiBDYWxsIGZyb20gbWFpbi50cyBhZnRlciBjb25maWcgbG9hZC5cblx0ICovXG5cdHB1YmxpYyBzZXRNb2RlbChtb2RlbDogc3RyaW5nLCBhY3Rpb25zOiBTdEFjdGlvbltdLCByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xuXHRcdHRoaXMubW9kZWwgPSBtb2RlbFxuXHRcdHRoaXMuYWN0aW9ucyA9IGFjdGlvbnNcblx0XHR0aGlzLnJlZnJlc2hBZnRlckNvbW1hbmQgPSByZWZyZXNoQWZ0ZXJDb21tYW5kXG5cdH1cblxuXHQvKipcblx0ICogU2V0IGNhbGxiYWNrIHRvIHRyaWdnZXIgd2hlbiBkZXZpY2Ugc3RhdGUgY2hhbmdlcyAoZm9yIGZlZWRiYWNrcykuXG5cdCAqIENhbGwgZnJvbSBtYWluLnRzIHRvIHdpcmUgdXAgY2hlY2tGZWVkYmFja3MuXG5cdCAqL1xuXHRwdWJsaWMgc2V0RmVlZGJhY2tDYWxsYmFjayhjYWxsYmFjazogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZCk6IHZvaWQge1xuXHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayA9IGNhbGxiYWNrXG5cdH1cblxuXHQvKiogUmV0dXJucyB0cnVlIGlmIHRoZSBkZXZpY2UgYXQgdGhlIGdpdmVuIElQIGhhcyBiZWVuIGF1dGhvcml6ZWQgdG8gcmVjZWl2ZSBjb21tYW5kcy4gKi9cblx0cHVibGljIGlzRGV2aWNlQXV0aG9yaXplZChpcDogc3RyaW5nKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuYXV0aG9yaXplZElwcy5oYXMoaXApXG5cdH1cblxuXHQvKiogTWFyayBhbiBJUCBhcyB2ZXJpZmllZCBhbmQgYWxsb3dlZCB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgYXV0aG9yaXplRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuYWRkKGlwKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgQXV0aG9yaXplZCBkZXZpY2UgYXQgJHtpcH1gKVxuXHR9XG5cblx0LyoqIFJlbW92ZSBhdXRob3JpemF0aW9uIGZvciBhbiBJUCAoZS5nLiBvbiBjb25maWcgY2hhbmdlIG9yIG1vZGVsIG1pc21hdGNoKS4gKi9cblx0cHVibGljIHJldm9rZURldmljZShpcDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hdXRob3JpemVkSXBzLmRlbGV0ZShpcClcblx0XHR0aGlzLmRldmljZVN0YXRlLmRlbGV0ZShpcClcblx0XHRsb2dnZXIuZGVidWcoYFJldm9rZWQgZGV2aWNlIGF0ICR7aXB9YClcblx0fVxuXG5cdC8qKlxuXHQgKiBTZW5kcyBhIHVuaWNhc3QgRGFudGUgaW5mbyByZXF1ZXN0IHRvIGEgc3BlY2lmaWMgSVAgYW5kIHdhaXRzIGZvciB0aGVcblx0ICogZGV2aWNlIGluZm8gcmVzcG9uc2UuIFJldHVybnMgdGhlIERldmljZUluZm8gaWYgdGhlIGRldmljZSByZXNwb25kcyB3aXRoaW5cblx0ICogdGltZW91dE1zLCBvciBudWxsIGlmIG5vIHJlc3BvbnNlLiBVc2VkIHRvIHZlcmlmeSBhIG1hbnVhbGx5IGNvbmZpZ3VyZWQgSVAuXG5cdCAqIERvZXMgTk9UIHJlcXVpcmUgYXV0aG9yaXphdGlvbiBcdTIwMTQgdGhpcyBpcyBob3cgYXV0aG9yaXphdGlvbiBpcyBlc3RhYmxpc2hlZC5cblx0ICovXG5cdHB1YmxpYyBhc3luYyBwcm9iZURldmljZShpcDogc3RyaW5nLCB0aW1lb3V0TXMgPSAzMDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4oKHJlc29sdmUpID0+IHtcblx0XHRcdGNvbnN0IGtleSA9IGBfX3Byb2JlXyR7aXB9X19gXG5cdFx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXG5cdFx0XHRjb25zdCBmaW5pc2ggPSAocmVzdWx0OiBEZXZpY2VJbmZvIHwgbnVsbCkgPT4ge1xuXHRcdFx0XHRpZiAocmVzb2x2ZWQpIHJldHVyblxuXHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKGtleSlcblx0XHRcdFx0cmVzb2x2ZShyZXN1bHQpXG5cdFx0XHR9XG5cblx0XHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChrZXksIChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdFx0aWYgKGRldmljZS5pcCA9PT0gaXApIGZpbmlzaChkZXZpY2UpXG5cdFx0XHR9KVxuXG5cdFx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gZmluaXNoKG51bGwpLCB0aW1lb3V0TXMpXG5cdFx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdFx0dGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGlwKVxuXHRcdFx0XHQudGhlbihhc3luYyAoKSA9PiB0aGlzLnR4UmVhZHkpXG5cdFx0XHRcdC50aGVuKCgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBxdWVyeSA9IGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpXG5cdFx0XHRcdFx0dGhpcy50eFNvY2tldC5zZW5kKHF1ZXJ5LCB0aGlzLmRlZmF1bHRQb3J0LCBpcCwgKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgUHJvYmUgdG8gJHtpcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRcdFx0ZmluaXNoKG51bGwpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSlcblx0XHRcdFx0LmNhdGNoKChlKSA9PiB7XG5cdFx0XHRcdFx0bG9nZ2VyLndhcm4oYHByb2JlRGV2aWNlIHNldHVwIGZhaWxlZCBmb3IgJHtpcH06ICR7ZX1gKVxuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRmaW5pc2gobnVsbClcblx0XHRcdFx0fSlcblx0XHR9KVxuXHR9XG5cblx0LyoqXG5cdCAqIFNlbmQgYSBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgcmVxdWVzdCB0byB0aGUgZGV2aWNlIGFuZCBzdG9yZSB0aGUgcmVzcG9uc2Vcblx0ICogaW4gZGV2aWNlU3RhdGUuIFJldHVybnMgdGhlIHJhdyByZXNwb25zZSBidWZmZXIgZm9yIHBhcnNpbmcuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEFsbFNldHRpbmdzKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGxvZ2dlci5pbmZvKGBSZXF1ZXN0aW5nIGFsbCBzZXR0aW5ncyBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKFxuXHRcdFx0dGhpcy5tb2RlbCxcblx0XHRcdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRcdFx0dW5kZWZpbmVkLFxuXHRcdFx0dW5kZWZpbmVkLFxuXHRcdFx0dW5kZWZpbmVkLFxuXHRcdFx0ZGV2aWNlSXAsXG5cdFx0XHRmYWxzZSxcblx0XHQpXG5cdFx0Ly8gZGV2aWNlU3RhdGUgaXMgcG9wdWxhdGVkIGJ5IGxvZ1N0UGF5bG9hZCB3aGVuIHRoZSBDTURfR0VUX0FMTF9TRVRUSU5HUyByZXNwb25zZSBhcnJpdmVzXG5cdFx0cmV0dXJuIHJlc3BvbnNlXG5cdH1cblxuXHQvKiogUmV0dXJuIGEgc25hcHNob3Qgb2YgdGhlIGN1cnJlbnQgZGV2aWNlIHN0YXRlIGZvciBhIGdpdmVuIElQIChmb3IgZmVlZGJhY2tzKS4gKi9cblx0cHVibGljIGdldERldmljZVN0YXRlKGRldmljZUlwOiBzdHJpbmcpOiBNYXA8c3RyaW5nLCBudW1iZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoZGV2aWNlSXApID8/IG5ldyBNYXAoKVxuXHR9XG5cblx0LyoqXG5cdCAqIERpc2NvdmVycyBTdHVkaW8gVGVjaG5vbG9naWVzIERhbnRlIGRldmljZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsuXG5cdCAqXG5cdCAqIFN0cmF0ZWd5OlxuXHQgKiAgRGFudGUgZGV2aWNlcyBicm9hZGNhc3QgYSAxLXNlY29uZCBhbm5vdW5jZSB0byBtdWx0aWNhc3QgMjI0LjAuMC4yMzM6ODcwOC5cblx0ICogIFdlIGxpc3RlbiBvbiB0aGF0IGdyb3VwLCBjb2xsZWN0IHNvdXJjZSBJUHMsIHRoZW4gc2VuZCBhIHVuaWNhc3QgZGV2aWNlIGluZm9cblx0ICogIHJlcXVlc3QgKDB4MDAyMCkgdG8gZWFjaCBuZXcgSVAgb24gcG9ydCA4NzAwLiBUaGUgZGV2aWNlIHJlc3BvbmRzIHRvIG91ciBJUFxuXHQgKiAgb24gcG9ydCA4NzAyIChyeFNvY2tldCksIHdoZXJlIGhhbmRsZUluY29taW5nKCkgcGlja3MgaXQgdXAgYW5kIGZpcmVzIHRoZVxuXHQgKiAgZGlzY292ZXJ5TGlzdGVuZXJzIGNhbGxiYWNrLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIGRpc2NvdmVyRGV2aWNlcyh0aW1lb3V0TXMgPSA1MDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvW10+IHtcblx0XHQvLyBSZWdpc3RlciBsaXN0ZW5lciBcdTIwMTQgaGFuZGxlSW5jb21pbmcoKSBmaXJlcyB0aGlzIGZvciBlYWNoIDB4MDE3MCByZXNwb25zZVxuXHRcdGNvbnN0IERJU0NPVkVSWV9LRVkgPSAnX19kaXNjb3ZlcnlfXydcblx0XHRjb25zdCBmb3VuZERldmljZXM6IERldmljZUluZm9bXSA9IFtdXG5cblx0XHRjb25zdCBvbkRldmljZUZvdW5kID0gKGRldmljZTogRGV2aWNlSW5mbykgPT4ge1xuXHRcdFx0aWYgKCFmb3VuZERldmljZXMuc29tZSgoZCkgPT4gZC5pcCA9PT0gZGV2aWNlLmlwKSkge1xuXHRcdFx0XHRmb3VuZERldmljZXMucHVzaChkZXZpY2UpXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gUmVnaXN0ZXIgdGhlIGNhbGxiYWNrIHNvIGhhbmRsZUluY29taW5nKCkgY2FuIGludm9rZSBpdCB3aGVuIDB4MDE3MCBhcnJpdmVzXG5cdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KERJU0NPVkVSWV9LRVksIG9uRGV2aWNlRm91bmQpXG5cblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0XHQvLyBkaXNjb3ZlckRldmljZXMoKSBpbiBkYW50ZS50cyBoYW5kbGVzIHRoZSBhbm5vdW5jZSBsaXN0ZW5pbmcgYW5kIHF1ZXJ5IHNlbmRpbmdcblx0XHRcdC8vIFJlc3BvbnNlcyBjb21lIGJhY2sgdG8gcnhTb2NrZXQgXHUyMTkyIGhhbmRsZUluY29taW5nKCkgXHUyMTkyIGRpc2NvdmVyeUxpc3RlbmVyc1xuXHRcdFx0YXdhaXQgZGlzY292ZXJEZXZpY2VzKFxuXHRcdFx0XHR0aGlzLnR4U29ja2V0LFxuXHRcdFx0XHRvbkRldmljZUZvdW5kLCAvLyBkYW50ZS50cyBkb2Vzbid0IGFjdHVhbGx5IHVzZSB0aGlzLCBidXQga2VwdCBmb3IgY29tcGF0aWJpbGl0eVxuXHRcdFx0XHRhc3luYyAoZGVzdElwKSA9PiB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKSxcblx0XHRcdFx0dGltZW91dE1zLFxuXHRcdFx0KVxuXHRcdFx0cmV0dXJuIGZvdW5kRGV2aWNlc1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5kZWxldGUoRElTQ09WRVJZX0tFWSlcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogUmVxdWVzdHMgZGV2aWNlIGZpcm13YXJlIHZlcnNpb24gdmlhIFN0dWRpby1UIHByb3RvY29sIChDTURfR0VUX0ZJUk1XQVJFKS5cblx0ICogUmV0dXJucyB0aGUgZmlybXdhcmUgdmVyc2lvbiBzdHJpbmcgKGUuZy4sIFwiMy4wMVwiLCBcIjIuMlwiLCBcIjEuMDVcIikuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2VJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0XHRsb2dnZXIuaW5mbyhgUmVxdWVzdGluZyBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soXG5cdFx0XHR0aGlzLm1vZGVsLFxuXHRcdFx0Q01EX0dFVF9GSVJNV0FSRSxcblx0XHRcdHVuZGVmaW5lZCxcblx0XHRcdHVuZGVmaW5lZCxcblx0XHRcdHVuZGVmaW5lZCxcblx0XHRcdGRldmljZUlwLFxuXHRcdFx0ZmFsc2UsXG5cdFx0KVxuXG5cdFx0Ly8gUmVzcG9uc2Ugc3RydWN0dXJlOiBbaGVhZGVyXSAweDVhIDB4ODAgW2Zpcm13YXJlX2RhdGFdIENSQ1xuXHRcdC8vIEZpcm13YXJlIGRhdGEgc3RhcnRzIGF0IGJ5dGUgMjYgKDI0LWJ5dGUgaGVhZGVyICsgMHg1YSArIDB4ODApXG5cdFx0Y29uc3QgZGF0YVN0YXJ0ID0gMjZcblxuXHRcdGlmIChyZXNwb25zZS5sZW5ndGggPCBkYXRhU3RhcnQgKyAzKSB7XG5cdFx0XHRsb2dnZXIud2FybihgRmlybXdhcmUgcmVzcG9uc2UgdG9vIHNob3J0OiAke3Jlc3BvbnNlLmxlbmd0aH0gYnl0ZXNgKVxuXHRcdFx0cmV0dXJuICdVbmtub3duJ1xuXHRcdH1cblxuXHRcdC8vIEZpcm13YXJlIGZvcm1hdDogW3Vua25vd25fYnl0ZSwgbWFqb3IsIG1pbm9yXVxuXHRcdGNvbnN0IG1ham9yID0gcmVzcG9uc2VbZGF0YVN0YXJ0ICsgMV1cblx0XHRjb25zdCBtaW5vciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDJdXG5cblx0XHRsZXQgbWlub3JTdHI6IHN0cmluZ1xuXHRcdGlmIChtaW5vciA9PT0gMikge1xuXHRcdFx0bWlub3JTdHIgPSAnMicgLy8gU3BlY2lhbCBjYXNlOiAyLjIgbm90IDIuMDJcblx0XHR9IGVsc2UgaWYgKG1pbm9yIDwgMTApIHtcblx0XHRcdG1pbm9yU3RyID0gbWlub3IudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpIC8vIDFcdTIxOTJcIjAxXCIsIDVcdTIxOTJcIjA1XCJcblx0XHR9IGVsc2Uge1xuXHRcdFx0bWlub3JTdHIgPSBtaW5vci50b1N0cmluZygpIC8vIDEwK1x1MjE5MlwiMTBcIiwgXCIyMFwiLCBldGNcblx0XHR9XG5cblx0XHRjb25zdCBmaXJtd2FyZSA9IGAke21ham9yfS4ke21pbm9yU3RyfWBcblxuXHRcdGxvZ2dlci5pbmZvKGBGaXJtd2FyZSB2ZXJzaW9uOiAke2Zpcm13YXJlfWApXG5cdFx0cmV0dXJuIGZpcm13YXJlXG5cdH1cblxuXHQvKipcblx0ICogRW5zdXJlIHdlJ3ZlIGpvaW5lZCB0aGUgbXVsdGljYXN0IGdyb3VwIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gZGVzdElwLlxuXHQgKiBPcHRpb24gQiBiZWhhdmlvcjogam9pbiBPTkxZIHRoZSBpbnRlcmZhY2UgdXNlZCB0byByZWFjaCB0aGUgZGV2aWNlLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBlbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGF3YWl0IGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblx0XHRcdGlmICghbG9jYWxBZGRyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgZGV0ZXJtaW5lIGxvY2FsIGFkZHJlc3MgZm9yIGRlc3RpbmF0aW9uICR7ZGVzdElwfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAodGhpcy5qb2luZWRJbnRlcmZhY2VzLmhhcyhsb2NhbEFkZHIpKSB7XG5cdFx0XHRcdC8vIGFscmVhZHkgam9pbmVkXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLnJ4U29ja2V0LmFkZE1lbWJlcnNoaXAodGhpcy5tdWx0aWNhc3RHcm91cCwgbG9jYWxBZGRyKVxuXHRcdFx0XHR0aGlzLmpvaW5lZEludGVyZmFjZXMuYWRkKGxvY2FsQWRkcilcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEpvaW5lZCBtdWx0aWNhc3QgJHt0aGlzLm11bHRpY2FzdEdyb3VwfSBvbiAke2xvY2FsQWRkcn1gKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBqb2luIG11bHRpY2FzdCBvbiAke2xvY2FsQWRkcn06ICR7U3RyaW5nKF9lKX1gKVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRsb2dnZXIud2FybihgZW5zdXJlTWVtYmVyc2hpcEZvciBmYWlsZWQ6ICR7X2V9YClcblx0XHR9XG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgc2VuZEF3YWl0QWNrKFxuXHRcdG1vZGVsOiBzdHJpbmcsXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0dGhpcy5wZW5kaW5nQ29tbWFuZENvdW50Kytcblx0XHRyZXR1cm4gbmV3IFByb21pc2U8QnVmZmVyPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHR0aGlzLnNlbmRRdWV1ZSA9IHRoaXMuc2VuZFF1ZXVlLnRoZW4oYXN5bmMgKCkgPT5cblx0XHRcdFx0dGhpcy5fc2VuZEF3YWl0QWNrKG1vZGVsLCBjbWRJZCwgYnVzQ2gsIHNldHRpbmdJZCwgdmFsdWUsIGRlc3RJcCwgYWRkTGVuKVxuXHRcdFx0XHRcdC50aGVuKChidWYpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHQvLyBPbmx5IHRyaWdnZXIgcmVxdWVzdEFsbFNldHRpbmdzIHdoZW4gdGhlIHF1ZXVlIGlzIGZ1bGx5IGRyYWluZWRcblx0XHRcdFx0XHRcdGlmICh0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQgPT09IDAgJiYgdGhpcy5yZWZyZXNoQWZ0ZXJDb21tYW5kICYmIHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRcdHRoaXMucmVxdWVzdEFsbFNldHRpbmdzKGRlc3RJcCkuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gcmVmcmVzaCBzZXR0aW5ncyBhZnRlciBjb21tYW5kOiAke2Vycn1gKVxuXHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0cmVzb2x2ZShidWYpXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0XHQuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0dGhpcy5wZW5kaW5nQ29tbWFuZENvdW50LS1cblx0XHRcdFx0XHRcdHJlamVjdChlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyciA6IG5ldyBFcnJvcihTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdFx0fSksXG5cdFx0XHQpXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgYXN5bmMgX3NlbmRBd2FpdEFjayhcblx0XHRtb2RlbDogc3RyaW5nLFxuXHRcdGNtZElkOiBudW1iZXIsXG5cdFx0YnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHRzZXR0aW5nSWQ6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHR2YWx1ZTogdW5rbm93bixcblx0XHRkZXN0SXA6IHN0cmluZyxcblx0XHRhZGRMZW4gPSB0cnVlLFxuXHQpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGNvbnN0IHRpbWVvdXRNcyA9IDIwMDBcblxuXHRcdC8vIFJlamVjdCBjb21tYW5kcyB0byB1bnZlcmlmaWVkIGRldmljZXMuIHByb2JlRGV2aWNlKCkgYnlwYXNzZXMgdGhpc1xuXHRcdC8vIGJlY2F1c2UgaXQgdXNlcyB0aGUgRGFudGUgcHJvdG9jb2wgZGlyZWN0bHkgdmlhIHR4U29ja2V0LCBub3Qgc2VuZEF3YWl0QWNrLlxuXHRcdGlmICghdGhpcy5hdXRob3JpemVkSXBzLmhhcyhkZXN0SXApKSB7XG5cdFx0XHR0aHJvdyBuZXcgRXJyb3IoYERldmljZSBhdCAke2Rlc3RJcH0gaXMgbm90IGF1dGhvcml6ZWQgXHUyMDE0IHZlcmlmeSB0aGUgSVAgYW5kIG1vZGVsIG1hdGNoIGJlZm9yZSBzZW5kaW5nIGNvbW1hbmRzYClcblx0XHR9XG5cblx0XHQvLyBFbnN1cmUgd2UgYXJlIGxpc3RlbmluZyBmb3IgcmVwbGllcyBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgd2lsbCByZWNlaXZlIHRoZW1cblx0XHRhd2FpdCB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKVxuXG5cdFx0Y29uc3QgZGF0YUJsb2NrOiBudW1iZXJbXSA9IFtdXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkKSBkYXRhQmxvY2sucHVzaChzZXR0aW5nSWQgJiAweGZmKVxuXHRcdGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSBkYXRhQmxvY2sucHVzaCguLi5TdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKSlcblxuXHRcdGNvbnN0IHBheWxvYWRCb2R5OiBudW1iZXJbXSA9IFsweDVhLCBjbWRJZCAmIDB4ZmZdXG5cblx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgcGF5bG9hZEJvZHkucHVzaChidXNDaCAmIDB4ZmYpXG5cdFx0aWYgKGFkZExlbikgcGF5bG9hZEJvZHkucHVzaChkYXRhQmxvY2subGVuZ3RoKVxuXG5cdFx0aWYgKGRhdGFCbG9jay5sZW5ndGggPiAwKSBwYXlsb2FkQm9keS5wdXNoKC4uLmRhdGFCbG9jaylcblxuXHRcdGNvbnN0IGNyYyA9IFN0Q29udHJvbGxlci5jcmM4RHZiUzIocGF5bG9hZEJvZHkpXG5cdFx0Y29uc3QgcGF5bG9hZFdpdGhDcmMgPSBCdWZmZXIuZnJvbShbLi4ucGF5bG9hZEJvZHksIGNyY10pXG5cblx0XHRjb25zdCB0b3RhbExlbiA9IDI0ICsgcGF5bG9hZFdpdGhDcmMubGVuZ3RoXG5cdFx0Y29uc3QgaGVhZGVyID0gYXdhaXQgU3RDb250cm9sbGVyLmJ1aWxkSGVhZGVyKHRvdGFsTGVuLCBkZXN0SXApXG5cdFx0Y29uc3QgcGFja2V0ID0gQnVmZmVyLmNvbmNhdChbaGVhZGVyLCBwYXlsb2FkV2l0aENyY10pXG5cblx0XHQvLyBIdW1hbi1yZWFkYWJsZSBpbmZvIGxvZyBmb3IgdGhlIG91dGdvaW5nIGNvbW1hbmRcblx0XHRjb25zdCBjbWROYW1lID0gZ2V0Q29tbWFuZE5hbWUoY21kSWQpXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkICYmIHZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRcdFx0bGV0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXG5cdFx0XHQvLyBJZiBubyBleGFjdCBtYXRjaCwgdHJ5IHRvIGZpbmQgYWN0aW9uIHdpdGggaWRBZGQgb3B0aW9uXG5cdFx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0XHRhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0XHRcdGlmIChhLmNtZF9pZCAhPT0gY21kSWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdGNvbnN0IGhhc0lkQWRkID0gYS5vcHRpb25zPy5zb21lKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRpZiAoIWhhc0lkQWRkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRyZXR1cm4gc2V0dGluZ0lkID49IGEuaWQgJiYgc2V0dGluZ0lkIDwgYS5pZCArIDEwXG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cblx0XHRcdGxldCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyAnVW5rbm93biBTZXR0aW5nJ1xuXG5cdFx0XHQvLyBJZiB0aGlzIGFjdGlvbiBoYXMgaWRBZGQgYW5kIHRoZSBzZXR0aW5nIGlkIGlzIG9mZnNldCBmcm9tIGJhc2UsIGluY2x1ZGUgY2hhbm5lbCBpbmZvXG5cdFx0XHRpZiAoYWN0aW9uKSB7XG5cdFx0XHRcdGNvbnN0IGhhc0lkQWRkID0gYWN0aW9uLm9wdGlvbnM/LnNvbWUoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRpZiAoaGFzSWRBZGQgJiYgc2V0dGluZ0lkICE9PSBhY3Rpb24uaWQpIHtcblx0XHRcdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZ0lkIC0gYWN0aW9uLmlkXG5cdFx0XHRcdFx0c2V0dGluZ05hbWUgPSBgJHtzZXR0aW5nTmFtZX0gQ2gke2NoYW5uZWxPZmZzZXQgKyAxfWBcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBMb29rIGZvciB0aGUgdmFsdWUgb3B0aW9uIHRvIGdldCBjaG9pY2VzXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbiA9IGFjdGlvbj8ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdFx0XHRjb25zdCBjaG9pY2VzID0gdmFsdWVPcHRpb24/LmNob2ljZXNcblx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBTdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKVxuXHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID0gY2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cblx0XHRcdGNvbnN0IGNtZEhleCA9IHRvSGV4KGNtZElkKVxuXHRcdFx0Y29uc3QgaWRIZXggPSB0b0hleChzZXR0aW5nSWQpXG5cdFx0XHRjb25zdCB2YWxIZXggPSBieXRlc1RvSGV4KHZhbHVlQnl0ZXMpXG5cdFx0XHRjb25zdCB2YWxEZWMgPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB2YWx1ZUJ5dGVzLmpvaW4oJywnKVxuXG5cdFx0XHRjb25zdCBwcmVmaXggPSBgY21kOiR7Y21kSGV4fSBpZDoke2lkSGV4fSB2YWw6JHt2YWxIZXh9YFxuXHRcdFx0Y29uc3Qgc3VmZml4ID0gY2hvaWNlTGFiZWwgPyBgJHtzZXR0aW5nTmFtZX06ICR7Y2hvaWNlTGFiZWx9ICgke3ZhbERlY30pYCA6IGAke3NldHRpbmdOYW1lfTogJHt2YWxEZWN9YFxuXG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtwcmVmaXh9IHwgJHtzdWZmaXh9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFRYICR7ZGVzdElwfSB8ICR7Y21kTmFtZX1gKVxuXHRcdH1cblx0XHRsb2dnZXIuZGVidWcoYFNlbmRpbmcgcGFja2V0IHRvICR7ZGVzdElwfTogJHtwYWNrZXQudG9TdHJpbmcoJ2hleCcpfWApXG5cblx0XHRhd2FpdCB0aGlzLnR4UmVhZHlcblxuXHRcdGNvbnN0IGtleSA9IGAke2Rlc3RJcH06JHtjbWRJZH1gXG5cblx0XHRyZXR1cm4gbmV3IFByb21pc2U8QnVmZmVyPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYFRpbWVvdXQgd2FpdGluZyBmb3IgQUNLIGZyb20gTW9kZWwke21vZGVsfSBhdCAke2Rlc3RJcH06ODcwMGApKVxuXHRcdFx0fSwgdGltZW91dE1zKVxuXG5cdFx0XHR0aGlzLnBlbmRpbmdBY2tzLnNldChrZXksIHtcblx0XHRcdFx0cmVzb2x2ZTogKGJ1ZikgPT4ge1xuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZXNvbHZlKGJ1Zilcblx0XHRcdFx0fSxcblx0XHRcdFx0cmVqZWN0OiAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChlcnIpXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHRpbWVyLFxuXHRcdFx0fSlcblxuXHRcdFx0dGhpcy50eFNvY2tldC5zZW5kKHBhY2tldCwgdGhpcy5kZWZhdWx0UG9ydCwgZGVzdElwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGhhbmRsZUluY29taW5nKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKSB7XG5cdFx0aWYgKG1zZy5sZW5ndGggPCA0KSByZXR1cm5cblx0XHRpZiAobXNnWzBdICE9PSAweGZmIHx8IG1zZ1sxXSAhPT0gMHhmZikgcmV0dXJuXG5cblx0XHRjb25zdCBtc2dUeXBlID0gbXNnLnJlYWRVSW50MTZCRSgyKVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlICgweDAxNzApIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFRoZXNlIGhhdmUgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNiwgbm90IFwiU3R1ZGlvLVRcIiBcdTIwMTQgaGFuZGxlIGJlZm9yZVxuXHRcdC8vIHRoZSBTdHVkaW8tVCBzaWduYXR1cmUgY2hlY2sgYmVsb3cuXG5cdFx0aWYgKG1zZ1R5cGUgPT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFICYmIHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNpemUgPiAwKSB7XG5cdFx0XHRjb25zdCBkZXZpY2UgPSBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZywgc3JjSXApXG5cdFx0XHRpZiAoZGV2aWNlKSB7XG5cdFx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0XHRgRGFudGUgaW5mbyByZXNwb25zZSBmcm9tICR7c3JjSXB9OiBgICtcblx0XHRcdFx0XHRcdGBEZXZpY2VJRD1cIiR7ZGV2aWNlLm5hbWV9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1vZGVsPVwiJHtkZXZpY2UubW9kZWx9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1vZGVsTmFtZT1cIiR7ZGV2aWNlLm1vZGVsTmFtZX1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTWFudWZhY3R1cmVyPVwiJHtkZXZpY2UubWFudWZhY3R1cmVyfVwiYCxcblx0XHRcdFx0KVxuXG5cdFx0XHRcdC8vIE9ubHkgYWNjZXB0IFN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlcyAoaWRlbnRpZmllZCBieSBEZXZpY2VJRCBcIlN0dWRpby1UXCIpXG5cdFx0XHRcdGlmIChkZXZpY2UubmFtZSA9PT0gJ1N0dWRpby1UJykge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgY2Igb2YgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMudmFsdWVzKCkpIHtcblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdGNiKGRldmljZSlcblx0XHRcdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBJZ25vcmluZyBub24tU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2U6IERldmljZUlEPVwiJHtkZXZpY2UubmFtZX1cIiBAICR7c3JjSXB9YClcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKG1zZy5sZW5ndGggPCAyNSkgcmV0dXJuXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgY29udHJvbCBwcm90b2NvbCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBzaWcgPSBtc2cuc3ViYXJyYXkoMTYsIDI0KVxuXHRcdGlmIChzaWcudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdTdHVkaW8tVCcpIHJldHVyblxuXG5cdFx0Ly8gUGF5bG9hZCBzdGFydHMgYXQgb2Zmc2V0IDI0XG5cdFx0Ly8gTGF5b3V0OiBbMHg1YV0gW2NtZElkfDB4ODBdIFtkYXRhLi4uXSBbY3JjXVxuXHRcdGNvbnN0IHN0UGF5bG9hZCA9IG1zZy5zdWJhcnJheSgyNClcblx0XHRpZiAoc3RQYXlsb2FkLmxlbmd0aCA8IDIpIHJldHVyblxuXHRcdGlmIChzdFBheWxvYWRbMF0gIT09IDB4NWEpIHJldHVyblxuXG5cdFx0Ly8gRGV2aWNlIHJlcGxpZXMgd2l0aCBjbWQgfCAweDgwXG5cdFx0Y29uc3QgcmVzcENtZElkID0gc3RQYXlsb2FkWzFdXG5cdFx0Y29uc3QgaXNSZXNwb25zZSA9IChyZXNwQ21kSWQgJiAweDgwKSAhPT0gMFxuXHRcdGNvbnN0IG9yaWdpbmFsQ21kSWQgPSByZXNwQ21kSWQgJiAweDdmIC8vIHN0cmlwIHRoZSByZXNwb25zZSBmbGFnXG5cblx0XHQvLyBMb2cgdGhlIHBheWxvYWQgKHdvcmtzIGZvciBib3RoIHJlcXVlc3RzIGFuZCByZXNwb25zZXMpXG5cdFx0dGhpcy5sb2dTdFBheWxvYWQoc3JjSXAsIG9yaWdpbmFsQ21kSWQsIG1zZywgc3RQYXlsb2FkLCBpc1Jlc3BvbnNlKVxuXG5cdFx0Ly8gT25seSBwcm9jZXNzIGFzIEFDSyBpZiB0aGlzIGlzIGEgcmVzcG9uc2UgdG8gb3VyIHJlcXVlc3Rcblx0XHRpZiAoaXNSZXNwb25zZSkge1xuXHRcdFx0Y29uc3Qga2V5ID0gYCR7c3JjSXB9OiR7b3JpZ2luYWxDbWRJZH1gXG5cdFx0XHRjb25zdCBwZW5kaW5nID0gdGhpcy5wZW5kaW5nQWNrcy5nZXQoa2V5KVxuXHRcdFx0aWYgKHBlbmRpbmcpIHtcblx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRwZW5kaW5nLnJlc29sdmUobXNnKVxuXHRcdFx0fVxuXHRcdH1cblx0XHQvLyBVbnNvbGljaXRlZCBtZXNzYWdlcyBhbmQgcmVxdWVzdHMgZnJvbSBvdGhlciBzb3VyY2VzIGFyZSBsb2dnZWQgYWJvdmVcblx0fVxuXG5cdC8qKlxuXHQgKiBEZWNvZGVzIGFuZCBsb2dzIGEgU3R1ZGlvLVQgcmVzcG9uc2UgcGF5bG9hZC5cblx0ICogUmVjZWl2ZXMgYm90aCB0aGUgZnVsbCBtc2cgKGZvciBwYXJzZXJzIHRoYXQgbmVlZCB0aGUgU3R1ZGlvLVQgaGVhZGVyKVxuXHQgKiBhbmQgc3RQYXlsb2FkIChtc2cuc3ViYXJyYXkoMjQpLCBmb3IgZGlyZWN0IGJ5dGUgYWNjZXNzKS5cblx0ICpcblx0ICogc3RQYXlsb2FkIGxheW91dDpcblx0ICogICBbMF0gICAgICAweDVhICBtYWdpY1xuXHQgKiAgIFsxXSAgICAgIGNtZElkIHwgMHg4MFxuXHQgKiAgIFsyLi4tMl0gIGRhdGEgYnl0ZXNcblx0ICogICBbLTFdICAgICBDUkMtOC9EVkItUzJcblx0ICovXG5cdHByaXZhdGUgbG9nU3RQYXlsb2FkKHNyY0lwOiBzdHJpbmcsIGNtZElkOiBudW1iZXIsIG1zZzogQnVmZmVyLCBzdFBheWxvYWQ6IEJ1ZmZlciwgaXNSZXNwb25zZSA9IHRydWUpOiB2b2lkIHtcblx0XHRjb25zdCBjbWROYW1lID0gYGNtZF8ke3RvSGV4KGNtZElkKX1gXG5cdFx0Y29uc3QgZGF0YSA9IHN0UGF5bG9hZC5zdWJhcnJheSgyLCBzdFBheWxvYWQubGVuZ3RoIC0gMSkgLy8gc3RyaXAgbWFnaWMrY21kSWQgaGVhZGVyIGFuZCBDUkNcblxuXHRcdC8vIFNob3cgY29tcGxldGUgcGF5bG9hZCBzdHJ1Y3R1cmU6IFsweDVhXSBbY21kSWR8MHg4MF0gW2RhdGEgYnl0ZXMuLi5dIFtjcmNdXG5cdFx0Y29uc3QgbWFnaWMgPSBzdFBheWxvYWRbMF1cblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBjcmMgPSBzdFBheWxvYWRbc3RQYXlsb2FkLmxlbmd0aCAtIDFdXG5cdFx0Y29uc3QgZnVsbFN0cnVjdHVyZSA9IGBbbWFnaWM6JHt0b0hleChtYWdpYyl9IGNtZDoke3RvSGV4KHJlc3BDbWRJZCl9IGRhdGE6JHtkYXRhLnRvU3RyaW5nKCdoZXgnKX0gY3JjOiR7dG9IZXgoY3JjKX1dYFxuXG5cdFx0Ly8gRGV0ZXJtaW5lIGRpcmVjdGlvbiBwcmVmaXhcblx0XHRjb25zdCBkaXJlY3Rpb24gPSBpc1Jlc3BvbnNlID8gJ1JYJyA6ICdTTklGRidcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgYW5kIENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBQYXJzZSBhbGwgc2V0dGluZ3MsIGRpZmYgYWdhaW5zdCBkZXZpY2VTdGF0ZSwgbG9nIGNoYW5nZWQgYXQgaW5mbyAvIHVuY2hhbmdlZCBhdCBkZWJ1Zyxcblx0XHQvLyB0aGVuIHVwZGF0ZSBkZXZpY2VTdGF0ZS4gQ01EX0dFVF9BTExfU0VUVElOR1MgYWxzbyBzZXJ2ZXMgYXMgdGhlIGluaXRpYWwgc3RhdGUgcG9wdWxhdGlvbiBvbiBjb25uZWN0LlxuXHRcdGlmIChjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgfHwgY21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0XHRpZiAoIXRoaXMubW9kZWwpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYCR7ZGlyZWN0aW9ufSAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5ncyA9XG5cdFx0XHRcdFx0Y21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIXG5cdFx0XHRcdFx0XHQ/IHBhcnNlU2V0dGluZ3NSZXNwb25zZSh0aGlzLm1vZGVsLCBtc2cpXG5cdFx0XHRcdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCh0aGlzLm1vZGVsLCBtc2cpXG5cblx0XHRcdFx0Y29uc3QgcHJldlN0YXRlID0gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoc3JjSXApID8/IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0XHRcdFx0Y29uc3QgbmV3U3RhdGUgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPihwcmV2U3RhdGUpIC8vIGNvcHkgXHUyMDE0IHVwZGF0ZSBpbiBwbGFjZVxuXG5cdFx0XHRcdGZvciAoY29uc3QgcyBvZiBzZXR0aW5ncykge1xuXHRcdFx0XHRcdGNvbnN0IHN0YXRlS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgcy5pZCwgcy5idXNDaClcblx0XHRcdFx0XHQvLyBGb3IgUkdCIGNvbG9ycyAoMyBieXRlcyksIHBhY2sgaW50byBzaW5nbGUgbnVtYmVyOiAoUiA8PCAxNikgfCAoRyA8PCA4KSB8IEJcblx0XHRcdFx0XHRjb25zdCBuZXdWYWx1ZSA9XG5cdFx0XHRcdFx0XHRzLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHRcdFx0XHRcdD8gKHMudmFsdWVCeXRlc1swXSA8PCAxNikgfCAocy52YWx1ZUJ5dGVzWzFdIDw8IDgpIHwgcy52YWx1ZUJ5dGVzWzJdXG5cdFx0XHRcdFx0XHRcdDogKHMudmFsdWVCeXRlc1swXSA/PyAwKVxuXHRcdFx0XHRcdGNvbnN0IHByZXZWYWx1ZSA9IHByZXZTdGF0ZS5nZXQoc3RhdGVLZXkpXG5cdFx0XHRcdFx0Y29uc3QgY2hhbmdlZCA9IHByZXZWYWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHByZXZWYWx1ZSAhPT0gbmV3VmFsdWVcblxuXHRcdFx0XHRcdG5ld1N0YXRlLnNldChzdGF0ZUtleSwgbmV3VmFsdWUpXG5cblx0XHRcdFx0XHRjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXRQYXJzZWRTZXR0aW5nKHMsIHRoaXMuYWN0aW9ucylcblx0XHRcdFx0XHRpZiAoY2hhbmdlZCkge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmluZm8oYCR7ZGlyZWN0aW9ufSAke3NyY0lwfSB8ICR7Zm9ybWF0dGVkfWApXG5cdFx0XHRcdFx0XHQvLyBUcmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZSBcdTIwMTQgdXNlIGJhc2Uga2V5IHdpdGhvdXQgYnVzQ2ggc28gaXQgbWF0Y2hlcyB0aGUgZmVlZGJhY2sgZGVmaW5pdGlvbiBJRFxuXHRcdFx0XHRcdFx0aWYgKHRoaXMuZmVlZGJhY2tDYWxsYmFjaykge1xuXHRcdFx0XHRcdFx0XHRjb25zdCBiYXNlRmVlZGJhY2tLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIHMuY21kX2lkLCBzLmlkKVxuXHRcdFx0XHRcdFx0XHQvL2xvZ2dlci5kZWJ1ZyhgVHJpZ2dlcmluZyBmZWVkYmFjayB1cGRhdGUgZm9yIGtleTogJHtiYXNlRmVlZGJhY2tLZXl9YClcblx0XHRcdFx0XHRcdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrKGJhc2VGZWVkYmFja0tleSlcblx0XHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBmZWVkYmFja0NhbGxiYWNrIG5vdCBzZXQgXHUyMDE0IHNraXBwaW5nIGZlZWRiYWNrIHVwZGF0ZSBmb3IgJHtzdGF0ZUtleX1gKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYCR7ZGlyZWN0aW9ufSAke3NyY0lwfSB8ICR7Zm9ybWF0dGVkfWApXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuZGV2aWNlU3RhdGUuc2V0KHNyY0lwLCBuZXdTdGF0ZSlcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYCR7ZGlyZWN0aW9ufSAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCBwYXJzZSBmYWlsZWQ6ICR7ZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBBbGwgb3RoZXIgY29tbWFuZHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Y29uc3QgZGVjb2RlZCA9IHRoaXMuZGVjb2RlU3REYXRhKGNtZElkLCBkYXRhKVxuXHRcdGlmIChkZWNvZGVkKSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgJHtkaXJlY3Rpb259ICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX0gfCAke2RlY29kZWR9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYCR7ZGlyZWN0aW9ufSAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogQXR0ZW1wdHMgdG8gZGVjb2RlIHRoZSBkYXRhIGJ5dGVzIG9mIGEgU3R1ZGlvLVQgcmVzcG9uc2UgaW50byBhXG5cdCAqIGh1bWFuLXJlYWRhYmxlIHN0cmluZy4gUmV0dXJucyBudWxsIHRvIGZhbGwgYmFjayB0byByYXcgaGV4LlxuXHQgKlxuXHQgKiBtc2cgaXMgdGhlIGZ1bGwgcGFja2V0IGJ1ZmZlciBcdTIwMTQgcmVxdWlyZWQgYnkgdGhlIHNldHRpbmdzIHBhcnNlcnMgd2hpY2hcblx0ICogbG9jYXRlIHRoZSBTdHVkaW8tVCBzaWduYXR1cmUgdGhlbXNlbHZlcy5cblx0ICovXG5cdHByaXZhdGUgZGVjb2RlU3REYXRhKGNtZElkOiBudW1iZXIsIGRhdGE6IEJ1ZmZlcik6IHN0cmluZyB8IG51bGwge1xuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMCkgcmV0dXJuICdBQ0snXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ2hlY2sgZm9yIHNpbmdsZS1ieXRlIHJlc3BvbnNlcyAoQUNLIG9yIGVycm9yKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdGlmIChkYXRhWzBdID09PSAweDAwKSB7XG5cdFx0XHRcdHJldHVybiAnQUNLIG9rJ1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0cmV0dXJuIGBFUlJPUiAke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdH1cblx0XHR9XG5cblx0XHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0RFVl9TUEVDICgweDBkKTogc2luZ2xlLWJ5dGUgQUNLIG9yIGVjaG8gb2YgYXBwbGllZCBzZXR0aW5nIFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gRGV2aWNlIHNlbmRzIHR3byBDTURfREVWX1NQRUMgcGFja2V0cyBpbiByZXNwb25zZSB0byBhIHNldDpcblx0XHRcdC8vICAgMS4gQUNLOiAgW3N0YXR1c10gICAgICAgICAgICAgICAoMSBieXRlLCAweDAwID0gb2spXG5cdFx0XHQvLyAgIDIuIEVjaG86IFtidXNDaF0gW3NldHRpbmdJZF0gW3ZhbHVlLi4uXSAgKGNvbmZpcm1pbmcgd2hhdCB3YXMgYXBwbGllZClcblx0XHRcdGNhc2UgQ01EX0RFVl9TUEVDOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0XHRcdHJldHVybiBkYXRhWzBdID09PSAweDAwID8gJ0FDSyBvaycgOiBgQUNLIGVycj0ke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlcyA9IGFjdGlvbj8ub3B0aW9ucz8uWzBdPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9XG5cdFx0XHRcdFx0XHRjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVN0ciA9IGNob2ljZUxhYmVsID8gYCR7Y2hvaWNlTGFiZWx9ICgke3RvSGV4KHZhbHVlTnVtISl9KWAgOiBieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpXG5cdFx0XHRcdFx0Y29uc3QgcmF3VGFnID0gYFske3RvSGV4KGNtZElkKX0vJHt0b0hleChzZXR0aW5nSWQpfV09JHtieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn0gJHtyYXdUYWd9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBgcmF3OiAke2RhdGEudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9NSUNfUFJFX0JVUyAoMHgxMik6IE11bHRpLWJ5dGUgZWNobyByZXNwb25zZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzoge1xuXHRcdFx0XHQvLyBBbHJlYWR5IGhhbmRsZWQgc2luZ2xlLWJ5dGUgYWJvdmUsIHNvIG11bHRpLWJ5dGUgbXVzdCBiZSBlY2hvXG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfWBcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/PyBgMHgke3ZhbHVlQnl0ZXMudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn1gXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIG51bGxcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEJ1cy1zY29wZWQgZ2V0L3NldCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdGNhc2UgQ01EX0JVU19HRVQ6XG5cdFx0XHRjYXNlIENNRF9CVVNfU0VUOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA8IDIpIHJldHVybiBudWxsXG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRyZXR1cm4gYGNoPSR7YnVzQ2h9IHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfSB2YWx1ZT0ke3ZhbHVlLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdHJldHVybiBudWxsIC8vIGZhbGwgdGhyb3VnaCB0byByYXcgaGV4XG5cdFx0fVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlOiB1bmtub3duKTogbnVtYmVyW10ge1xuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykgcmV0dXJuIFt2YWx1ZSA/IDEgOiAwXVxuXHRcdGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gTnVtYmVyKHYpICYgMHhmZilcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuXHRcdFx0aWYgKHZhbHVlID4gMHhmZikgcmV0dXJuIFsodmFsdWUgPj4gMTYpICYgMHhmZiwgKHZhbHVlID4+IDgpICYgMHhmZiwgdmFsdWUgJiAweGZmXVxuXHRcdFx0cmV0dXJuIFt2YWx1ZSAmIDB4ZmZdXG5cdFx0fVxuXHRcdHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgdmFsdWUgdHlwZSBmb3IgU1Rjb250cm9sbGVyOiAke3ZhbHVlfWApXG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBhc3luYyBidWlsZEhlYWRlcih0b3RhbExlbjogbnVtYmVyLCBkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0Y29uc3QgbWFjID0gYXdhaXQgZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwKVxuXG5cdFx0cmV0dXJuIEJ1ZmZlci5jb25jYXQoW1xuXHRcdFx0QnVmZmVyLmZyb20oWzB4ZmYsIDB4ZmYsIDB4MDAsIHRvdGFsTGVuICYgMHhmZiwgMHgwNywgMHhlMSwgMHgwMCwgMHgwMCwgLi4ubWFjLCAweDAwLCAweDAwXSksXG5cdFx0XHRCdWZmZXIuZnJvbSgnU3R1ZGlvLVQnLCAndXRmOCcpLFxuXHRcdF0pXG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBjcmM4RHZiUzIoZGF0YTogbnVtYmVyW10pOiBudW1iZXIge1xuXHRcdGxldCBjcmMgPSAwXG5cdFx0Zm9yIChjb25zdCBiIG9mIGRhdGEpIHtcblx0XHRcdGNyYyBePSBiXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IDg7IGkrKykge1xuXHRcdFx0XHRjcmMgPSAoY3JjICYgMHg4MCkgIT09IDAgPyAoKGNyYyA8PCAxKSBeIDB4ZDUpICYgMHhmZiA6IChjcmMgPDwgMSkgJiAweGZmXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBjcmNcblx0fVxuXG5cdC8qKlxuXHQgKiBSZXR1cm5zIHRoZSBjdXJyZW50IGtub3duIHZhbHVlIGZvciBhIHNldHRpbmcgb24gYSBkZXZpY2UsIG9yIHVuZGVmaW5lZCBpZiB1bmtub3duLlxuXHQgKiBVc2UgZm9yIGZlZWRiYWNrcyBcdTIwMTQgdmFsdWUgaXMgdXBkYXRlZCBvbiBldmVyeSBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgZnJvbSB0aGUgZGV2aWNlLlxuXHQgKlxuXHQgKiBAcGFyYW0gaXAgICAgICAgIERldmljZSBJUCBhZGRyZXNzXG5cdCAqIEBwYXJhbSBjbWRJZCAgICAgQ29tbWFuZCBJRCAoZS5nLiBDTURfREVWX1NQRUMpXG5cdCAqIEBwYXJhbSBzZXR0aW5nSWQgU2V0dGluZyBJRCAoZS5nLiAweDAyIGZvciBDb250cm9sIFNvdXJjZSlcblx0ICogQHBhcmFtIGJ1c0NoICAgICBPcHRpb25hbCBidXMvY2hhbm5lbCBJRCBmb3IgbXVsdGktY2hhbm5lbCBjb21tYW5kc1xuXHQgKi9cblx0cHVibGljIGdldFNldHRpbmdWYWx1ZShpcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBzZXR0aW5nSWQ6IG51bWJlciwgYnVzQ2g/OiBudW1iZXIpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuXHRcdGNvbnN0IGtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cdFx0cmV0dXJuIHRoaXMuZGV2aWNlU3RhdGUuZ2V0KGlwKT8uZ2V0KGtleSlcblx0fVxuXG5cdHB1YmxpYyBhc3luYyByZXNldERldmljZShtb2RlbDogc3RyaW5nLCBkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKG1vZGVsLCBDTURfUkVTRVRfREVWSUNFLCB1bmRlZmluZWQsIDB4MDAsIHVuZGVmaW5lZCwgZGVzdElwLCBmYWxzZSlcblx0fVxuXG5cdHB1YmxpYyBhc3luYyBnbG9iYWxNaWNLaWxsKG1vZGVsOiBzdHJpbmcsIGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5zZW5kQXdhaXRBY2sobW9kZWwsIENNRF9HTE9CQUxfTUlDX0tJTEwsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdEYW50ZScpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBEYW50ZSBkaXNjb3ZlcnkgY29uc3RhbnRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBtZXNzYWdlIHR5cGUgKHNlbnQgdG8gcG9ydCA4NzAwKSAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX01TR19JTkZPX1JFUVVFU1QgPSAweDAwMjBcbi8qKiBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSBtZXNzYWdlIHR5cGUgKHJlY2VpdmVkIG9uIHBvcnQgODcwMikgKi9cbmV4cG9ydCBjb25zdCBEQU5URV9NU0dfSU5GT19SRVNQT05TRSA9IDB4MDE3MFxuXG4vKipcbiAqIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlIGxheW91dCAoYWxsIG9mZnNldHMgYXJlIGludG8gdGhlIFVEUCBwYXlsb2FkKTpcbiAqICAgMHgwMCAgdWludDE2QkUgIE1hZ2ljICgweGZmZmYpXG4gKiAgIDB4MDIgIHVpbnQxNkJFICBNZXNzYWdlIHR5cGUgKDB4MDE3MClcbiAqICAgMHgwNCAgdWludDE2QkUgIFNlcXVlbmNlIG51bWJlclxuICogICAweDA2ICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDA4ICA4IGJ5dGVzICAgRVVJLTY0IChzb3VyY2UgTUFDIHdpdGggZmY6ZmUgaW5zZXJ0ZWQgbWlkKVxuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIEFTQ0lJIGlkZW50aWZpZXJcbiAqICAgMHgxOCAgMiBieXRlcyAgIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uIChtYWpvciwgbWlub3IpXG4gKiAgIDB4MjAgIDMxIGJ5dGVzICBEZXZpY2UgbmFtZSwgbnVsbC1wYWRkZWQgQVNDSUkgKG1heCAzMSBjaGFycyBwZXIgRGFudGUgc3BlYylcbiAqICAgMHgyZSAgdWludDE2QkUgIFByb2R1Y3QgSURcbiAqICAgMHg0YyAgNjQgYnl0ZXMgIE1hbnVmYWN0dXJlciBzdHJpbmcsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKiAgIDB4Y2MgIDY0IGJ5dGVzICBNb2RlbCBzdHJpbmcsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKi9cbmV4cG9ydCBjb25zdCBEQU5URV9JTkZPX01JTl9MRU4gPSAweGNjICsgNjQgLy8gMjY4IGJ5dGVzIFx1MjAxNCBuZWVkIGZ1bGwgbW9kZWwgZmllbGRcblxuLyoqXG4gKiBCdWlsZHMgYSBEYW50ZSBkZXZpY2UgaW5mbyByZXF1ZXN0IHBhY2tldCAodHlwZSAweDAwMjApLlxuICpcbiAqIFBhY2tldCBsYXlvdXQgKDMyIGJ5dGVzKSBcdTIwMTQgZGVyaXZlZCBmcm9tIGxpdmUgY2FwdHVyZSBhbmFseXNpczpcbiAqICAgMHgwMCAgdWludDE2QkUgIE1hZ2ljICgweGZmZmYpXG4gKiAgIDB4MDIgIHVpbnQxNkJFICBNZXNzYWdlIHR5cGUgKDB4MDAyMCA9IGRldmljZSBpbmZvIHJlcXVlc3QpXG4gKiAgIDB4MDQgIHVpbnQxNkJFICBTZXF1ZW5jZSBudW1iZXIgKHJhbmRvbSlcbiAqICAgMHgwNiAgMiBieXRlcyAgIFBhZGRpbmdcbiAqICAgMHgwOCAgNiBieXRlcyAgIFNvdXJjZSBNQUNcbiAqICAgMHgwZSAgMiBieXRlcyAgIFBhZGRpbmdcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBBU0NJSSBpZGVudGlmaWVyXG4gKiAgIDB4MTggIDIgYnl0ZXMgICBQcm90b2NvbCB2ZXJzaW9uICgweDA3MzkpXG4gKiAgIDB4MWEgIDIgYnl0ZXMgICBTdWItdHlwZSAoMHgwMGMxKVxuICogICAweDFjICB1aW50MzJCRSAgQ2FwYWJpbGl0eSBtYXNrICgweDAwMGY0MjQwKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnVpbGREYW50ZUluZm9SZXF1ZXN0KCk6IEJ1ZmZlciB7XG5cdGNvbnN0IGJ1ZiA9IEJ1ZmZlci5hbGxvYygzMiwgMClcblx0Y29uc3Qgc2VxID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMHhmZmZmKVxuXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4ZmZmZiwgMClcblx0YnVmLndyaXRlVUludDE2QkUoREFOVEVfTVNHX0lORk9fUkVRVUVTVCwgMilcblx0YnVmLndyaXRlVUludDE2QkUoc2VxLCA0KVxuXG5cdGNvbnN0IG1hYyA9IGdldEZpcnN0TG9jYWxNYWMoKVxuXHRtYWMuY29weShidWYsIDgpXG5cblx0QnVmZmVyLmZyb20oJ0F1ZGluYXRlJywgJ2FzY2lpJykuY29weShidWYsIDE2KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDA3MzksIDI0KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDAwYzEsIDI2KVxuXHRidWYud3JpdGVVSW50MzJCRSgweDAwMGY0MjQwLCAyOClcblxuXHRyZXR1cm4gYnVmXG59XG5cbi8qKiBSZXR1cm5zIHRoZSBmaXJzdCBub24tbG9vcGJhY2sgTUFDIGFzIGEgNi1ieXRlIEJ1ZmZlciwgb3IgemVyb3MuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Rmlyc3RMb2NhbE1hYygpOiBCdWZmZXIge1xuXHR0cnkge1xuXHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMoaWZhY2VzKSkge1xuXHRcdFx0Zm9yIChjb25zdCBhZGRyIG9mIGlmYWNlc1tuYW1lXSA/PyBbXSkge1xuXHRcdFx0XHRpZiAoIWFkZHIuaW50ZXJuYWwgJiYgYWRkci5mYW1pbHkgPT09ICdJUHY0JyAmJiBhZGRyLm1hYyAmJiBhZGRyLm1hYyAhPT0gJzAwOjAwOjAwOjAwOjAwOjAwJykge1xuXHRcdFx0XHRcdHJldHVybiBCdWZmZXIuZnJvbShhZGRyLm1hYy5zcGxpdCgnOicpLm1hcCgoaDogc3RyaW5nKSA9PiBwYXJzZUludChoLCAxNikpKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIHtcblx0XHQvKiBpZ25vcmUgKi9cblx0fVxuXHRyZXR1cm4gQnVmZmVyLmFsbG9jKDYsIDApXG59XG5cbi8qKlxuICogUGFyc2VzIGEgRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgKHR5cGUgMHgwMTcwKSBpbnRvIGEgRGV2aWNlSW5mby5cbiAqXG4gKiBSZXNwb25zZSBsYXlvdXQgKGtleSBvZmZzZXRzKTpcbiAqICAgMHgwOCAgOCBieXRlcyAgIEVVSS02NCBcdTIwMTQgY29udmVydCB0byBNQUMgYnkgZHJvcHBpbmcgYnl0ZXMgWzNdIGFuZCBbNF0gKGZmOmZlKVxuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIGlkZW50aWZpZXIgKHVzZWQgdG8gdmVyaWZ5IHRoaXMgaXMgYSByZWFsIHJlc3BvbnNlKVxuICogICAweDE4ICAxIGJ5dGUgICAgRGFudGUgRlcgbWFqb3JcbiAqICAgMHgxOSAgMSBieXRlICAgIERhbnRlIEZXIG1pbm9yXG4gKiAgIDB4MjAgIDMxIGJ5dGVzICBEZXZpY2UgbmFtZSAoRGFudGUgbGFiZWwpLCBudWxsLXBhZGRlZCBBU0NJSSAobWF4IDMxIGNoYXJzKVxuICogICAweDJlICB1aW50MTZCRSAgUHJvZHVjdCBJRFxuICogICAweDRjICA2NCBieXRlcyAgTWFudWZhY3R1cmVyLCBudWxsLXBhZGRlZCBBU0NJSVxuICogICAweGNjICA2NCBieXRlcyAgTW9kZWwgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICpcbiAqIFJldHVybnMgbnVsbCBpZiBidWZmZXIgaXMgdG9vIHNob3J0LCB3cm9uZyBtYWdpYywgb3IgbWlzc2luZyBtb2RlbCBzdHJpbmcuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKTogRGV2aWNlSW5mbyB8IG51bGwge1xuXHRpZiAobXNnLmxlbmd0aCA8IERBTlRFX0lORk9fTUlOX0xFTikgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZikgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5yZWFkVUludDE2QkUoMikgIT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVybiBudWxsXG5cblx0Y29uc3QgcmVhZFN0ciA9IChvZmZzZXQ6IG51bWJlciwgbGVuOiBudW1iZXIpOiBzdHJpbmcgPT5cblx0XHRtc2dcblx0XHRcdC5zdWJhcnJheShvZmZzZXQsIG9mZnNldCArIGxlbilcblx0XHRcdC50b1N0cmluZygnYXNjaWknKVxuXHRcdFx0LnNwbGl0KCdcXDAnKVswXVxuXHRcdFx0LnRyaW0oKVxuXG5cdGNvbnN0IGV1aTY0ID0gbXNnLnN1YmFycmF5KDgsIDE2KVxuXHRjb25zdCBtYWNCeXRlcyA9IFtldWk2NFswXSwgZXVpNjRbMV0sIGV1aTY0WzJdLCBldWk2NFs1XSwgZXVpNjRbNl0sIGV1aTY0WzddXVxuXHRjb25zdCBtYWMgPSBtYWNCeXRlcy5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJzonKVxuXG5cdGNvbnN0IG5hbWUgPSByZWFkU3RyKDB4MjAsIDMxKSAvLyBEYW50ZSBkZXZpY2UgbGFiZWwgKGNhbiBiZSB1cCB0byAzMSBjaGFycyBwZXIgRGFudGUgc3BlYylcblx0Y29uc3QgbWFudWZhY3R1cmVyID0gcmVhZFN0cigweDRjLCA2NCkgLy8gZS5nLiBcIlN0dWRpbyBUZWNobm9sb2dpZXMsIEluYy5cIlxuXHRjb25zdCBtb2RlbFJhdyA9IHJlYWRTdHIoMHhjYywgNjQpXG5cdGNvbnN0IGRhbnRlRmlybXdhcmUgPSBgJHttc2dbMHgxOF19LiR7bXNnWzB4MTldfWBcblxuXHRpZiAoIW1vZGVsUmF3KSByZXR1cm4gbnVsbFxuXG5cdC8vIEV4dHJhY3QganVzdCB0aGUgbW9kZWwgbnVtYmVyL2NvZGUgKGUuZy4gXCJNb2RlbCAzOTEgQWxlcnRpbmcgVW5pdFwiIFx1MjE5MiBcIjM5MVwiKVxuXHQvLyBTdHJpcCBcIk1vZGVsIFwiIHByZWZpeCwgdGhlbiB0YWtlIG9ubHkgdGhlIGZpcnN0IHdvcmQgKHRoZSBtb2RlbCBudW1iZXIpXG5cdGNvbnN0IG1vZGVsID0gbW9kZWxSYXdcblx0XHQucmVwbGFjZSgvXk1vZGVsXFxzKy9pLCAnJylcblx0XHQudHJpbSgpXG5cdFx0LnNwbGl0KC9cXHMrLylbMF1cblxuXHRyZXR1cm4ge1xuXHRcdGlwOiBzcmNJcCxcblx0XHRuYW1lLFxuXHRcdG1hbnVmYWN0dXJlcixcblx0XHRtb2RlbCxcblx0XHRtb2RlbE5hbWU6IG1vZGVsUmF3LCAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uXG5cdFx0bWFjLFxuXHRcdGRhbnRlRmlybXdhcmUsXG5cdH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBNQUMgYWRkcmVzcyBieXRlcyBvZiB0aGUgbG9jYWwgaW50ZXJmYWNlIHVzZWQgdG8gcm91dGUgdG8gZGVzdElwLlxuICogVXNlcyBhIHRlbXBvcmFyeSBVRFAgY29ubmVjdCB0byBsZXQgdGhlIE9TIHNlbGVjdCB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlLFxuICogdGhlbiBmaW5kcyB0aGUgbWF0Y2hpbmcgTUFDIGZyb20gb3MubmV0d29ya0ludGVyZmFjZXMoKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hY0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxudW1iZXJbXT4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8bnVtYmVyW10+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCB0bXAgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoJ3VkcDQnKVxuXG5cdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdH0pXG5cblx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cdFx0XHRcdHRtcC5jbG9zZSgpXG5cblx0XHRcdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdFx0XHRmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMoaWZhY2VzKSkge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgaWZhY2Ugb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdFx0XHRpZiAoXG5cdFx0XHRcdFx0XHRcdGlmYWNlLmZhbWlseSA9PT0gJ0lQdjQnICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLmFkZHJlc3MgPT09IGxvY2FsQWRkciAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnXG5cdFx0XHRcdFx0XHQpIHtcblx0XHRcdFx0XHRcdFx0cmV0dXJuIHJlc29sdmUoaWZhY2UubWFjLnNwbGl0KCc6JykubWFwKChiKSA9PiBwYXJzZUludChiLCAxNikgJiAweGZmKSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgTm8gaW50ZXJmYWNlIGZvdW5kIGZvciBsb2NhbCBhZGRyZXNzICR7bG9jYWxBZGRyfWApKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihTdHJpbmcoX2UpKSlcblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGxvY2FsIElQIGFkZHJlc3MgdXNlZCBieSB0aGUgT1MgdG8gcm91dGUgdG8gZGVzdElwLlxuICogVXNlcyBhIHRlbXBvcmFyeSBVRFAgc29ja2V0IGNvbm5lY3QgdG8gbGV0IHRoZSBPUyBzZWxlY3QgdGhlIG91dGdvaW5nIGludGVyZmFjZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPHN0cmluZz4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHQvLyBVc2UgYW4gYXJiaXRyYXJ5IHBvcnQgZm9yIGNvbm5lY3Q7IHdlIG9ubHkgbmVlZCB0aGUga2VybmVsIHRvIGFzc2lnbiBhIGxvY2FsIGFkZHJlc3MuXG5cdFx0dG1wLmNvbm5lY3QoOSwgZGVzdElwLCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGFkZHIuYWRkcmVzc1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZXNvbHZlKGxvY2FsQWRkcilcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihTdHJpbmcoX2UpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogRGlzY292ZXJzIFN0dWRpbyBUZWNobm9sb2dpZXMgRGFudGUgZGV2aWNlcyBvbiB0aGUgbG9jYWwgbmV0d29yay5cbiAqXG4gKiBTdHJhdGVneTpcbiAqICBEYW50ZSBkZXZpY2VzIGJyb2FkY2FzdCBhIDEtc2Vjb25kIGFubm91bmNlIHRvIG11bHRpY2FzdCAyMjQuMC4wLjIzMzo4NzA4LlxuICogIFdlIGxpc3RlbiBvbiB0aGF0IGdyb3VwLCBjb2xsZWN0IHNvdXJjZSBJUHMsIHRoZW4gc2VuZCBhIHVuaWNhc3QgZGV2aWNlIGluZm9cbiAqICByZXF1ZXN0ICgweDAwMjApIHRvIGVhY2ggbmV3IElQIG9uIHBvcnQgODcwMC4gVGhlIGRldmljZSByZXNwb25kcyBvbiBwb3J0IDg3MDIsXG4gKiAgd2hlcmUgdGhlIHByb3ZpZGVkIG9uRGV2aWNlRm91bmQgY2FsbGJhY2sgaXMgaW52b2tlZC5cbiAqXG4gKiBAcGFyYW0gdHhTb2NrZXQgLSBUaGUgc29ja2V0IHRvIHVzZSBmb3Igc2VuZGluZyBkaXNjb3ZlcnkgcmVxdWVzdHNcbiAqIEBwYXJhbSBvbkRldmljZUZvdW5kIC0gQ2FsbGJhY2sgaW52b2tlZCB3aGVuIGEgZGV2aWNlIGluZm8gcmVzcG9uc2UgKDB4MDE3MCkgaXMgcmVjZWl2ZWRcbiAqIEBwYXJhbSBlbnN1cmVNZW1iZXJzaGlwIC0gQ2FsbGJhY2sgdG8gZW5zdXJlIG11bHRpY2FzdCBtZW1iZXJzaGlwIGZvciBkZXZpY2UgSVBcbiAqIEBwYXJhbSB0aW1lb3V0TXMgLSBEaXNjb3ZlcnkgdGltZW91dCBpbiBtaWxsaXNlY29uZHNcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRpc2NvdmVyRGV2aWNlcyhcblx0dHhTb2NrZXQ6IGRncmFtLlNvY2tldCxcblx0X29uRGV2aWNlRm91bmQ6IChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQsIC8vIEludm9rZWQgYnkgU3RDb250cm9sbGVyLmhhbmRsZUluY29taW5nKCksIG5vdCBoZXJlXG5cdGVuc3VyZU1lbWJlcnNoaXA6IChkZXN0SXA6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPixcblx0dGltZW91dE1zID0gNTAwMCxcbik6IFByb21pc2U8RGV2aWNlSW5mb1tdPiB7XG5cdGNvbnN0IERBTlRFX0FOTk9VTkNFX0dST1VQID0gJzIyNC4wLjAuMjMzJ1xuXHRjb25zdCBEQU5URV9BTk5PVU5DRV9QT1JUID0gODcwOFxuXHRjb25zdCBERUZBVUxUX1BPUlQgPSA4NzAwXG5cblx0Y29uc3QgZm91bmQgPSBuZXcgTWFwPHN0cmluZywgRGV2aWNlSW5mbz4oKVxuXHRjb25zdCBxdWVyaWVkSXBzID0gbmV3IFNldDxzdHJpbmc+KClcblxuXHRyZXR1cm4gbmV3IFByb21pc2U8RGV2aWNlSW5mb1tdPigocmVzb2x2ZSkgPT4ge1xuXHRcdC8vIE5vdGU6IG9uRGV2aWNlRm91bmQgY2FsbGJhY2sgaXMgaW52b2tlZCBieSBTdENvbnRyb2xsZXIuaGFuZGxlSW5jb21pbmcoKVxuXHRcdC8vIHdoZW4gaXQgcmVjZWl2ZXMgMHgwMTcwIHJlc3BvbnNlcy4gV2UgZG9uJ3QgY2FsbCBpdCBoZXJlIHRvIGF2b2lkIGR1cGxpY2F0ZXMuXG5cblx0XHQvLyBPcGVuIGEgc2hvcnQtbGl2ZWQgc29ja2V0IGp1c3QgdG8gcmVjZWl2ZSB0aGUgRGFudGUgcGVyaW9kaWMgYW5ub3VuY2VzXG5cdFx0Y29uc3QgYW5ub3VuY2VTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0Y29uc3QgY2xlYW51cCA9ICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmRyb3BNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0cmVzb2x2ZShBcnJheS5mcm9tKGZvdW5kLnZhbHVlcygpKSlcblx0XHR9XG5cblx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoY2xlYW51cCwgdGltZW91dE1zKVxuXHRcdHRpbWVyLnVucmVmPy4oKVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEFubm91bmNlIHNvY2tldCBlcnJvcjogJHtlcnIubWVzc2FnZX1gKVxuXHRcdH0pXG5cblx0XHRhbm5vdW5jZVNvY2tldC5vbignbWVzc2FnZScsIChtc2csIHJpbmZvKSA9PiB7XG5cdFx0XHRjb25zdCBzcmNJcCA9IHJpbmZvLmFkZHJlc3Ncblx0XHRcdC8vIFZhbGlkYXRlIGl0J3MgYSBEYW50ZSBhbm5vdW5jZSAobWFnaWMgMHhmZmZlICsgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNilcblx0XHRcdGlmIChtc2cubGVuZ3RoIDwgMjQpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZSkgcmV0dXJuXG5cdFx0XHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVyblxuXG5cdFx0XHRpZiAocXVlcmllZElwcy5oYXMoc3JjSXApKSByZXR1cm5cblx0XHRcdHF1ZXJpZWRJcHMuYWRkKHNyY0lwKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBBbm5vdW5jZSBmcm9tICR7c3JjSXB9IFx1MjAxNCBzZW5kaW5nIHVuaWNhc3QgcXVlcnlgKVxuXG5cdFx0XHQvLyBKb2luIDIyNC4wLjAuMjMxIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gdGhpcyBkZXZpY2UgQkVGT1JFIHNlbmRpbmdcblx0XHRcdC8vIHRoZSBxdWVyeS4gVGhlIGRldmljZSBtdWx0aWNhc3RzIGl0cyAweDAxNzAgcmVzcG9uc2UgdG8gMjI0LjAuMC4yMzE6ODcwMlxuXHRcdFx0Ly8gaW4gYWRkaXRpb24gdG8gdW5pY2FzdGluZyBpdCBcdTIwMTQgcnhTb2NrZXQgbXVzdCBiZSBhIG1lbWJlciB0byByZWNlaXZlIGl0LlxuXHRcdFx0ZW5zdXJlTWVtYmVyc2hpcChzcmNJcClcblx0XHRcdFx0LnRoZW4oKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IHF1ZXJ5ID0gYnVpbGREYW50ZUluZm9SZXF1ZXN0KClcblx0XHRcdFx0XHR0eFNvY2tldC5zZW5kKHF1ZXJ5LCBERUZBVUxUX1BPUlQsIHNyY0lwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0XHRpZiAoZXJyKSBsb2dnZXIud2FybihgVW5pY2FzdCBxdWVyeSB0byAke3NyY0lwfSBmYWlsZWQ6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9KVxuXHRcdFx0XHQuY2F0Y2goKGVycikgPT4gbG9nZ2VyLndhcm4oYFF1ZXJ5IHNldHVwIGZhaWxlZDogJHtlcnJ9YCkpXG5cdFx0fSlcblxuXHRcdGFubm91bmNlU29ja2V0LmJpbmQoREFOVEVfQU5OT1VOQ0VfUE9SVCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuYWRkTWVtYmVyc2hpcChEQU5URV9BTk5PVU5DRV9HUk9VUClcblx0XHRcdFx0bG9nZ2VyLmluZm8oYExpc3RlbmluZyBmb3IgRGFudGUgYW5ub3VuY2VzIG9uICR7REFOVEVfQU5OT1VOQ0VfR1JPVVB9OiR7REFOVEVfQU5OT1VOQ0VfUE9SVH1gKVxuXHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3Qgam9pbiBhbm5vdW5jZSBtdWx0aWNhc3QgZ3JvdXA6ICR7ZXJyfWApXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIFN0b3JlIGNhbGxiYWNrIGZvciBjbGVhbnVwXG5cdH0pXG59XG4iLCAiaW1wb3J0IHtcblx0SW5zdGFuY2VUeXBlcyxcblx0SW5zdGFuY2VCYXNlLFxuXHRJbnN0YW5jZVN0YXR1cyxcblx0U29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkLFxuXHRjcmVhdGVNb2R1bGVMb2dnZXIsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQge1xuXHRHZXRDb25maWdGaWVsZHMsXG5cdHJlc29sdmVIb3N0LFxuXHRyZXNvbHZlTW9kZWwsXG5cdGdldERldmljZVNjaGVtYSxcblx0Z2V0RGV2aWNlc0ZvbGRlcixcblx0cmVsb2FkRGV2aWNlU2NoZW1hcyxcblx0Z2V0RGV2aWNlU2NoZW1hcyxcblx0dHlwZSBNb2R1bGVDb25maWcsXG59IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucywgVXBkYXRlVmFyaWFibGVWYWx1ZXMgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcbmltcG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH0gZnJvbSAnLi91cGdyYWRlcy5qcydcbmltcG9ydCB7IFVwZGF0ZUFjdGlvbnMgfSBmcm9tICcuL2FjdGlvbnMuanMnXG5pbXBvcnQgeyBVcGRhdGVGZWVkYmFja3MgfSBmcm9tICcuL2ZlZWRiYWNrcy5qcydcbmltcG9ydCB7IFN0Q29udHJvbGxlciB9IGZyb20gJy4vc3Rjb250cm9sbGVyLmpzJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGdldE5vcm1hbGl6ZWRTY2hlbWFzIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uLCB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MsIHNhdmVNb2RlbEpzb25QcmV0dHkgfSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdNb2R1bGVJbnN0YW5jZScpXG5cbmV4cG9ydCB0eXBlIE1vZHVsZVR5cGVzID0gSW5zdGFuY2VUeXBlcyAmIHtcblx0Y29uZmlnOiBNb2R1bGVDb25maWdcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTW9kdWxlSW5zdGFuY2UgZXh0ZW5kcyBJbnN0YW5jZUJhc2U8TW9kdWxlVHlwZXM+IHtcblx0Y29uZmlnITogTW9kdWxlQ29uZmlnIC8vIFNldHVwIGluIGluaXQoKVxuXHRzdENvbnRyb2xsZXIhOiBTdENvbnRyb2xsZXJcblxuXHQvKiogQ2FjaGVkIGRpc2NvdmVyeSByZXN1bHRzIFx1MjAxNCBwYXNzZWQgaW50byBnZXRDb25maWdGaWVsZHMoKSBzbyB0aGUgVUlcblx0ICogIGNhbiBzaG93IHRoZSBkaXNjb3ZlcmVkIGRldmljZSBkcm9wZG93biBvbiBzdWJzZXF1ZW50IGNvbmZpZyBvcGVucy4gKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHRjb25zdHJ1Y3RvcihpbnRlcm5hbDogdW5rbm93bikge1xuXHRcdHN1cGVyKGludGVybmFsKVxuXHR9XG5cblx0YXN5bmMgaW5pdChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0aWYgKCF0aGlzLnN0Q29udHJvbGxlcikge1xuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIgPSBuZXcgU3RDb250cm9sbGVyKClcblx0XHR9XG5cdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cblx0XHQvLyBXaXJlIGZlZWRiYWNrIGNhbGxiYWNrIHNvIHN0Q29udHJvbGxlciBjYW4gdHJpZ2dlciBmZWVkYmFjayB1cGRhdGVzXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0RmVlZGJhY2tDYWxsYmFjaygoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB7XG5cdFx0XHR0aGlzLmNoZWNrRmVlZGJhY2tzKGZlZWRiYWNrSWQpXG5cdFx0fSlcblxuXHRcdC8vIFN0YXJ0IGRpc2NvdmVyeSBpbiB0aGUgYmFja2dyb3VuZCBcdTIwMTQgYWxsIG1vZGVsIHJlc29sdXRpb24sIHNjaGVtYSBzeW5jLFxuXHRcdC8vIGFuZCBVSSB1cGRhdGVzIGhhcHBlbiBpbnNpZGUgcnVuRGlzY292ZXJ5KCkgb25jZSB0aGUgZGV2aWNlIGxpc3QgaXMga25vd24uXG5cdFx0dGhpcy5ydW5EaXNjb3ZlcnkoKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBEaXNjb3ZlcnkgZmFpbGVkOiAke2V9YClcblx0XHR9KVxuXHR9XG5cblx0LyoqXG5cdCAqIFJ1biBkZXZpY2UgZGlzY292ZXJ5LCB0aGVuIHJlc29sdmUgdGhlIG1vZGVsIGFuZCB1cGRhdGUgYWxsIFVJLlxuXHQgKiAtIElmIGRpc2NvdmVyeSBmaW5kcyBkZXZpY2VzLCByZXNvbHZlTW9kZWwgcGlja3MgZnJvbSB0aG9zZS5cblx0ICogLSBPbmx5IGlmIHRoZSBsaXN0IGlzIGVtcHR5IGRvIHdlIGZhbGwgYmFjayB0byB0aGUgbWFudWFsIGNvbmZpZyBzZWxlY3Rpb24uXG5cdCAqIEFsbCBhY3Rpb25zL2ZlZWRiYWNrcy92YXJpYWJsZXMgYXJlIGJ1aWx0IGFmdGVyIHRoZSBtb2RlbCBpcyBrbm93bi5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgcnVuRGlzY292ZXJ5KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGxvZ2dlci5pbmZvKCdTdGFydGluZyBkZXZpY2UgZGlzY292ZXJ5Li4uJylcblxuXHRcdHRoaXMuZGlzY292ZXJlZERldmljZXMgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5kaXNjb3ZlckRldmljZXMoKVxuXG5cdFx0Ly8gRGV0ZXJtaW5lIGVmZmVjdGl2ZSBtb2RlbCBcdTIwMTQgZnJvbSBkaXNjb3ZlcmVkIGRldmljZXMgZmlyc3QsIG1hbnVhbCBjb25maWcgb25seSBhcyBmYWxsYmFja1xuXHRcdGxldCBlZmZlY3RpdmVNb2RlbDogc3RyaW5nXG5cdFx0aWYgKHRoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRjb25zdCBtYW51YWxNb2RlbCA9IHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsXG5cdFx0XHRpZiAoIXRoaXMuY29uZmlnLmhvc3QgfHwgIW1hbnVhbE1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKCdObyBkZXZpY2VzIGRpc2NvdmVyZWQgYW5kIG5vIG1hbnVhbCBJUC9tb2RlbCBjb25maWd1cmVkJylcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHRsb2dnZXIuaW5mbygnTm8gZGV2aWNlcyBkaXNjb3ZlcmVkIFx1MjAxNCB3aWxsIHByb2JlIG1hbnVhbCBJUCBkdXJpbmcgYXV0aG9yaXphdGlvbicpXG5cdFx0XHRlZmZlY3RpdmVNb2RlbCA9IG1hbnVhbE1vZGVsXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBEaXNjb3ZlcmVkICR7dGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGh9IGRldmljZShzKTpgKVxuXHRcdFx0Zm9yIChjb25zdCBkIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSBNb2RlbCAke2QubW9kZWx9ICR7ZC5tYW51ZmFjdHVyZXIgPz8gJyd9IEAgJHtkLmlwfWApXG5cdFx0XHR9XG5cblx0XHRcdC8vIEF1dGhvcml6ZSBhbGwgZGlzY292ZXJlZCBkZXZpY2VzIHNvIGZpcm13YXJlIHJlcXVlc3RzIGNhbiBwcm9jZWVkLlxuXHRcdFx0Ly8gdmVyaWZ5QXV0aG9yaXphdGlvbiAoY2FsbGVkIGJlbG93KSB3aWxsIHJldm9rZSBhbnkgdGhhdCBkb24ndCBtYXRjaFxuXHRcdFx0Ly8gdGhlIGN1cnJlbnQgY29uZmlnIHNlbGVjdGlvbi5cblx0XHRcdGZvciAoY29uc3QgZGV2aWNlIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKGRldmljZS5pcClcblx0XHRcdH1cblxuXHRcdFx0Ly8gUmVxdWVzdCBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gZWFjaCBkaXNjb3ZlcmVkIGRldmljZVxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNvbnN0IGZpcm13YXJlID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2UuaXApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9IGZpcm13YXJlXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSAke2RldmljZS5pcH06IEZpcm13YXJlICR7ZmlybXdhcmV9LCBEYW50ZSAke2RldmljZS5kYW50ZUZpcm13YXJlfWApXG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgICAtICR7ZGV2aWNlLmlwfTogRmFpbGVkIHRvIGdldCBmaXJtd2FyZTogJHtlfWApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9ICdVbmtub3duJ1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdGVmZmVjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKHRoaXMuY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHRcdH1cblxuXHRcdC8vIFN5bmMgbW9kZWwgc2NoZW1hIHRvIGNvbnRyb2xsZXJcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIFZlcmlmeSB0aGF0IHRoZSBjdXJyZW50bHkgY29uZmlndXJlZCBob3N0K21vZGVsIGlzIHZhbGlkIG5vdyB0aGF0XG5cdFx0Ly8gZGlzY292ZXJ5IHJlc3VsdHMgYXJlIGtub3duLiBUaGlzIGlzIHRoZSBzYW1lIGNoZWNrIGNvbmZpZ1VwZGF0ZWQgdXNlcy5cblx0XHRjb25zdCB0YXJnZXRIb3N0ID0gdGhpcy5ob3N0XG5cdFx0YXdhaXQgdGhpcy52ZXJpZnlBdXRob3JpemF0aW9uKCcnLCB0YXJnZXRIb3N0KVxuXG5cdFx0Ly8gQnVpbGQgYWxsIFVJIG5vdyB0aGF0IG1vZGVsIGFuZCBhdXRob3JpemF0aW9uIHN0YXRlIGFyZSBrbm93blxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cblx0XHRsb2dnZXIuaW5mbygnRGV2aWNlIGRpc2NvdmVyeSBjb21wbGV0ZScpXG5cdH1cblxuXHQvLyBXaGVuIG1vZHVsZSBnZXRzIGRlbGV0ZWRcblx0YXN5bmMgZGVzdHJveSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLnN0Q29udHJvbGxlcj8uY2xvc2UoKVxuXHRcdGxvZ2dlci5kZWJ1ZygnZGVzdHJveScpXG5cdH1cblxuXHRhc3luYyBjb25maWdVcGRhdGVkKGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0Y29uc3QgcHJldmlvdXNIb3N0ID0gdGhpcy5ob3N0XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRjb25zdCBlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbChjb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdFx0dGhpcy5zeW5jTW9kZWwoZWZmZWN0aXZlTW9kZWwpXG5cblx0XHQvLyBDbGVhciB2YXJpYWJsZXMgaW1tZWRpYXRlbHkgXHUyMDE0IHRoZSBuZXcgc2VsZWN0aW9uIGlzbid0IGF1dGhvcml6ZWQgeWV0LlxuXHRcdC8vIFRoZXknbGwgYmUgcmVwb3B1bGF0ZWQgYmVsb3cgb25jZSB2ZXJpZnlBdXRob3JpemF0aW9uIGNvbXBsZXRlcy5cblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblxuXHRcdGNvbnN0IG5ld0hvc3QgPSB0aGlzLmhvc3RcblxuXHRcdC8vIFJlLXZlcmlmeSBhdXRob3JpemF0aW9uIG9uIGV2ZXJ5IGNvbmZpZyBjaGFuZ2UgKG1vZGVsIG9yIElQKS5cblx0XHQvLyBUaGlzIGhhbmRsZXMgc3dpdGNoaW5nIGZyb20gYSB2YWxpZCBkZXZpY2UgdG8gYW4gaW52YWxpZCBvbmUgYW5kIGJhY2suXG5cdFx0YXdhaXQgdGhpcy52ZXJpZnlBdXRob3JpemF0aW9uKHByZXZpb3VzSG9zdCwgbmV3SG9zdClcblxuXHRcdC8vIFJlYnVpbGQgVUkgYWZ0ZXIgYXV0aG9yaXphdGlvbiBzdGF0ZSBpcyBzZXR0bGVkXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblx0fVxuXG5cdC8qKlxuXHQgKiBSZS1ldmFsdWF0ZXMgd2hldGhlciB0aGUgY3VycmVudCBob3N0K21vZGVsIGNvbWJpbmF0aW9uIGlzIGF1dGhvcml6ZWQuXG5cdCAqIENhbGxlZCBvbiBldmVyeSBjb25maWcgY2hhbmdlIHNvIHRoYXQgc3dpdGNoaW5nIG1vZGVsIG9yIElQIGlzIGFsd2F5cyB2YWxpZGF0ZWQuXG5cdCAqXG5cdCAqIFJ1bGVzOlxuXHQgKiAtIGRpc2NvdmVyZWRIb3N0IHNldCBcdTIxOTIgZGV2aWNlIGFscmVhZHkgdmVyaWZpZWQgYnkgRGFudGUsIGFsd2F5cyBhdXRob3JpemVcblx0ICogLSBtYW51YWwgaG9zdCBcdTIxOTIgY2hlY2sgYWdhaW5zdCBkaXNjb3ZlcmVkIGxpc3QgZmlyc3Q7IHByb2JlIGlmIHVua25vd25cblx0ICogICAtIGRpc2NvdmVyZWQgZGV2aWNlIGF0IHRoYXQgSVAgd2l0aCBtYXRjaGluZyBtb2RlbCBcdTIxOTIgYXV0aG9yaXplXG5cdCAqICAgLSBkaXNjb3ZlcmVkIGRldmljZSBhdCB0aGF0IElQIHdpdGggd3JvbmcgbW9kZWwgXHUyMTkyIHJldm9rZSArIGxvZyBlcnJvclxuXHQgKiAgIC0gbm90IGluIGRpc2NvdmVyZWQgbGlzdCBcdTIxOTIgcHJvYmU7IGF1dGhvcml6ZSBvbiBtYXRjaCwgcmV2b2tlIG9uIG1pc21hdGNoL3RpbWVvdXRcblx0ICovXG5cdHByaXZhdGUgYXN5bmMgdmVyaWZ5QXV0aG9yaXphdGlvbihwcmV2aW91c0hvc3Q6IHN0cmluZywgbmV3SG9zdDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0aWYgKCFuZXdIb3N0KSB7XG5cdFx0XHRpZiAocHJldmlvdXNIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY29uZmlnLmRpc2NvdmVyZWRIb3N0KSB7XG5cdFx0XHQvLyBEaXNjb3ZlcmVkIGRldmljZSBcdTIwMTQgaWRlbnRpdHkgY29uZmlybWVkIGJ5IERhbnRlLCBhbHdheXMgYXV0aG9yaXplZC5cblx0XHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRjb25zdCB3YXNBdXRob3JpemVkID0gdGhpcy5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKG5ld0hvc3QpXG5cdFx0XHRpZiAoIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRpZiAobmV3SG9zdCAhPT0gcHJldmlvdXNIb3N0IHx8ICF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdGNvbnN0IG1vZGVsID0gcmVzb2x2ZU1vZGVsKHRoaXMuY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHRcdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobW9kZWwsIG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBNYW51YWwgbW9kZSBcdTIwMTQgY29uZmlnLmhvc3QgKyBjb25maWcuYWN0aXZlTW9kZWwgbXVzdCBtYXRjaFxuXHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWxcblx0XHRjb25zdCBkaXNjb3ZlcmVkQXRJcCA9IHRoaXMuZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gbmV3SG9zdClcblxuXHRcdGlmIChkaXNjb3ZlcmVkQXRJcCkge1xuXHRcdFx0aWYgKGRpc2NvdmVyZWRBdElwLm1vZGVsID09PSBtYW51YWxNb2RlbCkge1xuXHRcdFx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdFx0Y29uc3Qgd2FzQXV0aG9yaXplZCA9IHRoaXMuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChuZXdIb3N0KVxuXHRcdFx0XHRpZiAoIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAobmV3SG9zdCAhPT0gcHJldmlvdXNIb3N0IHx8ICF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1hbnVhbE1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtkaXNjb3ZlcmVkQXRJcC5tb2RlbH0pIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgLFxuXHRcdFx0XHQpXG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gSVAgbm90IGluIGRpc2NvdmVyZWQgbGlzdCBcdTIwMTQgcHJvYmUgaXRcblx0XHRsb2dnZXIuaW5mbyhgJHtuZXdIb3N0fSBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iaW5nYClcblx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UobmV3SG9zdClcblxuXHRcdGNvbnN0IHByb2JlZCA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnByb2JlRGV2aWNlKG5ld0hvc3QpXG5cdFx0aWYgKCFwcm9iZWQpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihgTm8gZGV2aWNlIHJlc3BvbmRlZCBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYClcblx0XHR9IGVsc2UgaWYgKHByb2JlZC5tb2RlbCAhPT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihcblx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtwcm9iZWQubW9kZWx9KSBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYCxcblx0XHRcdClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFZlcmlmaWVkIE1vZGVsICR7cHJvYmVkLm1vZGVsfSBhdCAke25ld0hvc3R9YClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1hbnVhbE1vZGVsLCBuZXdIb3N0KVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBGZXRjaGVzIGFsbCBzZXR0aW5ncyBmcm9tIHRoZSBkZXZpY2UuIElmIG5vIHNjaGVtYSBleGlzdHMgZm9yIHRoZSBtb2RlbCxcblx0ICogY3JlYXRlcyBvbmUgZnJvbSB0aGUgcmVzcG9uc2UgYW5kIHJlbG9hZHMgdGhlIHNjaGVtYSBjYWNoZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtb2RlbDogc3RyaW5nLCBpcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGJ1ZiA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0aWYgKCFnZXREZXZpY2VTY2hlbWEobW9kZWwpKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBObyBzY2hlbWEgZm91bmQgZm9yIE1vZGVsICR7bW9kZWx9IFx1MjAxNCBjcmVhdGluZyBmcm9tIGRldmljZSByZXNwb25zZWApXG5cblx0XHRcdFx0Y29uc3QgeyBzZXR0aW5nczogcGFyc2VkLCBkZXRlY3RlZFNlY3Rpb25lZCB9ID0gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24obW9kZWwsIGJ1Zilcblx0XHRcdFx0aWYgKHBhcnNlZC5sZW5ndGggPT09IDApIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IHBhcnNlIHNldHRpbmdzIGZvciBNb2RlbCAke21vZGVsfSBcdTIwMTQgc2NoZW1hIG5vdCBjcmVhdGVkYClcblx0XHRcdFx0XHRyZXR1cm5cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhnZXREZXZpY2VTY2hlbWFzKCkpXG5cdFx0XHRcdGNvbnN0IG5ld1NjaGVtYSA9IHsgbW9kZWwsIHNlY3Rpb25lZDogZGV0ZWN0ZWRTZWN0aW9uZWQgPz8gZmFsc2UsIGNtZFNjaGVtYTogW10gYXMgYW55W10gfVxuXHRcdFx0XHRpZiAoZGV0ZWN0ZWRTZWN0aW9uZWQgIT09IG51bGwpIHtcblx0XHRcdFx0XHRuZXdTY2hlbWEuc2VjdGlvbmVkID0gZGV0ZWN0ZWRTZWN0aW9uZWRcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCB1cGRhdGVkID0gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKG5ld1NjaGVtYSBhcyBhbnksIHBhcnNlZCwgc2NoZW1hcyBhcyBhbnkpXG5cblx0XHRcdFx0Y29uc3Qgc2NoZW1hUGF0aCA9IHBhdGguam9pbihnZXREZXZpY2VzRm9sZGVyKCksIGBNb2RlbCR7bW9kZWx9Lmpzb25gKVxuXHRcdFx0XHRzYXZlTW9kZWxKc29uUHJldHR5KHNjaGVtYVBhdGgsIHVwZGF0ZWQpXG5cdFx0XHRcdHJlbG9hZERldmljZVNjaGVtYXMoKVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgQ3JlYXRlZCBzY2hlbWEgZm9yIE1vZGVsICR7bW9kZWx9IGF0ICR7c2NoZW1hUGF0aH1gKVxuXG5cdFx0XHRcdC8vIFJlLXN5bmMgbW9kZWwgbm93IHRoYXQgc2NoZW1hIGV4aXN0c1xuXHRcdFx0XHR0aGlzLnN5bmNNb2RlbChtb2RlbClcblx0XHRcdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHRcdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZmV0Y2ggc2V0dGluZ3MgZnJvbSAke2lwfTogJHtlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqIExvYWRzIHRoZSBkZXZpY2UgSlNPTiBmb3IgdGhlIGdpdmVuIG1vZGVsIGFuZCBwdXNoZXMgaXQgdG8gdGhlIGNvbnRyb2xsZXIuICovXG5cdHByaXZhdGUgc3luY01vZGVsKG1vZGVsOiBzdHJpbmcpOiB2b2lkIHtcblx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0aWYgKCFzY2hlbWEpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBNb2RlbCBcIiR7bW9kZWx9XCIgbm90IGZvdW5kIGluIGRldmljZSBzY2hlbWFzYClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBbXSwgdHJ1ZSlcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGNvbnN0IGFjdGlvbnMgPSBBcnJheS5pc0FycmF5KHNjaGVtYS5jbWRTY2hlbWEpID8gc2NoZW1hLmNtZFNjaGVtYSA6IFtdXG5cdFx0Y29uc3QgcmVmcmVzaEFmdGVyQ29tbWFuZCA9IHNjaGVtYS5yZWZyZXNoQWZ0ZXJDb21tYW5kID8/IHRydWVcblxuXHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBhY3Rpb25zLCByZWZyZXNoQWZ0ZXJDb21tYW5kKVxuXHRcdGlmIChhY3Rpb25zLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYE5vIGFjdGlvbnMgZm91bmQgZm9yIG1vZGVsIFwiJHttb2RlbH1cIiBcdTIwMTQgc2V0dGluZ3MgZGVjb2Rpbmcgd2lsbCB1c2UgcmF3IElEc2ApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0YExvYWRlZCAke2FjdGlvbnMubGVuZ3RofSBhY3Rpb25zIGZvciBtb2RlbCBcIiR7bW9kZWx9XCIsIHNlY3Rpb25lZD0ke3NjaGVtYS5zZWN0aW9uZWR9LCByZWZyZXNoQWZ0ZXJDb21tYW5kPSR7cmVmcmVzaEFmdGVyQ29tbWFuZH1gLFxuXHRcdFx0KVxuXHRcdH1cblx0fVxuXG5cdGdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdFx0cmV0dXJuIEdldENvbmZpZ0ZpZWxkcyh0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLCBwcmVmZXJyaW5nIHRoZSBkaXNjb3ZlcmVkIGRldmljZSBzZWxlY3Rpb24uICovXG5cdGdldCBob3N0KCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIHJlc29sdmVIb3N0KHRoaXMuY29uZmlnKVxuXHR9XG5cblx0LyoqIFJldHVybnMgZGlzY292ZXJlZCBkZXZpY2VzIGZvciB1c2UgaW4gYWN0aW9ucy9jb25maWcgKi9cblx0Z2V0IGRldmljZXMoKTogRGV2aWNlSW5mb1tdIHtcblx0XHRyZXR1cm4gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlc1xuXHR9XG5cblx0dXBkYXRlQWN0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVBY3Rpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVGZWVkYmFja3MoKTogdm9pZCB7XG5cdFx0VXBkYXRlRmVlZGJhY2tzKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlVmFsdWVzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHRoaXMpXG5cdH1cbn1cblxuZXhwb3J0IHsgVXBncmFkZVNjcmlwdHMgfVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7QUFrQkEsSUFBTSxxQkFBa0MsQ0FBQyxRQUFRLE9BQU8sWUFBVztBQUVsRSxVQUFRLElBQUksSUFBSSxNQUFNLFlBQVcsQ0FBRSxJQUFJLFNBQVMsS0FBSyxNQUFNLE1BQU0sRUFBRSxJQUFJLE9BQU8sRUFBRTtBQUNqRjtBQUVBLFNBQVMsVUFBVSxRQUE0QixPQUFpQixTQUFlO0FBQzlFLFFBQU0sT0FBTyxPQUFPLE9BQU8scUJBQXFCLGFBQWEsT0FBTyxtQkFBbUI7QUFDdkYsT0FBSyxRQUFRLE9BQU8sT0FBTztBQUM1QjtBQU9NLFNBQVUsbUJBQW1CLFFBQWU7QUFDakQsU0FBTztJQUNOLE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPO0lBQzlELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPOztBQUVoRTs7O0FDVE0sU0FBVSxZQUFZLE1BQVc7QUFFdkM7OztBQ2hDQSxTQUFTLG9CQUFvQjtBQTJFdkIsSUFBTyxzQkFBUCxjQUFtQyxhQUFtQztFQUNsRTtFQUNBO0VBRVQsSUFBVyxXQUFRO0FBQ2xCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBQ0EsSUFBVyxhQUFVO0FBQ3BCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBRUEsSUFBWSxhQUFVO0FBQ3JCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7QUFDbkQsYUFBTyxLQUFLO0lBQ2IsT0FBTztBQUNOLGFBQU87SUFDUjtFQUNEO0VBRUEsU0FBdUU7RUFFdkUsWUFBWSxTQUF5QyxTQUErQjtBQUNuRixVQUFLO0FBRUwsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVyxFQUFFLEdBQUcsUUFBTztFQUM3QjtFQUVBLEtBQUssTUFBYyxVQUFtQixVQUFxQjtBQUMxRCxRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLHlCQUF5QjtBQUM3RixZQUFRLEtBQUssUUFBUTtNQUNwQixLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sb0NBQW9DO01BQ3JELEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSx5QkFBeUI7TUFDMUMsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtNQUNwQyxLQUFLO0FBQ0o7TUFDRDtBQUNDLG9CQUFZLEtBQUssTUFBTTtBQUN2QixjQUFNLElBQUksTUFBTSxzQkFBc0I7SUFDeEM7QUFFQSxTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLGFBQWEsUUFBUTtBQUUzQyxTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFFBQVEsS0FBSyxTQUFTO01BQ3RCLFlBQVk7O0tBRVosRUFDQSxLQUNBLENBQUMsYUFBWTtBQUNaLFdBQUssU0FBUyxFQUFFLFlBQVksTUFBTSxTQUFRO0FBQzFDLFdBQUssU0FBUyx3QkFBd0IsSUFBSSxVQUFVLElBQUk7QUFDeEQsV0FBSyxLQUFLLFdBQVc7SUFDdEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVM7QUFDZCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLE1BQU0sVUFBcUI7QUFDMUIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtJQUVwRCxPQUFPO0FBQ04sY0FBUSxLQUFLLFFBQVE7UUFDcEIsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQ0FBb0M7UUFDckQsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9CQUFvQjtRQUNyQztBQUNDLHNCQUFZLEtBQUssTUFBTTtBQUN2QixnQkFBTSxJQUFJLE1BQU0sc0JBQXNCO01BQ3hDO0lBQ0Q7QUFFQSxVQUFNLFdBQVcsS0FBSyxPQUFPO0FBQzdCLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsU0FBUyxRQUFRO0FBRXZDLFNBQUssU0FDSCxxQkFBcUI7TUFDckI7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxPQUFPO0lBQ2xCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFXQSxLQUNDLGNBQ0EsY0FDQSxpQkFDQSxnQkFDQSxTQUNBLFVBQXFCO0FBRXJCLFFBQUksT0FBTyxpQkFBaUI7QUFBVSxZQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDekUsUUFBSSxPQUFPLG9CQUFvQixVQUFVO0FBQ3hDLFVBQUksT0FBTyxtQkFBbUIsWUFBWSxPQUFPLFlBQVk7QUFBVSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDMUcsVUFBSSxhQUFhLFVBQWEsT0FBTyxhQUFhO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRWpHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxjQUFjLGVBQWU7QUFDOUUsV0FBSyxXQUFXLFFBQVEsZ0JBQWdCLFNBQVMsUUFBUTtJQUMxRCxXQUFXLE9BQU8sb0JBQW9CLFVBQVU7QUFDL0MsVUFBSSxtQkFBbUIsVUFBYSxPQUFPLG1CQUFtQjtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUU3RyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsR0FBRyxNQUFTO0FBQzdELFdBQUssV0FBVyxRQUFRLGNBQWMsaUJBQWlCLGNBQWM7SUFDdEUsT0FBTztBQUNOLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtJQUNwQztFQUNEO0VBRUEsZUFDQyxjQUNBLFFBQ0EsUUFBMEI7QUFFMUIsUUFBSTtBQUNKLFFBQUksT0FBTyxpQkFBaUIsVUFBVTtBQUNyQyxlQUFTLE9BQU8sS0FBSyxjQUFjLE9BQU87SUFDM0MsV0FBVyxPQUFPLFNBQVMsWUFBWSxHQUFHO0FBQ3pDLGVBQVM7SUFDVixXQUFXLE1BQU0sUUFBUSxZQUFZLEdBQUc7QUFFdkMsYUFBTyxPQUFPLEtBQUssWUFBWTtJQUNoQyxPQUFPO0FBQ04sZUFBUyxPQUFPLEtBQUssYUFBYSxRQUFRLGFBQWEsWUFBWSxhQUFhLFVBQVU7SUFDM0Y7QUFFQSxXQUFPLE9BQU8sU0FBUyxRQUFRLFdBQVcsU0FBWSxTQUFTLFNBQVMsTUFBUztFQUNsRjtFQUVBLFdBQVcsUUFBZ0IsTUFBYyxTQUFpQixVQUFxQjtBQUM5RSxRQUFJLENBQUMsS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0sb0JBQW9CO0FBRXpGLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsVUFBVSxLQUFLLE9BQU87TUFDdEIsU0FBUztNQUVUO01BQ0E7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLGlCQUFVO0lBQ1gsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLHFCQUFxQixTQUErQjtBQUNuRCxRQUFJO0FBQ0gsV0FBSyxLQUFLLFdBQVcsUUFBUSxTQUFTLFFBQVEsTUFBTTtJQUNyRCxTQUFTLElBQUk7SUFFYjtFQUNEO0VBQ0EsbUJBQW1CLE9BQVk7QUFDOUIsU0FBSyxTQUFTO0FBRWQsVUFBTSxhQUFhLEtBQUs7QUFDeEIsUUFBSTtBQUFZLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxXQUFXLFFBQVE7QUFFaEYsUUFBSTtBQUNILFdBQUssS0FBSyxTQUFTLEtBQUs7SUFDekIsU0FBUyxJQUFJO0lBRWI7RUFDRDs7OztBQzlQSyxTQUFVLGtCQUFtRCxLQUFZO0FBQzlFLFFBQU0sT0FBTztBQUNiLFNBQU8sQ0FBQyxDQUFDLFFBQVEsT0FBTyxTQUFTLFlBQVksT0FBTyxLQUFLLE9BQU8sWUFBWSxLQUFLLHVCQUF1QjtBQUN6Rzs7O0FDNkJNLElBQWdCLGVBQWhCLE1BQTRCO0VBQ3hCO0VBQ0E7RUFFQTtFQUVULElBQVcsS0FBRTtBQUNaLFdBQU8sS0FBSyxTQUFTO0VBQ3RCO0VBRUEsSUFBVyxrQkFBZTtBQUN6QixXQUFPLEtBQUs7RUFDYjs7Ozs7RUFNQSxJQUFXLFFBQUs7QUFDZixXQUFPLEtBQUssU0FBUztFQUN0Qjs7OztFQUtBLFlBQVksVUFBaUI7QUFDNUIsUUFBSSxDQUFDLGtCQUE2QixRQUFRLEtBQUssQ0FBQyxTQUFTO0FBQ3hELFlBQU0sSUFBSSxNQUNULG1HQUFtRztBQUdyRyxTQUFLLFdBQVc7QUFFaEIsU0FBSyxVQUFVLG1CQUFrQjtBQUVqQyxTQUFLLHdCQUF3QixLQUFLLHNCQUFzQixLQUFLLElBQUk7QUFFakUsU0FBSyxXQUFXO01BQ2YsMkJBQTJCO01BQzNCLHdCQUF3Qjs7QUFHekIsU0FBSyxJQUFJLFNBQVMsY0FBYztFQUNqQztFQStCQSxXQUFXLFdBQTRDLFlBQWlDO0FBQ3ZGLFNBQUssU0FBUyxXQUFXLFdBQVcsVUFBVTtFQUMvQzs7Ozs7RUF1QkEscUJBQXFCLFNBQXlEO0FBQzdFLFNBQUssU0FBUyxxQkFBcUIsT0FBTztFQUMzQzs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7Ozs7RUFPQSxxQkFDQyxXQUNBLFNBQThDO0FBRTlDLFNBQUssU0FBUyxxQkFBcUIsV0FBVyxPQUFPO0VBQ3REOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixRQUFJLE1BQU0sUUFBUSxTQUFTO0FBQUcsWUFBTSxJQUFJLE1BQU0sd0RBQXdEO0FBRXRHLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7RUFNQSxrQkFBa0IsUUFBdUM7QUFDeEQsU0FBSyxTQUFTLGtCQUFrQixNQUFNO0VBQ3ZDOzs7Ozs7RUFPQSxpQkFBbUMsWUFBYTtBQUMvQyxXQUFPLEtBQUssU0FBUyxpQkFBaUIsVUFBVTtFQUNqRDs7OztFQUtBLG9CQUFpQjtBQUNoQixTQUFLLFNBQVMsa0JBQWlCO0VBQ2hDOzs7Ozs7O0VBUUEsZUFDQyxpQkFDRyxlQUFtRDtBQUV0RCxTQUFLLFNBQVMsZUFBZSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUM7RUFDOUQ7Ozs7O0VBTUEsc0JBQXNCLGFBQXFCO0FBQzFDLFNBQUssU0FBUyxtQkFBbUIsV0FBVztFQUM3Qzs7Ozs7O0VBT0Esb0JBQW9CLFdBQW1CO0FBQ3RDLFNBQUssU0FBUyxpQkFBaUIsU0FBUztFQUN6Qzs7Ozs7O0VBTUEsc0JBQXNCLFdBQW1CO0FBQ3hDLFNBQUssU0FBUyxtQkFBbUIsU0FBUztFQUMzQzs7Ozs7O0VBT0Esd0JBQXdCLGFBQXFCO0FBQzVDLFNBQUssU0FBUyxxQkFBcUIsV0FBVztFQUMvQzs7Ozs7O0VBT0EsYUFBYSxRQUFpQyxjQUFxQjtBQUNsRSxTQUFLLFNBQVMsYUFBYSxRQUFRLFlBQVk7RUFDaEQ7Ozs7Ozs7O0VBU0EsUUFBUSxNQUFjLE1BQWNBLE9BQWMsTUFBc0I7QUFDdkUsU0FBSyxTQUFTLFFBQVEsTUFBTSxNQUFNQSxPQUFNLElBQUk7RUFDN0M7Ozs7Ozs7Ozs7O0VBWUEsYUFBYSxRQUF3QixTQUF1QjtBQUMzRCxTQUFLLFNBQVMsYUFBYSxRQUFRLFdBQVcsSUFBSTtFQUNuRDs7Ozs7O0VBT0EsSUFBSSxPQUFpQixTQUFlO0FBQ25DLFlBQVEsT0FBTztNQUNkLEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0Q7QUFDQyxvQkFBWSxLQUFLO0FBQ2pCLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7SUFDRjtFQUNEO0VBWUEsc0JBQ0MsZUFDQSxVQUF5QztBQUV6QyxVQUFNLFVBQWtDLE9BQU8sa0JBQWtCLFdBQVcsRUFBRSxNQUFNLGNBQWEsSUFBSztBQUV0RyxVQUFNLFNBQVMsSUFBSSxvQkFBb0IsS0FBSyxVQUFVLE9BQU87QUFDN0QsUUFBSTtBQUFVLGFBQU8sR0FBRyxXQUFXLFFBQVE7QUFFM0MsV0FBTztFQUNSOzs7O0FDL1VELElBQVk7Q0FBWixTQUFZQyxpQkFBYztBQUN6QixFQUFBQSxnQkFBQSxJQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxZQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxtQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsV0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsZ0JBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHVCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx5QkFBQSxJQUFBO0FBQ0QsR0FWWSxtQkFBQSxpQkFBYyxDQUFBLEVBQUE7QUFhcEIsSUFBVztDQUFqQixTQUFpQkMsUUFBSztBQUVSLEVBQUFBLE9BQUEsS0FBSztBQUNMLEVBQUFBLE9BQUEsV0FDWjtBQUNZLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsT0FDWjtBQUNZLEVBQUFBLE9BQUEsY0FBYztBQUNkLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsUUFBUTtBQUNSLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsU0FBUztBQUNULEVBQUFBLE9BQUEsZ0JBQWdCO0FBQ2hCLEVBQUFBLE9BQUEsWUFBWTtBQUNaLEVBQUFBLE9BQUEsV0FDWjtBQUNGLEdBbEJpQixVQUFBLFFBQUssQ0FBQSxFQUFBOzs7QUNqQnRCLE9BQU8sUUFBUTtBQUNmLE9BQU8sVUFBVTtBQUlqQixJQUFNLFNBQVMsbUJBQW1CLFFBQVE7QUFxQjFDLFNBQVMsdUJBQW9CO0FBQzVCLFFBQU0sY0FBYyxLQUFLLEtBQUssWUFBWSxTQUFTLFlBQVk7QUFDL0QsUUFBTSxlQUFlLEtBQUssS0FBSyxZQUFZLFNBQVMsV0FBVztBQUcvRCxNQUFJLEdBQUcsV0FBVyxXQUFXLEdBQUc7QUFDL0IsV0FBTyxNQUFNLHlCQUF5QixXQUFXLEVBQUU7QUFDbkQsV0FBTztFQUNSO0FBR0EsTUFBSSxHQUFHLFdBQVcsWUFBWSxHQUFHO0FBQ2hDLFdBQU8sS0FBSyxxREFBcUQsWUFBWSxFQUFFO0FBQy9FLFdBQU87RUFDUjtBQUdBLFFBQU0sV0FBVzs7TUFBMEMsV0FBVztNQUFTLFlBQVk7O0FBQzNGLFNBQU8sTUFBTSxRQUFRO0FBQ3JCLFFBQU0sSUFBSSxNQUFNLFFBQVE7QUFDekI7QUFHQSxJQUFNLGdCQUFnQixxQkFBb0I7QUFHMUMsSUFBSSxxQkFBaUQ7QUFNL0MsU0FBVSxtQkFBZ0I7QUFDL0IsU0FBTztBQUNSO0FBTUEsU0FBUyxvQkFBaUI7QUFDekIsUUFBTSxVQUErQixDQUFBO0FBQ3JDLE1BQUk7QUFDSCxVQUFNLFFBQVEsR0FBRyxZQUFZLGFBQWEsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsT0FBTyxDQUFDO0FBRTdFLGVBQVcsS0FBSyxPQUFPO0FBQ3RCLFlBQU0sV0FBVyxLQUFLLEtBQUssZUFBZSxDQUFDO0FBQzNDLFlBQU0sT0FBTyxLQUFLLE1BQU0sR0FBRyxhQUFhLFVBQVUsTUFBTSxDQUFDO0FBQ3pELFVBQUksTUFBTSxPQUFPO0FBQ2hCLGdCQUFRLE9BQU8sS0FBSyxLQUFLLENBQUMsSUFBSTtNQUMvQjtJQUNEO0FBRUEsV0FBTyxNQUFNLFVBQVUsT0FBTyxLQUFLLE9BQU8sRUFBRSxNQUFNLDRCQUE0QjtFQUMvRSxTQUFTLEdBQUc7QUFDWCxXQUFPLE1BQU0sa0NBQWtDLENBQUMsRUFBRTtFQUNuRDtBQUNBLFNBQU87QUFDUjtBQU1NLFNBQVUsbUJBQWdCO0FBQy9CLE1BQUksQ0FBQyxvQkFBb0I7QUFDeEIseUJBQXFCLGtCQUFpQjtFQUN2QztBQUNBLFNBQU87QUFDUjtBQU1NLFNBQVUsZ0JBQWdCLE9BQWE7QUFDNUMsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxTQUFPLFFBQVEsS0FBSztBQUNyQjtBQU1NLFNBQVUsc0JBQW1CO0FBQ2xDLFNBQU8sS0FBSyx1Q0FBdUM7QUFDbkQsdUJBQXFCLGtCQUFpQjtBQUN2QztBQUtBLFNBQVMsc0JBQW1CO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsU0FBTyxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUk7QUFDakM7QUFFTSxTQUFVLGdCQUFnQixvQkFBa0MsQ0FBQSxHQUFFO0FBQ25FLFFBQU0sU0FBUyxvQkFBbUI7QUFLbEMsUUFBTSxnQkFBZ0I7SUFDckIsRUFBRSxJQUFJLElBQUksT0FBTyxTQUFRO0lBQ3pCLEdBQUcsa0JBQWtCLElBQUksQ0FBQyxPQUFPO01BQ2hDLElBQUksRUFBRTtNQUNOLE9BQU8sU0FBUyxFQUFFLEtBQUssS0FBSyxFQUFFLEVBQUU7TUFDL0I7O0FBR0gsU0FBTzs7OztJQUlOO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxTQUFTO01BQ1QsU0FBUzs7Ozs7SUFNVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsT0FBTyxNQUFNO01BQ2IscUJBQXFCO01BQ3JCLFNBQVM7Ozs7O0lBTVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUyxPQUFPLENBQUMsS0FBSztNQUN0QixTQUFTLE9BQU8sSUFBSSxDQUFDLFdBQVc7UUFDL0IsSUFBSTtRQUNKLE9BQU8sU0FBUyxLQUFLO1FBQ3BCO01BQ0YscUJBQXFCO01BQ3JCLFNBQVM7OztBQUdaO0FBTU0sU0FBVSxZQUFZLFFBQW9CO0FBQy9DLFNBQU8sT0FBTyxrQkFBa0IsT0FBTztBQUN4QztBQU9NLFNBQVUsYUFBYSxRQUFzQixtQkFBK0I7QUFDakYsTUFBSSxPQUFPLGdCQUFnQjtBQUMxQixVQUFNLFNBQVMsa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLGNBQWM7QUFDM0UsV0FBTyxNQUFNLGlDQUFpQyxPQUFPLGNBQWMsb0JBQW9CLFFBQVEsU0FBUyxNQUFNLEVBQUU7QUFDaEgsUUFBSSxRQUFRLE9BQU87QUFDbEIsYUFBTyxPQUFPO0lBQ2Y7QUFFQSxRQUFJLGtCQUFrQixXQUFXLEdBQUc7QUFDbkMsYUFBTyxLQUFLLDZEQUE2RDtBQUN6RSxhQUFPO0lBQ1I7RUFDRDtBQUNBLFNBQU8sTUFBTSw4Q0FBOEMsT0FBTyxXQUFXLEdBQUc7QUFDaEYsU0FBTyxPQUFPO0FBQ2Y7OztBQzlNTSxTQUFVLDBCQUEwQixNQUFvQjtBQUM3RCxPQUFLLHVCQUF1QjtJQUMzQixPQUFPLEVBQUUsTUFBTSxzQkFBcUI7SUFDcEMsV0FBVyxFQUFFLE1BQU0sdUNBQXNDO0lBQ3pELGNBQWMsRUFBRSxNQUFNLHNCQUFxQjtJQUMzQyxVQUFVLEVBQUUsTUFBTSwwQkFBeUI7SUFDM0MsU0FBUyxFQUFFLE1BQU0sZ0NBQStCO0lBQ2hELEtBQUssRUFBRSxNQUFNLHFCQUFvQjtJQUNqQyxJQUFJLEVBQUUsTUFBTSxvQkFBbUI7R0FDL0I7QUFDRjtBQUVBLElBQU0sb0JBQW9CO0VBQ3pCLE9BQU87RUFDUCxXQUFXO0VBQ1gsY0FBYztFQUNkLFVBQVU7RUFDVixTQUFTO0VBQ1QsS0FBSztFQUNMLElBQUk7O0FBUUMsU0FBVSxxQkFBcUIsTUFBb0I7QUFDeEQsUUFBTSxjQUFjLEtBQUs7QUFHekIsTUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLGFBQWEsbUJBQW1CLFdBQVcsR0FBRztBQUN2RSxTQUFLLGtCQUFrQixpQkFBaUI7QUFDeEM7RUFDRDtBQUVBLFFBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFdBQVc7QUFDNUQsTUFBSSxRQUFRO0FBQ1gsU0FBSyxrQkFBa0I7TUFDdEIsT0FBTyxPQUFPLFNBQVM7TUFDdkIsV0FBVyxPQUFPLGFBQWE7TUFDL0IsY0FBYyxPQUFPLGdCQUFnQjtNQUNyQyxVQUFVLE9BQU8sZ0JBQWdCO01BQ2pDLFNBQVMsT0FBTyxpQkFBaUI7TUFDakMsS0FBSyxPQUFPLE9BQU87TUFDbkIsSUFBSSxPQUFPO0tBQ1g7RUFDRixPQUFPO0FBR04sU0FBSyxrQkFBa0I7TUFDdEIsR0FBRztNQUNILElBQUk7S0FDSjtFQUNGO0FBQ0Q7OztBQzFETyxJQUFNLGlCQUErRDs7Ozs7Ozs7Ozs7Ozs7O0FDcUJyRSxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGNBQWM7QUFDcEIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sYUFBYTtBQUNuQixJQUFNLHVCQUF1QjtBQUM3QixJQUFNLG9CQUFvQjtBQUMxQixJQUFNLGVBQWU7QUFDckIsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxjQUFjO0FBR3JCLFNBQVUsZUFBZSxPQUFhO0FBQzNDLFVBQVEsT0FBTztJQUNkLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1I7QUFDQyxhQUFPLFNBQVMsTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDO0VBQ3JEO0FBQ0Q7QUFRTSxTQUFVLGNBQ2YsT0FDQSxPQUNBLFdBQ0EsT0FBdUI7QUFFdkIsUUFBTSxNQUFNLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUyxFQUFFLElBQUk7QUFDN0QsUUFBTSxLQUFLLE9BQU8sY0FBYyxXQUFXLFVBQVUsU0FBUyxFQUFFLElBQUk7QUFFcEUsTUFBSSxVQUFVLFFBQVc7QUFDeEIsVUFBTSxLQUFLLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUyxFQUFFLElBQUk7QUFDNUQsV0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRSxJQUFJLEVBQUU7RUFDbkM7QUFFQSxTQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxFQUFFO0FBQzdCO0FBU00sU0FBVSxNQUFNLE9BQWUsWUFBWSxHQUFDO0FBQ2pELFNBQU8sS0FBSyxNQUFNLFNBQVMsRUFBRSxFQUFFLFNBQVMsV0FBVyxHQUFHLENBQUM7QUFDeEQ7QUFPTSxTQUFVLFdBQVcsT0FBd0I7QUFDbEQsU0FBTyxLQUFLLE1BQU0sS0FBSyxLQUFLLEVBQzFCLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUUsQ0FBQztBQUNYO0FBU00sU0FBVSxlQUFlLEdBQVcsR0FBVyxHQUFTO0FBQzdELFNBQU8sSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQ2pCLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUUsRUFDUCxZQUFXLENBQUU7QUFDaEI7QUFRTSxTQUFVLGVBQWUsSUFBVTtBQUN4QyxRQUFNLENBQUMsT0FBTyxVQUFVLEtBQUssSUFBSSxHQUFHLE1BQU0sR0FBRztBQUM3QyxTQUFPO0lBQ047SUFDQSxPQUFPLFNBQVMsVUFBVSxFQUFFO0lBQzVCLFFBQVEsU0FBUyxPQUFPLEVBQUU7O0FBRTVCO0FBVU0sU0FBVSxjQUFjLFFBQWdCLFFBQWM7QUFDM0QsUUFBTSxLQUFLLFNBQVMsT0FBTyxRQUFRLE9BQU8sRUFBRSxHQUFHLEVBQUU7QUFDakQsUUFBTSxLQUFLLFNBQVMsT0FBTyxRQUFRLE9BQU8sRUFBRSxHQUFHLEVBQUU7QUFDakQsTUFBSSxPQUFPLE1BQU0sRUFBRSxLQUFLLE9BQU8sTUFBTSxFQUFFO0FBQUcsV0FBTztBQUNqRCxTQUFPLEtBQUssSUFBSSxLQUFLLEVBQUU7QUFDeEI7QUFTTSxTQUFVLHFCQUNmLFlBQStCO0FBRS9CLFFBQU0sYUFBa0UsQ0FBQTtBQUN4RSxhQUFXLENBQUMsT0FBTyxJQUFJLEtBQUssT0FBTyxRQUFRLFVBQVUsR0FBRztBQUN2RCxlQUFXLEtBQUssSUFBSTtNQUNuQixPQUFPLEtBQUs7TUFDWixXQUFXLE1BQU0sUUFBUSxLQUFLLFNBQVMsSUFBSSxLQUFLLFlBQVksQ0FBQTs7RUFFOUQ7QUFDQSxTQUFPO0FBQ1I7QUFZTSxTQUFVLHFCQUNmLFNBQ0EsT0FDQSxPQUNBLFdBQWlCO0FBRWpCLFFBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsTUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLFFBQVEsT0FBTyxTQUFTO0FBQUcsV0FBTztBQUd4RCxNQUFJLFNBQVMsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFXLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBR3ZGLE1BQUksQ0FBQyxRQUFRO0FBQ1osYUFBUyxPQUFPLFVBQVUsS0FBSyxDQUFDLE1BQVU7QUFDekMsVUFBSSxFQUFFLFdBQVc7QUFBTyxlQUFPO0FBQy9CLFlBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFDcEUsVUFBSSxDQUFDLGFBQWE7QUFBUyxlQUFPO0FBRWxDLFlBQU0sU0FBUyxZQUFZLEVBQUU7QUFDN0IsYUFBTyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU07SUFDNUQsQ0FBQztFQUNGO0FBRUEsU0FBTztBQUNSOzs7QUN0TUEsU0FBUyxZQUFZLEdBQU07QUFDMUIsUUFBTSxPQUFPO0lBQ1osTUFBTSxFQUFFO0lBQ1IsSUFBSSxFQUFFO0lBQ04sT0FBTyxFQUFFO0lBQ1QsU0FBUyxFQUFFO0lBQ1gsU0FBUyxFQUFFOztBQUdaLFVBQVEsRUFBRSxNQUFNO0lBQ2YsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sU0FBUyxFQUFFLFdBQVcsQ0FBQSxFQUFFO0lBRTNDLEtBQUs7QUFDSixhQUFPO1FBQ04sR0FBRztRQUNILEtBQUssRUFBRTtRQUNQLEtBQUssRUFBRTtRQUNQLE1BQU0sRUFBRSxRQUFRO1FBQ2hCLE9BQU87O0lBR1QsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sU0FBUyxFQUFFLFdBQVcsTUFBSztJQUU5QyxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTDtBQUNDLGFBQU87RUFDVDtBQUNEO0FBTU0sU0FBVSxlQUFZO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsUUFBTSxVQUFzQyxDQUFBO0FBRTVDLGFBQVcsQ0FBQyxPQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ3RELFVBQU0sWUFBWSxPQUFPO0FBQ3pCLFFBQUksQ0FBQyxNQUFNLFFBQVEsU0FBUztBQUFHO0FBRS9CLGVBQVcsS0FBSyxXQUFXO0FBQzFCLFlBQU0sV0FBVyxjQUFjLE9BQU8sRUFBRSxRQUFRLEVBQUUsRUFBRTtBQUVwRCxZQUFNLFdBQVcsRUFBRSxXQUFXLENBQUEsR0FBSSxJQUFJLFdBQVc7QUFFakQsWUFBTSxTQUFvQztRQUN6QyxNQUFNLFNBQVMsS0FBSyxLQUFLLEVBQUUsSUFBSTtRQUMvQjtRQUNBLFVBQVUsWUFBVztRQUVyQjs7QUFHRCxjQUFRLFFBQVEsSUFBSTtJQUNyQjtFQUNEO0FBRUEsU0FBTztBQUNSO0FBTU0sU0FBVSxpQkFBYztBQUM3QixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sWUFBMEMsQ0FBQTtBQUVoRCxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLFdBQVcsV0FBVztBQUNoQyxZQUFNLGlCQUFpQixjQUFjLE9BQU8sUUFBUSxRQUFRLFFBQVEsRUFBRTtBQUd0RSxZQUFNLGNBQWMsUUFBUSxXQUFXLENBQUEsR0FBSSxJQUFJLFdBQVc7QUFHMUQsWUFBTSxlQUFlLFdBQVcsT0FBTyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFHdkUsbUJBQWEsS0FBSztRQUNqQixNQUFNO1FBQ04sSUFBSTtRQUNKLE9BQU87UUFDUCxTQUFTO1FBQ1QsU0FBUztPQUNUO0FBR0QsWUFBTSxnQkFBcUI7UUFDMUIsTUFBTTtRQUNOLE1BQU0sU0FBUyxLQUFLLEtBQUssUUFBUSxJQUFJO1FBQ3JDLFNBQVM7UUFDVCxVQUFVLE1BQUs7QUFFZCxpQkFBTztRQUNSOztBQUdELGdCQUFVLGNBQWMsSUFBSTtJQUM3QjtFQUNEO0FBRUEsU0FBTztBQUNSOzs7QUM1SEEsT0FBT0MsV0FBVTs7O0FDTGpCLE9BQU9DLFNBQVE7QUFnQmYsSUFBTUMsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBeUNsRCxTQUFTLGVBQWUsT0FBYTtBQUNwQyxRQUFNLFNBQVMsb0JBQUksSUFBRztBQUN0QixNQUFJLFlBQVk7QUFFaEIsTUFBSTtBQUVILFVBQU0sT0FBTyxnQkFBZ0IsS0FBSztBQUNsQyxRQUFJLENBQUMsTUFBTTtBQUVWLGFBQU8sRUFBRSxXQUFXLE9BQU07SUFDM0I7QUFHQSxnQkFBWSxLQUFLLGFBQWE7QUFHOUIsZUFBVyxVQUFVLEtBQUssYUFBYSxDQUFBLEdBQUk7QUFDMUMsWUFBTSxpQkFBaUIsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLFNBQVMsYUFBYTtBQUMvRixVQUFJLGdCQUFnQjtBQUVuQixlQUFPLElBQUksT0FBTyxFQUFFO0FBR3BCLGNBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQXdCLElBQUksT0FBTyxPQUFPO0FBQ3BGLFlBQUksYUFBYSxTQUFTO0FBQ3pCLHFCQUFXLFVBQVUsWUFBWSxTQUFTO0FBQ3pDLGdCQUFJLE9BQU8sT0FBTyxPQUFPLFVBQVU7QUFDbEMscUJBQU8sSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFO1lBQ2pDO1VBQ0Q7UUFDRDtNQUNEO0lBQ0Q7RUFDRCxTQUFTLE1BQU07RUFFZjtBQUVBLFNBQU8sRUFBRSxXQUFXLE9BQU07QUFDM0I7QUFNQSxTQUFTLHNCQUFzQixLQUFXO0FBQ3pDLFFBQU0sV0FBVyxJQUFJLFFBQVEsT0FBTyxLQUFLLFVBQVUsQ0FBQztBQUNwRCxNQUFJLFdBQVc7QUFBRyxVQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFFbkUsUUFBTSxlQUFlLFdBQVc7QUFDaEMsTUFBSSxJQUFJLFlBQVksTUFBTSxJQUFNO0FBQy9CLFVBQU0sSUFBSSxNQUFNLHVDQUF1QyxJQUFJLFlBQVksRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO0VBQ3hGO0FBRUEsU0FBTztBQUNSO0FBTUEsU0FBUyx1QkFBdUIsT0FBZSxTQUFzQixvQkFBSSxJQUFHLEdBQUU7QUFDN0UsTUFBSSxJQUFJO0FBQ1IsUUFBTSxNQUF1QixDQUFBO0FBRTdCLFNBQU8sSUFBSSxNQUFNLFFBQVE7QUFDeEIsVUFBTSxLQUFLLE1BQU0sQ0FBQztBQUNsQixRQUFJLElBQUksS0FBSyxNQUFNO0FBQVE7QUFHM0IsUUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNLFFBQVE7QUFDM0MsVUFBSSxLQUFLO1FBQ1IsUUFBUTtRQUNSO1FBQ0EsWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxDQUFDO09BQ3JEO0FBQ0QsV0FBSztBQUNMO0lBQ0Q7QUFFQSxRQUFJLEtBQUssRUFBRSxRQUFRLGNBQWMsSUFBSSxZQUFZLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUU7QUFDakUsU0FBSztFQUNOO0FBRUEsU0FBTztBQUNSO0FBRU0sU0FBVSx5QkFBeUIsS0FBYSxPQUFhO0FBQ2xFLFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtFQUM3QztBQUVBLFFBQU0sV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUM1QixRQUFNLFFBQVEsTUFBTTtBQUNwQixRQUFNLE1BQU0sUUFBUTtBQUNwQixNQUFJLE1BQU0sSUFBSTtBQUFRLFVBQU0sSUFBSSxNQUFNLHNCQUFzQjtBQUU1RCxRQUFNLEVBQUUsT0FBTSxJQUFLLGVBQWUsS0FBSztBQUN2QyxTQUFPLHVCQUF1QixJQUFJLFNBQVMsT0FBTyxHQUFHLEdBQUcsTUFBTTtBQUMvRDtBQU1NLFNBQVUsOEJBQThCLEtBQWEsT0FBYTtBQUN2RSxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSw0QkFBNEI7RUFDN0M7QUFHQSxNQUFJLElBQUksVUFBVSx1QkFBdUIsTUFBTSxJQUFJLE1BQU07QUFDekQsUUFBTSxNQUFNLElBQUksU0FBUztBQUN6QixRQUFNLE1BQXVCLENBQUE7QUFHN0IsUUFBTSxFQUFFLE9BQU0sSUFBSyxlQUFlLEtBQUs7QUFHdkMsUUFBTSxvQkFBb0IsQ0FBQyxhQUFhLGlCQUFpQixXQUFXO0FBRXBFLFNBQU8sSUFBSSxJQUFJLEtBQUs7QUFDbkIsVUFBTSxTQUFTLElBQUksQ0FBQztBQUNwQixVQUFNLGVBQWUsSUFBSSxJQUFJLENBQUM7QUFFOUIsVUFBTSxhQUFhLElBQUksSUFBSTtBQUMzQixRQUFJLGFBQWE7QUFBSztBQUd0QixVQUFNLFdBQVcsa0JBQWtCLFNBQVMsWUFBWTtBQUV4RCxRQUFJO0FBQ0osUUFBSTtBQUNKLFFBQUk7QUFFSixRQUFJLFVBQVU7QUFFYixjQUFRLElBQUksSUFBSSxDQUFDO0FBQ2pCLGdCQUFVLElBQUksSUFBSSxDQUFDO0FBQ25CLFVBQUksSUFBSTtJQUNULE9BQU87QUFFTixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVDtBQUVBLFVBQU0sT0FBTyxJQUFJO0FBRWpCLFdBQU8sSUFBSSxJQUFJLE1BQU07QUFDcEIsWUFBTSxLQUFLLElBQUksQ0FBQztBQUNoQixVQUFJO0FBR0osVUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNO0FBQ25DLHFCQUFhLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLENBQUM7QUFDaEQsYUFBSztNQUNOLE9BQU87QUFDTixxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUM7QUFDeEIsYUFBSztNQUNOO0FBRUEsWUFBTSxVQUF5QjtRQUM5QixRQUFRO1FBQ1I7UUFDQTs7QUFFRCxVQUFJLFVBQVUsUUFBVztBQUN4QixnQkFBUSxRQUFRO01BQ2pCO0FBQ0EsVUFBSSxLQUFLLE9BQU87SUFDakI7QUFFQSxRQUFJO0VBQ0w7QUFFQSxTQUFPO0FBQ1I7QUFXTSxTQUFVLHNCQUFzQixPQUFlLEtBQVc7QUFDL0QsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0saUNBQWlDLE1BQU0sU0FBUyxFQUFFLENBQUMsR0FBRztFQUN2RTtBQUNBLFFBQU0sRUFBRSxVQUFTLElBQUssZUFBZSxLQUFLO0FBQzFDLFNBQU8sWUFBWSw4QkFBOEIsS0FBSyxLQUFLLElBQUkseUJBQXlCLEtBQUssS0FBSztBQUNuRztBQU1NLFNBQVUsb0JBQW9CLFNBQXdCLFNBQW1CO0FBRTlFLE1BQUksU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxRQUFRLFVBQVUsRUFBRSxPQUFPLFFBQVEsRUFBRTtBQUtuRixNQUFJLENBQUMsUUFBUTtBQUNaLFVBQU0sYUFBYSxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQ3JDLFVBQUksRUFBRSxXQUFXLFFBQVE7QUFBUSxlQUFPO0FBRXhDLFlBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDL0QsVUFBSSxDQUFDLGFBQWE7QUFBUyxlQUFPO0FBRWxDLFlBQU0sZ0JBQWdCLFFBQVEsS0FBSyxFQUFFO0FBQ3JDLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxhQUFhO0lBQzlELENBQUM7QUFDRCxRQUFJLFlBQVk7QUFDZixlQUFTO0lBQ1Y7RUFDRDtBQUVBLFFBQU0sU0FBUyxNQUFNLFFBQVEsTUFBTTtBQUNuQyxRQUFNLFFBQVEsTUFBTSxRQUFRLEVBQUU7QUFDOUIsUUFBTSxTQUFTLFdBQVcsUUFBUSxVQUFVO0FBQzVDLFFBQU0sU0FDTCxRQUFRLFdBQVcsV0FBVyxJQUMzQixlQUFlLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsR0FBRyxRQUFRLFdBQVcsQ0FBQyxDQUFDLElBQ2xGLFFBQVEsV0FBVyxXQUFXLElBQzdCLFFBQVEsV0FBVyxDQUFDLElBQ3BCLFFBQVEsV0FBVyxLQUFLLEdBQUc7QUFHaEMsUUFBTSxXQUFXLFFBQVEsVUFBVSxTQUFZLE9BQU8sUUFBUSxLQUFLLEtBQUs7QUFDeEUsUUFBTSxTQUFTLE9BQU8sTUFBTSxHQUFHLFFBQVEsT0FBTyxLQUFLLFFBQVEsTUFBTTtBQUdqRSxNQUFJLFFBQVE7QUFDWCxRQUFJLE9BQU8sT0FBTztBQUdsQixRQUFJLFFBQVEsVUFBVSxRQUFXO0FBQ2hDLGFBQU8sR0FBRyxJQUFJLE1BQU0sUUFBUSxRQUFRLENBQUM7SUFDdEMsT0FFSztBQUNKLFlBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsVUFBSSxhQUFhLFNBQVM7QUFDekIsY0FBTSxnQkFBZ0IsUUFBUSxLQUFLLE9BQU87QUFDMUMsY0FBTSxjQUFjLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtBQUMxRSxZQUFJLGFBQWE7QUFDaEIsaUJBQU8sR0FBRyxJQUFJLElBQUksWUFBWSxLQUFLO1FBQ3BDO01BQ0Q7SUFDRDtBQUdBLFVBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsUUFBSSxhQUFhLFdBQVcsUUFBUSxXQUFXLFdBQVcsR0FBRztBQUM1RCxZQUFNLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLFdBQVcsQ0FBQyxDQUFDO0FBQzdFLFVBQUksUUFBUTtBQUNYLGVBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSyxLQUFLLE1BQU07TUFDdkQ7SUFDRDtBQUNBLFdBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLE1BQU07RUFDdEM7QUFHQSxTQUFPLEdBQUcsTUFBTTtBQUNqQjtBQWlCTSxTQUFVLGlDQUNmLE9BQ0EsS0FBVztBQUVYLFFBQU0sU0FBUyxnQkFBZ0IsS0FBSztBQUNwQyxRQUFNLG9CQUFvQixRQUFRO0FBR2xDLE1BQUksc0JBQXNCLFFBQVc7QUFDcEMsVUFBTSxXQUFXLG9CQUNkLDhCQUE4QixLQUFLLEtBQUssSUFDeEMseUJBQXlCLEtBQUssS0FBSztBQUN0QyxXQUFPLEVBQUUsVUFBVSxtQkFBbUIsS0FBSTtFQUMzQztBQUdBLE1BQUksZUFBZ0MsQ0FBQTtBQUNwQyxNQUFJLG9CQUFxQyxDQUFBO0FBRXpDLE1BQUk7QUFDSCxtQkFBZSx5QkFBeUIsS0FBSyxLQUFLO0VBQ25ELFNBQVMsR0FBRztBQUNYLElBQUFBLFFBQU8sTUFBTSx1QkFBdUIsQ0FBQyxFQUFFO0VBQ3hDO0FBRUEsTUFBSTtBQUNILHdCQUFvQiw4QkFBOEIsS0FBSyxLQUFLO0VBQzdELFNBQVMsR0FBRztBQUNYLElBQUFBLFFBQU8sTUFBTSw0QkFBNEIsQ0FBQyxFQUFFO0VBQzdDO0FBR0EsTUFBSSxrQkFBa0IsU0FBUyxhQUFhLFFBQVE7QUFDbkQsSUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxrQkFBa0IsTUFBTSxZQUFZLGFBQWEsTUFBTSxHQUFHO0FBQ25ILFdBQU8sRUFBRSxVQUFVLG1CQUFtQixtQkFBbUIsS0FBSTtFQUM5RCxXQUFXLGFBQWEsU0FBUyxHQUFHO0FBQ25DLElBQUFBLFFBQU8sS0FBSyxtQ0FBbUMsYUFBYSxNQUFNLGlCQUFpQixrQkFBa0IsTUFBTSxHQUFHO0FBQzlHLFdBQU8sRUFBRSxVQUFVLGNBQWMsbUJBQW1CLE1BQUs7RUFDMUQsT0FBTztBQUVOLElBQUFBLFFBQU8sS0FBSyx1REFBdUQsS0FBSyxFQUFFO0FBQzFFLFdBQU8sRUFBRSxVQUFVLENBQUEsR0FBSSxtQkFBbUIsS0FBSTtFQUMvQztBQUNEO0FBRU0sU0FBVSw0QkFBNEIsT0FBZSxLQUFXO0FBQ3JFLFFBQU0sRUFBRSxVQUFTLElBQUssZUFBZSxLQUFLO0FBQzFDLFNBQU8sWUFBWSw4QkFBOEIsS0FBSyxLQUFLLElBQUkseUJBQXlCLEtBQUssS0FBSztBQUNuRztBQVNBLFNBQVMsbUJBQW1CLFlBQW9CO0FBQy9DLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsV0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxVQUFVLFNBQVMsV0FBVyxDQUFDLEVBQUM7RUFDN0U7QUFFQSxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFVBQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBQ2xCLFdBQU87TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE1BQU07TUFDTixTQUFTLGVBQWUsR0FBRyxHQUFHLENBQUM7O0VBRWpDO0FBRUEsU0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxPQUFPLFNBQVMsQ0FBQyxHQUFHLFVBQVUsRUFBQztBQUM1RTtBQU1NLFNBQVUsNEJBQ2YsV0FDQSxRQUNBLFdBQXNDO0FBRXRDLFFBQU0sTUFBTSxnQkFBZ0IsU0FBUztBQUdyQyxNQUFJLENBQUMsSUFBSSxXQUFXO0FBQ25CLFFBQUksWUFBWSxDQUFBO0VBQ2pCO0FBR0EsUUFBTSxhQUFhLE9BQU8sT0FBTyxTQUFTLEVBQ3hDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsVUFBVSxVQUFVLEtBQUssRUFDekMsS0FBSyxDQUFDLEdBQUcsTUFBTSxjQUFjLFVBQVUsT0FBTyxFQUFFLEtBQUssSUFBSSxjQUFjLFVBQVUsT0FBTyxFQUFFLEtBQUssQ0FBQztBQUVsRyxFQUFBQyxRQUFPLEtBQUssbUJBQW1CLFVBQVUsS0FBSyxFQUFFO0FBQ2hELEVBQUFBLFFBQU8sTUFBTSw2QkFBNkIsV0FBVyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLElBQUksQ0FBQyxFQUFFO0FBRXJGLGFBQVcsRUFBRSxRQUFRLElBQUksV0FBVSxLQUFNLFFBQVE7QUFDaEQsUUFBSSxTQUFTLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUV6RSxRQUFJLENBQUMsUUFBUTtBQUVaLGlCQUFXLEtBQUssWUFBWTtBQUMzQixjQUFNLFFBQVEsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ3pFLFlBQUksT0FBTztBQUNWLG1CQUFTLGdCQUFnQixLQUFLO0FBQzlCLGlCQUFPLE9BQU8sR0FBRyxNQUFNLElBQUkseUJBQXlCLEVBQUUsS0FBSztBQUMzRCxVQUFBQSxRQUFPLEtBQUssb0JBQW9CLE1BQU0sRUFBRSxDQUFDLGVBQWUsRUFBRSxLQUFLLEVBQUU7QUFDakU7UUFDRDtNQUNEO0lBQ0Q7QUFFQSxRQUFJLENBQUMsUUFBUTtBQUNaLGVBQVM7UUFDUjtRQUNBO1FBQ0EsTUFBTSxtQkFBbUIsTUFBTSxFQUFFLEVBQUUsWUFBVyxDQUFFO1FBQ2hELFNBQVMsQ0FBQyxtQkFBbUIsVUFBVSxDQUFDOztBQUV6QyxNQUFBQSxRQUFPLEtBQUssMkJBQTJCLE1BQU0sRUFBRSxDQUFDLEVBQUU7SUFDbkQsT0FBTztBQUNOLFlBQU0sTUFBTSxPQUFPLFVBQVUsQ0FBQztBQUM5QixVQUFJO0FBQUssWUFBSSxVQUFVLG1CQUFtQixVQUFVLEVBQUU7SUFDdkQ7QUFHQSxVQUFNLFNBQVMsSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxPQUFPLFVBQVUsRUFBRSxPQUFPLE9BQU8sRUFBRTtBQUN6RixRQUFJLENBQUM7QUFBUSxVQUFJLFVBQVUsS0FBSyxNQUFNO0VBQ3ZDO0FBRUEsU0FBTztBQUNSO0FBTU0sU0FBVSxvQkFBb0IsVUFBa0IsU0FBb0I7QUFDekUsTUFBSTtBQUVILFVBQU0sYUFBa0IsRUFBRSxPQUFPLFFBQVEsTUFBSztBQUc5QyxRQUFJLGVBQWUsU0FBUztBQUMzQixpQkFBVyxZQUFZLFFBQVE7SUFDaEM7QUFHQSxRQUFJLHlCQUF5QixTQUFTO0FBQ3JDLGlCQUFXLHNCQUFzQixRQUFRO0lBQzFDO0FBQ0EsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRO0lBQ2hDO0FBRUEsZUFBVyxPQUFPLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDdkMsVUFBSSxFQUFFLE9BQU8sYUFBYTtBQUN6QixtQkFBVyxHQUFHLElBQUssUUFBZ0IsR0FBRztNQUN2QztJQUNEO0FBR0EsUUFBSSxPQUFPLEtBQUssVUFBVSxZQUFZLE1BQU0sQ0FBQztBQUs3QyxXQUFPLEtBQUssUUFBUSwwREFBMEQsNkJBQTZCO0FBRTNHLElBQUFDLElBQUcsY0FBYyxVQUFVLE9BQU8sTUFBTSxNQUFNO0VBQy9DLFNBQVMsR0FBRztBQUNYLElBQUFELFFBQU8sTUFBTSxxQkFBcUIsQ0FBQyxFQUFFO0VBQ3RDO0FBQ0Q7OztBRGxnQkEsSUFBTUUsVUFBUyxtQkFBbUIsU0FBUztBQUVyQyxTQUFVLGNBQWMsTUFBb0I7QUFDakQsUUFBTSxhQUFhLGlCQUFnQjtBQUNuQyxRQUFNLGFBQWEsYUFBWTtBQUMvQixRQUFNLFVBQVUscUJBQXFCLFVBQVU7QUFDL0MsUUFBTSxlQUFvQixDQUFBO0FBRzFCLFFBQU0sY0FBYyxhQUFhLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDMUQsRUFBQUEsUUFBTyxLQUNOLCtCQUErQixXQUFXLHNCQUFzQixLQUFLLE9BQU8sY0FBYyxvQkFBb0IsS0FBSyxRQUFRLE1BQU0sRUFBRTtBQVFwSSxNQUFJLEtBQUssYUFBYSxtQkFBbUIsS0FBSyxJQUFJLEdBQUc7QUFDcEQsaUJBQWEsdUJBQXVCLElBQUk7TUFDdkMsTUFBTTtNQUNOLFNBQVMsQ0FBQTtNQUNULFVBQVUsWUFBVztBQUNwQixjQUFNLFFBQVE7QUFDZCxjQUFNLEtBQUssS0FBSztBQUVoQixjQUFNLE1BQU0sTUFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUU7QUFHekQsWUFBSSxZQUFZLGdCQUFnQixLQUFLO0FBQ3JDLFlBQUksQ0FBQyxXQUFXO0FBQ2YsVUFBQUEsUUFBTyxNQUFNLFNBQVMsS0FBSyw0QkFBNEI7QUFDdkQ7UUFDRDtBQUdBLGNBQU0sRUFBRSxVQUFVLFFBQVEsa0JBQWlCLElBQUssaUNBQWlDLE9BQU8sR0FBRztBQUMzRixRQUFBQSxRQUFPLE1BQU0saUJBQWlCLEtBQUssVUFBVSxNQUFNLENBQUMsRUFBRTtBQUd0RCxZQUFJLHNCQUFzQixNQUFNO0FBQy9CLFVBQUFBLFFBQU8sS0FBSywyQkFBMkIsaUJBQWlCLHdCQUF3QjtBQUNoRixzQkFBWSxFQUFFLEdBQUcsV0FBVyxXQUFXLGtCQUFpQjtRQUN6RDtBQUVBLGNBQU0sVUFBVSw0QkFBNEIsV0FBVyxRQUFRLE9BQU87QUFDdEUsUUFBQUEsUUFBTyxNQUFNLHFCQUFxQixLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUMsQ0FBQyxFQUFFO0FBR3BFLGNBQU1DLGlCQUFnQixpQkFBZ0I7QUFDdEMsY0FBTSxhQUFhQyxNQUFLLEtBQUtELGdCQUFlLFFBQVEsS0FBSyxPQUFPO0FBQ2hFLDRCQUFvQixZQUFZLE9BQU87QUFHdkMsNEJBQW1CO0FBRW5CLFFBQUFELFFBQU8sS0FBSyxTQUFTLEtBQUssd0NBQXdDO01BQ25FOztFQUVGO0FBTUEsYUFBVyxDQUFDLFVBQVUsTUFBTSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDNUQsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxRQUFRO0FBR3hELFFBQUksVUFBVTtBQUFhO0FBRzNCLFVBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsVUFBTSxZQUFZLFFBQVEsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sTUFBTTtBQUUzRixpQkFBYSxRQUFRLElBQUk7TUFDeEIsR0FBRztNQUNILFVBQVUsT0FBTyxVQUFjO0FBQzlCLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBQ3pGLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTztBQUNuQyxjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxjQUFNLFlBQVksU0FBUztBQUUzQixjQUFNLEtBQUssYUFBYSxhQUFhLGFBQWEsT0FBTyxPQUFPLFdBQVcsT0FBTyxFQUFFO01BQ3JGOztFQUVGO0FBS0EsUUFBTSxlQUFlLFFBQVEsV0FBVztBQUN4QyxNQUFJLGNBQWM7QUFDakIsVUFBTSxtQkFBbUIsYUFBYSxhQUFhLENBQUEsR0FBSSxLQUFLLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxNQUFNLENBQUM7QUFFL0YsUUFBSSxpQkFBaUI7QUFDcEIsWUFBTSxXQUFXLEdBQUcsV0FBVztBQUUvQixtQkFBYSxRQUFRLElBQUk7UUFDeEIsTUFBTSxTQUFTLFdBQVc7UUFDMUIsU0FBUyxDQUFBO1FBQ1QsVUFBVSxZQUFXO0FBQ3BCLGdCQUFNLEtBQUssS0FBSztBQUNoQixVQUFBQSxRQUFPLEtBQUsseUJBQW9CLFdBQVcsTUFBTSxFQUFFLEVBQUU7QUFDckQsZ0JBQU0sS0FBSyxhQUFhLGNBQWMsYUFBYSxFQUFFO1FBQ3REOztJQUVGO0VBQ0Q7QUFFQSxPQUFLLHFCQUFxQixZQUFZO0FBRXRDLEVBQUFBLFFBQU8sS0FBSyxpQ0FBaUMsT0FBTyxLQUFLLFlBQVksRUFBRSxNQUFNLEVBQUU7QUFDaEY7OztBRXRIQSxJQUFNRyxVQUFTLG1CQUFtQixXQUFXO0FBSzdDLFNBQVMsaUJBQ1IsU0FDQSxPQUNBLE9BQ0EsV0FDQSxPQUFhO0FBRWIsUUFBTSxVQUFVLHFCQUFxQixTQUFTLE9BQU8sT0FBTyxTQUFTO0FBQ3JFLE1BQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxRQUFRLFFBQVEsT0FBTztBQUFHLFdBQU87QUFHeEQsUUFBTSxjQUFjLFFBQVEsUUFBUSxLQUFLLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUN6RSxNQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sUUFBUSxZQUFZLE9BQU87QUFBRyxXQUFPO0FBR2hFLFFBQU0sU0FBUyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLEtBQUs7QUFDbEUsU0FBTyxRQUFRLFNBQVM7QUFDekI7QUFNTSxTQUFVLGdCQUFnQixNQUFvQjtBQUNuRCxRQUFNLGFBQWEsaUJBQWdCO0FBQ25DLFFBQU0sZUFBZSxlQUFjO0FBQ25DLFFBQU0sVUFBVSxxQkFBcUIsVUFBVTtBQUMvQyxRQUFNLGlCQUFzQixDQUFBO0FBRzVCLFFBQU0sY0FBYyxhQUFhLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDMUQsRUFBQUEsUUFBTyxLQUNOLGlDQUFpQyxXQUFXLHNCQUFzQixLQUFLLE9BQU8sY0FBYyxvQkFBb0IsS0FBSyxRQUFRLE1BQU0sRUFBRTtBQU90SSxhQUFXLENBQUMsWUFBWSxRQUFRLEtBQUssT0FBTyxRQUFRLFlBQVksR0FBRztBQUNsRSxVQUFNLEVBQUUsT0FBTyxPQUFPLE9BQU0sSUFBSyxlQUFlLFVBQVU7QUFHMUQsUUFBSSxVQUFVO0FBQWE7QUFHM0IsbUJBQWUsVUFBVSxJQUFJO01BQzVCLEdBQUc7TUFDSCxVQUFVLENBQUMsa0JBQXNCO0FBQ2hDLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxjQUFjLFFBQVEsT0FBTztBQUMzQyxjQUFNLFFBQVEsY0FBYyxRQUFRLE9BQU8sS0FBSztBQUNoRCxjQUFNLFlBQVksU0FBUztBQUMzQixjQUFNLFVBQVUsS0FBSyxhQUFhLGdCQUFnQixJQUFJLE9BQU8sV0FBVyxLQUFLO0FBRzdFLGNBQU0sWUFBWSxjQUFjLFFBQVEsV0FBVyxLQUFLO0FBRXhELFlBQUksYUFBYSxZQUFZLFFBQVc7QUFFdkMsaUJBQU8saUJBQWlCLFNBQVMsT0FBTyxPQUFPLFdBQVcsT0FBTztRQUNsRTtBQUdBLGVBQU8sV0FBVztNQUNuQjs7RUFFRjtBQUVBLE9BQUssdUJBQXVCLGNBQWM7QUFFMUMsRUFBQUEsUUFBTyxLQUFLLHFDQUFxQyxPQUFPLEtBQUssY0FBYyxFQUFFLE1BQU0sRUFBRTtBQUN0Rjs7O0FDbkZBLE9BQU9DLFlBQVc7OztBQ0FsQixPQUFPLFdBQVc7QUFDbEIsT0FBTyxRQUFRO0FBSWYsSUFBTUMsVUFBUyxtQkFBbUIsT0FBTztBQUtsQyxJQUFNLHlCQUF5QjtBQUUvQixJQUFNLDBCQUEwQjtBQWdCaEMsSUFBTSxxQkFBcUIsTUFBTztBQWlCbkMsU0FBVSx3QkFBcUI7QUFDcEMsUUFBTSxNQUFNLE9BQU8sTUFBTSxJQUFJLENBQUM7QUFDOUIsUUFBTSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU0sSUFBSyxLQUFNO0FBRTdDLE1BQUksY0FBYyxPQUFRLENBQUM7QUFDM0IsTUFBSSxjQUFjLHdCQUF3QixDQUFDO0FBQzNDLE1BQUksY0FBYyxLQUFLLENBQUM7QUFFeEIsUUFBTSxNQUFNLGlCQUFnQjtBQUM1QixNQUFJLEtBQUssS0FBSyxDQUFDO0FBRWYsU0FBTyxLQUFLLFlBQVksT0FBTyxFQUFFLEtBQUssS0FBSyxFQUFFO0FBQzdDLE1BQUksY0FBYyxNQUFRLEVBQUU7QUFDNUIsTUFBSSxjQUFjLEtBQVEsRUFBRTtBQUM1QixNQUFJLGNBQWMsS0FBWSxFQUFFO0FBRWhDLFNBQU87QUFDUjtBQUdNLFNBQVUsbUJBQWdCO0FBQy9CLE1BQUk7QUFDSCxVQUFNLFNBQVMsR0FBRyxrQkFBaUI7QUFDbkMsZUFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMsaUJBQVcsUUFBUSxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdEMsWUFBSSxDQUFDLEtBQUssWUFBWSxLQUFLLFdBQVcsVUFBVSxLQUFLLE9BQU8sS0FBSyxRQUFRLHFCQUFxQjtBQUM3RixpQkFBTyxPQUFPLEtBQUssS0FBSyxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFjLFNBQVMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUMzRTtNQUNEO0lBQ0Q7RUFDRCxRQUFRO0VBRVI7QUFDQSxTQUFPLE9BQU8sTUFBTSxHQUFHLENBQUM7QUFDekI7QUFpQk0sU0FBVSx1QkFBdUIsS0FBYSxPQUFhO0FBQ2hFLE1BQUksSUFBSSxTQUFTO0FBQW9CLFdBQU87QUFDNUMsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVEsV0FBTztBQUMzQyxNQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBeUIsV0FBTztBQUM1RCxNQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZLFdBQU87QUFFbEUsUUFBTSxVQUFVLENBQUMsUUFBZ0IsUUFDaEMsSUFDRSxTQUFTLFFBQVEsU0FBUyxHQUFHLEVBQzdCLFNBQVMsT0FBTyxFQUNoQixNQUFNLElBQUksRUFBRSxDQUFDLEVBQ2IsS0FBSTtBQUVQLFFBQU0sUUFBUSxJQUFJLFNBQVMsR0FBRyxFQUFFO0FBQ2hDLFFBQU0sV0FBVyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQzVFLFFBQU0sTUFBTSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUV6RSxRQUFNLE9BQU8sUUFBUSxJQUFNLEVBQUU7QUFDN0IsUUFBTSxlQUFlLFFBQVEsSUFBTSxFQUFFO0FBQ3JDLFFBQU0sV0FBVyxRQUFRLEtBQU0sRUFBRTtBQUNqQyxRQUFNLGdCQUFnQixHQUFHLElBQUksRUFBSSxDQUFDLElBQUksSUFBSSxFQUFJLENBQUM7QUFFL0MsTUFBSSxDQUFDO0FBQVUsV0FBTztBQUl0QixRQUFNLFFBQVEsU0FDWixRQUFRLGNBQWMsRUFBRSxFQUN4QixLQUFJLEVBQ0osTUFBTSxLQUFLLEVBQUUsQ0FBQztBQUVoQixTQUFPO0lBQ04sSUFBSTtJQUNKO0lBQ0E7SUFDQTtJQUNBLFdBQVc7O0lBQ1g7SUFDQTs7QUFFRjtBQU9BLGVBQXNCLHFCQUFxQixRQUFjO0FBQ3hELFNBQU8sSUFBSSxRQUFrQixDQUFDLFNBQVMsV0FBVTtBQUNoRCxVQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFFckMsUUFBSSxLQUFLLFNBQVMsQ0FBQyxRQUFPO0FBQ3pCLFVBQUksTUFBSztBQUNULGFBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQzdDLENBQUM7QUFFRCxRQUFJLFFBQVEsR0FBRyxRQUFRLE1BQUs7QUFDM0IsVUFBSTtBQUNILGNBQU0sT0FBTyxJQUFJLFFBQU87QUFDeEIsY0FBTSxZQUFZLEtBQUs7QUFDdkIsWUFBSSxNQUFLO0FBRVQsY0FBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLG1CQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxxQkFBVyxTQUFTLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN2QyxnQkFDQyxNQUFNLFdBQVcsVUFDakIsTUFBTSxZQUFZLGFBQ2xCLE1BQU0sT0FDTixNQUFNLFFBQVEscUJBQ2I7QUFDRCxxQkFBTyxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxTQUFTLEdBQUcsRUFBRSxJQUFJLEdBQUksQ0FBQztZQUN2RTtVQUNEO1FBQ0Q7QUFDQSxlQUFPLElBQUksTUFBTSx3Q0FBd0MsU0FBUyxFQUFFLENBQUM7TUFDdEUsU0FBUyxJQUFJO0FBQ1osZUFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztNQUM3QjtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7QUFNQSxlQUFzQiw4QkFBOEIsUUFBYztBQUNqRSxTQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksV0FBVztBQUNmLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLENBQUMsVUFBVTtBQUNkLG1CQUFXO0FBQ1gsWUFBSSxNQUFLO0FBQ1QsZUFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDN0M7SUFDRCxDQUFDO0FBR0QsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxrQkFBUSxTQUFTO1FBQ2xCO01BQ0QsU0FBUyxJQUFJO0FBQ1osWUFBSSxDQUFDLFVBQVU7QUFDZCxxQkFBVztBQUNYLGNBQUksTUFBSztBQUNULGlCQUFPLElBQUksTUFBTSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQzdCO01BQ0Q7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBZ0JBLGVBQXNCLGdCQUNyQixVQUNBLGdCQUNBLGtCQUNBLFlBQVksS0FBSTtBQUVoQixRQUFNLHVCQUF1QjtBQUM3QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLGVBQWU7QUFFckIsUUFBTSxRQUFRLG9CQUFJLElBQUc7QUFDckIsUUFBTSxhQUFhLG9CQUFJLElBQUc7QUFFMUIsU0FBTyxJQUFJLFFBQXNCLENBQUMsWUFBVztBQUs1QyxVQUFNLGlCQUFpQixNQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFM0UsVUFBTSxVQUFVLE1BQUs7QUFDcEIsVUFBSTtBQUNILHVCQUFlLGVBQWUsb0JBQW9CO01BQ25ELFFBQVE7TUFFUjtBQUNBLFVBQUk7QUFDSCx1QkFBZSxNQUFLO01BQ3JCLFFBQVE7TUFFUjtBQUNBLGNBQVEsTUFBTSxLQUFLLE1BQU0sT0FBTSxDQUFFLENBQUM7SUFDbkM7QUFFQSxVQUFNLFFBQVEsV0FBVyxTQUFTLFNBQVM7QUFDM0MsVUFBTSxRQUFPO0FBRWIsbUJBQWUsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNsQyxNQUFBQSxRQUFPLEtBQUssMEJBQTBCLElBQUksT0FBTyxFQUFFO0lBQ3BELENBQUM7QUFFRCxtQkFBZSxHQUFHLFdBQVcsQ0FBQyxLQUFLLFVBQVM7QUFDM0MsWUFBTSxRQUFRLE1BQU07QUFFcEIsVUFBSSxJQUFJLFNBQVM7QUFBSTtBQUNyQixVQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBUTtBQUNwQyxVQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBRTNELFVBQUksV0FBVyxJQUFJLEtBQUs7QUFBRztBQUMzQixpQkFBVyxJQUFJLEtBQUs7QUFDcEIsTUFBQUEsUUFBTyxNQUFNLGlCQUFpQixLQUFLLCtCQUEwQjtBQUs3RCx1QkFBaUIsS0FBSyxFQUNwQixLQUFLLE1BQUs7QUFDVixjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGlCQUFTLEtBQUssT0FBTyxjQUFjLE9BQU8sQ0FBQyxRQUFPO0FBQ2pELGNBQUk7QUFBSyxZQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssWUFBWSxJQUFJLE9BQU8sRUFBRTtRQUN4RSxDQUFDO01BQ0YsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxRQUFRQSxRQUFPLEtBQUssdUJBQXVCLEdBQUcsRUFBRSxDQUFDO0lBQzNELENBQUM7QUFFRCxtQkFBZSxLQUFLLHFCQUFxQixNQUFLO0FBQzdDLFVBQUk7QUFDSCx1QkFBZSxjQUFjLG9CQUFvQjtBQUNqRCxRQUFBQSxRQUFPLEtBQUssb0NBQW9DLG9CQUFvQixJQUFJLG1CQUFtQixFQUFFO01BQzlGLFNBQVMsS0FBSztBQUNiLFFBQUFBLFFBQU8sS0FBSyw0Q0FBNEMsR0FBRyxFQUFFO01BQzlEO0lBQ0QsQ0FBQztFQUdGLENBQUM7QUFDRjs7O0FEbFJBLElBQU1DLFVBQVMsbUJBQW1CLGNBQWM7QUFFMUMsSUFBTyxlQUFQLE1BQU8sY0FBWTtFQUNQLGNBQXNCO0VBQ3RCLGlCQUFpQjtFQUNqQixTQUFTO0VBRWxCO0VBQ0E7O0VBQ0E7RUFJQSxtQkFBZ0Msb0JBQUksSUFBRzs7O0VBR3ZDLFlBQTJCLFFBQVEsUUFBTzs7RUFHMUMsc0JBQXNCOztFQUd0Qjs7RUFHQSxRQUFnQjtFQUNoQixVQUFzQixDQUFBO0VBQ3RCLHNCQUErQjs7Ozs7Ozs7RUFRL0IsY0FBZ0Qsb0JBQUksSUFBRzs7Ozs7OztFQVF2RCxnQkFBNkIsb0JBQUksSUFBRzs7RUFHcEMscUJBQWdFLG9CQUFJLElBQUc7O0VBR3ZFO0VBRVIsY0FBQTtBQUNDLElBQUFBLFFBQU8sS0FBSywwQkFBMEI7QUFFdEMsU0FBSyxjQUFjLG9CQUFJLElBQUc7QUFJMUIsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDcEUsU0FBSyxVQUFVLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDNUMsV0FBSyxTQUFTLEtBQUssR0FBRyxNQUFLO0FBQzFCLFFBQUFELFFBQU8sTUFBTSwyQkFBNEIsS0FBSyxTQUFTLFFBQU8sRUFBd0IsSUFBSSxFQUFFO0FBQzVGLGdCQUFPO01BQ1IsQ0FBQztJQUNGLENBQUM7QUFDRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBR0QsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFcEUsU0FBSyxTQUFTLEdBQUcsYUFBYSxNQUFLO0FBQ2xDLFlBQU0sT0FBTyxLQUFLLFNBQVMsUUFBTztBQUNsQyxNQUFBRCxRQUFPLE1BQU0sMEJBQTBCLEtBQUssVUFBVSxJQUFJLENBQUMsRUFBRTtBQUM3RCxVQUFJO0FBQ0gsYUFBSyxTQUFTLHFCQUFxQixJQUFJO01BQ3hDLFNBQVMsSUFBSTtNQUViO0lBQ0QsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzFDLFVBQUk7QUFDSCxhQUFLLGVBQWUsS0FBSyxNQUFNLE9BQU87TUFDdkMsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxFQUFFLEVBQUU7TUFDdEQ7SUFDRCxDQUFDO0FBR0QsU0FBSyxTQUFTLEtBQUssRUFBRSxTQUFTLFdBQVcsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2xFLE1BQUFBLFFBQU8sTUFBTSw4QkFBOEIsS0FBSyxNQUFNLEVBQUU7SUFDekQsQ0FBQztFQUNGO0VBRU8sUUFBSztBQUNYLFFBQUk7QUFDSCxpQkFBVyxhQUFhLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixHQUFHO0FBQzFELFlBQUk7QUFDSCxlQUFLLFNBQVMsZUFBZSxLQUFLLGdCQUFnQixTQUFTO1FBQzVELFFBQVE7UUFFUjtNQUNEO0lBQ0QsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7RUFDRDs7Ozs7RUFNTyxTQUFTLE9BQWUsU0FBcUIsc0JBQStCLE1BQUk7QUFDdEYsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVO0FBQ2YsU0FBSyxzQkFBc0I7RUFDNUI7Ozs7O0VBTU8sb0JBQW9CLFVBQXNDO0FBQ2hFLFNBQUssbUJBQW1CO0VBQ3pCOztFQUdPLG1CQUFtQixJQUFVO0FBQ25DLFdBQU8sS0FBSyxjQUFjLElBQUksRUFBRTtFQUNqQzs7RUFHTyxnQkFBZ0IsSUFBVTtBQUNoQyxTQUFLLGNBQWMsSUFBSSxFQUFFO0FBQ3pCLElBQUFBLFFBQU8sTUFBTSx3QkFBd0IsRUFBRSxFQUFFO0VBQzFDOztFQUdPLGFBQWEsSUFBVTtBQUM3QixTQUFLLGNBQWMsT0FBTyxFQUFFO0FBQzVCLFNBQUssWUFBWSxPQUFPLEVBQUU7QUFDMUIsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixFQUFFLEVBQUU7RUFDdkM7Ozs7Ozs7RUFRTyxNQUFNLFlBQVksSUFBWSxZQUFZLEtBQUk7QUFDcEQsV0FBTyxJQUFJLFFBQTJCLENBQUMsWUFBVztBQUNqRCxZQUFNLE1BQU0sV0FBVyxFQUFFO0FBQ3pCLFVBQUksV0FBVztBQUVmLFlBQU0sU0FBUyxDQUFDLFdBQTZCO0FBQzVDLFlBQUk7QUFBVTtBQUNkLG1CQUFXO0FBQ1gsYUFBSyxtQkFBbUIsT0FBTyxHQUFHO0FBQ2xDLGdCQUFRLE1BQU07TUFDZjtBQUVBLFdBQUssbUJBQW1CLElBQUksS0FBSyxDQUFDLFdBQXNCO0FBQ3ZELFlBQUksT0FBTyxPQUFPO0FBQUksaUJBQU8sTUFBTTtNQUNwQyxDQUFDO0FBRUQsWUFBTSxRQUFRLFdBQVcsTUFBTSxPQUFPLElBQUksR0FBRyxTQUFTO0FBQ3RELFlBQU0sUUFBTztBQUViLFdBQUssb0JBQW9CLEVBQUUsRUFDekIsS0FBSyxZQUFZLEtBQUssT0FBTyxFQUM3QixLQUFLLE1BQUs7QUFDVixjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGFBQUssU0FBUyxLQUFLLE9BQU8sS0FBSyxhQUFhLElBQUksQ0FBQyxRQUFPO0FBQ3ZELGNBQUksS0FBSztBQUNSLFlBQUFBLFFBQU8sS0FBSyxZQUFZLEVBQUUsWUFBWSxJQUFJLE9BQU8sRUFBRTtBQUNuRCx5QkFBYSxLQUFLO0FBQ2xCLG1CQUFPLElBQUk7VUFDWjtRQUNELENBQUM7TUFDRixDQUFDLEVBQ0EsTUFBTSxDQUFDLE1BQUs7QUFDWixRQUFBQSxRQUFPLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLEVBQUU7QUFDdEQscUJBQWEsS0FBSztBQUNsQixlQUFPLElBQUk7TUFDWixDQUFDO0lBQ0gsQ0FBQztFQUNGOzs7OztFQU1PLE1BQU0sbUJBQW1CLFVBQWdCO0FBQy9DLElBQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsUUFBUSxFQUFFO0FBQ3RELFVBQU0sV0FBVyxNQUFNLEtBQUssYUFDM0IsS0FBSyxPQUNMLHNCQUNBLFFBQ0EsUUFDQSxRQUNBLFVBQ0EsS0FBSztBQUdOLFdBQU87RUFDUjs7RUFHTyxlQUFlLFVBQWdCO0FBQ3JDLFdBQU8sS0FBSyxZQUFZLElBQUksUUFBUSxLQUFLLG9CQUFJLElBQUc7RUFDakQ7Ozs7Ozs7Ozs7O0VBWU8sTUFBTSxnQkFBZ0IsWUFBWSxLQUFJO0FBRTVDLFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sZUFBNkIsQ0FBQTtBQUVuQyxVQUFNLGdCQUFnQixDQUFDLFdBQXNCO0FBQzVDLFVBQUksQ0FBQyxhQUFhLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEVBQUUsR0FBRztBQUNsRCxxQkFBYSxLQUFLLE1BQU07TUFDekI7SUFDRDtBQUdBLFNBQUssbUJBQW1CLElBQUksZUFBZSxhQUFhO0FBRXhELFFBQUk7QUFDSCxZQUFNLEtBQUs7QUFHWCxZQUFNO1FBQ0wsS0FBSztRQUNMOztRQUNBLE9BQU8sV0FBVyxLQUFLLG9CQUFvQixNQUFNO1FBQ2pEO01BQVM7QUFFVixhQUFPO0lBQ1I7QUFDQyxXQUFLLG1CQUFtQixPQUFPLGFBQWE7SUFDN0M7RUFDRDs7Ozs7RUFNTyxNQUFNLHVCQUF1QixVQUFnQjtBQUNuRCxJQUFBQSxRQUFPLEtBQUssb0NBQW9DLFFBQVEsRUFBRTtBQUMxRCxVQUFNLFdBQVcsTUFBTSxLQUFLLGFBQzNCLEtBQUssT0FDTCxrQkFDQSxRQUNBLFFBQ0EsUUFDQSxVQUNBLEtBQUs7QUFLTixVQUFNLFlBQVk7QUFFbEIsUUFBSSxTQUFTLFNBQVMsWUFBWSxHQUFHO0FBQ3BDLE1BQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsU0FBUyxNQUFNLFFBQVE7QUFDbkUsYUFBTztJQUNSO0FBR0EsVUFBTSxRQUFRLFNBQVMsWUFBWSxDQUFDO0FBQ3BDLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUVwQyxRQUFJO0FBQ0osUUFBSSxVQUFVLEdBQUc7QUFDaEIsaUJBQVc7SUFDWixXQUFXLFFBQVEsSUFBSTtBQUN0QixpQkFBVyxNQUFNLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRztJQUM1QyxPQUFPO0FBQ04saUJBQVcsTUFBTSxTQUFRO0lBQzFCO0FBRUEsVUFBTSxXQUFXLEdBQUcsS0FBSyxJQUFJLFFBQVE7QUFFckMsSUFBQUEsUUFBTyxLQUFLLHFCQUFxQixRQUFRLEVBQUU7QUFDM0MsV0FBTztFQUNSOzs7OztFQU1RLE1BQU0sb0JBQW9CLFFBQWM7QUFDL0MsUUFBSTtBQUNILFlBQU0sWUFBWSxNQUFNLDhCQUE4QixNQUFNO0FBQzVELFVBQUksQ0FBQyxXQUFXO0FBQ2YsUUFBQUEsUUFBTyxLQUFLLHFEQUFxRCxNQUFNLEVBQUU7QUFDekU7TUFDRDtBQUVBLFVBQUksS0FBSyxpQkFBaUIsSUFBSSxTQUFTLEdBQUc7QUFFekM7TUFDRDtBQUVBLFVBQUk7QUFDSCxhQUFLLFNBQVMsY0FBYyxLQUFLLGdCQUFnQixTQUFTO0FBQzFELGFBQUssaUJBQWlCLElBQUksU0FBUztBQUNuQyxRQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssY0FBYyxPQUFPLFNBQVMsRUFBRTtNQUN0RSxTQUFTLElBQUk7QUFDWixRQUFBQSxRQUFPLEtBQUssK0JBQStCLFNBQVMsS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFO01BQ3RFO0lBQ0QsU0FBUyxJQUFJO0FBQ1osTUFBQUEsUUFBTyxLQUFLLCtCQUErQixFQUFFLEVBQUU7SUFDaEQ7RUFDRDtFQUVPLE1BQU0sYUFDWixPQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQ0EsUUFDQSxTQUFTLE1BQUk7QUFFYixTQUFLO0FBQ0wsV0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFdBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxZQUNwQyxLQUFLLGNBQWMsT0FBTyxPQUFPLE9BQU8sV0FBVyxPQUFPLFFBQVEsTUFBTSxFQUN0RSxLQUFLLENBQUMsUUFBTztBQUNiLGFBQUs7QUFFTCxZQUFJLEtBQUssd0JBQXdCLEtBQUssS0FBSyx1QkFBdUIsY0FBYyxRQUFXO0FBQzFGLGVBQUssbUJBQW1CLE1BQU0sRUFBRSxNQUFNLENBQUMsUUFBTztBQUM3QyxZQUFBQSxRQUFPLEtBQUssNkNBQTZDLEdBQUcsRUFBRTtVQUMvRCxDQUFDO1FBQ0Y7QUFDQSxnQkFBUSxHQUFHO01BQ1osQ0FBQyxFQUNBLE1BQU0sQ0FBQyxRQUFPO0FBQ2QsYUFBSztBQUNMLGVBQU8sZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDM0QsQ0FBQyxDQUFDO0lBRUwsQ0FBQztFQUNGO0VBRVEsTUFBTSxjQUNiLE9BQ0EsT0FDQSxPQUNBLFdBQ0EsT0FDQSxRQUNBLFNBQVMsTUFBSTtBQUViLFVBQU0sWUFBWTtBQUlsQixRQUFJLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxHQUFHO0FBQ3BDLFlBQU0sSUFBSSxNQUFNLGFBQWEsTUFBTSxpRkFBNEU7SUFDaEg7QUFHQSxVQUFNLEtBQUssb0JBQW9CLE1BQU07QUFFckMsVUFBTSxZQUFzQixDQUFBO0FBQzVCLFFBQUksY0FBYztBQUFXLGdCQUFVLEtBQUssWUFBWSxHQUFJO0FBQzVELFFBQUksVUFBVTtBQUFXLGdCQUFVLEtBQUssR0FBRyxjQUFhLGdCQUFnQixLQUFLLENBQUM7QUFFOUUsVUFBTSxjQUF3QixDQUFDLElBQU0sUUFBUSxHQUFJO0FBRWpELFFBQUksVUFBVTtBQUFXLGtCQUFZLEtBQUssUUFBUSxHQUFJO0FBQ3RELFFBQUk7QUFBUSxrQkFBWSxLQUFLLFVBQVUsTUFBTTtBQUU3QyxRQUFJLFVBQVUsU0FBUztBQUFHLGtCQUFZLEtBQUssR0FBRyxTQUFTO0FBRXZELFVBQU0sTUFBTSxjQUFhLFVBQVUsV0FBVztBQUM5QyxVQUFNLGlCQUFpQixPQUFPLEtBQUssQ0FBQyxHQUFHLGFBQWEsR0FBRyxDQUFDO0FBRXhELFVBQU0sV0FBVyxLQUFLLGVBQWU7QUFDckMsVUFBTSxTQUFTLE1BQU0sY0FBYSxZQUFZLFVBQVUsTUFBTTtBQUM5RCxVQUFNLFNBQVMsT0FBTyxPQUFPLENBQUMsUUFBUSxjQUFjLENBQUM7QUFHckQsVUFBTSxVQUFVLGVBQWUsS0FBSztBQUNwQyxRQUFJLGNBQWMsVUFBYSxVQUFVLFFBQVc7QUFFbkQsVUFBSSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUc5RSxVQUFJLENBQUMsUUFBUTtBQUNaLGlCQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBSztBQUNoQyxjQUFJLEVBQUUsV0FBVztBQUFPLG1CQUFPO0FBQy9CLGdCQUFNLFdBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQzVELGNBQUksQ0FBQztBQUFVLG1CQUFPO0FBQ3RCLGlCQUFPLGFBQWEsRUFBRSxNQUFNLFlBQVksRUFBRSxLQUFLO1FBQ2hELENBQUM7TUFDRjtBQUVBLFVBQUksY0FBYyxRQUFRLFFBQVE7QUFHbEMsVUFBSSxRQUFRO0FBQ1gsY0FBTSxXQUFXLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUNqRSxZQUFJLFlBQVksY0FBYyxPQUFPLElBQUk7QUFDeEMsZ0JBQU0sZ0JBQWdCLFlBQVksT0FBTztBQUN6Qyx3QkFBYyxHQUFHLFdBQVcsTUFBTSxnQkFBZ0IsQ0FBQztRQUNwRDtNQUNEO0FBR0EsWUFBTSxjQUFjLFFBQVEsU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUNyRSxZQUFNLFVBQVUsYUFBYTtBQUM3QixZQUFNLGFBQWEsY0FBYSxnQkFBZ0IsS0FBSztBQUNyRCxZQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsWUFBTSxjQUFjLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBRXhHLFlBQU0sU0FBUyxNQUFNLEtBQUs7QUFDMUIsWUFBTSxRQUFRLE1BQU0sU0FBUztBQUM3QixZQUFNLFNBQVMsV0FBVyxVQUFVO0FBQ3BDLFlBQU0sU0FBUyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSSxXQUFXLEtBQUssR0FBRztBQUU1RSxZQUFNLFNBQVMsT0FBTyxNQUFNLE9BQU8sS0FBSyxRQUFRLE1BQU07QUFDdEQsWUFBTSxTQUFTLGNBQWMsR0FBRyxXQUFXLEtBQUssV0FBVyxLQUFLLE1BQU0sTUFBTSxHQUFHLFdBQVcsS0FBSyxNQUFNO0FBRXJHLE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxFQUFFO0lBQ25ELE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sT0FBTyxFQUFFO0lBQ3hDO0FBQ0EsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixNQUFNLEtBQUssT0FBTyxTQUFTLEtBQUssQ0FBQyxFQUFFO0FBRXJFLFVBQU0sS0FBSztBQUVYLFVBQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxLQUFLO0FBRTlCLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxZQUFNLFFBQVEsV0FBVyxNQUFLO0FBQzdCLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZUFBTyxJQUFJLE1BQU0scUNBQXFDLEtBQUssT0FBTyxNQUFNLE9BQU8sQ0FBQztNQUNqRixHQUFHLFNBQVM7QUFFWixXQUFLLFlBQVksSUFBSSxLQUFLO1FBQ3pCLFNBQVMsQ0FBQyxRQUFPO0FBQ2hCLHVCQUFhLEtBQUs7QUFDbEIsa0JBQVEsR0FBRztRQUNaO1FBQ0EsUUFBUSxDQUFDLFFBQU87QUFDZix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLEdBQUc7UUFDWDtRQUNBO09BQ0E7QUFFRCxXQUFLLFNBQVMsS0FBSyxRQUFRLEtBQUssYUFBYSxRQUFRLENBQUMsUUFBTztBQUM1RCxZQUFJLEtBQUs7QUFDUixlQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQzdDO01BQ0QsQ0FBQztJQUNGLENBQUM7RUFDRjtFQUVRLGVBQWUsS0FBYSxPQUFhO0FBQ2hELFFBQUksSUFBSSxTQUFTO0FBQUc7QUFDcEIsUUFBSSxJQUFJLENBQUMsTUFBTSxPQUFRLElBQUksQ0FBQyxNQUFNO0FBQU07QUFFeEMsVUFBTSxVQUFVLElBQUksYUFBYSxDQUFDO0FBS2xDLFFBQUksWUFBWSwyQkFBMkIsS0FBSyxtQkFBbUIsT0FBTyxHQUFHO0FBQzVFLFlBQU0sU0FBUyx1QkFBdUIsS0FBSyxLQUFLO0FBQ2hELFVBQUksUUFBUTtBQUNYLFFBQUFBLFFBQU8sTUFDTiw0QkFBNEIsS0FBSyxlQUNuQixPQUFPLElBQUksYUFDZCxPQUFPLEtBQUssaUJBQ1IsT0FBTyxTQUFTLG9CQUNiLE9BQU8sWUFBWSxHQUFHO0FBSXpDLFlBQUksT0FBTyxTQUFTLFlBQVk7QUFDL0IscUJBQVcsTUFBTSxLQUFLLG1CQUFtQixPQUFNLEdBQUk7QUFDbEQsZ0JBQUk7QUFDSCxpQkFBRyxNQUFNO1lBQ1YsUUFBUTtZQUVSO1VBQ0Q7UUFDRCxPQUFPO0FBQ04sVUFBQUEsUUFBTyxNQUFNLHNEQUFzRCxPQUFPLElBQUksT0FBTyxLQUFLLEVBQUU7UUFDN0Y7TUFDRDtBQUNBO0lBQ0Q7QUFFQSxRQUFJLElBQUksU0FBUztBQUFJO0FBR3JCLFVBQU0sTUFBTSxJQUFJLFNBQVMsSUFBSSxFQUFFO0FBQy9CLFFBQUksSUFBSSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBSTFDLFVBQU0sWUFBWSxJQUFJLFNBQVMsRUFBRTtBQUNqQyxRQUFJLFVBQVUsU0FBUztBQUFHO0FBQzFCLFFBQUksVUFBVSxDQUFDLE1BQU07QUFBTTtBQUczQixVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sY0FBYyxZQUFZLFNBQVU7QUFDMUMsVUFBTSxnQkFBZ0IsWUFBWTtBQUdsQyxTQUFLLGFBQWEsT0FBTyxlQUFlLEtBQUssV0FBVyxVQUFVO0FBR2xFLFFBQUksWUFBWTtBQUNmLFlBQU0sTUFBTSxHQUFHLEtBQUssSUFBSSxhQUFhO0FBQ3JDLFlBQU0sVUFBVSxLQUFLLFlBQVksSUFBSSxHQUFHO0FBQ3hDLFVBQUksU0FBUztBQUNaLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZ0JBQVEsUUFBUSxHQUFHO01BQ3BCO0lBQ0Q7RUFFRDs7Ozs7Ozs7Ozs7O0VBYVEsYUFBYSxPQUFlLE9BQWUsS0FBYSxXQUFtQixhQUFhLE1BQUk7QUFDbkcsVUFBTSxVQUFVLE9BQU8sTUFBTSxLQUFLLENBQUM7QUFDbkMsVUFBTSxPQUFPLFVBQVUsU0FBUyxHQUFHLFVBQVUsU0FBUyxDQUFDO0FBR3ZELFVBQU0sUUFBUSxVQUFVLENBQUM7QUFDekIsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLE1BQU0sVUFBVSxVQUFVLFNBQVMsQ0FBQztBQUMxQyxVQUFNLGdCQUFnQixVQUFVLE1BQU0sS0FBSyxDQUFDLFFBQVEsTUFBTSxTQUFTLENBQUMsU0FBUyxLQUFLLFNBQVMsS0FBSyxDQUFDLFFBQVEsTUFBTSxHQUFHLENBQUM7QUFHbkgsVUFBTSxZQUFZLGFBQWEsT0FBTztBQUt0QyxRQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQUksQ0FBQyxLQUFLLE9BQU87QUFDaEIsUUFBQUEsUUFBTyxLQUFLLEdBQUcsU0FBUyxJQUFJLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxFQUFFO0FBQ25FO01BQ0Q7QUFDQSxVQUFJO0FBQ0gsY0FBTSxXQUNMLFVBQVUsb0JBQ1Asc0JBQXNCLEtBQUssT0FBTyxHQUFHLElBQ3JDLDRCQUE0QixLQUFLLE9BQU8sR0FBRztBQUUvQyxjQUFNLFlBQVksS0FBSyxZQUFZLElBQUksS0FBSyxLQUFLLG9CQUFJLElBQUc7QUFDeEQsY0FBTSxXQUFXLElBQUksSUFBb0IsU0FBUztBQUVsRCxtQkFBVyxLQUFLLFVBQVU7QUFDekIsZ0JBQU0sV0FBVyxjQUFjLEtBQUssT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSztBQUVsRSxnQkFBTSxXQUNMLEVBQUUsV0FBVyxXQUFXLElBQ3BCLEVBQUUsV0FBVyxDQUFDLEtBQUssS0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLElBQUssRUFBRSxXQUFXLENBQUMsSUFDaEUsRUFBRSxXQUFXLENBQUMsS0FBSztBQUN4QixnQkFBTSxZQUFZLFVBQVUsSUFBSSxRQUFRO0FBQ3hDLGdCQUFNLFVBQVUsY0FBYyxVQUFhLGNBQWM7QUFFekQsbUJBQVMsSUFBSSxVQUFVLFFBQVE7QUFFL0IsZ0JBQU0sWUFBWSxvQkFBb0IsR0FBRyxLQUFLLE9BQU87QUFDckQsY0FBSSxTQUFTO0FBQ1osWUFBQUEsUUFBTyxLQUFLLEdBQUcsU0FBUyxJQUFJLEtBQUssTUFBTSxTQUFTLEVBQUU7QUFFbEQsZ0JBQUksS0FBSyxrQkFBa0I7QUFDMUIsb0JBQU0sa0JBQWtCLGNBQWMsS0FBSyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7QUFFaEUsbUJBQUssaUJBQWlCLGVBQWU7WUFDdEMsT0FBTztBQUNOLGNBQUFBLFFBQU8sS0FBSyxnRUFBMkQsUUFBUSxFQUFFO1lBQ2xGO1VBQ0QsT0FBTztBQUNOLFlBQUFBLFFBQU8sTUFBTSxHQUFHLFNBQVMsSUFBSSxLQUFLLE1BQU0sU0FBUyxFQUFFO1VBQ3BEO1FBQ0Q7QUFDQSxhQUFLLFlBQVksSUFBSSxPQUFPLFFBQVE7TUFDckMsU0FBUyxHQUFHO0FBQ1gsUUFBQUEsUUFBTyxLQUFLLEdBQUcsU0FBUyxJQUFJLEtBQUssTUFBTSxPQUFPLG9CQUFvQixDQUFDLE1BQU0sYUFBYSxFQUFFO01BQ3pGO0FBQ0E7SUFDRDtBQUdBLFVBQU0sVUFBVSxLQUFLLGFBQWEsT0FBTyxJQUFJO0FBQzdDLFFBQUksU0FBUztBQUNaLE1BQUFBLFFBQU8sS0FBSyxHQUFHLFNBQVMsSUFBSSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsTUFBTSxPQUFPLEVBQUU7SUFDakYsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxHQUFHLFNBQVMsSUFBSSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsRUFBRTtJQUNwRTtFQUNEOzs7Ozs7OztFQVNRLGFBQWEsT0FBZSxNQUFZO0FBQy9DLFFBQUksS0FBSyxXQUFXO0FBQUcsYUFBTztBQUc5QixRQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLFVBQUksS0FBSyxDQUFDLE1BQU0sR0FBTTtBQUNyQixlQUFPO01BQ1IsT0FBTztBQUNOLGVBQU8sU0FBUyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7TUFDL0I7SUFDRDtBQUVBLFlBQVEsT0FBTzs7Ozs7TUFLZCxLQUFLLGNBQWM7QUFDbEIsWUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixpQkFBTyxLQUFLLENBQUMsTUFBTSxJQUFPLFdBQVcsV0FBVyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDL0Q7QUFDQSxZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxVQUFVLFFBQVEsVUFBVSxDQUFDLEdBQUc7QUFDdEMsZ0JBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxnQkFBTSxjQUNMLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBQ3JGLGdCQUFNLFdBQVcsY0FBYyxHQUFHLFdBQVcsS0FBSyxNQUFNLFFBQVMsQ0FBQyxNQUFNLFdBQVcsTUFBTSxLQUFLLFVBQVUsQ0FBQztBQUN6RyxnQkFBTSxTQUFTLElBQUksTUFBTSxLQUFLLENBQUMsSUFBSSxNQUFNLFNBQVMsQ0FBQyxLQUFLLFdBQVcsTUFBTSxLQUFLLFVBQVUsQ0FBQyxDQUFDO0FBQzFGLGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRLElBQUksTUFBTTtRQUNoRTtBQUNBLGVBQU8sUUFBUSxLQUFLLFNBQVMsS0FBSyxDQUFDO01BQ3BDOztNQUdBLEtBQUssaUJBQWlCO0FBRXJCLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDckIsZ0JBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsZ0JBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsZ0JBQU0sYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNsQyxnQkFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUNoRixnQkFBTSxjQUFjLFFBQVEsUUFBUSxXQUFXLE1BQU0sU0FBUyxDQUFDO0FBQy9ELGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sVUFBVSxRQUFRLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sR0FBRztBQUNoRSxnQkFBTSxjQUNMLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBQ3JGLGdCQUFNLFdBQVcsZUFBZSxLQUFLLFdBQVcsU0FBUyxLQUFLLENBQUM7QUFDL0QsaUJBQU8sV0FBVyxLQUFLLE1BQU0sV0FBVyxLQUFLLFFBQVE7UUFDdEQ7QUFDQSxlQUFPO01BQ1I7O01BR0EsS0FBSztNQUNMLEtBQUssYUFBYTtBQUNqQixZQUFJLEtBQUssU0FBUztBQUFHLGlCQUFPO0FBQzVCLGNBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsY0FBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixjQUFNLFFBQVEsS0FBSyxTQUFTLENBQUM7QUFDN0IsZUFBTyxNQUFNLEtBQUssWUFBWSxNQUFNLFNBQVMsQ0FBQyxVQUFVLE1BQU0sU0FBUyxLQUFLLENBQUM7TUFDOUU7TUFFQTtBQUNDLGVBQU87SUFDVDtFQUNEO0VBRVEsT0FBTyxnQkFBZ0IsT0FBYztBQUM1QyxRQUFJLE9BQU8sVUFBVTtBQUFXLGFBQU8sQ0FBQyxRQUFRLElBQUksQ0FBQztBQUNyRCxRQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUcsYUFBTyxNQUFNLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxJQUFJLEdBQUk7QUFDbEUsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM5QixVQUFJLFFBQVE7QUFBTSxlQUFPLENBQUUsU0FBUyxLQUFNLEtBQU8sU0FBUyxJQUFLLEtBQU0sUUFBUSxHQUFJO0FBQ2pGLGFBQU8sQ0FBQyxRQUFRLEdBQUk7SUFDckI7QUFDQSxVQUFNLElBQUksTUFBTSw0Q0FBNEMsS0FBSyxFQUFFO0VBQ3BFO0VBRVEsYUFBYSxZQUFZLFVBQWtCLFFBQWM7QUFDaEUsVUFBTSxNQUFNLE1BQU0scUJBQXFCLE1BQU07QUFFN0MsV0FBTyxPQUFPLE9BQU87TUFDcEIsT0FBTyxLQUFLLENBQUMsS0FBTSxLQUFNLEdBQU0sV0FBVyxLQUFNLEdBQU0sS0FBTSxHQUFNLEdBQU0sR0FBRyxLQUFLLEdBQU0sQ0FBSSxDQUFDO01BQzNGLE9BQU8sS0FBSyxZQUFZLE1BQU07S0FDOUI7RUFDRjtFQUVRLE9BQU8sVUFBVSxNQUFjO0FBQ3RDLFFBQUksTUFBTTtBQUNWLGVBQVcsS0FBSyxNQUFNO0FBQ3JCLGFBQU87QUFDUCxlQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUMzQixlQUFPLE1BQU0sU0FBVSxLQUFNLE9BQU8sSUFBSyxPQUFRLE1BQVEsT0FBTyxJQUFLO01BQ3RFO0lBQ0Q7QUFDQSxXQUFPO0VBQ1I7Ozs7Ozs7Ozs7RUFXTyxnQkFBZ0IsSUFBWSxPQUFlLFdBQW1CLE9BQWM7QUFDbEYsVUFBTSxNQUFNLGNBQWMsS0FBSyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQzdELFdBQU8sS0FBSyxZQUFZLElBQUksRUFBRSxHQUFHLElBQUksR0FBRztFQUN6QztFQUVPLE1BQU0sWUFBWSxPQUFlLFFBQWM7QUFDckQsV0FBTyxLQUFLLGFBQWEsT0FBTyxrQkFBa0IsUUFBVyxHQUFNLFFBQVcsUUFBUSxLQUFLO0VBQzVGO0VBRU8sTUFBTSxjQUFjLE9BQWUsUUFBYztBQUN2RCxXQUFPLEtBQUssYUFBYSxPQUFPLHFCQUFxQixRQUFXLFFBQVcsUUFBVyxRQUFRLEtBQUs7RUFDcEc7Ozs7QUU1d0JELE9BQU9FLFdBQVU7QUFFakIsSUFBTUMsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBTWxELElBQXFCLGlCQUFyQixjQUE0QyxhQUF5QjtFQUNwRTs7RUFDQTs7O0VBSVEsb0JBQWtDLENBQUE7RUFFMUMsWUFBWSxVQUFpQjtBQUM1QixVQUFNLFFBQVE7RUFDZjtFQUVBLE1BQU0sS0FBSyxRQUFvQjtBQUM5QixTQUFLLFNBQVM7QUFDZCxRQUFJLENBQUMsS0FBSyxjQUFjO0FBQ3ZCLFdBQUssZUFBZSxJQUFJLGFBQVk7SUFDckM7QUFDQSxTQUFLLGFBQWEsZUFBZSxFQUFFO0FBR25DLFNBQUssYUFBYSxvQkFBb0IsQ0FBQyxlQUFzQjtBQUM1RCxXQUFLLGVBQWUsVUFBVTtJQUMvQixDQUFDO0FBSUQsU0FBSyxhQUFZLEVBQUcsTUFBTSxDQUFDLE1BQUs7QUFDL0IsTUFBQUEsUUFBTyxNQUFNLHFCQUFxQixDQUFDLEVBQUU7SUFDdEMsQ0FBQztFQUNGOzs7Ozs7O0VBUVEsTUFBTSxlQUFZO0FBQ3pCLElBQUFBLFFBQU8sS0FBSyw4QkFBOEI7QUFFMUMsU0FBSyxvQkFBb0IsTUFBTSxLQUFLLGFBQWEsZ0JBQWU7QUFHaEUsUUFBSTtBQUNKLFFBQUksS0FBSyxrQkFBa0IsV0FBVyxHQUFHO0FBQ3hDLFlBQU0sY0FBYyxLQUFLLE9BQU87QUFDaEMsVUFBSSxDQUFDLEtBQUssT0FBTyxRQUFRLENBQUMsYUFBYTtBQUN0QyxRQUFBQSxRQUFPLEtBQUsseURBQXlEO0FBQ3JFO01BQ0Q7QUFDQSxNQUFBQSxRQUFPLEtBQUssd0VBQW1FO0FBQy9FLHVCQUFpQjtJQUNsQixPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGNBQWMsS0FBSyxrQkFBa0IsTUFBTSxhQUFhO0FBQ3BFLGlCQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdkMsUUFBQUEsUUFBTyxLQUFLLGFBQWEsRUFBRSxLQUFLLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFO01BQ3JFO0FBS0EsaUJBQVcsVUFBVSxLQUFLLG1CQUFtQjtBQUM1QyxhQUFLLGFBQWEsZ0JBQWdCLE9BQU8sRUFBRTtNQUM1QztBQUdBLGlCQUFXLFVBQVUsS0FBSyxtQkFBbUI7QUFDNUMsWUFBSTtBQUNILGdCQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsdUJBQXVCLE9BQU8sRUFBRTtBQUN6RSxpQkFBTyxlQUFlO0FBQ3RCLFVBQUFBLFFBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSxjQUFjLFFBQVEsV0FBVyxPQUFPLGFBQWEsRUFBRTtRQUNwRixTQUFTLEdBQUc7QUFDWCxVQUFBQSxRQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsNkJBQTZCLENBQUMsRUFBRTtBQUM1RCxpQkFBTyxlQUFlO1FBQ3ZCO01BQ0Q7QUFFQSx1QkFBaUIsYUFBYSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7SUFDbEU7QUFHQSxTQUFLLFVBQVUsY0FBYztBQUk3QixVQUFNLGFBQWEsS0FBSztBQUN4QixVQUFNLEtBQUssb0JBQW9CLElBQUksVUFBVTtBQUc3QyxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtBQUV6QixJQUFBQSxRQUFPLEtBQUssMkJBQTJCO0VBQ3hDOztFQUdBLE1BQU0sVUFBTztBQUNaLFNBQUssY0FBYyxNQUFLO0FBQ3hCLElBQUFBLFFBQU8sTUFBTSxTQUFTO0VBQ3ZCO0VBRUEsTUFBTSxjQUFjLFFBQW9CO0FBQ3ZDLFVBQU0sZUFBZSxLQUFLO0FBQzFCLFNBQUssU0FBUztBQUNkLFVBQU0saUJBQWlCLGFBQWEsUUFBUSxLQUFLLGlCQUFpQjtBQUNsRSxTQUFLLFVBQVUsY0FBYztBQUk3QixTQUFLLHFCQUFvQjtBQUV6QixVQUFNLFVBQVUsS0FBSztBQUlyQixVQUFNLEtBQUssb0JBQW9CLGNBQWMsT0FBTztBQUdwRCxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtFQUMxQjs7Ozs7Ozs7Ozs7O0VBYVEsTUFBTSxvQkFBb0IsY0FBc0IsU0FBZTtBQUN0RSxRQUFJLENBQUMsU0FBUztBQUNiLFVBQUk7QUFBYyxhQUFLLGFBQWEsYUFBYSxZQUFZO0FBQzdEO0lBQ0Q7QUFFQSxRQUFJLEtBQUssT0FBTyxnQkFBZ0I7QUFFL0IsVUFBSSxnQkFBZ0IsaUJBQWlCLFNBQVM7QUFDN0MsYUFBSyxhQUFhLGFBQWEsWUFBWTtNQUM1QztBQUNBLFlBQU0sZ0JBQWdCLEtBQUssYUFBYSxtQkFBbUIsT0FBTztBQUNsRSxVQUFJLENBQUMsZUFBZTtBQUNuQixhQUFLLGFBQWEsZ0JBQWdCLE9BQU87TUFDMUM7QUFDQSxVQUFJLFlBQVksZ0JBQWdCLENBQUMsZUFBZTtBQUMvQyxjQUFNLFFBQVEsYUFBYSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7QUFDOUQsY0FBTSxLQUFLLDZCQUE2QixPQUFPLE9BQU87TUFDdkQ7QUFDQTtJQUNEO0FBR0EsVUFBTSxjQUFjLEtBQUssT0FBTztBQUNoQyxVQUFNLGlCQUFpQixLQUFLLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUUxRSxRQUFJLGdCQUFnQjtBQUNuQixVQUFJLGVBQWUsVUFBVSxhQUFhO0FBQ3pDLFlBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLGVBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsY0FBTSxnQkFBZ0IsS0FBSyxhQUFhLG1CQUFtQixPQUFPO0FBQ2xFLFlBQUksQ0FBQyxlQUFlO0FBQ25CLGVBQUssYUFBYSxnQkFBZ0IsT0FBTztRQUMxQztBQUNBLFlBQUksWUFBWSxnQkFBZ0IsQ0FBQyxlQUFlO0FBQy9DLGdCQUFNLEtBQUssNkJBQTZCLGFBQWEsT0FBTztRQUM3RDtNQUNELE9BQU87QUFDTixRQUFBQSxRQUFPLE1BQ04sMEJBQTBCLFdBQVcsMkNBQTJDLGVBQWUsS0FBSyxRQUFRLE9BQU8sMEJBQXFCO0FBRXpJLGFBQUssYUFBYSxhQUFhLE9BQU87TUFDdkM7QUFDQTtJQUNEO0FBR0EsSUFBQUEsUUFBTyxLQUFLLEdBQUcsT0FBTyx3Q0FBbUM7QUFDekQsUUFBSSxnQkFBZ0IsaUJBQWlCO0FBQVMsV0FBSyxhQUFhLGFBQWEsWUFBWTtBQUN6RixTQUFLLGFBQWEsYUFBYSxPQUFPO0FBRXRDLFVBQU0sU0FBUyxNQUFNLEtBQUssYUFBYSxZQUFZLE9BQU87QUFDMUQsUUFBSSxDQUFDLFFBQVE7QUFDWixNQUFBQSxRQUFPLE1BQU0sMEJBQTBCLE9BQU8sMEJBQXFCO0lBQ3BFLFdBQVcsT0FBTyxVQUFVLGFBQWE7QUFDeEMsTUFBQUEsUUFBTyxNQUNOLDBCQUEwQixXQUFXLDJDQUEyQyxPQUFPLEtBQUssUUFBUSxPQUFPLDBCQUFxQjtJQUVsSSxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGtCQUFrQixPQUFPLEtBQUssT0FBTyxPQUFPLEVBQUU7QUFDMUQsV0FBSyxhQUFhLGdCQUFnQixPQUFPO0FBQ3pDLFlBQU0sS0FBSyw2QkFBNkIsYUFBYSxPQUFPO0lBQzdEO0VBQ0Q7Ozs7O0VBTVEsTUFBTSw2QkFBNkIsT0FBZSxJQUFVO0FBQ25FLFFBQUk7QUFDSCxZQUFNLE1BQU0sTUFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUU7QUFFekQsVUFBSSxDQUFDLGdCQUFnQixLQUFLLEdBQUc7QUFDNUIsUUFBQUEsUUFBTyxLQUFLLDZCQUE2QixLQUFLLHVDQUFrQztBQUVoRixjQUFNLEVBQUUsVUFBVSxRQUFRLGtCQUFpQixJQUFLLGlDQUFpQyxPQUFPLEdBQUc7QUFDM0YsWUFBSSxPQUFPLFdBQVcsR0FBRztBQUN4QixVQUFBQSxRQUFPLEtBQUssc0NBQXNDLEtBQUssNEJBQXVCO0FBQzlFO1FBQ0Q7QUFFQSxjQUFNLFVBQVUscUJBQXFCLGlCQUFnQixDQUFFO0FBQ3ZELGNBQU0sWUFBWSxFQUFFLE9BQU8sV0FBVyxxQkFBcUIsT0FBTyxXQUFXLENBQUEsRUFBVztBQUN4RixZQUFJLHNCQUFzQixNQUFNO0FBQy9CLG9CQUFVLFlBQVk7UUFDdkI7QUFDQSxjQUFNLFVBQVUsNEJBQTRCLFdBQWtCLFFBQVEsT0FBYztBQUVwRixjQUFNLGFBQWFELE1BQUssS0FBSyxpQkFBZ0IsR0FBSSxRQUFRLEtBQUssT0FBTztBQUNyRSw0QkFBb0IsWUFBWSxPQUFPO0FBQ3ZDLDRCQUFtQjtBQUNuQixRQUFBQyxRQUFPLEtBQUssNEJBQTRCLEtBQUssT0FBTyxVQUFVLEVBQUU7QUFHaEUsYUFBSyxVQUFVLEtBQUs7QUFDcEIsYUFBSyxjQUFhO0FBQ2xCLGFBQUssZ0JBQWU7QUFDcEIsYUFBSywwQkFBeUI7TUFDL0I7SUFDRCxTQUFTLEdBQUc7QUFDWCxNQUFBQSxRQUFPLEtBQUssaUNBQWlDLEVBQUUsS0FBSyxDQUFDLEVBQUU7SUFDeEQ7RUFDRDs7RUFHUSxVQUFVLE9BQWE7QUFDOUIsVUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxLQUFLLFVBQVUsS0FBSywrQkFBK0I7QUFDMUQsV0FBSyxhQUFhLFNBQVMsT0FBTyxDQUFBLEdBQUksSUFBSTtBQUMxQztJQUNEO0FBRUEsVUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSSxPQUFPLFlBQVksQ0FBQTtBQUNyRSxVQUFNLHNCQUFzQixPQUFPLHVCQUF1QjtBQUUxRCxTQUFLLGFBQWEsU0FBUyxPQUFPLFNBQVMsbUJBQW1CO0FBQzlELFFBQUksUUFBUSxXQUFXLEdBQUc7QUFDekIsTUFBQUEsUUFBTyxLQUFLLCtCQUErQixLQUFLLDZDQUF3QztJQUN6RixPQUFPO0FBQ04sTUFBQUEsUUFBTyxNQUNOLFVBQVUsUUFBUSxNQUFNLHVCQUF1QixLQUFLLGdCQUFnQixPQUFPLFNBQVMseUJBQXlCLG1CQUFtQixFQUFFO0lBRXBJO0VBQ0Q7RUFFQSxrQkFBZTtBQUNkLFdBQU8sZ0JBQWdCLEtBQUssaUJBQWlCO0VBQzlDOztFQUdBLElBQUksT0FBSTtBQUNQLFdBQU8sWUFBWSxLQUFLLE1BQU07RUFDL0I7O0VBR0EsSUFBSSxVQUFPO0FBQ1YsV0FBTyxLQUFLO0VBQ2I7RUFFQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSxrQkFBZTtBQUNkLG9CQUFnQixJQUFJO0VBQ3JCO0VBRUEsNEJBQXlCO0FBQ3hCLDhCQUEwQixJQUFJO0VBQy9CO0VBRUEsdUJBQW9CO0FBQ25CLHlCQUFxQixJQUFJO0VBQzFCOzsiLAogICJuYW1lcyI6IFsicGF0aCIsICJJbnN0YW5jZVN0YXR1cyIsICJSZWdleCIsICJwYXRoIiwgImZzIiwgImxvZ2dlciIsICJsb2dnZXIiLCAiZnMiLCAibG9nZ2VyIiwgImRldmljZXNGb2xkZXIiLCAicGF0aCIsICJsb2dnZXIiLCAiZGdyYW0iLCAibG9nZ2VyIiwgImxvZ2dlciIsICJkZ3JhbSIsICJwYXRoIiwgImxvZ2dlciJdCn0K
