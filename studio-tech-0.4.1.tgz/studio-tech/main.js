import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual" },
    ...discoveredDevices.map((d) => ({
      id: d.ip,
      label: `Model ${d.model} (${d.ip})`
    }))
  ];
  return [
    // ── Device discovery dropdown ────────────────────────────────────────
    // Mirrors the bonjour-device field: selecting a device populates the
    // host automatically; selecting 'Manual' shows the textinput below.
    {
      type: "dropdown",
      id: "discoveredHost",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies Dante device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry ──────────────────────────────────────────────────
    // Only visible when discoveredHost is '' (Manual selected).
    // Matches the pattern from the bonjour-device docs.
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Model selector ───────────────────────────────────────────────────
    // Only visible when Manual mode is selected (no discovered device).
    // When a discovered device is selected, the model is auto-detected.
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Select which Studio Technologies model is active for actions and Get All Settings"
    }
  ];
}
function resolveHost(config) {
  return config.discoveredHost || config.host;
}
function resolveModel(config, discoveredDevices) {
  if (config.discoveredHost) {
    const device = discoveredDevices.find((d) => d.ip === config.discoveredHost);
    logger.debug(`resolveModel: discoveredHost="${config.discoveredHost}", found device: ${device?.model ?? "none"}`);
    if (device?.model) {
      return device.model;
    }
  }
  logger.debug(`resolveModel: falling back to activeModel="${config.activeModel}"`);
  return config.activeModel;
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
function UpdateVariableValues(self) {
  const currentHost = self.host;
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "Unknown",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "Unknown",
      danteFW: device.danteFirmware || "Unknown",
      mac: device.mac || "",
      ip: device.ip || currentHost
    });
  } else {
    self.setVariableValues({
      model: self.config.activeModel || "Unknown",
      modelName: "",
      manufacturer: "",
      firmware: "Unknown",
      danteFW: "Unknown",
      mac: "",
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_BUS_GET:
      return "Get Bus Setting";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "textinput":
    case "colorpicker":
    case "static-text":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  for (const { cmd_id, id, valueBytes } of parsed) {
    let action = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (!action) {
      for (const c of candidates) {
        const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
        if (match) {
          action = structuredClone(match);
          action.name = `${match.name} (inferred from Model ${c.model})`;
          logger2.info(`Inferred setting ${toHex(id)} from Model ${c.model}`);
          break;
        }
      }
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown Setting ${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      logger2.warn(`Could not infer setting ${toHex(id)}`);
    } else {
      const opt = action.options?.[0];
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
    }
    const exists = out.cmdSchema.some((a) => a.cmd_id === action.cmd_id && a.id === action.id);
    if (!exists)
      out.cmdSchema.push(action);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("refreshAfterCommand" in jsonObj) {
      orderedObj.refreshAfterCommand = jsonObj.refreshAfterCommand;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema;
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = resolveModel(self.config, self.devices);
  logger3.info(`UpdateActions: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  wiredActions["global_getAllSettings"] = {
    name: "GLOBAL: Get All Settings (Auto-Update JSON)",
    options: [],
    callback: async () => {
      const model = activeModel;
      const ip = self.host;
      const buf = await self.stController.requestAllSettings(ip);
      let modelJson = getDeviceSchema(model);
      if (!modelJson) {
        logger3.error(`Model ${model} schema not found in cache`);
        return;
      }
      const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
      logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
      if (detectedSectioned !== null) {
        logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
        modelJson = { ...modelJson, sectioned: detectedSectioned };
      }
      const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
      logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
      const devicesFolder2 = getDevicesFolder();
      const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
      saveModelJsonPretty(schemaPath, updated);
      reloadDeviceSchemas();
      logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
    }
  };
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(activeModel, cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(activeModel, ip);
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
  logger3.info(`UpdateActions: wired actions: ${Object.keys(wiredActions).length}`);
}

// dist/feedbacks.js
var logger4 = createModuleLogger("Feedbacks");
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = resolveModel(self.config, self.devices);
  logger4.info(`UpdateFeedbacks: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const busCh = feedbackEvent.options["busCh"];
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
  logger4.info(`UpdateFeedbacks: wired feedbacks: ${Object.keys(wiredFeedbacks).length}`);
}

// dist/stcontroller.js
import dgram2 from "dgram";
import os2 from "os";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger5 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, onDeviceFound, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const found = /* @__PURE__ */ new Map();
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const wrappedCallback = (device) => {
      if (!found.has(device.ip)) {
        found.set(device.ip, device);
        onDeviceFound(device);
      }
    };
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve(Array.from(found.values()));
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger5.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger5.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      ensureMembership(srcIp).then(() => {
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger5.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      }).catch((err) => logger5.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger5.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger5.warn(`Could not join announce multicast group: ${err}`);
      }
    });
    announceSocket.wrappedCallback = wrappedCallback;
  });
}

// dist/stcontroller.js
var logger6 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks;
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  constructor() {
    logger6.info("StController initialized");
    this.pendingAcks = /* @__PURE__ */ new Map();
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger6.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger6.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger6.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger6.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger6.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger6.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger6.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(this.model, CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    logger6.debug(`Raw response buffer: ${response.toString("hex")}`);
    logger6.debug(`Response length: ${response.length}`);
    const parsed = parseGetAllSettingsForModel(this.model, response);
    logger6.debug(`Parsed settings count: ${parsed.length}`);
    if (parsed.length > 0) {
      logger6.debug(`First few settings: ${JSON.stringify(parsed.slice(0, 3))}`);
    }
    const stateMap = /* @__PURE__ */ new Map();
    for (const setting of parsed) {
      const key = makeSettingId(this.model, setting.cmd_id, setting.id, setting.busCh);
      const value = setting.valueBytes.length === 3 ? setting.valueBytes[0] << 16 | setting.valueBytes[1] << 8 | setting.valueBytes[2] : setting.valueBytes[0] ?? 0;
      stateMap.set(key, value);
    }
    this.deviceState.set(deviceIp, stateMap);
    return response;
  }
  /** Return a snapshot of the current device state for a given IP (for feedbacks). */
  getDeviceState(deviceIp) {
    return this.deviceState.get(deviceIp) ?? /* @__PURE__ */ new Map();
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      foundDevices.push(device);
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(
        this.txSocket,
        onDeviceFound,
        // dante.ts doesn't actually use this, but kept for compatibility
        async (destIp) => this.ensureMembershipFor(destIp),
        timeoutMs
      );
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger6.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(this.model, CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false, 27);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger6.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    let minorStr;
    if (minor === 2) {
      minorStr = "2";
    } else if (minor < 10) {
      minorStr = minor.toString().padStart(2, "0");
    } else {
      minorStr = minor.toString();
    }
    const firmware = `${major}.${minorStr}`;
    logger6.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Ensure we've joined the multicast group on the interface that routes to destIp.
   * Option B behavior: join ONLY the interface used to reach the device.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger6.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger6.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger6.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger6.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(model, cmdId, busCh, settingId, value, destIp, addLen = true, msgType = 32) {
    const timeoutMs = 2e3;
    await this.ensureMembershipFor(destIp);
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (busCh !== void 0)
      payloadBody.push(busCh & 255);
    if (addLen)
      payloadBody.push(dataBlock.length);
    if (dataBlock.length > 0)
      payloadBody.push(...dataBlock);
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    const header = await _StController.buildHeader(destIp, msgType);
    const packet = Buffer.concat([header, payloadWithCrc]);
    const cmdName = getCommandName(cmdId);
    if (settingId !== void 0 && value !== void 0) {
      let action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
      if (!action) {
        action = this.actions.find((a) => {
          if (a.cmd_id !== cmdId)
            return false;
          const hasIdAdd = a.options?.some((opt) => opt.id === "idAdd");
          if (!hasIdAdd)
            return false;
          return settingId >= a.id && settingId < a.id + 10;
        });
      }
      let settingName = action?.name ?? "Unknown Setting";
      if (action) {
        const hasIdAdd = action.options?.some((opt) => opt.id === "idAdd");
        if (hasIdAdd && settingId !== action.id) {
          const channelOffset = settingId - action.id;
          settingName = `${settingName} Ch${channelOffset + 1}`;
        }
      }
      const valueOption = action?.options?.find((opt) => opt.id === "value");
      const choices = valueOption?.choices;
      const valueBytes = _StController.buildValueBytes(value);
      const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
      const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
      const cmdHex = toHex(cmdId);
      const idHex = toHex(settingId);
      const valHex = bytesToHex(valueBytes);
      const valDec = valueBytes.length === 1 ? valueBytes[0] : valueBytes.join(",");
      const prefix = `cmd:${cmdHex} id:${idHex} val:${valHex}`;
      const suffix = choiceLabel ? `${settingName}: ${choiceLabel} (${valDec})` : `${settingName}: ${valDec}`;
      logger6.info(`TX ${destIp} | ${prefix} | ${suffix}`);
    } else {
      logger6.info(`TX ${destIp} | ${cmdName}`);
    }
    logger6.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    await this.txReady;
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model${model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          if (this.refreshAfterCommand && settingId !== void 0) {
            this.requestAllSettings(destIp).catch((err) => {
              logger6.warn(`Failed to refresh settings after command: ${err}`);
            });
          }
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        for (const cb of this.discoveryListeners.values()) {
          try {
            cb(device);
          } catch {
          }
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    this.logStPayload(srcIp, originalCmdId, msg, stPayload, isResponse);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload, isResponse = true) {
    const cmdName = `cmd_${toHex(cmdId)}`;
    const data = stPayload.subarray(2, stPayload.length - 1);
    const magic = stPayload[0];
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[magic:${toHex(magic)} cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    const direction = isResponse ? "RX" : "SNIFF";
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue !== void 0 && prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger6.info(`${direction} ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              this.feedbackCallback(stateKey);
            }
          } else {
            logger6.debug(`${direction} ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger6.warn(`${direction} ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    if (decoded) {
      logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logger6.info(`${direction} ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   *
   * msg is the full packet buffer — required by the settings parsers which
   * locate the Studio-T signature themselves.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  static async getMacForDestination(destIp) {
    return new Promise((resolve, reject) => {
      const tmp = dgram2.createSocket("udp4");
      tmp.once("error", (err) => {
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      });
      tmp.connect(9, destIp, () => {
        try {
          const addr = tmp.address();
          const localAddr = addr.address;
          tmp.close();
          const ifaces = os2.networkInterfaces();
          for (const name of Object.keys(ifaces)) {
            for (const iface of ifaces[name] ?? []) {
              if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
                return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
              }
            }
          }
          reject(new Error(`No interface found for local address ${localAddr}`));
        } catch (_e) {
          reject(new Error(String(_e)));
        }
      });
    });
  }
  static async buildHeader(destIp, msgType = 32) {
    const mac = await _StController.getMacForDestination(destIp);
    const msgTypeMsb = msgType >> 8 & 255;
    const msgTypeLsb = msgType & 255;
    return Buffer.concat([
      Buffer.from([255, 255, msgTypeMsb, msgTypeLsb, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(model, destIp) {
    return this.sendAwaitAck(model, CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(model, destIp) {
    return this.sendAwaitAck(model, CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger7 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Ok);
    this.discoveredDevices = await this.stController.discoverDevices();
    if (this.discoveredDevices.length === 0) {
      logger7.warn("No devices discovered");
    } else {
      logger7.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger7.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger7.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger7.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
    }
    const effectiveModel = resolveModel(this.config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    const targetHost = this.host;
    if (targetHost) {
      try {
        await this.stController.requestAllSettings(targetHost);
      } catch (e) {
        logger7.warn(`Failed to get all settings from ${targetHost}: ${e}`);
      }
    }
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger7.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    const newHost = this.host;
    if (newHost && newHost !== previousHost) {
      try {
        await this.stController.requestAllSettings(newHost);
      } catch (e) {
        logger7.warn(`Failed to get all settings from ${newHost}: ${e}`);
      }
    }
  }
  /** Loads the device JSON for the given model and pushes it to the controller. */
  syncModel(model) {
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger7.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, [], true);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    const refreshAfterCommand = schema.refreshAfterCommand ?? true;
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger7.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger7.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}, refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  // Return config fields for web config — include discovered devices so the
  // dropdown is populated. Called by Companion on first load and after
  // setConfigSchemaVersion() triggers a refresh.
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, preferring the discovered device selection. */
  get host() {
    return resolveHost(this.config);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdDb25maWcnKVxuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0aG9zdDogc3RyaW5nXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcblx0LyoqIElQIG9mIGEgZGlzY292ZXJlZCBEYW50ZSBkZXZpY2UsIG9yICcnIHdoZW4gdGhlIHVzZXIgY2hvb3NlcyBNYW51YWwgKi9cblx0ZGlzY292ZXJlZEhvc3Q6IHN0cmluZ1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBDRU5UUkFMSVpFRCBERVZJQ0UgU0NIRU1BIENBQ0hFXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBBbGwgZGV2aWNlIEpTT04gZmlsZXMgYXJlIGxvYWRlZCBvbmNlIGludG8gbWVtb3J5IGhlcmUuIE90aGVyIG1vZHVsZXMgc2hvdWxkXG4vLyB1c2UgZ2V0RGV2aWNlc0ZvbGRlcigpLCBnZXREZXZpY2VTY2hlbWFzKCksIGFuZCBnZXREZXZpY2VTY2hlbWEoKSBpbnN0ZWFkIG9mXG4vLyByZWFkaW5nIGZpbGVzIGRpcmVjdGx5LiBDYWxsIHJlbG9hZERldmljZVNjaGVtYXMoKSBhZnRlciB3cml0aW5nIHRvIGEgZmlsZS5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuLyoqXG4gKiBEZXRlcm1pbmVzIHRoZSBjb3JyZWN0IGRldmljZXMgZm9sZGVyIHBhdGggd2l0aCBmYWxsYmFjayBzdXBwb3J0LlxuICogQ2hlY2tzIHByaW1hcnkgcGF0aCBmaXJzdCwgdGhlbiBmYWxsYmFjaywgdGhlbiB0aHJvd3MgZXJyb3IgaWYgbmVpdGhlciBleGlzdHMuXG4gKi9cbmZ1bmN0aW9uIHJlc29sdmVEZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdGNvbnN0IHByaW1hcnlQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuLi9kZXZpY2VzJylcblx0Y29uc3QgZmFsbGJhY2tQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuL2RldmljZXMnKVxuXG5cdC8vIENoZWNrIHByaW1hcnkgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhwcmltYXJ5UGF0aCkpIHtcblx0XHRsb2dnZXIuZGVidWcoYFVzaW5nIGRldmljZXMgZm9sZGVyOiAke3ByaW1hcnlQYXRofWApXG5cdFx0cmV0dXJuIHByaW1hcnlQYXRoXG5cdH1cblxuXHQvLyBDaGVjayBmYWxsYmFjayBwYXRoXG5cdGlmIChmcy5leGlzdHNTeW5jKGZhbGxiYWNrUGF0aCkpIHtcblx0XHRsb2dnZXIud2FybihgUHJpbWFyeSBkZXZpY2VzIGZvbGRlciBub3QgZm91bmQsIHVzaW5nIGZhbGxiYWNrOiAke2ZhbGxiYWNrUGF0aH1gKVxuXHRcdHJldHVybiBmYWxsYmFja1BhdGhcblx0fVxuXG5cdC8vIE5laXRoZXIgcGF0aCBleGlzdHMgLSBmYXRhbCBlcnJvclxuXHRjb25zdCBlcnJvck1zZyA9IGBEZXZpY2VzIGZvbGRlciBub3QgZm91bmQhXFxuVHJpZWQ6XFxuICAtICR7cHJpbWFyeVBhdGh9XFxuICAtICR7ZmFsbGJhY2tQYXRofVxcbk1vZHVsZSBjYW5ub3QgY29udGludWUgd2l0aG91dCBkZXZpY2Ugc2NoZW1hcy5gXG5cdGxvZ2dlci5lcnJvcihlcnJvck1zZylcblx0dGhyb3cgbmV3IEVycm9yKGVycm9yTXNnKVxufVxuXG4vLyBSZXNvbHZlIHRoZSBkZXZpY2VzIGZvbGRlciBwYXRoICh3aXRoIGV4aXN0ZW5jZSBjaGVjayBhbmQgZmFsbGJhY2spXG5jb25zdCBkZXZpY2VzRm9sZGVyID0gcmVzb2x2ZURldmljZXNGb2xkZXIoKVxuXG4vLyBJbi1tZW1vcnkgY2FjaGUgb2YgYWxsIGRldmljZSBzY2hlbWFzLCBrZXllZCBieSBtb2RlbCBudW1iZXJcbmxldCBkZXZpY2VTY2hlbWFzQ2FjaGU6IFJlY29yZDxzdHJpbmcsIGFueT4gfCBudWxsID0gbnVsbFxuXG4vKipcbiAqIFJldHVybnMgdGhlIGFic29sdXRlIHBhdGggdG8gdGhlIGRldmljZXMgZm9sZGVyLlxuICogVXNlIHRoaXMgaW5zdGVhZCBvZiByZWRlZmluaW5nIHRoZSBwYXRoIGluIGV2ZXJ5IGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdHJldHVybiBkZXZpY2VzRm9sZGVyXG59XG5cbi8qKlxuICogTG9hZHMgYWxsIGRldmljZSBKU09OIGZpbGVzIGZyb20gdGhlIGRldmljZXMgZm9sZGVyIGludG8gbWVtb3J5LlxuICogVGhpcyBzaG91bGQgb25seSBiZSBjYWxsZWQgb25jZSBhdCBpbml0aWFsaXphdGlvbiwgb3IgYWZ0ZXIgYSBmaWxlIGlzIHdyaXR0ZW4uXG4gKi9cbmZ1bmN0aW9uIGxvYWREZXZpY2VTY2hlbWFzKCk6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRjb25zdCBzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge31cblx0dHJ5IHtcblx0XHRjb25zdCBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKGRldmljZXNGb2xkZXIpLmZpbHRlcigoZikgPT4gZi5lbmRzV2l0aCgnLmpzb24nKSlcblxuXHRcdGZvciAoY29uc3QgZiBvZiBmaWxlcykge1xuXHRcdFx0Y29uc3QgZnVsbFBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgZilcblx0XHRcdGNvbnN0IGpzb24gPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCwgJ3V0ZjgnKSlcblx0XHRcdGlmIChqc29uPy5tb2RlbCkge1xuXHRcdFx0XHRzY2hlbWFzW1N0cmluZyhqc29uLm1vZGVsKV0gPSBqc29uXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBMb2FkZWQgJHtPYmplY3Qua2V5cyhzY2hlbWFzKS5sZW5ndGh9IGRldmljZSBzY2hlbWFzIGludG8gY2FjaGVgKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmVycm9yKGBGYWlsZWQgdG8gbG9hZCBkZXZpY2Ugc2NoZW1hczogJHtlfWApXG5cdH1cblx0cmV0dXJuIHNjaGVtYXNcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIHRoZSBjYWNoZS5cbiAqIEluaXRpYWxpemVzIHRoZSBjYWNoZSBvbiBmaXJzdCBjYWxsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0aWYgKCFkZXZpY2VTY2hlbWFzQ2FjaGUpIHtcblx0XHRkZXZpY2VTY2hlbWFzQ2FjaGUgPSBsb2FkRGV2aWNlU2NoZW1hcygpXG5cdH1cblx0cmV0dXJuIGRldmljZVNjaGVtYXNDYWNoZVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBzcGVjaWZpYyBkZXZpY2Ugc2NoZW1hIGJ5IG1vZGVsIG51bWJlci5cbiAqIFJldHVybnMgdW5kZWZpbmVkIGlmIHRoZSBtb2RlbCBkb2Vzbid0IGV4aXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsOiBzdHJpbmcpOiBhbnkge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBzY2hlbWFzW21vZGVsXVxufVxuXG4vKipcbiAqIFJlbG9hZHMgYWxsIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay5cbiAqIENhbGwgdGhpcyBhZnRlciB3cml0aW5nIHRvIGEgZGV2aWNlIEpTT04gZmlsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbG9hZERldmljZVNjaGVtYXMoKTogdm9pZCB7XG5cdGxvZ2dlci5pbmZvKCdSZWxvYWRpbmcgZGV2aWNlIHNjaGVtYXMgZnJvbSBkaXNrLi4uJylcblx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBsaXN0IG9mIGF2YWlsYWJsZSBtb2RlbCBudW1iZXJzLCBzb3J0ZWQuXG4gKi9cbmZ1bmN0aW9uIGxvYWRBdmFpbGFibGVNb2RlbHMoKTogc3RyaW5nW10ge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBPYmplY3Qua2V5cyhzY2hlbWFzKS5zb3J0KClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEdldENvbmZpZ0ZpZWxkcyhkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW10pOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdGNvbnN0IG1vZGVscyA9IGxvYWRBdmFpbGFibGVNb2RlbHMoKVxuXG5cdC8vIEJ1aWxkIGNob2ljZXMgbWlycm9yaW5nIHRoZSBib25qb3VyLWRldmljZSBwYXR0ZXJuOlxuXHQvLyAgIGZpcnN0IGVudHJ5IGlzIGFsd2F5cyAnTWFudWFsJyAoZW1wdHkgdmFsdWUpXG5cdC8vICAgdGhlbiBvbmUgZW50cnkgcGVyIGRpc2NvdmVyZWQgZGV2aWNlXG5cdGNvbnN0IGRldmljZUNob2ljZXMgPSBbXG5cdFx0eyBpZDogJycsIGxhYmVsOiAnTWFudWFsJyB9LFxuXHRcdC4uLmRpc2NvdmVyZWREZXZpY2VzLm1hcCgoZCkgPT4gKHtcblx0XHRcdGlkOiBkLmlwLFxuXHRcdFx0bGFiZWw6IGBNb2RlbCAke2QubW9kZWx9ICgke2QuaXB9KWAsXG5cdFx0fSkpLFxuXHRdXG5cblx0cmV0dXJuIFtcblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2aWNlIGRpc2NvdmVyeSBkcm9wZG93biBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBNaXJyb3JzIHRoZSBib25qb3VyLWRldmljZSBmaWVsZDogc2VsZWN0aW5nIGEgZGV2aWNlIHBvcHVsYXRlcyB0aGVcblx0XHQvLyBob3N0IGF1dG9tYXRpY2FsbHk7IHNlbGVjdGluZyAnTWFudWFsJyBzaG93cyB0aGUgdGV4dGlucHV0IGJlbG93LlxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2Rpc2NvdmVyZWRIb3N0Jyxcblx0XHRcdGxhYmVsOiAnRGV2aWNlJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRjaG9pY2VzOiBkZXZpY2VDaG9pY2VzLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCBhbiBhdXRvLWRpc2NvdmVyZWQgU3R1ZGlvIFRlY2hub2xvZ2llcyBEYW50ZSBkZXZpY2UsIG9yIGNob29zZSBNYW51YWwgdG8gZW50ZXIgYW4gSVAgYWRkcmVzcy4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgTWFudWFsIElQIGVudHJ5IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIE9ubHkgdmlzaWJsZSB3aGVuIGRpc2NvdmVyZWRIb3N0IGlzICcnIChNYW51YWwgc2VsZWN0ZWQpLlxuXHRcdC8vIE1hdGNoZXMgdGhlIHBhdHRlcm4gZnJvbSB0aGUgYm9uam91ci1kZXZpY2UgZG9jcy5cblx0XHR7XG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGlkOiAnaG9zdCcsXG5cdFx0XHRsYWJlbDogJ1RhcmdldCBJUCcsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0cmVnZXg6IFJlZ2V4LklQLFxuXHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogYCEkKG9wdGlvbnM6ZGlzY292ZXJlZEhvc3QpYCxcblx0XHRcdHRvb2x0aXA6ICdFbnRlciB0aGUgSVAgYWRkcmVzcyBvZiB0aGUgZGV2aWNlIG1hbnVhbGx5LicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNb2RlbCBzZWxlY3RvciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBPbmx5IHZpc2libGUgd2hlbiBNYW51YWwgbW9kZSBpcyBzZWxlY3RlZCAobm8gZGlzY292ZXJlZCBkZXZpY2UpLlxuXHRcdC8vIFdoZW4gYSBkaXNjb3ZlcmVkIGRldmljZSBpcyBzZWxlY3RlZCwgdGhlIG1vZGVsIGlzIGF1dG8tZGV0ZWN0ZWQuXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnYWN0aXZlTW9kZWwnLFxuXHRcdFx0bGFiZWw6ICdBY3RpdmUgRGV2aWNlIE1vZGVsJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogbW9kZWxzWzBdID8/ICcnLFxuXHRcdFx0Y2hvaWNlczogbW9kZWxzLm1hcCgobW9kZWwpID0+ICh7XG5cdFx0XHRcdGlkOiBtb2RlbCxcblx0XHRcdFx0bGFiZWw6IGBNb2RlbCAke21vZGVsfWAsXG5cdFx0XHR9KSksXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkaXNjb3ZlcmVkSG9zdClgLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCB3aGljaCBTdHVkaW8gVGVjaG5vbG9naWVzIG1vZGVsIGlzIGFjdGl2ZSBmb3IgYWN0aW9ucyBhbmQgR2V0IEFsbCBTZXR0aW5ncycsXG5cdFx0fSxcblx0XVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQIGZyb20gY29uZmlnIFx1MjAxNCBwcmVmZXJzIHRoZSBkaXNjb3ZlcmVkIGRldmljZVxuICogSVAgd2hlbiBvbmUgaXMgc2VsZWN0ZWQsIGZhbGxzIGJhY2sgdG8gdGhlIG1hbnVhbGx5IGVudGVyZWQgaG9zdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVIb3N0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogc3RyaW5nIHtcblx0cmV0dXJuIGNvbmZpZy5kaXNjb3ZlcmVkSG9zdCB8fCBjb25maWcuaG9zdFxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBtb2RlbCBcdTIwMTQgaWYgYSBkaXNjb3ZlcmVkIGRldmljZSBpcyBzZWxlY3RlZCwgZXh0cmFjdHNcbiAqIGl0cyBtb2RlbCBmcm9tIHRoZSBkaXNjb3ZlcmVkRGV2aWNlcyBsaXN0OyBvdGhlcndpc2UgdXNlcyBhY3RpdmVNb2RlbC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVNb2RlbChjb25maWc6IE1vZHVsZUNvbmZpZywgZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSk6IHN0cmluZyB7XG5cdGlmIChjb25maWcuZGlzY292ZXJlZEhvc3QpIHtcblx0XHRjb25zdCBkZXZpY2UgPSBkaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLmlwID09PSBjb25maWcuZGlzY292ZXJlZEhvc3QpXG5cdFx0bG9nZ2VyLmRlYnVnKGByZXNvbHZlTW9kZWw6IGRpc2NvdmVyZWRIb3N0PVwiJHtjb25maWcuZGlzY292ZXJlZEhvc3R9XCIsIGZvdW5kIGRldmljZTogJHtkZXZpY2U/Lm1vZGVsID8/ICdub25lJ31gKVxuXHRcdGlmIChkZXZpY2U/Lm1vZGVsKSB7XG5cdFx0XHRyZXR1cm4gZGV2aWNlLm1vZGVsXG5cdFx0fVxuXHR9XG5cdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBmYWxsaW5nIGJhY2sgdG8gYWN0aXZlTW9kZWw9XCIke2NvbmZpZy5hY3RpdmVNb2RlbH1cImApXG5cdHJldHVybiBjb25maWcuYWN0aXZlTW9kZWxcbn1cbiIsICJpbXBvcnQgdHlwZSBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5cbi8qKlxuICogRGVmaW5lIENvbXBhbmlvbiB2YXJpYWJsZXMgZm9yIHRoaXMgbW9kdWxlLlxuICogVmFyaWFibGVzIGNhbiBiZSB1c2VkIHRvIGRpc3BsYXkgZHluYW1pYyBzdGF0ZSBpbiBidXR0b24gbGFiZWxzLCB0cmlnZ2VycywgZXRjLlxuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRzZWxmLnNldFZhcmlhYmxlRGVmaW5pdGlvbnMoe1xuXHRcdG1vZGVsOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTnVtYmVyJyB9LFxuXHRcdG1vZGVsTmFtZTogeyBuYW1lOiAnRGV2aWNlIE1vZGVsIE5hbWUgKEZ1bGwgRGVzY3JpcHRpb24pJyB9LFxuXHRcdG1hbnVmYWN0dXJlcjogeyBuYW1lOiAnRGV2aWNlIE1hbnVmYWN0dXJlcicgfSxcblx0XHRmaXJtd2FyZTogeyBuYW1lOiAnRGV2aWNlIEZpcm13YXJlIFZlcnNpb24nIH0sXG5cdFx0ZGFudGVGVzogeyBuYW1lOiAnRGFudGUgTW9kdWxlIEZpcm13YXJlIFZlcnNpb24nIH0sXG5cdFx0bWFjOiB7IG5hbWU6ICdEZXZpY2UgTUFDIEFkZHJlc3MnIH0sXG5cdFx0aXA6IHsgbmFtZTogJ0RldmljZSBJUCBBZGRyZXNzJyB9LFxuXHR9KVxufVxuXG4vKipcbiAqIFVwZGF0ZSB2YXJpYWJsZSB2YWx1ZXMgZnJvbSBkaXNjb3ZlcmVkIGRldmljZSBpbmZvcm1hdGlvbi5cbiAqIENhbGwgdGhpcyBhZnRlciBkZXZpY2UgZGlzY292ZXJ5IG9yIHdoZW4gZGV2aWNlIGluZm8gY2hhbmdlcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdC8vIEZpbmQgdGhlIGRldmljZSBpbmZvIGZvciB0aGUgY3VycmVudCBob3N0XG5cdGNvbnN0IGN1cnJlbnRIb3N0ID0gc2VsZi5ob3N0XG5cdGNvbnN0IGRldmljZSA9IHNlbGYuZGV2aWNlcy5maW5kKChkKSA9PiBkLmlwID09PSBjdXJyZW50SG9zdClcblxuXHRpZiAoZGV2aWNlKSB7XG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7XG5cdFx0XHRtb2RlbDogZGV2aWNlLm1vZGVsIHx8ICdVbmtub3duJyxcblx0XHRcdG1vZGVsTmFtZTogZGV2aWNlLm1vZGVsTmFtZSB8fCAnJyxcblx0XHRcdG1hbnVmYWN0dXJlcjogZGV2aWNlLm1hbnVmYWN0dXJlciB8fCAnJyxcblx0XHRcdGZpcm13YXJlOiBkZXZpY2UuZmlybXdhcmVNYWluIHx8ICdVbmtub3duJyxcblx0XHRcdGRhbnRlRlc6IGRldmljZS5kYW50ZUZpcm13YXJlIHx8ICdVbmtub3duJyxcblx0XHRcdG1hYzogZGV2aWNlLm1hYyB8fCAnJyxcblx0XHRcdGlwOiBkZXZpY2UuaXAgfHwgY3VycmVudEhvc3QsXG5cdFx0fSlcblx0fSBlbHNlIHtcblx0XHQvLyBObyBkZXZpY2UgaW5mbyBhdmFpbGFibGUgLSBzaG93IG1pbmltYWwgaW5mb1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0bW9kZWw6IHNlbGYuY29uZmlnLmFjdGl2ZU1vZGVsIHx8ICdVbmtub3duJyxcblx0XHRcdG1vZGVsTmFtZTogJycsXG5cdFx0XHRtYW51ZmFjdHVyZXI6ICcnLFxuXHRcdFx0ZmlybXdhcmU6ICdVbmtub3duJyxcblx0XHRcdGRhbnRlRlc6ICdVbmtub3duJyxcblx0XHRcdG1hYzogJycsXG5cdFx0XHRpcDogY3VycmVudEhvc3QsXG5cdFx0fSlcblx0fVxufVxuIiwgImltcG9ydCB0eXBlIHsgQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG5leHBvcnQgY29uc3QgVXBncmFkZVNjcmlwdHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQ8TW9kdWxlQ29uZmlnPltdID0gW1xuXHQvKlxuXHQgKiBQbGFjZSB5b3VyIHVwZ3JhZGUgc2NyaXB0cyBoZXJlXG5cdCAqIFJlbWVtYmVyIHRoYXQgb25jZSBpdCBoYXMgYmVlbiBhZGRlZCBpdCBjYW5ub3QgYmUgcmVtb3ZlZCFcblx0ICovXG5cdC8vIGZ1bmN0aW9uIChjb250ZXh0LCBwcm9wcykge1xuXHQvLyBcdHJldHVybiB7XG5cdC8vIFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHQvLyBcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHQvLyBcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdC8vIFx0fVxuXHQvLyB9LFxuXVxuIiwgImV4cG9ydCB0eXBlIENvbXBhbmlvbklucHV0Q2hvaWNlID0ge1xuXHRpZDogc3RyaW5nIHwgbnVtYmVyXG5cdGxhYmVsOiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgRGV2aWNlU2V0dGluZyA9IHtcblx0dHlwZTogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVmYXVsdDogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhblxuXHRjaG9pY2VzPzogQ29tcGFuaW9uSW5wdXRDaG9pY2VbXVxufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBHZXQgc2V0dGluZyBmcm9tIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0JVU19TRVQgPSAweDA0IC8vIFNldCBzZXR0aW5nIG9uIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0hFQURQSE9ORSA9IDB4MDUgLy8gSGVhZHBob25lIGNvbnRyb2xzIChyZXNlcnZlZCBmb3IgZnV0dXJlIHVzZSlcbmV4cG9ydCBjb25zdCBDTURfQlVUVE9OX01PREUgPSAweDA3IC8vIEJ1dHRvbiBtb2RlIGNvbmZpZ3VyYXRpb24gKHJlc2VydmVkIGZvciBmdXR1cmUgdXNlKVxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kcyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5leHBvcnQgY29uc3QgQ01EX0dFVF9BTExfU0VUVElOR1MgPSAweDBhIC8vIFJlcXVlc3QgYWxsIGN1cnJlbnQgc2V0dGluZ3MgZnJvbSBkZXZpY2VcbmV4cG9ydCBjb25zdCBDTURfU0VUVElOR1NfUFVTSCA9IDB4MGIgLy8gVW5zb2xpY2l0ZWQgc2V0dGluZ3MgdXBkYXRlIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX0RFVl9TUEVDID0gMHgwZCAvLyBEZXZpY2Utc3BlY2lmaWMgc2V0dGluZyBnZXQvc2V0IHdpdGggQUNLXG5leHBvcnQgY29uc3QgQ01EX1JFU0VUX0RFVklDRSA9IDB4MGUgLy8gRmFjdG9yeSByZXNldCBjb21tYW5kXG5leHBvcnQgY29uc3QgQ01EX0dMT0JBTF9NSUNfS0lMTCA9IDB4MTAgLy8gRW1lcmdlbmN5IG1pYyBraWxsIChhbGwgY2hhbm5lbHMpXG5leHBvcnQgY29uc3QgQ01EX01JQ19QUkVfQlVTID0gMHgxMiAvLyBNaWMvcHJlYW1wIHNldHRpbmdzIHBlciBidXMgKGdhaW4sIHBoYW50b20sIGV0YylcbmV4cG9ydCBjb25zdCBDTURfQ0hBTk5FTCA9IDB4MTQgLy8gQ2hhbm5lbC1zcGVjaWZpYyBjb250cm9scyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBDb21tYW5kIE5hbWUgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbW1hbmROYW1lKGNtZElkOiBudW1iZXIpOiBzdHJpbmcge1xuXHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0Y2FzZSBDTURfR0VUX0ZJUk1XQVJFOlxuXHRcdFx0cmV0dXJuICdHZXQgRmlybXdhcmUgVmVyc2lvbidcblx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0cmV0dXJuICdHZXQgQnVzIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfQlVTX1NFVDpcblx0XHRcdHJldHVybiAnU2V0IEJ1cyBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0hFQURQSE9ORTpcblx0XHRcdHJldHVybiAnSGVhZHBob25lIENvbnRyb2wnXG5cdFx0Y2FzZSBDTURfQlVUVE9OX01PREU6XG5cdFx0XHRyZXR1cm4gJ0J1dHRvbiBNb2RlJ1xuXHRcdGNhc2UgQ01EX1NZU1RFTTpcblx0XHRcdHJldHVybiAnU3lzdGVtIENvbW1hbmQnXG5cdFx0Y2FzZSBDTURfR0VUX0FMTF9TRVRUSU5HUzpcblx0XHRcdHJldHVybiAnUmVxdWVzdCBBbGwgU2V0dGluZ3MnXG5cdFx0Y2FzZSBDTURfU0VUVElOR1NfUFVTSDpcblx0XHRcdHJldHVybiAnU2V0dGluZ3MgUHVzaCdcblx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzpcblx0XHRcdHJldHVybiAnTWljL1ByZSBCdXMnXG5cdFx0Y2FzZSBDTURfREVWX1NQRUM6XG5cdFx0XHRyZXR1cm4gJ0RldmljZSBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0NIQU5ORUw6XG5cdFx0XHRyZXR1cm4gJ0NoYW5uZWwgU2V0dGluZydcblx0XHRjYXNlIENNRF9SRVNFVF9ERVZJQ0U6XG5cdFx0XHRyZXR1cm4gJ1Jlc2V0IERldmljZSdcblx0XHRjYXNlIENNRF9HTE9CQUxfTUlDX0tJTEw6XG5cdFx0XHRyZXR1cm4gJ0dsb2JhbCBNaWMgS2lsbCdcblx0XHRkZWZhdWx0OlxuXHRcdFx0cmV0dXJuIGBjbWRfMHgke2NtZElkLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfWBcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSUQgR2VuZXJhdGlvbiBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENyZWF0ZXMgYSBjb25zaXN0ZW50IElEIGZvciBhY3Rpb25zLCBmZWVkYmFja3MsIGFuZCBzdGF0ZSBrZXlzLlxuICogRm9ybWF0OiBgJHttb2RlbH1fJHtjbWRfaWR9XyR7YnVzQ2h9XyR7aWR9YCBmb3IgY29tbWFuZHMgd2l0aCBidXNDaCAoZS5nLiwgXCI1MzA0XzE0XzBfMFwiKVxuICogRm9ybWF0OiBgJHttb2RlbH1fJHtjbWRfaWR9XyR7aWR9YCBmb3IgY29tbWFuZHMgd2l0aG91dCBidXNDaCAoZS5nLiwgXCI1MzA0XzEyX2RcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1ha2VTZXR0aW5nSWQoXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIgfCBzdHJpbmcsXG5cdHNldHRpbmdJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRidXNDaD86IG51bWJlciB8IHN0cmluZyxcbik6IHN0cmluZyB7XG5cdGNvbnN0IGNtZCA9IHR5cGVvZiBjbWRJZCA9PT0gJ251bWJlcicgPyBjbWRJZC50b1N0cmluZygxNikgOiBjbWRJZFxuXHRjb25zdCBpZCA9IHR5cGVvZiBzZXR0aW5nSWQgPT09ICdudW1iZXInID8gc2V0dGluZ0lkLnRvU3RyaW5nKDE2KSA6IHNldHRpbmdJZFxuXG5cdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0Y29uc3QgY2ggPSB0eXBlb2YgYnVzQ2ggPT09ICdudW1iZXInID8gYnVzQ2gudG9TdHJpbmcoMTYpIDogYnVzQ2hcblx0XHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2NofV8ke2lkfWBcblx0fVxuXG5cdHJldHVybiBgJHttb2RlbH1fJHtjbWR9XyR7aWR9YFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSGV4IEZvcm1hdHRpbmcgSGVscGVycyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogQ29udmVydHMgYSBudW1iZXIgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4IGFuZCBwYWRkaW5nLlxuICogQHBhcmFtIHZhbHVlIC0gVGhlIG51bWJlciB0byBjb252ZXJ0XG4gKiBAcGFyYW0gcGFkTGVuZ3RoIC0gTnVtYmVyIG9mIGhleCBkaWdpdHMgdG8gcGFkIHRvIChkZWZhdWx0OiAyKVxuICogQHJldHVybnMgRm9ybWF0dGVkIGhleCBzdHJpbmcgKGUuZy4sIFwiMHgwZFwiLCBcIjB4ZmZcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSGV4KHZhbHVlOiBudW1iZXIsIHBhZExlbmd0aCA9IDIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHt2YWx1ZS50b1N0cmluZygxNikucGFkU3RhcnQocGFkTGVuZ3RoLCAnMCcpfWBcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBhcnJheSBvZiBieXRlcyB0byBhIGhleCBzdHJpbmcgd2l0aCAweCBwcmVmaXguXG4gKiBAcGFyYW0gYnl0ZXMgLSBBcnJheSBvZiBieXRlcyBvciBCdWZmZXJcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGFmZjEyXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBieXRlc1RvSGV4KGJ5dGVzOiBudW1iZXJbXSB8IEJ1ZmZlcik6IHN0cmluZyB7XG5cdHJldHVybiBgMHgke0FycmF5LmZyb20oYnl0ZXMpXG5cdFx0Lm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJyl9YFxufVxuXG4vKipcbiAqIEZvcm1hdHMgUkdCIGNvbG9yIGJ5dGVzIGFzIGEgQ1NTIGhleCBjb2xvciBzdHJpbmcuXG4gKiBAcGFyYW0gciAtIFJlZCBjb21wb25lbnQgKDAtMjU1KVxuICogQHBhcmFtIGcgLSBHcmVlbiBjb21wb25lbnQgKDAtMjU1KVxuICogQHBhcmFtIGIgLSBCbHVlIGNvbXBvbmVudCAoMC0yNTUpXG4gKiBAcmV0dXJucyBDU1MgaGV4IGNvbG9yIHN0cmluZyAoZS5nLiwgXCIjRkYwMEFCXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRSZ2JDb2xvcihyOiBudW1iZXIsIGc6IG51bWJlciwgYjogbnVtYmVyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAjJHtbciwgZywgYl1cblx0XHQubWFwKCh2KSA9PiB2LnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuXHRcdC5qb2luKCcnKVxuXHRcdC50b1VwcGVyQ2FzZSgpfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIFBhcnNpbmcgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBQYXJzZXMgYSBzZXR0aW5nIElEIHN0cmluZyBpbnRvIGl0cyBjb21wb25lbnRzLlxuICogQHBhcmFtIGlkIC0gU2V0dGluZyBJRCBzdHJpbmcgKGUuZy4sIFwiMzkxX2RfMFwiIG9yIFwiNTMwNF8xNF8wXzFcIilcbiAqIEByZXR1cm5zIFBhcnNlZCBjb21wb25lbnRzIHdpdGggaGV4IHN0cmluZ3MgY29udmVydGVkIHRvIG51bWJlcnNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ0lkKGlkOiBzdHJpbmcpOiB7IG1vZGVsOiBzdHJpbmc7IGNtZElkOiBudW1iZXI7IGJhc2VJZDogbnVtYmVyIH0ge1xuXHRjb25zdCBbbW9kZWwsIGNtZElkU3RyLCBpZFN0cl0gPSBpZC5zcGxpdCgnXycpXG5cdHJldHVybiB7XG5cdFx0bW9kZWwsXG5cdFx0Y21kSWQ6IHBhcnNlSW50KGNtZElkU3RyLCAxNiksXG5cdFx0YmFzZUlkOiBwYXJzZUludChpZFN0ciwgMTYpLFxuXHR9XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBNb2RlbCBEaXN0YW5jZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENhbGN1bGF0ZXMgbnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIHR3byBtb2RlbCBudW1iZXJzLlxuICogVXNlZCBmb3IgZmluZGluZyBzaW1pbGFyIG1vZGVscyBmb3Igc2V0dGluZyBpbmZlcmVuY2UuXG4gKiBAcGFyYW0gbW9kZWxBIC0gRmlyc3QgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MVwiKVxuICogQHBhcmFtIG1vZGVsQiAtIFNlY29uZCBtb2RlbCBudW1iZXIgKGUuZy4sIFwiMzkyXCIpXG4gKiBAcmV0dXJucyBOdW1lcmljIGRpc3RhbmNlIGJldHdlZW4gbW9kZWxzLCBvciBJbmZpbml0eSBpZiBlaXRoZXIgaXMgbm9uLW51bWVyaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1vZGVsRGlzdGFuY2UobW9kZWxBOiBzdHJpbmcsIG1vZGVsQjogc3RyaW5nKTogbnVtYmVyIHtcblx0Y29uc3QgbmEgPSBwYXJzZUludChtb2RlbEEucmVwbGFjZSgvXFxEL2csICcnKSwgMTApXG5cdGNvbnN0IG5iID0gcGFyc2VJbnQobW9kZWxCLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRpZiAoTnVtYmVyLmlzTmFOKG5hKSB8fCBOdW1iZXIuaXNOYU4obmIpKSByZXR1cm4gSW5maW5pdHlcblx0cmV0dXJuIE1hdGguYWJzKG5hIC0gbmIpXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBTY2hlbWEgTm9ybWFsaXphdGlvbiBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIE5vcm1hbGl6ZXMgZGV2aWNlIHNjaGVtYXMgdG8gZW5zdXJlIGNtZFNjaGVtYSBpcyBhbHdheXMgYW4gYXJyYXkuXG4gKiBUaGlzIGhlbHBlciBlbGltaW5hdGVzIGR1cGxpY2F0ZSBzY2hlbWEgdHJhbnNmb3JtYXRpb24gY29kZS5cbiAqIEBwYXJhbSBzY2hlbWFzUmF3IC0gUmF3IHNjaGVtYXMgZnJvbSBnZXREZXZpY2VTY2hlbWFzKClcbiAqIEByZXR1cm5zIE5vcm1hbGl6ZWQgc2NoZW1hcyB3aXRoIGd1YXJhbnRlZWQgY21kU2NoZW1hIGFycmF5c1xuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoXG5cdHNjaGVtYXNSYXc6IFJlY29yZDxzdHJpbmcsIGFueT4sXG4pOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4ge1xuXHRjb25zdCBub3JtYWxpemVkOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4gPSB7fVxuXHRmb3IgKGNvbnN0IFttb2RlbCwganNvbl0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hc1JhdykpIHtcblx0XHRub3JtYWxpemVkW21vZGVsXSA9IHtcblx0XHRcdG1vZGVsOiBqc29uLm1vZGVsLFxuXHRcdFx0Y21kU2NoZW1hOiBBcnJheS5pc0FycmF5KGpzb24uY21kU2NoZW1hKSA/IGpzb24uY21kU2NoZW1hIDogW10sXG5cdFx0fVxuXHR9XG5cdHJldHVybiBub3JtYWxpemVkXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBBY3Rpb24gTG9va3VwIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogRmluZHMgYW4gYWN0aW9uL3NldHRpbmcgaW4gdGhlIHNjaGVtYSwgc3VwcG9ydGluZyBib3RoIGV4YWN0IG1hdGNoZXMgYW5kIGlkQWRkIG9mZnNldHMuXG4gKiBUaGlzIGhlbHBlciBlbGltaW5hdGVzIGR1cGxpY2F0ZSBhY3Rpb24gbG9va3VwIGxvZ2ljIGFjcm9zcyBtdWx0aXBsZSBmaWxlcy5cbiAqIEBwYXJhbSBzY2hlbWFzIC0gTm9ybWFsaXplZCBkZXZpY2Ugc2NoZW1hc1xuICogQHBhcmFtIG1vZGVsIC0gRGV2aWNlIG1vZGVsIChlLmcuLCBcIjM5MVwiKVxuICogQHBhcmFtIGNtZElkIC0gQ29tbWFuZCBJRFxuICogQHBhcmFtIHNldHRpbmdJZCAtIFNldHRpbmcgSUQgKG1heSBpbmNsdWRlIGlkQWRkIG9mZnNldClcbiAqIEByZXR1cm5zIE1hdGNoaW5nIGFjdGlvbi9zZXR0aW5nIG9yIHVuZGVmaW5lZFxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZEFjdGlvbkZvclNldHRpbmcoXG5cdHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9Pixcblx0bW9kZWw6IHN0cmluZyxcblx0Y21kSWQ6IG51bWJlcixcblx0c2V0dGluZ0lkOiBudW1iZXIsXG4pOiBhbnkge1xuXHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRpZiAoIXNjaGVtYSB8fCAhQXJyYXkuaXNBcnJheShzY2hlbWEuY21kU2NoZW1hKSkgcmV0dXJuIHVuZGVmaW5lZFxuXG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHMuY21kX2lkID09PSBjbWRJZCAmJiBzLmlkID09PSBzZXR0aW5nSWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2gsIHRyeSB0byBmaW5kIGJhc2UgYWN0aW9uIHdpdGggaWRBZGRcblx0aWYgKCFhY3Rpb24pIHtcblx0XHRhY3Rpb24gPSBzY2hlbWEuY21kU2NoZW1hLmZpbmQoKHM6IGFueSkgPT4ge1xuXHRcdFx0aWYgKHMuY21kX2lkICE9PSBjbWRJZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IHMub3B0aW9ucz8uZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgc2V0dGluZ0lkIG1hdGNoZXMgYmFzZSArIGFueSBpZEFkZCBvZmZzZXRcblx0XHRcdGNvbnN0IG9mZnNldCA9IHNldHRpbmdJZCAtIHMuaWRcblx0XHRcdHJldHVybiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KVxuXHRcdH0pXG5cdH1cblxuXHRyZXR1cm4gYWN0aW9uXG59XG4iLCAiLyoqXG4gKiBidWlsZC1jb21tYW5kcy50c1xuICogLSBVc2VzIGNlbnRyYWxpemVkIGRldmljZSBzY2hlbWEgY2FjaGUgZnJvbSBjb25maWcudHNcbiAqIC0gUHJvZHVjZXMgQ29tcGFuaW9uIGFjdGlvbiBkZWZpbml0aW9ucyBhbmQgZmVlZGJhY2tzXG4gKi9cblxuaW1wb3J0IHtcblx0Q29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMsXG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24sXG5cdENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBtYWtlU2V0dGluZ0lkIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLSBPcHRpb24gQnVpbGRlciAtLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5mdW5jdGlvbiBidWlsZE9wdGlvbihvOiBhbnkpOiBhbnkge1xuXHRjb25zdCBiYXNlID0ge1xuXHRcdHR5cGU6IG8udHlwZSxcblx0XHRpZDogby5pZCxcblx0XHRsYWJlbDogby5sYWJlbCxcblx0XHRkZWZhdWx0OiBvLmRlZmF1bHQsXG5cdFx0dG9vbHRpcDogby50b29sdGlwLFxuXHR9XG5cblx0c3dpdGNoIChvLnR5cGUpIHtcblx0XHRjYXNlICdkcm9wZG93bic6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBjaG9pY2VzOiBvLmNob2ljZXMgPz8gW10gfVxuXG5cdFx0Y2FzZSAnbnVtYmVyJzpcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdC4uLmJhc2UsXG5cdFx0XHRcdG1pbjogby5taW4sXG5cdFx0XHRcdG1heDogby5tYXgsXG5cdFx0XHRcdHN0ZXA6IG8uc3RlcCA/PyAxLFxuXHRcdFx0XHRyYW5nZTogdHJ1ZSxcblx0XHRcdH1cblxuXHRcdGNhc2UgJ2NoZWNrYm94Jzpcblx0XHRcdHJldHVybiB7IC4uLmJhc2UsIGRlZmF1bHQ6IG8uZGVmYXVsdCA/PyBmYWxzZSB9XG5cblx0XHRjYXNlICd0ZXh0aW5wdXQnOlxuXHRcdGNhc2UgJ2NvbG9ycGlja2VyJzpcblx0XHRjYXNlICdzdGF0aWMtdGV4dCc6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIGEuY21kX2lkLCBhLmlkKVxuXG5cdFx0XHRjb25zdCBvcHRpb25zID0gKGEub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHRjb25zdCBhY3Rpb246IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHthLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVBY3Rpb25zICovXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGFjdGlvbnNbYWN0aW9uSWRdID0gYWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvbnNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBGZWVkYmFja3MgLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGZWVkYmFja3MoKTogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgZmVlZGJhY2tzOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3Qgc2V0dGluZyBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0lkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgc2V0dGluZy5jbWRfaWQsIHNldHRpbmcuaWQpXG5cblx0XHRcdC8vIEJ1aWxkIG9wdGlvbnNcblx0XHRcdGNvbnN0IGFsbE9wdGlvbnMgPSAoc2V0dGluZy5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdC8vIEZpbHRlciBvdXQgJ3ZhbHVlJyBvcHRpb24gZm9yIHZhbHVlIGZlZWRiYWNrIChrZWVwIG9ubHkgYnVzQ2gvaWRBZGQpXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbnMgPSBhbGxPcHRpb25zLmZpbHRlcigob3B0OiBhbnkpID0+IG9wdC5pZCAhPT0gJ3ZhbHVlJylcblxuXHRcdFx0Ly8gQWRkIGEgY2hlY2tib3ggb3B0aW9uIHRvIHJldHVybiBsYWJlbCBpbnN0ZWFkIG9mIHZhbHVlXG5cdFx0XHR2YWx1ZU9wdGlvbnMucHVzaCh7XG5cdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0bGFiZWw6ICdTaG93IExhYmVsJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHR9KVxuXG5cdFx0XHQvLyBWYWx1ZSBmZWVkYmFjayBmb3IgYWxsIHNldHRpbmdzIChhcHBlYXJzIGluIFZhcmlhYmxlcyBsaXN0KVxuXHRcdFx0Y29uc3QgdmFsdWVGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHR0eXBlOiAndmFsdWUnLFxuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnM6IHZhbHVlT3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRyZXR1cm4gMFxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRmZWVkYmFja3NbYmFzZUZlZWRiYWNrSWRdID0gdmFsdWVGZWVkYmFja1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IHJlc29sdmVNb2RlbCwgZ2V0RGV2aWNlc0ZvbGRlciwgZ2V0RGV2aWNlU2NoZW1hLCBnZXREZXZpY2VTY2hlbWFzLCByZWxvYWREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMgfSBmcm9tICcuL3R5cGVzLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5cbmltcG9ydCB7IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uLCBzYXZlTW9kZWxKc29uUHJldHR5LCB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MgfSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ0FjdGlvbnMnKVxuXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlQWN0aW9ucyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBzY2hlbWFzUmF3ID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IHJhd0FjdGlvbnMgPSBidWlsZEFjdGlvbnMoKVxuXHRjb25zdCBzY2hlbWFzID0gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoc2NoZW1hc1Jhdylcblx0Y29uc3Qgd2lyZWRBY3Rpb25zOiBhbnkgPSB7fVxuXG5cdC8vIEdldCB0aGUgYWN0aXZlIG1vZGVsIHVzaW5nIHJlc29sdmVNb2RlbFxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbChzZWxmLmNvbmZpZywgc2VsZi5kZXZpY2VzKVxuXHRsb2dnZXIuaW5mbyhcblx0XHRgVXBkYXRlQWN0aW9uczogYWN0aXZlTW9kZWw9XCIke2FjdGl2ZU1vZGVsfVwiLCBkaXNjb3ZlcmVkSG9zdD1cIiR7c2VsZi5jb25maWcuZGlzY292ZXJlZEhvc3R9XCIsIGRldmljZXMgY291bnQ9JHtzZWxmLmRldmljZXMubGVuZ3RofWAsXG5cdClcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEdMT0JBTDogR0VUIEFMTCBTRVRUSU5HUyAoQVVUTyBKU09OIFVQREFURSlcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0d2lyZWRBY3Rpb25zWydnbG9iYWxfZ2V0QWxsU2V0dGluZ3MnXSA9IHtcblx0XHRuYW1lOiAnR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzIChBdXRvLVVwZGF0ZSBKU09OKScsXG5cdFx0b3B0aW9uczogW10sXG5cdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdGNvbnN0IG1vZGVsID0gYWN0aXZlTW9kZWxcblx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cblx0XHRcdGNvbnN0IGJ1ZiA9IGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIHRvIGdldCB0aGUgc2NoZW1hXG5cdFx0XHRsZXQgbW9kZWxKc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdFx0aWYgKCFtb2RlbEpzb24pIHtcblx0XHRcdFx0bG9nZ2VyLmVycm9yKGBNb2RlbCAke21vZGVsfSBzY2hlbWEgbm90IGZvdW5kIGluIGNhY2hlYClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdC8vIFBhcnNlIHdpdGggYXV0by1kZXRlY3Rpb25cblx0XHRcdGNvbnN0IHsgc2V0dGluZ3M6IHBhcnNlZCwgZGV0ZWN0ZWRTZWN0aW9uZWQgfSA9IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uKG1vZGVsLCBidWYpXG5cdFx0XHRsb2dnZXIuZGVidWcoYHBhcnNlZCByZXBseTogJHtKU09OLnN0cmluZ2lmeShwYXJzZWQpfWApXG5cblx0XHRcdC8vIElmIHdlIGF1dG8tZGV0ZWN0ZWQgdGhlIGZvcm1hdCwgYWRkIGl0IHRvIHRoZSBKU09OXG5cdFx0XHRpZiAoZGV0ZWN0ZWRTZWN0aW9uZWQgIT09IG51bGwpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgc2VjdGlvbmVkPSR7ZGV0ZWN0ZWRTZWN0aW9uZWR9LCBhZGRpbmcgdG8gbW9kZWwgSlNPTmApXG5cdFx0XHRcdG1vZGVsSnNvbiA9IHsgLi4ubW9kZWxKc29uLCBzZWN0aW9uZWQ6IGRldGVjdGVkU2VjdGlvbmVkIH1cblx0XHRcdH1cblxuXHRcdFx0Y29uc3QgdXBkYXRlZCA9IHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyhtb2RlbEpzb24sIHBhcnNlZCwgc2NoZW1hcylcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgbmV3IEFjdGlvbnMganNvbjogJHtKU09OLnN0cmluZ2lmeSh1cGRhdGVkLCBudWxsLCAyKX1gKVxuXG5cdFx0XHQvLyBTYXZlIHRoZSB1cGRhdGVkIEpTT04gdG8gZGlza1xuXHRcdFx0Y29uc3QgZGV2aWNlc0ZvbGRlciA9IGdldERldmljZXNGb2xkZXIoKVxuXHRcdFx0Y29uc3Qgc2NoZW1hUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBgTW9kZWwke21vZGVsfS5qc29uYClcblx0XHRcdHNhdmVNb2RlbEpzb25QcmV0dHkoc2NoZW1hUGF0aCwgdXBkYXRlZClcblxuXHRcdFx0Ly8gUmVsb2FkIHRoZSBjYWNoZSBhZnRlciB3cml0aW5nIHRvIGZpbGVcblx0XHRcdHJlbG9hZERldmljZVNjaGVtYXMoKVxuXG5cdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gSlNPTiBhdXRvLXVwZGF0ZWQgZnJvbSBnZXRBbGxTZXR0aW5nc2ApXG5cdFx0fSxcblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgQUNUSU9OUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFthY3Rpb25JZCwgYWN0aW9uXSBvZiBPYmplY3QuZW50cmllcyhyYXdBY3Rpb25zKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGFjdGlvbklkKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGFjdGlvbnMgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIEdldCB0aGUgcmF3IGFjdGlvbiBzY2hlbWEgdG8gYWNjZXNzIGZpeGVkIGJ1c0NoIHZhbHVlXG5cdFx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0XHRjb25zdCByYXdBY3Rpb24gPSBzY2hlbWE/LmNtZFNjaGVtYT8uZmluZCgoYTogYW55KSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gYmFzZUlkKVxuXG5cdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdC4uLmFjdGlvbixcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoZXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHQvLyBVc2UgYnVzQ2ggZnJvbSBvcHRpb25zIGlmIHByZXNlbnQsIG90aGVyd2lzZSB1c2UgZml4ZWQgdmFsdWUgZnJvbSBzY2hlbWFcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBldmVudC5vcHRpb25zWydidXNDaCddICE9PSB1bmRlZmluZWQgPyBldmVudC5vcHRpb25zWydidXNDaCddIDogcmF3QWN0aW9uPy5idXNDaFxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGV2ZW50Lm9wdGlvbnNbJ3ZhbHVlJ11cblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBldmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblxuXHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5zZW5kQXdhaXRBY2soYWN0aXZlTW9kZWwsIGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgaXApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgTUlDIEtJTEwgKE9OTFkgSUYgQUNUSVZFIE1PREVMIFNVUFBPUlRTIElUKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Y29uc3QgYWN0aXZlU2NoZW1hID0gc2NoZW1hc1thY3RpdmVNb2RlbF1cblx0aWYgKGFjdGl2ZVNjaGVtYSkge1xuXHRcdGNvbnN0IHN1cHBvcnRzTWljS2lsbCA9IChhY3RpdmVTY2hlbWEuY21kU2NoZW1hID8/IFtdKS5zb21lKChhOiBhbnkpID0+IGEubmFtZS5pbmNsdWRlcygnS2lsbCcpKVxuXG5cdFx0aWYgKHN1cHBvcnRzTWljS2lsbCkge1xuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBgJHthY3RpdmVNb2RlbH1fbWljS2lsbGBcblxuXHRcdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7YWN0aXZlTW9kZWx9XSBNaWMgS2lsbGAsXG5cdFx0XHRcdG9wdGlvbnM6IFtdLFxuXHRcdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYE1pYyBLaWxsIFx1MjE5MiBNb2RlbCAke2FjdGl2ZU1vZGVsfSBAICR7aXB9YClcblx0XHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5nbG9iYWxNaWNLaWxsKGFjdGl2ZU1vZGVsLCBpcClcblx0XHRcdFx0fSxcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEFjdGlvbkRlZmluaXRpb25zKHdpcmVkQWN0aW9ucylcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRlQWN0aW9uczogd2lyZWQgYWN0aW9uczogJHtPYmplY3Qua2V5cyh3aXJlZEFjdGlvbnMpLmxlbmd0aH1gKVxufVxuIiwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYSB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9CVVNfU0VULFxuXHRDTURfQ0hBTk5FTCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdGZvcm1hdFJnYkNvbG9yLFxuXHRtb2RlbERpc3RhbmNlLFxufSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1NldHRpbmdzUGFyc2VyJylcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVFlQRVNcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IHR5cGUgUGFyc2VkU2V0dGluZyA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRidXNDaD86IG51bWJlciAvLyBPcHRpb25hbDogb25seSBwcmVzZW50IGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoICgweDA0LCAweDEyLCAweDE0KVxuXHR2YWx1ZUJ5dGVzOiBudW1iZXJbXVxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbk9wdGlvbiA9IHtcblx0aWQ/OiBzdHJpbmdcblx0bGFiZWw6IHN0cmluZ1xuXHR0eXBlOiBzdHJpbmdcblx0ZGVmYXVsdDogdW5rbm93blxuXHR0b29sdGlwPzogc3RyaW5nXG5cdGNob2ljZXM/OiBBcnJheTx7IGlkOiBudW1iZXI7IGxhYmVsOiBzdHJpbmcgfT5cbn1cblxuZXhwb3J0IHR5cGUgU3RBY3Rpb24gPSB7XG5cdGNtZF9pZDogbnVtYmVyXG5cdGlkOiBudW1iZXJcblx0bmFtZTogc3RyaW5nXG5cdG9wdGlvbnM6IFN0QWN0aW9uT3B0aW9uW11cblx0YnVzQ2g/OiBudW1iZXIgLy8gRml4ZWQgY2hhbm5lbCB2YWx1ZSBmb3IgYWN0aW9ucyB0aGF0IGRvbid0IGhhdmUgYSBjaGFubmVsIG9wdGlvblxufVxuXG5leHBvcnQgdHlwZSBTdE1vZGVsSnNvbiA9IHtcblx0bW9kZWw6IHN0cmluZ1xuXHRzZWN0aW9uZWQ/OiBib29sZWFuXG5cdHJlZnJlc2hBZnRlckNvbW1hbmQ/OiBib29sZWFuXG5cdGNtZFNjaGVtYTogU3RBY3Rpb25bXVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGT1JNQVQgSEVMUEVSU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBnZXRNb2RlbENvbmZpZyhtb2RlbDogc3RyaW5nKTogeyBzZWN0aW9uZWQ6IGJvb2xlYW47IHJnYklkczogU2V0PG51bWJlcj4gfSB7XG5cdGNvbnN0IHJnYklkcyA9IG5ldyBTZXQ8bnVtYmVyPigpXG5cdGxldCBzZWN0aW9uZWQgPSBmYWxzZVxuXG5cdHRyeSB7XG5cdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIGluc3RlYWQgb2YgcmVhZGluZyBmcm9tIGRpc2tcblx0XHRjb25zdCBqc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghanNvbikge1xuXHRcdFx0Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgc2NoZW1hLCByZXR1cm4gZGVmYXVsdHNcblx0XHRcdHJldHVybiB7IHNlY3Rpb25lZCwgcmdiSWRzIH1cblx0XHR9XG5cblx0XHQvLyBSZWFkIHNlY3Rpb25lZCBwcm9wZXJ0eSAoZGVmYXVsdCB0byBmYWxzZSBpZiBub3Qgc3BlY2lmaWVkKVxuXHRcdHNlY3Rpb25lZCA9IGpzb24uc2VjdGlvbmVkID8/IGZhbHNlXG5cblx0XHQvLyBCdWlsZCBSR0IgSURzIHNldFxuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHQvLyBBZGQgdGhlIGJhc2UgSURcblx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQpXG5cblx0XHRcdFx0Ly8gSWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkIGNob2ljZXMsIGFkZCBhbGwgdGhlIG9mZnNldCBJRHMgdG9vXG5cdFx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjaG9pY2Ugb2YgaWRBZGRPcHRpb24uY2hvaWNlcykge1xuXHRcdFx0XHRcdFx0aWYgKHR5cGVvZiBjaG9pY2UuaWQgPT09ICdudW1iZXInKSB7XG5cdFx0XHRcdFx0XHRcdHJnYklkcy5hZGQoYWN0aW9uLmlkICsgY2hvaWNlLmlkKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCAoX2Vycikge1xuXHRcdC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHNjaGVtYSwgcmV0dXJuIGRlZmF1bHRzXG5cdH1cblxuXHRyZXR1cm4geyBzZWN0aW9uZWQsIHJnYklkcyB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZJTkQgVEhFIFJFQUwgNUEgUEFZTE9BRCBJTkRFWFxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmOiBCdWZmZXIpOiBudW1iZXIge1xuXHRjb25zdCBzaWdJbmRleCA9IGJ1Zi5pbmRleE9mKEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcpKVxuXHRpZiAoc2lnSW5kZXggPCAwKSB0aHJvdyBuZXcgRXJyb3IoJ05vIFN0dWRpby1UIHNpZ25hdHVyZSBpbiBwYWNrZXQnKVxuXG5cdGNvbnN0IHBheWxvYWRJbmRleCA9IHNpZ0luZGV4ICsgOFxuXHRpZiAoYnVmW3BheWxvYWRJbmRleF0gIT09IDB4NWEpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIDB4NUEgYWZ0ZXIgU3R1ZGlvLVQsIGZvdW5kICR7YnVmW3BheWxvYWRJbmRleF0udG9TdHJpbmcoMTYpfWApXG5cdH1cblxuXHRyZXR1cm4gcGF5bG9hZEluZGV4XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZMQVQgUEFSU0VSXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYmxvY2s6IEJ1ZmZlciwgcmdiSWRzOiBTZXQ8bnVtYmVyPiA9IG5ldyBTZXQoKSk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGxldCBwID0gMFxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0d2hpbGUgKHAgPCBibG9jay5sZW5ndGgpIHtcblx0XHRjb25zdCBpZCA9IGJsb2NrW3BdXG5cdFx0aWYgKHAgKyAxID49IGJsb2NrLmxlbmd0aCkgYnJlYWtcblxuXHRcdC8vIFJHQiBjYXNlIC0gY2hlY2sgaWYgdGhpcyBJRCBpcyBhIGtub3duIGNvbG9ycGlja2VyXG5cdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHAgKyAzIDwgYmxvY2subGVuZ3RoKSB7XG5cdFx0XHRvdXQucHVzaCh7XG5cdFx0XHRcdGNtZF9pZDogQ01EX0RFVl9TUEVDLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXSwgYmxvY2tbcCArIDJdLCBibG9ja1twICsgM11dLFxuXHRcdFx0fSlcblx0XHRcdHAgKz0gNFxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHRvdXQucHVzaCh7IGNtZF9pZDogQ01EX0RFVl9TUEVDLCBpZCwgdmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXV0gfSlcblx0XHRwICs9IDJcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Y29uc3QgYmxvY2tMZW4gPSBidWZbaWR4ICsgMl1cblx0Y29uc3Qgc3RhcnQgPSBpZHggKyAzXG5cdGNvbnN0IGVuZCA9IHN0YXJ0ICsgYmxvY2tMZW5cblx0aWYgKGVuZCA+IGJ1Zi5sZW5ndGgpIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBibG9jayBsZW5ndGgnKVxuXG5cdGNvbnN0IHsgcmdiSWRzIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYnVmLnN1YmFycmF5KHN0YXJ0LCBlbmQpLCByZ2JJZHMpXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNFQ1RJT05FRCBQQVJTRVJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZjogQnVmZmVyLCBtb2RlbDogc3RyaW5nKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgYSBnZXRBbGxTZXR0aW5ncyByZXBseScpXG5cdH1cblxuXHQvLyBDTURfR0VUX0FMTF9TRVRUSU5HUyBoYXMgYSB0b3RhbC1sZW5ndGggYnl0ZSBhdCBpZHgrMiBiZWZvcmUgdGhlIHNlY3Rpb25zOyBDTURfU0VUVElOR1NfUFVTSCBkb2VzIG5vdC5cblx0bGV0IHAgPSBjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgPyBpZHggKyAzIDogaWR4ICsgMlxuXHRjb25zdCBlbmQgPSBidWYubGVuZ3RoIC0gMVxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0Ly8gR2V0IFJHQiBJRHMgZm9yIHRoaXMgbW9kZWxcblx0Y29uc3QgeyByZ2JJZHMgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgaW4gdGhlaXIgc2VjdGlvbiBzdHJ1Y3R1cmVcblx0Y29uc3QgY29tbWFuZHNXaXRoQnVzQ2ggPSBbQ01EX0JVU19TRVQsIENNRF9NSUNfUFJFX0JVUywgQ01EX0NIQU5ORUxdXG5cblx0d2hpbGUgKHAgKyAyIDwgZW5kKSB7XG5cdFx0Y29uc3QgY21kTGVuID0gYnVmW3BdXG5cdFx0Y29uc3Qgc2VjdGlvbkNtZElkID0gYnVmW3AgKyAxXVxuXG5cdFx0Y29uc3Qgc2VjdGlvbkVuZCA9IHAgKyAxICsgY21kTGVuXG5cdFx0aWYgKHNlY3Rpb25FbmQgPiBlbmQpIGJyZWFrXG5cblx0XHQvLyBDaGVjayBpZiB0aGlzIGNvbW1hbmQgaW5jbHVkZXMgYSBidXNDaCBieXRlXG5cdFx0Y29uc3QgaGFzQnVzQ2ggPSBjb21tYW5kc1dpdGhCdXNDaC5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cblx0XHRsZXQgYnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZFxuXHRcdGxldCBkYXRhTGVuOiBudW1iZXJcblx0XHRsZXQgcTogbnVtYmVyXG5cblx0XHRpZiAoaGFzQnVzQ2gpIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRkYXRhTGVuID0gYnVmW3AgKyAzXVxuXHRcdFx0cSA9IHAgKyA0IC8vIERhdGEgc3RhcnRzIGFmdGVyIGNtZExlbiwgY21kSWQsIGJ1c0NoLCBkYXRhTGVuXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbZGF0YUxlbl0gW2lkOnZhbCBwYWlyc11cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDJdXG5cdFx0XHRxID0gcCArIDMgLy8gRGF0YSBzdGFydHMgYWZ0ZXIgY21kTGVuLCBjbWRJZCwgZGF0YUxlblxuXHRcdH1cblxuXHRcdGNvbnN0IHFFbmQgPSBxICsgZGF0YUxlblxuXG5cdFx0d2hpbGUgKHEgKyAxIDwgcUVuZCkge1xuXHRcdFx0Y29uc3QgaWQgPSBidWZbcV1cblx0XHRcdGxldCB2YWx1ZUJ5dGVzOiBudW1iZXJbXVxuXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIElEIGlzIGFuIFJHQiBjb2xvcnBpY2tlciAobmVlZHMgMyBieXRlcylcblx0XHRcdGlmIChyZ2JJZHMuaGFzKGlkKSAmJiBxICsgMyA8IHFFbmQpIHtcblx0XHRcdFx0dmFsdWVCeXRlcyA9IFtidWZbcSArIDFdLCBidWZbcSArIDJdLCBidWZbcSArIDNdXVxuXHRcdFx0XHRxICs9IDRcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXV1cblx0XHRcdFx0cSArPSAyXG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHNldHRpbmc6IFBhcnNlZFNldHRpbmcgPSB7XG5cdFx0XHRcdGNtZF9pZDogc2VjdGlvbkNtZElkLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdHNldHRpbmcuYnVzQ2ggPSBidXNDaFxuXHRcdFx0fVxuXHRcdFx0b3V0LnB1c2goc2V0dGluZylcblx0XHR9XG5cblx0XHRwID0gc2VjdGlvbkVuZFxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBHRU5FUklDIFNFVFRJTkdTIFJFU1BPTlNFIFBBUlNFUiAoMHgwYSBnZXQtYWxsICsgMHgwYiB1bnNvbGljaXRlZCBwdXNoKVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBhbnkgZnVsbCBzZXR0aW5ncyBibG9jayByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhlIGNtZElkIGlzIDB4MGFcbiAqIChyZXNwb25zZSB0byBHZXQgQWxsIFNldHRpbmdzKSBvciAweDBiICh1bnNvbGljaXRlZCBwdXNoIGFmdGVyIGEgc2V0KS5cbiAqIEJvdGggdXNlIHRoZSBzYW1lIHNlY3Rpb25lZCBvciBmbGF0IGJsb2NrIGxheW91dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ3NSZXNwb25zZShtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgTm90IGEgc2V0dGluZ3MgYmxvY2sgKGNtZElkPTB4JHtjbWRJZC50b1N0cmluZygxNil9KWApXG5cdH1cblx0Y29uc3QgeyBzZWN0aW9uZWQgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gc2VjdGlvbmVkID8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbCkgOiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcbn1cblxuLyoqXG4gKiBGb3JtYXRzIGEgc2luZ2xlIHBhcnNlZCBzZXR0aW5nIGludG8gYSBodW1hbi1yZWFkYWJsZSBzdHJpbmcgdXNpbmcgYWN0aW9uXG4gKiBkZWZpbml0aW9ucyBmcm9tIHRoZSBkZXZpY2UgSlNPTi4gRmFsbHMgYmFjayB0byBoZXggSURzIHdoZW4gdW5rbm93bi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZzogUGFyc2VkU2V0dGluZywgYWN0aW9uczogU3RBY3Rpb25bXSk6IHN0cmluZyB7XG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gc2V0dGluZy5jbWRfaWQgJiYgYS5pZCA9PT0gc2V0dGluZy5pZClcblxuXHQvLyBJZiBubyBleGFjdCBtYXRjaCBhbmQgaWQgPiBiYXNlIGlkLCB0cnkgdG8gZmluZCBhY3Rpb24gd2l0aCBpZEFkZCBvcHRpb25cblx0Ly8gVGhpcyBoYW5kbGVzIGNhc2VzIGxpa2UgY21kX2lkIDUgKFBob25lcyBSb3V0aW5nKSBhbmQgY21kX2lkIDcgKEJ1dHRvbnMpXG5cdC8vIHdoZXJlIGlkIDAtMyByZXByZXNlbnRzIGNoYW5uZWxzIDEtNFxuXHRpZiAoIWFjdGlvbikge1xuXHRcdGNvbnN0IGJhc2VBY3Rpb24gPSBhY3Rpb25zLmZpbmQoKGEpID0+IHtcblx0XHRcdGlmIChhLmNtZF9pZCAhPT0gc2V0dGluZy5jbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBhY3Rpb24gaGFzIGFuIGlkQWRkIG9wdGlvbiAoaW5kaWNhdGluZyBjaGFubmVsIHNlbGVjdGlvbilcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYS5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhlIHNldHRpbmcuaWQgb2Zmc2V0IG1hdGNoZXMgb25lIG9mIHRoZSBpZEFkZCBjaG9pY2UgSURzXG5cdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZy5pZCAtIGEuaWRcblx0XHRcdHJldHVybiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGMpID0+IGMuaWQgPT09IGNoYW5uZWxPZmZzZXQpXG5cdFx0fSlcblx0XHRpZiAoYmFzZUFjdGlvbikge1xuXHRcdFx0YWN0aW9uID0gYmFzZUFjdGlvblxuXHRcdH1cblx0fVxuXG5cdGNvbnN0IGNtZEhleCA9IHRvSGV4KHNldHRpbmcuY21kX2lkKVxuXHRjb25zdCBpZEhleCA9IHRvSGV4KHNldHRpbmcuaWQpXG5cdGNvbnN0IHZhbEhleCA9IGJ5dGVzVG9IZXgoc2V0dGluZy52YWx1ZUJ5dGVzKVxuXHRjb25zdCB2YWxEZWMgPVxuXHRcdHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdD8gZm9ybWF0UmdiQ29sb3Ioc2V0dGluZy52YWx1ZUJ5dGVzWzBdLCBzZXR0aW5nLnZhbHVlQnl0ZXNbMV0sIHNldHRpbmcudmFsdWVCeXRlc1syXSlcblx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMVxuXHRcdFx0XHQ/IHNldHRpbmcudmFsdWVCeXRlc1swXVxuXHRcdFx0XHQ6IHNldHRpbmcudmFsdWVCeXRlcy5qb2luKCcsJylcblxuXHQvLyBCdWlsZCB0aGUgcHJlZml4OiBjbWQ6MHgxMiBjaDowIGlkOjB4MDEgdmFsOjB4MTQgKGNoIG9ubHkgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2gpXG5cdGNvbnN0IGJ1c0NoU3RyID0gc2V0dGluZy5idXNDaCAhPT0gdW5kZWZpbmVkID8gYCBjaDoke3NldHRpbmcuYnVzQ2h9YCA6ICcnXG5cdGNvbnN0IHByZWZpeCA9IGBjbWQ6JHtjbWRIZXh9JHtidXNDaFN0cn0gaWQ6JHtpZEhleH0gdmFsOiR7dmFsSGV4fWBcblxuXHQvLyBJZiB3ZSBoYXZlIGFuIGFjdGlvbiB3aXRoIGEgbmFtZSBhbmQgY2hvaWNlIGxhYmVsLCB1c2UgaXRcblx0aWYgKGFjdGlvbikge1xuXHRcdGxldCBuYW1lID0gYWN0aW9uLm5hbWVcblxuXHRcdC8vIElmIHNldHRpbmcgaGFzIGJ1c0NoLCBhZGQgY2hhbm5lbCBpbmZvIHRvIG5hbWVcblx0XHRpZiAoc2V0dGluZy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRuYW1lID0gYCR7bmFtZX0gQ2gke3NldHRpbmcuYnVzQ2ggKyAxfWBcblx0XHR9XG5cdFx0Ly8gT3RoZXJ3aXNlLCBpZiB0aGlzIGFjdGlvbiBoYXMgaWRBZGQsIGluY2x1ZGUgdGhlIGlkQWRkIGxhYmVsXG5cdFx0ZWxzZSB7XG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmIChpZEFkZE9wdGlvbj8uY2hvaWNlcykge1xuXHRcdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZy5pZCAtIGFjdGlvbi5pZFxuXHRcdFx0XHRjb25zdCBpZEFkZENob2ljZSA9IGlkQWRkT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHRcdFx0aWYgKGlkQWRkQ2hvaWNlKSB7XG5cdFx0XHRcdFx0bmFtZSA9IGAke25hbWV9ICR7aWRBZGRDaG9pY2UubGFiZWx9YFxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gTG9vayBmb3IgdGhlIHZhbHVlIG9wdGlvbiAobm90IGJ1c0NoIG9yIGlkQWRkKVxuXHRcdGNvbnN0IHZhbHVlT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAndmFsdWUnKVxuXHRcdGlmICh2YWx1ZU9wdGlvbj8uY2hvaWNlcyAmJiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRjb25zdCBjaG9pY2UgPSB2YWx1ZU9wdGlvbi5jaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHNldHRpbmcudmFsdWVCeXRlc1swXSlcblx0XHRcdGlmIChjaG9pY2UpIHtcblx0XHRcdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke2Nob2ljZS5sYWJlbH0gKCR7dmFsRGVjfSlgXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBgJHtwcmVmaXh9IHwgJHtuYW1lfTogJHt2YWxEZWN9YFxuXHR9XG5cblx0Ly8gTm8gYWN0aW9uIGZvdW5kIC0ganVzdCBzaG93IHRoZSByYXcgdmFsdWVzXG5cdHJldHVybiBgJHtwcmVmaXh9IHwgVW5rbm93biBTZXR0aW5nYFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBQQVJTRVIgRElTUEFUQ0ggV0lUSCBBVVRPLURFVEVDVElPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBnZXRBbGxTZXR0aW5ncyByZXNwb25zZSB3aXRoIGF1dG9tYXRpYyBmb3JtYXQgZGV0ZWN0aW9uLlxuICpcbiAqIFN0cmF0ZWd5OlxuICogMS4gSWYgbW9kZWwgaGFzIGV4cGxpY2l0IFwic2VjdGlvbmVkXCIgcHJvcGVydHksIHVzZSB0aGF0XG4gKiAyLiBPdGhlcndpc2UsIHRyeSBGTEFUIHBhcnNlciBmaXJzdCAoaXQncyBzaW1wbGVyKVxuICogMy4gSWYgRkxBVCByZXR1cm5zIDAgc2V0dGluZ3MsIHRyeSBTRUNUSU9ORUQgcGFyc2VyXG4gKiA0LiBVc2Ugd2hpY2hldmVyIHBhcnNlciByZXR1cm5zIG1vcmUgc2V0dGluZ3NcbiAqXG4gKiBAcmV0dXJucyB7c2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGJvb2xlYW4gfCBudWxsfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24oXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGJ1ZjogQnVmZmVyLFxuKTogeyBzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdOyBkZXRlY3RlZFNlY3Rpb25lZDogYm9vbGVhbiB8IG51bGwgfSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0Y29uc3QgZGVjbGFyZWRTZWN0aW9uZWQgPSBzY2hlbWE/LnNlY3Rpb25lZFxuXG5cdC8vIElmIGV4cGxpY2l0bHkgZGVjbGFyZWQgaW4gSlNPTiwgdXNlIHRoYXRcblx0aWYgKGRlY2xhcmVkU2VjdGlvbmVkICE9PSB1bmRlZmluZWQpIHtcblx0XHRjb25zdCBzZXR0aW5ncyA9IGRlY2xhcmVkU2VjdGlvbmVkXG5cdFx0XHQ/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG5cdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxuXHRcdHJldHVybiB7IHNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9IC8vIG51bGwgPSB1c2VkIGRlY2xhcmVkIHZhbHVlXG5cdH1cblxuXHQvLyBObyBkZWNsYXJhdGlvbiAtIHRyeSBib3RoIHBhcnNlcnMgYW5kIHBpY2sgdGhlIGJlc3Qgb25lXG5cdGxldCBmbGF0U2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cdGxldCBzZWN0aW9uZWRTZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHR0cnkge1xuXHRcdGZsYXRTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBGbGF0IHBhcnNlciBmYWlsZWQ6ICR7ZX1gKVxuXHR9XG5cblx0dHJ5IHtcblx0XHRzZWN0aW9uZWRTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZGVidWcoYFNlY3Rpb25lZCBwYXJzZXIgZmFpbGVkOiAke2V9YClcblx0fVxuXG5cdC8vIFBpY2sgdGhlIHBhcnNlciB0aGF0IHJldHVybmVkIG1vcmUgc2V0dGluZ3Ncblx0aWYgKHNlY3Rpb25lZFNldHRpbmdzLmxlbmd0aCA+IGZsYXRTZXR0aW5ncy5sZW5ndGgpIHtcblx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBTRUNUSU9ORUQgZm9ybWF0IChzZWN0aW9uZWQ9JHtzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGh9IHZzIGZsYXQ9JHtmbGF0U2V0dGluZ3MubGVuZ3RofSlgKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBzZWN0aW9uZWRTZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IHRydWUgfVxuXHR9IGVsc2UgaWYgKGZsYXRTZXR0aW5ncy5sZW5ndGggPiAwKSB7XG5cdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgRkxBVCBmb3JtYXQgKGZsYXQ9JHtmbGF0U2V0dGluZ3MubGVuZ3RofSB2cyBzZWN0aW9uZWQ9JHtzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGh9KWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IGZsYXRTZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGZhbHNlIH1cblx0fSBlbHNlIHtcblx0XHQvLyBCb3RoIHBhcnNlcnMgcmV0dXJuZWQgMCBzZXR0aW5nc1xuXHRcdGxvZ2dlci53YXJuKGBXYXJuaW5nOiBCb3RoIHBhcnNlcnMgcmV0dXJuZWQgMCBzZXR0aW5ncyBmb3IgbW9kZWwgJHttb2RlbH1gKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfVxuXHR9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwobW9kZWw6IHN0cmluZywgYnVmOiBCdWZmZXIpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCB7IHNlY3Rpb25lZCB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cdHJldHVybiBzZWN0aW9uZWQgPyBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKSA6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxufVxuXG4vKiBcdTI3MDUgYmFja3dhcmQtY29tcGF0aWJsZSBleHBvcnQgKi9cbmV4cG9ydCBjb25zdCBwYXJzZUdldEFsbFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFZBTFVFIFx1MjE5MiBPUFRJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXM6IG51bWJlcltdKTogU3RBY3Rpb25PcHRpb24ge1xuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdudW1iZXInLCBkZWZhdWx0OiB2YWx1ZUJ5dGVzWzBdIH1cblx0fVxuXG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMykge1xuXHRcdGNvbnN0IFtyLCBnLCBiXSA9IHZhbHVlQnl0ZXNcblx0XHRyZXR1cm4ge1xuXHRcdFx0aWQ6ICd2YWx1ZScsXG5cdFx0XHRsYWJlbDogJ0NvbG9yJyxcblx0XHRcdHR5cGU6ICdjb2xvcnBpY2tlcicsXG5cdFx0XHRkZWZhdWx0OiBmb3JtYXRSZ2JDb2xvcihyLCBnLCBiKSxcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdyYXcnLCBkZWZhdWx0OiBbLi4udmFsdWVCeXRlc10gfVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTTUFSVCBKU09OIFVQREFURVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKFxuXHRtb2RlbEpzb246IFN0TW9kZWxKc29uLFxuXHRwYXJzZWQ6IFBhcnNlZFNldHRpbmdbXSxcblx0YWxsTW9kZWxzOiBSZWNvcmQ8c3RyaW5nLCBTdE1vZGVsSnNvbj4sXG4pOiBTdE1vZGVsSnNvbiB7XG5cdGNvbnN0IG91dCA9IHN0cnVjdHVyZWRDbG9uZShtb2RlbEpzb24pXG5cblx0Ly8gRW5zdXJlIGNtZFNjaGVtYSBhcnJheSBleGlzdHNcblx0aWYgKCFvdXQuY21kU2NoZW1hKSB7XG5cdFx0b3V0LmNtZFNjaGVtYSA9IFtdXG5cdH1cblxuXHQvLyBTb3J0IG90aGVyIG1vZGVscyBieSBudW1lcmljIGRpc3RhbmNlIHRvIGN1cnJlbnQgbW9kZWxcblx0Y29uc3QgY2FuZGlkYXRlcyA9IE9iamVjdC52YWx1ZXMoYWxsTW9kZWxzKVxuXHRcdC5maWx0ZXIoKG0pID0+IG0ubW9kZWwgIT09IG1vZGVsSnNvbi5tb2RlbCkgLy8gZXhjbHVkZSBzZWxmXG5cdFx0LnNvcnQoKGEsIGIpID0+IG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBhLm1vZGVsKSAtIG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBiLm1vZGVsKSlcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRpbmcgbW9kZWw6ICR7bW9kZWxKc29uLm1vZGVsfWApXG5cdGxvZ2dlci5kZWJ1ZyhgQ2FuZGlkYXRlcyBmb3IgaW5mZXJlbmNlOiAke2NhbmRpZGF0ZXMubWFwKChjKSA9PiBjLm1vZGVsKS5qb2luKCcsICcpfWApXG5cblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQsIHZhbHVlQnl0ZXMgfSBvZiBwYXJzZWQpIHtcblx0XHRsZXQgYWN0aW9uID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXG5cdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdC8vIFRyeSBjYW5kaWRhdGVzIGluIG9yZGVyIG9mIHByb3hpbWl0eVxuXHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0Y29uc3QgbWF0Y2ggPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZClcblx0XHRcdFx0aWYgKG1hdGNoKSB7XG5cdFx0XHRcdFx0YWN0aW9uID0gc3RydWN0dXJlZENsb25lKG1hdGNoKVxuXHRcdFx0XHRcdGFjdGlvbi5uYW1lID0gYCR7bWF0Y2gubmFtZX0gKGluZmVycmVkIGZyb20gTW9kZWwgJHtjLm1vZGVsfSlgXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYEluZmVycmVkIHNldHRpbmcgJHt0b0hleChpZCl9IGZyb20gTW9kZWwgJHtjLm1vZGVsfWApXG5cdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSB7XG5cdFx0XHRcdGNtZF9pZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdG5hbWU6IGBVbmtub3duIFNldHRpbmcgJHt0b0hleChpZCkudG9VcHBlckNhc2UoKX1gLFxuXHRcdFx0XHRvcHRpb25zOiBbdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpXSxcblx0XHRcdH1cblx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgaW5mZXIgc2V0dGluZyAke3RvSGV4KGlkKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCBvcHQgPSBhY3Rpb24ub3B0aW9ucz8uWzBdXG5cdFx0XHRpZiAob3B0KSBvcHQuZGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cdFx0fVxuXG5cdFx0Ly8gQXZvaWQgZHVwbGljYXRlc1xuXHRcdGNvbnN0IGV4aXN0cyA9IG91dC5jbWRTY2hlbWEuc29tZSgoYSkgPT4gYS5jbWRfaWQgPT09IGFjdGlvbi5jbWRfaWQgJiYgYS5pZCA9PT0gYWN0aW9uLmlkKVxuXHRcdGlmICghZXhpc3RzKSBvdXQuY21kU2NoZW1hLnB1c2goYWN0aW9uKVxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTQVZFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBzYXZlTW9kZWxKc29uUHJldHR5KGZpbGVQYXRoOiBzdHJpbmcsIGpzb25PYmo6IFN0TW9kZWxKc29uKTogdm9pZCB7XG5cdHRyeSB7XG5cdFx0Ly8gRW5zdXJlIHByb3BlciBrZXkgb3JkZXJpbmc6IG1vZGVsLCBzZWN0aW9uZWQgKGlmIHByZXNlbnQpLCByZWZyZXNoQWZ0ZXJDb21tYW5kLCBjbWRTY2hlbWFcblx0XHRjb25zdCBvcmRlcmVkT2JqOiBhbnkgPSB7IG1vZGVsOiBqc29uT2JqLm1vZGVsIH1cblxuXHRcdC8vIEFkZCBzZWN0aW9uZWQga2V5IGlmIHByZXNlbnQgKHJpZ2h0IGFmdGVyIG1vZGVsKVxuXHRcdGlmICgnc2VjdGlvbmVkJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLnNlY3Rpb25lZCA9IGpzb25PYmouc2VjdGlvbmVkXG5cdFx0fVxuXG5cdFx0Ly8gQWRkIG90aGVyIGtleXMgaW4gb3JkZXJcblx0XHRpZiAoJ3JlZnJlc2hBZnRlckNvbW1hbmQnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmoucmVmcmVzaEFmdGVyQ29tbWFuZCA9IGpzb25PYmoucmVmcmVzaEFmdGVyQ29tbWFuZFxuXHRcdH1cblx0XHRpZiAoJ2NtZFNjaGVtYScgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5jbWRTY2hlbWEgPSBqc29uT2JqLmNtZFNjaGVtYVxuXHRcdH1cblx0XHQvLyBDb3B5IGFueSBvdGhlciBrZXlzIHRoYXQgbWlnaHQgZXhpc3Rcblx0XHRmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhqc29uT2JqKSkge1xuXHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRPYmopKSB7XG5cdFx0XHRcdG9yZGVyZWRPYmpba2V5XSA9IChqc29uT2JqIGFzIGFueSlba2V5XVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIEN1c3RvbSBmb3JtYXR0ZXI6IGtlZXAgY2hvaWNlIG9iamVjdHMgY29tcGFjdCBvbiBvbmUgbGluZVxuXHRcdGxldCBqc29uID0gSlNPTi5zdHJpbmdpZnkob3JkZXJlZE9iaiwgbnVsbCwgMilcblxuXHRcdC8vIFJlcGxhY2UgZXhwYW5kZWQgY2hvaWNlIG9iamVjdHMgd2l0aCBjb21wYWN0IHNpbmdsZS1saW5lIGZvcm1hdFxuXHRcdC8vIE1hdGNoZXM6IHtcXG4gICAgICAgICAgICBcImlkXCI6IFgsXFxuICAgICAgICAgICAgXCJsYWJlbFwiOiBcIllcIlxcbiAgICAgICAgICB9XG5cdFx0Ly8gUmVwbGFjZXMgd2l0aDogeyBcImlkXCI6IFgsIFwibGFiZWxcIjogXCJZXCIgfVxuXHRcdGpzb24gPSBqc29uLnJlcGxhY2UoL1xce1xcblxccytcImlkXCI6XFxzKihcXGQrKSxcXG5cXHMrXCJsYWJlbFwiOlxccypcIihbXlwiXSopXCJcXG5cXHMrXFx9L2csICd7IFwiaWRcIjogJDEsIFwibGFiZWxcIjogXCIkMlwiIH0nKVxuXG5cdFx0ZnMud3JpdGVGaWxlU3luYyhmaWxlUGF0aCwganNvbiArICdcXG4nLCAndXRmOCcpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZXJyb3IoYEZpbGUgV3JpdGUgRXJyb3I6ICR7ZX1gKVxuXHR9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIExPQUQgREVWSUNFIEpTT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBMb2FkcyB0aGUgYWN0aW9ucyBhcnJheSBmb3IgYSBnaXZlbiBtb2RlbCBmcm9tIHRoZSBjZW50cmFsaXplZCBjYWNoZS5cbiAqIFJldHVybnMgYW4gZW1wdHkgYXJyYXkgaWYgdGhlIG1vZGVsIGlzIG5vdCBmb3VuZC5cbiAqIEBkZXByZWNhdGVkIC0gVGhpcyBmdW5jdGlvbiBpcyBubyBsb25nZXIgbmVlZGVkLiBVc2UgZ2V0RGV2aWNlU2NoZW1hKCkgZnJvbSBjb25maWcudHMgaW5zdGVhZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxvYWRBY3Rpb25zRm9yTW9kZWwoX2RldmljZXNGb2xkZXI6IHN0cmluZywgbW9kZWw6IHN0cmluZyk6IFN0QWN0aW9uW10ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdHJldHVybiBzY2hlbWE/LmNtZFNjaGVtYSA/PyBbXVxufVxuXG4vKipcbiAqIExvYWRzIHRoZSBtb2RlbCBjb25maWd1cmF0aW9uIGZyb20gdGhlIGNlbnRyYWxpemVkIGNhY2hlLlxuICogQGRlcHJlY2F0ZWQgLSBUaGlzIGZ1bmN0aW9uIGlzIG5vIGxvbmdlciBuZWVkZWQuIFVzZSBnZXREZXZpY2VTY2hlbWEoKSBmcm9tIGNvbmZpZy50cyBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZE1vZGVsQ29uZmlnKFxuXHRfZGV2aWNlc0ZvbGRlcjogc3RyaW5nLFxuXHRtb2RlbDogc3RyaW5nLFxuKTogeyBhY3Rpb25zOiBTdEFjdGlvbltdOyByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuIH0ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdHJldHVybiB7XG5cdFx0YWN0aW9uczogc2NoZW1hPy5jbWRTY2hlbWEgPz8gW10sXG5cdFx0cmVmcmVzaEFmdGVyQ29tbWFuZDogc2NoZW1hPy5yZWZyZXNoQWZ0ZXJDb21tYW5kID8/IHRydWUsIC8vIERlZmF1bHQgdG8gdHJ1ZSBpZiBub3Qgc3BlY2lmaWVkXG5cdH1cbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRGZWVkYmFja3MgfSBmcm9tICcuL2J1aWxkLWNvbW1hbmRzLmpzJ1xuaW1wb3J0IHsgcmVzb2x2ZU1vZGVsLCBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMsIGZpbmRBY3Rpb25Gb3JTZXR0aW5nIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRmVlZGJhY2tzJylcblxuLyoqXG4gKiBIZWxwZXIgZnVuY3Rpb24gdG8gZ2V0IGxhYmVsIGZyb20gY2hvaWNlcyBiYXNlZCBvbiB2YWx1ZVxuICovXG5mdW5jdGlvbiBnZXRMYWJlbEZvclZhbHVlKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuXHR2YWx1ZTogbnVtYmVyLFxuKTogc3RyaW5nIHwgbnVtYmVyIHtcblx0Y29uc3Qgc2V0dGluZyA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRpZiAoIXNldHRpbmcgfHwgIUFycmF5LmlzQXJyYXkoc2V0dGluZy5vcHRpb25zKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgJ3ZhbHVlJyBvcHRpb24gd2hpY2ggY29udGFpbnMgdGhlIGNob2ljZXNcblx0Y29uc3QgdmFsdWVPcHRpb24gPSBzZXR0aW5nLm9wdGlvbnMuZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0aWYgKCF2YWx1ZU9wdGlvbiB8fCAhQXJyYXkuaXNBcnJheSh2YWx1ZU9wdGlvbi5jaG9pY2VzKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgY2hvaWNlIHdpdGggbWF0Y2hpbmcgaWRcblx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjOiBhbnkpID0+IGMuaWQgPT09IHZhbHVlKVxuXHRyZXR1cm4gY2hvaWNlPy5sYWJlbCA/PyB2YWx1ZVxufVxuXG4vKipcbiAqIEJ1aWxkIGFuZCB3aXJlIENvbXBhbmlvbiBmZWVkYmFjayBkZWZpbml0aW9uc1xuICogUGF0dGVybiBtYXRjaGVzIGFjdGlvbnMudHMgLSBmaWx0ZXJzIGJ5IGFjdGl2ZSBtb2RlbCBhbmQgd2lyZXMgY2FsbGJhY2tzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVGZWVkYmFja3Moc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdGZWVkYmFja3MgPSBidWlsZEZlZWRiYWNrcygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEZlZWRiYWNrczogYW55ID0ge31cblxuXHQvLyBHZXQgdGhlIGFjdGl2ZSBtb2RlbCB1c2luZyByZXNvbHZlTW9kZWxcblx0Y29uc3QgYWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwoc2VsZi5jb25maWcsIHNlbGYuZGV2aWNlcylcblx0bG9nZ2VyLmluZm8oXG5cdFx0YFVwZGF0ZUZlZWRiYWNrczogYWN0aXZlTW9kZWw9XCIke2FjdGl2ZU1vZGVsfVwiLCBkaXNjb3ZlcmVkSG9zdD1cIiR7c2VsZi5jb25maWcuZGlzY292ZXJlZEhvc3R9XCIsIGRldmljZXMgY291bnQ9JHtzZWxmLmRldmljZXMubGVuZ3RofWAsXG5cdClcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEZFRURCQUNLUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFtmZWVkYmFja0lkLCBmZWVkYmFja10gb2YgT2JqZWN0LmVudHJpZXMocmF3RmVlZGJhY2tzKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGZlZWRiYWNrSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgZmVlZGJhY2tzIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBtb2RlbFxuXHRcdGlmIChtb2RlbCAhPT0gYWN0aXZlTW9kZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBWQUxVRSBGRUVEQkFDSzogUmV0dXJucyBjdXJyZW50IHZhbHVlIGZvciBsb2NhbCB2YXJpYWJsZVxuXHRcdHdpcmVkRmVlZGJhY2tzW2ZlZWRiYWNrSWRdID0ge1xuXHRcdFx0Li4uZmVlZGJhY2ssXG5cdFx0XHRjYWxsYmFjazogKGZlZWRiYWNrRXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snYnVzQ2gnXVxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cdFx0XHRcdGNvbnN0IGN1cnJlbnQgPSBzZWxmLnN0Q29udHJvbGxlci5nZXRTZXR0aW5nVmFsdWUoaXAsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXG5cdFx0XHRcdC8vIENoZWNrIGlmIHVzZXIgd2FudHMgbGFiZWwgaW5zdGVhZCBvZiBudW1lcmljIHZhbHVlXG5cdFx0XHRcdGNvbnN0IHNob3dMYWJlbCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snc2hvd0xhYmVsJ10gPz8gZmFsc2VcblxuXHRcdFx0XHRpZiAoc2hvd0xhYmVsICYmIGN1cnJlbnQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdC8vIFJldHVybiB0aGUgbGFiZWwgZnJvbSBjaG9pY2VzXG5cdFx0XHRcdFx0cmV0dXJuIGdldExhYmVsRm9yVmFsdWUoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQsIGN1cnJlbnQpXG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBSZXR1cm4gbnVtZXJpYyB2YWx1ZSBkaXJlY3RseSBmb3IgbG9jYWwgdmFyaWFibGUgKHR5cGU6ICd2YWx1ZScpXG5cdFx0XHRcdHJldHVybiBjdXJyZW50ID8/IDBcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0c2VsZi5zZXRGZWVkYmFja0RlZmluaXRpb25zKHdpcmVkRmVlZGJhY2tzKVxuXG5cdGxvZ2dlci5pbmZvKGBVcGRhdGVGZWVkYmFja3M6IHdpcmVkIGZlZWRiYWNrczogJHtPYmplY3Qua2V5cyh3aXJlZEZlZWRiYWNrcykubGVuZ3RofWApXG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IG9zIGZyb20gJ29zJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9CVVNfR0VULFxuXHRDTURfQlVTX1NFVCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX0dFVF9GSVJNV0FSRSxcblx0Q01EX0dMT0JBTF9NSUNfS0lMTCxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfUkVTRVRfREVWSUNFLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0Z2V0Q29tbWFuZE5hbWUsXG5cdG1ha2VTZXR0aW5nSWQsXG5cdHRvSGV4LFxuXHRieXRlc1RvSGV4LFxuXHR0eXBlIERldmljZUluZm8sXG59IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQge1xuXHRwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwsXG5cdHBhcnNlU2V0dGluZ3NSZXNwb25zZSxcblx0Zm9ybWF0UGFyc2VkU2V0dGluZyxcblx0dHlwZSBTdEFjdGlvbixcbn0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcbmltcG9ydCB7XG5cdERBTlRFX01TR19JTkZPX1JFU1BPTlNFLFxuXHRwYXJzZURhbnRlSW5mb1Jlc3BvbnNlLFxuXHRkaXNjb3ZlckRldmljZXMsXG5cdGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uLFxufSBmcm9tICcuL2RhbnRlLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1N0Q29udHJvbGxlcicpXG5cbmV4cG9ydCBjbGFzcyBTdENvbnRyb2xsZXIge1xuXHRwcml2YXRlIHJlYWRvbmx5IGRlZmF1bHRQb3J0OiBudW1iZXIgPSA4NzAwXG5cdHByaXZhdGUgcmVhZG9ubHkgbXVsdGljYXN0R3JvdXAgPSAnMjI0LjAuMC4yMzEnXG5cdHByaXZhdGUgcmVhZG9ubHkgcnhQb3J0ID0gODcwMlxuXG5cdHByaXZhdGUgdHhTb2NrZXQ6IGRncmFtLlNvY2tldFxuXHRwcml2YXRlIHJ4U29ja2V0OiBkZ3JhbS5Tb2NrZXQgLy8gZm9yIHJlY2VpdmluZyByZXNwb25zZXMgKDg3MDIpXG5cdHByaXZhdGUgcGVuZGluZ0Fja3M6IE1hcDxcblx0XHRzdHJpbmcsXG5cdFx0eyByZXNvbHZlOiAoYnVmOiBCdWZmZXIpID0+IHZvaWQ7IHJlamVjdDogKGU6IEVycm9yKSA9PiB2b2lkOyB0aW1lcjogTm9kZUpTLlRpbWVvdXQgfVxuXHQ+XG5cdHByaXZhdGUgam9pbmVkSW50ZXJmYWNlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KCkgLy8gbG9jYWwgSVBzIHdlJ3ZlIGpvaW5lZCBtdWx0aWNhc3Qgb25cblxuXHQvKiogUmVzb2x2ZXMgb25jZSB0eFNvY2tldCBpcyBib3VuZCBhbmQgcmVhZHkgdG8gc2VuZCAqL1xuXHRwcml2YXRlIHR4UmVhZHk6IFByb21pc2U8dm9pZD5cblxuXHQvKiogQWN0aXZlIGRldmljZSBtb2RlbCBhbmQgYWN0aW9uIGRlZmluaXRpb25zIGZvciBzZXR0aW5ncyBkZWNvZGluZyAqL1xuXHRwcml2YXRlIG1vZGVsOiBzdHJpbmcgPSAnJ1xuXHRwcml2YXRlIGFjdGlvbnM6IFN0QWN0aW9uW10gPSBbXVxuXHRwcml2YXRlIHJlZnJlc2hBZnRlckNvbW1hbmQ6IGJvb2xlYW4gPSB0cnVlIC8vIERlZmF1bHQgdG8gdHJ1ZSAobW9zdCBkZXZpY2VzIG5lZWQgaXQpXG5cblx0LyoqXG5cdCAqIEtub3duIHN0YXRlIG9mIGV2ZXJ5IHNldHRpbmcgcGVyIGRldmljZSBJUC5cblx0ICogS2V5ZWQgYnkgSVAgXHUyMTkyIE1hcCBvZiBcIiR7Y21kSWR9LyR7c2V0dGluZ0lkfVwiIFx1MjE5MiBjdXJyZW50IHZhbHVlIGJ5dGUuXG5cdCAqIFBvcHVsYXRlZCBvbiBjb25uZWN0IHZpYSByZXF1ZXN0QWxsU2V0dGluZ3MoKSwgdXBkYXRlZCBvbiBldmVyeSBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikuXG5cdCAqIFVzZWQgdG8gZGlmZiBpbmNvbWluZyBwdXNoZXMgKGNoYW5nZWQgPSBpbmZvLCB1bmNoYW5nZWQgPSBkZWJ1ZykgYW5kIGZvciBmZWVkYmFja3MuXG5cdCAqL1xuXHRwcml2YXRlIGRldmljZVN0YXRlOiBNYXA8c3RyaW5nLCBNYXA8c3RyaW5nLCBudW1iZXI+PiA9IG5ldyBNYXAoKVxuXG5cdC8qKiBDYWxsYmFja3MgcmVnaXN0ZXJlZCBieSBkaXNjb3ZlckRldmljZXMoKSBcdTIwMTQga2V5ZWQgYnkgc291cmNlIElQICovXG5cdHByaXZhdGUgZGlzY292ZXJ5TGlzdGVuZXJzOiBNYXA8c3RyaW5nLCAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB2b2lkPiA9IG5ldyBNYXAoKVxuXG5cdC8qKiBDYWxsYmFjayB0byB0cmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZXMgd2hlbiBzdGF0ZSBjaGFuZ2VzICovXG5cdHByaXZhdGUgZmVlZGJhY2tDYWxsYmFjaz86IChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHZvaWRcblxuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRsb2dnZXIuaW5mbygnU3RDb250cm9sbGVyIGluaXRpYWxpemVkJylcblxuXHRcdHRoaXMucGVuZGluZ0Fja3MgPSBuZXcgTWFwKClcblxuXHRcdC8vIFNlbmQgc29ja2V0IFx1MjAxNCBiaW5kIHRvIGVwaGVtZXJhbCBwb3J0LiBSZXNwb25zZXMgYWx3YXlzIGdvIHRvIHJ4U29ja2V0IG9uXG5cdFx0Ly8gcG9ydCA4NzAyIChEYW50ZSBoYXJkY29kZXMgdGhlIHJlc3BvbnNlIGRlc3RpbmF0aW9uIHBvcnQgdG8gODcwMikuXG5cdFx0dGhpcy50eFNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cdFx0dGhpcy50eFJlYWR5ID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuYmluZCgwLCAoKSA9PiB7XG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgVFggc29ja2V0IGJvdW5kIHRvIHBvcnQgJHsodGhpcy50eFNvY2tldC5hZGRyZXNzKCkgYXMgeyBwb3J0OiBudW1iZXIgfSkucG9ydH1gKVxuXHRcdFx0XHRyZXNvbHZlKClcblx0XHRcdH0pXG5cdFx0fSlcblx0XHR0aGlzLnR4U29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgVFggc29ja2V0IGVycm9yOiAke2Vycn1gKVxuXHRcdH0pXG5cblx0XHQvLyBSZWNlaXZlIHNvY2tldCAtIGJpbmQgdG8gYWxsIGFkZHJlc3NlcyBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHNcblx0XHR0aGlzLnJ4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2xpc3RlbmluZycsICgpID0+IHtcblx0XHRcdGNvbnN0IGFkZHIgPSB0aGlzLnJ4U29ja2V0LmFkZHJlc3MoKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgbGlzdGVuaW5nIG9uICR7SlNPTi5zdHJpbmdpZnkoYWRkcil9YClcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMucnhTb2NrZXQuc2V0TXVsdGljYXN0TG9vcGJhY2sodHJ1ZSlcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgUlggc29ja2V0IGVycm9yOiAke2Vycn1gKVxuXHRcdH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdtZXNzYWdlJywgKG1zZywgcmluZm8pID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMuaGFuZGxlSW5jb21pbmcobXNnLCByaW5mby5hZGRyZXNzKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLmVycm9yKGBFcnJvciBoYW5kbGluZyBpbmNvbWluZyBtZXNzYWdlOiAke19lfWApXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIEJpbmQgdG8gd2lsZGNhcmQgc28ga2VybmVsIGNhbiBkZWxpdmVyIG11bHRpY2FzdCBwYWNrZXRzIGZvciBqb2luZWQgaW50ZXJmYWNlc1xuXHRcdHRoaXMucnhTb2NrZXQuYmluZCh7IGFkZHJlc3M6ICcwLjAuMC4wJywgcG9ydDogdGhpcy5yeFBvcnQgfSwgKCkgPT4ge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgYm91bmQgdG8gMC4wLjAuMDoke3RoaXMucnhQb3J0fWApXG5cdFx0fSlcblx0fVxuXG5cdHB1YmxpYyBjbG9zZSgpOiB2b2lkIHtcblx0XHR0cnkge1xuXHRcdFx0Zm9yIChjb25zdCBsb2NhbEFkZHIgb2YgQXJyYXkuZnJvbSh0aGlzLmpvaW5lZEludGVyZmFjZXMpKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0dGhpcy5yeFNvY2tldC5kcm9wTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBsb2NhbEFkZHIpXG5cdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMucnhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnR4U29ja2V0LmNsb3NlKClcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBQcm92aWRlIHRoZSBhY3RpdmUgZGV2aWNlIG1vZGVsIGFuZCBhY3Rpb24gZGVmaW5pdGlvbnMgc28gaW5jb21pbmcgbWVzc2FnZXNcblx0ICogY2FuIGJlIGRlY29kZWQgaW50byBodW1hbi1yZWFkYWJsZSBuYW1lcy4gQ2FsbCBmcm9tIG1haW4udHMgYWZ0ZXIgY29uZmlnIGxvYWQuXG5cdCAqL1xuXHRwdWJsaWMgc2V0TW9kZWwobW9kZWw6IHN0cmluZywgYWN0aW9uczogU3RBY3Rpb25bXSwgcmVmcmVzaEFmdGVyQ29tbWFuZDogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcblx0XHR0aGlzLm1vZGVsID0gbW9kZWxcblx0XHR0aGlzLmFjdGlvbnMgPSBhY3Rpb25zXG5cdFx0dGhpcy5yZWZyZXNoQWZ0ZXJDb21tYW5kID0gcmVmcmVzaEFmdGVyQ29tbWFuZFxuXHR9XG5cblx0LyoqXG5cdCAqIFNldCBjYWxsYmFjayB0byB0cmlnZ2VyIHdoZW4gZGV2aWNlIHN0YXRlIGNoYW5nZXMgKGZvciBmZWVkYmFja3MpLlxuXHQgKiBDYWxsIGZyb20gbWFpbi50cyB0byB3aXJlIHVwIGNoZWNrRmVlZGJhY2tzLlxuXHQgKi9cblx0cHVibGljIHNldEZlZWRiYWNrQ2FsbGJhY2soY2FsbGJhY2s6IChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHZvaWQpOiB2b2lkIHtcblx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2sgPSBjYWxsYmFja1xuXHR9XG5cblx0LyoqXG5cdCAqIFNlbmQgYSBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgcmVxdWVzdCB0byB0aGUgZGV2aWNlIGFuZCBzdG9yZSB0aGUgcmVzcG9uc2Vcblx0ICogaW4gZGV2aWNlU3RhdGUuIFJldHVybnMgdGhlIHJhdyByZXNwb25zZSBidWZmZXIgZm9yIHBhcnNpbmcuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEFsbFNldHRpbmdzKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGxvZ2dlci5pbmZvKGBSZXF1ZXN0aW5nIGFsbCBzZXR0aW5ncyBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKFxuXHRcdFx0dGhpcy5tb2RlbCxcblx0XHRcdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRcdFx0dW5kZWZpbmVkLFxuXHRcdFx0dW5kZWZpbmVkLFxuXHRcdFx0dW5kZWZpbmVkLFxuXHRcdFx0ZGV2aWNlSXAsXG5cdFx0XHRmYWxzZSxcblx0XHQpXG5cblx0XHQvLyBEZWJ1ZzogTG9nIHRoZSByYXcgcmVzcG9uc2Vcblx0XHRsb2dnZXIuZGVidWcoYFJhdyByZXNwb25zZSBidWZmZXI6ICR7cmVzcG9uc2UudG9TdHJpbmcoJ2hleCcpfWApXG5cdFx0bG9nZ2VyLmRlYnVnKGBSZXNwb25zZSBsZW5ndGg6ICR7cmVzcG9uc2UubGVuZ3RofWApXG5cblx0XHQvLyBQYXJzZSBhbmQgc3RvcmUgaW4gZGV2aWNlU3RhdGVcblx0XHRjb25zdCBwYXJzZWQgPSBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwodGhpcy5tb2RlbCwgcmVzcG9uc2UpXG5cdFx0bG9nZ2VyLmRlYnVnKGBQYXJzZWQgc2V0dGluZ3MgY291bnQ6ICR7cGFyc2VkLmxlbmd0aH1gKVxuXHRcdGlmIChwYXJzZWQubGVuZ3RoID4gMCkge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBGaXJzdCBmZXcgc2V0dGluZ3M6ICR7SlNPTi5zdHJpbmdpZnkocGFyc2VkLnNsaWNlKDAsIDMpKX1gKVxuXHRcdH1cblxuXHRcdGNvbnN0IHN0YXRlTWFwID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKVxuXHRcdGZvciAoY29uc3Qgc2V0dGluZyBvZiBwYXJzZWQpIHtcblx0XHRcdGNvbnN0IGtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgc2V0dGluZy5jbWRfaWQsIHNldHRpbmcuaWQsIHNldHRpbmcuYnVzQ2gpXG5cdFx0XHQvLyBGb3IgUkdCIGNvbG9ycyAoMyBieXRlcyksIHBhY2sgaW50byBzaW5nbGUgbnVtYmVyOiAoUiA8PCAxNikgfCAoRyA8PCA4KSB8IEJcblx0XHRcdGNvbnN0IHZhbHVlID1cblx0XHRcdFx0c2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0XHRcdD8gKHNldHRpbmcudmFsdWVCeXRlc1swXSA8PCAxNikgfCAoc2V0dGluZy52YWx1ZUJ5dGVzWzFdIDw8IDgpIHwgc2V0dGluZy52YWx1ZUJ5dGVzWzJdXG5cdFx0XHRcdFx0OiAoc2V0dGluZy52YWx1ZUJ5dGVzWzBdID8/IDApXG5cdFx0XHRzdGF0ZU1hcC5zZXQoa2V5LCB2YWx1ZSlcblx0XHR9XG5cdFx0dGhpcy5kZXZpY2VTdGF0ZS5zZXQoZGV2aWNlSXAsIHN0YXRlTWFwKSAvLyBSZXR1cm4gYnVmZmVyIGZvciBjYWxsZXIgdG8gcGFyc2UgaWYgbmVlZGVkXG5cdFx0cmV0dXJuIHJlc3BvbnNlXG5cdH1cblxuXHQvKiogUmV0dXJuIGEgc25hcHNob3Qgb2YgdGhlIGN1cnJlbnQgZGV2aWNlIHN0YXRlIGZvciBhIGdpdmVuIElQIChmb3IgZmVlZGJhY2tzKS4gKi9cblx0cHVibGljIGdldERldmljZVN0YXRlKGRldmljZUlwOiBzdHJpbmcpOiBNYXA8c3RyaW5nLCBudW1iZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoZGV2aWNlSXApID8/IG5ldyBNYXAoKVxuXHR9XG5cblx0LyoqXG5cdCAqIERpc2NvdmVycyBTdHVkaW8gVGVjaG5vbG9naWVzIERhbnRlIGRldmljZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsuXG5cdCAqXG5cdCAqIFN0cmF0ZWd5OlxuXHQgKiAgRGFudGUgZGV2aWNlcyBicm9hZGNhc3QgYSAxLXNlY29uZCBhbm5vdW5jZSB0byBtdWx0aWNhc3QgMjI0LjAuMC4yMzM6ODcwOC5cblx0ICogIFdlIGxpc3RlbiBvbiB0aGF0IGdyb3VwLCBjb2xsZWN0IHNvdXJjZSBJUHMsIHRoZW4gc2VuZCBhIHVuaWNhc3QgZGV2aWNlIGluZm9cblx0ICogIHJlcXVlc3QgKDB4MDAyMCkgdG8gZWFjaCBuZXcgSVAgb24gcG9ydCA4NzAwLiBUaGUgZGV2aWNlIHJlc3BvbmRzIHRvIG91ciBJUFxuXHQgKiAgb24gcG9ydCA4NzAyIChyeFNvY2tldCksIHdoZXJlIGhhbmRsZUluY29taW5nKCkgcGlja3MgaXQgdXAgYW5kIGZpcmVzIHRoZVxuXHQgKiAgZGlzY292ZXJ5TGlzdGVuZXJzIGNhbGxiYWNrLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIGRpc2NvdmVyRGV2aWNlcyh0aW1lb3V0TXMgPSA1MDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvW10+IHtcblx0XHQvLyBSZWdpc3RlciBsaXN0ZW5lciBcdTIwMTQgaGFuZGxlSW5jb21pbmcoKSBmaXJlcyB0aGlzIGZvciBlYWNoIDB4MDE3MCByZXNwb25zZVxuXHRcdGNvbnN0IERJU0NPVkVSWV9LRVkgPSAnX19kaXNjb3ZlcnlfXydcblx0XHRjb25zdCBmb3VuZERldmljZXM6IERldmljZUluZm9bXSA9IFtdXG5cblx0XHRjb25zdCBvbkRldmljZUZvdW5kID0gKGRldmljZTogRGV2aWNlSW5mbykgPT4ge1xuXHRcdFx0Zm91bmREZXZpY2VzLnB1c2goZGV2aWNlKVxuXHRcdH1cblxuXHRcdC8vIFJlZ2lzdGVyIHRoZSBjYWxsYmFjayBzbyBoYW5kbGVJbmNvbWluZygpIGNhbiBpbnZva2UgaXQgd2hlbiAweDAxNzAgYXJyaXZlc1xuXHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChESVNDT1ZFUllfS0VZLCBvbkRldmljZUZvdW5kKVxuXG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHRoaXMudHhSZWFkeVxuXHRcdFx0Ly8gZGlzY292ZXJEZXZpY2VzKCkgaW4gZGFudGUudHMgaGFuZGxlcyB0aGUgYW5ub3VuY2UgbGlzdGVuaW5nIGFuZCBxdWVyeSBzZW5kaW5nXG5cdFx0XHQvLyBSZXNwb25zZXMgY29tZSBiYWNrIHRvIHJ4U29ja2V0IFx1MjE5MiBoYW5kbGVJbmNvbWluZygpIFx1MjE5MiBkaXNjb3ZlcnlMaXN0ZW5lcnNcblx0XHRcdGF3YWl0IGRpc2NvdmVyRGV2aWNlcyhcblx0XHRcdFx0dGhpcy50eFNvY2tldCxcblx0XHRcdFx0b25EZXZpY2VGb3VuZCwgLy8gZGFudGUudHMgZG9lc24ndCBhY3R1YWxseSB1c2UgdGhpcywgYnV0IGtlcHQgZm9yIGNvbXBhdGliaWxpdHlcblx0XHRcdFx0YXN5bmMgKGRlc3RJcCkgPT4gdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcCksXG5cdFx0XHRcdHRpbWVvdXRNcyxcblx0XHRcdClcblx0XHRcdHJldHVybiBmb3VuZERldmljZXNcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKERJU0NPVkVSWV9LRVkpXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFJlcXVlc3RzIGRldmljZSBmaXJtd2FyZSB2ZXJzaW9uIHZpYSBTdHVkaW8tVCBwcm90b2NvbCAoQ01EX0dFVF9GSVJNV0FSRSkuXG5cdCAqIFJldHVybnMgdGhlIGZpcm13YXJlIHZlcnNpb24gc3RyaW5nIChlLmcuLCBcIjMuMDFcIiwgXCIyLjJcIiwgXCIxLjA1XCIpLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHJlcXVlc3RGaXJtd2FyZVZlcnNpb24oZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgZmlybXdhcmUgdmVyc2lvbiBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKFxuXHRcdFx0dGhpcy5tb2RlbCxcblx0XHRcdENNRF9HRVRfRklSTVdBUkUsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHR1bmRlZmluZWQsXG5cdFx0XHRkZXZpY2VJcCxcblx0XHRcdGZhbHNlLFxuXHRcdFx0MHgwMDFiLCAvLyBGaXJtd2FyZSByZXF1ZXN0IG1lc3NhZ2UgdHlwZVxuXHRcdClcblxuXHRcdC8vIFJlc3BvbnNlIHN0cnVjdHVyZTogW2hlYWRlcl0gMHg1YSAweDgwIFtmaXJtd2FyZV9kYXRhXSBDUkNcblx0XHQvLyBGaXJtd2FyZSBkYXRhIHN0YXJ0cyBhdCBieXRlIDI2ICgyNC1ieXRlIGhlYWRlciArIDB4NWEgKyAweDgwKVxuXHRcdGNvbnN0IGRhdGFTdGFydCA9IDI2XG5cblx0XHRpZiAocmVzcG9uc2UubGVuZ3RoIDwgZGF0YVN0YXJ0ICsgMykge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEZpcm13YXJlIHJlc3BvbnNlIHRvbyBzaG9ydDogJHtyZXNwb25zZS5sZW5ndGh9IGJ5dGVzYClcblx0XHRcdHJldHVybiAnVW5rbm93bidcblx0XHR9XG5cblx0XHQvLyBGaXJtd2FyZSBmb3JtYXQ6IFt1bmtub3duX2J5dGUsIG1ham9yLCBtaW5vcl1cblx0XHRjb25zdCBtYWpvciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDFdXG5cdFx0Y29uc3QgbWlub3IgPSByZXNwb25zZVtkYXRhU3RhcnQgKyAyXVxuXG5cdFx0Ly8gRm9ybWF0IGFzIG1ham9yLm1pbm9yIHdpdGggbm8gc3BlY2lhbCBwYWRkaW5nIHJ1bGVzXG5cdFx0Ly8gRXhhbXBsZXM6IDMuMVx1MjE5MlwiMy4wMVwiLCAyLjJcdTIxOTJcIjIuMlwiLCA1LjRcdTIxOTJcIjUuMDRcIiwgMS41XHUyMTkyXCIxLjA1XCJcblx0XHQvLyBQYXR0ZXJuOiBpZiBtaW5vciA8IDEwIGFuZCBtaW5vciAhPSAyLCBwYWQgdG8gMiBkaWdpdHNcblx0XHQvLyBBY3R1YWxseSBzaW1wbGVyOiBhbHdheXMgcGFkIHNpbmdsZSBkaWdpdHMgRVhDRVBUIDJcblx0XHRsZXQgbWlub3JTdHI6IHN0cmluZ1xuXHRcdGlmIChtaW5vciA9PT0gMikge1xuXHRcdFx0bWlub3JTdHIgPSAnMicgLy8gU3BlY2lhbCBjYXNlOiAyLjIgbm90IDIuMDJcblx0XHR9IGVsc2UgaWYgKG1pbm9yIDwgMTApIHtcblx0XHRcdG1pbm9yU3RyID0gbWlub3IudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpIC8vIDFcdTIxOTJcIjAxXCIsIDVcdTIxOTJcIjA1XCJcblx0XHR9IGVsc2Uge1xuXHRcdFx0bWlub3JTdHIgPSBtaW5vci50b1N0cmluZygpIC8vIDEwK1x1MjE5MlwiMTBcIiwgXCIyMFwiLCBldGNcblx0XHR9XG5cblx0XHRjb25zdCBmaXJtd2FyZSA9IGAke21ham9yfS4ke21pbm9yU3RyfWBcblxuXHRcdGxvZ2dlci5pbmZvKGBGaXJtd2FyZSB2ZXJzaW9uOiAke2Zpcm13YXJlfWApXG5cdFx0cmV0dXJuIGZpcm13YXJlXG5cdH1cblxuXHQvKipcblx0ICogRW5zdXJlIHdlJ3ZlIGpvaW5lZCB0aGUgbXVsdGljYXN0IGdyb3VwIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gZGVzdElwLlxuXHQgKiBPcHRpb24gQiBiZWhhdmlvcjogam9pbiBPTkxZIHRoZSBpbnRlcmZhY2UgdXNlZCB0byByZWFjaCB0aGUgZGV2aWNlLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBlbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGF3YWl0IGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblx0XHRcdGlmICghbG9jYWxBZGRyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgZGV0ZXJtaW5lIGxvY2FsIGFkZHJlc3MgZm9yIGRlc3RpbmF0aW9uICR7ZGVzdElwfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAodGhpcy5qb2luZWRJbnRlcmZhY2VzLmhhcyhsb2NhbEFkZHIpKSB7XG5cdFx0XHRcdC8vIGFscmVhZHkgam9pbmVkXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLnJ4U29ja2V0LmFkZE1lbWJlcnNoaXAodGhpcy5tdWx0aWNhc3RHcm91cCwgbG9jYWxBZGRyKVxuXHRcdFx0XHR0aGlzLmpvaW5lZEludGVyZmFjZXMuYWRkKGxvY2FsQWRkcilcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEpvaW5lZCBtdWx0aWNhc3QgJHt0aGlzLm11bHRpY2FzdEdyb3VwfSBvbiAke2xvY2FsQWRkcn1gKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBqb2luIG11bHRpY2FzdCBvbiAke2xvY2FsQWRkcn06ICR7U3RyaW5nKF9lKX1gKVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRsb2dnZXIud2FybihgZW5zdXJlTWVtYmVyc2hpcEZvciBmYWlsZWQ6ICR7X2V9YClcblx0XHR9XG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgc2VuZEF3YWl0QWNrKFxuXHRcdG1vZGVsOiBzdHJpbmcsXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdFx0bXNnVHlwZSA9IDB4MDAyMCwgLy8gRGVmYXVsdCB0byBzdGFuZGFyZCBjb21tYW5kIG1lc3NhZ2UgdHlwZVxuXHQpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGNvbnN0IHRpbWVvdXRNcyA9IDIwMDBcblxuXHRcdC8vIEVuc3VyZSB3ZSBhcmUgbGlzdGVuaW5nIGZvciByZXBsaWVzIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCB3aWxsIHJlY2VpdmUgdGhlbVxuXHRcdGF3YWl0IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApXG5cblx0XHRjb25zdCBkYXRhQmxvY2s6IG51bWJlcltdID0gW11cblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKHNldHRpbmdJZCAmIDB4ZmYpXG5cdFx0aWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKC4uLlN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpKVxuXG5cdFx0Y29uc3QgcGF5bG9hZEJvZHk6IG51bWJlcltdID0gWzB4NWEsIGNtZElkICYgMHhmZl1cblxuXHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBwYXlsb2FkQm9keS5wdXNoKGJ1c0NoICYgMHhmZilcblx0XHRpZiAoYWRkTGVuKSBwYXlsb2FkQm9keS5wdXNoKGRhdGFCbG9jay5sZW5ndGgpXG5cblx0XHRpZiAoZGF0YUJsb2NrLmxlbmd0aCA+IDApIHBheWxvYWRCb2R5LnB1c2goLi4uZGF0YUJsb2NrKVxuXG5cdFx0Y29uc3QgY3JjID0gU3RDb250cm9sbGVyLmNyYzhEdmJTMihwYXlsb2FkQm9keSlcblx0XHRjb25zdCBwYXlsb2FkV2l0aENyYyA9IEJ1ZmZlci5mcm9tKFsuLi5wYXlsb2FkQm9keSwgY3JjXSlcblxuXHRcdGNvbnN0IGhlYWRlciA9IGF3YWl0IFN0Q29udHJvbGxlci5idWlsZEhlYWRlcihkZXN0SXAsIG1zZ1R5cGUpXG5cdFx0Y29uc3QgcGFja2V0ID0gQnVmZmVyLmNvbmNhdChbaGVhZGVyLCBwYXlsb2FkV2l0aENyY10pXG5cblx0XHQvLyBIdW1hbi1yZWFkYWJsZSBpbmZvIGxvZyBmb3IgdGhlIG91dGdvaW5nIGNvbW1hbmRcblx0XHRjb25zdCBjbWROYW1lID0gZ2V0Q29tbWFuZE5hbWUoY21kSWQpXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkICYmIHZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRcdFx0bGV0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXG5cdFx0XHQvLyBJZiBubyBleGFjdCBtYXRjaCwgdHJ5IHRvIGZpbmQgYWN0aW9uIHdpdGggaWRBZGQgb3B0aW9uXG5cdFx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0XHRhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0XHRcdGlmIChhLmNtZF9pZCAhPT0gY21kSWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdGNvbnN0IGhhc0lkQWRkID0gYS5vcHRpb25zPy5zb21lKChvcHQpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRpZiAoIWhhc0lkQWRkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRyZXR1cm4gc2V0dGluZ0lkID49IGEuaWQgJiYgc2V0dGluZ0lkIDwgYS5pZCArIDEwXG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cblx0XHRcdGxldCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyAnVW5rbm93biBTZXR0aW5nJ1xuXG5cdFx0XHQvLyBJZiB0aGlzIGFjdGlvbiBoYXMgaWRBZGQgYW5kIHRoZSBzZXR0aW5nIGlkIGlzIG9mZnNldCBmcm9tIGJhc2UsIGluY2x1ZGUgY2hhbm5lbCBpbmZvXG5cdFx0XHRpZiAoYWN0aW9uKSB7XG5cdFx0XHRcdGNvbnN0IGhhc0lkQWRkID0gYWN0aW9uLm9wdGlvbnM/LnNvbWUoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRpZiAoaGFzSWRBZGQgJiYgc2V0dGluZ0lkICE9PSBhY3Rpb24uaWQpIHtcblx0XHRcdFx0XHRjb25zdCBjaGFubmVsT2Zmc2V0ID0gc2V0dGluZ0lkIC0gYWN0aW9uLmlkXG5cdFx0XHRcdFx0c2V0dGluZ05hbWUgPSBgJHtzZXR0aW5nTmFtZX0gQ2gke2NoYW5uZWxPZmZzZXQgKyAxfWBcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBMb29rIGZvciB0aGUgdmFsdWUgb3B0aW9uIHRvIGdldCBjaG9pY2VzXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbiA9IGFjdGlvbj8ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdFx0XHRjb25zdCBjaG9pY2VzID0gdmFsdWVPcHRpb24/LmNob2ljZXNcblx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBTdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKVxuXHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID0gY2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cblx0XHRcdGNvbnN0IGNtZEhleCA9IHRvSGV4KGNtZElkKVxuXHRcdFx0Y29uc3QgaWRIZXggPSB0b0hleChzZXR0aW5nSWQpXG5cdFx0XHRjb25zdCB2YWxIZXggPSBieXRlc1RvSGV4KHZhbHVlQnl0ZXMpXG5cdFx0XHRjb25zdCB2YWxEZWMgPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB2YWx1ZUJ5dGVzLmpvaW4oJywnKVxuXG5cdFx0XHRjb25zdCBwcmVmaXggPSBgY21kOiR7Y21kSGV4fSBpZDoke2lkSGV4fSB2YWw6JHt2YWxIZXh9YFxuXHRcdFx0Y29uc3Qgc3VmZml4ID0gY2hvaWNlTGFiZWwgPyBgJHtzZXR0aW5nTmFtZX06ICR7Y2hvaWNlTGFiZWx9ICgke3ZhbERlY30pYCA6IGAke3NldHRpbmdOYW1lfTogJHt2YWxEZWN9YFxuXG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtwcmVmaXh9IHwgJHtzdWZmaXh9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFRYICR7ZGVzdElwfSB8ICR7Y21kTmFtZX1gKVxuXHRcdH1cblx0XHRsb2dnZXIuZGVidWcoYFNlbmRpbmcgcGFja2V0IHRvICR7ZGVzdElwfTogJHtwYWNrZXQudG9TdHJpbmcoJ2hleCcpfWApXG5cblx0XHRhd2FpdCB0aGlzLnR4UmVhZHlcblxuXHRcdGNvbnN0IGtleSA9IGAke2Rlc3RJcH06JHtjbWRJZH1gXG5cblx0XHRyZXR1cm4gbmV3IFByb21pc2U8QnVmZmVyPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYFRpbWVvdXQgd2FpdGluZyBmb3IgQUNLIGZyb20gTW9kZWwke21vZGVsfSBhdCAke2Rlc3RJcH06ODcwMGApKVxuXHRcdFx0fSwgdGltZW91dE1zKVxuXG5cdFx0XHR0aGlzLnBlbmRpbmdBY2tzLnNldChrZXksIHtcblx0XHRcdFx0cmVzb2x2ZTogKGJ1ZikgPT4ge1xuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblxuXHRcdFx0XHRcdC8vIElmIGRldmljZSByZXF1aXJlcyByZWZyZXNoIGFmdGVyIGNvbW1hbmQsIHJlcXVlc3QgYWxsIHNldHRpbmdzIChub24tYmxvY2tpbmcpXG5cdFx0XHRcdFx0aWYgKHRoaXMucmVmcmVzaEFmdGVyQ29tbWFuZCAmJiBzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdFx0dGhpcy5yZXF1ZXN0QWxsU2V0dGluZ3MoZGVzdElwKS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gcmVmcmVzaCBzZXR0aW5ncyBhZnRlciBjb21tYW5kOiAke2Vycn1gKVxuXHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRyZXNvbHZlKGJ1Zilcblx0XHRcdFx0fSxcblx0XHRcdFx0cmVqZWN0OiAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChlcnIpXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHRpbWVyLFxuXHRcdFx0fSlcblxuXHRcdFx0dGhpcy50eFNvY2tldC5zZW5kKHBhY2tldCwgdGhpcy5kZWZhdWx0UG9ydCwgZGVzdElwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGhhbmRsZUluY29taW5nKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKSB7XG5cdFx0aWYgKG1zZy5sZW5ndGggPCA0KSByZXR1cm5cblx0XHRpZiAobXNnWzBdICE9PSAweGZmIHx8IG1zZ1sxXSAhPT0gMHhmZikgcmV0dXJuXG5cblx0XHRjb25zdCBtc2dUeXBlID0gbXNnLnJlYWRVSW50MTZCRSgyKVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlICgweDAxNzApIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFRoZXNlIGhhdmUgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNiwgbm90IFwiU3R1ZGlvLVRcIiBcdTIwMTQgaGFuZGxlIGJlZm9yZVxuXHRcdC8vIHRoZSBTdHVkaW8tVCBzaWduYXR1cmUgY2hlY2sgYmVsb3cuXG5cdFx0aWYgKG1zZ1R5cGUgPT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFICYmIHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNpemUgPiAwKSB7XG5cdFx0XHRjb25zdCBkZXZpY2UgPSBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZywgc3JjSXApXG5cdFx0XHRpZiAoZGV2aWNlKSB7XG5cdFx0XHRcdGZvciAoY29uc3QgY2Igb2YgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMudmFsdWVzKCkpIHtcblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0Y2IoZGV2aWNlKVxuXHRcdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAobXNnLmxlbmd0aCA8IDI1KSByZXR1cm5cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBTdHVkaW8tVCBjb250cm9sIHByb3RvY29sIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGNvbnN0IHNpZyA9IG1zZy5zdWJhcnJheSgxNiwgMjQpXG5cdFx0aWYgKHNpZy50b1N0cmluZygnYXNjaWknKSAhPT0gJ1N0dWRpby1UJykgcmV0dXJuXG5cblx0XHQvLyBQYXlsb2FkIHN0YXJ0cyBhdCBvZmZzZXQgMjRcblx0XHQvLyBMYXlvdXQ6IFsweDVhXSBbY21kSWR8MHg4MF0gW2RhdGEuLi5dIFtjcmNdXG5cdFx0Y29uc3Qgc3RQYXlsb2FkID0gbXNnLnN1YmFycmF5KDI0KVxuXHRcdGlmIChzdFBheWxvYWQubGVuZ3RoIDwgMikgcmV0dXJuXG5cdFx0aWYgKHN0UGF5bG9hZFswXSAhPT0gMHg1YSkgcmV0dXJuXG5cblx0XHQvLyBEZXZpY2UgcmVwbGllcyB3aXRoIGNtZCB8IDB4ODBcblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBpc1Jlc3BvbnNlID0gKHJlc3BDbWRJZCAmIDB4ODApICE9PSAwXG5cdFx0Y29uc3Qgb3JpZ2luYWxDbWRJZCA9IHJlc3BDbWRJZCAmIDB4N2YgLy8gc3RyaXAgdGhlIHJlc3BvbnNlIGZsYWdcblxuXHRcdC8vIExvZyB0aGUgcGF5bG9hZCAod29ya3MgZm9yIGJvdGggcmVxdWVzdHMgYW5kIHJlc3BvbnNlcylcblx0XHR0aGlzLmxvZ1N0UGF5bG9hZChzcmNJcCwgb3JpZ2luYWxDbWRJZCwgbXNnLCBzdFBheWxvYWQsIGlzUmVzcG9uc2UpXG5cblx0XHQvLyBPbmx5IHByb2Nlc3MgYXMgQUNLIGlmIHRoaXMgaXMgYSByZXNwb25zZSB0byBvdXIgcmVxdWVzdFxuXHRcdGlmIChpc1Jlc3BvbnNlKSB7XG5cdFx0XHRjb25zdCBrZXkgPSBgJHtzcmNJcH06JHtvcmlnaW5hbENtZElkfWBcblx0XHRcdGNvbnN0IHBlbmRpbmcgPSB0aGlzLnBlbmRpbmdBY2tzLmdldChrZXkpXG5cdFx0XHRpZiAocGVuZGluZykge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHBlbmRpbmcucmVzb2x2ZShtc2cpXG5cdFx0XHR9XG5cdFx0fVxuXHRcdC8vIFVuc29saWNpdGVkIG1lc3NhZ2VzIGFuZCByZXF1ZXN0cyBmcm9tIG90aGVyIHNvdXJjZXMgYXJlIGxvZ2dlZCBhYm92ZVxuXHR9XG5cblx0LyoqXG5cdCAqIERlY29kZXMgYW5kIGxvZ3MgYSBTdHVkaW8tVCByZXNwb25zZSBwYXlsb2FkLlxuXHQgKiBSZWNlaXZlcyBib3RoIHRoZSBmdWxsIG1zZyAoZm9yIHBhcnNlcnMgdGhhdCBuZWVkIHRoZSBTdHVkaW8tVCBoZWFkZXIpXG5cdCAqIGFuZCBzdFBheWxvYWQgKG1zZy5zdWJhcnJheSgyNCksIGZvciBkaXJlY3QgYnl0ZSBhY2Nlc3MpLlxuXHQgKlxuXHQgKiBzdFBheWxvYWQgbGF5b3V0OlxuXHQgKiAgIFswXSAgICAgIDB4NWEgIG1hZ2ljXG5cdCAqICAgWzFdICAgICAgY21kSWQgfCAweDgwXG5cdCAqICAgWzIuLi0yXSAgZGF0YSBieXRlc1xuXHQgKiAgIFstMV0gICAgIENSQy04L0RWQi1TMlxuXHQgKi9cblx0cHJpdmF0ZSBsb2dTdFBheWxvYWQoc3JjSXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgbXNnOiBCdWZmZXIsIHN0UGF5bG9hZDogQnVmZmVyLCBpc1Jlc3BvbnNlID0gdHJ1ZSk6IHZvaWQge1xuXHRcdGNvbnN0IGNtZE5hbWUgPSBgY21kXyR7dG9IZXgoY21kSWQpfWBcblx0XHRjb25zdCBkYXRhID0gc3RQYXlsb2FkLnN1YmFycmF5KDIsIHN0UGF5bG9hZC5sZW5ndGggLSAxKSAvLyBzdHJpcCBtYWdpYytjbWRJZCBoZWFkZXIgYW5kIENSQ1xuXG5cdFx0Ly8gU2hvdyBjb21wbGV0ZSBwYXlsb2FkIHN0cnVjdHVyZTogWzB4NWFdIFtjbWRJZHwweDgwXSBbZGF0YSBieXRlcy4uLl0gW2NyY11cblx0XHRjb25zdCBtYWdpYyA9IHN0UGF5bG9hZFswXVxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGNyYyA9IHN0UGF5bG9hZFtzdFBheWxvYWQubGVuZ3RoIC0gMV1cblx0XHRjb25zdCBmdWxsU3RydWN0dXJlID0gYFttYWdpYzoke3RvSGV4KG1hZ2ljKX0gY21kOiR7dG9IZXgocmVzcENtZElkKX0gZGF0YToke2RhdGEudG9TdHJpbmcoJ2hleCcpfSBjcmM6JHt0b0hleChjcmMpfV1gXG5cblx0XHQvLyBEZXRlcm1pbmUgZGlyZWN0aW9uIHByZWZpeFxuXHRcdGNvbnN0IGRpcmVjdGlvbiA9IGlzUmVzcG9uc2UgPyAnUlgnIDogJ1NOSUZGJ1xuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSBhbmQgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFBhcnNlIGFsbCBzZXR0aW5ncywgZGlmZiBhZ2FpbnN0IGRldmljZVN0YXRlLCBsb2cgY2hhbmdlZCBhdCBpbmZvIC8gdW5jaGFuZ2VkIGF0IGRlYnVnLFxuXHRcdC8vIHRoZW4gdXBkYXRlIGRldmljZVN0YXRlLiBDTURfR0VUX0FMTF9TRVRUSU5HUyBhbHNvIHNlcnZlcyBhcyB0aGUgaW5pdGlhbCBzdGF0ZSBwb3B1bGF0aW9uIG9uIGNvbm5lY3QuXG5cdFx0aWYgKGNtZElkID09PSBDTURfR0VUX0FMTF9TRVRUSU5HUyB8fCBjbWRJZCA9PT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHRcdGlmICghdGhpcy5tb2RlbCkge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgJHtkaXJlY3Rpb259ICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IHNldHRpbmdzID1cblx0XHRcdFx0XHRjbWRJZCA9PT0gQ01EX1NFVFRJTkdTX1BVU0hcblx0XHRcdFx0XHRcdD8gcGFyc2VTZXR0aW5nc1Jlc3BvbnNlKHRoaXMubW9kZWwsIG1zZylcblx0XHRcdFx0XHRcdDogcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsKHRoaXMubW9kZWwsIG1zZylcblxuXHRcdFx0XHRjb25zdCBwcmV2U3RhdGUgPSB0aGlzLmRldmljZVN0YXRlLmdldChzcmNJcCkgPz8gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKVxuXHRcdFx0XHRjb25zdCBuZXdTdGF0ZSA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KHByZXZTdGF0ZSkgLy8gY29weSBcdTIwMTQgdXBkYXRlIGluIHBsYWNlXG5cblx0XHRcdFx0Zm9yIChjb25zdCBzIG9mIHNldHRpbmdzKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc3RhdGVLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIHMuY21kX2lkLCBzLmlkLCBzLmJ1c0NoKVxuXHRcdFx0XHRcdC8vIEZvciBSR0IgY29sb3JzICgzIGJ5dGVzKSwgcGFjayBpbnRvIHNpbmdsZSBudW1iZXI6IChSIDw8IDE2KSB8IChHIDw8IDgpIHwgQlxuXHRcdFx0XHRcdGNvbnN0IG5ld1ZhbHVlID1cblx0XHRcdFx0XHRcdHMudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdFx0XHRcdFx0PyAocy52YWx1ZUJ5dGVzWzBdIDw8IDE2KSB8IChzLnZhbHVlQnl0ZXNbMV0gPDwgOCkgfCBzLnZhbHVlQnl0ZXNbMl1cblx0XHRcdFx0XHRcdFx0OiAocy52YWx1ZUJ5dGVzWzBdID8/IDApXG5cdFx0XHRcdFx0Y29uc3QgcHJldlZhbHVlID0gcHJldlN0YXRlLmdldChzdGF0ZUtleSlcblx0XHRcdFx0XHRjb25zdCBjaGFuZ2VkID0gcHJldlZhbHVlICE9PSB1bmRlZmluZWQgJiYgcHJldlZhbHVlICE9PSBuZXdWYWx1ZVxuXG5cdFx0XHRcdFx0bmV3U3RhdGUuc2V0KHN0YXRlS2V5LCBuZXdWYWx1ZSlcblxuXHRcdFx0XHRcdGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdFBhcnNlZFNldHRpbmcocywgdGhpcy5hY3Rpb25zKVxuXHRcdFx0XHRcdGlmIChjaGFuZ2VkKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgJHtkaXJlY3Rpb259ICR7c3JjSXB9IHwgJHtmb3JtYXR0ZWR9YClcblx0XHRcdFx0XHRcdC8vIFRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlIGZvciB0aGlzIHNldHRpbmdcblx0XHRcdFx0XHRcdGlmICh0aGlzLmZlZWRiYWNrQ2FsbGJhY2spIHtcblx0XHRcdFx0XHRcdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrKHN0YXRlS2V5KVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYCR7ZGlyZWN0aW9ufSAke3NyY0lwfSB8ICR7Zm9ybWF0dGVkfWApXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuZGV2aWNlU3RhdGUuc2V0KHNyY0lwLCBuZXdTdGF0ZSlcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYCR7ZGlyZWN0aW9ufSAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCBwYXJzZSBmYWlsZWQ6ICR7ZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBBbGwgb3RoZXIgY29tbWFuZHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Y29uc3QgZGVjb2RlZCA9IHRoaXMuZGVjb2RlU3REYXRhKGNtZElkLCBkYXRhKVxuXHRcdGlmIChkZWNvZGVkKSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgJHtkaXJlY3Rpb259ICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX0gfCAke2RlY29kZWR9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYCR7ZGlyZWN0aW9ufSAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogQXR0ZW1wdHMgdG8gZGVjb2RlIHRoZSBkYXRhIGJ5dGVzIG9mIGEgU3R1ZGlvLVQgcmVzcG9uc2UgaW50byBhXG5cdCAqIGh1bWFuLXJlYWRhYmxlIHN0cmluZy4gUmV0dXJucyBudWxsIHRvIGZhbGwgYmFjayB0byByYXcgaGV4LlxuXHQgKlxuXHQgKiBtc2cgaXMgdGhlIGZ1bGwgcGFja2V0IGJ1ZmZlciBcdTIwMTQgcmVxdWlyZWQgYnkgdGhlIHNldHRpbmdzIHBhcnNlcnMgd2hpY2hcblx0ICogbG9jYXRlIHRoZSBTdHVkaW8tVCBzaWduYXR1cmUgdGhlbXNlbHZlcy5cblx0ICovXG5cdHByaXZhdGUgZGVjb2RlU3REYXRhKGNtZElkOiBudW1iZXIsIGRhdGE6IEJ1ZmZlcik6IHN0cmluZyB8IG51bGwge1xuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMCkgcmV0dXJuICdBQ0snXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ2hlY2sgZm9yIHNpbmdsZS1ieXRlIHJlc3BvbnNlcyAoQUNLIG9yIGVycm9yKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdGlmIChkYXRhWzBdID09PSAweDAwKSB7XG5cdFx0XHRcdHJldHVybiAnQUNLIG9rJ1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0cmV0dXJuIGBFUlJPUiAke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdH1cblx0XHR9XG5cblx0XHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0RFVl9TUEVDICgweDBkKTogc2luZ2xlLWJ5dGUgQUNLIG9yIGVjaG8gb2YgYXBwbGllZCBzZXR0aW5nIFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gRGV2aWNlIHNlbmRzIHR3byBDTURfREVWX1NQRUMgcGFja2V0cyBpbiByZXNwb25zZSB0byBhIHNldDpcblx0XHRcdC8vICAgMS4gQUNLOiAgW3N0YXR1c10gICAgICAgICAgICAgICAoMSBieXRlLCAweDAwID0gb2spXG5cdFx0XHQvLyAgIDIuIEVjaG86IFtidXNDaF0gW3NldHRpbmdJZF0gW3ZhbHVlLi4uXSAgKGNvbmZpcm1pbmcgd2hhdCB3YXMgYXBwbGllZClcblx0XHRcdGNhc2UgQ01EX0RFVl9TUEVDOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0XHRcdHJldHVybiBkYXRhWzBdID09PSAweDAwID8gJ0FDSyBvaycgOiBgQUNLIGVycj0ke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlcyA9IGFjdGlvbj8ub3B0aW9ucz8uWzBdPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9XG5cdFx0XHRcdFx0XHRjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVN0ciA9IGNob2ljZUxhYmVsID8gYCR7Y2hvaWNlTGFiZWx9ICgke3RvSGV4KHZhbHVlTnVtISl9KWAgOiBieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpXG5cdFx0XHRcdFx0Y29uc3QgcmF3VGFnID0gYFske3RvSGV4KGNtZElkKX0vJHt0b0hleChzZXR0aW5nSWQpfV09JHtieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn0gJHtyYXdUYWd9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBgcmF3OiAke2RhdGEudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9NSUNfUFJFX0JVUyAoMHgxMik6IE11bHRpLWJ5dGUgZWNobyByZXNwb25zZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzoge1xuXHRcdFx0XHQvLyBBbHJlYWR5IGhhbmRsZWQgc2luZ2xlLWJ5dGUgYWJvdmUsIHNvIG11bHRpLWJ5dGUgbXVzdCBiZSBlY2hvXG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfWBcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/PyBgMHgke3ZhbHVlQnl0ZXMudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn1gXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIG51bGxcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEJ1cy1zY29wZWQgZ2V0L3NldCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdGNhc2UgQ01EX0JVU19HRVQ6XG5cdFx0XHRjYXNlIENNRF9CVVNfU0VUOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA8IDIpIHJldHVybiBudWxsXG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRyZXR1cm4gYGNoPSR7YnVzQ2h9IHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfSB2YWx1ZT0ke3ZhbHVlLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdHJldHVybiBudWxsIC8vIGZhbGwgdGhyb3VnaCB0byByYXcgaGV4XG5cdFx0fVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlOiB1bmtub3duKTogbnVtYmVyW10ge1xuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykgcmV0dXJuIFt2YWx1ZSA/IDEgOiAwXVxuXHRcdGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gTnVtYmVyKHYpICYgMHhmZilcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuXHRcdFx0aWYgKHZhbHVlID4gMHhmZikgcmV0dXJuIFsodmFsdWUgPj4gMTYpICYgMHhmZiwgKHZhbHVlID4+IDgpICYgMHhmZiwgdmFsdWUgJiAweGZmXVxuXHRcdFx0cmV0dXJuIFt2YWx1ZSAmIDB4ZmZdXG5cdFx0fVxuXHRcdHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgdmFsdWUgdHlwZSBmb3IgU1Rjb250cm9sbGVyOiAke3ZhbHVlfWApXG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBhc3luYyBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8bnVtYmVyW10+IHtcblx0XHRyZXR1cm4gbmV3IFByb21pc2U8bnVtYmVyW10+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHR9KVxuXG5cdFx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXG5cdFx0XHRcdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdFx0XHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IGlmYWNlIG9mIGlmYWNlc1tuYW1lXSA/PyBbXSkge1xuXHRcdFx0XHRcdFx0XHRpZiAoXG5cdFx0XHRcdFx0XHRcdFx0aWZhY2UuZmFtaWx5ID09PSAnSVB2NCcgJiZcblx0XHRcdFx0XHRcdFx0XHRpZmFjZS5hZGRyZXNzID09PSBsb2NhbEFkZHIgJiZcblx0XHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgJiZcblx0XHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCdcblx0XHRcdFx0XHRcdFx0KSB7XG5cdFx0XHRcdFx0XHRcdFx0cmV0dXJuIHJlc29sdmUoaWZhY2UubWFjLnNwbGl0KCc6JykubWFwKChiKSA9PiBwYXJzZUludChiLCAxNikgJiAweGZmKSlcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYE5vIGludGVyZmFjZSBmb3VuZCBmb3IgbG9jYWwgYWRkcmVzcyAke2xvY2FsQWRkcn1gKSlcblx0XHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBhc3luYyBidWlsZEhlYWRlcihkZXN0SXA6IHN0cmluZywgbXNnVHlwZSA9IDB4MDAyMCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0Y29uc3QgbWFjID0gYXdhaXQgU3RDb250cm9sbGVyLmdldE1hY0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblxuXHRcdC8vIE1lc3NhZ2UgdHlwZSBpcyAyIGJ5dGVzIChiaWctZW5kaWFuKTogZS5nLiwgMHgwMDIwLCAweDAwMWIsIDB4MDAxZVxuXHRcdGNvbnN0IG1zZ1R5cGVNc2IgPSAobXNnVHlwZSA+PiA4KSAmIDB4ZmZcblx0XHRjb25zdCBtc2dUeXBlTHNiID0gbXNnVHlwZSAmIDB4ZmZcblxuXHRcdHJldHVybiBCdWZmZXIuY29uY2F0KFtcblx0XHRcdEJ1ZmZlci5mcm9tKFsweGZmLCAweGZmLCBtc2dUeXBlTXNiLCBtc2dUeXBlTHNiLCAweDA3LCAweGUxLCAweDAwLCAweDAwLCAuLi5tYWMsIDB4MDAsIDB4MDBdKSxcblx0XHRcdEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcsICd1dGY4JyksXG5cdFx0XSlcblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGNyYzhEdmJTMihkYXRhOiBudW1iZXJbXSk6IG51bWJlciB7XG5cdFx0bGV0IGNyYyA9IDBcblx0XHRmb3IgKGNvbnN0IGIgb2YgZGF0YSkge1xuXHRcdFx0Y3JjIF49IGJcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgODsgaSsrKSB7XG5cdFx0XHRcdGNyYyA9IChjcmMgJiAweDgwKSAhPT0gMCA/ICgoY3JjIDw8IDEpIF4gMHhkNSkgJiAweGZmIDogKGNyYyA8PCAxKSAmIDB4ZmZcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGNyY1xuXHR9XG5cblx0LyoqXG5cdCAqIFJldHVybnMgdGhlIGN1cnJlbnQga25vd24gdmFsdWUgZm9yIGEgc2V0dGluZyBvbiBhIGRldmljZSwgb3IgdW5kZWZpbmVkIGlmIHVua25vd24uXG5cdCAqIFVzZSBmb3IgZmVlZGJhY2tzIFx1MjAxNCB2YWx1ZSBpcyB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBmcm9tIHRoZSBkZXZpY2UuXG5cdCAqXG5cdCAqIEBwYXJhbSBpcCAgICAgICAgRGV2aWNlIElQIGFkZHJlc3Ncblx0ICogQHBhcmFtIGNtZElkICAgICBDb21tYW5kIElEIChlLmcuIENNRF9ERVZfU1BFQylcblx0ICogQHBhcmFtIHNldHRpbmdJZCBTZXR0aW5nIElEIChlLmcuIDB4MDIgZm9yIENvbnRyb2wgU291cmNlKVxuXHQgKiBAcGFyYW0gYnVzQ2ggICAgIE9wdGlvbmFsIGJ1cy9jaGFubmVsIElEIGZvciBtdWx0aS1jaGFubmVsIGNvbW1hbmRzXG5cdCAqL1xuXHRwdWJsaWMgZ2V0U2V0dGluZ1ZhbHVlKGlwOiBzdHJpbmcsIGNtZElkOiBudW1iZXIsIHNldHRpbmdJZDogbnVtYmVyLCBidXNDaD86IG51bWJlcik6IG51bWJlciB8IHVuZGVmaW5lZCB7XG5cdFx0Y29uc3Qga2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBidXNDaClcblx0XHRyZXR1cm4gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoaXApPy5nZXQoa2V5KVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHJlc2V0RGV2aWNlKG1vZGVsOiBzdHJpbmcsIGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5zZW5kQXdhaXRBY2sobW9kZWwsIENNRF9SRVNFVF9ERVZJQ0UsIHVuZGVmaW5lZCwgMHgwMCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG5cblx0cHVibGljIGFzeW5jIGdsb2JhbE1pY0tpbGwobW9kZWw6IHN0cmluZywgZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHJldHVybiB0aGlzLnNlbmRBd2FpdEFjayhtb2RlbCwgQ01EX0dMT0JBTF9NSUNfS0lMTCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGVzdElwLCBmYWxzZSlcblx0fVxufVxuIiwgImltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSdcbmltcG9ydCBvcyBmcm9tICdvcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IERldmljZUluZm8gfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ0RhbnRlJylcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIERhbnRlIGRpc2NvdmVyeSBjb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKiBEYW50ZSBkZXZpY2UgaW5mbyByZXF1ZXN0IG1lc3NhZ2UgdHlwZSAoc2VudCB0byBwb3J0IDg3MDApICovXG5leHBvcnQgY29uc3QgREFOVEVfTVNHX0lORk9fUkVRVUVTVCA9IDB4MDAyMFxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlIG1lc3NhZ2UgdHlwZSAocmVjZWl2ZWQgb24gcG9ydCA4NzAyKSAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX01TR19JTkZPX1JFU1BPTlNFID0gMHgwMTcwXG5cbi8qKlxuICogRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgbGF5b3V0IChhbGwgb2Zmc2V0cyBhcmUgaW50byB0aGUgVURQIHBheWxvYWQpOlxuICogICAweDAwICB1aW50MTZCRSAgTWFnaWMgKDB4ZmZmZilcbiAqICAgMHgwMiAgdWludDE2QkUgIE1lc3NhZ2UgdHlwZSAoMHgwMTcwKVxuICogICAweDA0ICB1aW50MTZCRSAgU2VxdWVuY2UgbnVtYmVyXG4gKiAgIDB4MDYgIDIgYnl0ZXMgICBQYWRkaW5nXG4gKiAgIDB4MDggIDggYnl0ZXMgICBFVUktNjQgKHNvdXJjZSBNQUMgd2l0aCBmZjpmZSBpbnNlcnRlZCBtaWQpXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgQVNDSUkgaWRlbnRpZmllclxuICogICAweDE4ICAyIGJ5dGVzICAgRGFudGUgbW9kdWxlIGZpcm13YXJlIHZlcnNpb24gKG1ham9yLCBtaW5vcilcbiAqICAgMHgyMCAgMzEgYnl0ZXMgIERldmljZSBuYW1lLCBudWxsLXBhZGRlZCBBU0NJSSAobWF4IDMxIGNoYXJzIHBlciBEYW50ZSBzcGVjKVxuICogICAweDJlICB1aW50MTZCRSAgUHJvZHVjdCBJRFxuICogICAweDRjICA2NCBieXRlcyAgTWFudWZhY3R1cmVyIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqICAgMHhjYyAgNjQgYnl0ZXMgIE1vZGVsIHN0cmluZywgbnVsbC1wYWRkZWQgQVNDSUlcbiAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX0lORk9fTUlOX0xFTiA9IDB4Y2MgKyA2NCAvLyAyNjggYnl0ZXMgXHUyMDE0IG5lZWQgZnVsbCBtb2RlbCBmaWVsZFxuXG4vKipcbiAqIEJ1aWxkcyBhIERhbnRlIGRldmljZSBpbmZvIHJlcXVlc3QgcGFja2V0ICh0eXBlIDB4MDAyMCkuXG4gKlxuICogUGFja2V0IGxheW91dCAoMzIgYnl0ZXMpIFx1MjAxNCBkZXJpdmVkIGZyb20gbGl2ZSBjYXB0dXJlIGFuYWx5c2lzOlxuICogICAweDAwICB1aW50MTZCRSAgTWFnaWMgKDB4ZmZmZilcbiAqICAgMHgwMiAgdWludDE2QkUgIE1lc3NhZ2UgdHlwZSAoMHgwMDIwID0gZGV2aWNlIGluZm8gcmVxdWVzdClcbiAqICAgMHgwNCAgdWludDE2QkUgIFNlcXVlbmNlIG51bWJlciAocmFuZG9tKVxuICogICAweDA2ICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDA4ICA2IGJ5dGVzICAgU291cmNlIE1BQ1xuICogICAweDBlICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIEFTQ0lJIGlkZW50aWZpZXJcbiAqICAgMHgxOCAgMiBieXRlcyAgIFByb3RvY29sIHZlcnNpb24gKDB4MDczOSlcbiAqICAgMHgxYSAgMiBieXRlcyAgIFN1Yi10eXBlICgweDAwYzEpXG4gKiAgIDB4MWMgIHVpbnQzMkJFICBDYXBhYmlsaXR5IG1hc2sgKDB4MDAwZjQyNDApXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidWlsZERhbnRlSW5mb1JlcXVlc3QoKTogQnVmZmVyIHtcblx0Y29uc3QgYnVmID0gQnVmZmVyLmFsbG9jKDMyLCAwKVxuXHRjb25zdCBzZXEgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAweGZmZmYpXG5cblx0YnVmLndyaXRlVUludDE2QkUoMHhmZmZmLCAwKVxuXHRidWYud3JpdGVVSW50MTZCRShEQU5URV9NU0dfSU5GT19SRVFVRVNULCAyKVxuXHRidWYud3JpdGVVSW50MTZCRShzZXEsIDQpXG5cblx0Y29uc3QgbWFjID0gZ2V0Rmlyc3RMb2NhbE1hYygpXG5cdG1hYy5jb3B5KGJ1ZiwgOClcblxuXHRCdWZmZXIuZnJvbSgnQXVkaW5hdGUnLCAnYXNjaWknKS5jb3B5KGJ1ZiwgMTYpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4MDczOSwgMjQpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4MDBjMSwgMjYpXG5cdGJ1Zi53cml0ZVVJbnQzMkJFKDB4MDAwZjQyNDAsIDI4KVxuXG5cdHJldHVybiBidWZcbn1cblxuLyoqIFJldHVybnMgdGhlIGZpcnN0IG5vbi1sb29wYmFjayBNQUMgYXMgYSA2LWJ5dGUgQnVmZmVyLCBvciB6ZXJvcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRGaXJzdExvY2FsTWFjKCk6IEJ1ZmZlciB7XG5cdHRyeSB7XG5cdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRmb3IgKGNvbnN0IGFkZHIgb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdGlmICghYWRkci5pbnRlcm5hbCAmJiBhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmIGFkZHIubWFjICYmIGFkZHIubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnKSB7XG5cdFx0XHRcdFx0cmV0dXJuIEJ1ZmZlci5mcm9tKGFkZHIubWFjLnNwbGl0KCc6JykubWFwKChoOiBzdHJpbmcpID0+IHBhcnNlSW50KGgsIDE2KSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH0gY2F0Y2gge1xuXHRcdC8qIGlnbm9yZSAqL1xuXHR9XG5cdHJldHVybiBCdWZmZXIuYWxsb2MoNiwgMClcbn1cblxuLyoqXG4gKiBQYXJzZXMgYSBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSAodHlwZSAweDAxNzApIGludG8gYSBEZXZpY2VJbmZvLlxuICpcbiAqIFJlc3BvbnNlIGxheW91dCAoa2V5IG9mZnNldHMpOlxuICogICAweDA4ICA4IGJ5dGVzICAgRVVJLTY0IFx1MjAxNCBjb252ZXJ0IHRvIE1BQyBieSBkcm9wcGluZyBieXRlcyBbM10gYW5kIFs0XSAoZmY6ZmUpXG4gKiAgIDB4MTAgIDggYnl0ZXMgICBcIkF1ZGluYXRlXCIgaWRlbnRpZmllciAodXNlZCB0byB2ZXJpZnkgdGhpcyBpcyBhIHJlYWwgcmVzcG9uc2UpXG4gKiAgIDB4MTggIDEgYnl0ZSAgICBEYW50ZSBGVyBtYWpvclxuICogICAweDE5ICAxIGJ5dGUgICAgRGFudGUgRlcgbWlub3JcbiAqICAgMHgyMCAgMzEgYnl0ZXMgIERldmljZSBuYW1lIChEYW50ZSBsYWJlbCksIG51bGwtcGFkZGVkIEFTQ0lJIChtYXggMzEgY2hhcnMpXG4gKiAgIDB4MmUgIHVpbnQxNkJFICBQcm9kdWN0IElEXG4gKiAgIDB4NGMgIDY0IGJ5dGVzICBNYW51ZmFjdHVyZXIsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKiAgIDB4Y2MgIDY0IGJ5dGVzICBNb2RlbCBzdHJpbmcsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKlxuICogUmV0dXJucyBudWxsIGlmIGJ1ZmZlciBpcyB0b28gc2hvcnQsIHdyb25nIG1hZ2ljLCBvciBtaXNzaW5nIG1vZGVsIHN0cmluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpOiBEZXZpY2VJbmZvIHwgbnVsbCB7XG5cdGlmIChtc2cubGVuZ3RoIDwgREFOVEVfSU5GT19NSU5fTEVOKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgwKSAhPT0gMHhmZmZmKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgyKSAhPT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UpIHJldHVybiBudWxsXG5cdGlmIChtc2cuc3ViYXJyYXkoMTYsIDI0KS50b1N0cmluZygnYXNjaWknKSAhPT0gJ0F1ZGluYXRlJykgcmV0dXJuIG51bGxcblxuXHRjb25zdCByZWFkU3RyID0gKG9mZnNldDogbnVtYmVyLCBsZW46IG51bWJlcik6IHN0cmluZyA9PlxuXHRcdG1zZ1xuXHRcdFx0LnN1YmFycmF5KG9mZnNldCwgb2Zmc2V0ICsgbGVuKVxuXHRcdFx0LnRvU3RyaW5nKCdhc2NpaScpXG5cdFx0XHQuc3BsaXQoJ1xcMCcpWzBdXG5cdFx0XHQudHJpbSgpXG5cblx0Y29uc3QgZXVpNjQgPSBtc2cuc3ViYXJyYXkoOCwgMTYpXG5cdGNvbnN0IG1hY0J5dGVzID0gW2V1aTY0WzBdLCBldWk2NFsxXSwgZXVpNjRbMl0sIGV1aTY0WzVdLCBldWk2NFs2XSwgZXVpNjRbN11dXG5cdGNvbnN0IG1hYyA9IG1hY0J5dGVzLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSkuam9pbignOicpXG5cblx0Y29uc3QgbmFtZSA9IHJlYWRTdHIoMHgyMCwgMzEpIC8vIERhbnRlIGRldmljZSBsYWJlbCAoY2FuIGJlIHVwIHRvIDMxIGNoYXJzIHBlciBEYW50ZSBzcGVjKVxuXHRjb25zdCBtYW51ZmFjdHVyZXIgPSByZWFkU3RyKDB4NGMsIDY0KSAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGNvbnN0IG1vZGVsUmF3ID0gcmVhZFN0cigweGNjLCA2NClcblx0Y29uc3QgZGFudGVGaXJtd2FyZSA9IGAke21zZ1sweDE4XX0uJHttc2dbMHgxOV19YFxuXG5cdGlmICghbW9kZWxSYXcpIHJldHVybiBudWxsXG5cblx0Ly8gRXh0cmFjdCBqdXN0IHRoZSBtb2RlbCBudW1iZXIvY29kZSAoZS5nLiBcIk1vZGVsIDM5MSBBbGVydGluZyBVbml0XCIgXHUyMTkyIFwiMzkxXCIpXG5cdC8vIFN0cmlwIFwiTW9kZWwgXCIgcHJlZml4LCB0aGVuIHRha2Ugb25seSB0aGUgZmlyc3Qgd29yZCAodGhlIG1vZGVsIG51bWJlcilcblx0Y29uc3QgbW9kZWwgPSBtb2RlbFJhd1xuXHRcdC5yZXBsYWNlKC9eTW9kZWxcXHMrL2ksICcnKVxuXHRcdC50cmltKClcblx0XHQuc3BsaXQoL1xccysvKVswXVxuXG5cdHJldHVybiB7XG5cdFx0aXA6IHNyY0lwLFxuXHRcdG5hbWUsXG5cdFx0bWFudWZhY3R1cmVyLFxuXHRcdG1vZGVsLFxuXHRcdG1vZGVsTmFtZTogbW9kZWxSYXcsIC8vIEZ1bGwgbW9kZWwgZGVzY3JpcHRpb25cblx0XHRtYWMsXG5cdFx0ZGFudGVGaXJtd2FyZSxcblx0fVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGxvY2FsIElQIGFkZHJlc3MgdXNlZCBieSB0aGUgT1MgdG8gcm91dGUgdG8gZGVzdElwLlxuICogVXNlcyBhIHRlbXBvcmFyeSBVRFAgc29ja2V0IGNvbm5lY3QgdG8gbGV0IHRoZSBPUyBzZWxlY3QgdGhlIG91dGdvaW5nIGludGVyZmFjZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPHN0cmluZz4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHQvLyBVc2UgYW4gYXJiaXRyYXJ5IHBvcnQgZm9yIGNvbm5lY3Q7IHdlIG9ubHkgbmVlZCB0aGUga2VybmVsIHRvIGFzc2lnbiBhIGxvY2FsIGFkZHJlc3MuXG5cdFx0dG1wLmNvbm5lY3QoOSwgZGVzdElwLCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGFkZHIuYWRkcmVzc1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZXNvbHZlKGxvY2FsQWRkcilcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihTdHJpbmcoX2UpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogRGlzY292ZXJzIFN0dWRpbyBUZWNobm9sb2dpZXMgRGFudGUgZGV2aWNlcyBvbiB0aGUgbG9jYWwgbmV0d29yay5cbiAqXG4gKiBTdHJhdGVneTpcbiAqICBEYW50ZSBkZXZpY2VzIGJyb2FkY2FzdCBhIDEtc2Vjb25kIGFubm91bmNlIHRvIG11bHRpY2FzdCAyMjQuMC4wLjIzMzo4NzA4LlxuICogIFdlIGxpc3RlbiBvbiB0aGF0IGdyb3VwLCBjb2xsZWN0IHNvdXJjZSBJUHMsIHRoZW4gc2VuZCBhIHVuaWNhc3QgZGV2aWNlIGluZm9cbiAqICByZXF1ZXN0ICgweDAwMjApIHRvIGVhY2ggbmV3IElQIG9uIHBvcnQgODcwMC4gVGhlIGRldmljZSByZXNwb25kcyBvbiBwb3J0IDg3MDIsXG4gKiAgd2hlcmUgdGhlIHByb3ZpZGVkIG9uRGV2aWNlRm91bmQgY2FsbGJhY2sgaXMgaW52b2tlZC5cbiAqXG4gKiBAcGFyYW0gdHhTb2NrZXQgLSBUaGUgc29ja2V0IHRvIHVzZSBmb3Igc2VuZGluZyBkaXNjb3ZlcnkgcmVxdWVzdHNcbiAqIEBwYXJhbSBvbkRldmljZUZvdW5kIC0gQ2FsbGJhY2sgaW52b2tlZCB3aGVuIGEgZGV2aWNlIGluZm8gcmVzcG9uc2UgKDB4MDE3MCkgaXMgcmVjZWl2ZWRcbiAqIEBwYXJhbSBlbnN1cmVNZW1iZXJzaGlwIC0gQ2FsbGJhY2sgdG8gZW5zdXJlIG11bHRpY2FzdCBtZW1iZXJzaGlwIGZvciBkZXZpY2UgSVBcbiAqIEBwYXJhbSB0aW1lb3V0TXMgLSBEaXNjb3ZlcnkgdGltZW91dCBpbiBtaWxsaXNlY29uZHNcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRpc2NvdmVyRGV2aWNlcyhcblx0dHhTb2NrZXQ6IGRncmFtLlNvY2tldCxcblx0b25EZXZpY2VGb3VuZDogKGRldmljZTogRGV2aWNlSW5mbykgPT4gdm9pZCxcblx0ZW5zdXJlTWVtYmVyc2hpcDogKGRlc3RJcDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+LFxuXHR0aW1lb3V0TXMgPSA1MDAwLFxuKTogUHJvbWlzZTxEZXZpY2VJbmZvW10+IHtcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfR1JPVVAgPSAnMjI0LjAuMC4yMzMnXG5cdGNvbnN0IERBTlRFX0FOTk9VTkNFX1BPUlQgPSA4NzA4XG5cdGNvbnN0IERFRkFVTFRfUE9SVCA9IDg3MDBcblxuXHRjb25zdCBmb3VuZCA9IG5ldyBNYXA8c3RyaW5nLCBEZXZpY2VJbmZvPigpXG5cdGNvbnN0IHF1ZXJpZWRJcHMgPSBuZXcgU2V0PHN0cmluZz4oKVxuXG5cdHJldHVybiBuZXcgUHJvbWlzZTxEZXZpY2VJbmZvW10+KChyZXNvbHZlKSA9PiB7XG5cdFx0Ly8gV3JhcCB0aGUgY2FsbGJhY2sgdG8gdHJhY2sgZm91bmQgZGV2aWNlc1xuXHRcdGNvbnN0IHdyYXBwZWRDYWxsYmFjayA9IChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdGlmICghZm91bmQuaGFzKGRldmljZS5pcCkpIHtcblx0XHRcdFx0Zm91bmQuc2V0KGRldmljZS5pcCwgZGV2aWNlKVxuXHRcdFx0XHRvbkRldmljZUZvdW5kKGRldmljZSlcblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBPcGVuIGEgc2hvcnQtbGl2ZWQgc29ja2V0IGp1c3QgdG8gcmVjZWl2ZSB0aGUgRGFudGUgcGVyaW9kaWMgYW5ub3VuY2VzXG5cdFx0Y29uc3QgYW5ub3VuY2VTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0Y29uc3QgY2xlYW51cCA9ICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmRyb3BNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0cmVzb2x2ZShBcnJheS5mcm9tKGZvdW5kLnZhbHVlcygpKSlcblx0XHR9XG5cblx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoY2xlYW51cCwgdGltZW91dE1zKVxuXHRcdHRpbWVyLnVucmVmPy4oKVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEFubm91bmNlIHNvY2tldCBlcnJvcjogJHtlcnIubWVzc2FnZX1gKVxuXHRcdH0pXG5cblx0XHRhbm5vdW5jZVNvY2tldC5vbignbWVzc2FnZScsIChtc2csIHJpbmZvKSA9PiB7XG5cdFx0XHRjb25zdCBzcmNJcCA9IHJpbmZvLmFkZHJlc3Ncblx0XHRcdC8vIFZhbGlkYXRlIGl0J3MgYSBEYW50ZSBhbm5vdW5jZSAobWFnaWMgMHhmZmZlICsgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNilcblx0XHRcdGlmIChtc2cubGVuZ3RoIDwgMjQpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZSkgcmV0dXJuXG5cdFx0XHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVyblxuXG5cdFx0XHRpZiAocXVlcmllZElwcy5oYXMoc3JjSXApKSByZXR1cm5cblx0XHRcdHF1ZXJpZWRJcHMuYWRkKHNyY0lwKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBBbm5vdW5jZSBmcm9tICR7c3JjSXB9IFx1MjAxNCBzZW5kaW5nIHVuaWNhc3QgcXVlcnlgKVxuXG5cdFx0XHQvLyBKb2luIDIyNC4wLjAuMjMxIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gdGhpcyBkZXZpY2UgQkVGT1JFIHNlbmRpbmdcblx0XHRcdC8vIHRoZSBxdWVyeS4gVGhlIGRldmljZSBtdWx0aWNhc3RzIGl0cyAweDAxNzAgcmVzcG9uc2UgdG8gMjI0LjAuMC4yMzE6ODcwMlxuXHRcdFx0Ly8gaW4gYWRkaXRpb24gdG8gdW5pY2FzdGluZyBpdCBcdTIwMTQgcnhTb2NrZXQgbXVzdCBiZSBhIG1lbWJlciB0byByZWNlaXZlIGl0LlxuXHRcdFx0ZW5zdXJlTWVtYmVyc2hpcChzcmNJcClcblx0XHRcdFx0LnRoZW4oKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IHF1ZXJ5ID0gYnVpbGREYW50ZUluZm9SZXF1ZXN0KClcblx0XHRcdFx0XHR0eFNvY2tldC5zZW5kKHF1ZXJ5LCBERUZBVUxUX1BPUlQsIHNyY0lwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0XHRpZiAoZXJyKSBsb2dnZXIud2FybihgVW5pY2FzdCBxdWVyeSB0byAke3NyY0lwfSBmYWlsZWQ6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9KVxuXHRcdFx0XHQuY2F0Y2goKGVycikgPT4gbG9nZ2VyLndhcm4oYFF1ZXJ5IHNldHVwIGZhaWxlZDogJHtlcnJ9YCkpXG5cdFx0fSlcblxuXHRcdGFubm91bmNlU29ja2V0LmJpbmQoREFOVEVfQU5OT1VOQ0VfUE9SVCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuYWRkTWVtYmVyc2hpcChEQU5URV9BTk5PVU5DRV9HUk9VUClcblx0XHRcdFx0bG9nZ2VyLmluZm8oYExpc3RlbmluZyBmb3IgRGFudGUgYW5ub3VuY2VzIG9uICR7REFOVEVfQU5OT1VOQ0VfR1JPVVB9OiR7REFOVEVfQU5OT1VOQ0VfUE9SVH1gKVxuXHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3Qgam9pbiBhbm5vdW5jZSBtdWx0aWNhc3QgZ3JvdXA6ICR7ZXJyfWApXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIFN0b3JlIGNhbGxiYWNrIGZvciBjbGVhbnVwXG5cdFx0Oyhhbm5vdW5jZVNvY2tldCBhcyBhbnkpLndyYXBwZWRDYWxsYmFjayA9IHdyYXBwZWRDYWxsYmFja1xuXHR9KVxufVxuIiwgImltcG9ydCB7XG5cdEluc3RhbmNlVHlwZXMsXG5cdEluc3RhbmNlQmFzZSxcblx0SW5zdGFuY2VTdGF0dXMsXG5cdFNvbWVDb21wYW5pb25Db25maWdGaWVsZCxcblx0Y3JlYXRlTW9kdWxlTG9nZ2VyLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgR2V0Q29uZmlnRmllbGRzLCByZXNvbHZlSG9zdCwgcmVzb2x2ZU1vZGVsLCBnZXREZXZpY2VTY2hlbWEsIHR5cGUgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zLCBVcGRhdGVWYXJpYWJsZVZhbHVlcyB9IGZyb20gJy4vdmFyaWFibGVzLmpzJ1xuaW1wb3J0IHsgVXBncmFkZVNjcmlwdHMgfSBmcm9tICcuL3VwZ3JhZGVzLmpzJ1xuaW1wb3J0IHsgVXBkYXRlQWN0aW9ucyB9IGZyb20gJy4vYWN0aW9ucy5qcydcbmltcG9ydCB7IFVwZGF0ZUZlZWRiYWNrcyB9IGZyb20gJy4vZmVlZGJhY2tzLmpzJ1xuaW1wb3J0IHsgU3RDb250cm9sbGVyIH0gZnJvbSAnLi9zdGNvbnRyb2xsZXIuanMnXG5pbXBvcnQgdHlwZSB7IERldmljZUluZm8gfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ01vZHVsZUluc3RhbmNlJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlVHlwZXMgPSBJbnN0YW5jZVR5cGVzICYge1xuXHRjb25maWc6IE1vZHVsZUNvbmZpZ1xufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNb2R1bGVJbnN0YW5jZSBleHRlbmRzIEluc3RhbmNlQmFzZTxNb2R1bGVUeXBlcz4ge1xuXHRjb25maWchOiBNb2R1bGVDb25maWcgLy8gU2V0dXAgaW4gaW5pdCgpXG5cdHN0Q29udHJvbGxlciE6IFN0Q29udHJvbGxlclxuXG5cdC8qKiBDYWNoZWQgZGlzY292ZXJ5IHJlc3VsdHMgXHUyMDE0IHBhc3NlZCBpbnRvIGdldENvbmZpZ0ZpZWxkcygpIHNvIHRoZSBVSVxuXHQgKiAgY2FuIHNob3cgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIGRyb3Bkb3duIG9uIHN1YnNlcXVlbnQgY29uZmlnIG9wZW5zLiAqL1xuXHRwcml2YXRlIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXVxuXG5cdGNvbnN0cnVjdG9yKGludGVybmFsOiB1bmtub3duKSB7XG5cdFx0c3VwZXIoaW50ZXJuYWwpXG5cdH1cblxuXHRhc3luYyBpbml0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRpZiAoIXRoaXMuc3RDb250cm9sbGVyKSB7XG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlciA9IG5ldyBTdENvbnRyb2xsZXIoKVxuXHRcdH1cblx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5PaylcblxuXHRcdC8vIFJ1biBkaXNjb3ZlcnkgdG8gcG9wdWxhdGUgdGhlIGRldmljZSBsaXN0IEZJUlNUXG5cdFx0dGhpcy5kaXNjb3ZlcmVkRGV2aWNlcyA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLmRpc2NvdmVyRGV2aWNlcygpXG5cdFx0aWYgKHRoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRsb2dnZXIud2FybignTm8gZGV2aWNlcyBkaXNjb3ZlcmVkJylcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYERpc2NvdmVyZWQgJHt0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aH0gZGV2aWNlKHMpOmApXG5cdFx0XHRmb3IgKGNvbnN0IGQgb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtIE1vZGVsICR7ZC5tb2RlbH0gJHtkLm1hbnVmYWN0dXJlciA/PyAnJ30gQCAke2QuaXB9YClcblx0XHRcdH1cblxuXHRcdFx0Ly8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgZnJvbSBlYWNoIGRpc2NvdmVyZWQgZGV2aWNlIHZpYSBTdHVkaW8tVCBwcm90b2NvbFxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNvbnN0IGZpcm13YXJlID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2UuaXApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9IGZpcm13YXJlXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSAke2RldmljZS5pcH06IEZpcm13YXJlICR7ZmlybXdhcmV9LCBEYW50ZSAke2RldmljZS5kYW50ZUZpcm13YXJlfWApXG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgICAtICR7ZGV2aWNlLmlwfTogRmFpbGVkIHRvIGdldCBmaXJtd2FyZTogJHtlfWApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9ICdVbmtub3duJ1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gTG9hZCBkZXZpY2Ugc2NoZW1hIGFuZCBzeW5jIHRvIGNvbnRyb2xsZXIgZm9yIG1lc3NhZ2UgZGVjb2Rpbmdcblx0XHQvLyBVc2UgcmVzb2x2ZU1vZGVsIHRvIGF1dG8tZGV0ZWN0IG1vZGVsIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaWYgc2VsZWN0ZWRcblx0XHRjb25zdCBlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIFdpcmUgZmVlZGJhY2sgY2FsbGJhY2sgc28gc3RDb250cm9sbGVyIGNhbiB0cmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZXNcblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRGZWVkYmFja0NhbGxiYWNrKChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHtcblx0XHRcdHRoaXMuY2hlY2tGZWVkYmFja3MoZmVlZGJhY2tJZClcblx0XHR9KVxuXG5cdFx0Ly8gTk9XIHVwZGF0ZSBhY3Rpb25zL2ZlZWRiYWNrcy92YXJpYWJsZXMgYWZ0ZXIgZGlzY292ZXJ5IGFuZCBtb2RlbCByZXNvbHV0aW9uXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKCkgLy8gU2V0IGluaXRpYWwgdmFyaWFibGUgdmFsdWVzIGZyb20gZGlzY292ZXJlZCBkZXZpY2VcblxuXHRcdC8vIEZldGNoIGluaXRpYWwgc2V0dGluZ3Mgc3RhdGUgZnJvbSB0aGUgY29uZmlndXJlZCBkZXZpY2Ugb25seVxuXHRcdGNvbnN0IHRhcmdldEhvc3QgPSB0aGlzLmhvc3Rcblx0XHRpZiAodGFyZ2V0SG9zdCkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKHRhcmdldEhvc3QpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZ2V0IGFsbCBzZXR0aW5ncyBmcm9tICR7dGFyZ2V0SG9zdH06ICR7ZX1gKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdC8vIFdoZW4gbW9kdWxlIGdldHMgZGVsZXRlZFxuXHRhc3luYyBkZXN0cm95KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuc3RDb250cm9sbGVyPy5jbG9zZSgpXG5cdFx0bG9nZ2VyLmRlYnVnKCdkZXN0cm95Jylcblx0fVxuXG5cdGFzeW5jIGNvbmZpZ1VwZGF0ZWQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRjb25zdCBwcmV2aW91c0hvc3QgPSB0aGlzLmhvc3Rcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGNvbnN0IGVmZmVjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKGNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIFJlYnVpbGQgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgdmFyaWFibGVzIHdoZW4gY29uZmlnIGNoYW5nZXMgKG1vZGVsIG9yIGRldmljZSBzZWxlY3Rpb24gY2hhbmdlZClcblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKSAvLyBVcGRhdGUgdmFyaWFibGUgdmFsdWVzIHdoZW4gY29uZmlnIGNoYW5nZXNcblxuXHRcdC8vIElmIHRoZSBob3N0IGNoYW5nZWQsIHJlcXVlc3Qgc2V0dGluZ3MgZnJvbSB0aGUgbmV3IGRldmljZVxuXHRcdGNvbnN0IG5ld0hvc3QgPSB0aGlzLmhvc3Rcblx0XHRpZiAobmV3SG9zdCAmJiBuZXdIb3N0ICE9PSBwcmV2aW91c0hvc3QpIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhuZXdIb3N0KVxuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIGdldCBhbGwgc2V0dGluZ3MgZnJvbSAke25ld0hvc3R9OiAke2V9YClcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQvKiogTG9hZHMgdGhlIGRldmljZSBKU09OIGZvciB0aGUgZ2l2ZW4gbW9kZWwgYW5kIHB1c2hlcyBpdCB0byB0aGUgY29udHJvbGxlci4gKi9cblx0cHJpdmF0ZSBzeW5jTW9kZWwobW9kZWw6IHN0cmluZyk6IHZvaWQge1xuXHRcdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0XHRpZiAoIXNjaGVtYSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYE1vZGVsIFwiJHttb2RlbH1cIiBub3QgZm91bmQgaW4gZGV2aWNlIHNjaGVtYXNgKVxuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0TW9kZWwobW9kZWwsIFtdLCB0cnVlKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Y29uc3QgYWN0aW9ucyA9IEFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkgPyBzY2hlbWEuY21kU2NoZW1hIDogW11cblx0XHRjb25zdCByZWZyZXNoQWZ0ZXJDb21tYW5kID0gc2NoZW1hLnJlZnJlc2hBZnRlckNvbW1hbmQgPz8gdHJ1ZSAvLyBEZWZhdWx0IHRvIHRydWUgaWYgbm90IHNwZWNpZmllZFxuXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0TW9kZWwobW9kZWwsIGFjdGlvbnMsIHJlZnJlc2hBZnRlckNvbW1hbmQpXG5cdFx0aWYgKGFjdGlvbnMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTm8gYWN0aW9ucyBmb3VuZCBmb3IgbW9kZWwgXCIke21vZGVsfVwiIFx1MjAxNCBzZXR0aW5ncyBkZWNvZGluZyB3aWxsIHVzZSByYXcgSURzYClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKFxuXHRcdFx0XHRgTG9hZGVkICR7YWN0aW9ucy5sZW5ndGh9IGFjdGlvbnMgZm9yIG1vZGVsIFwiJHttb2RlbH1cIiwgc2VjdGlvbmVkPSR7c2NoZW1hLnNlY3Rpb25lZH0sIHJlZnJlc2hBZnRlckNvbW1hbmQ9JHtyZWZyZXNoQWZ0ZXJDb21tYW5kfWAsXG5cdFx0XHQpXG5cdFx0fVxuXHR9XG5cblx0Ly8gUmV0dXJuIGNvbmZpZyBmaWVsZHMgZm9yIHdlYiBjb25maWcgXHUyMDE0IGluY2x1ZGUgZGlzY292ZXJlZCBkZXZpY2VzIHNvIHRoZVxuXHQvLyBkcm9wZG93biBpcyBwb3B1bGF0ZWQuIENhbGxlZCBieSBDb21wYW5pb24gb24gZmlyc3QgbG9hZCBhbmQgYWZ0ZXJcblx0Ly8gc2V0Q29uZmlnU2NoZW1hVmVyc2lvbigpIHRyaWdnZXJzIGEgcmVmcmVzaC5cblx0Z2V0Q29uZmlnRmllbGRzKCk6IFNvbWVDb21wYW5pb25Db25maWdGaWVsZFtdIHtcblx0XHRyZXR1cm4gR2V0Q29uZmlnRmllbGRzKHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdH1cblxuXHQvKiogUmV0dXJucyB0aGUgZWZmZWN0aXZlIGhvc3QgSVAsIHByZWZlcnJpbmcgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIHNlbGVjdGlvbi4gKi9cblx0Z2V0IGhvc3QoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gcmVzb2x2ZUhvc3QodGhpcy5jb25maWcpXG5cdH1cblxuXHQvKiogUmV0dXJucyBkaXNjb3ZlcmVkIGRldmljZXMgZm9yIHVzZSBpbiBhY3Rpb25zL2NvbmZpZyAqL1xuXHRnZXQgZGV2aWNlcygpOiBEZXZpY2VJbmZvW10ge1xuXHRcdHJldHVybiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzXG5cdH1cblxuXHR1cGRhdGVBY3Rpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZUFjdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZUZlZWRiYWNrcygpOiB2b2lkIHtcblx0XHRVcGRhdGVGZWVkYmFja3ModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlVmFyaWFibGVWYWx1ZXMoKTogdm9pZCB7XG5cdFx0VXBkYXRlVmFyaWFibGVWYWx1ZXModGhpcylcblx0fVxufVxuXG5leHBvcnQgeyBVcGdyYWRlU2NyaXB0cyB9XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7OztBQWtCQSxJQUFNLHFCQUFrQyxDQUFDLFFBQVEsT0FBTyxZQUFXO0FBRWxFLFVBQVEsSUFBSSxJQUFJLE1BQU0sWUFBVyxDQUFFLElBQUksU0FBUyxLQUFLLE1BQU0sTUFBTSxFQUFFLElBQUksT0FBTyxFQUFFO0FBQ2pGO0FBRUEsU0FBUyxVQUFVLFFBQTRCLE9BQWlCLFNBQWU7QUFDOUUsUUFBTSxPQUFPLE9BQU8sT0FBTyxxQkFBcUIsYUFBYSxPQUFPLG1CQUFtQjtBQUN2RixPQUFLLFFBQVEsT0FBTyxPQUFPO0FBQzVCO0FBT00sU0FBVSxtQkFBbUIsUUFBZTtBQUNqRCxTQUFPO0lBQ04sT0FBTyxDQUFDLFlBQW9CLFVBQVUsUUFBUSxTQUFTLE9BQU87SUFDOUQsTUFBTSxDQUFDLFlBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU87SUFDNUQsTUFBTSxDQUFDLFlBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU87SUFDNUQsT0FBTyxDQUFDLFlBQW9CLFVBQVUsUUFBUSxTQUFTLE9BQU87O0FBRWhFOzs7QUNUTSxTQUFVLFlBQVksTUFBVztBQUV2Qzs7O0FDaENBLFNBQVMsb0JBQW9CO0FBMkV2QixJQUFPLHNCQUFQLGNBQW1DLGFBQW1DO0VBQ2xFO0VBQ0E7RUFFVCxJQUFXLFdBQVE7QUFDbEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFDQSxJQUFXLGFBQVU7QUFDcEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFFQSxJQUFZLGFBQVU7QUFDckIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtBQUNuRCxhQUFPLEtBQUs7SUFDYixPQUFPO0FBQ04sYUFBTztJQUNSO0VBQ0Q7RUFFQSxTQUF1RTtFQUV2RSxZQUFZLFNBQXlDLFNBQStCO0FBQ25GLFVBQUs7QUFFTCxTQUFLLFdBQVc7QUFDaEIsU0FBSyxXQUFXLEVBQUUsR0FBRyxRQUFPO0VBQzdCO0VBRUEsS0FBSyxNQUFjLFVBQW1CLFVBQXFCO0FBQzFELFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0seUJBQXlCO0FBQzdGLFlBQVEsS0FBSyxRQUFRO01BQ3BCLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxvQ0FBb0M7TUFDckQsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLHlCQUF5QjtNQUMxQyxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sbUJBQW1CO01BQ3BDLEtBQUs7QUFDSjtNQUNEO0FBQ0Msb0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGNBQU0sSUFBSSxNQUFNLHNCQUFzQjtJQUN4QztBQUVBLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsYUFBYSxRQUFRO0FBRTNDLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsUUFBUSxLQUFLLFNBQVM7TUFDdEIsWUFBWTs7S0FFWixFQUNBLEtBQ0EsQ0FBQyxhQUFZO0FBQ1osV0FBSyxTQUFTLEVBQUUsWUFBWSxNQUFNLFNBQVE7QUFDMUMsV0FBSyxTQUFTLHdCQUF3QixJQUFJLFVBQVUsSUFBSTtBQUN4RCxXQUFLLEtBQUssV0FBVztJQUN0QixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUztBQUNkLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEsTUFBTSxVQUFxQjtBQUMxQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0lBRXBELE9BQU87QUFDTixjQUFRLEtBQUssUUFBUTtRQUNwQixLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9DQUFvQztRQUNyRCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0JBQW9CO1FBQ3JDO0FBQ0Msc0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGdCQUFNLElBQUksTUFBTSxzQkFBc0I7TUFDeEM7SUFDRDtBQUVBLFVBQU0sV0FBVyxLQUFLLE9BQU87QUFDN0IsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxTQUFTLFFBQVE7QUFFdkMsU0FBSyxTQUNILHFCQUFxQjtNQUNyQjtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLE9BQU87SUFDbEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQVdBLEtBQ0MsY0FDQSxjQUNBLGlCQUNBLGdCQUNBLFNBQ0EsVUFBcUI7QUFFckIsUUFBSSxPQUFPLGlCQUFpQjtBQUFVLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUN6RSxRQUFJLE9BQU8sb0JBQW9CLFVBQVU7QUFDeEMsVUFBSSxPQUFPLG1CQUFtQixZQUFZLE9BQU8sWUFBWTtBQUFVLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUMxRyxVQUFJLGFBQWEsVUFBYSxPQUFPLGFBQWE7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFakcsWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLGNBQWMsZUFBZTtBQUM5RSxXQUFLLFdBQVcsUUFBUSxnQkFBZ0IsU0FBUyxRQUFRO0lBQzFELFdBQVcsT0FBTyxvQkFBb0IsVUFBVTtBQUMvQyxVQUFJLG1CQUFtQixVQUFhLE9BQU8sbUJBQW1CO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRTdHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxHQUFHLE1BQVM7QUFDN0QsV0FBSyxXQUFXLFFBQVEsY0FBYyxpQkFBaUIsY0FBYztJQUN0RSxPQUFPO0FBQ04sWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0lBQ3BDO0VBQ0Q7RUFFQSxlQUNDLGNBQ0EsUUFDQSxRQUEwQjtBQUUxQixRQUFJO0FBQ0osUUFBSSxPQUFPLGlCQUFpQixVQUFVO0FBQ3JDLGVBQVMsT0FBTyxLQUFLLGNBQWMsT0FBTztJQUMzQyxXQUFXLE9BQU8sU0FBUyxZQUFZLEdBQUc7QUFDekMsZUFBUztJQUNWLFdBQVcsTUFBTSxRQUFRLFlBQVksR0FBRztBQUV2QyxhQUFPLE9BQU8sS0FBSyxZQUFZO0lBQ2hDLE9BQU87QUFDTixlQUFTLE9BQU8sS0FBSyxhQUFhLFFBQVEsYUFBYSxZQUFZLGFBQWEsVUFBVTtJQUMzRjtBQUVBLFdBQU8sT0FBTyxTQUFTLFFBQVEsV0FBVyxTQUFZLFNBQVMsU0FBUyxNQUFTO0VBQ2xGO0VBRUEsV0FBVyxRQUFnQixNQUFjLFNBQWlCLFVBQXFCO0FBQzlFLFFBQUksQ0FBQyxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFFekYsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixVQUFVLEtBQUssT0FBTztNQUN0QixTQUFTO01BRVQ7TUFDQTtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osaUJBQVU7SUFDWCxHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEscUJBQXFCLFNBQStCO0FBQ25ELFFBQUk7QUFDSCxXQUFLLEtBQUssV0FBVyxRQUFRLFNBQVMsUUFBUSxNQUFNO0lBQ3JELFNBQVMsSUFBSTtJQUViO0VBQ0Q7RUFDQSxtQkFBbUIsT0FBWTtBQUM5QixTQUFLLFNBQVM7QUFFZCxVQUFNLGFBQWEsS0FBSztBQUN4QixRQUFJO0FBQVksV0FBSyxTQUFTLHdCQUF3QixPQUFPLFdBQVcsUUFBUTtBQUVoRixRQUFJO0FBQ0gsV0FBSyxLQUFLLFNBQVMsS0FBSztJQUN6QixTQUFTLElBQUk7SUFFYjtFQUNEOzs7O0FDOVBLLFNBQVUsa0JBQW1ELEtBQVk7QUFDOUUsUUFBTSxPQUFPO0FBQ2IsU0FBTyxDQUFDLENBQUMsUUFBUSxPQUFPLFNBQVMsWUFBWSxPQUFPLEtBQUssT0FBTyxZQUFZLEtBQUssdUJBQXVCO0FBQ3pHOzs7QUM2Qk0sSUFBZ0IsZUFBaEIsTUFBNEI7RUFDeEI7RUFDQTtFQUVBO0VBRVQsSUFBVyxLQUFFO0FBQ1osV0FBTyxLQUFLLFNBQVM7RUFDdEI7RUFFQSxJQUFXLGtCQUFlO0FBQ3pCLFdBQU8sS0FBSztFQUNiOzs7OztFQU1BLElBQVcsUUFBSztBQUNmLFdBQU8sS0FBSyxTQUFTO0VBQ3RCOzs7O0VBS0EsWUFBWSxVQUFpQjtBQUM1QixRQUFJLENBQUMsa0JBQTZCLFFBQVEsS0FBSyxDQUFDLFNBQVM7QUFDeEQsWUFBTSxJQUFJLE1BQ1QsbUdBQW1HO0FBR3JHLFNBQUssV0FBVztBQUVoQixTQUFLLFVBQVUsbUJBQWtCO0FBRWpDLFNBQUssd0JBQXdCLEtBQUssc0JBQXNCLEtBQUssSUFBSTtBQUVqRSxTQUFLLFdBQVc7TUFDZiwyQkFBMkI7TUFDM0Isd0JBQXdCOztBQUd6QixTQUFLLElBQUksU0FBUyxjQUFjO0VBQ2pDO0VBK0JBLFdBQVcsV0FBNEMsWUFBaUM7QUFDdkYsU0FBSyxTQUFTLFdBQVcsV0FBVyxVQUFVO0VBQy9DOzs7OztFQXVCQSxxQkFBcUIsU0FBeUQ7QUFDN0UsU0FBSyxTQUFTLHFCQUFxQixPQUFPO0VBQzNDOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7OztFQU9BLHFCQUNDLFdBQ0EsU0FBOEM7QUFFOUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXLE9BQU87RUFDdEQ7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFFBQUksTUFBTSxRQUFRLFNBQVM7QUFBRyxZQUFNLElBQUksTUFBTSx3REFBd0Q7QUFFdEcsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7OztFQU1BLGtCQUFrQixRQUF1QztBQUN4RCxTQUFLLFNBQVMsa0JBQWtCLE1BQU07RUFDdkM7Ozs7OztFQU9BLGlCQUFtQyxZQUFhO0FBQy9DLFdBQU8sS0FBSyxTQUFTLGlCQUFpQixVQUFVO0VBQ2pEOzs7O0VBS0Esb0JBQWlCO0FBQ2hCLFNBQUssU0FBUyxrQkFBaUI7RUFDaEM7Ozs7Ozs7RUFRQSxlQUNDLGlCQUNHLGVBQW1EO0FBRXRELFNBQUssU0FBUyxlQUFlLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQztFQUM5RDs7Ozs7RUFNQSxzQkFBc0IsYUFBcUI7QUFDMUMsU0FBSyxTQUFTLG1CQUFtQixXQUFXO0VBQzdDOzs7Ozs7RUFPQSxvQkFBb0IsV0FBbUI7QUFDdEMsU0FBSyxTQUFTLGlCQUFpQixTQUFTO0VBQ3pDOzs7Ozs7RUFNQSxzQkFBc0IsV0FBbUI7QUFDeEMsU0FBSyxTQUFTLG1CQUFtQixTQUFTO0VBQzNDOzs7Ozs7RUFPQSx3QkFBd0IsYUFBcUI7QUFDNUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXO0VBQy9DOzs7Ozs7RUFPQSxhQUFhLFFBQWlDLGNBQXFCO0FBQ2xFLFNBQUssU0FBUyxhQUFhLFFBQVEsWUFBWTtFQUNoRDs7Ozs7Ozs7RUFTQSxRQUFRLE1BQWMsTUFBY0EsT0FBYyxNQUFzQjtBQUN2RSxTQUFLLFNBQVMsUUFBUSxNQUFNLE1BQU1BLE9BQU0sSUFBSTtFQUM3Qzs7Ozs7Ozs7Ozs7RUFZQSxhQUFhLFFBQXdCLFNBQXVCO0FBQzNELFNBQUssU0FBUyxhQUFhLFFBQVEsV0FBVyxJQUFJO0VBQ25EOzs7Ozs7RUFPQSxJQUFJLE9BQWlCLFNBQWU7QUFDbkMsWUFBUSxPQUFPO01BQ2QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRDtBQUNDLG9CQUFZLEtBQUs7QUFDakIsYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtJQUNGO0VBQ0Q7RUFZQSxzQkFDQyxlQUNBLFVBQXlDO0FBRXpDLFVBQU0sVUFBa0MsT0FBTyxrQkFBa0IsV0FBVyxFQUFFLE1BQU0sY0FBYSxJQUFLO0FBRXRHLFVBQU0sU0FBUyxJQUFJLG9CQUFvQixLQUFLLFVBQVUsT0FBTztBQUM3RCxRQUFJO0FBQVUsYUFBTyxHQUFHLFdBQVcsUUFBUTtBQUUzQyxXQUFPO0VBQ1I7Ozs7QUMvVUQsSUFBWTtDQUFaLFNBQVlDLGlCQUFjO0FBQ3pCLEVBQUFBLGdCQUFBLElBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFlBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLG1CQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxXQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxnQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsdUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHlCQUFBLElBQUE7QUFDRCxHQVZZLG1CQUFBLGlCQUFjLENBQUEsRUFBQTtBQWFwQixJQUFXO0NBQWpCLFNBQWlCQyxRQUFLO0FBRVIsRUFBQUEsT0FBQSxLQUFLO0FBQ0wsRUFBQUEsT0FBQSxXQUNaO0FBQ1ksRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxPQUNaO0FBQ1ksRUFBQUEsT0FBQSxjQUFjO0FBQ2QsRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxRQUFRO0FBQ1IsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxTQUFTO0FBQ1QsRUFBQUEsT0FBQSxnQkFBZ0I7QUFDaEIsRUFBQUEsT0FBQSxZQUFZO0FBQ1osRUFBQUEsT0FBQSxXQUNaO0FBQ0YsR0FsQmlCLFVBQUEsUUFBSyxDQUFBLEVBQUE7OztBQ2pCdEIsT0FBTyxRQUFRO0FBQ2YsT0FBTyxVQUFVO0FBR2pCLElBQU0sU0FBUyxtQkFBbUIsUUFBUTtBQXNCMUMsU0FBUyx1QkFBb0I7QUFDNUIsUUFBTSxjQUFjLEtBQUssS0FBSyxZQUFZLFNBQVMsWUFBWTtBQUMvRCxRQUFNLGVBQWUsS0FBSyxLQUFLLFlBQVksU0FBUyxXQUFXO0FBRy9ELE1BQUksR0FBRyxXQUFXLFdBQVcsR0FBRztBQUMvQixXQUFPLE1BQU0seUJBQXlCLFdBQVcsRUFBRTtBQUNuRCxXQUFPO0VBQ1I7QUFHQSxNQUFJLEdBQUcsV0FBVyxZQUFZLEdBQUc7QUFDaEMsV0FBTyxLQUFLLHFEQUFxRCxZQUFZLEVBQUU7QUFDL0UsV0FBTztFQUNSO0FBR0EsUUFBTSxXQUFXOztNQUEwQyxXQUFXO01BQVMsWUFBWTs7QUFDM0YsU0FBTyxNQUFNLFFBQVE7QUFDckIsUUFBTSxJQUFJLE1BQU0sUUFBUTtBQUN6QjtBQUdBLElBQU0sZ0JBQWdCLHFCQUFvQjtBQUcxQyxJQUFJLHFCQUFpRDtBQU0vQyxTQUFVLG1CQUFnQjtBQUMvQixTQUFPO0FBQ1I7QUFNQSxTQUFTLG9CQUFpQjtBQUN6QixRQUFNLFVBQStCLENBQUE7QUFDckMsTUFBSTtBQUNILFVBQU0sUUFBUSxHQUFHLFlBQVksYUFBYSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxPQUFPLENBQUM7QUFFN0UsZUFBVyxLQUFLLE9BQU87QUFDdEIsWUFBTSxXQUFXLEtBQUssS0FBSyxlQUFlLENBQUM7QUFDM0MsWUFBTSxPQUFPLEtBQUssTUFBTSxHQUFHLGFBQWEsVUFBVSxNQUFNLENBQUM7QUFDekQsVUFBSSxNQUFNLE9BQU87QUFDaEIsZ0JBQVEsT0FBTyxLQUFLLEtBQUssQ0FBQyxJQUFJO01BQy9CO0lBQ0Q7QUFFQSxXQUFPLE1BQU0sVUFBVSxPQUFPLEtBQUssT0FBTyxFQUFFLE1BQU0sNEJBQTRCO0VBQy9FLFNBQVMsR0FBRztBQUNYLFdBQU8sTUFBTSxrQ0FBa0MsQ0FBQyxFQUFFO0VBQ25EO0FBQ0EsU0FBTztBQUNSO0FBTU0sU0FBVSxtQkFBZ0I7QUFDL0IsTUFBSSxDQUFDLG9CQUFvQjtBQUN4Qix5QkFBcUIsa0JBQWlCO0VBQ3ZDO0FBQ0EsU0FBTztBQUNSO0FBTU0sU0FBVSxnQkFBZ0IsT0FBYTtBQUM1QyxRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFNBQU8sUUFBUSxLQUFLO0FBQ3JCO0FBTU0sU0FBVSxzQkFBbUI7QUFDbEMsU0FBTyxLQUFLLHVDQUF1QztBQUNuRCx1QkFBcUIsa0JBQWlCO0FBQ3ZDO0FBS0EsU0FBUyxzQkFBbUI7QUFDM0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxTQUFPLE9BQU8sS0FBSyxPQUFPLEVBQUUsS0FBSTtBQUNqQztBQUVNLFNBQVUsZ0JBQWdCLG9CQUFrQyxDQUFBLEdBQUU7QUFDbkUsUUFBTSxTQUFTLG9CQUFtQjtBQUtsQyxRQUFNLGdCQUFnQjtJQUNyQixFQUFFLElBQUksSUFBSSxPQUFPLFNBQVE7SUFDekIsR0FBRyxrQkFBa0IsSUFBSSxDQUFDLE9BQU87TUFDaEMsSUFBSSxFQUFFO01BQ04sT0FBTyxTQUFTLEVBQUUsS0FBSyxLQUFLLEVBQUUsRUFBRTtNQUMvQjs7QUFHSCxTQUFPOzs7O0lBSU47TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULFNBQVM7TUFDVCxTQUFTOzs7OztJQU1WO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxPQUFPLE1BQU07TUFDYixxQkFBcUI7TUFDckIsU0FBUzs7Ozs7SUFNVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTLE9BQU8sQ0FBQyxLQUFLO01BQ3RCLFNBQVMsT0FBTyxJQUFJLENBQUMsV0FBVztRQUMvQixJQUFJO1FBQ0osT0FBTyxTQUFTLEtBQUs7UUFDcEI7TUFDRixxQkFBcUI7TUFDckIsU0FBUzs7O0FBR1o7QUFNTSxTQUFVLFlBQVksUUFBb0I7QUFDL0MsU0FBTyxPQUFPLGtCQUFrQixPQUFPO0FBQ3hDO0FBTU0sU0FBVSxhQUFhLFFBQXNCLG1CQUErQjtBQUNqRixNQUFJLE9BQU8sZ0JBQWdCO0FBQzFCLFVBQU0sU0FBUyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sY0FBYztBQUMzRSxXQUFPLE1BQU0saUNBQWlDLE9BQU8sY0FBYyxvQkFBb0IsUUFBUSxTQUFTLE1BQU0sRUFBRTtBQUNoSCxRQUFJLFFBQVEsT0FBTztBQUNsQixhQUFPLE9BQU87SUFDZjtFQUNEO0FBQ0EsU0FBTyxNQUFNLDhDQUE4QyxPQUFPLFdBQVcsR0FBRztBQUNoRixTQUFPLE9BQU87QUFDZjs7O0FDeE1NLFNBQVUsMEJBQTBCLE1BQW9CO0FBQzdELE9BQUssdUJBQXVCO0lBQzNCLE9BQU8sRUFBRSxNQUFNLHNCQUFxQjtJQUNwQyxXQUFXLEVBQUUsTUFBTSx1Q0FBc0M7SUFDekQsY0FBYyxFQUFFLE1BQU0sc0JBQXFCO0lBQzNDLFVBQVUsRUFBRSxNQUFNLDBCQUF5QjtJQUMzQyxTQUFTLEVBQUUsTUFBTSxnQ0FBK0I7SUFDaEQsS0FBSyxFQUFFLE1BQU0scUJBQW9CO0lBQ2pDLElBQUksRUFBRSxNQUFNLG9CQUFtQjtHQUMvQjtBQUNGO0FBTU0sU0FBVSxxQkFBcUIsTUFBb0I7QUFFeEQsUUFBTSxjQUFjLEtBQUs7QUFDekIsUUFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sV0FBVztBQUU1RCxNQUFJLFFBQVE7QUFDWCxTQUFLLGtCQUFrQjtNQUN0QixPQUFPLE9BQU8sU0FBUztNQUN2QixXQUFXLE9BQU8sYUFBYTtNQUMvQixjQUFjLE9BQU8sZ0JBQWdCO01BQ3JDLFVBQVUsT0FBTyxnQkFBZ0I7TUFDakMsU0FBUyxPQUFPLGlCQUFpQjtNQUNqQyxLQUFLLE9BQU8sT0FBTztNQUNuQixJQUFJLE9BQU8sTUFBTTtLQUNqQjtFQUNGLE9BQU87QUFFTixTQUFLLGtCQUFrQjtNQUN0QixPQUFPLEtBQUssT0FBTyxlQUFlO01BQ2xDLFdBQVc7TUFDWCxjQUFjO01BQ2QsVUFBVTtNQUNWLFNBQVM7TUFDVCxLQUFLO01BQ0wsSUFBSTtLQUNKO0VBQ0Y7QUFDRDs7O0FDOUNPLElBQU0saUJBQStEOzs7Ozs7Ozs7Ozs7Ozs7QUNxQnJFLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sY0FBYztBQUNwQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxnQkFBZ0I7QUFDdEIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxhQUFhO0FBQ25CLElBQU0sdUJBQXVCO0FBQzdCLElBQU0sb0JBQW9CO0FBQzFCLElBQU0sZUFBZTtBQUNyQixJQUFNLG1CQUFtQjtBQUN6QixJQUFNLHNCQUFzQjtBQUM1QixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGNBQWM7QUFHckIsU0FBVSxlQUFlLE9BQWE7QUFDM0MsVUFBUSxPQUFPO0lBQ2QsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUjtBQUNDLGFBQU8sU0FBUyxNQUFNLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUM7RUFDckQ7QUFDRDtBQVFNLFNBQVUsY0FDZixPQUNBLE9BQ0EsV0FDQSxPQUF1QjtBQUV2QixRQUFNLE1BQU0sT0FBTyxVQUFVLFdBQVcsTUFBTSxTQUFTLEVBQUUsSUFBSTtBQUM3RCxRQUFNLEtBQUssT0FBTyxjQUFjLFdBQVcsVUFBVSxTQUFTLEVBQUUsSUFBSTtBQUVwRSxNQUFJLFVBQVUsUUFBVztBQUN4QixVQUFNLEtBQUssT0FBTyxVQUFVLFdBQVcsTUFBTSxTQUFTLEVBQUUsSUFBSTtBQUM1RCxXQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUksRUFBRTtFQUNuQztBQUVBLFNBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDN0I7QUFTTSxTQUFVLE1BQU0sT0FBZSxZQUFZLEdBQUM7QUFDakQsU0FBTyxLQUFLLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxXQUFXLEdBQUcsQ0FBQztBQUN4RDtBQU9NLFNBQVUsV0FBVyxPQUF3QjtBQUNsRCxTQUFPLEtBQUssTUFBTSxLQUFLLEtBQUssRUFDMUIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxDQUFDO0FBQ1g7QUFTTSxTQUFVLGVBQWUsR0FBVyxHQUFXLEdBQVM7QUFDN0QsU0FBTyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsRUFDakIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxFQUNQLFlBQVcsQ0FBRTtBQUNoQjtBQVFNLFNBQVUsZUFBZSxJQUFVO0FBQ3hDLFFBQU0sQ0FBQyxPQUFPLFVBQVUsS0FBSyxJQUFJLEdBQUcsTUFBTSxHQUFHO0FBQzdDLFNBQU87SUFDTjtJQUNBLE9BQU8sU0FBUyxVQUFVLEVBQUU7SUFDNUIsUUFBUSxTQUFTLE9BQU8sRUFBRTs7QUFFNUI7QUFVTSxTQUFVLGNBQWMsUUFBZ0IsUUFBYztBQUMzRCxRQUFNLEtBQUssU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUNqRCxRQUFNLEtBQUssU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUNqRCxNQUFJLE9BQU8sTUFBTSxFQUFFLEtBQUssT0FBTyxNQUFNLEVBQUU7QUFBRyxXQUFPO0FBQ2pELFNBQU8sS0FBSyxJQUFJLEtBQUssRUFBRTtBQUN4QjtBQVNNLFNBQVUscUJBQ2YsWUFBK0I7QUFFL0IsUUFBTSxhQUFrRSxDQUFBO0FBQ3hFLGFBQVcsQ0FBQyxPQUFPLElBQUksS0FBSyxPQUFPLFFBQVEsVUFBVSxHQUFHO0FBQ3ZELGVBQVcsS0FBSyxJQUFJO01BQ25CLE9BQU8sS0FBSztNQUNaLFdBQVcsTUFBTSxRQUFRLEtBQUssU0FBUyxJQUFJLEtBQUssWUFBWSxDQUFBOztFQUU5RDtBQUNBLFNBQU87QUFDUjtBQVlNLFNBQVUscUJBQ2YsU0FDQSxPQUNBLE9BQ0EsV0FBaUI7QUFFakIsUUFBTSxTQUFTLFFBQVEsS0FBSztBQUM1QixNQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sUUFBUSxPQUFPLFNBQVM7QUFBRyxXQUFPO0FBR3hELE1BQUksU0FBUyxPQUFPLFVBQVUsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFHdkYsTUFBSSxDQUFDLFFBQVE7QUFDWixhQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVTtBQUN6QyxVQUFJLEVBQUUsV0FBVztBQUFPLGVBQU87QUFDL0IsWUFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUNwRSxVQUFJLENBQUMsYUFBYTtBQUFTLGVBQU87QUFFbEMsWUFBTSxTQUFTLFlBQVksRUFBRTtBQUM3QixhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sTUFBTTtJQUM1RCxDQUFDO0VBQ0Y7QUFFQSxTQUFPO0FBQ1I7OztBQ3RNQSxTQUFTLFlBQVksR0FBTTtBQUMxQixRQUFNLE9BQU87SUFDWixNQUFNLEVBQUU7SUFDUixJQUFJLEVBQUU7SUFDTixPQUFPLEVBQUU7SUFDVCxTQUFTLEVBQUU7SUFDWCxTQUFTLEVBQUU7O0FBR1osVUFBUSxFQUFFLE1BQU07SUFDZixLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxDQUFBLEVBQUU7SUFFM0MsS0FBSztBQUNKLGFBQU87UUFDTixHQUFHO1FBQ0gsS0FBSyxFQUFFO1FBQ1AsS0FBSyxFQUFFO1FBQ1AsTUFBTSxFQUFFLFFBQVE7UUFDaEIsT0FBTzs7SUFHVCxLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxNQUFLO0lBRTlDLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMO0FBQ0MsYUFBTztFQUNUO0FBQ0Q7QUFNTSxTQUFVLGVBQVk7QUFDM0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxRQUFNLFVBQXNDLENBQUE7QUFFNUMsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxLQUFLLFdBQVc7QUFDMUIsWUFBTSxXQUFXLGNBQWMsT0FBTyxFQUFFLFFBQVEsRUFBRSxFQUFFO0FBRXBELFlBQU0sV0FBVyxFQUFFLFdBQVcsQ0FBQSxHQUFJLElBQUksV0FBVztBQUVqRCxZQUFNLFNBQW9DO1FBQ3pDLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxJQUFJO1FBQy9CO1FBQ0EsVUFBVSxZQUFXO1FBRXJCOztBQUdELGNBQVEsUUFBUSxJQUFJO0lBQ3JCO0VBQ0Q7QUFFQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLGlCQUFjO0FBQzdCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsUUFBTSxZQUEwQyxDQUFBO0FBRWhELGFBQVcsQ0FBQyxPQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ3RELFVBQU0sWUFBWSxPQUFPO0FBQ3pCLFFBQUksQ0FBQyxNQUFNLFFBQVEsU0FBUztBQUFHO0FBRS9CLGVBQVcsV0FBVyxXQUFXO0FBQ2hDLFlBQU0saUJBQWlCLGNBQWMsT0FBTyxRQUFRLFFBQVEsUUFBUSxFQUFFO0FBR3RFLFlBQU0sY0FBYyxRQUFRLFdBQVcsQ0FBQSxHQUFJLElBQUksV0FBVztBQUcxRCxZQUFNLGVBQWUsV0FBVyxPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUd2RSxtQkFBYSxLQUFLO1FBQ2pCLE1BQU07UUFDTixJQUFJO1FBQ0osT0FBTztRQUNQLFNBQVM7UUFDVCxTQUFTO09BQ1Q7QUFHRCxZQUFNLGdCQUFxQjtRQUMxQixNQUFNO1FBQ04sTUFBTSxTQUFTLEtBQUssS0FBSyxRQUFRLElBQUk7UUFDckMsU0FBUztRQUNULFVBQVUsTUFBSztBQUVkLGlCQUFPO1FBQ1I7O0FBR0QsZ0JBQVUsY0FBYyxJQUFJO0lBQzdCO0VBQ0Q7QUFFQSxTQUFPO0FBQ1I7OztBQzVIQSxPQUFPQyxXQUFVOzs7QUNMakIsT0FBT0MsU0FBUTtBQWdCZixJQUFNQyxVQUFTLG1CQUFtQixnQkFBZ0I7QUF5Q2xELFNBQVMsZUFBZSxPQUFhO0FBQ3BDLFFBQU0sU0FBUyxvQkFBSSxJQUFHO0FBQ3RCLE1BQUksWUFBWTtBQUVoQixNQUFJO0FBRUgsVUFBTSxPQUFPLGdCQUFnQixLQUFLO0FBQ2xDLFFBQUksQ0FBQyxNQUFNO0FBRVYsYUFBTyxFQUFFLFdBQVcsT0FBTTtJQUMzQjtBQUdBLGdCQUFZLEtBQUssYUFBYTtBQUc5QixlQUFXLFVBQVUsS0FBSyxhQUFhLENBQUEsR0FBSTtBQUMxQyxZQUFNLGlCQUFpQixPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQXdCLElBQUksU0FBUyxhQUFhO0FBQy9GLFVBQUksZ0JBQWdCO0FBRW5CLGVBQU8sSUFBSSxPQUFPLEVBQUU7QUFHcEIsY0FBTSxjQUFjLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBd0IsSUFBSSxPQUFPLE9BQU87QUFDcEYsWUFBSSxhQUFhLFNBQVM7QUFDekIscUJBQVcsVUFBVSxZQUFZLFNBQVM7QUFDekMsZ0JBQUksT0FBTyxPQUFPLE9BQU8sVUFBVTtBQUNsQyxxQkFBTyxJQUFJLE9BQU8sS0FBSyxPQUFPLEVBQUU7WUFDakM7VUFDRDtRQUNEO01BQ0Q7SUFDRDtFQUNELFNBQVMsTUFBTTtFQUVmO0FBRUEsU0FBTyxFQUFFLFdBQVcsT0FBTTtBQUMzQjtBQU1BLFNBQVMsc0JBQXNCLEtBQVc7QUFDekMsUUFBTSxXQUFXLElBQUksUUFBUSxPQUFPLEtBQUssVUFBVSxDQUFDO0FBQ3BELE1BQUksV0FBVztBQUFHLFVBQU0sSUFBSSxNQUFNLGlDQUFpQztBQUVuRSxRQUFNLGVBQWUsV0FBVztBQUNoQyxNQUFJLElBQUksWUFBWSxNQUFNLElBQU07QUFDL0IsVUFBTSxJQUFJLE1BQU0sdUNBQXVDLElBQUksWUFBWSxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUU7RUFDeEY7QUFFQSxTQUFPO0FBQ1I7QUFNQSxTQUFTLHVCQUF1QixPQUFlLFNBQXNCLG9CQUFJLElBQUcsR0FBRTtBQUM3RSxNQUFJLElBQUk7QUFDUixRQUFNLE1BQXVCLENBQUE7QUFFN0IsU0FBTyxJQUFJLE1BQU0sUUFBUTtBQUN4QixVQUFNLEtBQUssTUFBTSxDQUFDO0FBQ2xCLFFBQUksSUFBSSxLQUFLLE1BQU07QUFBUTtBQUczQixRQUFJLE9BQU8sSUFBSSxFQUFFLEtBQUssSUFBSSxJQUFJLE1BQU0sUUFBUTtBQUMzQyxVQUFJLEtBQUs7UUFDUixRQUFRO1FBQ1I7UUFDQSxZQUFZLENBQUMsTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLENBQUM7T0FDckQ7QUFDRCxXQUFLO0FBQ0w7SUFDRDtBQUVBLFFBQUksS0FBSyxFQUFFLFFBQVEsY0FBYyxJQUFJLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBRTtBQUNqRSxTQUFLO0VBQ047QUFFQSxTQUFPO0FBQ1I7QUFFTSxTQUFVLHlCQUF5QixLQUFhLE9BQWE7QUFDbEUsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0sNEJBQTRCO0VBQzdDO0FBRUEsUUFBTSxXQUFXLElBQUksTUFBTSxDQUFDO0FBQzVCLFFBQU0sUUFBUSxNQUFNO0FBQ3BCLFFBQU0sTUFBTSxRQUFRO0FBQ3BCLE1BQUksTUFBTSxJQUFJO0FBQVEsVUFBTSxJQUFJLE1BQU0sc0JBQXNCO0FBRTVELFFBQU0sRUFBRSxPQUFNLElBQUssZUFBZSxLQUFLO0FBQ3ZDLFNBQU8sdUJBQXVCLElBQUksU0FBUyxPQUFPLEdBQUcsR0FBRyxNQUFNO0FBQy9EO0FBTU0sU0FBVSw4QkFBOEIsS0FBYSxPQUFhO0FBQ3ZFLFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtFQUM3QztBQUdBLE1BQUksSUFBSSxVQUFVLHVCQUF1QixNQUFNLElBQUksTUFBTTtBQUN6RCxRQUFNLE1BQU0sSUFBSSxTQUFTO0FBQ3pCLFFBQU0sTUFBdUIsQ0FBQTtBQUc3QixRQUFNLEVBQUUsT0FBTSxJQUFLLGVBQWUsS0FBSztBQUd2QyxRQUFNLG9CQUFvQixDQUFDLGFBQWEsaUJBQWlCLFdBQVc7QUFFcEUsU0FBTyxJQUFJLElBQUksS0FBSztBQUNuQixVQUFNLFNBQVMsSUFBSSxDQUFDO0FBQ3BCLFVBQU0sZUFBZSxJQUFJLElBQUksQ0FBQztBQUU5QixVQUFNLGFBQWEsSUFBSSxJQUFJO0FBQzNCLFFBQUksYUFBYTtBQUFLO0FBR3RCLFVBQU0sV0FBVyxrQkFBa0IsU0FBUyxZQUFZO0FBRXhELFFBQUk7QUFDSixRQUFJO0FBQ0osUUFBSTtBQUVKLFFBQUksVUFBVTtBQUViLGNBQVEsSUFBSSxJQUFJLENBQUM7QUFDakIsZ0JBQVUsSUFBSSxJQUFJLENBQUM7QUFDbkIsVUFBSSxJQUFJO0lBQ1QsT0FBTztBQUVOLGdCQUFVLElBQUksSUFBSSxDQUFDO0FBQ25CLFVBQUksSUFBSTtJQUNUO0FBRUEsVUFBTSxPQUFPLElBQUk7QUFFakIsV0FBTyxJQUFJLElBQUksTUFBTTtBQUNwQixZQUFNLEtBQUssSUFBSSxDQUFDO0FBQ2hCLFVBQUk7QUFHSixVQUFJLE9BQU8sSUFBSSxFQUFFLEtBQUssSUFBSSxJQUFJLE1BQU07QUFDbkMscUJBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQztBQUNoRCxhQUFLO01BQ04sT0FBTztBQUNOLHFCQUFhLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQztBQUN4QixhQUFLO01BQ047QUFFQSxZQUFNLFVBQXlCO1FBQzlCLFFBQVE7UUFDUjtRQUNBOztBQUVELFVBQUksVUFBVSxRQUFXO0FBQ3hCLGdCQUFRLFFBQVE7TUFDakI7QUFDQSxVQUFJLEtBQUssT0FBTztJQUNqQjtBQUVBLFFBQUk7RUFDTDtBQUVBLFNBQU87QUFDUjtBQVdNLFNBQVUsc0JBQXNCLE9BQWUsS0FBVztBQUMvRCxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSxpQ0FBaUMsTUFBTSxTQUFTLEVBQUUsQ0FBQyxHQUFHO0VBQ3ZFO0FBQ0EsUUFBTSxFQUFFLFVBQVMsSUFBSyxlQUFlLEtBQUs7QUFDMUMsU0FBTyxZQUFZLDhCQUE4QixLQUFLLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxLQUFLO0FBQ25HO0FBTU0sU0FBVSxvQkFBb0IsU0FBd0IsU0FBbUI7QUFFOUUsTUFBSSxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFFBQVEsVUFBVSxFQUFFLE9BQU8sUUFBUSxFQUFFO0FBS25GLE1BQUksQ0FBQyxRQUFRO0FBQ1osVUFBTSxhQUFhLFFBQVEsS0FBSyxDQUFDLE1BQUs7QUFDckMsVUFBSSxFQUFFLFdBQVcsUUFBUTtBQUFRLGVBQU87QUFFeEMsWUFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUMvRCxVQUFJLENBQUMsYUFBYTtBQUFTLGVBQU87QUFFbEMsWUFBTSxnQkFBZ0IsUUFBUSxLQUFLLEVBQUU7QUFDckMsYUFBTyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGFBQWE7SUFDOUQsQ0FBQztBQUNELFFBQUksWUFBWTtBQUNmLGVBQVM7SUFDVjtFQUNEO0FBRUEsUUFBTSxTQUFTLE1BQU0sUUFBUSxNQUFNO0FBQ25DLFFBQU0sUUFBUSxNQUFNLFFBQVEsRUFBRTtBQUM5QixRQUFNLFNBQVMsV0FBVyxRQUFRLFVBQVU7QUFDNUMsUUFBTSxTQUNMLFFBQVEsV0FBVyxXQUFXLElBQzNCLGVBQWUsUUFBUSxXQUFXLENBQUMsR0FBRyxRQUFRLFdBQVcsQ0FBQyxHQUFHLFFBQVEsV0FBVyxDQUFDLENBQUMsSUFDbEYsUUFBUSxXQUFXLFdBQVcsSUFDN0IsUUFBUSxXQUFXLENBQUMsSUFDcEIsUUFBUSxXQUFXLEtBQUssR0FBRztBQUdoQyxRQUFNLFdBQVcsUUFBUSxVQUFVLFNBQVksT0FBTyxRQUFRLEtBQUssS0FBSztBQUN4RSxRQUFNLFNBQVMsT0FBTyxNQUFNLEdBQUcsUUFBUSxPQUFPLEtBQUssUUFBUSxNQUFNO0FBR2pFLE1BQUksUUFBUTtBQUNYLFFBQUksT0FBTyxPQUFPO0FBR2xCLFFBQUksUUFBUSxVQUFVLFFBQVc7QUFDaEMsYUFBTyxHQUFHLElBQUksTUFBTSxRQUFRLFFBQVEsQ0FBQztJQUN0QyxPQUVLO0FBQ0osWUFBTSxjQUFjLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUNwRSxVQUFJLGFBQWEsU0FBUztBQUN6QixjQUFNLGdCQUFnQixRQUFRLEtBQUssT0FBTztBQUMxQyxjQUFNLGNBQWMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxhQUFhO0FBQzFFLFlBQUksYUFBYTtBQUNoQixpQkFBTyxHQUFHLElBQUksSUFBSSxZQUFZLEtBQUs7UUFDcEM7TUFDRDtJQUNEO0FBR0EsVUFBTSxjQUFjLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sT0FBTztBQUNwRSxRQUFJLGFBQWEsV0FBVyxRQUFRLFdBQVcsV0FBVyxHQUFHO0FBQzVELFlBQU0sU0FBUyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsV0FBVyxDQUFDLENBQUM7QUFDN0UsVUFBSSxRQUFRO0FBQ1gsZUFBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssT0FBTyxLQUFLLEtBQUssTUFBTTtNQUN2RDtJQUNEO0FBQ0EsV0FBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssTUFBTTtFQUN0QztBQUdBLFNBQU8sR0FBRyxNQUFNO0FBQ2pCO0FBaUJNLFNBQVUsaUNBQ2YsT0FDQSxLQUFXO0FBRVgsUUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQU0sb0JBQW9CLFFBQVE7QUFHbEMsTUFBSSxzQkFBc0IsUUFBVztBQUNwQyxVQUFNLFdBQVcsb0JBQ2QsOEJBQThCLEtBQUssS0FBSyxJQUN4Qyx5QkFBeUIsS0FBSyxLQUFLO0FBQ3RDLFdBQU8sRUFBRSxVQUFVLG1CQUFtQixLQUFJO0VBQzNDO0FBR0EsTUFBSSxlQUFnQyxDQUFBO0FBQ3BDLE1BQUksb0JBQXFDLENBQUE7QUFFekMsTUFBSTtBQUNILG1CQUFlLHlCQUF5QixLQUFLLEtBQUs7RUFDbkQsU0FBUyxHQUFHO0FBQ1gsSUFBQUEsUUFBTyxNQUFNLHVCQUF1QixDQUFDLEVBQUU7RUFDeEM7QUFFQSxNQUFJO0FBQ0gsd0JBQW9CLDhCQUE4QixLQUFLLEtBQUs7RUFDN0QsU0FBUyxHQUFHO0FBQ1gsSUFBQUEsUUFBTyxNQUFNLDRCQUE0QixDQUFDLEVBQUU7RUFDN0M7QUFHQSxNQUFJLGtCQUFrQixTQUFTLGFBQWEsUUFBUTtBQUNuRCxJQUFBQSxRQUFPLEtBQUssNkNBQTZDLGtCQUFrQixNQUFNLFlBQVksYUFBYSxNQUFNLEdBQUc7QUFDbkgsV0FBTyxFQUFFLFVBQVUsbUJBQW1CLG1CQUFtQixLQUFJO0VBQzlELFdBQVcsYUFBYSxTQUFTLEdBQUc7QUFDbkMsSUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxhQUFhLE1BQU0saUJBQWlCLGtCQUFrQixNQUFNLEdBQUc7QUFDOUcsV0FBTyxFQUFFLFVBQVUsY0FBYyxtQkFBbUIsTUFBSztFQUMxRCxPQUFPO0FBRU4sSUFBQUEsUUFBTyxLQUFLLHVEQUF1RCxLQUFLLEVBQUU7QUFDMUUsV0FBTyxFQUFFLFVBQVUsQ0FBQSxHQUFJLG1CQUFtQixLQUFJO0VBQy9DO0FBQ0Q7QUFFTSxTQUFVLDRCQUE0QixPQUFlLEtBQVc7QUFDckUsUUFBTSxFQUFFLFVBQVMsSUFBSyxlQUFlLEtBQUs7QUFDMUMsU0FBTyxZQUFZLDhCQUE4QixLQUFLLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxLQUFLO0FBQ25HO0FBU0EsU0FBUyxtQkFBbUIsWUFBb0I7QUFDL0MsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUM1QixXQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLFVBQVUsU0FBUyxXQUFXLENBQUMsRUFBQztFQUM3RTtBQUVBLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsVUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLElBQUk7QUFDbEIsV0FBTztNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsTUFBTTtNQUNOLFNBQVMsZUFBZSxHQUFHLEdBQUcsQ0FBQzs7RUFFakM7QUFFQSxTQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLE9BQU8sU0FBUyxDQUFDLEdBQUcsVUFBVSxFQUFDO0FBQzVFO0FBTU0sU0FBVSw0QkFDZixXQUNBLFFBQ0EsV0FBc0M7QUFFdEMsUUFBTSxNQUFNLGdCQUFnQixTQUFTO0FBR3JDLE1BQUksQ0FBQyxJQUFJLFdBQVc7QUFDbkIsUUFBSSxZQUFZLENBQUE7RUFDakI7QUFHQSxRQUFNLGFBQWEsT0FBTyxPQUFPLFNBQVMsRUFDeEMsT0FBTyxDQUFDLE1BQU0sRUFBRSxVQUFVLFVBQVUsS0FBSyxFQUN6QyxLQUFLLENBQUMsR0FBRyxNQUFNLGNBQWMsVUFBVSxPQUFPLEVBQUUsS0FBSyxJQUFJLGNBQWMsVUFBVSxPQUFPLEVBQUUsS0FBSyxDQUFDO0FBRWxHLEVBQUFDLFFBQU8sS0FBSyxtQkFBbUIsVUFBVSxLQUFLLEVBQUU7QUFDaEQsRUFBQUEsUUFBTyxNQUFNLDZCQUE2QixXQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssSUFBSSxDQUFDLEVBQUU7QUFFckYsYUFBVyxFQUFFLFFBQVEsSUFBSSxXQUFVLEtBQU0sUUFBUTtBQUNoRCxRQUFJLFNBQVMsSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBRXpFLFFBQUksQ0FBQyxRQUFRO0FBRVosaUJBQVcsS0FBSyxZQUFZO0FBQzNCLGNBQU0sUUFBUSxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDekUsWUFBSSxPQUFPO0FBQ1YsbUJBQVMsZ0JBQWdCLEtBQUs7QUFDOUIsaUJBQU8sT0FBTyxHQUFHLE1BQU0sSUFBSSx5QkFBeUIsRUFBRSxLQUFLO0FBQzNELFVBQUFBLFFBQU8sS0FBSyxvQkFBb0IsTUFBTSxFQUFFLENBQUMsZUFBZSxFQUFFLEtBQUssRUFBRTtBQUNqRTtRQUNEO01BQ0Q7SUFDRDtBQUVBLFFBQUksQ0FBQyxRQUFRO0FBQ1osZUFBUztRQUNSO1FBQ0E7UUFDQSxNQUFNLG1CQUFtQixNQUFNLEVBQUUsRUFBRSxZQUFXLENBQUU7UUFDaEQsU0FBUyxDQUFDLG1CQUFtQixVQUFVLENBQUM7O0FBRXpDLE1BQUFBLFFBQU8sS0FBSywyQkFBMkIsTUFBTSxFQUFFLENBQUMsRUFBRTtJQUNuRCxPQUFPO0FBQ04sWUFBTSxNQUFNLE9BQU8sVUFBVSxDQUFDO0FBQzlCLFVBQUk7QUFBSyxZQUFJLFVBQVUsbUJBQW1CLFVBQVUsRUFBRTtJQUN2RDtBQUdBLFVBQU0sU0FBUyxJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLE9BQU8sVUFBVSxFQUFFLE9BQU8sT0FBTyxFQUFFO0FBQ3pGLFFBQUksQ0FBQztBQUFRLFVBQUksVUFBVSxLQUFLLE1BQU07RUFDdkM7QUFFQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLG9CQUFvQixVQUFrQixTQUFvQjtBQUN6RSxNQUFJO0FBRUgsVUFBTSxhQUFrQixFQUFFLE9BQU8sUUFBUSxNQUFLO0FBRzlDLFFBQUksZUFBZSxTQUFTO0FBQzNCLGlCQUFXLFlBQVksUUFBUTtJQUNoQztBQUdBLFFBQUkseUJBQXlCLFNBQVM7QUFDckMsaUJBQVcsc0JBQXNCLFFBQVE7SUFDMUM7QUFDQSxRQUFJLGVBQWUsU0FBUztBQUMzQixpQkFBVyxZQUFZLFFBQVE7SUFDaEM7QUFFQSxlQUFXLE9BQU8sT0FBTyxLQUFLLE9BQU8sR0FBRztBQUN2QyxVQUFJLEVBQUUsT0FBTyxhQUFhO0FBQ3pCLG1CQUFXLEdBQUcsSUFBSyxRQUFnQixHQUFHO01BQ3ZDO0lBQ0Q7QUFHQSxRQUFJLE9BQU8sS0FBSyxVQUFVLFlBQVksTUFBTSxDQUFDO0FBSzdDLFdBQU8sS0FBSyxRQUFRLDBEQUEwRCw2QkFBNkI7QUFFM0csSUFBQUMsSUFBRyxjQUFjLFVBQVUsT0FBTyxNQUFNLE1BQU07RUFDL0MsU0FBUyxHQUFHO0FBQ1gsSUFBQUQsUUFBTyxNQUFNLHFCQUFxQixDQUFDLEVBQUU7RUFDdEM7QUFDRDs7O0FEbGdCQSxJQUFNRSxVQUFTLG1CQUFtQixTQUFTO0FBRXJDLFNBQVUsY0FBYyxNQUFvQjtBQUNqRCxRQUFNLGFBQWEsaUJBQWdCO0FBQ25DLFFBQU0sYUFBYSxhQUFZO0FBQy9CLFFBQU0sVUFBVSxxQkFBcUIsVUFBVTtBQUMvQyxRQUFNLGVBQW9CLENBQUE7QUFHMUIsUUFBTSxjQUFjLGFBQWEsS0FBSyxRQUFRLEtBQUssT0FBTztBQUMxRCxFQUFBQSxRQUFPLEtBQ04sK0JBQStCLFdBQVcsc0JBQXNCLEtBQUssT0FBTyxjQUFjLG9CQUFvQixLQUFLLFFBQVEsTUFBTSxFQUFFO0FBT3BJLGVBQWEsdUJBQXVCLElBQUk7SUFDdkMsTUFBTTtJQUNOLFNBQVMsQ0FBQTtJQUNULFVBQVUsWUFBVztBQUNwQixZQUFNLFFBQVE7QUFDZCxZQUFNLEtBQUssS0FBSztBQUVoQixZQUFNLE1BQU0sTUFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUU7QUFHekQsVUFBSSxZQUFZLGdCQUFnQixLQUFLO0FBQ3JDLFVBQUksQ0FBQyxXQUFXO0FBQ2YsUUFBQUEsUUFBTyxNQUFNLFNBQVMsS0FBSyw0QkFBNEI7QUFDdkQ7TUFDRDtBQUdBLFlBQU0sRUFBRSxVQUFVLFFBQVEsa0JBQWlCLElBQUssaUNBQWlDLE9BQU8sR0FBRztBQUMzRixNQUFBQSxRQUFPLE1BQU0saUJBQWlCLEtBQUssVUFBVSxNQUFNLENBQUMsRUFBRTtBQUd0RCxVQUFJLHNCQUFzQixNQUFNO0FBQy9CLFFBQUFBLFFBQU8sS0FBSywyQkFBMkIsaUJBQWlCLHdCQUF3QjtBQUNoRixvQkFBWSxFQUFFLEdBQUcsV0FBVyxXQUFXLGtCQUFpQjtNQUN6RDtBQUVBLFlBQU0sVUFBVSw0QkFBNEIsV0FBVyxRQUFRLE9BQU87QUFDdEUsTUFBQUEsUUFBTyxNQUFNLHFCQUFxQixLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUMsQ0FBQyxFQUFFO0FBR3BFLFlBQU1DLGlCQUFnQixpQkFBZ0I7QUFDdEMsWUFBTSxhQUFhQyxNQUFLLEtBQUtELGdCQUFlLFFBQVEsS0FBSyxPQUFPO0FBQ2hFLDBCQUFvQixZQUFZLE9BQU87QUFHdkMsMEJBQW1CO0FBRW5CLE1BQUFELFFBQU8sS0FBSyxTQUFTLEtBQUssd0NBQXdDO0lBQ25FOztBQU9ELGFBQVcsQ0FBQyxVQUFVLE1BQU0sS0FBSyxPQUFPLFFBQVEsVUFBVSxHQUFHO0FBQzVELFVBQU0sRUFBRSxPQUFPLE9BQU8sT0FBTSxJQUFLLGVBQWUsUUFBUTtBQUd4RCxRQUFJLFVBQVU7QUFBYTtBQUczQixVQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLFVBQU0sWUFBWSxRQUFRLFdBQVcsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLE1BQU07QUFFM0YsaUJBQWEsUUFBUSxJQUFJO01BQ3hCLEdBQUc7TUFDSCxVQUFVLE9BQU8sVUFBYztBQUM5QixjQUFNLEtBQUssS0FBSztBQUVoQixjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFZLE1BQU0sUUFBUSxPQUFPLElBQUksV0FBVztBQUN6RixjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU87QUFDbkMsY0FBTSxRQUFRLE1BQU0sUUFBUSxPQUFPLEtBQUs7QUFDeEMsY0FBTSxZQUFZLFNBQVM7QUFFM0IsY0FBTSxLQUFLLGFBQWEsYUFBYSxhQUFhLE9BQU8sT0FBTyxXQUFXLE9BQU8sRUFBRTtNQUNyRjs7RUFFRjtBQUtBLFFBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsTUFBSSxjQUFjO0FBQ2pCLFVBQU0sbUJBQW1CLGFBQWEsYUFBYSxDQUFBLEdBQUksS0FBSyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBRS9GLFFBQUksaUJBQWlCO0FBQ3BCLFlBQU0sV0FBVyxHQUFHLFdBQVc7QUFFL0IsbUJBQWEsUUFBUSxJQUFJO1FBQ3hCLE1BQU0sU0FBUyxXQUFXO1FBQzFCLFNBQVMsQ0FBQTtRQUNULFVBQVUsWUFBVztBQUNwQixnQkFBTSxLQUFLLEtBQUs7QUFDaEIsVUFBQUEsUUFBTyxLQUFLLHlCQUFvQixXQUFXLE1BQU0sRUFBRSxFQUFFO0FBQ3JELGdCQUFNLEtBQUssYUFBYSxjQUFjLGFBQWEsRUFBRTtRQUN0RDs7SUFFRjtFQUNEO0FBRUEsT0FBSyxxQkFBcUIsWUFBWTtBQUV0QyxFQUFBQSxRQUFPLEtBQUssaUNBQWlDLE9BQU8sS0FBSyxZQUFZLEVBQUUsTUFBTSxFQUFFO0FBQ2hGOzs7QUVwSEEsSUFBTUcsVUFBUyxtQkFBbUIsV0FBVztBQUs3QyxTQUFTLGlCQUNSLFNBQ0EsT0FDQSxPQUNBLFdBQ0EsT0FBYTtBQUViLFFBQU0sVUFBVSxxQkFBcUIsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUNyRSxNQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sUUFBUSxRQUFRLE9BQU87QUFBRyxXQUFPO0FBR3hELFFBQU0sY0FBYyxRQUFRLFFBQVEsS0FBSyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFDekUsTUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLFFBQVEsWUFBWSxPQUFPO0FBQUcsV0FBTztBQUdoRSxRQUFNLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxLQUFLO0FBQ2xFLFNBQU8sUUFBUSxTQUFTO0FBQ3pCO0FBTU0sU0FBVSxnQkFBZ0IsTUFBb0I7QUFDbkQsUUFBTSxhQUFhLGlCQUFnQjtBQUNuQyxRQUFNLGVBQWUsZUFBYztBQUNuQyxRQUFNLFVBQVUscUJBQXFCLFVBQVU7QUFDL0MsUUFBTSxpQkFBc0IsQ0FBQTtBQUc1QixRQUFNLGNBQWMsYUFBYSxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQzFELEVBQUFBLFFBQU8sS0FDTixpQ0FBaUMsV0FBVyxzQkFBc0IsS0FBSyxPQUFPLGNBQWMsb0JBQW9CLEtBQUssUUFBUSxNQUFNLEVBQUU7QUFPdEksYUFBVyxDQUFDLFlBQVksUUFBUSxLQUFLLE9BQU8sUUFBUSxZQUFZLEdBQUc7QUFDbEUsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxVQUFVO0FBRzFELFFBQUksVUFBVTtBQUFhO0FBRzNCLG1CQUFlLFVBQVUsSUFBSTtNQUM1QixHQUFHO01BQ0gsVUFBVSxDQUFDLGtCQUFzQjtBQUNoQyxjQUFNLEtBQUssS0FBSztBQUNoQixjQUFNLFFBQVEsY0FBYyxRQUFRLE9BQU87QUFDM0MsY0FBTSxRQUFRLGNBQWMsUUFBUSxPQUFPLEtBQUs7QUFDaEQsY0FBTSxZQUFZLFNBQVM7QUFDM0IsY0FBTSxVQUFVLEtBQUssYUFBYSxnQkFBZ0IsSUFBSSxPQUFPLFdBQVcsS0FBSztBQUc3RSxjQUFNLFlBQVksY0FBYyxRQUFRLFdBQVcsS0FBSztBQUV4RCxZQUFJLGFBQWEsWUFBWSxRQUFXO0FBRXZDLGlCQUFPLGlCQUFpQixTQUFTLE9BQU8sT0FBTyxXQUFXLE9BQU87UUFDbEU7QUFHQSxlQUFPLFdBQVc7TUFDbkI7O0VBRUY7QUFFQSxPQUFLLHVCQUF1QixjQUFjO0FBRTFDLEVBQUFBLFFBQU8sS0FBSyxxQ0FBcUMsT0FBTyxLQUFLLGNBQWMsRUFBRSxNQUFNLEVBQUU7QUFDdEY7OztBQ25GQSxPQUFPQyxZQUFXO0FBQ2xCLE9BQU9DLFNBQVE7OztBQ0RmLE9BQU8sV0FBVztBQUNsQixPQUFPLFFBQVE7QUFJZixJQUFNQyxVQUFTLG1CQUFtQixPQUFPO0FBS2xDLElBQU0seUJBQXlCO0FBRS9CLElBQU0sMEJBQTBCO0FBZ0JoQyxJQUFNLHFCQUFxQixNQUFPO0FBaUJuQyxTQUFVLHdCQUFxQjtBQUNwQyxRQUFNLE1BQU0sT0FBTyxNQUFNLElBQUksQ0FBQztBQUM5QixRQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTSxJQUFLLEtBQU07QUFFN0MsTUFBSSxjQUFjLE9BQVEsQ0FBQztBQUMzQixNQUFJLGNBQWMsd0JBQXdCLENBQUM7QUFDM0MsTUFBSSxjQUFjLEtBQUssQ0FBQztBQUV4QixRQUFNLE1BQU0saUJBQWdCO0FBQzVCLE1BQUksS0FBSyxLQUFLLENBQUM7QUFFZixTQUFPLEtBQUssWUFBWSxPQUFPLEVBQUUsS0FBSyxLQUFLLEVBQUU7QUFDN0MsTUFBSSxjQUFjLE1BQVEsRUFBRTtBQUM1QixNQUFJLGNBQWMsS0FBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFZLEVBQUU7QUFFaEMsU0FBTztBQUNSO0FBR00sU0FBVSxtQkFBZ0I7QUFDL0IsTUFBSTtBQUNILFVBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxlQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxpQkFBVyxRQUFRLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN0QyxZQUFJLENBQUMsS0FBSyxZQUFZLEtBQUssV0FBVyxVQUFVLEtBQUssT0FBTyxLQUFLLFFBQVEscUJBQXFCO0FBQzdGLGlCQUFPLE9BQU8sS0FBSyxLQUFLLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQWMsU0FBUyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQzNFO01BQ0Q7SUFDRDtFQUNELFFBQVE7RUFFUjtBQUNBLFNBQU8sT0FBTyxNQUFNLEdBQUcsQ0FBQztBQUN6QjtBQWlCTSxTQUFVLHVCQUF1QixLQUFhLE9BQWE7QUFDaEUsTUFBSSxJQUFJLFNBQVM7QUFBb0IsV0FBTztBQUM1QyxNQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBUSxXQUFPO0FBQzNDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUF5QixXQUFPO0FBQzVELE1BQUksSUFBSSxTQUFTLElBQUksRUFBRSxFQUFFLFNBQVMsT0FBTyxNQUFNO0FBQVksV0FBTztBQUVsRSxRQUFNLFVBQVUsQ0FBQyxRQUFnQixRQUNoQyxJQUNFLFNBQVMsUUFBUSxTQUFTLEdBQUcsRUFDN0IsU0FBUyxPQUFPLEVBQ2hCLE1BQU0sSUFBSSxFQUFFLENBQUMsRUFDYixLQUFJO0FBRVAsUUFBTSxRQUFRLElBQUksU0FBUyxHQUFHLEVBQUU7QUFDaEMsUUFBTSxXQUFXLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDNUUsUUFBTSxNQUFNLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHO0FBRXpFLFFBQU0sT0FBTyxRQUFRLElBQU0sRUFBRTtBQUM3QixRQUFNLGVBQWUsUUFBUSxJQUFNLEVBQUU7QUFDckMsUUFBTSxXQUFXLFFBQVEsS0FBTSxFQUFFO0FBQ2pDLFFBQU0sZ0JBQWdCLEdBQUcsSUFBSSxFQUFJLENBQUMsSUFBSSxJQUFJLEVBQUksQ0FBQztBQUUvQyxNQUFJLENBQUM7QUFBVSxXQUFPO0FBSXRCLFFBQU0sUUFBUSxTQUNaLFFBQVEsY0FBYyxFQUFFLEVBQ3hCLEtBQUksRUFDSixNQUFNLEtBQUssRUFBRSxDQUFDO0FBRWhCLFNBQU87SUFDTixJQUFJO0lBQ0o7SUFDQTtJQUNBO0lBQ0EsV0FBVzs7SUFDWDtJQUNBOztBQUVGO0FBTUEsZUFBc0IsOEJBQThCLFFBQWM7QUFDakUsU0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFVBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUVyQyxRQUFJLFdBQVc7QUFDZixRQUFJLEtBQUssU0FBUyxDQUFDLFFBQU87QUFDekIsVUFBSSxDQUFDLFVBQVU7QUFDZCxtQkFBVztBQUNYLFlBQUksTUFBSztBQUNULGVBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzdDO0lBQ0QsQ0FBQztBQUdELFFBQUksUUFBUSxHQUFHLFFBQVEsTUFBSztBQUMzQixVQUFJO0FBQ0gsY0FBTSxPQUFPLElBQUksUUFBTztBQUN4QixjQUFNLFlBQVksS0FBSztBQUN2QixZQUFJLENBQUMsVUFBVTtBQUNkLHFCQUFXO0FBQ1gsY0FBSSxNQUFLO0FBQ1Qsa0JBQVEsU0FBUztRQUNsQjtNQUNELFNBQVMsSUFBSTtBQUNaLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxpQkFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM3QjtNQUNEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQWdCQSxlQUFzQixnQkFDckIsVUFDQSxlQUNBLGtCQUNBLFlBQVksS0FBSTtBQUVoQixRQUFNLHVCQUF1QjtBQUM3QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLGVBQWU7QUFFckIsUUFBTSxRQUFRLG9CQUFJLElBQUc7QUFDckIsUUFBTSxhQUFhLG9CQUFJLElBQUc7QUFFMUIsU0FBTyxJQUFJLFFBQXNCLENBQUMsWUFBVztBQUU1QyxVQUFNLGtCQUFrQixDQUFDLFdBQXNCO0FBQzlDLFVBQUksQ0FBQyxNQUFNLElBQUksT0FBTyxFQUFFLEdBQUc7QUFDMUIsY0FBTSxJQUFJLE9BQU8sSUFBSSxNQUFNO0FBQzNCLHNCQUFjLE1BQU07TUFDckI7SUFDRDtBQUdBLFVBQU0saUJBQWlCLE1BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUUzRSxVQUFNLFVBQVUsTUFBSztBQUNwQixVQUFJO0FBQ0gsdUJBQWUsZUFBZSxvQkFBb0I7TUFDbkQsUUFBUTtNQUVSO0FBQ0EsVUFBSTtBQUNILHVCQUFlLE1BQUs7TUFDckIsUUFBUTtNQUVSO0FBQ0EsY0FBUSxNQUFNLEtBQUssTUFBTSxPQUFNLENBQUUsQ0FBQztJQUNuQztBQUVBLFVBQU0sUUFBUSxXQUFXLFNBQVMsU0FBUztBQUMzQyxVQUFNLFFBQU87QUFFYixtQkFBZSxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2xDLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsSUFBSSxPQUFPLEVBQUU7SUFDcEQsQ0FBQztBQUVELG1CQUFlLEdBQUcsV0FBVyxDQUFDLEtBQUssVUFBUztBQUMzQyxZQUFNLFFBQVEsTUFBTTtBQUVwQixVQUFJLElBQUksU0FBUztBQUFJO0FBQ3JCLFVBQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRO0FBQ3BDLFVBQUksSUFBSSxTQUFTLElBQUksRUFBRSxFQUFFLFNBQVMsT0FBTyxNQUFNO0FBQVk7QUFFM0QsVUFBSSxXQUFXLElBQUksS0FBSztBQUFHO0FBQzNCLGlCQUFXLElBQUksS0FBSztBQUNwQixNQUFBQSxRQUFPLE1BQU0saUJBQWlCLEtBQUssK0JBQTBCO0FBSzdELHVCQUFpQixLQUFLLEVBQ3BCLEtBQUssTUFBSztBQUNWLGNBQU0sUUFBUSxzQkFBcUI7QUFDbkMsaUJBQVMsS0FBSyxPQUFPLGNBQWMsT0FBTyxDQUFDLFFBQU87QUFDakQsY0FBSTtBQUFLLFlBQUFBLFFBQU8sS0FBSyxvQkFBb0IsS0FBSyxZQUFZLElBQUksT0FBTyxFQUFFO1FBQ3hFLENBQUM7TUFDRixDQUFDLEVBQ0EsTUFBTSxDQUFDLFFBQVFBLFFBQU8sS0FBSyx1QkFBdUIsR0FBRyxFQUFFLENBQUM7SUFDM0QsQ0FBQztBQUVELG1CQUFlLEtBQUsscUJBQXFCLE1BQUs7QUFDN0MsVUFBSTtBQUNILHVCQUFlLGNBQWMsb0JBQW9CO0FBQ2pELFFBQUFBLFFBQU8sS0FBSyxvQ0FBb0Msb0JBQW9CLElBQUksbUJBQW1CLEVBQUU7TUFDOUYsU0FBUyxLQUFLO0FBQ2IsUUFBQUEsUUFBTyxLQUFLLDRDQUE0QyxHQUFHLEVBQUU7TUFDOUQ7SUFDRCxDQUFDO0FBR0MsbUJBQXVCLGtCQUFrQjtFQUM1QyxDQUFDO0FBQ0Y7OztBRGhQQSxJQUFNQyxVQUFTLG1CQUFtQixjQUFjO0FBRTFDLElBQU8sZUFBUCxNQUFPLGNBQVk7RUFDUCxjQUFzQjtFQUN0QixpQkFBaUI7RUFDakIsU0FBUztFQUVsQjtFQUNBOztFQUNBO0VBSUEsbUJBQWdDLG9CQUFJLElBQUc7OztFQUd2Qzs7RUFHQSxRQUFnQjtFQUNoQixVQUFzQixDQUFBO0VBQ3RCLHNCQUErQjs7Ozs7Ozs7RUFRL0IsY0FBZ0Qsb0JBQUksSUFBRzs7RUFHdkQscUJBQWdFLG9CQUFJLElBQUc7O0VBR3ZFO0VBRVIsY0FBQTtBQUNDLElBQUFBLFFBQU8sS0FBSywwQkFBMEI7QUFFdEMsU0FBSyxjQUFjLG9CQUFJLElBQUc7QUFJMUIsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDcEUsU0FBSyxVQUFVLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDNUMsV0FBSyxTQUFTLEtBQUssR0FBRyxNQUFLO0FBQzFCLFFBQUFELFFBQU8sTUFBTSwyQkFBNEIsS0FBSyxTQUFTLFFBQU8sRUFBd0IsSUFBSSxFQUFFO0FBQzVGLGdCQUFPO01BQ1IsQ0FBQztJQUNGLENBQUM7QUFDRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBR0QsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFcEUsU0FBSyxTQUFTLEdBQUcsYUFBYSxNQUFLO0FBQ2xDLFlBQU0sT0FBTyxLQUFLLFNBQVMsUUFBTztBQUNsQyxNQUFBRCxRQUFPLE1BQU0sMEJBQTBCLEtBQUssVUFBVSxJQUFJLENBQUMsRUFBRTtBQUM3RCxVQUFJO0FBQ0gsYUFBSyxTQUFTLHFCQUFxQixJQUFJO01BQ3hDLFNBQVMsSUFBSTtNQUViO0lBQ0QsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzFDLFVBQUk7QUFDSCxhQUFLLGVBQWUsS0FBSyxNQUFNLE9BQU87TUFDdkMsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxFQUFFLEVBQUU7TUFDdEQ7SUFDRCxDQUFDO0FBR0QsU0FBSyxTQUFTLEtBQUssRUFBRSxTQUFTLFdBQVcsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2xFLE1BQUFBLFFBQU8sTUFBTSw4QkFBOEIsS0FBSyxNQUFNLEVBQUU7SUFDekQsQ0FBQztFQUNGO0VBRU8sUUFBSztBQUNYLFFBQUk7QUFDSCxpQkFBVyxhQUFhLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixHQUFHO0FBQzFELFlBQUk7QUFDSCxlQUFLLFNBQVMsZUFBZSxLQUFLLGdCQUFnQixTQUFTO1FBQzVELFFBQVE7UUFFUjtNQUNEO0lBQ0QsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7RUFDRDs7Ozs7RUFNTyxTQUFTLE9BQWUsU0FBcUIsc0JBQStCLE1BQUk7QUFDdEYsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVO0FBQ2YsU0FBSyxzQkFBc0I7RUFDNUI7Ozs7O0VBTU8sb0JBQW9CLFVBQXNDO0FBQ2hFLFNBQUssbUJBQW1CO0VBQ3pCOzs7OztFQU1PLE1BQU0sbUJBQW1CLFVBQWdCO0FBQy9DLElBQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsUUFBUSxFQUFFO0FBQ3RELFVBQU0sV0FBVyxNQUFNLEtBQUssYUFDM0IsS0FBSyxPQUNMLHNCQUNBLFFBQ0EsUUFDQSxRQUNBLFVBQ0EsS0FBSztBQUlOLElBQUFBLFFBQU8sTUFBTSx3QkFBd0IsU0FBUyxTQUFTLEtBQUssQ0FBQyxFQUFFO0FBQy9ELElBQUFBLFFBQU8sTUFBTSxvQkFBb0IsU0FBUyxNQUFNLEVBQUU7QUFHbEQsVUFBTSxTQUFTLDRCQUE0QixLQUFLLE9BQU8sUUFBUTtBQUMvRCxJQUFBQSxRQUFPLE1BQU0sMEJBQTBCLE9BQU8sTUFBTSxFQUFFO0FBQ3RELFFBQUksT0FBTyxTQUFTLEdBQUc7QUFDdEIsTUFBQUEsUUFBTyxNQUFNLHVCQUF1QixLQUFLLFVBQVUsT0FBTyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRTtJQUN6RTtBQUVBLFVBQU0sV0FBVyxvQkFBSSxJQUFHO0FBQ3hCLGVBQVcsV0FBVyxRQUFRO0FBQzdCLFlBQU0sTUFBTSxjQUFjLEtBQUssT0FBTyxRQUFRLFFBQVEsUUFBUSxJQUFJLFFBQVEsS0FBSztBQUUvRSxZQUFNLFFBQ0wsUUFBUSxXQUFXLFdBQVcsSUFDMUIsUUFBUSxXQUFXLENBQUMsS0FBSyxLQUFPLFFBQVEsV0FBVyxDQUFDLEtBQUssSUFBSyxRQUFRLFdBQVcsQ0FBQyxJQUNsRixRQUFRLFdBQVcsQ0FBQyxLQUFLO0FBQzlCLGVBQVMsSUFBSSxLQUFLLEtBQUs7SUFDeEI7QUFDQSxTQUFLLFlBQVksSUFBSSxVQUFVLFFBQVE7QUFDdkMsV0FBTztFQUNSOztFQUdPLGVBQWUsVUFBZ0I7QUFDckMsV0FBTyxLQUFLLFlBQVksSUFBSSxRQUFRLEtBQUssb0JBQUksSUFBRztFQUNqRDs7Ozs7Ozs7Ozs7RUFZTyxNQUFNLGdCQUFnQixZQUFZLEtBQUk7QUFFNUMsVUFBTSxnQkFBZ0I7QUFDdEIsVUFBTSxlQUE2QixDQUFBO0FBRW5DLFVBQU0sZ0JBQWdCLENBQUMsV0FBc0I7QUFDNUMsbUJBQWEsS0FBSyxNQUFNO0lBQ3pCO0FBR0EsU0FBSyxtQkFBbUIsSUFBSSxlQUFlLGFBQWE7QUFFeEQsUUFBSTtBQUNILFlBQU0sS0FBSztBQUdYLFlBQU07UUFDTCxLQUFLO1FBQ0w7O1FBQ0EsT0FBTyxXQUFXLEtBQUssb0JBQW9CLE1BQU07UUFDakQ7TUFBUztBQUVWLGFBQU87SUFDUjtBQUNDLFdBQUssbUJBQW1CLE9BQU8sYUFBYTtJQUM3QztFQUNEOzs7OztFQU1PLE1BQU0sdUJBQXVCLFVBQWdCO0FBQ25ELElBQUFBLFFBQU8sS0FBSyxvQ0FBb0MsUUFBUSxFQUFFO0FBQzFELFVBQU0sV0FBVyxNQUFNLEtBQUssYUFDM0IsS0FBSyxPQUNMLGtCQUNBLFFBQ0EsUUFDQSxRQUNBLFVBQ0EsT0FDQSxFQUFNO0FBS1AsVUFBTSxZQUFZO0FBRWxCLFFBQUksU0FBUyxTQUFTLFlBQVksR0FBRztBQUNwQyxNQUFBQSxRQUFPLEtBQUssZ0NBQWdDLFNBQVMsTUFBTSxRQUFRO0FBQ25FLGFBQU87SUFDUjtBQUdBLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUNwQyxVQUFNLFFBQVEsU0FBUyxZQUFZLENBQUM7QUFNcEMsUUFBSTtBQUNKLFFBQUksVUFBVSxHQUFHO0FBQ2hCLGlCQUFXO0lBQ1osV0FBVyxRQUFRLElBQUk7QUFDdEIsaUJBQVcsTUFBTSxTQUFRLEVBQUcsU0FBUyxHQUFHLEdBQUc7SUFDNUMsT0FBTztBQUNOLGlCQUFXLE1BQU0sU0FBUTtJQUMxQjtBQUVBLFVBQU0sV0FBVyxHQUFHLEtBQUssSUFBSSxRQUFRO0FBRXJDLElBQUFBLFFBQU8sS0FBSyxxQkFBcUIsUUFBUSxFQUFFO0FBQzNDLFdBQU87RUFDUjs7Ozs7RUFNUSxNQUFNLG9CQUFvQixRQUFjO0FBQy9DLFFBQUk7QUFDSCxZQUFNLFlBQVksTUFBTSw4QkFBOEIsTUFBTTtBQUM1RCxVQUFJLENBQUMsV0FBVztBQUNmLFFBQUFBLFFBQU8sS0FBSyxxREFBcUQsTUFBTSxFQUFFO0FBQ3pFO01BQ0Q7QUFFQSxVQUFJLEtBQUssaUJBQWlCLElBQUksU0FBUyxHQUFHO0FBRXpDO01BQ0Q7QUFFQSxVQUFJO0FBQ0gsYUFBSyxTQUFTLGNBQWMsS0FBSyxnQkFBZ0IsU0FBUztBQUMxRCxhQUFLLGlCQUFpQixJQUFJLFNBQVM7QUFDbkMsUUFBQUEsUUFBTyxLQUFLLG9CQUFvQixLQUFLLGNBQWMsT0FBTyxTQUFTLEVBQUU7TUFDdEUsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxLQUFLLCtCQUErQixTQUFTLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRTtNQUN0RTtJQUNELFNBQVMsSUFBSTtBQUNaLE1BQUFBLFFBQU8sS0FBSywrQkFBK0IsRUFBRSxFQUFFO0lBQ2hEO0VBQ0Q7RUFFTyxNQUFNLGFBQ1osT0FDQSxPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUNULFVBQVUsSUFBTTtBQUVoQixVQUFNLFlBQVk7QUFHbEIsVUFBTSxLQUFLLG9CQUFvQixNQUFNO0FBRXJDLFVBQU0sWUFBc0IsQ0FBQTtBQUM1QixRQUFJLGNBQWM7QUFBVyxnQkFBVSxLQUFLLFlBQVksR0FBSTtBQUM1RCxRQUFJLFVBQVU7QUFBVyxnQkFBVSxLQUFLLEdBQUcsY0FBYSxnQkFBZ0IsS0FBSyxDQUFDO0FBRTlFLFVBQU0sY0FBd0IsQ0FBQyxJQUFNLFFBQVEsR0FBSTtBQUVqRCxRQUFJLFVBQVU7QUFBVyxrQkFBWSxLQUFLLFFBQVEsR0FBSTtBQUN0RCxRQUFJO0FBQVEsa0JBQVksS0FBSyxVQUFVLE1BQU07QUFFN0MsUUFBSSxVQUFVLFNBQVM7QUFBRyxrQkFBWSxLQUFLLEdBQUcsU0FBUztBQUV2RCxVQUFNLE1BQU0sY0FBYSxVQUFVLFdBQVc7QUFDOUMsVUFBTSxpQkFBaUIsT0FBTyxLQUFLLENBQUMsR0FBRyxhQUFhLEdBQUcsQ0FBQztBQUV4RCxVQUFNLFNBQVMsTUFBTSxjQUFhLFlBQVksUUFBUSxPQUFPO0FBQzdELFVBQU0sU0FBUyxPQUFPLE9BQU8sQ0FBQyxRQUFRLGNBQWMsQ0FBQztBQUdyRCxVQUFNLFVBQVUsZUFBZSxLQUFLO0FBQ3BDLFFBQUksY0FBYyxVQUFhLFVBQVUsUUFBVztBQUVuRCxVQUFJLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBRzlFLFVBQUksQ0FBQyxRQUFRO0FBQ1osaUJBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQ2hDLGNBQUksRUFBRSxXQUFXO0FBQU8sbUJBQU87QUFDL0IsZ0JBQU0sV0FBVyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDNUQsY0FBSSxDQUFDO0FBQVUsbUJBQU87QUFDdEIsaUJBQU8sYUFBYSxFQUFFLE1BQU0sWUFBWSxFQUFFLEtBQUs7UUFDaEQsQ0FBQztNQUNGO0FBRUEsVUFBSSxjQUFjLFFBQVEsUUFBUTtBQUdsQyxVQUFJLFFBQVE7QUFDWCxjQUFNLFdBQVcsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ2pFLFlBQUksWUFBWSxjQUFjLE9BQU8sSUFBSTtBQUN4QyxnQkFBTSxnQkFBZ0IsWUFBWSxPQUFPO0FBQ3pDLHdCQUFjLEdBQUcsV0FBVyxNQUFNLGdCQUFnQixDQUFDO1FBQ3BEO01BQ0Q7QUFHQSxZQUFNLGNBQWMsUUFBUSxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3JFLFlBQU0sVUFBVSxhQUFhO0FBQzdCLFlBQU0sYUFBYSxjQUFhLGdCQUFnQixLQUFLO0FBQ3JELFlBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxZQUFNLGNBQWMsV0FBVyxhQUFhLFNBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7QUFFeEcsWUFBTSxTQUFTLE1BQU0sS0FBSztBQUMxQixZQUFNLFFBQVEsTUFBTSxTQUFTO0FBQzdCLFlBQU0sU0FBUyxXQUFXLFVBQVU7QUFDcEMsWUFBTSxTQUFTLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJLFdBQVcsS0FBSyxHQUFHO0FBRTVFLFlBQU0sU0FBUyxPQUFPLE1BQU0sT0FBTyxLQUFLLFFBQVEsTUFBTTtBQUN0RCxZQUFNLFNBQVMsY0FBYyxHQUFHLFdBQVcsS0FBSyxXQUFXLEtBQUssTUFBTSxNQUFNLEdBQUcsV0FBVyxLQUFLLE1BQU07QUFFckcsTUFBQUEsUUFBTyxLQUFLLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLEVBQUU7SUFDbkQsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxPQUFPLEVBQUU7SUFDeEM7QUFDQSxJQUFBQSxRQUFPLE1BQU0scUJBQXFCLE1BQU0sS0FBSyxPQUFPLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFFckUsVUFBTSxLQUFLO0FBRVgsVUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLEtBQUs7QUFFOUIsV0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFlBQU0sUUFBUSxXQUFXLE1BQUs7QUFDN0IsYUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQixlQUFPLElBQUksTUFBTSxxQ0FBcUMsS0FBSyxPQUFPLE1BQU0sT0FBTyxDQUFDO01BQ2pGLEdBQUcsU0FBUztBQUVaLFdBQUssWUFBWSxJQUFJLEtBQUs7UUFDekIsU0FBUyxDQUFDLFFBQU87QUFDaEIsdUJBQWEsS0FBSztBQUdsQixjQUFJLEtBQUssdUJBQXVCLGNBQWMsUUFBVztBQUN4RCxpQkFBSyxtQkFBbUIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxRQUFPO0FBQzdDLGNBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsR0FBRyxFQUFFO1lBQy9ELENBQUM7VUFDRjtBQUVBLGtCQUFRLEdBQUc7UUFDWjtRQUNBLFFBQVEsQ0FBQyxRQUFPO0FBQ2YsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxHQUFHO1FBQ1g7UUFDQTtPQUNBO0FBRUQsV0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLGFBQWEsUUFBUSxDQUFDLFFBQU87QUFDNUQsWUFBSSxLQUFLO0FBQ1IsZUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUM3QztNQUNELENBQUM7SUFDRixDQUFDO0VBQ0Y7RUFFUSxlQUFlLEtBQWEsT0FBYTtBQUNoRCxRQUFJLElBQUksU0FBUztBQUFHO0FBQ3BCLFFBQUksSUFBSSxDQUFDLE1BQU0sT0FBUSxJQUFJLENBQUMsTUFBTTtBQUFNO0FBRXhDLFVBQU0sVUFBVSxJQUFJLGFBQWEsQ0FBQztBQUtsQyxRQUFJLFlBQVksMkJBQTJCLEtBQUssbUJBQW1CLE9BQU8sR0FBRztBQUM1RSxZQUFNLFNBQVMsdUJBQXVCLEtBQUssS0FBSztBQUNoRCxVQUFJLFFBQVE7QUFDWCxtQkFBVyxNQUFNLEtBQUssbUJBQW1CLE9BQU0sR0FBSTtBQUNsRCxjQUFJO0FBQ0gsZUFBRyxNQUFNO1VBQ1YsUUFBUTtVQUVSO1FBQ0Q7TUFDRDtBQUNBO0lBQ0Q7QUFFQSxRQUFJLElBQUksU0FBUztBQUFJO0FBR3JCLFVBQU0sTUFBTSxJQUFJLFNBQVMsSUFBSSxFQUFFO0FBQy9CLFFBQUksSUFBSSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBSTFDLFVBQU0sWUFBWSxJQUFJLFNBQVMsRUFBRTtBQUNqQyxRQUFJLFVBQVUsU0FBUztBQUFHO0FBQzFCLFFBQUksVUFBVSxDQUFDLE1BQU07QUFBTTtBQUczQixVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sY0FBYyxZQUFZLFNBQVU7QUFDMUMsVUFBTSxnQkFBZ0IsWUFBWTtBQUdsQyxTQUFLLGFBQWEsT0FBTyxlQUFlLEtBQUssV0FBVyxVQUFVO0FBR2xFLFFBQUksWUFBWTtBQUNmLFlBQU0sTUFBTSxHQUFHLEtBQUssSUFBSSxhQUFhO0FBQ3JDLFlBQU0sVUFBVSxLQUFLLFlBQVksSUFBSSxHQUFHO0FBQ3hDLFVBQUksU0FBUztBQUNaLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZ0JBQVEsUUFBUSxHQUFHO01BQ3BCO0lBQ0Q7RUFFRDs7Ozs7Ozs7Ozs7O0VBYVEsYUFBYSxPQUFlLE9BQWUsS0FBYSxXQUFtQixhQUFhLE1BQUk7QUFDbkcsVUFBTSxVQUFVLE9BQU8sTUFBTSxLQUFLLENBQUM7QUFDbkMsVUFBTSxPQUFPLFVBQVUsU0FBUyxHQUFHLFVBQVUsU0FBUyxDQUFDO0FBR3ZELFVBQU0sUUFBUSxVQUFVLENBQUM7QUFDekIsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLE1BQU0sVUFBVSxVQUFVLFNBQVMsQ0FBQztBQUMxQyxVQUFNLGdCQUFnQixVQUFVLE1BQU0sS0FBSyxDQUFDLFFBQVEsTUFBTSxTQUFTLENBQUMsU0FBUyxLQUFLLFNBQVMsS0FBSyxDQUFDLFFBQVEsTUFBTSxHQUFHLENBQUM7QUFHbkgsVUFBTSxZQUFZLGFBQWEsT0FBTztBQUt0QyxRQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQUksQ0FBQyxLQUFLLE9BQU87QUFDaEIsUUFBQUEsUUFBTyxLQUFLLEdBQUcsU0FBUyxJQUFJLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxFQUFFO0FBQ25FO01BQ0Q7QUFDQSxVQUFJO0FBQ0gsY0FBTSxXQUNMLFVBQVUsb0JBQ1Asc0JBQXNCLEtBQUssT0FBTyxHQUFHLElBQ3JDLDRCQUE0QixLQUFLLE9BQU8sR0FBRztBQUUvQyxjQUFNLFlBQVksS0FBSyxZQUFZLElBQUksS0FBSyxLQUFLLG9CQUFJLElBQUc7QUFDeEQsY0FBTSxXQUFXLElBQUksSUFBb0IsU0FBUztBQUVsRCxtQkFBVyxLQUFLLFVBQVU7QUFDekIsZ0JBQU0sV0FBVyxjQUFjLEtBQUssT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSztBQUVsRSxnQkFBTSxXQUNMLEVBQUUsV0FBVyxXQUFXLElBQ3BCLEVBQUUsV0FBVyxDQUFDLEtBQUssS0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLElBQUssRUFBRSxXQUFXLENBQUMsSUFDaEUsRUFBRSxXQUFXLENBQUMsS0FBSztBQUN4QixnQkFBTSxZQUFZLFVBQVUsSUFBSSxRQUFRO0FBQ3hDLGdCQUFNLFVBQVUsY0FBYyxVQUFhLGNBQWM7QUFFekQsbUJBQVMsSUFBSSxVQUFVLFFBQVE7QUFFL0IsZ0JBQU0sWUFBWSxvQkFBb0IsR0FBRyxLQUFLLE9BQU87QUFDckQsY0FBSSxTQUFTO0FBQ1osWUFBQUEsUUFBTyxLQUFLLEdBQUcsU0FBUyxJQUFJLEtBQUssTUFBTSxTQUFTLEVBQUU7QUFFbEQsZ0JBQUksS0FBSyxrQkFBa0I7QUFDMUIsbUJBQUssaUJBQWlCLFFBQVE7WUFDL0I7VUFDRCxPQUFPO0FBQ04sWUFBQUEsUUFBTyxNQUFNLEdBQUcsU0FBUyxJQUFJLEtBQUssTUFBTSxTQUFTLEVBQUU7VUFDcEQ7UUFDRDtBQUNBLGFBQUssWUFBWSxJQUFJLE9BQU8sUUFBUTtNQUNyQyxTQUFTLEdBQUc7QUFDWCxRQUFBQSxRQUFPLEtBQUssR0FBRyxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU8sb0JBQW9CLENBQUMsTUFBTSxhQUFhLEVBQUU7TUFDekY7QUFDQTtJQUNEO0FBR0EsVUFBTSxVQUFVLEtBQUssYUFBYSxPQUFPLElBQUk7QUFDN0MsUUFBSSxTQUFTO0FBQ1osTUFBQUEsUUFBTyxLQUFLLEdBQUcsU0FBUyxJQUFJLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxNQUFNLE9BQU8sRUFBRTtJQUNqRixPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLEdBQUcsU0FBUyxJQUFJLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxFQUFFO0lBQ3BFO0VBQ0Q7Ozs7Ozs7O0VBU1EsYUFBYSxPQUFlLE1BQVk7QUFDL0MsUUFBSSxLQUFLLFdBQVc7QUFBRyxhQUFPO0FBRzlCLFFBQUksS0FBSyxXQUFXLEdBQUc7QUFDdEIsVUFBSSxLQUFLLENBQUMsTUFBTSxHQUFNO0FBQ3JCLGVBQU87TUFDUixPQUFPO0FBQ04sZUFBTyxTQUFTLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQztNQUMvQjtJQUNEO0FBRUEsWUFBUSxPQUFPOzs7OztNQUtkLEtBQUssY0FBYztBQUNsQixZQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLGlCQUFPLEtBQUssQ0FBQyxNQUFNLElBQU8sV0FBVyxXQUFXLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQztRQUMvRDtBQUNBLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDckIsZ0JBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsZ0JBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsZ0JBQU0sYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNsQyxnQkFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUNoRixnQkFBTSxjQUFjLFFBQVEsUUFBUSxXQUFXLE1BQU0sU0FBUyxDQUFDO0FBQy9ELGdCQUFNLFVBQVUsUUFBUSxVQUFVLENBQUMsR0FBRztBQUN0QyxnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLGNBQ0wsV0FBVyxhQUFhLFNBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7QUFDckYsZ0JBQU0sV0FBVyxjQUFjLEdBQUcsV0FBVyxLQUFLLE1BQU0sUUFBUyxDQUFDLE1BQU0sV0FBVyxNQUFNLEtBQUssVUFBVSxDQUFDO0FBQ3pHLGdCQUFNLFNBQVMsSUFBSSxNQUFNLEtBQUssQ0FBQyxJQUFJLE1BQU0sU0FBUyxDQUFDLEtBQUssV0FBVyxNQUFNLEtBQUssVUFBVSxDQUFDLENBQUM7QUFDMUYsaUJBQU8sV0FBVyxLQUFLLE1BQU0sV0FBVyxLQUFLLFFBQVEsSUFBSSxNQUFNO1FBQ2hFO0FBQ0EsZUFBTyxRQUFRLEtBQUssU0FBUyxLQUFLLENBQUM7TUFDcEM7O01BR0EsS0FBSyxpQkFBaUI7QUFFckIsWUFBSSxLQUFLLFVBQVUsR0FBRztBQUNyQixnQkFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixnQkFBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixnQkFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO0FBQ2xDLGdCQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBQ2hGLGdCQUFNLGNBQWMsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLENBQUM7QUFDL0QsZ0JBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxnQkFBTSxVQUFVLFFBQVEsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxHQUFHO0FBQ2hFLGdCQUFNLGNBQ0wsV0FBVyxhQUFhLFNBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7QUFDckYsZ0JBQU0sV0FBVyxlQUFlLEtBQUssV0FBVyxTQUFTLEtBQUssQ0FBQztBQUMvRCxpQkFBTyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUTtRQUN0RDtBQUNBLGVBQU87TUFDUjs7TUFHQSxLQUFLO01BQ0wsS0FBSyxhQUFhO0FBQ2pCLFlBQUksS0FBSyxTQUFTO0FBQUcsaUJBQU87QUFDNUIsY0FBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixjQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGNBQU0sUUFBUSxLQUFLLFNBQVMsQ0FBQztBQUM3QixlQUFPLE1BQU0sS0FBSyxZQUFZLE1BQU0sU0FBUyxDQUFDLFVBQVUsTUFBTSxTQUFTLEtBQUssQ0FBQztNQUM5RTtNQUVBO0FBQ0MsZUFBTztJQUNUO0VBQ0Q7RUFFUSxPQUFPLGdCQUFnQixPQUFjO0FBQzVDLFFBQUksT0FBTyxVQUFVO0FBQVcsYUFBTyxDQUFDLFFBQVEsSUFBSSxDQUFDO0FBQ3JELFFBQUksTUFBTSxRQUFRLEtBQUs7QUFBRyxhQUFPLE1BQU0sSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDLElBQUksR0FBSTtBQUNsRSxRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzlCLFVBQUksUUFBUTtBQUFNLGVBQU8sQ0FBRSxTQUFTLEtBQU0sS0FBTyxTQUFTLElBQUssS0FBTSxRQUFRLEdBQUk7QUFDakYsYUFBTyxDQUFDLFFBQVEsR0FBSTtJQUNyQjtBQUNBLFVBQU0sSUFBSSxNQUFNLDRDQUE0QyxLQUFLLEVBQUU7RUFDcEU7RUFFUSxhQUFhLHFCQUFxQixRQUFjO0FBQ3ZELFdBQU8sSUFBSSxRQUFrQixDQUFDLFNBQVMsV0FBVTtBQUNoRCxZQUFNLE1BQU1DLE9BQU0sYUFBYSxNQUFNO0FBRXJDLFVBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixZQUFJLE1BQUs7QUFDVCxlQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztNQUM3QyxDQUFDO0FBRUQsVUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFlBQUk7QUFDSCxnQkFBTSxPQUFPLElBQUksUUFBTztBQUN4QixnQkFBTSxZQUFZLEtBQUs7QUFFdkIsY0FBSSxNQUFLO0FBRVQsZ0JBQU0sU0FBU0MsSUFBRyxrQkFBaUI7QUFDbkMscUJBQVcsUUFBUSxPQUFPLEtBQUssTUFBTSxHQUFHO0FBQ3ZDLHVCQUFXLFNBQVMsT0FBTyxJQUFJLEtBQUssQ0FBQSxHQUFJO0FBQ3ZDLGtCQUNDLE1BQU0sV0FBVyxVQUNqQixNQUFNLFlBQVksYUFDbEIsTUFBTSxPQUNOLE1BQU0sUUFBUSxxQkFDYjtBQUNELHVCQUFPLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLFNBQVMsR0FBRyxFQUFFLElBQUksR0FBSSxDQUFDO2NBQ3ZFO1lBQ0Q7VUFDRDtBQUVBLGlCQUFPLElBQUksTUFBTSx3Q0FBd0MsU0FBUyxFQUFFLENBQUM7UUFDdEUsU0FBUyxJQUFJO0FBQ1osaUJBQU8sSUFBSSxNQUFNLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDN0I7TUFDRCxDQUFDO0lBQ0YsQ0FBQztFQUNGO0VBRVEsYUFBYSxZQUFZLFFBQWdCLFVBQVUsSUFBTTtBQUNoRSxVQUFNLE1BQU0sTUFBTSxjQUFhLHFCQUFxQixNQUFNO0FBRzFELFVBQU0sYUFBYyxXQUFXLElBQUs7QUFDcEMsVUFBTSxhQUFhLFVBQVU7QUFFN0IsV0FBTyxPQUFPLE9BQU87TUFDcEIsT0FBTyxLQUFLLENBQUMsS0FBTSxLQUFNLFlBQVksWUFBWSxHQUFNLEtBQU0sR0FBTSxHQUFNLEdBQUcsS0FBSyxHQUFNLENBQUksQ0FBQztNQUM1RixPQUFPLEtBQUssWUFBWSxNQUFNO0tBQzlCO0VBQ0Y7RUFFUSxPQUFPLFVBQVUsTUFBYztBQUN0QyxRQUFJLE1BQU07QUFDVixlQUFXLEtBQUssTUFBTTtBQUNyQixhQUFPO0FBQ1AsZUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDM0IsZUFBTyxNQUFNLFNBQVUsS0FBTSxPQUFPLElBQUssT0FBUSxNQUFRLE9BQU8sSUFBSztNQUN0RTtJQUNEO0FBQ0EsV0FBTztFQUNSOzs7Ozs7Ozs7O0VBV08sZ0JBQWdCLElBQVksT0FBZSxXQUFtQixPQUFjO0FBQ2xGLFVBQU0sTUFBTSxjQUFjLEtBQUssT0FBTyxPQUFPLFdBQVcsS0FBSztBQUM3RCxXQUFPLEtBQUssWUFBWSxJQUFJLEVBQUUsR0FBRyxJQUFJLEdBQUc7RUFDekM7RUFFTyxNQUFNLFlBQVksT0FBZSxRQUFjO0FBQ3JELFdBQU8sS0FBSyxhQUFhLE9BQU8sa0JBQWtCLFFBQVcsR0FBTSxRQUFXLFFBQVEsS0FBSztFQUM1RjtFQUVPLE1BQU0sY0FBYyxPQUFlLFFBQWM7QUFDdkQsV0FBTyxLQUFLLGFBQWEsT0FBTyxxQkFBcUIsUUFBVyxRQUFXLFFBQVcsUUFBUSxLQUFLO0VBQ3BHOzs7O0FFN3RCRCxJQUFNQyxVQUFTLG1CQUFtQixnQkFBZ0I7QUFNbEQsSUFBcUIsaUJBQXJCLGNBQTRDLGFBQXlCO0VBQ3BFOztFQUNBOzs7RUFJUSxvQkFBa0MsQ0FBQTtFQUUxQyxZQUFZLFVBQWlCO0FBQzVCLFVBQU0sUUFBUTtFQUNmO0VBRUEsTUFBTSxLQUFLLFFBQW9CO0FBQzlCLFNBQUssU0FBUztBQUNkLFFBQUksQ0FBQyxLQUFLLGNBQWM7QUFDdkIsV0FBSyxlQUFlLElBQUksYUFBWTtJQUNyQztBQUNBLFNBQUssYUFBYSxlQUFlLEVBQUU7QUFHbkMsU0FBSyxvQkFBb0IsTUFBTSxLQUFLLGFBQWEsZ0JBQWU7QUFDaEUsUUFBSSxLQUFLLGtCQUFrQixXQUFXLEdBQUc7QUFDeEMsTUFBQUEsUUFBTyxLQUFLLHVCQUF1QjtJQUNwQyxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGNBQWMsS0FBSyxrQkFBa0IsTUFBTSxhQUFhO0FBQ3BFLGlCQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdkMsUUFBQUEsUUFBTyxLQUFLLGFBQWEsRUFBRSxLQUFLLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFO01BQ3JFO0FBR0EsaUJBQVcsVUFBVSxLQUFLLG1CQUFtQjtBQUM1QyxZQUFJO0FBQ0gsZ0JBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSx1QkFBdUIsT0FBTyxFQUFFO0FBQ3pFLGlCQUFPLGVBQWU7QUFDdEIsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLGNBQWMsUUFBUSxXQUFXLE9BQU8sYUFBYSxFQUFFO1FBQ3BGLFNBQVMsR0FBRztBQUNYLFVBQUFBLFFBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSw2QkFBNkIsQ0FBQyxFQUFFO0FBQzVELGlCQUFPLGVBQWU7UUFDdkI7TUFDRDtJQUNEO0FBSUEsVUFBTSxpQkFBaUIsYUFBYSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7QUFDdkUsU0FBSyxVQUFVLGNBQWM7QUFHN0IsU0FBSyxhQUFhLG9CQUFvQixDQUFDLGVBQXNCO0FBQzVELFdBQUssZUFBZSxVQUFVO0lBQy9CLENBQUM7QUFHRCxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtBQUd6QixVQUFNLGFBQWEsS0FBSztBQUN4QixRQUFJLFlBQVk7QUFDZixVQUFJO0FBQ0gsY0FBTSxLQUFLLGFBQWEsbUJBQW1CLFVBQVU7TUFDdEQsU0FBUyxHQUFHO0FBQ1gsUUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxVQUFVLEtBQUssQ0FBQyxFQUFFO01BQ2xFO0lBQ0Q7RUFDRDs7RUFHQSxNQUFNLFVBQU87QUFDWixTQUFLLGNBQWMsTUFBSztBQUN4QixJQUFBQSxRQUFPLE1BQU0sU0FBUztFQUN2QjtFQUVBLE1BQU0sY0FBYyxRQUFvQjtBQUN2QyxVQUFNLGVBQWUsS0FBSztBQUMxQixTQUFLLFNBQVM7QUFDZCxVQUFNLGlCQUFpQixhQUFhLFFBQVEsS0FBSyxpQkFBaUI7QUFDbEUsU0FBSyxVQUFVLGNBQWM7QUFHN0IsU0FBSyxjQUFhO0FBQ2xCLFNBQUssZ0JBQWU7QUFDcEIsU0FBSywwQkFBeUI7QUFDOUIsU0FBSyxxQkFBb0I7QUFHekIsVUFBTSxVQUFVLEtBQUs7QUFDckIsUUFBSSxXQUFXLFlBQVksY0FBYztBQUN4QyxVQUFJO0FBQ0gsY0FBTSxLQUFLLGFBQWEsbUJBQW1CLE9BQU87TUFDbkQsU0FBUyxHQUFHO0FBQ1gsUUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxPQUFPLEtBQUssQ0FBQyxFQUFFO01BQy9EO0lBQ0Q7RUFDRDs7RUFHUSxVQUFVLE9BQWE7QUFDOUIsVUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxLQUFLLFVBQVUsS0FBSywrQkFBK0I7QUFDMUQsV0FBSyxhQUFhLFNBQVMsT0FBTyxDQUFBLEdBQUksSUFBSTtBQUMxQztJQUNEO0FBRUEsVUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSSxPQUFPLFlBQVksQ0FBQTtBQUNyRSxVQUFNLHNCQUFzQixPQUFPLHVCQUF1QjtBQUUxRCxTQUFLLGFBQWEsU0FBUyxPQUFPLFNBQVMsbUJBQW1CO0FBQzlELFFBQUksUUFBUSxXQUFXLEdBQUc7QUFDekIsTUFBQUEsUUFBTyxLQUFLLCtCQUErQixLQUFLLDZDQUF3QztJQUN6RixPQUFPO0FBQ04sTUFBQUEsUUFBTyxNQUNOLFVBQVUsUUFBUSxNQUFNLHVCQUF1QixLQUFLLGdCQUFnQixPQUFPLFNBQVMseUJBQXlCLG1CQUFtQixFQUFFO0lBRXBJO0VBQ0Q7Ozs7RUFLQSxrQkFBZTtBQUNkLFdBQU8sZ0JBQWdCLEtBQUssaUJBQWlCO0VBQzlDOztFQUdBLElBQUksT0FBSTtBQUNQLFdBQU8sWUFBWSxLQUFLLE1BQU07RUFDL0I7O0VBR0EsSUFBSSxVQUFPO0FBQ1YsV0FBTyxLQUFLO0VBQ2I7RUFFQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSxrQkFBZTtBQUNkLG9CQUFnQixJQUFJO0VBQ3JCO0VBRUEsNEJBQXlCO0FBQ3hCLDhCQUEwQixJQUFJO0VBQy9CO0VBRUEsdUJBQW9CO0FBQ25CLHlCQUFxQixJQUFJO0VBQzFCOzsiLAogICJuYW1lcyI6IFsicGF0aCIsICJJbnN0YW5jZVN0YXR1cyIsICJSZWdleCIsICJwYXRoIiwgImZzIiwgImxvZ2dlciIsICJsb2dnZXIiLCAiZnMiLCAibG9nZ2VyIiwgImRldmljZXNGb2xkZXIiLCAicGF0aCIsICJsb2dnZXIiLCAiZGdyYW0iLCAib3MiLCAibG9nZ2VyIiwgImxvZ2dlciIsICJkZ3JhbSIsICJvcyIsICJsb2dnZXIiXQp9Cg==
