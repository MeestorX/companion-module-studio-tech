import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path4, args) {
    this.#context.oscSend(host, port, path4, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual" },
    ...discoveredDevices.map((d) => ({
      id: d.ip,
      label: `Model ${d.model} (${d.ip})`
    }))
  ];
  return [
    // ── Device discovery dropdown ────────────────────────────────────────
    // Mirrors the bonjour-device field: selecting a device populates the
    // host automatically; selecting 'Manual' shows the textinput below.
    {
      type: "dropdown",
      id: "discoveredHost",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies Dante device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry ──────────────────────────────────────────────────
    // Only visible when discoveredHost is '' (Manual selected).
    // Matches the pattern from the bonjour-device docs.
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Model selector ───────────────────────────────────────────────────
    // Only visible when Manual mode is selected (no discovered device).
    // When a discovered device is selected, the model is auto-detected.
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:discoveredHost)`,
      tooltip: "Select which Studio Technologies model is active for actions and Get All Settings"
    }
  ];
}
function resolveHost(config) {
  return config.discoveredHost || config.host;
}
function resolveModel(config, discoveredDevices) {
  if (config.discoveredHost) {
    const device = discoveredDevices.find((d) => d.ip === config.discoveredHost);
    logger.debug(`resolveModel: discoveredHost="${config.discoveredHost}", found device: ${device?.model ?? "none"}`);
    if (device?.model) {
      return device.model;
    }
    if (discoveredDevices.length === 0) {
      logger.warn(`resolveModel: No devices discovered, cannot determine model`);
      return "";
    }
  }
  logger.debug(`resolveModel: falling back to activeModel="${config.activeModel}"`);
  return config.activeModel;
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_BUS_GET:
      return "Get Bus Setting";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "textinput":
    case "colorpicker":
    case "static-text":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  for (const { cmd_id, id, valueBytes } of parsed) {
    let action = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (!action) {
      for (const c of candidates) {
        const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
        if (match) {
          action = structuredClone(match);
          action.name = `${match.name} (inferred from Model ${c.model})`;
          logger2.info(`Inferred setting ${toHex(id)} from Model ${c.model}`);
          break;
        }
      }
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown Setting ${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      logger2.warn(`Could not infer setting ${toHex(id)}`);
    } else {
      const opt = action.options?.[0];
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
    }
    const exists = out.cmdSchema.some((a) => a.cmd_id === action.cmd_id && a.id === action.id);
    if (!exists)
      out.cmdSchema.push(action);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("refreshAfterCommand" in jsonObj) {
      orderedObj.refreshAfterCommand = jsonObj.refreshAfterCommand;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema;
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  logger3.info(`UpdateActions: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  wiredActions["global_getAllSettings"] = {
    name: "GLOBAL: Get All Settings (Auto-Update JSON)",
    options: [],
    callback: async () => {
      const model = activeModel;
      const ip = self.host;
      const buf = await self.stController.requestAllSettings(ip);
      let modelJson = getDeviceSchema(model);
      if (!modelJson) {
        logger3.error(`Model ${model} schema not found in cache`);
        return;
      }
      const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
      logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
      if (detectedSectioned !== null) {
        logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
        modelJson = { ...modelJson, sectioned: detectedSectioned };
      }
      const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
      logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
      const devicesFolder2 = getDevicesFolder();
      const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
      saveModelJsonPretty(schemaPath, updated);
      reloadDeviceSchemas();
      logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
    }
  };
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
  logger3.info(`UpdateActions: wired actions: ${Object.keys(wiredActions).length}`);
}

// dist/feedbacks.js
var logger4 = createModuleLogger("Feedbacks");
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  logger4.info(`UpdateFeedbacks: activeModel="${activeModel}", discoveredHost="${self.config.discoveredHost}", devices count=${self.devices.length}`);
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const busCh = feedbackEvent.options["busCh"];
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
  logger4.info(`UpdateFeedbacks: wired feedbacks: ${Object.keys(wiredFeedbacks).length}`);
}

// dist/stcontroller.js
import dgram2 from "dgram";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger5 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger5.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger5.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger5.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger5.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger5.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger5.warn(`Could not join announce multicast group: ${err}`);
      }
    });
  });
}

// dist/stcontroller.js
var logger6 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  constructor() {
    logger6.info("StController initialized");
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger6.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger6.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger6.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger6.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger6.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger6.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger6.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    logger6.debug(`Revoked device at ${ip}`);
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    return new Promise((resolve) => {
      const key = `__probe_${ip}__`;
      let resolved = false;
      const finish = (result) => {
        if (resolved)
          return;
        resolved = true;
        this.discoveryListeners.delete(key);
        resolve(result);
      };
      this.discoveryListeners.set(key, (device) => {
        if (device.ip === ip)
          finish(device);
      });
      const timer = setTimeout(() => finish(null), timeoutMs);
      timer.unref?.();
      const run = async () => {
        await this.ensureMembershipFor(ip);
        await this.txReady;
        const query = buildDanteInfoRequest();
        this.txSocket.send(query, this.defaultPort, ip, (err) => {
          if (err) {
            logger6.warn(`Probe to ${ip} failed: ${err.message}`);
            clearTimeout(timer);
            finish(null);
          }
        });
      };
      run().catch((e) => {
        logger6.warn(`probeDevice setup failed for ${ip}: ${e}`);
        clearTimeout(timer);
        finish(null);
      });
    });
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger6.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger6.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger6.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger6.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger6.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger6.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger6.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger6.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && this.refreshAfterCommand && settingId !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger6.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    if (!this.authorizedIps.has(destIp)) {
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    await this.ensureMembershipFor(destIp);
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (busCh !== void 0)
      payloadBody.push(busCh & 255);
    if (addLen)
      payloadBody.push(dataBlock.length);
    if (dataBlock.length > 0)
      payloadBody.push(...dataBlock);
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger6.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger6.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    logger6.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger6.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger6.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse && originalCmdId === CMD_GET_ALL_SETTINGS) {
      logger6.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
    }
    this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger6.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger6.info(`RX ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, s.id);
              this.feedbackCallback(baseFeedbackKey);
            } else {
              logger6.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger6.debug(`RX ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger6.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    if (decoded) {
      logger6.info(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logger6.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
import path3 from "path";
var logger7 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Ok);
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger7.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger7.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger7.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger7.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger7.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger7.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger7.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger7.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    logger7.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger7.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current host+model combination is authorized.
   * Called on every config change so that switching model or IP is always validated.
   *
   * Rules:
   * - discoveredHost set AND found in current discovery → authorize
   * - discoveredHost set but NOT found in current discovery → revoke (stale config)
   * - manual host → check against discovered list first; probe if unknown
   *   - discovered device at that IP with matching model → authorize
   *   - discovered device at that IP with wrong model → revoke + log error
   *   - not in discovered list → probe; authorize on match, revoke on mismatch/timeout
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.discoveredHost) {
      const foundNow = this.discoveredDevices.find((d) => d.ip === newHost);
      if (!foundNow) {
        logger7.warn(`discoveredHost "${newHost}" was not found in current discovery \u2014 not authorizing`);
        this.stController.revokeDevice(newHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        const model = resolveModel(this.config, this.discoveredDevices);
        await this.fetchSettingsAndEnsureSchema(model, newHost);
      }
      return;
    }
    const manualModel = this.config.activeModel;
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
      } else {
        logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
      }
      return;
    }
    logger7.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger7.error(`No device responded at ${newHost} \u2014 commands blocked`);
    } else if (probed.model !== manualModel) {
      logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
    } else {
      logger7.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      const buf = await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger7.info(`No schema found for Model ${model} \u2014 creating from device response`);
        const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
        if (parsed.length === 0) {
          logger7.warn(`Could not parse settings for Model ${model} \u2014 schema not created`);
          return;
        }
        const schemas = getNormalizedSchemas(getDeviceSchemas());
        const newSchema = { model, sectioned: detectedSectioned ?? false, cmdSchema: [] };
        if (detectedSectioned !== null) {
          newSchema.sectioned = detectedSectioned;
        }
        const updated = updateModelJsonFromSettings(newSchema, parsed, schemas);
        const schemaPath = path3.join(getDevicesFolder(), `Model${model}.json`);
        saveModelJsonPretty(schemaPath, updated);
        reloadDeviceSchemas();
        logger7.info(`Created schema for Model ${model} at ${schemaPath}`);
        this.syncModel(model);
        this.updateActions();
        this.updateFeedbacks();
        this.updateVariableDefinitions();
      }
    } catch (e) {
      logger7.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger7.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, [], true);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    const refreshAfterCommand = schema.refreshAfterCommand ?? true;
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger7.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger7.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}, refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, preferring the discovered device selection. */
  get host() {
    return resolveHost(this.config);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0aG9zdDogc3RyaW5nXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcblx0LyoqIElQIG9mIGEgZGlzY292ZXJlZCBEYW50ZSBkZXZpY2UsIG9yICcnIHdoZW4gdGhlIHVzZXIgY2hvb3NlcyBNYW51YWwgKi9cblx0ZGlzY292ZXJlZEhvc3Q6IHN0cmluZ1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBDRU5UUkFMSVpFRCBERVZJQ0UgU0NIRU1BIENBQ0hFXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBBbGwgZGV2aWNlIEpTT04gZmlsZXMgYXJlIGxvYWRlZCBvbmNlIGludG8gbWVtb3J5IGhlcmUuIE90aGVyIG1vZHVsZXMgc2hvdWxkXG4vLyB1c2UgZ2V0RGV2aWNlc0ZvbGRlcigpLCBnZXREZXZpY2VTY2hlbWFzKCksIGFuZCBnZXREZXZpY2VTY2hlbWEoKSBpbnN0ZWFkIG9mXG4vLyByZWFkaW5nIGZpbGVzIGRpcmVjdGx5LiBDYWxsIHJlbG9hZERldmljZVNjaGVtYXMoKSBhZnRlciB3cml0aW5nIHRvIGEgZmlsZS5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuLyoqXG4gKiBEZXRlcm1pbmVzIHRoZSBjb3JyZWN0IGRldmljZXMgZm9sZGVyIHBhdGggd2l0aCBmYWxsYmFjayBzdXBwb3J0LlxuICogQ2hlY2tzIHByaW1hcnkgcGF0aCBmaXJzdCwgdGhlbiBmYWxsYmFjaywgdGhlbiB0aHJvd3MgZXJyb3IgaWYgbmVpdGhlciBleGlzdHMuXG4gKi9cbmZ1bmN0aW9uIHJlc29sdmVEZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdGNvbnN0IHByaW1hcnlQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuLi9kZXZpY2VzJylcblx0Y29uc3QgZmFsbGJhY2tQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuL2RldmljZXMnKVxuXG5cdC8vIENoZWNrIHByaW1hcnkgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhwcmltYXJ5UGF0aCkpIHtcblx0XHRsb2dnZXIuZGVidWcoYFVzaW5nIGRldmljZXMgZm9sZGVyOiAke3ByaW1hcnlQYXRofWApXG5cdFx0cmV0dXJuIHByaW1hcnlQYXRoXG5cdH1cblxuXHQvLyBDaGVjayBmYWxsYmFjayBwYXRoXG5cdGlmIChmcy5leGlzdHNTeW5jKGZhbGxiYWNrUGF0aCkpIHtcblx0XHRsb2dnZXIud2FybihgUHJpbWFyeSBkZXZpY2VzIGZvbGRlciBub3QgZm91bmQsIHVzaW5nIGZhbGxiYWNrOiAke2ZhbGxiYWNrUGF0aH1gKVxuXHRcdHJldHVybiBmYWxsYmFja1BhdGhcblx0fVxuXG5cdC8vIE5laXRoZXIgcGF0aCBleGlzdHMgLSBmYXRhbCBlcnJvclxuXHRjb25zdCBlcnJvck1zZyA9IGBEZXZpY2VzIGZvbGRlciBub3QgZm91bmQhXFxuVHJpZWQ6XFxuICAtICR7cHJpbWFyeVBhdGh9XFxuICAtICR7ZmFsbGJhY2tQYXRofVxcbk1vZHVsZSBjYW5ub3QgY29udGludWUgd2l0aG91dCBkZXZpY2Ugc2NoZW1hcy5gXG5cdGxvZ2dlci5lcnJvcihlcnJvck1zZylcblx0dGhyb3cgbmV3IEVycm9yKGVycm9yTXNnKVxufVxuXG4vLyBSZXNvbHZlIHRoZSBkZXZpY2VzIGZvbGRlciBwYXRoICh3aXRoIGV4aXN0ZW5jZSBjaGVjayBhbmQgZmFsbGJhY2spXG5jb25zdCBkZXZpY2VzRm9sZGVyID0gcmVzb2x2ZURldmljZXNGb2xkZXIoKVxuXG4vLyBJbi1tZW1vcnkgY2FjaGUgb2YgYWxsIGRldmljZSBzY2hlbWFzLCBrZXllZCBieSBtb2RlbCBudW1iZXJcbmxldCBkZXZpY2VTY2hlbWFzQ2FjaGU6IFJlY29yZDxzdHJpbmcsIGFueT4gfCBudWxsID0gbnVsbFxuXG4vKipcbiAqIFJldHVybnMgdGhlIGFic29sdXRlIHBhdGggdG8gdGhlIGRldmljZXMgZm9sZGVyLlxuICogVXNlIHRoaXMgaW5zdGVhZCBvZiByZWRlZmluaW5nIHRoZSBwYXRoIGluIGV2ZXJ5IGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdHJldHVybiBkZXZpY2VzRm9sZGVyXG59XG5cbi8qKlxuICogTG9hZHMgYWxsIGRldmljZSBKU09OIGZpbGVzIGZyb20gdGhlIGRldmljZXMgZm9sZGVyIGludG8gbWVtb3J5LlxuICogVGhpcyBzaG91bGQgb25seSBiZSBjYWxsZWQgb25jZSBhdCBpbml0aWFsaXphdGlvbiwgb3IgYWZ0ZXIgYSBmaWxlIGlzIHdyaXR0ZW4uXG4gKi9cbmZ1bmN0aW9uIGxvYWREZXZpY2VTY2hlbWFzKCk6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRjb25zdCBzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge31cblx0dHJ5IHtcblx0XHRjb25zdCBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKGRldmljZXNGb2xkZXIpLmZpbHRlcigoZikgPT4gZi5lbmRzV2l0aCgnLmpzb24nKSlcblxuXHRcdGZvciAoY29uc3QgZiBvZiBmaWxlcykge1xuXHRcdFx0Y29uc3QgZnVsbFBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgZilcblx0XHRcdGNvbnN0IGpzb24gPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCwgJ3V0ZjgnKSlcblx0XHRcdGlmIChqc29uPy5tb2RlbCkge1xuXHRcdFx0XHRzY2hlbWFzW1N0cmluZyhqc29uLm1vZGVsKV0gPSBqc29uXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBMb2FkZWQgJHtPYmplY3Qua2V5cyhzY2hlbWFzKS5sZW5ndGh9IGRldmljZSBzY2hlbWFzIGludG8gY2FjaGVgKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmVycm9yKGBGYWlsZWQgdG8gbG9hZCBkZXZpY2Ugc2NoZW1hczogJHtlfWApXG5cdH1cblx0cmV0dXJuIHNjaGVtYXNcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIHRoZSBjYWNoZS5cbiAqIEluaXRpYWxpemVzIHRoZSBjYWNoZSBvbiBmaXJzdCBjYWxsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0aWYgKCFkZXZpY2VTY2hlbWFzQ2FjaGUpIHtcblx0XHRkZXZpY2VTY2hlbWFzQ2FjaGUgPSBsb2FkRGV2aWNlU2NoZW1hcygpXG5cdH1cblx0cmV0dXJuIGRldmljZVNjaGVtYXNDYWNoZVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBzcGVjaWZpYyBkZXZpY2Ugc2NoZW1hIGJ5IG1vZGVsIG51bWJlci5cbiAqIFJldHVybnMgdW5kZWZpbmVkIGlmIHRoZSBtb2RlbCBkb2Vzbid0IGV4aXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsOiBzdHJpbmcpOiBhbnkge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBzY2hlbWFzW21vZGVsXVxufVxuXG4vKipcbiAqIFJlbG9hZHMgYWxsIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay5cbiAqIENhbGwgdGhpcyBhZnRlciB3cml0aW5nIHRvIGEgZGV2aWNlIEpTT04gZmlsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbG9hZERldmljZVNjaGVtYXMoKTogdm9pZCB7XG5cdGxvZ2dlci5pbmZvKCdSZWxvYWRpbmcgZGV2aWNlIHNjaGVtYXMgZnJvbSBkaXNrLi4uJylcblx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBsaXN0IG9mIGF2YWlsYWJsZSBtb2RlbCBudW1iZXJzLCBzb3J0ZWQuXG4gKi9cbmZ1bmN0aW9uIGxvYWRBdmFpbGFibGVNb2RlbHMoKTogc3RyaW5nW10ge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBPYmplY3Qua2V5cyhzY2hlbWFzKS5zb3J0KClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEdldENvbmZpZ0ZpZWxkcyhkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW10pOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdGNvbnN0IG1vZGVscyA9IGxvYWRBdmFpbGFibGVNb2RlbHMoKVxuXG5cdC8vIEJ1aWxkIGNob2ljZXMgbWlycm9yaW5nIHRoZSBib25qb3VyLWRldmljZSBwYXR0ZXJuOlxuXHQvLyAgIGZpcnN0IGVudHJ5IGlzIGFsd2F5cyAnTWFudWFsJyAoZW1wdHkgdmFsdWUpXG5cdC8vICAgdGhlbiBvbmUgZW50cnkgcGVyIGRpc2NvdmVyZWQgZGV2aWNlXG5cdGNvbnN0IGRldmljZUNob2ljZXMgPSBbXG5cdFx0eyBpZDogJycsIGxhYmVsOiAnTWFudWFsJyB9LFxuXHRcdC4uLmRpc2NvdmVyZWREZXZpY2VzLm1hcCgoZCkgPT4gKHtcblx0XHRcdGlkOiBkLmlwLFxuXHRcdFx0bGFiZWw6IGBNb2RlbCAke2QubW9kZWx9ICgke2QuaXB9KWAsXG5cdFx0fSkpLFxuXHRdXG5cblx0cmV0dXJuIFtcblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2aWNlIGRpc2NvdmVyeSBkcm9wZG93biBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBNaXJyb3JzIHRoZSBib25qb3VyLWRldmljZSBmaWVsZDogc2VsZWN0aW5nIGEgZGV2aWNlIHBvcHVsYXRlcyB0aGVcblx0XHQvLyBob3N0IGF1dG9tYXRpY2FsbHk7IHNlbGVjdGluZyAnTWFudWFsJyBzaG93cyB0aGUgdGV4dGlucHV0IGJlbG93LlxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2Rpc2NvdmVyZWRIb3N0Jyxcblx0XHRcdGxhYmVsOiAnRGV2aWNlJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRjaG9pY2VzOiBkZXZpY2VDaG9pY2VzLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCBhbiBhdXRvLWRpc2NvdmVyZWQgU3R1ZGlvIFRlY2hub2xvZ2llcyBEYW50ZSBkZXZpY2UsIG9yIGNob29zZSBNYW51YWwgdG8gZW50ZXIgYW4gSVAgYWRkcmVzcy4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgTWFudWFsIElQIGVudHJ5IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIE9ubHkgdmlzaWJsZSB3aGVuIGRpc2NvdmVyZWRIb3N0IGlzICcnIChNYW51YWwgc2VsZWN0ZWQpLlxuXHRcdC8vIE1hdGNoZXMgdGhlIHBhdHRlcm4gZnJvbSB0aGUgYm9uam91ci1kZXZpY2UgZG9jcy5cblx0XHR7XG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGlkOiAnaG9zdCcsXG5cdFx0XHRsYWJlbDogJ1RhcmdldCBJUCcsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0cmVnZXg6IFJlZ2V4LklQLFxuXHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogYCEkKG9wdGlvbnM6ZGlzY292ZXJlZEhvc3QpYCxcblx0XHRcdHRvb2x0aXA6ICdFbnRlciB0aGUgSVAgYWRkcmVzcyBvZiB0aGUgZGV2aWNlIG1hbnVhbGx5LicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNb2RlbCBzZWxlY3RvciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBPbmx5IHZpc2libGUgd2hlbiBNYW51YWwgbW9kZSBpcyBzZWxlY3RlZCAobm8gZGlzY292ZXJlZCBkZXZpY2UpLlxuXHRcdC8vIFdoZW4gYSBkaXNjb3ZlcmVkIGRldmljZSBpcyBzZWxlY3RlZCwgdGhlIG1vZGVsIGlzIGF1dG8tZGV0ZWN0ZWQuXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnYWN0aXZlTW9kZWwnLFxuXHRcdFx0bGFiZWw6ICdBY3RpdmUgRGV2aWNlIE1vZGVsJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogbW9kZWxzWzBdID8/ICcnLFxuXHRcdFx0Y2hvaWNlczogbW9kZWxzLm1hcCgobW9kZWwpID0+ICh7XG5cdFx0XHRcdGlkOiBtb2RlbCxcblx0XHRcdFx0bGFiZWw6IGBNb2RlbCAke21vZGVsfWAsXG5cdFx0XHR9KSksXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkaXNjb3ZlcmVkSG9zdClgLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCB3aGljaCBTdHVkaW8gVGVjaG5vbG9naWVzIG1vZGVsIGlzIGFjdGl2ZSBmb3IgYWN0aW9ucyBhbmQgR2V0IEFsbCBTZXR0aW5ncycsXG5cdFx0fSxcblx0XVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQIGZyb20gY29uZmlnIFx1MjAxNCBwcmVmZXJzIHRoZSBkaXNjb3ZlcmVkIGRldmljZVxuICogSVAgd2hlbiBvbmUgaXMgc2VsZWN0ZWQsIGZhbGxzIGJhY2sgdG8gdGhlIG1hbnVhbGx5IGVudGVyZWQgaG9zdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVIb3N0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogc3RyaW5nIHtcblx0cmV0dXJuIGNvbmZpZy5kaXNjb3ZlcmVkSG9zdCB8fCBjb25maWcuaG9zdFxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBtb2RlbCBcdTIwMTQgaWYgYSBkaXNjb3ZlcmVkIGRldmljZSBpcyBzZWxlY3RlZCwgZXh0cmFjdHNcbiAqIGl0cyBtb2RlbCBmcm9tIHRoZSBkaXNjb3ZlcmVkRGV2aWNlcyBsaXN0OyBvdGhlcndpc2UgdXNlcyBhY3RpdmVNb2RlbC5cbiAqIFJldHVybnMgZW1wdHkgc3RyaW5nIGlmIG5vIGRldmljZXMgYXJlIGRpc2NvdmVyZWQgYW5kIHVzaW5nIGRpc2NvdmVyZWRIb3N0IG1vZGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlTW9kZWwoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRpc2NvdmVyZWRIb3N0KSB7XG5cdFx0Y29uc3QgZGV2aWNlID0gZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY29uZmlnLmRpc2NvdmVyZWRIb3N0KVxuXHRcdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBkaXNjb3ZlcmVkSG9zdD1cIiR7Y29uZmlnLmRpc2NvdmVyZWRIb3N0fVwiLCBmb3VuZCBkZXZpY2U6ICR7ZGV2aWNlPy5tb2RlbCA/PyAnbm9uZSd9YClcblx0XHRpZiAoZGV2aWNlPy5tb2RlbCkge1xuXHRcdFx0cmV0dXJuIGRldmljZS5tb2RlbFxuXHRcdH1cblx0XHQvLyBJZiB1c2luZyBkaXNjb3ZlcmVkSG9zdCBtb2RlIGJ1dCBubyBkZXZpY2UgZm91bmQsIGRvbid0IGZhbGwgYmFjayB0byBhY3RpdmVNb2RlbFxuXHRcdGlmIChkaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGggPT09IDApIHtcblx0XHRcdGxvZ2dlci53YXJuKGByZXNvbHZlTW9kZWw6IE5vIGRldmljZXMgZGlzY292ZXJlZCwgY2Fubm90IGRldGVybWluZSBtb2RlbGApXG5cdFx0XHRyZXR1cm4gJydcblx0XHR9XG5cdH1cblx0bG9nZ2VyLmRlYnVnKGByZXNvbHZlTW9kZWw6IGZhbGxpbmcgYmFjayB0byBhY3RpdmVNb2RlbD1cIiR7Y29uZmlnLmFjdGl2ZU1vZGVsfVwiYClcblx0cmV0dXJuIGNvbmZpZy5hY3RpdmVNb2RlbFxufVxuIiwgImltcG9ydCB0eXBlIE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcblxuLyoqXG4gKiBEZWZpbmUgQ29tcGFuaW9uIHZhcmlhYmxlcyBmb3IgdGhpcyBtb2R1bGUuXG4gKiBWYXJpYWJsZXMgY2FuIGJlIHVzZWQgdG8gZGlzcGxheSBkeW5hbWljIHN0YXRlIGluIGJ1dHRvbiBsYWJlbHMsIHRyaWdnZXJzLCBldGMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh7XG5cdFx0bW9kZWw6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOdW1iZXInIH0sXG5cdFx0bW9kZWxOYW1lOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTmFtZSAoRnVsbCBEZXNjcmlwdGlvbiknIH0sXG5cdFx0bWFudWZhY3R1cmVyOiB7IG5hbWU6ICdEZXZpY2UgTWFudWZhY3R1cmVyJyB9LFxuXHRcdGZpcm13YXJlOiB7IG5hbWU6ICdEZXZpY2UgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRkYW50ZUZXOiB7IG5hbWU6ICdEYW50ZSBNb2R1bGUgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRtYWM6IHsgbmFtZTogJ0RldmljZSBNQUMgQWRkcmVzcycgfSxcblx0XHRpcDogeyBuYW1lOiAnRGV2aWNlIElQIEFkZHJlc3MnIH0sXG5cdH0pXG59XG5cbmNvbnN0IENMRUFSRURfVkFSSUFCTEVTID0ge1xuXHRtb2RlbDogJycsXG5cdG1vZGVsTmFtZTogJycsXG5cdG1hbnVmYWN0dXJlcjogJycsXG5cdGZpcm13YXJlOiAnJyxcblx0ZGFudGVGVzogJycsXG5cdG1hYzogJycsXG5cdGlwOiAnJyxcbn1cblxuLyoqXG4gKiBVcGRhdGUgdmFyaWFibGUgdmFsdWVzIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaW5mb3JtYXRpb24uXG4gKiBPbmx5IHBvcHVsYXRlcyB2YXJpYWJsZXMgd2hlbiB0aGUgY3VycmVudCBob3N0IGlzIGF1dGhvcml6ZWQuXG4gKiBDbGVhcnMgYWxsIHZhcmlhYmxlcyBpZiB0aGUgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkIG9yIG5vdCBmb3VuZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IGN1cnJlbnRIb3N0ID0gc2VsZi5ob3N0XG5cblx0Ly8gQ2xlYXIgdmFyaWFibGVzIGlmIG5vIGhvc3QgY29uZmlndXJlZCBvciBkZXZpY2UgaXMgbm90IGF1dGhvcml6ZWRcblx0aWYgKCFjdXJyZW50SG9zdCB8fCAhc2VsZi5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKGN1cnJlbnRIb3N0KSkge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoQ0xFQVJFRF9WQVJJQUJMRVMpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBkZXZpY2UgPSBzZWxmLmRldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY3VycmVudEhvc3QpXG5cdGlmIChkZXZpY2UpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdG1vZGVsOiBkZXZpY2UubW9kZWwgfHwgJycsXG5cdFx0XHRtb2RlbE5hbWU6IGRldmljZS5tb2RlbE5hbWUgfHwgJycsXG5cdFx0XHRtYW51ZmFjdHVyZXI6IGRldmljZS5tYW51ZmFjdHVyZXIgfHwgJycsXG5cdFx0XHRmaXJtd2FyZTogZGV2aWNlLmZpcm13YXJlTWFpbiB8fCAnJyxcblx0XHRcdGRhbnRlRlc6IGRldmljZS5kYW50ZUZpcm13YXJlIHx8ICcnLFxuXHRcdFx0bWFjOiBkZXZpY2UubWFjIHx8ICcnLFxuXHRcdFx0aXA6IGRldmljZS5pcCxcblx0XHR9KVxuXHR9IGVsc2Uge1xuXHRcdC8vIEF1dGhvcml6ZWQgYnV0IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgKG1hbnVhbCBJUCB0aGF0IHByb2JlZCBzdWNjZXNzZnVsbHkpXG5cdFx0Ly8gV2Uga25vdyBpdCdzIHRoZSByaWdodCBkZXZpY2UgYnV0IGRvbid0IGhhdmUgZnVsbCBpbmZvIHlldFxuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0Li4uQ0xFQVJFRF9WQVJJQUJMRVMsXG5cdFx0XHRpcDogY3VycmVudEhvc3QsXG5cdFx0fSlcblx0fVxufVxuIiwgImltcG9ydCB0eXBlIHsgQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG5leHBvcnQgY29uc3QgVXBncmFkZVNjcmlwdHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQ8TW9kdWxlQ29uZmlnPltdID0gW1xuXHQvKlxuXHQgKiBQbGFjZSB5b3VyIHVwZ3JhZGUgc2NyaXB0cyBoZXJlXG5cdCAqIFJlbWVtYmVyIHRoYXQgb25jZSBpdCBoYXMgYmVlbiBhZGRlZCBpdCBjYW5ub3QgYmUgcmVtb3ZlZCFcblx0ICovXG5cdC8vIGZ1bmN0aW9uIChjb250ZXh0LCBwcm9wcykge1xuXHQvLyBcdHJldHVybiB7XG5cdC8vIFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHQvLyBcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHQvLyBcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdC8vIFx0fVxuXHQvLyB9LFxuXVxuIiwgImV4cG9ydCB0eXBlIENvbXBhbmlvbklucHV0Q2hvaWNlID0ge1xuXHRpZDogc3RyaW5nIHwgbnVtYmVyXG5cdGxhYmVsOiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgRGV2aWNlU2V0dGluZyA9IHtcblx0dHlwZTogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVmYXVsdDogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhblxuXHRjaG9pY2VzPzogQ29tcGFuaW9uSW5wdXRDaG9pY2VbXVxufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBHZXQgc2V0dGluZyBmcm9tIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0JVU19TRVQgPSAweDA0IC8vIFNldCBzZXR0aW5nIG9uIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0hFQURQSE9ORSA9IDB4MDUgLy8gSGVhZHBob25lIGNvbnRyb2xzIChyZXNlcnZlZCBmb3IgZnV0dXJlIHVzZSlcbmV4cG9ydCBjb25zdCBDTURfQlVUVE9OX01PREUgPSAweDA3IC8vIEJ1dHRvbiBtb2RlIGNvbmZpZ3VyYXRpb24gKHJlc2VydmVkIGZvciBmdXR1cmUgdXNlKVxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kcyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5leHBvcnQgY29uc3QgQ01EX0dFVF9BTExfU0VUVElOR1MgPSAweDBhIC8vIFJlcXVlc3QgYWxsIGN1cnJlbnQgc2V0dGluZ3MgZnJvbSBkZXZpY2VcbmV4cG9ydCBjb25zdCBDTURfU0VUVElOR1NfUFVTSCA9IDB4MGIgLy8gVW5zb2xpY2l0ZWQgc2V0dGluZ3MgdXBkYXRlIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX0RFVl9TUEVDID0gMHgwZCAvLyBEZXZpY2Utc3BlY2lmaWMgc2V0dGluZyBnZXQvc2V0IHdpdGggQUNLXG5leHBvcnQgY29uc3QgQ01EX1JFU0VUX0RFVklDRSA9IDB4MGUgLy8gRmFjdG9yeSByZXNldCBjb21tYW5kXG5leHBvcnQgY29uc3QgQ01EX0dMT0JBTF9NSUNfS0lMTCA9IDB4MTAgLy8gRW1lcmdlbmN5IG1pYyBraWxsIChhbGwgY2hhbm5lbHMpXG5leHBvcnQgY29uc3QgQ01EX01JQ19QUkVfQlVTID0gMHgxMiAvLyBNaWMvcHJlYW1wIHNldHRpbmdzIHBlciBidXMgKGdhaW4sIHBoYW50b20sIGV0YylcbmV4cG9ydCBjb25zdCBDTURfQ0hBTk5FTCA9IDB4MTQgLy8gQ2hhbm5lbC1zcGVjaWZpYyBjb250cm9scyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBDb21tYW5kIE5hbWUgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbW1hbmROYW1lKGNtZElkOiBudW1iZXIpOiBzdHJpbmcge1xuXHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0Y2FzZSBDTURfR0VUX0ZJUk1XQVJFOlxuXHRcdFx0cmV0dXJuICdHZXQgRmlybXdhcmUgVmVyc2lvbidcblx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0cmV0dXJuICdHZXQgQnVzIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfQlVTX1NFVDpcblx0XHRcdHJldHVybiAnU2V0IEJ1cyBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0hFQURQSE9ORTpcblx0XHRcdHJldHVybiAnSGVhZHBob25lIENvbnRyb2wnXG5cdFx0Y2FzZSBDTURfQlVUVE9OX01PREU6XG5cdFx0XHRyZXR1cm4gJ0J1dHRvbiBNb2RlJ1xuXHRcdGNhc2UgQ01EX1NZU1RFTTpcblx0XHRcdHJldHVybiAnU3lzdGVtIENvbW1hbmQnXG5cdFx0Y2FzZSBDTURfR0VUX0FMTF9TRVRUSU5HUzpcblx0XHRcdHJldHVybiAnUmVxdWVzdCBBbGwgU2V0dGluZ3MnXG5cdFx0Y2FzZSBDTURfU0VUVElOR1NfUFVTSDpcblx0XHRcdHJldHVybiAnU2V0dGluZ3MgUHVzaCdcblx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzpcblx0XHRcdHJldHVybiAnTWljL1ByZSBCdXMnXG5cdFx0Y2FzZSBDTURfREVWX1NQRUM6XG5cdFx0XHRyZXR1cm4gJ0RldmljZSBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0NIQU5ORUw6XG5cdFx0XHRyZXR1cm4gJ0NoYW5uZWwgU2V0dGluZydcblx0XHRjYXNlIENNRF9SRVNFVF9ERVZJQ0U6XG5cdFx0XHRyZXR1cm4gJ1Jlc2V0IERldmljZSdcblx0XHRjYXNlIENNRF9HTE9CQUxfTUlDX0tJTEw6XG5cdFx0XHRyZXR1cm4gJ0dsb2JhbCBNaWMgS2lsbCdcblx0XHRkZWZhdWx0OlxuXHRcdFx0cmV0dXJuIGBjbWRfMHgke2NtZElkLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfWBcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSUQgR2VuZXJhdGlvbiBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENyZWF0ZXMgYSBjb25zaXN0ZW50IElEIGZvciBhY3Rpb25zLCBmZWVkYmFja3MsIGFuZCBzdGF0ZSBrZXlzLlxuICogRm9ybWF0OiBgJHttb2RlbH1fJHtjbWRfaWR9XyR7YnVzQ2h9XyR7aWR9YCBmb3IgY29tbWFuZHMgd2l0aCBidXNDaCAoZS5nLiwgXCI1MzA0XzE0XzBfMFwiKVxuICogRm9ybWF0OiBgJHttb2RlbH1fJHtjbWRfaWR9XyR7aWR9YCBmb3IgY29tbWFuZHMgd2l0aG91dCBidXNDaCAoZS5nLiwgXCI1MzA0XzEyX2RcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1ha2VTZXR0aW5nSWQoXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIgfCBzdHJpbmcsXG5cdHNldHRpbmdJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRidXNDaD86IG51bWJlciB8IHN0cmluZyxcbik6IHN0cmluZyB7XG5cdGNvbnN0IGNtZCA9IHR5cGVvZiBjbWRJZCA9PT0gJ251bWJlcicgPyBjbWRJZC50b1N0cmluZygxNikgOiBjbWRJZFxuXHRjb25zdCBpZCA9IHR5cGVvZiBzZXR0aW5nSWQgPT09ICdudW1iZXInID8gc2V0dGluZ0lkLnRvU3RyaW5nKDE2KSA6IHNldHRpbmdJZFxuXG5cdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0Y29uc3QgY2ggPSB0eXBlb2YgYnVzQ2ggPT09ICdudW1iZXInID8gYnVzQ2gudG9TdHJpbmcoMTYpIDogYnVzQ2hcblx0XHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2NofV8ke2lkfWBcblx0fVxuXG5cdHJldHVybiBgJHttb2RlbH1fJHtjbWR9XyR7aWR9YFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSGV4IEZvcm1hdHRpbmcgSGVscGVycyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogQ29udmVydHMgYSBudW1iZXIgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4IGFuZCBwYWRkaW5nLlxuICogQHBhcmFtIHZhbHVlIC0gVGhlIG51bWJlciB0byBjb252ZXJ0XG4gKiBAcGFyYW0gcGFkTGVuZ3RoIC0gTnVtYmVyIG9mIGhleCBkaWdpdHMgdG8gcGFkIHRvIChkZWZhdWx0OiAyKVxuICogQHJldHVybnMgRm9ybWF0dGVkIGhleCBzdHJpbmcgKGUuZy4sIFwiMHgwZFwiLCBcIjB4ZmZcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSGV4KHZhbHVlOiBudW1iZXIsIHBhZExlbmd0aCA9IDIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHt2YWx1ZS50b1N0cmluZygxNikucGFkU3RhcnQocGFkTGVuZ3RoLCAnMCcpfWBcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBhcnJheSBvZiBieXRlcyB0byBhIGhleCBzdHJpbmcgd2l0aCAweCBwcmVmaXguXG4gKiBAcGFyYW0gYnl0ZXMgLSBBcnJheSBvZiBieXRlcyBvciBCdWZmZXJcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGFmZjEyXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBieXRlc1RvSGV4KGJ5dGVzOiBudW1iZXJbXSB8IEJ1ZmZlcik6IHN0cmluZyB7XG5cdHJldHVybiBgMHgke0FycmF5LmZyb20oYnl0ZXMpXG5cdFx0Lm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJyl9YFxufVxuXG4vKipcbiAqIEZvcm1hdHMgUkdCIGNvbG9yIGJ5dGVzIGFzIGEgQ1NTIGhleCBjb2xvciBzdHJpbmcuXG4gKiBAcGFyYW0gciAtIFJlZCBjb21wb25lbnQgKDAtMjU1KVxuICogQHBhcmFtIGcgLSBHcmVlbiBjb21wb25lbnQgKDAtMjU1KVxuICogQHBhcmFtIGIgLSBCbHVlIGNvbXBvbmVudCAoMC0yNTUpXG4gKiBAcmV0dXJucyBDU1MgaGV4IGNvbG9yIHN0cmluZyAoZS5nLiwgXCIjRkYwMEFCXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRSZ2JDb2xvcihyOiBudW1iZXIsIGc6IG51bWJlciwgYjogbnVtYmVyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAjJHtbciwgZywgYl1cblx0XHQubWFwKCh2KSA9PiB2LnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuXHRcdC5qb2luKCcnKVxuXHRcdC50b1VwcGVyQ2FzZSgpfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIFBhcnNpbmcgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBQYXJzZXMgYSBzZXR0aW5nIElEIHN0cmluZyBpbnRvIGl0cyBjb21wb25lbnRzLlxuICogQHBhcmFtIGlkIC0gU2V0dGluZyBJRCBzdHJpbmcgKGUuZy4sIFwiMzkxX2RfMFwiIG9yIFwiNTMwNF8xNF8wXzFcIilcbiAqIEByZXR1cm5zIFBhcnNlZCBjb21wb25lbnRzIHdpdGggaGV4IHN0cmluZ3MgY29udmVydGVkIHRvIG51bWJlcnNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ0lkKGlkOiBzdHJpbmcpOiB7IG1vZGVsOiBzdHJpbmc7IGNtZElkOiBudW1iZXI7IGJhc2VJZDogbnVtYmVyIH0ge1xuXHRjb25zdCBbbW9kZWwsIGNtZElkU3RyLCBpZFN0cl0gPSBpZC5zcGxpdCgnXycpXG5cdHJldHVybiB7XG5cdFx0bW9kZWwsXG5cdFx0Y21kSWQ6IHBhcnNlSW50KGNtZElkU3RyLCAxNiksXG5cdFx0YmFzZUlkOiBwYXJzZUludChpZFN0ciwgMTYpLFxuXHR9XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBNb2RlbCBEaXN0YW5jZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENhbGN1bGF0ZXMgbnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIHR3byBtb2RlbCBudW1iZXJzLlxuICogVXNlZCBmb3IgZmluZGluZyBzaW1pbGFyIG1vZGVscyBmb3Igc2V0dGluZyBpbmZlcmVuY2UuXG4gKiBAcGFyYW0gbW9kZWxBIC0gRmlyc3QgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MVwiKVxuICogQHBhcmFtIG1vZGVsQiAtIFNlY29uZCBtb2RlbCBudW1iZXIgKGUuZy4sIFwiMzkyXCIpXG4gKiBAcmV0dXJucyBOdW1lcmljIGRpc3RhbmNlIGJldHdlZW4gbW9kZWxzLCBvciBJbmZpbml0eSBpZiBlaXRoZXIgaXMgbm9uLW51bWVyaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1vZGVsRGlzdGFuY2UobW9kZWxBOiBzdHJpbmcsIG1vZGVsQjogc3RyaW5nKTogbnVtYmVyIHtcblx0Y29uc3QgbmEgPSBwYXJzZUludChtb2RlbEEucmVwbGFjZSgvXFxEL2csICcnKSwgMTApXG5cdGNvbnN0IG5iID0gcGFyc2VJbnQobW9kZWxCLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRpZiAoTnVtYmVyLmlzTmFOKG5hKSB8fCBOdW1iZXIuaXNOYU4obmIpKSByZXR1cm4gSW5maW5pdHlcblx0cmV0dXJuIE1hdGguYWJzKG5hIC0gbmIpXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBTY2hlbWEgTm9ybWFsaXphdGlvbiBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIE5vcm1hbGl6ZXMgZGV2aWNlIHNjaGVtYXMgdG8gZW5zdXJlIGNtZFNjaGVtYSBpcyBhbHdheXMgYW4gYXJyYXkuXG4gKiBUaGlzIGhlbHBlciBlbGltaW5hdGVzIGR1cGxpY2F0ZSBzY2hlbWEgdHJhbnNmb3JtYXRpb24gY29kZS5cbiAqIEBwYXJhbSBzY2hlbWFzUmF3IC0gUmF3IHNjaGVtYXMgZnJvbSBnZXREZXZpY2VTY2hlbWFzKClcbiAqIEByZXR1cm5zIE5vcm1hbGl6ZWQgc2NoZW1hcyB3aXRoIGd1YXJhbnRlZWQgY21kU2NoZW1hIGFycmF5c1xuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoXG5cdHNjaGVtYXNSYXc6IFJlY29yZDxzdHJpbmcsIGFueT4sXG4pOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4ge1xuXHRjb25zdCBub3JtYWxpemVkOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4gPSB7fVxuXHRmb3IgKGNvbnN0IFttb2RlbCwganNvbl0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hc1JhdykpIHtcblx0XHRub3JtYWxpemVkW21vZGVsXSA9IHtcblx0XHRcdG1vZGVsOiBqc29uLm1vZGVsLFxuXHRcdFx0Y21kU2NoZW1hOiBBcnJheS5pc0FycmF5KGpzb24uY21kU2NoZW1hKSA/IGpzb24uY21kU2NoZW1hIDogW10sXG5cdFx0fVxuXHR9XG5cdHJldHVybiBub3JtYWxpemVkXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBBY3Rpb24gTG9va3VwIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogRmluZHMgYW4gYWN0aW9uL3NldHRpbmcgaW4gdGhlIHNjaGVtYSwgc3VwcG9ydGluZyBib3RoIGV4YWN0IG1hdGNoZXMgYW5kIGlkQWRkIG9mZnNldHMuXG4gKiBUaGlzIGhlbHBlciBlbGltaW5hdGVzIGR1cGxpY2F0ZSBhY3Rpb24gbG9va3VwIGxvZ2ljIGFjcm9zcyBtdWx0aXBsZSBmaWxlcy5cbiAqIEBwYXJhbSBzY2hlbWFzIC0gTm9ybWFsaXplZCBkZXZpY2Ugc2NoZW1hc1xuICogQHBhcmFtIG1vZGVsIC0gRGV2aWNlIG1vZGVsIChlLmcuLCBcIjM5MVwiKVxuICogQHBhcmFtIGNtZElkIC0gQ29tbWFuZCBJRFxuICogQHBhcmFtIHNldHRpbmdJZCAtIFNldHRpbmcgSUQgKG1heSBpbmNsdWRlIGlkQWRkIG9mZnNldClcbiAqIEByZXR1cm5zIE1hdGNoaW5nIGFjdGlvbi9zZXR0aW5nIG9yIHVuZGVmaW5lZFxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZEFjdGlvbkZvclNldHRpbmcoXG5cdHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9Pixcblx0bW9kZWw6IHN0cmluZyxcblx0Y21kSWQ6IG51bWJlcixcblx0c2V0dGluZ0lkOiBudW1iZXIsXG4pOiBhbnkge1xuXHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRpZiAoIXNjaGVtYSB8fCAhQXJyYXkuaXNBcnJheShzY2hlbWEuY21kU2NoZW1hKSkgcmV0dXJuIHVuZGVmaW5lZFxuXG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHMuY21kX2lkID09PSBjbWRJZCAmJiBzLmlkID09PSBzZXR0aW5nSWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2gsIHRyeSB0byBmaW5kIGJhc2UgYWN0aW9uIHdpdGggaWRBZGRcblx0aWYgKCFhY3Rpb24pIHtcblx0XHRhY3Rpb24gPSBzY2hlbWEuY21kU2NoZW1hLmZpbmQoKHM6IGFueSkgPT4ge1xuXHRcdFx0aWYgKHMuY21kX2lkICE9PSBjbWRJZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IHMub3B0aW9ucz8uZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgc2V0dGluZ0lkIG1hdGNoZXMgYmFzZSArIGFueSBpZEFkZCBvZmZzZXRcblx0XHRcdGNvbnN0IG9mZnNldCA9IHNldHRpbmdJZCAtIHMuaWRcblx0XHRcdHJldHVybiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KVxuXHRcdH0pXG5cdH1cblxuXHRyZXR1cm4gYWN0aW9uXG59XG4iLCAiLyoqXG4gKiBidWlsZC1jb21tYW5kcy50c1xuICogLSBVc2VzIGNlbnRyYWxpemVkIGRldmljZSBzY2hlbWEgY2FjaGUgZnJvbSBjb25maWcudHNcbiAqIC0gUHJvZHVjZXMgQ29tcGFuaW9uIGFjdGlvbiBkZWZpbml0aW9ucyBhbmQgZmVlZGJhY2tzXG4gKi9cblxuaW1wb3J0IHtcblx0Q29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMsXG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24sXG5cdENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBtYWtlU2V0dGluZ0lkIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLSBPcHRpb24gQnVpbGRlciAtLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5mdW5jdGlvbiBidWlsZE9wdGlvbihvOiBhbnkpOiBhbnkge1xuXHRjb25zdCBiYXNlID0ge1xuXHRcdHR5cGU6IG8udHlwZSxcblx0XHRpZDogby5pZCxcblx0XHRsYWJlbDogby5sYWJlbCxcblx0XHRkZWZhdWx0OiBvLmRlZmF1bHQsXG5cdFx0dG9vbHRpcDogby50b29sdGlwLFxuXHR9XG5cblx0c3dpdGNoIChvLnR5cGUpIHtcblx0XHRjYXNlICdkcm9wZG93bic6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBjaG9pY2VzOiBvLmNob2ljZXMgPz8gW10gfVxuXG5cdFx0Y2FzZSAnbnVtYmVyJzpcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdC4uLmJhc2UsXG5cdFx0XHRcdG1pbjogby5taW4sXG5cdFx0XHRcdG1heDogby5tYXgsXG5cdFx0XHRcdHN0ZXA6IG8uc3RlcCA/PyAxLFxuXHRcdFx0XHRyYW5nZTogdHJ1ZSxcblx0XHRcdH1cblxuXHRcdGNhc2UgJ2NoZWNrYm94Jzpcblx0XHRcdHJldHVybiB7IC4uLmJhc2UsIGRlZmF1bHQ6IG8uZGVmYXVsdCA/PyBmYWxzZSB9XG5cblx0XHRjYXNlICd0ZXh0aW5wdXQnOlxuXHRcdGNhc2UgJ2NvbG9ycGlja2VyJzpcblx0XHRjYXNlICdzdGF0aWMtdGV4dCc6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIGEuY21kX2lkLCBhLmlkKVxuXG5cdFx0XHRjb25zdCBvcHRpb25zID0gKGEub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHRjb25zdCBhY3Rpb246IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHthLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVBY3Rpb25zICovXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGFjdGlvbnNbYWN0aW9uSWRdID0gYWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvbnNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBGZWVkYmFja3MgLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGZWVkYmFja3MoKTogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgZmVlZGJhY2tzOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3Qgc2V0dGluZyBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0lkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgc2V0dGluZy5jbWRfaWQsIHNldHRpbmcuaWQpXG5cblx0XHRcdC8vIEJ1aWxkIG9wdGlvbnNcblx0XHRcdGNvbnN0IGFsbE9wdGlvbnMgPSAoc2V0dGluZy5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdC8vIEZpbHRlciBvdXQgJ3ZhbHVlJyBvcHRpb24gZm9yIHZhbHVlIGZlZWRiYWNrIChrZWVwIG9ubHkgYnVzQ2gvaWRBZGQpXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbnMgPSBhbGxPcHRpb25zLmZpbHRlcigob3B0OiBhbnkpID0+IG9wdC5pZCAhPT0gJ3ZhbHVlJylcblxuXHRcdFx0Ly8gQWRkIGEgY2hlY2tib3ggb3B0aW9uIHRvIHJldHVybiBsYWJlbCBpbnN0ZWFkIG9mIHZhbHVlXG5cdFx0XHR2YWx1ZU9wdGlvbnMucHVzaCh7XG5cdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0bGFiZWw6ICdTaG93IExhYmVsJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHR9KVxuXG5cdFx0XHQvLyBWYWx1ZSBmZWVkYmFjayBmb3IgYWxsIHNldHRpbmdzIChhcHBlYXJzIGluIFZhcmlhYmxlcyBsaXN0KVxuXHRcdFx0Y29uc3QgdmFsdWVGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHR0eXBlOiAndmFsdWUnLFxuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnM6IHZhbHVlT3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRyZXR1cm4gMFxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRmZWVkYmFja3NbYmFzZUZlZWRiYWNrSWRdID0gdmFsdWVGZWVkYmFja1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IGdldERldmljZXNGb2xkZXIsIGdldERldmljZVNjaGVtYSwgZ2V0RGV2aWNlU2NoZW1hcywgcmVsb2FkRGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuXG5pbXBvcnQgeyBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbiwgc2F2ZU1vZGVsSnNvblByZXR0eSwgdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzIH0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdBY3Rpb25zJylcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUFjdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdBY3Rpb25zID0gYnVpbGRBY3Rpb25zKClcblx0Y29uc3Qgc2NoZW1hcyA9IGdldE5vcm1hbGl6ZWRTY2hlbWFzKHNjaGVtYXNSYXcpXG5cdGNvbnN0IHdpcmVkQWN0aW9uczogYW55ID0ge31cblxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblx0bG9nZ2VyLmluZm8oXG5cdFx0YFVwZGF0ZUFjdGlvbnM6IGFjdGl2ZU1vZGVsPVwiJHthY3RpdmVNb2RlbH1cIiwgZGlzY292ZXJlZEhvc3Q9XCIke3NlbGYuY29uZmlnLmRpc2NvdmVyZWRIb3N0fVwiLCBkZXZpY2VzIGNvdW50PSR7c2VsZi5kZXZpY2VzLmxlbmd0aH1gLFxuXHQpXG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBHTE9CQUw6IEdFVCBBTEwgU0VUVElOR1MgKEFVVE8gSlNPTiBVUERBVEUpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdHdpcmVkQWN0aW9uc1snZ2xvYmFsX2dldEFsbFNldHRpbmdzJ10gPSB7XG5cdFx0bmFtZTogJ0dMT0JBTDogR2V0IEFsbCBTZXR0aW5ncyAoQXV0by1VcGRhdGUgSlNPTiknLFxuXHRcdG9wdGlvbnM6IFtdLFxuXHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRjb25zdCBtb2RlbCA9IGFjdGl2ZU1vZGVsXG5cdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXG5cdFx0XHRjb25zdCBidWYgPSBhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApXG5cblx0XHRcdC8vIFVzZSBjZW50cmFsaXplZCBjYWNoZSB0byBnZXQgdGhlIHNjaGVtYVxuXHRcdFx0bGV0IG1vZGVsSnNvbiA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0XHRcdGlmICghbW9kZWxKc29uKSB7XG5cdFx0XHRcdGxvZ2dlci5lcnJvcihgTW9kZWwgJHttb2RlbH0gc2NoZW1hIG5vdCBmb3VuZCBpbiBjYWNoZWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHQvLyBQYXJzZSB3aXRoIGF1dG8tZGV0ZWN0aW9uXG5cdFx0XHRjb25zdCB7IHNldHRpbmdzOiBwYXJzZWQsIGRldGVjdGVkU2VjdGlvbmVkIH0gPSBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbihtb2RlbCwgYnVmKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBwYXJzZWQgcmVwbHk6ICR7SlNPTi5zdHJpbmdpZnkocGFyc2VkKX1gKVxuXG5cdFx0XHQvLyBJZiB3ZSBhdXRvLWRldGVjdGVkIHRoZSBmb3JtYXQsIGFkZCBpdCB0byB0aGUgSlNPTlxuXHRcdFx0aWYgKGRldGVjdGVkU2VjdGlvbmVkICE9PSBudWxsKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIHNlY3Rpb25lZD0ke2RldGVjdGVkU2VjdGlvbmVkfSwgYWRkaW5nIHRvIG1vZGVsIEpTT05gKVxuXHRcdFx0XHRtb2RlbEpzb24gPSB7IC4uLm1vZGVsSnNvbiwgc2VjdGlvbmVkOiBkZXRlY3RlZFNlY3Rpb25lZCB9XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHVwZGF0ZWQgPSB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MobW9kZWxKc29uLCBwYXJzZWQsIHNjaGVtYXMpXG5cdFx0XHRsb2dnZXIuZGVidWcoYG5ldyBBY3Rpb25zIGpzb246ICR7SlNPTi5zdHJpbmdpZnkodXBkYXRlZCwgbnVsbCwgMil9YClcblxuXHRcdFx0Ly8gU2F2ZSB0aGUgdXBkYXRlZCBKU09OIHRvIGRpc2tcblx0XHRcdGNvbnN0IGRldmljZXNGb2xkZXIgPSBnZXREZXZpY2VzRm9sZGVyKClcblx0XHRcdGNvbnN0IHNjaGVtYVBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgYE1vZGVsJHttb2RlbH0uanNvbmApXG5cdFx0XHRzYXZlTW9kZWxKc29uUHJldHR5KHNjaGVtYVBhdGgsIHVwZGF0ZWQpXG5cblx0XHRcdC8vIFJlbG9hZCB0aGUgY2FjaGUgYWZ0ZXIgd3JpdGluZyB0byBmaWxlXG5cdFx0XHRyZWxvYWREZXZpY2VTY2hlbWFzKClcblxuXHRcdFx0bG9nZ2VyLmluZm8oYE1vZGVsICR7bW9kZWx9IEpTT04gYXV0by11cGRhdGVkIGZyb20gZ2V0QWxsU2V0dGluZ3NgKVxuXHRcdH0sXG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEFDVElPTlMgKEZJTFRFUkVEIEJZIEFDVElWRSBNT0RFTClcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0Zm9yIChjb25zdCBbYWN0aW9uSWQsIGFjdGlvbl0gb2YgT2JqZWN0LmVudHJpZXMocmF3QWN0aW9ucykpIHtcblx0XHRjb25zdCB7IG1vZGVsLCBjbWRJZCwgYmFzZUlkIH0gPSBwYXJzZVNldHRpbmdJZChhY3Rpb25JZClcblxuXHRcdC8vIE9ubHkgaW5jbHVkZSBhY3Rpb25zIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBtb2RlbFxuXHRcdGlmIChtb2RlbCAhPT0gYWN0aXZlTW9kZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBHZXQgdGhlIHJhdyBhY3Rpb24gc2NoZW1hIHRvIGFjY2VzcyBmaXhlZCBidXNDaCB2YWx1ZVxuXHRcdGNvbnN0IHNjaGVtYSA9IHNjaGVtYXNbbW9kZWxdXG5cdFx0Y29uc3QgcmF3QWN0aW9uID0gc2NoZW1hPy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IGJhc2VJZClcblxuXHRcdHdpcmVkQWN0aW9uc1thY3Rpb25JZF0gPSB7XG5cdFx0XHQuLi5hY3Rpb24sXG5cdFx0XHRjYWxsYmFjazogYXN5bmMgKGV2ZW50OiBhbnkpID0+IHtcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBldmVudC5vcHRpb25zWydidXNDaCddICE9PSB1bmRlZmluZWQgPyBldmVudC5vcHRpb25zWydidXNDaCddIDogcmF3QWN0aW9uPy5idXNDaFxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGV2ZW50Lm9wdGlvbnNbJ3ZhbHVlJ11cblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBldmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblxuXHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5zZW5kQXdhaXRBY2soY21kSWQsIGJ1c0NoLCBzZXR0aW5nSWQsIHZhbHVlLCBpcClcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBNSUMgS0lMTCAoT05MWSBJRiBBQ1RJVkUgTU9ERUwgU1VQUE9SVFMgSVQpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRjb25zdCBhY3RpdmVTY2hlbWEgPSBzY2hlbWFzW2FjdGl2ZU1vZGVsXVxuXHRpZiAoYWN0aXZlU2NoZW1hKSB7XG5cdFx0Y29uc3Qgc3VwcG9ydHNNaWNLaWxsID0gKGFjdGl2ZVNjaGVtYS5jbWRTY2hlbWEgPz8gW10pLnNvbWUoKGE6IGFueSkgPT4gYS5uYW1lLmluY2x1ZGVzKCdLaWxsJykpXG5cblx0XHRpZiAoc3VwcG9ydHNNaWNLaWxsKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IGAke2FjdGl2ZU1vZGVsfV9taWNLaWxsYFxuXG5cdFx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHthY3RpdmVNb2RlbH1dIE1pYyBLaWxsYCxcblx0XHRcdFx0b3B0aW9uczogW10sXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgTWljIEtpbGwgXHUyMTkyIE1vZGVsICR7YWN0aXZlTW9kZWx9IEAgJHtpcH1gKVxuXHRcdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLmdsb2JhbE1pY0tpbGwoaXApXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0c2VsZi5zZXRBY3Rpb25EZWZpbml0aW9ucyh3aXJlZEFjdGlvbnMpXG5cblx0bG9nZ2VyLmluZm8oYFVwZGF0ZUFjdGlvbnM6IHdpcmVkIGFjdGlvbnM6ICR7T2JqZWN0LmtleXMod2lyZWRBY3Rpb25zKS5sZW5ndGh9YClcbn1cbiIsICJpbXBvcnQgZnMgZnJvbSAnZnMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWEgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQge1xuXHRDTURfQlVTX1NFVCxcblx0Q01EX0NIQU5ORUwsXG5cdENNRF9ERVZfU1BFQyxcblx0Q01EX0dFVF9BTExfU0VUVElOR1MsXG5cdENNRF9NSUNfUFJFX0JVUyxcblx0Q01EX1NFVFRJTkdTX1BVU0gsXG5cdHRvSGV4LFxuXHRieXRlc1RvSGV4LFxuXHRmb3JtYXRSZ2JDb2xvcixcblx0bW9kZWxEaXN0YW5jZSxcbn0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdTZXR0aW5nc1BhcnNlcicpXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFRZUEVTXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCB0eXBlIFBhcnNlZFNldHRpbmcgPSB7XG5cdGNtZF9pZDogbnVtYmVyXG5cdGlkOiBudW1iZXJcblx0YnVzQ2g/OiBudW1iZXIgLy8gT3B0aW9uYWw6IG9ubHkgcHJlc2VudCBmb3IgY29tbWFuZHMgd2l0aCBidXNDaCAoMHgwNCwgMHgxMiwgMHgxNClcblx0dmFsdWVCeXRlczogbnVtYmVyW11cbn1cblxuZXhwb3J0IHR5cGUgU3RBY3Rpb25PcHRpb24gPSB7XG5cdGlkPzogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0dHlwZTogc3RyaW5nXG5cdGRlZmF1bHQ6IHVua25vd25cblx0dG9vbHRpcD86IHN0cmluZ1xuXHRjaG9pY2VzPzogQXJyYXk8eyBpZDogbnVtYmVyOyBsYWJlbDogc3RyaW5nIH0+XG59XG5cbmV4cG9ydCB0eXBlIFN0QWN0aW9uID0ge1xuXHRjbWRfaWQ6IG51bWJlclxuXHRpZDogbnVtYmVyXG5cdG5hbWU6IHN0cmluZ1xuXHRvcHRpb25zOiBTdEFjdGlvbk9wdGlvbltdXG5cdGJ1c0NoPzogbnVtYmVyIC8vIEZpeGVkIGNoYW5uZWwgdmFsdWUgZm9yIGFjdGlvbnMgdGhhdCBkb24ndCBoYXZlIGEgY2hhbm5lbCBvcHRpb25cbn1cblxuZXhwb3J0IHR5cGUgU3RNb2RlbEpzb24gPSB7XG5cdG1vZGVsOiBzdHJpbmdcblx0c2VjdGlvbmVkPzogYm9vbGVhblxuXHRyZWZyZXNoQWZ0ZXJDb21tYW5kPzogYm9vbGVhblxuXHRjbWRTY2hlbWE6IFN0QWN0aW9uW11cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRk9STUFUIEhFTFBFUlNcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gZ2V0TW9kZWxDb25maWcobW9kZWw6IHN0cmluZyk6IHsgc2VjdGlvbmVkOiBib29sZWFuOyByZ2JJZHM6IFNldDxudW1iZXI+IH0ge1xuXHRjb25zdCByZ2JJZHMgPSBuZXcgU2V0PG51bWJlcj4oKVxuXHRsZXQgc2VjdGlvbmVkID0gZmFsc2VcblxuXHR0cnkge1xuXHRcdC8vIFVzZSBjZW50cmFsaXplZCBjYWNoZSBpbnN0ZWFkIG9mIHJlYWRpbmcgZnJvbSBkaXNrXG5cdFx0Y29uc3QganNvbiA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0XHRpZiAoIWpzb24pIHtcblx0XHRcdC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHNjaGVtYSwgcmV0dXJuIGRlZmF1bHRzXG5cdFx0XHRyZXR1cm4geyBzZWN0aW9uZWQsIHJnYklkcyB9XG5cdFx0fVxuXG5cdFx0Ly8gUmVhZCBzZWN0aW9uZWQgcHJvcGVydHkgKGRlZmF1bHQgdG8gZmFsc2UgaWYgbm90IHNwZWNpZmllZClcblx0XHRzZWN0aW9uZWQgPSBqc29uLnNlY3Rpb25lZCA/PyBmYWxzZVxuXG5cdFx0Ly8gQnVpbGQgUkdCIElEcyBzZXRcblx0XHRmb3IgKGNvbnN0IGFjdGlvbiBvZiBqc29uLmNtZFNjaGVtYSB8fCBbXSkge1xuXHRcdFx0Y29uc3QgaGFzQ29sb3JwaWNrZXIgPSBhY3Rpb24ub3B0aW9ucz8uc29tZSgob3B0OiBTdEFjdGlvbk9wdGlvbikgPT4gb3B0LnR5cGUgPT09ICdjb2xvcnBpY2tlcicpXG5cdFx0XHRpZiAoaGFzQ29sb3JwaWNrZXIpIHtcblx0XHRcdFx0Ly8gQWRkIHRoZSBiYXNlIElEXG5cdFx0XHRcdHJnYklkcy5hZGQoYWN0aW9uLmlkKVxuXG5cdFx0XHRcdC8vIElmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCBjaG9pY2VzLCBhZGQgYWxsIHRoZSBvZmZzZXQgSURzIHRvb1xuXHRcdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdGlmIChpZEFkZE9wdGlvbj8uY2hvaWNlcykge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgY2hvaWNlIG9mIGlkQWRkT3B0aW9uLmNob2ljZXMpIHtcblx0XHRcdFx0XHRcdGlmICh0eXBlb2YgY2hvaWNlLmlkID09PSAnbnVtYmVyJykge1xuXHRcdFx0XHRcdFx0XHRyZ2JJZHMuYWRkKGFjdGlvbi5pZCArIGNob2ljZS5pZClcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH0gY2F0Y2ggKF9lcnIpIHtcblx0XHQvLyBJZiB3ZSBjYW4ndCBsb2FkIHRoZSBzY2hlbWEsIHJldHVybiBkZWZhdWx0c1xuXHR9XG5cblx0cmV0dXJuIHsgc2VjdGlvbmVkLCByZ2JJZHMgfVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGSU5EIFRIRSBSRUFMIDVBIFBBWUxPQUQgSU5ERVhcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1ZjogQnVmZmVyKTogbnVtYmVyIHtcblx0Y29uc3Qgc2lnSW5kZXggPSBidWYuaW5kZXhPZihCdWZmZXIuZnJvbSgnU3R1ZGlvLVQnKSlcblx0aWYgKHNpZ0luZGV4IDwgMCkgdGhyb3cgbmV3IEVycm9yKCdObyBTdHVkaW8tVCBzaWduYXR1cmUgaW4gcGFja2V0JylcblxuXHRjb25zdCBwYXlsb2FkSW5kZXggPSBzaWdJbmRleCArIDhcblx0aWYgKGJ1ZltwYXlsb2FkSW5kZXhdICE9PSAweDVhKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCAweDVBIGFmdGVyIFN0dWRpby1ULCBmb3VuZCAke2J1ZltwYXlsb2FkSW5kZXhdLnRvU3RyaW5nKDE2KX1gKVxuXHR9XG5cblx0cmV0dXJuIHBheWxvYWRJbmRleFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGTEFUIFBBUlNFUlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBwYXJzZUZsYXRJZFZhbFNlcXVlbmNlKGJsb2NrOiBCdWZmZXIsIHJnYklkczogU2V0PG51bWJlcj4gPSBuZXcgU2V0KCkpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRsZXQgcCA9IDBcblx0Y29uc3Qgb3V0OiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdHdoaWxlIChwIDwgYmxvY2subGVuZ3RoKSB7XG5cdFx0Y29uc3QgaWQgPSBibG9ja1twXVxuXHRcdGlmIChwICsgMSA+PSBibG9jay5sZW5ndGgpIGJyZWFrXG5cblx0XHQvLyBSR0IgY2FzZSAtIGNoZWNrIGlmIHRoaXMgSUQgaXMgYSBrbm93biBjb2xvcnBpY2tlclxuXHRcdGlmIChyZ2JJZHMuaGFzKGlkKSAmJiBwICsgMyA8IGJsb2NrLmxlbmd0aCkge1xuXHRcdFx0b3V0LnB1c2goe1xuXHRcdFx0XHRjbWRfaWQ6IENNRF9ERVZfU1BFQyxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdHZhbHVlQnl0ZXM6IFtibG9ja1twICsgMV0sIGJsb2NrW3AgKyAyXSwgYmxvY2tbcCArIDNdXSxcblx0XHRcdH0pXG5cdFx0XHRwICs9IDRcblx0XHRcdGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0b3V0LnB1c2goeyBjbWRfaWQ6IENNRF9ERVZfU1BFQywgaWQsIHZhbHVlQnl0ZXM6IFtibG9ja1twICsgMV1dIH0pXG5cdFx0cCArPSAyXG5cdH1cblxuXHRyZXR1cm4gb3V0XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmOiBCdWZmZXIsIG1vZGVsOiBzdHJpbmcpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ05vdCBhIGdldEFsbFNldHRpbmdzIHJlcGx5Jylcblx0fVxuXG5cdGNvbnN0IGJsb2NrTGVuID0gYnVmW2lkeCArIDJdXG5cdGNvbnN0IHN0YXJ0ID0gaWR4ICsgM1xuXHRjb25zdCBlbmQgPSBzdGFydCArIGJsb2NrTGVuXG5cdGlmIChlbmQgPiBidWYubGVuZ3RoKSB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgYmxvY2sgbGVuZ3RoJylcblxuXHRjb25zdCB7IHJnYklkcyB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cdHJldHVybiBwYXJzZUZsYXRJZFZhbFNlcXVlbmNlKGJ1Zi5zdWJhcnJheShzdGFydCwgZW5kKSwgcmdiSWRzKVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTRUNUSU9ORUQgUEFSU0VSXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Ly8gQ01EX0dFVF9BTExfU0VUVElOR1MgaGFzIGEgdG90YWwtbGVuZ3RoIGJ5dGUgYXQgaWR4KzIgYmVmb3JlIHRoZSBzZWN0aW9uczsgQ01EX1NFVFRJTkdTX1BVU0ggZG9lcyBub3QuXG5cdGxldCBwID0gY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTID8gaWR4ICsgMyA6IGlkeCArIDJcblx0Y29uc3QgZW5kID0gYnVmLmxlbmd0aCAtIDFcblx0Y29uc3Qgb3V0OiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdC8vIEdldCBSR0IgSURzIGZvciB0aGlzIG1vZGVsXG5cdGNvbnN0IHsgcmdiSWRzIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblxuXHQvLyBDb21tYW5kIElEcyB0aGF0IGluY2x1ZGUgYSBidXNDaCBieXRlIGluIHRoZWlyIHNlY3Rpb24gc3RydWN0dXJlXG5cdGNvbnN0IGNvbW1hbmRzV2l0aEJ1c0NoID0gW0NNRF9CVVNfU0VULCBDTURfTUlDX1BSRV9CVVMsIENNRF9DSEFOTkVMXVxuXG5cdHdoaWxlIChwICsgMiA8IGVuZCkge1xuXHRcdGNvbnN0IGNtZExlbiA9IGJ1ZltwXVxuXHRcdGNvbnN0IHNlY3Rpb25DbWRJZCA9IGJ1ZltwICsgMV1cblxuXHRcdGNvbnN0IHNlY3Rpb25FbmQgPSBwICsgMSArIGNtZExlblxuXHRcdGlmIChzZWN0aW9uRW5kID4gZW5kKSBicmVha1xuXG5cdFx0Ly8gQ2hlY2sgaWYgdGhpcyBjb21tYW5kIGluY2x1ZGVzIGEgYnVzQ2ggYnl0ZVxuXHRcdGNvbnN0IGhhc0J1c0NoID0gY29tbWFuZHNXaXRoQnVzQ2guaW5jbHVkZXMoc2VjdGlvbkNtZElkKVxuXG5cdFx0bGV0IGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWRcblx0XHRsZXQgZGF0YUxlbjogbnVtYmVyXG5cdFx0bGV0IHE6IG51bWJlclxuXG5cdFx0aWYgKGhhc0J1c0NoKSB7XG5cdFx0XHQvLyBTdHJ1Y3R1cmU6IFtjbWRMZW5dIFtjbWRJZF0gW2J1c0NoXSBbZGF0YUxlbl0gW2lkOnZhbCBwYWlyc11cblx0XHRcdGJ1c0NoID0gYnVmW3AgKyAyXVxuXHRcdFx0ZGF0YUxlbiA9IGJ1ZltwICsgM11cblx0XHRcdHEgPSBwICsgNCAvLyBEYXRhIHN0YXJ0cyBhZnRlciBjbWRMZW4sIGNtZElkLCBidXNDaCwgZGF0YUxlblxuXHRcdH0gZWxzZSB7XG5cdFx0XHQvLyBTdHJ1Y3R1cmU6IFtjbWRMZW5dIFtjbWRJZF0gW2RhdGFMZW5dIFtpZDp2YWwgcGFpcnNdXG5cdFx0XHRkYXRhTGVuID0gYnVmW3AgKyAyXVxuXHRcdFx0cSA9IHAgKyAzIC8vIERhdGEgc3RhcnRzIGFmdGVyIGNtZExlbiwgY21kSWQsIGRhdGFMZW5cblx0XHR9XG5cblx0XHRjb25zdCBxRW5kID0gcSArIGRhdGFMZW5cblxuXHRcdHdoaWxlIChxICsgMSA8IHFFbmQpIHtcblx0XHRcdGNvbnN0IGlkID0gYnVmW3FdXG5cdFx0XHRsZXQgdmFsdWVCeXRlczogbnVtYmVyW11cblxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBJRCBpcyBhbiBSR0IgY29sb3JwaWNrZXIgKG5lZWRzIDMgYnl0ZXMpXG5cdFx0XHRpZiAocmdiSWRzLmhhcyhpZCkgJiYgcSArIDMgPCBxRW5kKSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXSwgYnVmW3EgKyAyXSwgYnVmW3EgKyAzXV1cblx0XHRcdFx0cSArPSA0XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV1dXG5cdFx0XHRcdHEgKz0gMlxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IHNlY3Rpb25DbWRJZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdH1cblx0XHRcdG91dC5wdXNoKHNldHRpbmcpXG5cdFx0fVxuXG5cdFx0cCA9IHNlY3Rpb25FbmRcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgR0VORVJJQyBTRVRUSU5HUyBSRVNQT05TRSBQQVJTRVIgKDB4MGEgZ2V0LWFsbCArIDB4MGIgdW5zb2xpY2l0ZWQgcHVzaClcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBQYXJzZXMgYW55IGZ1bGwgc2V0dGluZ3MgYmxvY2sgcmVnYXJkbGVzcyBvZiB3aGV0aGVyIHRoZSBjbWRJZCBpcyAweDBhXG4gKiAocmVzcG9uc2UgdG8gR2V0IEFsbCBTZXR0aW5ncykgb3IgMHgwYiAodW5zb2xpY2l0ZWQgcHVzaCBhZnRlciBhIHNldCkuXG4gKiBCb3RoIHVzZSB0aGUgc2FtZSBzZWN0aW9uZWQgb3IgZmxhdCBibG9jayBsYXlvdXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdzUmVzcG9uc2UobW9kZWw6IHN0cmluZywgYnVmOiBCdWZmZXIpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYE5vdCBhIHNldHRpbmdzIGJsb2NrIChjbWRJZD0weCR7Y21kSWQudG9TdHJpbmcoMTYpfSlgKVxuXHR9XG5cdGNvbnN0IHsgc2VjdGlvbmVkIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHNlY3Rpb25lZCA/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpIDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG59XG5cbi8qKlxuICogRm9ybWF0cyBhIHNpbmdsZSBwYXJzZWQgc2V0dGluZyBpbnRvIGEgaHVtYW4tcmVhZGFibGUgc3RyaW5nIHVzaW5nIGFjdGlvblxuICogZGVmaW5pdGlvbnMgZnJvbSB0aGUgZGV2aWNlIEpTT04uIEZhbGxzIGJhY2sgdG8gaGV4IElEcyB3aGVuIHVua25vd24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmc6IFBhcnNlZFNldHRpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiBzdHJpbmcge1xuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IHNldHRpbmcuY21kX2lkICYmIGEuaWQgPT09IHNldHRpbmcuaWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2ggYW5kIGlkID4gYmFzZSBpZCwgdHJ5IHRvIGZpbmQgYWN0aW9uIHdpdGggaWRBZGQgb3B0aW9uXG5cdC8vIFRoaXMgaGFuZGxlcyBjYXNlcyBsaWtlIENNRF9IRUFEUEhPTkUgKDB4MDUsIGUuZy4gUGhvbmVzIFJvdXRpbmcpIGFuZFxuXHQvLyBDTURfQlVUVE9OX01PREUgKDB4MDcsIGUuZy4gQnV0dG9ucykgd2hlcmUgaWQgMC0zIHJlcHJlc2VudHMgY2hhbm5lbHMgMS00XG5cdGlmICghYWN0aW9uKSB7XG5cdFx0Y29uc3QgYmFzZUFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBzZXR0aW5nLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIGFjdGlvbiBoYXMgYW4gaWRBZGQgb3B0aW9uIChpbmRpY2F0aW5nIGNoYW5uZWwgc2VsZWN0aW9uKVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGUgc2V0dGluZy5pZCBvZmZzZXQgbWF0Y2hlcyBvbmUgb2YgdGhlIGlkQWRkIGNob2ljZSBJRHNcblx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYS5pZFxuXHRcdFx0cmV0dXJuIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHR9KVxuXHRcdGlmIChiYXNlQWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSBiYXNlQWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0Y29uc3QgY21kSGV4ID0gdG9IZXgoc2V0dGluZy5jbWRfaWQpXG5cdGNvbnN0IGlkSGV4ID0gdG9IZXgoc2V0dGluZy5pZClcblx0Y29uc3QgdmFsSGV4ID0gYnl0ZXNUb0hleChzZXR0aW5nLnZhbHVlQnl0ZXMpXG5cdGNvbnN0IHZhbERlYyA9XG5cdFx0c2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0PyBmb3JtYXRSZ2JDb2xvcihzZXR0aW5nLnZhbHVlQnl0ZXNbMF0sIHNldHRpbmcudmFsdWVCeXRlc1sxXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzJdKVxuXHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxXG5cdFx0XHRcdD8gc2V0dGluZy52YWx1ZUJ5dGVzWzBdXG5cdFx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmpvaW4oJywnKVxuXG5cdC8vIEJ1aWxkIHRoZSBwcmVmaXg6IGNtZDoweDEyIGNoOjAgaWQ6MHgwMSB2YWw6MHgxNCAoY2ggb25seSBmb3IgY29tbWFuZHMgd2l0aCBidXNDaClcblx0Y29uc3QgYnVzQ2hTdHIgPSBzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQgPyBgIGNoOiR7c2V0dGluZy5idXNDaH1gIDogJydcblx0Y29uc3QgcHJlZml4ID0gYGNtZDoke2NtZEhleH0ke2J1c0NoU3RyfSBpZDoke2lkSGV4fSB2YWw6JHt2YWxIZXh9YFxuXG5cdC8vIElmIHdlIGhhdmUgYW4gYWN0aW9uIHdpdGggYSBuYW1lIGFuZCBjaG9pY2UgbGFiZWwsIHVzZSBpdFxuXHRpZiAoYWN0aW9uKSB7XG5cdFx0bGV0IG5hbWUgPSBhY3Rpb24ubmFtZVxuXG5cdFx0Ly8gSWYgc2V0dGluZyBoYXMgYnVzQ2gsIGFkZCBjaGFubmVsIGluZm8gdG8gbmFtZVxuXHRcdGlmIChzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdG5hbWUgPSBgJHtuYW1lfSBDaCR7c2V0dGluZy5idXNDaCArIDF9YFxuXHRcdH1cblx0XHQvLyBPdGhlcndpc2UsIGlmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCwgaW5jbHVkZSB0aGUgaWRBZGQgbGFiZWxcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYWN0aW9uLmlkXG5cdFx0XHRcdGNvbnN0IGlkQWRkQ2hvaWNlID0gaWRBZGRPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdFx0XHRpZiAoaWRBZGRDaG9pY2UpIHtcblx0XHRcdFx0XHRuYW1lID0gYCR7bmFtZX0gJHtpZEFkZENob2ljZS5sYWJlbH1gXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBMb29rIGZvciB0aGUgdmFsdWUgb3B0aW9uIChub3QgYnVzQ2ggb3IgaWRBZGQpXG5cdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdFx0aWYgKHZhbHVlT3B0aW9uPy5jaG9pY2VzICYmIHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRcdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gc2V0dGluZy52YWx1ZUJ5dGVzWzBdKVxuXHRcdFx0aWYgKGNob2ljZSkge1xuXHRcdFx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7Y2hvaWNlLmxhYmVsfSAoJHt2YWxEZWN9KWBcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke3ZhbERlY31gXG5cdH1cblxuXHQvLyBObyBhY3Rpb24gZm91bmQgLSBqdXN0IHNob3cgdGhlIHJhdyB2YWx1ZXNcblx0cmV0dXJuIGAke3ByZWZpeH0gfCBVbmtub3duIFNldHRpbmdgXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFBBUlNFUiBESVNQQVRDSCBXSVRIIEFVVE8tREVURUNUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogUGFyc2VzIGdldEFsbFNldHRpbmdzIHJlc3BvbnNlIHdpdGggYXV0b21hdGljIGZvcm1hdCBkZXRlY3Rpb24uXG4gKlxuICogU3RyYXRlZ3k6XG4gKiAxLiBJZiBtb2RlbCBoYXMgZXhwbGljaXQgXCJzZWN0aW9uZWRcIiBwcm9wZXJ0eSwgdXNlIHRoYXRcbiAqIDIuIE90aGVyd2lzZSwgdHJ5IEZMQVQgcGFyc2VyIGZpcnN0IChpdCdzIHNpbXBsZXIpXG4gKiAzLiBJZiBGTEFUIHJldHVybnMgMCBzZXR0aW5ncywgdHJ5IFNFQ1RJT05FRCBwYXJzZXJcbiAqIDQuIFVzZSB3aGljaGV2ZXIgcGFyc2VyIHJldHVybnMgbW9yZSBzZXR0aW5nc1xuICpcbiAqIEByZXR1cm5zIHtzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdLCBkZXRlY3RlZFNlY3Rpb25lZDogYm9vbGVhbiB8IG51bGx9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbihcblx0bW9kZWw6IHN0cmluZyxcblx0YnVmOiBCdWZmZXIsXG4pOiB7IHNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW107IGRldGVjdGVkU2VjdGlvbmVkOiBib29sZWFuIHwgbnVsbCB9IHtcblx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRjb25zdCBkZWNsYXJlZFNlY3Rpb25lZCA9IHNjaGVtYT8uc2VjdGlvbmVkXG5cblx0Ly8gSWYgZXhwbGljaXRseSBkZWNsYXJlZCBpbiBKU09OLCB1c2UgdGhhdFxuXHRpZiAoZGVjbGFyZWRTZWN0aW9uZWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IHNldHRpbmdzID0gZGVjbGFyZWRTZWN0aW9uZWRcblx0XHRcdD8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbClcblx0XHRcdDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiBudWxsIH0gLy8gbnVsbCA9IHVzZWQgZGVjbGFyZWQgdmFsdWVcblx0fVxuXG5cdC8vIE5vIGRlY2xhcmF0aW9uIC0gdHJ5IGJvdGggcGFyc2VycyBhbmQgcGljayB0aGUgYmVzdCBvbmVcblx0bGV0IGZsYXRTZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdID0gW11cblx0bGV0IHNlY3Rpb25lZFNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdHRyeSB7XG5cdFx0ZmxhdFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZGVidWcoYEZsYXQgcGFyc2VyIGZhaWxlZDogJHtlfWApXG5cdH1cblxuXHR0cnkge1xuXHRcdHNlY3Rpb25lZFNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5kZWJ1ZyhgU2VjdGlvbmVkIHBhcnNlciBmYWlsZWQ6ICR7ZX1gKVxuXHR9XG5cblx0Ly8gUGljayB0aGUgcGFyc2VyIHRoYXQgcmV0dXJuZWQgbW9yZSBzZXR0aW5nc1xuXHRpZiAoc2VjdGlvbmVkU2V0dGluZ3MubGVuZ3RoID4gZmxhdFNldHRpbmdzLmxlbmd0aCkge1xuXHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIFNFQ1RJT05FRCBmb3JtYXQgKHNlY3Rpb25lZD0ke3NlY3Rpb25lZFNldHRpbmdzLmxlbmd0aH0gdnMgZmxhdD0ke2ZsYXRTZXR0aW5ncy5sZW5ndGh9KWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IHNlY3Rpb25lZFNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogdHJ1ZSB9XG5cdH0gZWxzZSBpZiAoZmxhdFNldHRpbmdzLmxlbmd0aCA+IDApIHtcblx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBGTEFUIGZvcm1hdCAoZmxhdD0ke2ZsYXRTZXR0aW5ncy5sZW5ndGh9IHZzIHNlY3Rpb25lZD0ke3NlY3Rpb25lZFNldHRpbmdzLmxlbmd0aH0pYClcblx0XHRyZXR1cm4geyBzZXR0aW5nczogZmxhdFNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogZmFsc2UgfVxuXHR9IGVsc2Uge1xuXHRcdC8vIEJvdGggcGFyc2VycyByZXR1cm5lZCAwIHNldHRpbmdzXG5cdFx0bG9nZ2VyLndhcm4oYFdhcm5pbmc6IEJvdGggcGFyc2VycyByZXR1cm5lZCAwIHNldHRpbmdzIGZvciBtb2RlbCAke21vZGVsfWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IFtdLCBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9XG5cdH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbChtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IHsgc2VjdGlvbmVkIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHNlY3Rpb25lZCA/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpIDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG59XG5cbi8qIFx1MjcwNSBiYWNrd2FyZC1jb21wYXRpYmxlIGV4cG9ydCAqL1xuZXhwb3J0IGNvbnN0IHBhcnNlR2V0QWxsU2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWxcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVkFMVUUgXHUyMTkyIE9QVElPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlczogbnVtYmVyW10pOiBTdEFjdGlvbk9wdGlvbiB7XG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdHJldHVybiB7IGlkOiAndmFsdWUnLCBsYWJlbDogJ1ZhbHVlJywgdHlwZTogJ251bWJlcicsIGRlZmF1bHQ6IHZhbHVlQnl0ZXNbMF0gfVxuXHR9XG5cblx0aWYgKHZhbHVlQnl0ZXMubGVuZ3RoID09PSAzKSB7XG5cdFx0Y29uc3QgW3IsIGcsIGJdID0gdmFsdWVCeXRlc1xuXHRcdHJldHVybiB7XG5cdFx0XHRpZDogJ3ZhbHVlJyxcblx0XHRcdGxhYmVsOiAnQ29sb3InLFxuXHRcdFx0dHlwZTogJ2NvbG9ycGlja2VyJyxcblx0XHRcdGRlZmF1bHQ6IGZvcm1hdFJnYkNvbG9yKHIsIGcsIGIpLFxuXHRcdH1cblx0fVxuXG5cdHJldHVybiB7IGlkOiAndmFsdWUnLCBsYWJlbDogJ1ZhbHVlJywgdHlwZTogJ3JhdycsIGRlZmF1bHQ6IFsuLi52YWx1ZUJ5dGVzXSB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNNQVJUIEpTT04gVVBEQVRFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MoXG5cdG1vZGVsSnNvbjogU3RNb2RlbEpzb24sXG5cdHBhcnNlZDogUGFyc2VkU2V0dGluZ1tdLFxuXHRhbGxNb2RlbHM6IFJlY29yZDxzdHJpbmcsIFN0TW9kZWxKc29uPixcbik6IFN0TW9kZWxKc29uIHtcblx0Y29uc3Qgb3V0ID0gc3RydWN0dXJlZENsb25lKG1vZGVsSnNvbilcblxuXHQvLyBFbnN1cmUgY21kU2NoZW1hIGFycmF5IGV4aXN0c1xuXHRpZiAoIW91dC5jbWRTY2hlbWEpIHtcblx0XHRvdXQuY21kU2NoZW1hID0gW11cblx0fVxuXG5cdC8vIFNvcnQgb3RoZXIgbW9kZWxzIGJ5IG51bWVyaWMgZGlzdGFuY2UgdG8gY3VycmVudCBtb2RlbFxuXHRjb25zdCBjYW5kaWRhdGVzID0gT2JqZWN0LnZhbHVlcyhhbGxNb2RlbHMpXG5cdFx0LmZpbHRlcigobSkgPT4gbS5tb2RlbCAhPT0gbW9kZWxKc29uLm1vZGVsKSAvLyBleGNsdWRlIHNlbGZcblx0XHQuc29ydCgoYSwgYikgPT4gbW9kZWxEaXN0YW5jZShtb2RlbEpzb24ubW9kZWwsIGEubW9kZWwpIC0gbW9kZWxEaXN0YW5jZShtb2RlbEpzb24ubW9kZWwsIGIubW9kZWwpKVxuXG5cdGxvZ2dlci5pbmZvKGBVcGRhdGluZyBtb2RlbDogJHttb2RlbEpzb24ubW9kZWx9YClcblx0bG9nZ2VyLmRlYnVnKGBDYW5kaWRhdGVzIGZvciBpbmZlcmVuY2U6ICR7Y2FuZGlkYXRlcy5tYXAoKGMpID0+IGMubW9kZWwpLmpvaW4oJywgJyl9YClcblxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCwgdmFsdWVCeXRlcyB9IG9mIHBhcnNlZCkge1xuXHRcdGxldCBhY3Rpb24gPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0Ly8gVHJ5IGNhbmRpZGF0ZXMgaW4gb3JkZXIgb2YgcHJveGltaXR5XG5cdFx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0XHRjb25zdCBtYXRjaCA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdFx0XHRpZiAobWF0Y2gpIHtcblx0XHRcdFx0XHRhY3Rpb24gPSBzdHJ1Y3R1cmVkQ2xvbmUobWF0Y2gpXG5cdFx0XHRcdFx0YWN0aW9uLm5hbWUgPSBgJHttYXRjaC5uYW1lfSAoaW5mZXJyZWQgZnJvbSBNb2RlbCAke2MubW9kZWx9KWBcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgSW5mZXJyZWQgc2V0dGluZyAke3RvSGV4KGlkKX0gZnJvbSBNb2RlbCAke2MubW9kZWx9YClcblx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWYgKCFhY3Rpb24pIHtcblx0XHRcdGFjdGlvbiA9IHtcblx0XHRcdFx0Y21kX2lkLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0bmFtZTogYFVua25vd24gU2V0dGluZyAke3RvSGV4KGlkKS50b1VwcGVyQ2FzZSgpfWAsXG5cdFx0XHRcdG9wdGlvbnM6IFt2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcyldLFxuXHRcdFx0fVxuXHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBpbmZlciBzZXR0aW5nICR7dG9IZXgoaWQpfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGNvbnN0IG9wdCA9IGFjdGlvbi5vcHRpb25zPy5bMF1cblx0XHRcdGlmIChvcHQpIG9wdC5kZWZhdWx0ID0gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpLmRlZmF1bHRcblx0XHR9XG5cblx0XHQvLyBBdm9pZCBkdXBsaWNhdGVzXG5cdFx0Y29uc3QgZXhpc3RzID0gb3V0LmNtZFNjaGVtYS5zb21lKChhKSA9PiBhLmNtZF9pZCA9PT0gYWN0aW9uLmNtZF9pZCAmJiBhLmlkID09PSBhY3Rpb24uaWQpXG5cdFx0aWYgKCFleGlzdHMpIG91dC5jbWRTY2hlbWEucHVzaChhY3Rpb24pXG5cdH1cblxuXHRyZXR1cm4gb3V0XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNBVkVcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHNhdmVNb2RlbEpzb25QcmV0dHkoZmlsZVBhdGg6IHN0cmluZywganNvbk9iajogU3RNb2RlbEpzb24pOiB2b2lkIHtcblx0dHJ5IHtcblx0XHQvLyBFbnN1cmUgcHJvcGVyIGtleSBvcmRlcmluZzogbW9kZWwsIHNlY3Rpb25lZCAoaWYgcHJlc2VudCksIHJlZnJlc2hBZnRlckNvbW1hbmQsIGNtZFNjaGVtYVxuXHRcdGNvbnN0IG9yZGVyZWRPYmo6IGFueSA9IHsgbW9kZWw6IGpzb25PYmoubW9kZWwgfVxuXG5cdFx0Ly8gQWRkIHNlY3Rpb25lZCBrZXkgaWYgcHJlc2VudCAocmlnaHQgYWZ0ZXIgbW9kZWwpXG5cdFx0aWYgKCdzZWN0aW9uZWQnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmouc2VjdGlvbmVkID0ganNvbk9iai5zZWN0aW9uZWRcblx0XHR9XG5cblx0XHQvLyBBZGQgb3RoZXIga2V5cyBpbiBvcmRlclxuXHRcdGlmICgncmVmcmVzaEFmdGVyQ29tbWFuZCcgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5yZWZyZXNoQWZ0ZXJDb21tYW5kID0ganNvbk9iai5yZWZyZXNoQWZ0ZXJDb21tYW5kXG5cdFx0fVxuXHRcdGlmICgnY21kU2NoZW1hJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLmNtZFNjaGVtYSA9IGpzb25PYmouY21kU2NoZW1hXG5cdFx0fVxuXHRcdC8vIENvcHkgYW55IG90aGVyIGtleXMgdGhhdCBtaWdodCBleGlzdFxuXHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGpzb25PYmopKSB7XG5cdFx0XHRpZiAoIShrZXkgaW4gb3JkZXJlZE9iaikpIHtcblx0XHRcdFx0b3JkZXJlZE9ialtrZXldID0gKGpzb25PYmogYXMgYW55KVtrZXldXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ3VzdG9tIGZvcm1hdHRlcjoga2VlcCBjaG9pY2Ugb2JqZWN0cyBjb21wYWN0IG9uIG9uZSBsaW5lXG5cdFx0bGV0IGpzb24gPSBKU09OLnN0cmluZ2lmeShvcmRlcmVkT2JqLCBudWxsLCAyKVxuXG5cdFx0Ly8gUmVwbGFjZSBleHBhbmRlZCBjaG9pY2Ugb2JqZWN0cyB3aXRoIGNvbXBhY3Qgc2luZ2xlLWxpbmUgZm9ybWF0XG5cdFx0Ly8gTWF0Y2hlczoge1xcbiAgICAgICAgICAgIFwiaWRcIjogWCxcXG4gICAgICAgICAgICBcImxhYmVsXCI6IFwiWVwiXFxuICAgICAgICAgIH1cblx0XHQvLyBSZXBsYWNlcyB3aXRoOiB7IFwiaWRcIjogWCwgXCJsYWJlbFwiOiBcIllcIiB9XG5cdFx0anNvbiA9IGpzb24ucmVwbGFjZSgvXFx7XFxuXFxzK1wiaWRcIjpcXHMqKFxcZCspLFxcblxccytcImxhYmVsXCI6XFxzKlwiKFteXCJdKilcIlxcblxccytcXH0vZywgJ3sgXCJpZFwiOiAkMSwgXCJsYWJlbFwiOiBcIiQyXCIgfScpXG5cblx0XHRmcy53cml0ZUZpbGVTeW5jKGZpbGVQYXRoLCBqc29uICsgJ1xcbicsICd1dGY4Jylcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmlsZSBXcml0ZSBFcnJvcjogJHtlfWApXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgTE9BRCBERVZJQ0UgSlNPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIExvYWRzIHRoZSBhY3Rpb25zIGFycmF5IGZvciBhIGdpdmVuIG1vZGVsIGZyb20gdGhlIGNlbnRyYWxpemVkIGNhY2hlLlxuICogUmV0dXJucyBhbiBlbXB0eSBhcnJheSBpZiB0aGUgbW9kZWwgaXMgbm90IGZvdW5kLlxuICogQGRlcHJlY2F0ZWQgLSBUaGlzIGZ1bmN0aW9uIGlzIG5vIGxvbmdlciBuZWVkZWQuIFVzZSBnZXREZXZpY2VTY2hlbWEoKSBmcm9tIGNvbmZpZy50cyBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZEFjdGlvbnNGb3JNb2RlbChfZGV2aWNlc0ZvbGRlcjogc3RyaW5nLCBtb2RlbDogc3RyaW5nKTogU3RBY3Rpb25bXSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0cmV0dXJuIHNjaGVtYT8uY21kU2NoZW1hID8/IFtdXG59XG5cbi8qKlxuICogTG9hZHMgdGhlIG1vZGVsIGNvbmZpZ3VyYXRpb24gZnJvbSB0aGUgY2VudHJhbGl6ZWQgY2FjaGUuXG4gKiBAZGVwcmVjYXRlZCAtIFRoaXMgZnVuY3Rpb24gaXMgbm8gbG9uZ2VyIG5lZWRlZC4gVXNlIGdldERldmljZVNjaGVtYSgpIGZyb20gY29uZmlnLnRzIGluc3RlYWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsb2FkTW9kZWxDb25maWcoXG5cdF9kZXZpY2VzRm9sZGVyOiBzdHJpbmcsXG5cdG1vZGVsOiBzdHJpbmcsXG4pOiB7IGFjdGlvbnM6IFN0QWN0aW9uW107IHJlZnJlc2hBZnRlckNvbW1hbmQ6IGJvb2xlYW4gfSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0cmV0dXJuIHtcblx0XHRhY3Rpb25zOiBzY2hlbWE/LmNtZFNjaGVtYSA/PyBbXSxcblx0XHRyZWZyZXNoQWZ0ZXJDb21tYW5kOiBzY2hlbWE/LnJlZnJlc2hBZnRlckNvbW1hbmQgPz8gdHJ1ZSwgLy8gRGVmYXVsdCB0byB0cnVlIGlmIG5vdCBzcGVjaWZpZWRcblx0fVxufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQgeyBidWlsZEZlZWRiYWNrcyB9IGZyb20gJy4vYnVpbGQtY29tbWFuZHMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMsIGZpbmRBY3Rpb25Gb3JTZXR0aW5nIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRmVlZGJhY2tzJylcblxuLyoqXG4gKiBIZWxwZXIgZnVuY3Rpb24gdG8gZ2V0IGxhYmVsIGZyb20gY2hvaWNlcyBiYXNlZCBvbiB2YWx1ZVxuICovXG5mdW5jdGlvbiBnZXRMYWJlbEZvclZhbHVlKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuXHR2YWx1ZTogbnVtYmVyLFxuKTogc3RyaW5nIHwgbnVtYmVyIHtcblx0Y29uc3Qgc2V0dGluZyA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRpZiAoIXNldHRpbmcgfHwgIUFycmF5LmlzQXJyYXkoc2V0dGluZy5vcHRpb25zKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgJ3ZhbHVlJyBvcHRpb24gd2hpY2ggY29udGFpbnMgdGhlIGNob2ljZXNcblx0Y29uc3QgdmFsdWVPcHRpb24gPSBzZXR0aW5nLm9wdGlvbnMuZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0aWYgKCF2YWx1ZU9wdGlvbiB8fCAhQXJyYXkuaXNBcnJheSh2YWx1ZU9wdGlvbi5jaG9pY2VzKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgY2hvaWNlIHdpdGggbWF0Y2hpbmcgaWRcblx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjOiBhbnkpID0+IGMuaWQgPT09IHZhbHVlKVxuXHRyZXR1cm4gY2hvaWNlPy5sYWJlbCA/PyB2YWx1ZVxufVxuXG4vKipcbiAqIEJ1aWxkIGFuZCB3aXJlIENvbXBhbmlvbiBmZWVkYmFjayBkZWZpbml0aW9uc1xuICogUGF0dGVybiBtYXRjaGVzIGFjdGlvbnMudHMgLSBmaWx0ZXJzIGJ5IGFjdGl2ZSBtb2RlbCBhbmQgd2lyZXMgY2FsbGJhY2tzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVGZWVkYmFja3Moc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdGZWVkYmFja3MgPSBidWlsZEZlZWRiYWNrcygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEZlZWRiYWNrczogYW55ID0ge31cblxuXHQvLyBHZXQgdGhlIGFjdGl2ZSBtb2RlbCBmcm9tIHRoZSBjYWNoZWQgdmFsdWUgc2V0IGJ5IHN5bmNNb2RlbCgpXG5cdGNvbnN0IGFjdGl2ZU1vZGVsID0gc2VsZi5hY3RpdmVNb2RlbFxuXHRsb2dnZXIuaW5mbyhcblx0XHRgVXBkYXRlRmVlZGJhY2tzOiBhY3RpdmVNb2RlbD1cIiR7YWN0aXZlTW9kZWx9XCIsIGRpc2NvdmVyZWRIb3N0PVwiJHtzZWxmLmNvbmZpZy5kaXNjb3ZlcmVkSG9zdH1cIiwgZGV2aWNlcyBjb3VudD0ke3NlbGYuZGV2aWNlcy5sZW5ndGh9YCxcblx0KVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgRkVFREJBQ0tTIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2ZlZWRiYWNrSWQsIGZlZWRiYWNrXSBvZiBPYmplY3QuZW50cmllcyhyYXdGZWVkYmFja3MpKSB7XG5cdFx0Y29uc3QgeyBtb2RlbCwgY21kSWQsIGJhc2VJZCB9ID0gcGFyc2VTZXR0aW5nSWQoZmVlZGJhY2tJZClcblxuXHRcdC8vIE9ubHkgaW5jbHVkZSBmZWVkYmFja3MgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIFZBTFVFIEZFRURCQUNLOiBSZXR1cm5zIGN1cnJlbnQgdmFsdWUgZm9yIGxvY2FsIHZhcmlhYmxlXG5cdFx0d2lyZWRGZWVkYmFja3NbZmVlZGJhY2tJZF0gPSB7XG5cdFx0XHQuLi5mZWVkYmFjayxcblx0XHRcdGNhbGxiYWNrOiAoZmVlZGJhY2tFdmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydidXNDaCddXG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblx0XHRcdFx0Y29uc3QgY3VycmVudCA9IHNlbGYuc3RDb250cm9sbGVyLmdldFNldHRpbmdWYWx1ZShpcCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cblx0XHRcdFx0Ly8gQ2hlY2sgaWYgdXNlciB3YW50cyBsYWJlbCBpbnN0ZWFkIG9mIG51bWVyaWMgdmFsdWVcblx0XHRcdFx0Y29uc3Qgc2hvd0xhYmVsID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydzaG93TGFiZWwnXSA/PyBmYWxzZVxuXG5cdFx0XHRcdGlmIChzaG93TGFiZWwgJiYgY3VycmVudCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Ly8gUmV0dXJuIHRoZSBsYWJlbCBmcm9tIGNob2ljZXNcblx0XHRcdFx0XHRyZXR1cm4gZ2V0TGFiZWxGb3JWYWx1ZShzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgY3VycmVudClcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFJldHVybiBudW1lcmljIHZhbHVlIGRpcmVjdGx5IGZvciBsb2NhbCB2YXJpYWJsZSAodHlwZTogJ3ZhbHVlJylcblx0XHRcdFx0cmV0dXJuIGN1cnJlbnQgPz8gMFxuXHRcdFx0fSxcblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEZlZWRiYWNrRGVmaW5pdGlvbnMod2lyZWRGZWVkYmFja3MpXG5cblx0bG9nZ2VyLmluZm8oYFVwZGF0ZUZlZWRiYWNrczogd2lyZWQgZmVlZGJhY2tzOiAke09iamVjdC5rZXlzKHdpcmVkRmVlZGJhY2tzKS5sZW5ndGh9YClcbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHtcblx0Q01EX0JVU19HRVQsXG5cdENNRF9CVVNfU0VULFxuXHRDTURfREVWX1NQRUMsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfR0VUX0ZJUk1XQVJFLFxuXHRDTURfR0xPQkFMX01JQ19LSUxMLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9SRVNFVF9ERVZJQ0UsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHRnZXRDb21tYW5kTmFtZSxcblx0bWFrZVNldHRpbmdJZCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdHR5cGUgRGV2aWNlSW5mbyxcbn0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7XG5cdHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCxcblx0cGFyc2VTZXR0aW5nc1Jlc3BvbnNlLFxuXHRmb3JtYXRQYXJzZWRTZXR0aW5nLFxuXHR0eXBlIFN0QWN0aW9uLFxuXHR0eXBlIFBhcnNlZFNldHRpbmcsXG59IGZyb20gJy4vc2V0dGluZ3NQYXJzZXIuanMnXG5pbXBvcnQge1xuXHREQU5URV9NU0dfSU5GT19SRVNQT05TRSxcblx0cGFyc2VEYW50ZUluZm9SZXNwb25zZSxcblx0ZGlzY292ZXJEZXZpY2VzLFxuXHRidWlsZERhbnRlSW5mb1JlcXVlc3QsXG5cdGdldE1hY0ZvckRlc3RpbmF0aW9uLFxuXHRnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbixcbn0gZnJvbSAnLi9kYW50ZS5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdTdENvbnRyb2xsZXInKVxuXG5leHBvcnQgY2xhc3MgU3RDb250cm9sbGVyIHtcblx0cHJpdmF0ZSByZWFkb25seSBkZWZhdWx0UG9ydDogbnVtYmVyID0gODcwMFxuXHRwcml2YXRlIHJlYWRvbmx5IG11bHRpY2FzdEdyb3VwID0gJzIyNC4wLjAuMjMxJ1xuXHRwcml2YXRlIHJlYWRvbmx5IHJ4UG9ydCA9IDg3MDJcblxuXHRwcml2YXRlIHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXRcblx0cHJpdmF0ZSByeFNvY2tldDogZGdyYW0uU29ja2V0IC8vIGZvciByZWNlaXZpbmcgcmVzcG9uc2VzICg4NzAyKVxuXHRwcml2YXRlIHBlbmRpbmdBY2tzOiBNYXA8XG5cdFx0c3RyaW5nLFxuXHRcdHsgcmVzb2x2ZTogKGJ1ZjogQnVmZmVyKSA9PiB2b2lkOyByZWplY3Q6IChlOiBFcnJvcikgPT4gdm9pZDsgdGltZXI6IE5vZGVKUy5UaW1lb3V0IH1cblx0PiA9IG5ldyBNYXAoKVxuXHRwcml2YXRlIGpvaW5lZEludGVyZmFjZXM6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpIC8vIGxvY2FsIElQcyB3ZSd2ZSBqb2luZWQgbXVsdGljYXN0IG9uXG5cblx0LyoqIFNlcmlhbGl6ZXMgb3V0Z29pbmcgY29tbWFuZHMgc28gZWFjaCB3YWl0cyBmb3IgQUNLIGJlZm9yZSB0aGUgbmV4dCBpcyBzZW50ICovXG5cdHByaXZhdGUgc2VuZFF1ZXVlOiBQcm9taXNlPHZvaWQ+ID0gUHJvbWlzZS5yZXNvbHZlKClcblxuXHQvKiogVHJhY2tzIGhvdyBtYW55IGNvbW1hbmRzIGFyZSBxdWV1ZWQvaW4tZmxpZ2h0LCB0byBkZWZlciByZXF1ZXN0QWxsU2V0dGluZ3MgKi9cblx0cHJpdmF0ZSBwZW5kaW5nQ29tbWFuZENvdW50ID0gMFxuXG5cdC8qKiBSZXNvbHZlcyBvbmNlIHR4U29ja2V0IGlzIGJvdW5kIGFuZCByZWFkeSB0byBzZW5kICovXG5cdHByaXZhdGUgdHhSZWFkeTogUHJvbWlzZTx2b2lkPlxuXG5cdC8qKiBBY3RpdmUgZGV2aWNlIG1vZGVsIGFuZCBhY3Rpb24gZGVmaW5pdGlvbnMgZm9yIHNldHRpbmdzIGRlY29kaW5nICovXG5cdHByaXZhdGUgbW9kZWw6IHN0cmluZyA9ICcnXG5cdHByaXZhdGUgYWN0aW9uczogU3RBY3Rpb25bXSA9IFtdXG5cdHByaXZhdGUgcmVmcmVzaEFmdGVyQ29tbWFuZDogYm9vbGVhbiA9IHRydWUgLy8gRGVmYXVsdCB0byB0cnVlIChtb3N0IGRldmljZXMgbmVlZCBpdClcblxuXHQvKipcblx0ICogS25vd24gc3RhdGUgb2YgZXZlcnkgc2V0dGluZyBwZXIgZGV2aWNlIElQLlxuXHQgKiBLZXllZCBieSBJUCBcdTIxOTIgTWFwIG9mIFwiJHtjbWRJZH0vJHtzZXR0aW5nSWR9XCIgXHUyMTkyIGN1cnJlbnQgdmFsdWUgYnl0ZS5cblx0ICogUG9wdWxhdGVkIG9uIGNvbm5lY3QgdmlhIHJlcXVlc3RBbGxTZXR0aW5ncygpLCB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKS5cblx0ICogVXNlZCB0byBkaWZmIGluY29taW5nIHB1c2hlcyAoY2hhbmdlZCA9IGluZm8sIHVuY2hhbmdlZCA9IGRlYnVnKSBhbmQgZm9yIGZlZWRiYWNrcy5cblx0ICovXG5cdHByaXZhdGUgZGV2aWNlU3RhdGU6IE1hcDxzdHJpbmcsIE1hcDxzdHJpbmcsIG51bWJlcj4+ID0gbmV3IE1hcCgpXG5cblx0LyoqXG5cdCAqIElQcyB0aGF0IGhhdmUgYmVlbiB2ZXJpZmllZCBhZ2FpbnN0IHRoZSBjb25maWd1cmVkIG1vZGVsIGFuZCBhcmUgYWxsb3dlZFxuXHQgKiB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiBQb3B1bGF0ZWQgYnkgYXV0aG9yaXplRGV2aWNlKCkgYWZ0ZXIgYVxuXHQgKiBzdWNjZXNzZnVsIHByb2JlRGV2aWNlKCkgbW9kZWwgbWF0Y2gsIG9yIGFmdGVyIG11bHRpY2FzdCBkaXNjb3ZlcnkuXG5cdCAqIF9zZW5kQXdhaXRBY2soKSByZWplY3RzIGFueSBkZXN0SXAgbm90IGluIHRoaXMgc2V0LlxuXHQgKi9cblx0cHJpdmF0ZSBhdXRob3JpemVkSXBzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxuXG5cdC8qKiBDYWxsYmFja3MgcmVnaXN0ZXJlZCBieSBkaXNjb3ZlckRldmljZXMoKSBcdTIwMTQga2V5ZWQgYnkgc291cmNlIElQICovXG5cdHByaXZhdGUgZGlzY292ZXJ5TGlzdGVuZXJzOiBNYXA8c3RyaW5nLCAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB2b2lkPiA9IG5ldyBNYXAoKVxuXG5cdC8qKiBDYWxsYmFjayB0byB0cmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZXMgd2hlbiBzdGF0ZSBjaGFuZ2VzICovXG5cdHByaXZhdGUgZmVlZGJhY2tDYWxsYmFjaz86IChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHZvaWRcblxuXHQvKiogQ2FjaGUgb2YgbG9jYWwgaW50ZXJmYWNlIE1BQyBieXRlcyBwZXIgZGVzdGluYXRpb24gSVAsIHRvIGF2b2lkIHJlcGVhdGVkIE9TIGxvb2t1cHMgKi9cblx0cHJpdmF0ZSBtYWNDYWNoZTogTWFwPHN0cmluZywgbnVtYmVyW10+ID0gbmV3IE1hcCgpXG5cblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0bG9nZ2VyLmluZm8oJ1N0Q29udHJvbGxlciBpbml0aWFsaXplZCcpXG5cblx0XHQvLyBTZW5kIHNvY2tldCBcdTIwMTQgYmluZCB0byBlcGhlbWVyYWwgcG9ydC4gUmVzcG9uc2VzIGFsd2F5cyBnbyB0byByeFNvY2tldCBvblxuXHRcdC8vIHBvcnQgODcwMiAoRGFudGUgaGFyZGNvZGVzIHRoZSByZXNwb25zZSBkZXN0aW5hdGlvbiBwb3J0IHRvIDg3MDIpLlxuXHRcdHRoaXMudHhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXHRcdHRoaXMudHhSZWFkeSA9IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiB7XG5cdFx0XHR0aGlzLnR4U29ja2V0LmJpbmQoMCwgKCkgPT4ge1xuXHRcdFx0XHRsb2dnZXIuZGVidWcoYFRYIHNvY2tldCBib3VuZCB0byBwb3J0ICR7KHRoaXMudHhTb2NrZXQuYWRkcmVzcygpIGFzIHsgcG9ydDogbnVtYmVyIH0pLnBvcnR9YClcblx0XHRcdFx0cmVzb2x2ZSgpXG5cdFx0XHR9KVxuXHRcdH0pXG5cdFx0dGhpcy50eFNvY2tldC5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYFRYIHNvY2tldCBlcnJvcjogJHtlcnJ9YClcblx0XHR9KVxuXG5cdFx0Ly8gUmVjZWl2ZSBzb2NrZXQgLSBiaW5kIHRvIGFsbCBhZGRyZXNzZXMgc28ga2VybmVsIGNhbiBkZWxpdmVyIG11bHRpY2FzdCBwYWNrZXRzXG5cdFx0dGhpcy5yeFNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdsaXN0ZW5pbmcnLCAoKSA9PiB7XG5cdFx0XHRjb25zdCBhZGRyID0gdGhpcy5yeFNvY2tldC5hZGRyZXNzKClcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggc29ja2V0IGxpc3RlbmluZyBvbiAke0pTT04uc3RyaW5naWZ5KGFkZHIpfWApXG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLnJ4U29ja2V0LnNldE11bHRpY2FzdExvb3BiYWNrKHRydWUpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYFJYIHNvY2tldCBlcnJvcjogJHtlcnJ9YClcblx0XHR9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbWVzc2FnZScsIChtc2csIHJpbmZvKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLmhhbmRsZUluY29taW5nKG1zZywgcmluZm8uYWRkcmVzcylcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGxvZ2dlci5lcnJvcihgRXJyb3IgaGFuZGxpbmcgaW5jb21pbmcgbWVzc2FnZTogJHtfZX1gKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHQvLyBCaW5kIHRvIHdpbGRjYXJkIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0cyBmb3Igam9pbmVkIGludGVyZmFjZXNcblx0XHR0aGlzLnJ4U29ja2V0LmJpbmQoeyBhZGRyZXNzOiAnMC4wLjAuMCcsIHBvcnQ6IHRoaXMucnhQb3J0IH0sICgpID0+IHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggc29ja2V0IGJvdW5kIHRvIDAuMC4wLjA6JHt0aGlzLnJ4UG9ydH1gKVxuXHRcdH0pXG5cdH1cblxuXHRwdWJsaWMgY2xvc2UoKTogdm9pZCB7XG5cdFx0dHJ5IHtcblx0XHRcdGZvciAoY29uc3QgbG9jYWxBZGRyIG9mIEFycmF5LmZyb20odGhpcy5qb2luZWRJbnRlcmZhY2VzKSkge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdHRoaXMucnhTb2NrZXQuZHJvcE1lbWJlcnNoaXAodGhpcy5tdWx0aWNhc3RHcm91cCwgbG9jYWxBZGRyKVxuXHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnJ4U29ja2V0LmNsb3NlKClcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy50eFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogUHJvdmlkZSB0aGUgYWN0aXZlIGRldmljZSBtb2RlbCBhbmQgYWN0aW9uIGRlZmluaXRpb25zIHNvIGluY29taW5nIG1lc3NhZ2VzXG5cdCAqIGNhbiBiZSBkZWNvZGVkIGludG8gaHVtYW4tcmVhZGFibGUgbmFtZXMuIENhbGwgZnJvbSBtYWluLnRzIGFmdGVyIGNvbmZpZyBsb2FkLlxuXHQgKi9cblx0cHVibGljIHNldE1vZGVsKG1vZGVsOiBzdHJpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10sIHJlZnJlc2hBZnRlckNvbW1hbmQ6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCB7XG5cdFx0dGhpcy5tb2RlbCA9IG1vZGVsXG5cdFx0dGhpcy5hY3Rpb25zID0gYWN0aW9uc1xuXHRcdHRoaXMucmVmcmVzaEFmdGVyQ29tbWFuZCA9IHJlZnJlc2hBZnRlckNvbW1hbmRcblx0fVxuXG5cdC8qKlxuXHQgKiBTZXQgY2FsbGJhY2sgdG8gdHJpZ2dlciB3aGVuIGRldmljZSBzdGF0ZSBjaGFuZ2VzIChmb3IgZmVlZGJhY2tzKS5cblx0ICogQ2FsbCBmcm9tIG1haW4udHMgdG8gd2lyZSB1cCBjaGVja0ZlZWRiYWNrcy5cblx0ICovXG5cdHB1YmxpYyBzZXRGZWVkYmFja0NhbGxiYWNrKGNhbGxiYWNrOiAoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB2b2lkKTogdm9pZCB7XG5cdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrID0gY2FsbGJhY2tcblx0fVxuXG5cdC8qKiBSZXR1cm5zIHRydWUgaWYgdGhlIGRldmljZSBhdCB0aGUgZ2l2ZW4gSVAgaGFzIGJlZW4gYXV0aG9yaXplZCB0byByZWNlaXZlIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgaXNEZXZpY2VBdXRob3JpemVkKGlwOiBzdHJpbmcpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5hdXRob3JpemVkSXBzLmhhcyhpcClcblx0fVxuXG5cdC8qKiBNYXJrIGFuIElQIGFzIHZlcmlmaWVkIGFuZCBhbGxvd2VkIHRvIHJlY2VpdmUgU3R1ZGlvLVQgY29tbWFuZHMuICovXG5cdHB1YmxpYyBhdXRob3JpemVEZXZpY2UoaXA6IHN0cmluZyk6IHZvaWQge1xuXHRcdHRoaXMuYXV0aG9yaXplZElwcy5hZGQoaXApXG5cdFx0bG9nZ2VyLmRlYnVnKGBBdXRob3JpemVkIGRldmljZSBhdCAke2lwfWApXG5cdH1cblxuXHQvKiogUmVtb3ZlIGF1dGhvcml6YXRpb24gZm9yIGFuIElQIChlLmcuIG9uIGNvbmZpZyBjaGFuZ2Ugb3IgbW9kZWwgbWlzbWF0Y2gpLiAqL1xuXHRwdWJsaWMgcmV2b2tlRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuZGVsZXRlKGlwKVxuXHRcdHRoaXMuZGV2aWNlU3RhdGUuZGVsZXRlKGlwKVxuXHRcdHRoaXMubWFjQ2FjaGUuZGVsZXRlKGlwKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgUmV2b2tlZCBkZXZpY2UgYXQgJHtpcH1gKVxuXHR9XG5cblx0LyoqXG5cdCAqIFNlbmRzIGEgdW5pY2FzdCBEYW50ZSBpbmZvIHJlcXVlc3QgdG8gYSBzcGVjaWZpYyBJUCBhbmQgd2FpdHMgZm9yIHRoZVxuXHQgKiBkZXZpY2UgaW5mbyByZXNwb25zZS4gUmV0dXJucyB0aGUgRGV2aWNlSW5mbyBpZiB0aGUgZGV2aWNlIHJlc3BvbmRzIHdpdGhpblxuXHQgKiB0aW1lb3V0TXMsIG9yIG51bGwgaWYgbm8gcmVzcG9uc2UuIFVzZWQgdG8gdmVyaWZ5IGEgbWFudWFsbHkgY29uZmlndXJlZCBJUC5cblx0ICogRG9lcyBOT1QgcmVxdWlyZSBhdXRob3JpemF0aW9uIFx1MjAxNCB0aGlzIGlzIGhvdyBhdXRob3JpemF0aW9uIGlzIGVzdGFibGlzaGVkLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHByb2JlRGV2aWNlKGlwOiBzdHJpbmcsIHRpbWVvdXRNcyA9IDMwMDApOiBQcm9taXNlPERldmljZUluZm8gfCBudWxsPiB7XG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPERldmljZUluZm8gfCBudWxsPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0Y29uc3Qga2V5ID0gYF9fcHJvYmVfJHtpcH1fX2Bcblx0XHRcdGxldCByZXNvbHZlZCA9IGZhbHNlXG5cblx0XHRcdGNvbnN0IGZpbmlzaCA9IChyZXN1bHQ6IERldmljZUluZm8gfCBudWxsKSA9PiB7XG5cdFx0XHRcdGlmIChyZXNvbHZlZCkgcmV0dXJuXG5cdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5kZWxldGUoa2V5KVxuXHRcdFx0XHRyZXNvbHZlKHJlc3VsdClcblx0XHRcdH1cblxuXHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KGtleSwgKGRldmljZTogRGV2aWNlSW5mbykgPT4ge1xuXHRcdFx0XHRpZiAoZGV2aWNlLmlwID09PSBpcCkgZmluaXNoKGRldmljZSlcblx0XHRcdH0pXG5cblx0XHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBmaW5pc2gobnVsbCksIHRpbWVvdXRNcylcblx0XHRcdHRpbWVyLnVucmVmPy4oKVxuXG5cdFx0XHRjb25zdCBydW4gPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdGF3YWl0IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihpcClcblx0XHRcdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0XHRcdGNvbnN0IHF1ZXJ5ID0gYnVpbGREYW50ZUluZm9SZXF1ZXN0KClcblx0XHRcdFx0dGhpcy50eFNvY2tldC5zZW5kKHF1ZXJ5LCB0aGlzLmRlZmF1bHRQb3J0LCBpcCwgKGVycikgPT4ge1xuXHRcdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBQcm9iZSB0byAke2lwfSBmYWlsZWQ6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRcdGZpbmlzaChudWxsKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSlcblx0XHRcdH1cblxuXHRcdFx0cnVuKCkuY2F0Y2goKGUpID0+IHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYHByb2JlRGV2aWNlIHNldHVwIGZhaWxlZCBmb3IgJHtpcH06ICR7ZX1gKVxuXHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdGZpbmlzaChudWxsKVxuXHRcdFx0fSlcblx0XHR9KVxuXHR9XG5cblx0LyoqXG5cdCAqIFNlbmQgYSBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgcmVxdWVzdCB0byB0aGUgZGV2aWNlIGFuZCBzdG9yZSB0aGUgcmVzcG9uc2Vcblx0ICogaW4gZGV2aWNlU3RhdGUuIFJldHVybnMgdGhlIHJhdyByZXNwb25zZSBidWZmZXIgZm9yIHBhcnNpbmcuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEFsbFNldHRpbmdzKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGxvZ2dlci5pbmZvKGBSZXF1ZXN0aW5nIGFsbCBzZXR0aW5ncyBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HRVRfQUxMX1NFVFRJTkdTLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXZpY2VJcCwgZmFsc2UpXG5cdFx0Ly8gZGV2aWNlU3RhdGUgaXMgcG9wdWxhdGVkIGJ5IGxvZ1N0UGF5bG9hZCB3aGVuIHRoZSBDTURfR0VUX0FMTF9TRVRUSU5HUyByZXNwb25zZSBhcnJpdmVzXG5cdFx0cmV0dXJuIHJlc3BvbnNlXG5cdH1cblxuXHQvKipcblx0ICogRGlzY292ZXJzIFN0dWRpbyBUZWNobm9sb2dpZXMgRGFudGUgZGV2aWNlcyBvbiB0aGUgbG9jYWwgbmV0d29yay5cblx0ICpcblx0ICogU3RyYXRlZ3k6XG5cdCAqICBEYW50ZSBkZXZpY2VzIGJyb2FkY2FzdCBhIDEtc2Vjb25kIGFubm91bmNlIHRvIG11bHRpY2FzdCAyMjQuMC4wLjIzMzo4NzA4LlxuXHQgKiAgV2UgbGlzdGVuIG9uIHRoYXQgZ3JvdXAsIGNvbGxlY3Qgc291cmNlIElQcywgdGhlbiBzZW5kIGEgdW5pY2FzdCBkZXZpY2UgaW5mb1xuXHQgKiAgcmVxdWVzdCAoMHgwMDIwKSB0byBlYWNoIG5ldyBJUCBvbiBwb3J0IDg3MDAuIFRoZSBkZXZpY2UgcmVzcG9uZHMgdG8gb3VyIElQXG5cdCAqICBvbiBwb3J0IDg3MDIgKHJ4U29ja2V0KSwgd2hlcmUgaGFuZGxlSW5jb21pbmcoKSBwaWNrcyBpdCB1cCBhbmQgZmlyZXMgdGhlXG5cdCAqICBkaXNjb3ZlcnlMaXN0ZW5lcnMgY2FsbGJhY2suXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgZGlzY292ZXJEZXZpY2VzKHRpbWVvdXRNcyA9IDUwMDApOiBQcm9taXNlPERldmljZUluZm9bXT4ge1xuXHRcdC8vIFJlZ2lzdGVyIGxpc3RlbmVyIFx1MjAxNCBoYW5kbGVJbmNvbWluZygpIGZpcmVzIHRoaXMgZm9yIGVhY2ggMHgwMTcwIHJlc3BvbnNlXG5cdFx0Y29uc3QgRElTQ09WRVJZX0tFWSA9ICdfX2Rpc2NvdmVyeV9fJ1xuXHRcdGNvbnN0IGZvdW5kRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHRcdGNvbnN0IG9uRGV2aWNlRm91bmQgPSAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB7XG5cdFx0XHRpZiAoIWZvdW5kRGV2aWNlcy5zb21lKChkKSA9PiBkLmlwID09PSBkZXZpY2UuaXApKSB7XG5cdFx0XHRcdGZvdW5kRGV2aWNlcy5wdXNoKGRldmljZSlcblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBSZWdpc3RlciB0aGUgY2FsbGJhY2sgc28gaGFuZGxlSW5jb21pbmcoKSBjYW4gaW52b2tlIGl0IHdoZW4gMHgwMTcwIGFycml2ZXNcblx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5zZXQoRElTQ09WRVJZX0tFWSwgb25EZXZpY2VGb3VuZClcblxuXHRcdHRyeSB7XG5cdFx0XHRhd2FpdCB0aGlzLnR4UmVhZHlcblx0XHRcdC8vIGRpc2NvdmVyRGV2aWNlcygpIGluIGRhbnRlLnRzIGhhbmRsZXMgdGhlIGFubm91bmNlIGxpc3RlbmluZyBhbmQgcXVlcnkgc2VuZGluZy5cblx0XHRcdC8vIFJlc3BvbnNlcyBjb21lIGJhY2sgdG8gcnhTb2NrZXQgXHUyMTkyIGhhbmRsZUluY29taW5nKCkgXHUyMTkyIGRpc2NvdmVyeUxpc3RlbmVycy5cblx0XHRcdGF3YWl0IGRpc2NvdmVyRGV2aWNlcyh0aGlzLnR4U29ja2V0LCBhc3luYyAoZGVzdElwKSA9PiB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKSwgdGltZW91dE1zKVxuXHRcdFx0cmV0dXJuIGZvdW5kRGV2aWNlc1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5kZWxldGUoRElTQ09WRVJZX0tFWSlcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogUmVxdWVzdHMgZGV2aWNlIGZpcm13YXJlIHZlcnNpb24gdmlhIFN0dWRpby1UIHByb3RvY29sIChDTURfR0VUX0ZJUk1XQVJFKS5cblx0ICogUmV0dXJucyB0aGUgZmlybXdhcmUgdmVyc2lvbiBzdHJpbmcgKGUuZy4sIFwiMy4wMVwiLCBcIjIuMlwiLCBcIjEuMDVcIikuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2VJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0XHRsb2dnZXIuaW5mbyhgUmVxdWVzdGluZyBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soQ01EX0dFVF9GSVJNV0FSRSwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGV2aWNlSXAsIGZhbHNlKVxuXG5cdFx0Ly8gUmVzcG9uc2Ugc3RydWN0dXJlOiBbaGVhZGVyXSAweDVhIDB4ODAgW2Zpcm13YXJlX2RhdGFdIENSQ1xuXHRcdC8vIEZpcm13YXJlIGRhdGEgc3RhcnRzIGF0IGJ5dGUgMjYgKDI0LWJ5dGUgaGVhZGVyICsgMHg1YSArIDB4ODApXG5cdFx0Y29uc3QgZGF0YVN0YXJ0ID0gMjZcblxuXHRcdGlmIChyZXNwb25zZS5sZW5ndGggPCBkYXRhU3RhcnQgKyAzKSB7XG5cdFx0XHRsb2dnZXIud2FybihgRmlybXdhcmUgcmVzcG9uc2UgdG9vIHNob3J0OiAke3Jlc3BvbnNlLmxlbmd0aH0gYnl0ZXNgKVxuXHRcdFx0cmV0dXJuICdVbmtub3duJ1xuXHRcdH1cblxuXHRcdC8vIEZpcm13YXJlIGZvcm1hdDogW3Vua25vd25fYnl0ZSwgbWFqb3IsIG1pbm9yXVxuXHRcdGNvbnN0IG1ham9yID0gcmVzcG9uc2VbZGF0YVN0YXJ0ICsgMV1cblx0XHRjb25zdCBtaW5vciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDJdXG5cblx0XHRjb25zdCBtaW5vclN0ciA9XG5cdFx0XHRtaW5vciA8IDEwXG5cdFx0XHRcdD8gbWlub3IudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpIC8vIGUuZy4gMSBcdTIxOTIgXCIwMVwiLCA1IFx1MjE5MiBcIjA1XCJcblx0XHRcdFx0OiBtaW5vci50b1N0cmluZygpIC8vIGUuZy4gMTAgXHUyMTkyIFwiMTBcIlxuXG5cdFx0Y29uc3QgZmlybXdhcmUgPSBgJHttYWpvcn0uJHttaW5vclN0cn1gXG5cblx0XHRsb2dnZXIuaW5mbyhgRmlybXdhcmUgdmVyc2lvbjogJHtmaXJtd2FyZX1gKVxuXHRcdHJldHVybiBmaXJtd2FyZVxuXHR9XG5cblx0LyoqXG5cdCAqIEpvaW5zIHRoZSBtdWx0aWNhc3QgcmVzcG9uc2UgZ3JvdXAgb24gdGhlIGludGVyZmFjZSB0aGF0IHJvdXRlcyB0byBkZXN0SXAuXG5cdCAqIE9ubHkgam9pbnMgdGhlIHNwZWNpZmljIGludGVyZmFjZSB1c2VkIHRvIHJlYWNoIHRoZSBkZXZpY2UsIGFuZCBvbmx5IG9uY2UgcGVyIGludGVyZmFjZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhd2FpdCBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHRpZiAoIWxvY2FsQWRkcikge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGRldGVybWluZSBsb2NhbCBhZGRyZXNzIGZvciBkZXN0aW5hdGlvbiAke2Rlc3RJcH1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0aWYgKHRoaXMuam9pbmVkSW50ZXJmYWNlcy5oYXMobG9jYWxBZGRyKSkge1xuXHRcdFx0XHQvLyBhbHJlYWR5IGpvaW5lZFxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5hZGRNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0dGhpcy5qb2luZWRJbnRlcmZhY2VzLmFkZChsb2NhbEFkZHIpXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBKb2luZWQgbXVsdGljYXN0ICR7dGhpcy5tdWx0aWNhc3RHcm91cH0gb24gJHtsb2NhbEFkZHJ9YClcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gam9pbiBtdWx0aWNhc3Qgb24gJHtsb2NhbEFkZHJ9OiAke1N0cmluZyhfZSl9YClcblx0XHRcdH1cblx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYGVuc3VyZU1lbWJlcnNoaXBGb3IgZmFpbGVkOiAke19lfWApXG5cdFx0fVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHNlbmRBd2FpdEFjayhcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0KTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQrK1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdHRoaXMuc2VuZFF1ZXVlID0gdGhpcy5zZW5kUXVldWUudGhlbihhc3luYyAoKSA9PlxuXHRcdFx0XHR0aGlzLl9zZW5kQXdhaXRBY2soY21kSWQsIGJ1c0NoLCBzZXR0aW5nSWQsIHZhbHVlLCBkZXN0SXAsIGFkZExlbilcblx0XHRcdFx0XHQudGhlbigoYnVmKSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQtLVxuXHRcdFx0XHRcdFx0Ly8gT25seSB0cmlnZ2VyIHJlcXVlc3RBbGxTZXR0aW5ncyB3aGVuIHRoZSBxdWV1ZSBpcyBmdWxseSBkcmFpbmVkXG5cdFx0XHRcdFx0XHRpZiAodGhpcy5wZW5kaW5nQ29tbWFuZENvdW50ID09PSAwICYmIHRoaXMucmVmcmVzaEFmdGVyQ29tbWFuZCAmJiBzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdFx0XHR0aGlzLnJlcXVlc3RBbGxTZXR0aW5ncyhkZXN0SXApLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0LmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHRyZWplY3QoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIgOiBuZXcgRXJyb3IoU3RyaW5nKGVycikpKVxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIF9zZW5kQXdhaXRBY2soXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0Y29uc3QgdGltZW91dE1zID0gMjAwMFxuXG5cdFx0Ly8gUmVqZWN0IGNvbW1hbmRzIHRvIHVudmVyaWZpZWQgZGV2aWNlcy4gcHJvYmVEZXZpY2UoKSBieXBhc3NlcyB0aGlzXG5cdFx0Ly8gYmVjYXVzZSBpdCB1c2VzIHRoZSBEYW50ZSBwcm90b2NvbCBkaXJlY3RseSB2aWEgdHhTb2NrZXQsIG5vdCBzZW5kQXdhaXRBY2suXG5cdFx0aWYgKCF0aGlzLmF1dGhvcml6ZWRJcHMuaGFzKGRlc3RJcCkpIHtcblx0XHRcdHRocm93IG5ldyBFcnJvcihgRGV2aWNlIGF0ICR7ZGVzdElwfSBpcyBub3QgYXV0aG9yaXplZCBcdTIwMTQgdmVyaWZ5IHRoZSBJUCBhbmQgbW9kZWwgbWF0Y2ggYmVmb3JlIHNlbmRpbmcgY29tbWFuZHNgKVxuXHRcdH1cblxuXHRcdC8vIEVuc3VyZSB3ZSBhcmUgbGlzdGVuaW5nIGZvciByZXBsaWVzIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCB3aWxsIHJlY2VpdmUgdGhlbVxuXHRcdGF3YWl0IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApXG5cblx0XHRjb25zdCBkYXRhQmxvY2s6IG51bWJlcltdID0gW11cblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKHNldHRpbmdJZCAmIDB4ZmYpXG5cdFx0aWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKC4uLlN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpKVxuXG5cdFx0Y29uc3QgcGF5bG9hZEJvZHk6IG51bWJlcltdID0gWzB4NWEsIGNtZElkICYgMHhmZl1cblxuXHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBwYXlsb2FkQm9keS5wdXNoKGJ1c0NoICYgMHhmZilcblx0XHRpZiAoYWRkTGVuKSBwYXlsb2FkQm9keS5wdXNoKGRhdGFCbG9jay5sZW5ndGgpXG5cblx0XHRpZiAoZGF0YUJsb2NrLmxlbmd0aCA+IDApIHBheWxvYWRCb2R5LnB1c2goLi4uZGF0YUJsb2NrKVxuXG5cdFx0Y29uc3QgY3JjID0gU3RDb250cm9sbGVyLmNyYzhEdmJTMihwYXlsb2FkQm9keSlcblx0XHRjb25zdCBwYXlsb2FkV2l0aENyYyA9IEJ1ZmZlci5mcm9tKFsuLi5wYXlsb2FkQm9keSwgY3JjXSlcblxuXHRcdGNvbnN0IHRvdGFsTGVuID0gMjQgKyBwYXlsb2FkV2l0aENyYy5sZW5ndGhcblx0XHRjb25zdCBoZWFkZXIgPSBhd2FpdCB0aGlzLmJ1aWxkSGVhZGVyKHRvdGFsTGVuLCBkZXN0SXApXG5cdFx0Y29uc3QgcGFja2V0ID0gQnVmZmVyLmNvbmNhdChbaGVhZGVyLCBwYXlsb2FkV2l0aENyY10pXG5cblx0XHQvLyBIdW1hbi1yZWFkYWJsZSBpbmZvIGxvZyBmb3IgdGhlIG91dGdvaW5nIGNvbW1hbmRcblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IFN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IGNtZElkLFxuXHRcdFx0XHRpZDogc2V0dGluZ0lkLFxuXHRcdFx0XHRidXNDaCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKGBUWCAke2Rlc3RJcH0gfCAke2Zvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZywgdGhpcy5hY3Rpb25zKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtnZXRDb21tYW5kTmFtZShjbWRJZCl9YClcblx0XHR9XG5cdFx0bG9nZ2VyLmRlYnVnKGBTZW5kaW5nIHBhY2tldCB0byAke2Rlc3RJcH06ICR7cGFja2V0LnRvU3RyaW5nKCdoZXgnKX1gKVxuXG5cdFx0Y29uc3Qga2V5ID0gYCR7ZGVzdElwfToke2NtZElkfWBcblxuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgVGltZW91dCB3YWl0aW5nIGZvciBBQ0sgZnJvbSBNb2RlbCAke3RoaXMubW9kZWx9IGF0ICR7ZGVzdElwfTo4NzAwYCkpXG5cdFx0XHR9LCB0aW1lb3V0TXMpXG5cblx0XHRcdHRoaXMucGVuZGluZ0Fja3Muc2V0KGtleSwge1xuXHRcdFx0XHRyZXNvbHZlOiAoYnVmKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHRyZWplY3Q6IChlcnIpID0+IHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KGVycilcblx0XHRcdFx0fSxcblx0XHRcdFx0dGltZXIsXG5cdFx0XHR9KVxuXG5cdFx0XHR0aGlzLnR4U29ja2V0LnNlbmQocGFja2V0LCB0aGlzLmRlZmF1bHRQb3J0LCBkZXN0SXAsIChlcnIpID0+IHtcblx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgaGFuZGxlSW5jb21pbmcobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpIHtcblx0XHRpZiAobXNnLmxlbmd0aCA8IDQpIHJldHVyblxuXHRcdGlmIChtc2dbMF0gIT09IDB4ZmYgfHwgbXNnWzFdICE9PSAweGZmKSByZXR1cm5cblxuXHRcdGNvbnN0IG1zZ1R5cGUgPSBtc2cucmVhZFVJbnQxNkJFKDIpXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgKDB4MDE3MCkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gVGhlc2UgaGF2ZSBcIkF1ZGluYXRlXCIgYXQgb2Zmc2V0IDE2LCBub3QgXCJTdHVkaW8tVFwiIFx1MjAxNCBoYW5kbGUgYmVmb3JlXG5cdFx0Ly8gdGhlIFN0dWRpby1UIHNpZ25hdHVyZSBjaGVjayBiZWxvdy5cblx0XHRpZiAobXNnVHlwZSA9PT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgJiYgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2l6ZSA+IDApIHtcblx0XHRcdGNvbnN0IGRldmljZSA9IHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnLCBzcmNJcClcblx0XHRcdGlmIChkZXZpY2UpIHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKFxuXHRcdFx0XHRcdGBEYW50ZSBpbmZvIHJlc3BvbnNlIGZyb20gJHtzcmNJcH06IGAgK1xuXHRcdFx0XHRcdFx0YERldmljZUlEPVwiJHtkZXZpY2UubmFtZX1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTW9kZWw9XCIke2RldmljZS5tb2RlbH1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTW9kZWxOYW1lPVwiJHtkZXZpY2UubW9kZWxOYW1lfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNYW51ZmFjdHVyZXI9XCIke2RldmljZS5tYW51ZmFjdHVyZXJ9XCJgLFxuXHRcdFx0XHQpXG5cblx0XHRcdFx0Ly8gT25seSBhY2NlcHQgU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2VzIChpZGVudGlmaWVkIGJ5IERldmljZUlEIFwiU3R1ZGlvLVRcIilcblx0XHRcdFx0aWYgKGRldmljZS5uYW1lID09PSAnU3R1ZGlvLVQnKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjYiBvZiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy52YWx1ZXMoKSkge1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0Y2IoZGV2aWNlKVxuXHRcdFx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYElnbm9yaW5nIG5vbi1TdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZTogRGV2aWNlSUQ9XCIke2RldmljZS5uYW1lfVwiIEAgJHtzcmNJcH1gKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAobXNnLmxlbmd0aCA8IDI1KSByZXR1cm5cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBTdHVkaW8tVCBjb250cm9sIHByb3RvY29sIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGNvbnN0IHNpZyA9IG1zZy5zdWJhcnJheSgxNiwgMjQpXG5cdFx0aWYgKHNpZy50b1N0cmluZygnYXNjaWknKSAhPT0gJ1N0dWRpby1UJykgcmV0dXJuXG5cblx0XHQvLyBQYXlsb2FkIHN0YXJ0cyBhdCBvZmZzZXQgMjRcblx0XHQvLyBMYXlvdXQ6IFsweDVhXSBbY21kSWR8MHg4MF0gW2RhdGEuLi5dIFtjcmNdXG5cdFx0Y29uc3Qgc3RQYXlsb2FkID0gbXNnLnN1YmFycmF5KDI0KVxuXHRcdGlmIChzdFBheWxvYWQubGVuZ3RoIDwgMikgcmV0dXJuXG5cdFx0aWYgKHN0UGF5bG9hZFswXSAhPT0gMHg1YSkgcmV0dXJuXG5cblx0XHQvLyBEZXZpY2UgcmVwbGllcyB3aXRoIGNtZCB8IDB4ODBcblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBpc1Jlc3BvbnNlID0gKHJlc3BDbWRJZCAmIDB4ODApICE9PSAwXG5cdFx0Y29uc3Qgb3JpZ2luYWxDbWRJZCA9IHJlc3BDbWRJZCAmIDB4N2YgLy8gc3RyaXAgdGhlIHJlc3BvbnNlIGZsYWdcblxuXHRcdC8vIExvZyByYXcgcGFja2V0IGZvciBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgcmVzcG9uc2VzIGJlZm9yZSBwYXJzaW5nXG5cdFx0aWYgKGlzUmVzcG9uc2UgJiYgb3JpZ2luYWxDbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MpIHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUmVjZWl2ZWQgcGFja2V0IGZyb20gJHtzcmNJcH06ICR7bXNnLnRvU3RyaW5nKCdoZXgnKX1gKVxuXHRcdH1cblxuXHRcdC8vIExvZyB0aGUgcGF5bG9hZCAod29ya3MgZm9yIGJvdGggcmVxdWVzdHMgYW5kIHJlc3BvbnNlcylcblx0XHR0aGlzLmxvZ1N0UGF5bG9hZChzcmNJcCwgb3JpZ2luYWxDbWRJZCwgbXNnLCBzdFBheWxvYWQpXG5cblx0XHQvLyBPbmx5IHByb2Nlc3MgYXMgQUNLIGlmIHRoaXMgaXMgYSByZXNwb25zZSB0byBvdXIgcmVxdWVzdFxuXHRcdGlmIChpc1Jlc3BvbnNlKSB7XG5cdFx0XHRjb25zdCBrZXkgPSBgJHtzcmNJcH06JHtvcmlnaW5hbENtZElkfWBcblx0XHRcdGNvbnN0IHBlbmRpbmcgPSB0aGlzLnBlbmRpbmdBY2tzLmdldChrZXkpXG5cdFx0XHRpZiAocGVuZGluZykge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHBlbmRpbmcucmVzb2x2ZShtc2cpXG5cdFx0XHR9XG5cdFx0fVxuXHRcdC8vIFVuc29saWNpdGVkIG1lc3NhZ2VzIGFuZCByZXF1ZXN0cyBmcm9tIG90aGVyIHNvdXJjZXMgYXJlIGxvZ2dlZCBhYm92ZVxuXHR9XG5cblx0LyoqXG5cdCAqIERlY29kZXMgYW5kIGxvZ3MgYSBTdHVkaW8tVCByZXNwb25zZSBwYXlsb2FkLlxuXHQgKiBSZWNlaXZlcyBib3RoIHRoZSBmdWxsIG1zZyAoZm9yIHBhcnNlcnMgdGhhdCBuZWVkIHRoZSBTdHVkaW8tVCBoZWFkZXIpXG5cdCAqIGFuZCBzdFBheWxvYWQgKG1zZy5zdWJhcnJheSgyNCksIGZvciBkaXJlY3QgYnl0ZSBhY2Nlc3MpLlxuXHQgKlxuXHQgKiBzdFBheWxvYWQgbGF5b3V0OlxuXHQgKiAgIFswXSAgICAgIDB4NWEgIG1hZ2ljXG5cdCAqICAgWzFdICAgICAgY21kSWQgfCAweDgwXG5cdCAqICAgWzIuLi0yXSAgZGF0YSBieXRlc1xuXHQgKiAgIFstMV0gICAgIENSQy04L0RWQi1TMlxuXHQgKi9cblx0cHJpdmF0ZSBsb2dTdFBheWxvYWQoc3JjSXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgbXNnOiBCdWZmZXIsIHN0UGF5bG9hZDogQnVmZmVyKTogdm9pZCB7XG5cdFx0Y29uc3QgY21kTmFtZSA9IGdldENvbW1hbmROYW1lKGNtZElkKVxuXHRcdGNvbnN0IGRhdGEgPSBzdFBheWxvYWQuc3ViYXJyYXkoMiwgc3RQYXlsb2FkLmxlbmd0aCAtIDEpIC8vIHN0cmlwIG1hZ2ljK2NtZElkIGhlYWRlciBhbmQgQ1JDXG5cblx0XHQvLyBQYXlsb2FkIHN0cnVjdHVyZTogW2NtZDoweDhkXSBbZGF0YSBieXRlcy4uLl0gW2NyY11cblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBjcmMgPSBzdFBheWxvYWRbc3RQYXlsb2FkLmxlbmd0aCAtIDFdXG5cdFx0Y29uc3QgZnVsbFN0cnVjdHVyZSA9IGBbY21kOiR7dG9IZXgocmVzcENtZElkKX0gZGF0YToke2RhdGEudG9TdHJpbmcoJ2hleCcpfSBjcmM6JHt0b0hleChjcmMpfV1gXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIGFuZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gUGFyc2UgYWxsIHNldHRpbmdzLCBkaWZmIGFnYWluc3QgZGV2aWNlU3RhdGUsIGxvZyBjaGFuZ2VkIGF0IGluZm8gLyB1bmNoYW5nZWQgYXQgZGVidWcsXG5cdFx0Ly8gdGhlbiB1cGRhdGUgZGV2aWNlU3RhdGUuIENNRF9HRVRfQUxMX1NFVFRJTkdTIGFsc28gc2VydmVzIGFzIHRoZSBpbml0aWFsIHN0YXRlIHBvcHVsYXRpb24gb24gY29ubmVjdC5cblx0XHRpZiAoY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTIHx8IGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0aWYgKCF0aGlzLm1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5ncyA9XG5cdFx0XHRcdFx0Y21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIXG5cdFx0XHRcdFx0XHQ/IHBhcnNlU2V0dGluZ3NSZXNwb25zZSh0aGlzLm1vZGVsLCBtc2cpXG5cdFx0XHRcdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCh0aGlzLm1vZGVsLCBtc2cpXG5cblx0XHRcdFx0Y29uc3QgcHJldlN0YXRlID0gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoc3JjSXApID8/IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0XHRcdFx0Y29uc3QgbmV3U3RhdGUgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPihwcmV2U3RhdGUpIC8vIGNvcHkgXHUyMDE0IHVwZGF0ZSBpbiBwbGFjZVxuXG5cdFx0XHRcdGZvciAoY29uc3QgcyBvZiBzZXR0aW5ncykge1xuXHRcdFx0XHRcdGNvbnN0IHN0YXRlS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgcy5pZCwgcy5idXNDaClcblx0XHRcdFx0XHQvLyBGb3IgUkdCIGNvbG9ycyAoMyBieXRlcyksIHBhY2sgaW50byBzaW5nbGUgbnVtYmVyOiAoUiA8PCAxNikgfCAoRyA8PCA4KSB8IEJcblx0XHRcdFx0XHRjb25zdCBuZXdWYWx1ZSA9XG5cdFx0XHRcdFx0XHRzLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHRcdFx0XHRcdD8gKHMudmFsdWVCeXRlc1swXSA8PCAxNikgfCAocy52YWx1ZUJ5dGVzWzFdIDw8IDgpIHwgcy52YWx1ZUJ5dGVzWzJdXG5cdFx0XHRcdFx0XHRcdDogKHMudmFsdWVCeXRlc1swXSA/PyAwKVxuXHRcdFx0XHRcdGNvbnN0IHByZXZWYWx1ZSA9IHByZXZTdGF0ZS5nZXQoc3RhdGVLZXkpXG5cdFx0XHRcdFx0Y29uc3QgY2hhbmdlZCA9IHByZXZWYWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHByZXZWYWx1ZSAhPT0gbmV3VmFsdWVcblxuXHRcdFx0XHRcdG5ld1N0YXRlLnNldChzdGF0ZUtleSwgbmV3VmFsdWUpXG5cblx0XHRcdFx0XHRjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXRQYXJzZWRTZXR0aW5nKHMsIHRoaXMuYWN0aW9ucylcblx0XHRcdFx0XHRpZiAoY2hhbmdlZCkge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmluZm8oYFJYICR7c3JjSXB9IHwgJHtmb3JtYXR0ZWR9YClcblx0XHRcdFx0XHRcdC8vIFRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlIFx1MjAxNCB1c2UgYmFzZSBrZXkgd2l0aG91dCBidXNDaCBzbyBpdCBtYXRjaGVzIHRoZSBmZWVkYmFjayBkZWZpbml0aW9uIElEXG5cdFx0XHRcdFx0XHRpZiAodGhpcy5mZWVkYmFja0NhbGxiYWNrKSB7XG5cdFx0XHRcdFx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0tleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgcy5jbWRfaWQsIHMuaWQpXG5cdFx0XHRcdFx0XHRcdC8vbG9nZ2VyLmRlYnVnKGBUcmlnZ2VyaW5nIGZlZWRiYWNrIHVwZGF0ZSBmb3Iga2V5OiAke2Jhc2VGZWVkYmFja0tleX1gKVxuXHRcdFx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soYmFzZUZlZWRiYWNrS2V5KVxuXHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYGZlZWRiYWNrQ2FsbGJhY2sgbm90IHNldCBcdTIwMTQgc2tpcHBpbmcgZmVlZGJhY2sgdXBkYXRlIGZvciAke3N0YXRlS2V5fWApXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLmRldmljZVN0YXRlLnNldChzcmNJcCwgbmV3U3RhdGUpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCBwYXJzZSBmYWlsZWQ6ICR7ZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBBbGwgb3RoZXIgY29tbWFuZHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Y29uc3QgZGVjb2RlZCA9IHRoaXMuZGVjb2RlU3REYXRhKGNtZElkLCBkYXRhKVxuXHRcdGlmIChkZWNvZGVkKSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfSB8ICR7ZGVjb2RlZH1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEF0dGVtcHRzIHRvIGRlY29kZSB0aGUgZGF0YSBieXRlcyBvZiBhIFN0dWRpby1UIHJlc3BvbnNlIGludG8gYVxuXHQgKiBodW1hbi1yZWFkYWJsZSBzdHJpbmcuIFJldHVybnMgbnVsbCB0byBmYWxsIGJhY2sgdG8gcmF3IGhleC5cblx0ICovXG5cdHByaXZhdGUgZGVjb2RlU3REYXRhKGNtZElkOiBudW1iZXIsIGRhdGE6IEJ1ZmZlcik6IHN0cmluZyB8IG51bGwge1xuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMCkgcmV0dXJuICdBQ0snXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ2hlY2sgZm9yIHNpbmdsZS1ieXRlIHJlc3BvbnNlcyAoQUNLIG9yIGVycm9yKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdGlmIChkYXRhWzBdID09PSAweDAwKSB7XG5cdFx0XHRcdHJldHVybiAnQUNLIG9rJ1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0cmV0dXJuIGBFUlJPUiAke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdH1cblx0XHR9XG5cblx0XHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0RFVl9TUEVDICgweDBkKTogc2luZ2xlLWJ5dGUgQUNLIG9yIGVjaG8gb2YgYXBwbGllZCBzZXR0aW5nIFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gRGV2aWNlIHNlbmRzIHR3byBDTURfREVWX1NQRUMgcGFja2V0cyBpbiByZXNwb25zZSB0byBhIHNldDpcblx0XHRcdC8vICAgMS4gQUNLOiAgW3N0YXR1c10gICAgICAgICAgICAgICAoMSBieXRlLCAweDAwID0gb2spXG5cdFx0XHQvLyAgIDIuIEVjaG86IFtidXNDaF0gW3NldHRpbmdJZF0gW3ZhbHVlLi4uXSAgKGNvbmZpcm1pbmcgd2hhdCB3YXMgYXBwbGllZClcblx0XHRcdGNhc2UgQ01EX0RFVl9TUEVDOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0XHRcdHJldHVybiBkYXRhWzBdID09PSAweDAwID8gJ0FDSyBvaycgOiBgQUNLIGVycj0ke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlcyA9IGFjdGlvbj8ub3B0aW9ucz8uWzBdPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9XG5cdFx0XHRcdFx0XHRjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVN0ciA9IGNob2ljZUxhYmVsID8gYCR7Y2hvaWNlTGFiZWx9ICgke3RvSGV4KHZhbHVlTnVtISl9KWAgOiBieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpXG5cdFx0XHRcdFx0Y29uc3QgcmF3VGFnID0gYFske3RvSGV4KGNtZElkKX0vJHt0b0hleChzZXR0aW5nSWQpfV09JHtieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn0gJHtyYXdUYWd9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBgcmF3OiAke2RhdGEudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9NSUNfUFJFX0JVUyAoMHgxMik6IE11bHRpLWJ5dGUgZWNobyByZXNwb25zZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzoge1xuXHRcdFx0XHQvLyBBbHJlYWR5IGhhbmRsZWQgc2luZ2xlLWJ5dGUgYWJvdmUsIHNvIG11bHRpLWJ5dGUgbXVzdCBiZSBlY2hvXG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfWBcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/PyBgMHgke3ZhbHVlQnl0ZXMudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn1gXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIG51bGxcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEJ1cy1zY29wZWQgZ2V0L3NldCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdGNhc2UgQ01EX0JVU19HRVQ6XG5cdFx0XHRjYXNlIENNRF9CVVNfU0VUOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA8IDIpIHJldHVybiBudWxsXG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRyZXR1cm4gYGNoPSR7YnVzQ2h9IHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfSB2YWx1ZT0ke3ZhbHVlLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdHJldHVybiBudWxsIC8vIGZhbGwgdGhyb3VnaCB0byByYXcgaGV4XG5cdFx0fVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlOiB1bmtub3duKTogbnVtYmVyW10ge1xuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykgcmV0dXJuIFt2YWx1ZSA/IDEgOiAwXVxuXHRcdGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gTnVtYmVyKHYpICYgMHhmZilcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuXHRcdFx0aWYgKHZhbHVlID4gMHhmZikgcmV0dXJuIFsodmFsdWUgPj4gMTYpICYgMHhmZiwgKHZhbHVlID4+IDgpICYgMHhmZiwgdmFsdWUgJiAweGZmXVxuXHRcdFx0cmV0dXJuIFt2YWx1ZSAmIDB4ZmZdXG5cdFx0fVxuXHRcdHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgdmFsdWUgdHlwZSBmb3IgU1Rjb250cm9sbGVyOiAke3ZhbHVlfWApXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIGJ1aWxkSGVhZGVyKHRvdGFsTGVuOiBudW1iZXIsIGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRsZXQgbWFjID0gdGhpcy5tYWNDYWNoZS5nZXQoZGVzdElwKVxuXHRcdGlmICghbWFjKSB7XG5cdFx0XHRtYWMgPSBhd2FpdCBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHR0aGlzLm1hY0NhY2hlLnNldChkZXN0SXAsIG1hYylcblx0XHR9XG5cblx0XHRyZXR1cm4gQnVmZmVyLmNvbmNhdChbXG5cdFx0XHRCdWZmZXIuZnJvbShbMHhmZiwgMHhmZiwgMHgwMCwgdG90YWxMZW4gJiAweGZmLCAweDA3LCAweGUxLCAweDAwLCAweDAwLCAuLi5tYWMsIDB4MDAsIDB4MDBdKSxcblx0XHRcdEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcsICd1dGY4JyksXG5cdFx0XSlcblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGNyYzhEdmJTMihkYXRhOiBudW1iZXJbXSk6IG51bWJlciB7XG5cdFx0bGV0IGNyYyA9IDBcblx0XHRmb3IgKGNvbnN0IGIgb2YgZGF0YSkge1xuXHRcdFx0Y3JjIF49IGJcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgODsgaSsrKSB7XG5cdFx0XHRcdGNyYyA9IChjcmMgJiAweDgwKSAhPT0gMCA/ICgoY3JjIDw8IDEpIF4gMHhkNSkgJiAweGZmIDogKGNyYyA8PCAxKSAmIDB4ZmZcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGNyY1xuXHR9XG5cblx0LyoqXG5cdCAqIFJldHVybnMgdGhlIGN1cnJlbnQga25vd24gdmFsdWUgZm9yIGEgc2V0dGluZyBvbiBhIGRldmljZSwgb3IgdW5kZWZpbmVkIGlmIHVua25vd24uXG5cdCAqIFVzZSBmb3IgZmVlZGJhY2tzIFx1MjAxNCB2YWx1ZSBpcyB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBmcm9tIHRoZSBkZXZpY2UuXG5cdCAqXG5cdCAqIEBwYXJhbSBpcCAgICAgICAgRGV2aWNlIElQIGFkZHJlc3Ncblx0ICogQHBhcmFtIGNtZElkICAgICBDb21tYW5kIElEIChlLmcuIENNRF9ERVZfU1BFQylcblx0ICogQHBhcmFtIHNldHRpbmdJZCBTZXR0aW5nIElEIChlLmcuIDB4MDIgZm9yIENvbnRyb2wgU291cmNlKVxuXHQgKiBAcGFyYW0gYnVzQ2ggICAgIE9wdGlvbmFsIGJ1cy9jaGFubmVsIElEIGZvciBtdWx0aS1jaGFubmVsIGNvbW1hbmRzXG5cdCAqL1xuXHRwdWJsaWMgZ2V0U2V0dGluZ1ZhbHVlKGlwOiBzdHJpbmcsIGNtZElkOiBudW1iZXIsIHNldHRpbmdJZDogbnVtYmVyLCBidXNDaD86IG51bWJlcik6IG51bWJlciB8IHVuZGVmaW5lZCB7XG5cdFx0Y29uc3Qga2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBidXNDaClcblx0XHRyZXR1cm4gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoaXApPy5nZXQoa2V5KVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHJlc2V0RGV2aWNlKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5zZW5kQXdhaXRBY2soQ01EX1JFU0VUX0RFVklDRSwgdW5kZWZpbmVkLCAweDAwLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgZ2xvYmFsTWljS2lsbChkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HTE9CQUxfTUlDX0tJTEwsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdEYW50ZScpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBEYW50ZSBkaXNjb3ZlcnkgY29uc3RhbnRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBtZXNzYWdlIHR5cGUgKHNlbnQgdG8gcG9ydCA4NzAwKSAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX01TR19JTkZPX1JFUVVFU1QgPSAweDAwMjBcbi8qKiBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSBtZXNzYWdlIHR5cGUgKHJlY2VpdmVkIG9uIHBvcnQgODcwMikgKi9cbmV4cG9ydCBjb25zdCBEQU5URV9NU0dfSU5GT19SRVNQT05TRSA9IDB4MDE3MFxuXG4vKipcbiAqIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlIGxheW91dCAoYWxsIG9mZnNldHMgYXJlIGludG8gdGhlIFVEUCBwYXlsb2FkKTpcbiAqICAgMHgwMCAgdWludDE2QkUgIE1hZ2ljICgweGZmZmYpXG4gKiAgIDB4MDIgIHVpbnQxNkJFICBNZXNzYWdlIHR5cGUgKDB4MDE3MClcbiAqICAgMHgwNCAgdWludDE2QkUgIFNlcXVlbmNlIG51bWJlclxuICogICAweDA2ICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDA4ICA4IGJ5dGVzICAgRVVJLTY0IChzb3VyY2UgTUFDIHdpdGggZmY6ZmUgaW5zZXJ0ZWQgbWlkKVxuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIEFTQ0lJIGlkZW50aWZpZXJcbiAqICAgMHgxOCAgMiBieXRlcyAgIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uIChtYWpvciwgbWlub3IpXG4gKiAgIDB4MjAgIDMxIGJ5dGVzICBEZXZpY2UgbmFtZSwgbnVsbC1wYWRkZWQgQVNDSUkgKG1heCAzMSBjaGFycyBwZXIgRGFudGUgc3BlYylcbiAqICAgMHgyZSAgdWludDE2QkUgIFByb2R1Y3QgSURcbiAqICAgMHg0YyAgNjQgYnl0ZXMgIE1hbnVmYWN0dXJlciBzdHJpbmcsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKiAgIDB4Y2MgIDY0IGJ5dGVzICBNb2RlbCBzdHJpbmcsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKi9cbmV4cG9ydCBjb25zdCBEQU5URV9JTkZPX01JTl9MRU4gPSAweGNjICsgNjQgLy8gMjY4IGJ5dGVzIFx1MjAxNCBuZWVkIGZ1bGwgbW9kZWwgZmllbGRcblxuLyoqXG4gKiBCdWlsZHMgYSBEYW50ZSBkZXZpY2UgaW5mbyByZXF1ZXN0IHBhY2tldCAodHlwZSAweDAwMjApLlxuICpcbiAqIFBhY2tldCBsYXlvdXQgKDMyIGJ5dGVzKSBcdTIwMTQgZGVyaXZlZCBmcm9tIGxpdmUgY2FwdHVyZSBhbmFseXNpczpcbiAqICAgMHgwMCAgdWludDE2QkUgIE1hZ2ljICgweGZmZmYpXG4gKiAgIDB4MDIgIHVpbnQxNkJFICBNZXNzYWdlIHR5cGUgKDB4MDAyMCA9IGRldmljZSBpbmZvIHJlcXVlc3QpXG4gKiAgIDB4MDQgIHVpbnQxNkJFICBTZXF1ZW5jZSBudW1iZXIgKHJhbmRvbSlcbiAqICAgMHgwNiAgMiBieXRlcyAgIFBhZGRpbmdcbiAqICAgMHgwOCAgNiBieXRlcyAgIFNvdXJjZSBNQUNcbiAqICAgMHgwZSAgMiBieXRlcyAgIFBhZGRpbmdcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBBU0NJSSBpZGVudGlmaWVyXG4gKiAgIDB4MTggIDIgYnl0ZXMgICBQcm90b2NvbCB2ZXJzaW9uICgweDA3MzkpXG4gKiAgIDB4MWEgIDIgYnl0ZXMgICBTdWItdHlwZSAoMHgwMGMxKVxuICogICAweDFjICB1aW50MzJCRSAgQ2FwYWJpbGl0eSBtYXNrICgweDAwMGY0MjQwKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnVpbGREYW50ZUluZm9SZXF1ZXN0KCk6IEJ1ZmZlciB7XG5cdGNvbnN0IGJ1ZiA9IEJ1ZmZlci5hbGxvYygzMiwgMClcblx0Y29uc3Qgc2VxID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMHhmZmZmKVxuXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4ZmZmZiwgMClcblx0YnVmLndyaXRlVUludDE2QkUoREFOVEVfTVNHX0lORk9fUkVRVUVTVCwgMilcblx0YnVmLndyaXRlVUludDE2QkUoc2VxLCA0KVxuXG5cdGNvbnN0IG1hYyA9IGdldEZpcnN0TG9jYWxNYWMoKVxuXHRtYWMuY29weShidWYsIDgpXG5cblx0QnVmZmVyLmZyb20oJ0F1ZGluYXRlJywgJ2FzY2lpJykuY29weShidWYsIDE2KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDA3MzksIDI0KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDAwYzEsIDI2KVxuXHRidWYud3JpdGVVSW50MzJCRSgweDAwMGY0MjQwLCAyOClcblxuXHRyZXR1cm4gYnVmXG59XG5cbi8qKiBSZXR1cm5zIHRoZSBmaXJzdCBub24tbG9vcGJhY2sgTUFDIGFzIGEgNi1ieXRlIEJ1ZmZlciwgb3IgemVyb3MuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Rmlyc3RMb2NhbE1hYygpOiBCdWZmZXIge1xuXHR0cnkge1xuXHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMoaWZhY2VzKSkge1xuXHRcdFx0Zm9yIChjb25zdCBhZGRyIG9mIGlmYWNlc1tuYW1lXSA/PyBbXSkge1xuXHRcdFx0XHRpZiAoIWFkZHIuaW50ZXJuYWwgJiYgYWRkci5mYW1pbHkgPT09ICdJUHY0JyAmJiBhZGRyLm1hYyAmJiBhZGRyLm1hYyAhPT0gJzAwOjAwOjAwOjAwOjAwOjAwJykge1xuXHRcdFx0XHRcdHJldHVybiBCdWZmZXIuZnJvbShhZGRyLm1hYy5zcGxpdCgnOicpLm1hcCgoaDogc3RyaW5nKSA9PiBwYXJzZUludChoLCAxNikpKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIHtcblx0XHQvKiBpZ25vcmUgKi9cblx0fVxuXHRyZXR1cm4gQnVmZmVyLmFsbG9jKDYsIDApXG59XG5cbi8qKlxuICogUGFyc2VzIGEgRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgKHR5cGUgMHgwMTcwKSBpbnRvIGEgRGV2aWNlSW5mby5cbiAqXG4gKiBSZXNwb25zZSBsYXlvdXQgKGtleSBvZmZzZXRzKTpcbiAqICAgMHgwOCAgOCBieXRlcyAgIEVVSS02NCBcdTIwMTQgY29udmVydCB0byBNQUMgYnkgZHJvcHBpbmcgYnl0ZXMgWzNdIGFuZCBbNF0gKGZmOmZlKVxuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIGlkZW50aWZpZXIgKHVzZWQgdG8gdmVyaWZ5IHRoaXMgaXMgYSByZWFsIHJlc3BvbnNlKVxuICogICAweDE4ICAxIGJ5dGUgICAgRGFudGUgRlcgbWFqb3JcbiAqICAgMHgxOSAgMSBieXRlICAgIERhbnRlIEZXIG1pbm9yXG4gKiAgIDB4MjAgIDMxIGJ5dGVzICBEZXZpY2UgbmFtZSAoRGFudGUgbGFiZWwpLCBudWxsLXBhZGRlZCBBU0NJSSAobWF4IDMxIGNoYXJzKVxuICogICAweDJlICB1aW50MTZCRSAgUHJvZHVjdCBJRFxuICogICAweDRjICA2NCBieXRlcyAgTWFudWZhY3R1cmVyLCBudWxsLXBhZGRlZCBBU0NJSVxuICogICAweGNjICA2NCBieXRlcyAgTW9kZWwgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICpcbiAqIFJldHVybnMgbnVsbCBpZiBidWZmZXIgaXMgdG9vIHNob3J0LCB3cm9uZyBtYWdpYywgb3IgbWlzc2luZyBtb2RlbCBzdHJpbmcuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKTogRGV2aWNlSW5mbyB8IG51bGwge1xuXHRpZiAobXNnLmxlbmd0aCA8IERBTlRFX0lORk9fTUlOX0xFTikgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZikgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5yZWFkVUludDE2QkUoMikgIT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVybiBudWxsXG5cblx0Y29uc3QgcmVhZFN0ciA9IChvZmZzZXQ6IG51bWJlciwgbGVuOiBudW1iZXIpOiBzdHJpbmcgPT5cblx0XHRtc2dcblx0XHRcdC5zdWJhcnJheShvZmZzZXQsIG9mZnNldCArIGxlbilcblx0XHRcdC50b1N0cmluZygnYXNjaWknKVxuXHRcdFx0LnNwbGl0KCdcXDAnKVswXVxuXHRcdFx0LnRyaW0oKVxuXG5cdGNvbnN0IGV1aTY0ID0gbXNnLnN1YmFycmF5KDgsIDE2KVxuXHRjb25zdCBtYWNCeXRlcyA9IFtldWk2NFswXSwgZXVpNjRbMV0sIGV1aTY0WzJdLCBldWk2NFs1XSwgZXVpNjRbNl0sIGV1aTY0WzddXVxuXHRjb25zdCBtYWMgPSBtYWNCeXRlcy5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJzonKVxuXG5cdGNvbnN0IG5hbWUgPSByZWFkU3RyKDB4MjAsIDMxKSAvLyBEYW50ZSBkZXZpY2UgbGFiZWwgKGNhbiBiZSB1cCB0byAzMSBjaGFycyBwZXIgRGFudGUgc3BlYylcblx0Y29uc3QgbWFudWZhY3R1cmVyID0gcmVhZFN0cigweDRjLCA2NCkgLy8gZS5nLiBcIlN0dWRpbyBUZWNobm9sb2dpZXMsIEluYy5cIlxuXHRjb25zdCBtb2RlbFJhdyA9IHJlYWRTdHIoMHhjYywgNjQpXG5cdGNvbnN0IGRhbnRlRmlybXdhcmUgPSBgJHttc2dbMHgxOF19LiR7bXNnWzB4MTldfWBcblxuXHRpZiAoIW1vZGVsUmF3KSByZXR1cm4gbnVsbFxuXG5cdC8vIEV4dHJhY3QganVzdCB0aGUgbW9kZWwgbnVtYmVyL2NvZGUgKGUuZy4gXCJNb2RlbCAzOTEgQWxlcnRpbmcgVW5pdFwiIFx1MjE5MiBcIjM5MVwiKVxuXHQvLyBTdHJpcCBcIk1vZGVsIFwiIHByZWZpeCwgdGhlbiB0YWtlIG9ubHkgdGhlIGZpcnN0IHdvcmQgKHRoZSBtb2RlbCBudW1iZXIpXG5cdGNvbnN0IG1vZGVsID0gbW9kZWxSYXdcblx0XHQucmVwbGFjZSgvXk1vZGVsXFxzKy9pLCAnJylcblx0XHQudHJpbSgpXG5cdFx0LnNwbGl0KC9cXHMrLylbMF1cblxuXHRyZXR1cm4ge1xuXHRcdGlwOiBzcmNJcCxcblx0XHRuYW1lLFxuXHRcdG1hbnVmYWN0dXJlcixcblx0XHRtb2RlbCxcblx0XHRtb2RlbE5hbWU6IG1vZGVsUmF3LCAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uXG5cdFx0bWFjLFxuXHRcdGRhbnRlRmlybXdhcmUsXG5cdH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBNQUMgYWRkcmVzcyBieXRlcyBvZiB0aGUgbG9jYWwgaW50ZXJmYWNlIHVzZWQgdG8gcm91dGUgdG8gZGVzdElwLlxuICogVXNlcyBhIHRlbXBvcmFyeSBVRFAgY29ubmVjdCB0byBsZXQgdGhlIE9TIHNlbGVjdCB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlLFxuICogdGhlbiBmaW5kcyB0aGUgbWF0Y2hpbmcgTUFDIGZyb20gb3MubmV0d29ya0ludGVyZmFjZXMoKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hY0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxudW1iZXJbXT4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8bnVtYmVyW10+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCB0bXAgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoJ3VkcDQnKVxuXG5cdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdH0pXG5cblx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cdFx0XHRcdHRtcC5jbG9zZSgpXG5cblx0XHRcdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdFx0XHRmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMoaWZhY2VzKSkge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgaWZhY2Ugb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdFx0XHRpZiAoXG5cdFx0XHRcdFx0XHRcdGlmYWNlLmZhbWlseSA9PT0gJ0lQdjQnICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLmFkZHJlc3MgPT09IGxvY2FsQWRkciAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnXG5cdFx0XHRcdFx0XHQpIHtcblx0XHRcdFx0XHRcdFx0cmV0dXJuIHJlc29sdmUoaWZhY2UubWFjLnNwbGl0KCc6JykubWFwKChiKSA9PiBwYXJzZUludChiLCAxNikgJiAweGZmKSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgTm8gaW50ZXJmYWNlIGZvdW5kIGZvciBsb2NhbCBhZGRyZXNzICR7bG9jYWxBZGRyfWApKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihTdHJpbmcoX2UpKSlcblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGxvY2FsIElQIGFkZHJlc3MgdXNlZCBieSB0aGUgT1MgdG8gcm91dGUgdG8gZGVzdElwLlxuICogVXNlcyBhIHRlbXBvcmFyeSBVRFAgc29ja2V0IGNvbm5lY3QgdG8gbGV0IHRoZSBPUyBzZWxlY3QgdGhlIG91dGdvaW5nIGludGVyZmFjZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPHN0cmluZz4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHQvLyBVc2UgYW4gYXJiaXRyYXJ5IHBvcnQgZm9yIGNvbm5lY3Q7IHdlIG9ubHkgbmVlZCB0aGUga2VybmVsIHRvIGFzc2lnbiBhIGxvY2FsIGFkZHJlc3MuXG5cdFx0dG1wLmNvbm5lY3QoOSwgZGVzdElwLCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGFkZHIuYWRkcmVzc1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZXNvbHZlKGxvY2FsQWRkcilcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihTdHJpbmcoX2UpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogTGlzdGVucyBmb3IgRGFudGUgZGV2aWNlIGFubm91bmNlcyBvbiB0aGUgbG9jYWwgbmV0d29yayBhbmQgc2VuZHMgdW5pY2FzdFxuICogaW5mbyByZXF1ZXN0cyB0byBlYWNoIGRpc2NvdmVyZWQgSVAuIFJlc3BvbnNlcyBhcnJpdmUgb24gdGhlIGNhbGxlcidzIHJ4U29ja2V0XG4gKiB2aWEgaGFuZGxlSW5jb21pbmcoKSBcdTIxOTIgZGlzY292ZXJ5TGlzdGVuZXJzLlxuICpcbiAqIEBwYXJhbSB0eFNvY2tldCAtIFRoZSBzb2NrZXQgdG8gdXNlIGZvciBzZW5kaW5nIGRpc2NvdmVyeSByZXF1ZXN0c1xuICogQHBhcmFtIGVuc3VyZU1lbWJlcnNoaXAgLSBDYWxsYmFjayB0byBlbnN1cmUgbXVsdGljYXN0IG1lbWJlcnNoaXAgYmVmb3JlIHF1ZXJ5aW5nXG4gKiBAcGFyYW0gdGltZW91dE1zIC0gSG93IGxvbmcgdG8gbGlzdGVuIGZvciBhbm5vdW5jZXMgYmVmb3JlIHJlc29sdmluZ1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGlzY292ZXJEZXZpY2VzKFxuXHR0eFNvY2tldDogZGdyYW0uU29ja2V0LFxuXHRlbnN1cmVNZW1iZXJzaGlwOiAoZGVzdElwOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD4sXG5cdHRpbWVvdXRNcyA9IDUwMDAsXG4pOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfR1JPVVAgPSAnMjI0LjAuMC4yMzMnXG5cdGNvbnN0IERBTlRFX0FOTk9VTkNFX1BPUlQgPSA4NzA4XG5cdGNvbnN0IERFRkFVTFRfUE9SVCA9IDg3MDBcblxuXHRjb25zdCBxdWVyaWVkSXBzID0gbmV3IFNldDxzdHJpbmc+KClcblxuXHRyZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcblx0XHRjb25zdCBhbm5vdW5jZVNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cblx0XHRjb25zdCBjbGVhbnVwID0gKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuZHJvcE1lbWJlcnNoaXAoREFOVEVfQU5OT1VOQ0VfR1JPVVApXG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhbm5vdW5jZVNvY2tldC5jbG9zZSgpXG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0XHRyZXNvbHZlKClcblx0XHR9XG5cblx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoY2xlYW51cCwgdGltZW91dE1zKVxuXHRcdHRpbWVyLnVucmVmPy4oKVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEFubm91bmNlIHNvY2tldCBlcnJvcjogJHtlcnIubWVzc2FnZX1gKVxuXHRcdH0pXG5cblx0XHRhbm5vdW5jZVNvY2tldC5vbignbWVzc2FnZScsIChtc2csIHJpbmZvKSA9PiB7XG5cdFx0XHRjb25zdCBzcmNJcCA9IHJpbmZvLmFkZHJlc3Ncblx0XHRcdC8vIFZhbGlkYXRlIGl0J3MgYSBEYW50ZSBhbm5vdW5jZSAobWFnaWMgMHhmZmZlICsgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNilcblx0XHRcdGlmIChtc2cubGVuZ3RoIDwgMjQpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZSkgcmV0dXJuXG5cdFx0XHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVyblxuXG5cdFx0XHRpZiAocXVlcmllZElwcy5oYXMoc3JjSXApKSByZXR1cm5cblx0XHRcdHF1ZXJpZWRJcHMuYWRkKHNyY0lwKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBBbm5vdW5jZSBmcm9tICR7c3JjSXB9IFx1MjAxNCBzZW5kaW5nIHVuaWNhc3QgcXVlcnlgKVxuXG5cdFx0XHQvLyBKb2luIDIyNC4wLjAuMjMxIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gdGhpcyBkZXZpY2UgQkVGT1JFIHNlbmRpbmdcblx0XHRcdC8vIHRoZSBxdWVyeS4gVGhlIGRldmljZSBtdWx0aWNhc3RzIGl0cyAweDAxNzAgcmVzcG9uc2UgdG8gMjI0LjAuMC4yMzE6ODcwMlxuXHRcdFx0Ly8gaW4gYWRkaXRpb24gdG8gdW5pY2FzdGluZyBpdCBcdTIwMTQgcnhTb2NrZXQgbXVzdCBiZSBhIG1lbWJlciB0byByZWNlaXZlIGl0LlxuXHRcdFx0Y29uc3Qgc2VuZFF1ZXJ5ID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRhd2FpdCBlbnN1cmVNZW1iZXJzaGlwKHNyY0lwKVxuXHRcdFx0XHRjb25zdCBxdWVyeSA9IGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpXG5cdFx0XHRcdHR4U29ja2V0LnNlbmQocXVlcnksIERFRkFVTFRfUE9SVCwgc3JjSXAsIChlcnIpID0+IHtcblx0XHRcdFx0XHRpZiAoZXJyKSBsb2dnZXIud2FybihgVW5pY2FzdCBxdWVyeSB0byAke3NyY0lwfSBmYWlsZWQ6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdFx0fSlcblx0XHRcdH1cblx0XHRcdHNlbmRRdWVyeSgpLmNhdGNoKChlcnIpID0+IGxvZ2dlci53YXJuKGBRdWVyeSBzZXR1cCBmYWlsZWQ6ICR7ZXJyfWApKVxuXHRcdH0pXG5cblx0XHRhbm5vdW5jZVNvY2tldC5iaW5kKERBTlRFX0FOTk9VTkNFX1BPUlQsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmFkZE1lbWJlcnNoaXAoREFOVEVfQU5OT1VOQ0VfR1JPVVApXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBMaXN0ZW5pbmcgZm9yIERhbnRlIGFubm91bmNlcyBvbiAke0RBTlRFX0FOTk9VTkNFX0dST1VQfToke0RBTlRFX0FOTk9VTkNFX1BPUlR9YClcblx0XHRcdH0gY2F0Y2ggKGVycikge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGpvaW4gYW5ub3VuY2UgbXVsdGljYXN0IGdyb3VwOiAke2Vycn1gKVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG4iLCAiaW1wb3J0IHtcblx0SW5zdGFuY2VUeXBlcyxcblx0SW5zdGFuY2VCYXNlLFxuXHRJbnN0YW5jZVN0YXR1cyxcblx0U29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkLFxuXHRjcmVhdGVNb2R1bGVMb2dnZXIsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQge1xuXHRHZXRDb25maWdGaWVsZHMsXG5cdHJlc29sdmVIb3N0LFxuXHRyZXNvbHZlTW9kZWwsXG5cdGdldERldmljZVNjaGVtYSxcblx0Z2V0RGV2aWNlc0ZvbGRlcixcblx0cmVsb2FkRGV2aWNlU2NoZW1hcyxcblx0Z2V0RGV2aWNlU2NoZW1hcyxcblx0dHlwZSBNb2R1bGVDb25maWcsXG59IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucywgVXBkYXRlVmFyaWFibGVWYWx1ZXMgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcbmltcG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH0gZnJvbSAnLi91cGdyYWRlcy5qcydcbmltcG9ydCB7IFVwZGF0ZUFjdGlvbnMgfSBmcm9tICcuL2FjdGlvbnMuanMnXG5pbXBvcnQgeyBVcGRhdGVGZWVkYmFja3MgfSBmcm9tICcuL2ZlZWRiYWNrcy5qcydcbmltcG9ydCB7IFN0Q29udHJvbGxlciB9IGZyb20gJy4vc3Rjb250cm9sbGVyLmpzJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGdldE5vcm1hbGl6ZWRTY2hlbWFzIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uLCB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MsIHNhdmVNb2RlbEpzb25QcmV0dHkgfSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdNb2R1bGVJbnN0YW5jZScpXG5cbmV4cG9ydCB0eXBlIE1vZHVsZVR5cGVzID0gSW5zdGFuY2VUeXBlcyAmIHtcblx0Y29uZmlnOiBNb2R1bGVDb25maWdcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTW9kdWxlSW5zdGFuY2UgZXh0ZW5kcyBJbnN0YW5jZUJhc2U8TW9kdWxlVHlwZXM+IHtcblx0Y29uZmlnITogTW9kdWxlQ29uZmlnIC8vIFNldHVwIGluIGluaXQoKVxuXHRzdENvbnRyb2xsZXIhOiBTdENvbnRyb2xsZXJcblxuXHQvKiogQ2FjaGVkIGRpc2NvdmVyeSByZXN1bHRzIFx1MjAxNCBwYXNzZWQgaW50byBnZXRDb25maWdGaWVsZHMoKSBzbyB0aGUgVUlcblx0ICogIGNhbiBzaG93IHRoZSBkaXNjb3ZlcmVkIGRldmljZSBkcm9wZG93biBvbiBzdWJzZXF1ZW50IGNvbmZpZyBvcGVucy4gKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHQvKiogQ3VycmVudGx5IGFjdGl2ZSBtb2RlbCBcdTIwMTQgcmVzb2x2ZWQgb25jZSBpbiBzeW5jTW9kZWwoKSBhbmQgY2FjaGVkIGhlcmVcblx0ICogIHNvIFVwZGF0ZUFjdGlvbnMsIFVwZGF0ZUZlZWRiYWNrcyBldGMuIGRvbid0IGVhY2ggY2FsbCByZXNvbHZlTW9kZWwgaW5kZXBlbmRlbnRseS4gKi9cblx0YWN0aXZlTW9kZWw6IHN0cmluZyA9ICcnXG5cblx0Y29uc3RydWN0b3IoaW50ZXJuYWw6IHVua25vd24pIHtcblx0XHRzdXBlcihpbnRlcm5hbClcblx0fVxuXG5cdGFzeW5jIGluaXQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGlmICghdGhpcy5zdENvbnRyb2xsZXIpIHtcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyID0gbmV3IFN0Q29udHJvbGxlcigpXG5cdFx0fVxuXHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLk9rKVxuXG5cdFx0Ly8gV2lyZSBmZWVkYmFjayBjYWxsYmFjayBzbyBzdENvbnRyb2xsZXIgY2FuIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlc1xuXHRcdHRoaXMuc3RDb250cm9sbGVyLnNldEZlZWRiYWNrQ2FsbGJhY2soKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4ge1xuXHRcdFx0dGhpcy5jaGVja0ZlZWRiYWNrcyhmZWVkYmFja0lkKVxuXHRcdH0pXG5cblx0XHQvLyBTdGFydCBkaXNjb3ZlcnkgaW4gdGhlIGJhY2tncm91bmQgXHUyMDE0IGFsbCBtb2RlbCByZXNvbHV0aW9uLCBzY2hlbWEgc3luYyxcblx0XHQvLyBhbmQgVUkgdXBkYXRlcyBoYXBwZW4gaW5zaWRlIHJ1bkRpc2NvdmVyeSgpIG9uY2UgdGhlIGRldmljZSBsaXN0IGlzIGtub3duLlxuXHRcdHRoaXMucnVuRGlzY292ZXJ5KCkuY2F0Y2goKGUpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgRGlzY292ZXJ5IGZhaWxlZDogJHtlfWApXG5cdFx0fSlcblx0fVxuXG5cdC8qKlxuXHQgKiBSdW4gZGV2aWNlIGRpc2NvdmVyeSwgdGhlbiByZXNvbHZlIHRoZSBtb2RlbCBhbmQgdXBkYXRlIGFsbCBVSS5cblx0ICogLSBJZiBkaXNjb3ZlcnkgZmluZHMgZGV2aWNlcywgcmVzb2x2ZU1vZGVsIHBpY2tzIGZyb20gdGhvc2UuXG5cdCAqIC0gT25seSBpZiB0aGUgbGlzdCBpcyBlbXB0eSBkbyB3ZSBmYWxsIGJhY2sgdG8gdGhlIG1hbnVhbCBjb25maWcgc2VsZWN0aW9uLlxuXHQgKiBBbGwgYWN0aW9ucy9mZWVkYmFja3MvdmFyaWFibGVzIGFyZSBidWlsdCBhZnRlciB0aGUgbW9kZWwgaXMga25vd24uXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIHJ1bkRpc2NvdmVyeSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRsb2dnZXIuaW5mbygnU3RhcnRpbmcgZGV2aWNlIGRpc2NvdmVyeS4uLicpXG5cblx0XHR0aGlzLmRpc2NvdmVyZWREZXZpY2VzID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIuZGlzY292ZXJEZXZpY2VzKClcblxuXHRcdC8vIERldGVybWluZSBlZmZlY3RpdmUgbW9kZWwgXHUyMDE0IGZyb20gZGlzY292ZXJlZCBkZXZpY2VzIGZpcnN0LCBtYW51YWwgY29uZmlnIG9ubHkgYXMgZmFsbGJhY2tcblx0XHRsZXQgZWZmZWN0aXZlTW9kZWw6IHN0cmluZ1xuXHRcdGlmICh0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0Y29uc3QgbWFudWFsTW9kZWwgPSB0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbFxuXHRcdFx0aWYgKCF0aGlzLmNvbmZpZy5ob3N0IHx8ICFtYW51YWxNb2RlbCkge1xuXHRcdFx0XHRsb2dnZXIud2FybignTm8gZGV2aWNlcyBkaXNjb3ZlcmVkIGFuZCBubyBtYW51YWwgSVAvbW9kZWwgY29uZmlndXJlZCcpXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0bG9nZ2VyLmluZm8oJ05vIGRldmljZXMgZGlzY292ZXJlZCBcdTIwMTQgd2lsbCBwcm9iZSBtYW51YWwgSVAgZHVyaW5nIGF1dGhvcml6YXRpb24nKVxuXHRcdFx0ZWZmZWN0aXZlTW9kZWwgPSBtYW51YWxNb2RlbFxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgRGlzY292ZXJlZCAke3RoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RofSBkZXZpY2Uocyk6YClcblx0XHRcdGZvciAoY29uc3QgZCBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGAgIC0gTW9kZWwgJHtkLm1vZGVsfSAke2QubWFudWZhY3R1cmVyID8/ICcnfSBAICR7ZC5pcH1gKVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBBdXRob3JpemUgYWxsIGRpc2NvdmVyZWQgZGV2aWNlcyBzbyBmaXJtd2FyZSByZXF1ZXN0cyBjYW4gcHJvY2VlZC5cblx0XHRcdC8vIHZlcmlmeUF1dGhvcml6YXRpb24gKGNhbGxlZCBiZWxvdykgd2lsbCByZXZva2UgYW55IHRoYXQgZG9uJ3QgbWF0Y2hcblx0XHRcdC8vIHRoZSBjdXJyZW50IGNvbmZpZyBzZWxlY3Rpb24uXG5cdFx0XHRmb3IgKGNvbnN0IGRldmljZSBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShkZXZpY2UuaXApXG5cdFx0XHR9XG5cblx0XHRcdC8vIFJlcXVlc3QgZmlybXdhcmUgdmVyc2lvbiBmcm9tIGVhY2ggZGlzY292ZXJlZCBkZXZpY2Vcblx0XHRcdGZvciAoY29uc3QgZGV2aWNlIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRjb25zdCBmaXJtd2FyZSA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RGaXJtd2FyZVZlcnNpb24oZGV2aWNlLmlwKVxuXHRcdFx0XHRcdGRldmljZS5maXJtd2FyZU1haW4gPSBmaXJtd2FyZVxuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGAgIC0gJHtkZXZpY2UuaXB9OiBGaXJtd2FyZSAke2Zpcm13YXJlfSwgRGFudGUgJHtkZXZpY2UuZGFudGVGaXJtd2FyZX1gKVxuXHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLndhcm4oYCAgLSAke2RldmljZS5pcH06IEZhaWxlZCB0byBnZXQgZmlybXdhcmU6ICR7ZX1gKVxuXHRcdFx0XHRcdGRldmljZS5maXJtd2FyZU1haW4gPSAnVW5rbm93bidcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0XHR9XG5cblx0XHQvLyBTeW5jIG1vZGVsIHNjaGVtYSB0byBjb250cm9sbGVyXG5cdFx0dGhpcy5zeW5jTW9kZWwoZWZmZWN0aXZlTW9kZWwpXG5cblx0XHQvLyBWZXJpZnkgdGhhdCB0aGUgY3VycmVudGx5IGNvbmZpZ3VyZWQgaG9zdCttb2RlbCBpcyB2YWxpZCBub3cgdGhhdFxuXHRcdC8vIGRpc2NvdmVyeSByZXN1bHRzIGFyZSBrbm93bi4gVGhpcyBpcyB0aGUgc2FtZSBjaGVjayBjb25maWdVcGRhdGVkIHVzZXMuXG5cdFx0Y29uc3QgdGFyZ2V0SG9zdCA9IHRoaXMuaG9zdFxuXHRcdGF3YWl0IHRoaXMudmVyaWZ5QXV0aG9yaXphdGlvbignJywgdGFyZ2V0SG9zdClcblxuXHRcdC8vIEJ1aWxkIGFsbCBVSSBub3cgdGhhdCBtb2RlbCBhbmQgYXV0aG9yaXphdGlvbiBzdGF0ZSBhcmUga25vd25cblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXG5cdFx0bG9nZ2VyLmluZm8oJ0RldmljZSBkaXNjb3ZlcnkgY29tcGxldGUnKVxuXHR9XG5cblx0Ly8gV2hlbiBtb2R1bGUgZ2V0cyBkZWxldGVkXG5cdGFzeW5jIGRlc3Ryb3koKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5zdENvbnRyb2xsZXI/LmNsb3NlKClcblx0XHRsb2dnZXIuZGVidWcoJ2Rlc3Ryb3knKVxuXHR9XG5cblx0YXN5bmMgY29uZmlnVXBkYXRlZChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGNvbnN0IHByZXZpb3VzSG9zdCA9IHRoaXMuaG9zdFxuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0Y29uc3QgZWZmZWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwoY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXG5cdFx0Ly8gQ2xlYXIgdmFyaWFibGVzIGltbWVkaWF0ZWx5IFx1MjAxNCB0aGUgbmV3IHNlbGVjdGlvbiBpc24ndCBhdXRob3JpemVkIHlldC5cblx0XHQvLyBUaGV5J2xsIGJlIHJlcG9wdWxhdGVkIGJlbG93IG9uY2UgdmVyaWZ5QXV0aG9yaXphdGlvbiBjb21wbGV0ZXMuXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cblx0XHRjb25zdCBuZXdIb3N0ID0gdGhpcy5ob3N0XG5cblx0XHQvLyBSZS12ZXJpZnkgYXV0aG9yaXphdGlvbiBvbiBldmVyeSBjb25maWcgY2hhbmdlIChtb2RlbCBvciBJUCkuXG5cdFx0Ly8gVGhpcyBoYW5kbGVzIHN3aXRjaGluZyBmcm9tIGEgdmFsaWQgZGV2aWNlIHRvIGFuIGludmFsaWQgb25lIGFuZCBiYWNrLlxuXHRcdGF3YWl0IHRoaXMudmVyaWZ5QXV0aG9yaXphdGlvbihwcmV2aW91c0hvc3QsIG5ld0hvc3QpXG5cblx0XHQvLyBSZWJ1aWxkIFVJIGFmdGVyIGF1dGhvcml6YXRpb24gc3RhdGUgaXMgc2V0dGxlZFxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cdH1cblxuXHQvKipcblx0ICogUmUtZXZhbHVhdGVzIHdoZXRoZXIgdGhlIGN1cnJlbnQgaG9zdCttb2RlbCBjb21iaW5hdGlvbiBpcyBhdXRob3JpemVkLlxuXHQgKiBDYWxsZWQgb24gZXZlcnkgY29uZmlnIGNoYW5nZSBzbyB0aGF0IHN3aXRjaGluZyBtb2RlbCBvciBJUCBpcyBhbHdheXMgdmFsaWRhdGVkLlxuXHQgKlxuXHQgKiBSdWxlczpcblx0ICogLSBkaXNjb3ZlcmVkSG9zdCBzZXQgQU5EIGZvdW5kIGluIGN1cnJlbnQgZGlzY292ZXJ5IFx1MjE5MiBhdXRob3JpemVcblx0ICogLSBkaXNjb3ZlcmVkSG9zdCBzZXQgYnV0IE5PVCBmb3VuZCBpbiBjdXJyZW50IGRpc2NvdmVyeSBcdTIxOTIgcmV2b2tlIChzdGFsZSBjb25maWcpXG5cdCAqIC0gbWFudWFsIGhvc3QgXHUyMTkyIGNoZWNrIGFnYWluc3QgZGlzY292ZXJlZCBsaXN0IGZpcnN0OyBwcm9iZSBpZiB1bmtub3duXG5cdCAqICAgLSBkaXNjb3ZlcmVkIGRldmljZSBhdCB0aGF0IElQIHdpdGggbWF0Y2hpbmcgbW9kZWwgXHUyMTkyIGF1dGhvcml6ZVxuXHQgKiAgIC0gZGlzY292ZXJlZCBkZXZpY2UgYXQgdGhhdCBJUCB3aXRoIHdyb25nIG1vZGVsIFx1MjE5MiByZXZva2UgKyBsb2cgZXJyb3Jcblx0ICogICAtIG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgXHUyMTkyIHByb2JlOyBhdXRob3JpemUgb24gbWF0Y2gsIHJldm9rZSBvbiBtaXNtYXRjaC90aW1lb3V0XG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIHZlcmlmeUF1dGhvcml6YXRpb24ocHJldmlvdXNIb3N0OiBzdHJpbmcsIG5ld0hvc3Q6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGlmICghbmV3SG9zdCkge1xuXHRcdFx0aWYgKHByZXZpb3VzSG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNvbmZpZy5kaXNjb3ZlcmVkSG9zdCkge1xuXHRcdFx0Ly8gZGlzY292ZXJlZEhvc3QgaXMgc2V0LCBidXQgb25seSBhdXRob3JpemUgaWYgdGhlIGRldmljZSB3YXMgYWN0dWFsbHkgZm91bmRcblx0XHRcdC8vIGluIHRoZSBjdXJyZW50IGRpc2NvdmVyeSBydW4uIEEgc3RhbGUgZGlzY292ZXJlZEhvc3QgZnJvbSBhIHByZXZpb3VzIHNlc3Npb25cblx0XHRcdC8vIG11c3Qgbm90IGJlIHRyZWF0ZWQgYXMgdmVyaWZpZWQuXG5cdFx0XHRjb25zdCBmb3VuZE5vdyA9IHRoaXMuZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gbmV3SG9zdClcblx0XHRcdGlmICghZm91bmROb3cpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYGRpc2NvdmVyZWRIb3N0IFwiJHtuZXdIb3N0fVwiIHdhcyBub3QgZm91bmQgaW4gY3VycmVudCBkaXNjb3ZlcnkgXHUyMDE0IG5vdCBhdXRob3JpemluZ2ApXG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0Ly8gRGV2aWNlIGNvbmZpcm1lZCBieSBEYW50ZSBpbiB0aGlzIHNlc3Npb24gXHUyMDE0IGF1dGhvcml6ZS5cblx0XHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRjb25zdCB3YXNBdXRob3JpemVkID0gdGhpcy5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKG5ld0hvc3QpXG5cdFx0XHRpZiAoIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRpZiAobmV3SG9zdCAhPT0gcHJldmlvdXNIb3N0IHx8ICF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdGNvbnN0IG1vZGVsID0gcmVzb2x2ZU1vZGVsKHRoaXMuY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHRcdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobW9kZWwsIG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBNYW51YWwgbW9kZSBcdTIwMTQgY29uZmlnLmhvc3QgKyBjb25maWcuYWN0aXZlTW9kZWwgbXVzdCBtYXRjaFxuXHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWxcblx0XHRjb25zdCBkaXNjb3ZlcmVkQXRJcCA9IHRoaXMuZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gbmV3SG9zdClcblxuXHRcdGlmIChkaXNjb3ZlcmVkQXRJcCkge1xuXHRcdFx0aWYgKGRpc2NvdmVyZWRBdElwLm1vZGVsID09PSBtYW51YWxNb2RlbCkge1xuXHRcdFx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdFx0Y29uc3Qgd2FzQXV0aG9yaXplZCA9IHRoaXMuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChuZXdIb3N0KVxuXHRcdFx0XHRpZiAoIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAobmV3SG9zdCAhPT0gcHJldmlvdXNIb3N0IHx8ICF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1hbnVhbE1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtkaXNjb3ZlcmVkQXRJcC5tb2RlbH0pIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgLFxuXHRcdFx0XHQpXG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gSVAgbm90IGluIGRpc2NvdmVyZWQgbGlzdCBcdTIwMTQgcHJvYmUgaXRcblx0XHRsb2dnZXIuaW5mbyhgJHtuZXdIb3N0fSBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iaW5nYClcblx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UobmV3SG9zdClcblxuXHRcdGNvbnN0IHByb2JlZCA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnByb2JlRGV2aWNlKG5ld0hvc3QpXG5cdFx0aWYgKCFwcm9iZWQpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihgTm8gZGV2aWNlIHJlc3BvbmRlZCBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYClcblx0XHR9IGVsc2UgaWYgKHByb2JlZC5tb2RlbCAhPT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihcblx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtwcm9iZWQubW9kZWx9KSBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYCxcblx0XHRcdClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFZlcmlmaWVkIE1vZGVsICR7cHJvYmVkLm1vZGVsfSBhdCAke25ld0hvc3R9YClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1hbnVhbE1vZGVsLCBuZXdIb3N0KVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBGZXRjaGVzIGFsbCBzZXR0aW5ncyBmcm9tIHRoZSBkZXZpY2UuIElmIG5vIHNjaGVtYSBleGlzdHMgZm9yIHRoZSBtb2RlbCxcblx0ICogY3JlYXRlcyBvbmUgZnJvbSB0aGUgcmVzcG9uc2UgYW5kIHJlbG9hZHMgdGhlIHNjaGVtYSBjYWNoZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtb2RlbDogc3RyaW5nLCBpcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGJ1ZiA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0aWYgKCFnZXREZXZpY2VTY2hlbWEobW9kZWwpKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBObyBzY2hlbWEgZm91bmQgZm9yIE1vZGVsICR7bW9kZWx9IFx1MjAxNCBjcmVhdGluZyBmcm9tIGRldmljZSByZXNwb25zZWApXG5cblx0XHRcdFx0Y29uc3QgeyBzZXR0aW5nczogcGFyc2VkLCBkZXRlY3RlZFNlY3Rpb25lZCB9ID0gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24obW9kZWwsIGJ1Zilcblx0XHRcdFx0aWYgKHBhcnNlZC5sZW5ndGggPT09IDApIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IHBhcnNlIHNldHRpbmdzIGZvciBNb2RlbCAke21vZGVsfSBcdTIwMTQgc2NoZW1hIG5vdCBjcmVhdGVkYClcblx0XHRcdFx0XHRyZXR1cm5cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhnZXREZXZpY2VTY2hlbWFzKCkpXG5cdFx0XHRcdGNvbnN0IG5ld1NjaGVtYSA9IHsgbW9kZWwsIHNlY3Rpb25lZDogZGV0ZWN0ZWRTZWN0aW9uZWQgPz8gZmFsc2UsIGNtZFNjaGVtYTogW10gYXMgYW55W10gfVxuXHRcdFx0XHRpZiAoZGV0ZWN0ZWRTZWN0aW9uZWQgIT09IG51bGwpIHtcblx0XHRcdFx0XHRuZXdTY2hlbWEuc2VjdGlvbmVkID0gZGV0ZWN0ZWRTZWN0aW9uZWRcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCB1cGRhdGVkID0gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKG5ld1NjaGVtYSBhcyBhbnksIHBhcnNlZCwgc2NoZW1hcyBhcyBhbnkpXG5cblx0XHRcdFx0Y29uc3Qgc2NoZW1hUGF0aCA9IHBhdGguam9pbihnZXREZXZpY2VzRm9sZGVyKCksIGBNb2RlbCR7bW9kZWx9Lmpzb25gKVxuXHRcdFx0XHRzYXZlTW9kZWxKc29uUHJldHR5KHNjaGVtYVBhdGgsIHVwZGF0ZWQpXG5cdFx0XHRcdHJlbG9hZERldmljZVNjaGVtYXMoKVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgQ3JlYXRlZCBzY2hlbWEgZm9yIE1vZGVsICR7bW9kZWx9IGF0ICR7c2NoZW1hUGF0aH1gKVxuXG5cdFx0XHRcdC8vIFJlLXN5bmMgbW9kZWwgbm93IHRoYXQgc2NoZW1hIGV4aXN0c1xuXHRcdFx0XHR0aGlzLnN5bmNNb2RlbChtb2RlbClcblx0XHRcdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHRcdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZmV0Y2ggc2V0dGluZ3MgZnJvbSAke2lwfTogJHtlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqIExvYWRzIHRoZSBkZXZpY2UgSlNPTiBmb3IgdGhlIGdpdmVuIG1vZGVsLCBjYWNoZXMgaXQgYXMgYWN0aXZlTW9kZWwsIGFuZCBwdXNoZXMgaXQgdG8gdGhlIGNvbnRyb2xsZXIuICovXG5cdHByaXZhdGUgc3luY01vZGVsKG1vZGVsOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmFjdGl2ZU1vZGVsID0gbW9kZWxcblx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0aWYgKCFzY2hlbWEpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBNb2RlbCBcIiR7bW9kZWx9XCIgbm90IGZvdW5kIGluIGRldmljZSBzY2hlbWFzYClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBbXSwgdHJ1ZSlcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGNvbnN0IGFjdGlvbnMgPSBBcnJheS5pc0FycmF5KHNjaGVtYS5jbWRTY2hlbWEpID8gc2NoZW1hLmNtZFNjaGVtYSA6IFtdXG5cdFx0Y29uc3QgcmVmcmVzaEFmdGVyQ29tbWFuZCA9IHNjaGVtYS5yZWZyZXNoQWZ0ZXJDb21tYW5kID8/IHRydWVcblxuXHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBhY3Rpb25zLCByZWZyZXNoQWZ0ZXJDb21tYW5kKVxuXHRcdGlmIChhY3Rpb25zLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYE5vIGFjdGlvbnMgZm91bmQgZm9yIG1vZGVsIFwiJHttb2RlbH1cIiBcdTIwMTQgc2V0dGluZ3MgZGVjb2Rpbmcgd2lsbCB1c2UgcmF3IElEc2ApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0YExvYWRlZCAke2FjdGlvbnMubGVuZ3RofSBhY3Rpb25zIGZvciBtb2RlbCBcIiR7bW9kZWx9XCIsIHNlY3Rpb25lZD0ke3NjaGVtYS5zZWN0aW9uZWR9LCByZWZyZXNoQWZ0ZXJDb21tYW5kPSR7cmVmcmVzaEFmdGVyQ29tbWFuZH1gLFxuXHRcdFx0KVxuXHRcdH1cblx0fVxuXG5cdGdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdFx0cmV0dXJuIEdldENvbmZpZ0ZpZWxkcyh0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLCBwcmVmZXJyaW5nIHRoZSBkaXNjb3ZlcmVkIGRldmljZSBzZWxlY3Rpb24uICovXG5cdGdldCBob3N0KCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIHJlc29sdmVIb3N0KHRoaXMuY29uZmlnKVxuXHR9XG5cblx0LyoqIFJldHVybnMgZGlzY292ZXJlZCBkZXZpY2VzIGZvciB1c2UgaW4gYWN0aW9ucy9jb25maWcgKi9cblx0Z2V0IGRldmljZXMoKTogRGV2aWNlSW5mb1tdIHtcblx0XHRyZXR1cm4gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlc1xuXHR9XG5cblx0dXBkYXRlQWN0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVBY3Rpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVGZWVkYmFja3MoKTogdm9pZCB7XG5cdFx0VXBkYXRlRmVlZGJhY2tzKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlVmFsdWVzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHRoaXMpXG5cdH1cbn1cblxuZXhwb3J0IHsgVXBncmFkZVNjcmlwdHMgfVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7QUFrQkEsSUFBTSxxQkFBa0MsQ0FBQyxRQUFRLE9BQU8sWUFBVztBQUVsRSxVQUFRLElBQUksSUFBSSxNQUFNLFlBQVcsQ0FBRSxJQUFJLFNBQVMsS0FBSyxNQUFNLE1BQU0sRUFBRSxJQUFJLE9BQU8sRUFBRTtBQUNqRjtBQUVBLFNBQVMsVUFBVSxRQUE0QixPQUFpQixTQUFlO0FBQzlFLFFBQU0sT0FBTyxPQUFPLE9BQU8scUJBQXFCLGFBQWEsT0FBTyxtQkFBbUI7QUFDdkYsT0FBSyxRQUFRLE9BQU8sT0FBTztBQUM1QjtBQU9NLFNBQVUsbUJBQW1CLFFBQWU7QUFDakQsU0FBTztJQUNOLE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPO0lBQzlELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPOztBQUVoRTs7O0FDVE0sU0FBVSxZQUFZLE1BQVc7QUFFdkM7OztBQ2hDQSxTQUFTLG9CQUFvQjtBQTJFdkIsSUFBTyxzQkFBUCxjQUFtQyxhQUFtQztFQUNsRTtFQUNBO0VBRVQsSUFBVyxXQUFRO0FBQ2xCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBQ0EsSUFBVyxhQUFVO0FBQ3BCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBRUEsSUFBWSxhQUFVO0FBQ3JCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7QUFDbkQsYUFBTyxLQUFLO0lBQ2IsT0FBTztBQUNOLGFBQU87SUFDUjtFQUNEO0VBRUEsU0FBdUU7RUFFdkUsWUFBWSxTQUF5QyxTQUErQjtBQUNuRixVQUFLO0FBRUwsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVyxFQUFFLEdBQUcsUUFBTztFQUM3QjtFQUVBLEtBQUssTUFBYyxVQUFtQixVQUFxQjtBQUMxRCxRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLHlCQUF5QjtBQUM3RixZQUFRLEtBQUssUUFBUTtNQUNwQixLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sb0NBQW9DO01BQ3JELEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSx5QkFBeUI7TUFDMUMsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtNQUNwQyxLQUFLO0FBQ0o7TUFDRDtBQUNDLG9CQUFZLEtBQUssTUFBTTtBQUN2QixjQUFNLElBQUksTUFBTSxzQkFBc0I7SUFDeEM7QUFFQSxTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLGFBQWEsUUFBUTtBQUUzQyxTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFFBQVEsS0FBSyxTQUFTO01BQ3RCLFlBQVk7O0tBRVosRUFDQSxLQUNBLENBQUMsYUFBWTtBQUNaLFdBQUssU0FBUyxFQUFFLFlBQVksTUFBTSxTQUFRO0FBQzFDLFdBQUssU0FBUyx3QkFBd0IsSUFBSSxVQUFVLElBQUk7QUFDeEQsV0FBSyxLQUFLLFdBQVc7SUFDdEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVM7QUFDZCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLE1BQU0sVUFBcUI7QUFDMUIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtJQUVwRCxPQUFPO0FBQ04sY0FBUSxLQUFLLFFBQVE7UUFDcEIsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQ0FBb0M7UUFDckQsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9CQUFvQjtRQUNyQztBQUNDLHNCQUFZLEtBQUssTUFBTTtBQUN2QixnQkFBTSxJQUFJLE1BQU0sc0JBQXNCO01BQ3hDO0lBQ0Q7QUFFQSxVQUFNLFdBQVcsS0FBSyxPQUFPO0FBQzdCLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsU0FBUyxRQUFRO0FBRXZDLFNBQUssU0FDSCxxQkFBcUI7TUFDckI7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxPQUFPO0lBQ2xCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFXQSxLQUNDLGNBQ0EsY0FDQSxpQkFDQSxnQkFDQSxTQUNBLFVBQXFCO0FBRXJCLFFBQUksT0FBTyxpQkFBaUI7QUFBVSxZQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDekUsUUFBSSxPQUFPLG9CQUFvQixVQUFVO0FBQ3hDLFVBQUksT0FBTyxtQkFBbUIsWUFBWSxPQUFPLFlBQVk7QUFBVSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDMUcsVUFBSSxhQUFhLFVBQWEsT0FBTyxhQUFhO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRWpHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxjQUFjLGVBQWU7QUFDOUUsV0FBSyxXQUFXLFFBQVEsZ0JBQWdCLFNBQVMsUUFBUTtJQUMxRCxXQUFXLE9BQU8sb0JBQW9CLFVBQVU7QUFDL0MsVUFBSSxtQkFBbUIsVUFBYSxPQUFPLG1CQUFtQjtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUU3RyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsR0FBRyxNQUFTO0FBQzdELFdBQUssV0FBVyxRQUFRLGNBQWMsaUJBQWlCLGNBQWM7SUFDdEUsT0FBTztBQUNOLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtJQUNwQztFQUNEO0VBRUEsZUFDQyxjQUNBLFFBQ0EsUUFBMEI7QUFFMUIsUUFBSTtBQUNKLFFBQUksT0FBTyxpQkFBaUIsVUFBVTtBQUNyQyxlQUFTLE9BQU8sS0FBSyxjQUFjLE9BQU87SUFDM0MsV0FBVyxPQUFPLFNBQVMsWUFBWSxHQUFHO0FBQ3pDLGVBQVM7SUFDVixXQUFXLE1BQU0sUUFBUSxZQUFZLEdBQUc7QUFFdkMsYUFBTyxPQUFPLEtBQUssWUFBWTtJQUNoQyxPQUFPO0FBQ04sZUFBUyxPQUFPLEtBQUssYUFBYSxRQUFRLGFBQWEsWUFBWSxhQUFhLFVBQVU7SUFDM0Y7QUFFQSxXQUFPLE9BQU8sU0FBUyxRQUFRLFdBQVcsU0FBWSxTQUFTLFNBQVMsTUFBUztFQUNsRjtFQUVBLFdBQVcsUUFBZ0IsTUFBYyxTQUFpQixVQUFxQjtBQUM5RSxRQUFJLENBQUMsS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0sb0JBQW9CO0FBRXpGLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsVUFBVSxLQUFLLE9BQU87TUFDdEIsU0FBUztNQUVUO01BQ0E7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLGlCQUFVO0lBQ1gsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLHFCQUFxQixTQUErQjtBQUNuRCxRQUFJO0FBQ0gsV0FBSyxLQUFLLFdBQVcsUUFBUSxTQUFTLFFBQVEsTUFBTTtJQUNyRCxTQUFTLElBQUk7SUFFYjtFQUNEO0VBQ0EsbUJBQW1CLE9BQVk7QUFDOUIsU0FBSyxTQUFTO0FBRWQsVUFBTSxhQUFhLEtBQUs7QUFDeEIsUUFBSTtBQUFZLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxXQUFXLFFBQVE7QUFFaEYsUUFBSTtBQUNILFdBQUssS0FBSyxTQUFTLEtBQUs7SUFDekIsU0FBUyxJQUFJO0lBRWI7RUFDRDs7OztBQzlQSyxTQUFVLGtCQUFtRCxLQUFZO0FBQzlFLFFBQU0sT0FBTztBQUNiLFNBQU8sQ0FBQyxDQUFDLFFBQVEsT0FBTyxTQUFTLFlBQVksT0FBTyxLQUFLLE9BQU8sWUFBWSxLQUFLLHVCQUF1QjtBQUN6Rzs7O0FDNkJNLElBQWdCLGVBQWhCLE1BQTRCO0VBQ3hCO0VBQ0E7RUFFQTtFQUVULElBQVcsS0FBRTtBQUNaLFdBQU8sS0FBSyxTQUFTO0VBQ3RCO0VBRUEsSUFBVyxrQkFBZTtBQUN6QixXQUFPLEtBQUs7RUFDYjs7Ozs7RUFNQSxJQUFXLFFBQUs7QUFDZixXQUFPLEtBQUssU0FBUztFQUN0Qjs7OztFQUtBLFlBQVksVUFBaUI7QUFDNUIsUUFBSSxDQUFDLGtCQUE2QixRQUFRLEtBQUssQ0FBQyxTQUFTO0FBQ3hELFlBQU0sSUFBSSxNQUNULG1HQUFtRztBQUdyRyxTQUFLLFdBQVc7QUFFaEIsU0FBSyxVQUFVLG1CQUFrQjtBQUVqQyxTQUFLLHdCQUF3QixLQUFLLHNCQUFzQixLQUFLLElBQUk7QUFFakUsU0FBSyxXQUFXO01BQ2YsMkJBQTJCO01BQzNCLHdCQUF3Qjs7QUFHekIsU0FBSyxJQUFJLFNBQVMsY0FBYztFQUNqQztFQStCQSxXQUFXLFdBQTRDLFlBQWlDO0FBQ3ZGLFNBQUssU0FBUyxXQUFXLFdBQVcsVUFBVTtFQUMvQzs7Ozs7RUF1QkEscUJBQXFCLFNBQXlEO0FBQzdFLFNBQUssU0FBUyxxQkFBcUIsT0FBTztFQUMzQzs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7Ozs7RUFPQSxxQkFDQyxXQUNBLFNBQThDO0FBRTlDLFNBQUssU0FBUyxxQkFBcUIsV0FBVyxPQUFPO0VBQ3REOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixRQUFJLE1BQU0sUUFBUSxTQUFTO0FBQUcsWUFBTSxJQUFJLE1BQU0sd0RBQXdEO0FBRXRHLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7RUFNQSxrQkFBa0IsUUFBdUM7QUFDeEQsU0FBSyxTQUFTLGtCQUFrQixNQUFNO0VBQ3ZDOzs7Ozs7RUFPQSxpQkFBbUMsWUFBYTtBQUMvQyxXQUFPLEtBQUssU0FBUyxpQkFBaUIsVUFBVTtFQUNqRDs7OztFQUtBLG9CQUFpQjtBQUNoQixTQUFLLFNBQVMsa0JBQWlCO0VBQ2hDOzs7Ozs7O0VBUUEsZUFDQyxpQkFDRyxlQUFtRDtBQUV0RCxTQUFLLFNBQVMsZUFBZSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUM7RUFDOUQ7Ozs7O0VBTUEsc0JBQXNCLGFBQXFCO0FBQzFDLFNBQUssU0FBUyxtQkFBbUIsV0FBVztFQUM3Qzs7Ozs7O0VBT0Esb0JBQW9CLFdBQW1CO0FBQ3RDLFNBQUssU0FBUyxpQkFBaUIsU0FBUztFQUN6Qzs7Ozs7O0VBTUEsc0JBQXNCLFdBQW1CO0FBQ3hDLFNBQUssU0FBUyxtQkFBbUIsU0FBUztFQUMzQzs7Ozs7O0VBT0Esd0JBQXdCLGFBQXFCO0FBQzVDLFNBQUssU0FBUyxxQkFBcUIsV0FBVztFQUMvQzs7Ozs7O0VBT0EsYUFBYSxRQUFpQyxjQUFxQjtBQUNsRSxTQUFLLFNBQVMsYUFBYSxRQUFRLFlBQVk7RUFDaEQ7Ozs7Ozs7O0VBU0EsUUFBUSxNQUFjLE1BQWNBLE9BQWMsTUFBc0I7QUFDdkUsU0FBSyxTQUFTLFFBQVEsTUFBTSxNQUFNQSxPQUFNLElBQUk7RUFDN0M7Ozs7Ozs7Ozs7O0VBWUEsYUFBYSxRQUF3QixTQUF1QjtBQUMzRCxTQUFLLFNBQVMsYUFBYSxRQUFRLFdBQVcsSUFBSTtFQUNuRDs7Ozs7O0VBT0EsSUFBSSxPQUFpQixTQUFlO0FBQ25DLFlBQVEsT0FBTztNQUNkLEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0Q7QUFDQyxvQkFBWSxLQUFLO0FBQ2pCLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7SUFDRjtFQUNEO0VBWUEsc0JBQ0MsZUFDQSxVQUF5QztBQUV6QyxVQUFNLFVBQWtDLE9BQU8sa0JBQWtCLFdBQVcsRUFBRSxNQUFNLGNBQWEsSUFBSztBQUV0RyxVQUFNLFNBQVMsSUFBSSxvQkFBb0IsS0FBSyxVQUFVLE9BQU87QUFDN0QsUUFBSTtBQUFVLGFBQU8sR0FBRyxXQUFXLFFBQVE7QUFFM0MsV0FBTztFQUNSOzs7O0FDL1VELElBQVk7Q0FBWixTQUFZQyxpQkFBYztBQUN6QixFQUFBQSxnQkFBQSxJQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxZQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxtQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsV0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsZ0JBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHVCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx5QkFBQSxJQUFBO0FBQ0QsR0FWWSxtQkFBQSxpQkFBYyxDQUFBLEVBQUE7QUFhcEIsSUFBVztDQUFqQixTQUFpQkMsUUFBSztBQUVSLEVBQUFBLE9BQUEsS0FBSztBQUNMLEVBQUFBLE9BQUEsV0FDWjtBQUNZLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsT0FDWjtBQUNZLEVBQUFBLE9BQUEsY0FBYztBQUNkLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsUUFBUTtBQUNSLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsU0FBUztBQUNULEVBQUFBLE9BQUEsZ0JBQWdCO0FBQ2hCLEVBQUFBLE9BQUEsWUFBWTtBQUNaLEVBQUFBLE9BQUEsV0FDWjtBQUNGLEdBbEJpQixVQUFBLFFBQUssQ0FBQSxFQUFBOzs7QUNqQnRCLE9BQU8sUUFBUTtBQUNmLE9BQU8sVUFBVTtBQUlqQixJQUFNLFNBQVMsbUJBQW1CLFFBQVE7QUFxQjFDLFNBQVMsdUJBQW9CO0FBQzVCLFFBQU0sY0FBYyxLQUFLLEtBQUssWUFBWSxTQUFTLFlBQVk7QUFDL0QsUUFBTSxlQUFlLEtBQUssS0FBSyxZQUFZLFNBQVMsV0FBVztBQUcvRCxNQUFJLEdBQUcsV0FBVyxXQUFXLEdBQUc7QUFDL0IsV0FBTyxNQUFNLHlCQUF5QixXQUFXLEVBQUU7QUFDbkQsV0FBTztFQUNSO0FBR0EsTUFBSSxHQUFHLFdBQVcsWUFBWSxHQUFHO0FBQ2hDLFdBQU8sS0FBSyxxREFBcUQsWUFBWSxFQUFFO0FBQy9FLFdBQU87RUFDUjtBQUdBLFFBQU0sV0FBVzs7TUFBMEMsV0FBVztNQUFTLFlBQVk7O0FBQzNGLFNBQU8sTUFBTSxRQUFRO0FBQ3JCLFFBQU0sSUFBSSxNQUFNLFFBQVE7QUFDekI7QUFHQSxJQUFNLGdCQUFnQixxQkFBb0I7QUFHMUMsSUFBSSxxQkFBaUQ7QUFNL0MsU0FBVSxtQkFBZ0I7QUFDL0IsU0FBTztBQUNSO0FBTUEsU0FBUyxvQkFBaUI7QUFDekIsUUFBTSxVQUErQixDQUFBO0FBQ3JDLE1BQUk7QUFDSCxVQUFNLFFBQVEsR0FBRyxZQUFZLGFBQWEsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsT0FBTyxDQUFDO0FBRTdFLGVBQVcsS0FBSyxPQUFPO0FBQ3RCLFlBQU0sV0FBVyxLQUFLLEtBQUssZUFBZSxDQUFDO0FBQzNDLFlBQU0sT0FBTyxLQUFLLE1BQU0sR0FBRyxhQUFhLFVBQVUsTUFBTSxDQUFDO0FBQ3pELFVBQUksTUFBTSxPQUFPO0FBQ2hCLGdCQUFRLE9BQU8sS0FBSyxLQUFLLENBQUMsSUFBSTtNQUMvQjtJQUNEO0FBRUEsV0FBTyxNQUFNLFVBQVUsT0FBTyxLQUFLLE9BQU8sRUFBRSxNQUFNLDRCQUE0QjtFQUMvRSxTQUFTLEdBQUc7QUFDWCxXQUFPLE1BQU0sa0NBQWtDLENBQUMsRUFBRTtFQUNuRDtBQUNBLFNBQU87QUFDUjtBQU1NLFNBQVUsbUJBQWdCO0FBQy9CLE1BQUksQ0FBQyxvQkFBb0I7QUFDeEIseUJBQXFCLGtCQUFpQjtFQUN2QztBQUNBLFNBQU87QUFDUjtBQU1NLFNBQVUsZ0JBQWdCLE9BQWE7QUFDNUMsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxTQUFPLFFBQVEsS0FBSztBQUNyQjtBQU1NLFNBQVUsc0JBQW1CO0FBQ2xDLFNBQU8sS0FBSyx1Q0FBdUM7QUFDbkQsdUJBQXFCLGtCQUFpQjtBQUN2QztBQUtBLFNBQVMsc0JBQW1CO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsU0FBTyxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUk7QUFDakM7QUFFTSxTQUFVLGdCQUFnQixvQkFBa0MsQ0FBQSxHQUFFO0FBQ25FLFFBQU0sU0FBUyxvQkFBbUI7QUFLbEMsUUFBTSxnQkFBZ0I7SUFDckIsRUFBRSxJQUFJLElBQUksT0FBTyxTQUFRO0lBQ3pCLEdBQUcsa0JBQWtCLElBQUksQ0FBQyxPQUFPO01BQ2hDLElBQUksRUFBRTtNQUNOLE9BQU8sU0FBUyxFQUFFLEtBQUssS0FBSyxFQUFFLEVBQUU7TUFDL0I7O0FBR0gsU0FBTzs7OztJQUlOO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxTQUFTO01BQ1QsU0FBUzs7Ozs7SUFNVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsT0FBTyxNQUFNO01BQ2IscUJBQXFCO01BQ3JCLFNBQVM7Ozs7O0lBTVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUyxPQUFPLENBQUMsS0FBSztNQUN0QixTQUFTLE9BQU8sSUFBSSxDQUFDLFdBQVc7UUFDL0IsSUFBSTtRQUNKLE9BQU8sU0FBUyxLQUFLO1FBQ3BCO01BQ0YscUJBQXFCO01BQ3JCLFNBQVM7OztBQUdaO0FBTU0sU0FBVSxZQUFZLFFBQW9CO0FBQy9DLFNBQU8sT0FBTyxrQkFBa0IsT0FBTztBQUN4QztBQU9NLFNBQVUsYUFBYSxRQUFzQixtQkFBK0I7QUFDakYsTUFBSSxPQUFPLGdCQUFnQjtBQUMxQixVQUFNLFNBQVMsa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLGNBQWM7QUFDM0UsV0FBTyxNQUFNLGlDQUFpQyxPQUFPLGNBQWMsb0JBQW9CLFFBQVEsU0FBUyxNQUFNLEVBQUU7QUFDaEgsUUFBSSxRQUFRLE9BQU87QUFDbEIsYUFBTyxPQUFPO0lBQ2Y7QUFFQSxRQUFJLGtCQUFrQixXQUFXLEdBQUc7QUFDbkMsYUFBTyxLQUFLLDZEQUE2RDtBQUN6RSxhQUFPO0lBQ1I7RUFDRDtBQUNBLFNBQU8sTUFBTSw4Q0FBOEMsT0FBTyxXQUFXLEdBQUc7QUFDaEYsU0FBTyxPQUFPO0FBQ2Y7OztBQzlNTSxTQUFVLDBCQUEwQixNQUFvQjtBQUM3RCxPQUFLLHVCQUF1QjtJQUMzQixPQUFPLEVBQUUsTUFBTSxzQkFBcUI7SUFDcEMsV0FBVyxFQUFFLE1BQU0sdUNBQXNDO0lBQ3pELGNBQWMsRUFBRSxNQUFNLHNCQUFxQjtJQUMzQyxVQUFVLEVBQUUsTUFBTSwwQkFBeUI7SUFDM0MsU0FBUyxFQUFFLE1BQU0sZ0NBQStCO0lBQ2hELEtBQUssRUFBRSxNQUFNLHFCQUFvQjtJQUNqQyxJQUFJLEVBQUUsTUFBTSxvQkFBbUI7R0FDL0I7QUFDRjtBQUVBLElBQU0sb0JBQW9CO0VBQ3pCLE9BQU87RUFDUCxXQUFXO0VBQ1gsY0FBYztFQUNkLFVBQVU7RUFDVixTQUFTO0VBQ1QsS0FBSztFQUNMLElBQUk7O0FBUUMsU0FBVSxxQkFBcUIsTUFBb0I7QUFDeEQsUUFBTSxjQUFjLEtBQUs7QUFHekIsTUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLGFBQWEsbUJBQW1CLFdBQVcsR0FBRztBQUN2RSxTQUFLLGtCQUFrQixpQkFBaUI7QUFDeEM7RUFDRDtBQUVBLFFBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFdBQVc7QUFDNUQsTUFBSSxRQUFRO0FBQ1gsU0FBSyxrQkFBa0I7TUFDdEIsT0FBTyxPQUFPLFNBQVM7TUFDdkIsV0FBVyxPQUFPLGFBQWE7TUFDL0IsY0FBYyxPQUFPLGdCQUFnQjtNQUNyQyxVQUFVLE9BQU8sZ0JBQWdCO01BQ2pDLFNBQVMsT0FBTyxpQkFBaUI7TUFDakMsS0FBSyxPQUFPLE9BQU87TUFDbkIsSUFBSSxPQUFPO0tBQ1g7RUFDRixPQUFPO0FBR04sU0FBSyxrQkFBa0I7TUFDdEIsR0FBRztNQUNILElBQUk7S0FDSjtFQUNGO0FBQ0Q7OztBQzFETyxJQUFNLGlCQUErRDs7Ozs7Ozs7Ozs7Ozs7O0FDcUJyRSxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGNBQWM7QUFDcEIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sYUFBYTtBQUNuQixJQUFNLHVCQUF1QjtBQUM3QixJQUFNLG9CQUFvQjtBQUMxQixJQUFNLGVBQWU7QUFDckIsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxjQUFjO0FBR3JCLFNBQVUsZUFBZSxPQUFhO0FBQzNDLFVBQVEsT0FBTztJQUNkLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1I7QUFDQyxhQUFPLFNBQVMsTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDO0VBQ3JEO0FBQ0Q7QUFRTSxTQUFVLGNBQ2YsT0FDQSxPQUNBLFdBQ0EsT0FBdUI7QUFFdkIsUUFBTSxNQUFNLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUyxFQUFFLElBQUk7QUFDN0QsUUFBTSxLQUFLLE9BQU8sY0FBYyxXQUFXLFVBQVUsU0FBUyxFQUFFLElBQUk7QUFFcEUsTUFBSSxVQUFVLFFBQVc7QUFDeEIsVUFBTSxLQUFLLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUyxFQUFFLElBQUk7QUFDNUQsV0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRSxJQUFJLEVBQUU7RUFDbkM7QUFFQSxTQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxFQUFFO0FBQzdCO0FBU00sU0FBVSxNQUFNLE9BQWUsWUFBWSxHQUFDO0FBQ2pELFNBQU8sS0FBSyxNQUFNLFNBQVMsRUFBRSxFQUFFLFNBQVMsV0FBVyxHQUFHLENBQUM7QUFDeEQ7QUFPTSxTQUFVLFdBQVcsT0FBd0I7QUFDbEQsU0FBTyxLQUFLLE1BQU0sS0FBSyxLQUFLLEVBQzFCLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUUsQ0FBQztBQUNYO0FBU00sU0FBVSxlQUFlLEdBQVcsR0FBVyxHQUFTO0FBQzdELFNBQU8sSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQ2pCLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUUsRUFDUCxZQUFXLENBQUU7QUFDaEI7QUFRTSxTQUFVLGVBQWUsSUFBVTtBQUN4QyxRQUFNLENBQUMsT0FBTyxVQUFVLEtBQUssSUFBSSxHQUFHLE1BQU0sR0FBRztBQUM3QyxTQUFPO0lBQ047SUFDQSxPQUFPLFNBQVMsVUFBVSxFQUFFO0lBQzVCLFFBQVEsU0FBUyxPQUFPLEVBQUU7O0FBRTVCO0FBVU0sU0FBVSxjQUFjLFFBQWdCLFFBQWM7QUFDM0QsUUFBTSxLQUFLLFNBQVMsT0FBTyxRQUFRLE9BQU8sRUFBRSxHQUFHLEVBQUU7QUFDakQsUUFBTSxLQUFLLFNBQVMsT0FBTyxRQUFRLE9BQU8sRUFBRSxHQUFHLEVBQUU7QUFDakQsTUFBSSxPQUFPLE1BQU0sRUFBRSxLQUFLLE9BQU8sTUFBTSxFQUFFO0FBQUcsV0FBTztBQUNqRCxTQUFPLEtBQUssSUFBSSxLQUFLLEVBQUU7QUFDeEI7QUFTTSxTQUFVLHFCQUNmLFlBQStCO0FBRS9CLFFBQU0sYUFBa0UsQ0FBQTtBQUN4RSxhQUFXLENBQUMsT0FBTyxJQUFJLEtBQUssT0FBTyxRQUFRLFVBQVUsR0FBRztBQUN2RCxlQUFXLEtBQUssSUFBSTtNQUNuQixPQUFPLEtBQUs7TUFDWixXQUFXLE1BQU0sUUFBUSxLQUFLLFNBQVMsSUFBSSxLQUFLLFlBQVksQ0FBQTs7RUFFOUQ7QUFDQSxTQUFPO0FBQ1I7QUFZTSxTQUFVLHFCQUNmLFNBQ0EsT0FDQSxPQUNBLFdBQWlCO0FBRWpCLFFBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsTUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLFFBQVEsT0FBTyxTQUFTO0FBQUcsV0FBTztBQUd4RCxNQUFJLFNBQVMsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFXLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBR3ZGLE1BQUksQ0FBQyxRQUFRO0FBQ1osYUFBUyxPQUFPLFVBQVUsS0FBSyxDQUFDLE1BQVU7QUFDekMsVUFBSSxFQUFFLFdBQVc7QUFBTyxlQUFPO0FBQy9CLFlBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFDcEUsVUFBSSxDQUFDLGFBQWE7QUFBUyxlQUFPO0FBRWxDLFlBQU0sU0FBUyxZQUFZLEVBQUU7QUFDN0IsYUFBTyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU07SUFDNUQsQ0FBQztFQUNGO0FBRUEsU0FBTztBQUNSOzs7QUN0TUEsU0FBUyxZQUFZLEdBQU07QUFDMUIsUUFBTSxPQUFPO0lBQ1osTUFBTSxFQUFFO0lBQ1IsSUFBSSxFQUFFO0lBQ04sT0FBTyxFQUFFO0lBQ1QsU0FBUyxFQUFFO0lBQ1gsU0FBUyxFQUFFOztBQUdaLFVBQVEsRUFBRSxNQUFNO0lBQ2YsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sU0FBUyxFQUFFLFdBQVcsQ0FBQSxFQUFFO0lBRTNDLEtBQUs7QUFDSixhQUFPO1FBQ04sR0FBRztRQUNILEtBQUssRUFBRTtRQUNQLEtBQUssRUFBRTtRQUNQLE1BQU0sRUFBRSxRQUFRO1FBQ2hCLE9BQU87O0lBR1QsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sU0FBUyxFQUFFLFdBQVcsTUFBSztJQUU5QyxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTDtBQUNDLGFBQU87RUFDVDtBQUNEO0FBTU0sU0FBVSxlQUFZO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsUUFBTSxVQUFzQyxDQUFBO0FBRTVDLGFBQVcsQ0FBQyxPQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ3RELFVBQU0sWUFBWSxPQUFPO0FBQ3pCLFFBQUksQ0FBQyxNQUFNLFFBQVEsU0FBUztBQUFHO0FBRS9CLGVBQVcsS0FBSyxXQUFXO0FBQzFCLFlBQU0sV0FBVyxjQUFjLE9BQU8sRUFBRSxRQUFRLEVBQUUsRUFBRTtBQUVwRCxZQUFNLFdBQVcsRUFBRSxXQUFXLENBQUEsR0FBSSxJQUFJLFdBQVc7QUFFakQsWUFBTSxTQUFvQztRQUN6QyxNQUFNLFNBQVMsS0FBSyxLQUFLLEVBQUUsSUFBSTtRQUMvQjtRQUNBLFVBQVUsWUFBVztRQUVyQjs7QUFHRCxjQUFRLFFBQVEsSUFBSTtJQUNyQjtFQUNEO0FBRUEsU0FBTztBQUNSO0FBTU0sU0FBVSxpQkFBYztBQUM3QixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sWUFBMEMsQ0FBQTtBQUVoRCxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLFdBQVcsV0FBVztBQUNoQyxZQUFNLGlCQUFpQixjQUFjLE9BQU8sUUFBUSxRQUFRLFFBQVEsRUFBRTtBQUd0RSxZQUFNLGNBQWMsUUFBUSxXQUFXLENBQUEsR0FBSSxJQUFJLFdBQVc7QUFHMUQsWUFBTSxlQUFlLFdBQVcsT0FBTyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFHdkUsbUJBQWEsS0FBSztRQUNqQixNQUFNO1FBQ04sSUFBSTtRQUNKLE9BQU87UUFDUCxTQUFTO1FBQ1QsU0FBUztPQUNUO0FBR0QsWUFBTSxnQkFBcUI7UUFDMUIsTUFBTTtRQUNOLE1BQU0sU0FBUyxLQUFLLEtBQUssUUFBUSxJQUFJO1FBQ3JDLFNBQVM7UUFDVCxVQUFVLE1BQUs7QUFFZCxpQkFBTztRQUNSOztBQUdELGdCQUFVLGNBQWMsSUFBSTtJQUM3QjtFQUNEO0FBRUEsU0FBTztBQUNSOzs7QUM1SEEsT0FBT0MsV0FBVTs7O0FDTGpCLE9BQU9DLFNBQVE7QUFnQmYsSUFBTUMsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBeUNsRCxTQUFTLGVBQWUsT0FBYTtBQUNwQyxRQUFNLFNBQVMsb0JBQUksSUFBRztBQUN0QixNQUFJLFlBQVk7QUFFaEIsTUFBSTtBQUVILFVBQU0sT0FBTyxnQkFBZ0IsS0FBSztBQUNsQyxRQUFJLENBQUMsTUFBTTtBQUVWLGFBQU8sRUFBRSxXQUFXLE9BQU07SUFDM0I7QUFHQSxnQkFBWSxLQUFLLGFBQWE7QUFHOUIsZUFBVyxVQUFVLEtBQUssYUFBYSxDQUFBLEdBQUk7QUFDMUMsWUFBTSxpQkFBaUIsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLFNBQVMsYUFBYTtBQUMvRixVQUFJLGdCQUFnQjtBQUVuQixlQUFPLElBQUksT0FBTyxFQUFFO0FBR3BCLGNBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQXdCLElBQUksT0FBTyxPQUFPO0FBQ3BGLFlBQUksYUFBYSxTQUFTO0FBQ3pCLHFCQUFXLFVBQVUsWUFBWSxTQUFTO0FBQ3pDLGdCQUFJLE9BQU8sT0FBTyxPQUFPLFVBQVU7QUFDbEMscUJBQU8sSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFO1lBQ2pDO1VBQ0Q7UUFDRDtNQUNEO0lBQ0Q7RUFDRCxTQUFTLE1BQU07RUFFZjtBQUVBLFNBQU8sRUFBRSxXQUFXLE9BQU07QUFDM0I7QUFNQSxTQUFTLHNCQUFzQixLQUFXO0FBQ3pDLFFBQU0sV0FBVyxJQUFJLFFBQVEsT0FBTyxLQUFLLFVBQVUsQ0FBQztBQUNwRCxNQUFJLFdBQVc7QUFBRyxVQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFFbkUsUUFBTSxlQUFlLFdBQVc7QUFDaEMsTUFBSSxJQUFJLFlBQVksTUFBTSxJQUFNO0FBQy9CLFVBQU0sSUFBSSxNQUFNLHVDQUF1QyxJQUFJLFlBQVksRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO0VBQ3hGO0FBRUEsU0FBTztBQUNSO0FBTUEsU0FBUyx1QkFBdUIsT0FBZSxTQUFzQixvQkFBSSxJQUFHLEdBQUU7QUFDN0UsTUFBSSxJQUFJO0FBQ1IsUUFBTSxNQUF1QixDQUFBO0FBRTdCLFNBQU8sSUFBSSxNQUFNLFFBQVE7QUFDeEIsVUFBTSxLQUFLLE1BQU0sQ0FBQztBQUNsQixRQUFJLElBQUksS0FBSyxNQUFNO0FBQVE7QUFHM0IsUUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNLFFBQVE7QUFDM0MsVUFBSSxLQUFLO1FBQ1IsUUFBUTtRQUNSO1FBQ0EsWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxDQUFDO09BQ3JEO0FBQ0QsV0FBSztBQUNMO0lBQ0Q7QUFFQSxRQUFJLEtBQUssRUFBRSxRQUFRLGNBQWMsSUFBSSxZQUFZLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUU7QUFDakUsU0FBSztFQUNOO0FBRUEsU0FBTztBQUNSO0FBRU0sU0FBVSx5QkFBeUIsS0FBYSxPQUFhO0FBQ2xFLFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtFQUM3QztBQUVBLFFBQU0sV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUM1QixRQUFNLFFBQVEsTUFBTTtBQUNwQixRQUFNLE1BQU0sUUFBUTtBQUNwQixNQUFJLE1BQU0sSUFBSTtBQUFRLFVBQU0sSUFBSSxNQUFNLHNCQUFzQjtBQUU1RCxRQUFNLEVBQUUsT0FBTSxJQUFLLGVBQWUsS0FBSztBQUN2QyxTQUFPLHVCQUF1QixJQUFJLFNBQVMsT0FBTyxHQUFHLEdBQUcsTUFBTTtBQUMvRDtBQU1NLFNBQVUsOEJBQThCLEtBQWEsT0FBYTtBQUN2RSxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSw0QkFBNEI7RUFDN0M7QUFHQSxNQUFJLElBQUksVUFBVSx1QkFBdUIsTUFBTSxJQUFJLE1BQU07QUFDekQsUUFBTSxNQUFNLElBQUksU0FBUztBQUN6QixRQUFNLE1BQXVCLENBQUE7QUFHN0IsUUFBTSxFQUFFLE9BQU0sSUFBSyxlQUFlLEtBQUs7QUFHdkMsUUFBTSxvQkFBb0IsQ0FBQyxhQUFhLGlCQUFpQixXQUFXO0FBRXBFLFNBQU8sSUFBSSxJQUFJLEtBQUs7QUFDbkIsVUFBTSxTQUFTLElBQUksQ0FBQztBQUNwQixVQUFNLGVBQWUsSUFBSSxJQUFJLENBQUM7QUFFOUIsVUFBTSxhQUFhLElBQUksSUFBSTtBQUMzQixRQUFJLGFBQWE7QUFBSztBQUd0QixVQUFNLFdBQVcsa0JBQWtCLFNBQVMsWUFBWTtBQUV4RCxRQUFJO0FBQ0osUUFBSTtBQUNKLFFBQUk7QUFFSixRQUFJLFVBQVU7QUFFYixjQUFRLElBQUksSUFBSSxDQUFDO0FBQ2pCLGdCQUFVLElBQUksSUFBSSxDQUFDO0FBQ25CLFVBQUksSUFBSTtJQUNULE9BQU87QUFFTixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVDtBQUVBLFVBQU0sT0FBTyxJQUFJO0FBRWpCLFdBQU8sSUFBSSxJQUFJLE1BQU07QUFDcEIsWUFBTSxLQUFLLElBQUksQ0FBQztBQUNoQixVQUFJO0FBR0osVUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNO0FBQ25DLHFCQUFhLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLENBQUM7QUFDaEQsYUFBSztNQUNOLE9BQU87QUFDTixxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUM7QUFDeEIsYUFBSztNQUNOO0FBRUEsWUFBTSxVQUF5QjtRQUM5QixRQUFRO1FBQ1I7UUFDQTs7QUFFRCxVQUFJLFVBQVUsUUFBVztBQUN4QixnQkFBUSxRQUFRO01BQ2pCO0FBQ0EsVUFBSSxLQUFLLE9BQU87SUFDakI7QUFFQSxRQUFJO0VBQ0w7QUFFQSxTQUFPO0FBQ1I7QUFXTSxTQUFVLHNCQUFzQixPQUFlLEtBQVc7QUFDL0QsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0saUNBQWlDLE1BQU0sU0FBUyxFQUFFLENBQUMsR0FBRztFQUN2RTtBQUNBLFFBQU0sRUFBRSxVQUFTLElBQUssZUFBZSxLQUFLO0FBQzFDLFNBQU8sWUFBWSw4QkFBOEIsS0FBSyxLQUFLLElBQUkseUJBQXlCLEtBQUssS0FBSztBQUNuRztBQU1NLFNBQVUsb0JBQW9CLFNBQXdCLFNBQW1CO0FBRTlFLE1BQUksU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxRQUFRLFVBQVUsRUFBRSxPQUFPLFFBQVEsRUFBRTtBQUtuRixNQUFJLENBQUMsUUFBUTtBQUNaLFVBQU0sYUFBYSxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQ3JDLFVBQUksRUFBRSxXQUFXLFFBQVE7QUFBUSxlQUFPO0FBRXhDLFlBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDL0QsVUFBSSxDQUFDLGFBQWE7QUFBUyxlQUFPO0FBRWxDLFlBQU0sZ0JBQWdCLFFBQVEsS0FBSyxFQUFFO0FBQ3JDLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxhQUFhO0lBQzlELENBQUM7QUFDRCxRQUFJLFlBQVk7QUFDZixlQUFTO0lBQ1Y7RUFDRDtBQUVBLFFBQU0sU0FBUyxNQUFNLFFBQVEsTUFBTTtBQUNuQyxRQUFNLFFBQVEsTUFBTSxRQUFRLEVBQUU7QUFDOUIsUUFBTSxTQUFTLFdBQVcsUUFBUSxVQUFVO0FBQzVDLFFBQU0sU0FDTCxRQUFRLFdBQVcsV0FBVyxJQUMzQixlQUFlLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsR0FBRyxRQUFRLFdBQVcsQ0FBQyxDQUFDLElBQ2xGLFFBQVEsV0FBVyxXQUFXLElBQzdCLFFBQVEsV0FBVyxDQUFDLElBQ3BCLFFBQVEsV0FBVyxLQUFLLEdBQUc7QUFHaEMsUUFBTSxXQUFXLFFBQVEsVUFBVSxTQUFZLE9BQU8sUUFBUSxLQUFLLEtBQUs7QUFDeEUsUUFBTSxTQUFTLE9BQU8sTUFBTSxHQUFHLFFBQVEsT0FBTyxLQUFLLFFBQVEsTUFBTTtBQUdqRSxNQUFJLFFBQVE7QUFDWCxRQUFJLE9BQU8sT0FBTztBQUdsQixRQUFJLFFBQVEsVUFBVSxRQUFXO0FBQ2hDLGFBQU8sR0FBRyxJQUFJLE1BQU0sUUFBUSxRQUFRLENBQUM7SUFDdEMsT0FFSztBQUNKLFlBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsVUFBSSxhQUFhLFNBQVM7QUFDekIsY0FBTSxnQkFBZ0IsUUFBUSxLQUFLLE9BQU87QUFDMUMsY0FBTSxjQUFjLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtBQUMxRSxZQUFJLGFBQWE7QUFDaEIsaUJBQU8sR0FBRyxJQUFJLElBQUksWUFBWSxLQUFLO1FBQ3BDO01BQ0Q7SUFDRDtBQUdBLFVBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsUUFBSSxhQUFhLFdBQVcsUUFBUSxXQUFXLFdBQVcsR0FBRztBQUM1RCxZQUFNLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLFdBQVcsQ0FBQyxDQUFDO0FBQzdFLFVBQUksUUFBUTtBQUNYLGVBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSyxLQUFLLE1BQU07TUFDdkQ7SUFDRDtBQUNBLFdBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLE1BQU07RUFDdEM7QUFHQSxTQUFPLEdBQUcsTUFBTTtBQUNqQjtBQWlCTSxTQUFVLGlDQUNmLE9BQ0EsS0FBVztBQUVYLFFBQU0sU0FBUyxnQkFBZ0IsS0FBSztBQUNwQyxRQUFNLG9CQUFvQixRQUFRO0FBR2xDLE1BQUksc0JBQXNCLFFBQVc7QUFDcEMsVUFBTSxXQUFXLG9CQUNkLDhCQUE4QixLQUFLLEtBQUssSUFDeEMseUJBQXlCLEtBQUssS0FBSztBQUN0QyxXQUFPLEVBQUUsVUFBVSxtQkFBbUIsS0FBSTtFQUMzQztBQUdBLE1BQUksZUFBZ0MsQ0FBQTtBQUNwQyxNQUFJLG9CQUFxQyxDQUFBO0FBRXpDLE1BQUk7QUFDSCxtQkFBZSx5QkFBeUIsS0FBSyxLQUFLO0VBQ25ELFNBQVMsR0FBRztBQUNYLElBQUFBLFFBQU8sTUFBTSx1QkFBdUIsQ0FBQyxFQUFFO0VBQ3hDO0FBRUEsTUFBSTtBQUNILHdCQUFvQiw4QkFBOEIsS0FBSyxLQUFLO0VBQzdELFNBQVMsR0FBRztBQUNYLElBQUFBLFFBQU8sTUFBTSw0QkFBNEIsQ0FBQyxFQUFFO0VBQzdDO0FBR0EsTUFBSSxrQkFBa0IsU0FBUyxhQUFhLFFBQVE7QUFDbkQsSUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxrQkFBa0IsTUFBTSxZQUFZLGFBQWEsTUFBTSxHQUFHO0FBQ25ILFdBQU8sRUFBRSxVQUFVLG1CQUFtQixtQkFBbUIsS0FBSTtFQUM5RCxXQUFXLGFBQWEsU0FBUyxHQUFHO0FBQ25DLElBQUFBLFFBQU8sS0FBSyxtQ0FBbUMsYUFBYSxNQUFNLGlCQUFpQixrQkFBa0IsTUFBTSxHQUFHO0FBQzlHLFdBQU8sRUFBRSxVQUFVLGNBQWMsbUJBQW1CLE1BQUs7RUFDMUQsT0FBTztBQUVOLElBQUFBLFFBQU8sS0FBSyx1REFBdUQsS0FBSyxFQUFFO0FBQzFFLFdBQU8sRUFBRSxVQUFVLENBQUEsR0FBSSxtQkFBbUIsS0FBSTtFQUMvQztBQUNEO0FBRU0sU0FBVSw0QkFBNEIsT0FBZSxLQUFXO0FBQ3JFLFFBQU0sRUFBRSxVQUFTLElBQUssZUFBZSxLQUFLO0FBQzFDLFNBQU8sWUFBWSw4QkFBOEIsS0FBSyxLQUFLLElBQUkseUJBQXlCLEtBQUssS0FBSztBQUNuRztBQVNBLFNBQVMsbUJBQW1CLFlBQW9CO0FBQy9DLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsV0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxVQUFVLFNBQVMsV0FBVyxDQUFDLEVBQUM7RUFDN0U7QUFFQSxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFVBQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBQ2xCLFdBQU87TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE1BQU07TUFDTixTQUFTLGVBQWUsR0FBRyxHQUFHLENBQUM7O0VBRWpDO0FBRUEsU0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxPQUFPLFNBQVMsQ0FBQyxHQUFHLFVBQVUsRUFBQztBQUM1RTtBQU1NLFNBQVUsNEJBQ2YsV0FDQSxRQUNBLFdBQXNDO0FBRXRDLFFBQU0sTUFBTSxnQkFBZ0IsU0FBUztBQUdyQyxNQUFJLENBQUMsSUFBSSxXQUFXO0FBQ25CLFFBQUksWUFBWSxDQUFBO0VBQ2pCO0FBR0EsUUFBTSxhQUFhLE9BQU8sT0FBTyxTQUFTLEVBQ3hDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsVUFBVSxVQUFVLEtBQUssRUFDekMsS0FBSyxDQUFDLEdBQUcsTUFBTSxjQUFjLFVBQVUsT0FBTyxFQUFFLEtBQUssSUFBSSxjQUFjLFVBQVUsT0FBTyxFQUFFLEtBQUssQ0FBQztBQUVsRyxFQUFBQyxRQUFPLEtBQUssbUJBQW1CLFVBQVUsS0FBSyxFQUFFO0FBQ2hELEVBQUFBLFFBQU8sTUFBTSw2QkFBNkIsV0FBVyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLElBQUksQ0FBQyxFQUFFO0FBRXJGLGFBQVcsRUFBRSxRQUFRLElBQUksV0FBVSxLQUFNLFFBQVE7QUFDaEQsUUFBSSxTQUFTLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUV6RSxRQUFJLENBQUMsUUFBUTtBQUVaLGlCQUFXLEtBQUssWUFBWTtBQUMzQixjQUFNLFFBQVEsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ3pFLFlBQUksT0FBTztBQUNWLG1CQUFTLGdCQUFnQixLQUFLO0FBQzlCLGlCQUFPLE9BQU8sR0FBRyxNQUFNLElBQUkseUJBQXlCLEVBQUUsS0FBSztBQUMzRCxVQUFBQSxRQUFPLEtBQUssb0JBQW9CLE1BQU0sRUFBRSxDQUFDLGVBQWUsRUFBRSxLQUFLLEVBQUU7QUFDakU7UUFDRDtNQUNEO0lBQ0Q7QUFFQSxRQUFJLENBQUMsUUFBUTtBQUNaLGVBQVM7UUFDUjtRQUNBO1FBQ0EsTUFBTSxtQkFBbUIsTUFBTSxFQUFFLEVBQUUsWUFBVyxDQUFFO1FBQ2hELFNBQVMsQ0FBQyxtQkFBbUIsVUFBVSxDQUFDOztBQUV6QyxNQUFBQSxRQUFPLEtBQUssMkJBQTJCLE1BQU0sRUFBRSxDQUFDLEVBQUU7SUFDbkQsT0FBTztBQUNOLFlBQU0sTUFBTSxPQUFPLFVBQVUsQ0FBQztBQUM5QixVQUFJO0FBQUssWUFBSSxVQUFVLG1CQUFtQixVQUFVLEVBQUU7SUFDdkQ7QUFHQSxVQUFNLFNBQVMsSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxPQUFPLFVBQVUsRUFBRSxPQUFPLE9BQU8sRUFBRTtBQUN6RixRQUFJLENBQUM7QUFBUSxVQUFJLFVBQVUsS0FBSyxNQUFNO0VBQ3ZDO0FBRUEsU0FBTztBQUNSO0FBTU0sU0FBVSxvQkFBb0IsVUFBa0IsU0FBb0I7QUFDekUsTUFBSTtBQUVILFVBQU0sYUFBa0IsRUFBRSxPQUFPLFFBQVEsTUFBSztBQUc5QyxRQUFJLGVBQWUsU0FBUztBQUMzQixpQkFBVyxZQUFZLFFBQVE7SUFDaEM7QUFHQSxRQUFJLHlCQUF5QixTQUFTO0FBQ3JDLGlCQUFXLHNCQUFzQixRQUFRO0lBQzFDO0FBQ0EsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRO0lBQ2hDO0FBRUEsZUFBVyxPQUFPLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDdkMsVUFBSSxFQUFFLE9BQU8sYUFBYTtBQUN6QixtQkFBVyxHQUFHLElBQUssUUFBZ0IsR0FBRztNQUN2QztJQUNEO0FBR0EsUUFBSSxPQUFPLEtBQUssVUFBVSxZQUFZLE1BQU0sQ0FBQztBQUs3QyxXQUFPLEtBQUssUUFBUSwwREFBMEQsNkJBQTZCO0FBRTNHLElBQUFDLElBQUcsY0FBYyxVQUFVLE9BQU8sTUFBTSxNQUFNO0VBQy9DLFNBQVMsR0FBRztBQUNYLElBQUFELFFBQU8sTUFBTSxxQkFBcUIsQ0FBQyxFQUFFO0VBQ3RDO0FBQ0Q7OztBRGxnQkEsSUFBTUUsVUFBUyxtQkFBbUIsU0FBUztBQUVyQyxTQUFVLGNBQWMsTUFBb0I7QUFDakQsUUFBTSxhQUFhLGlCQUFnQjtBQUNuQyxRQUFNLGFBQWEsYUFBWTtBQUMvQixRQUFNLFVBQVUscUJBQXFCLFVBQVU7QUFDL0MsUUFBTSxlQUFvQixDQUFBO0FBRTFCLFFBQU0sY0FBYyxLQUFLO0FBQ3pCLEVBQUFBLFFBQU8sS0FDTiwrQkFBK0IsV0FBVyxzQkFBc0IsS0FBSyxPQUFPLGNBQWMsb0JBQW9CLEtBQUssUUFBUSxNQUFNLEVBQUU7QUFPcEksZUFBYSx1QkFBdUIsSUFBSTtJQUN2QyxNQUFNO0lBQ04sU0FBUyxDQUFBO0lBQ1QsVUFBVSxZQUFXO0FBQ3BCLFlBQU0sUUFBUTtBQUNkLFlBQU0sS0FBSyxLQUFLO0FBRWhCLFlBQU0sTUFBTSxNQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUd6RCxVQUFJLFlBQVksZ0JBQWdCLEtBQUs7QUFDckMsVUFBSSxDQUFDLFdBQVc7QUFDZixRQUFBQSxRQUFPLE1BQU0sU0FBUyxLQUFLLDRCQUE0QjtBQUN2RDtNQUNEO0FBR0EsWUFBTSxFQUFFLFVBQVUsUUFBUSxrQkFBaUIsSUFBSyxpQ0FBaUMsT0FBTyxHQUFHO0FBQzNGLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSyxVQUFVLE1BQU0sQ0FBQyxFQUFFO0FBR3RELFVBQUksc0JBQXNCLE1BQU07QUFDL0IsUUFBQUEsUUFBTyxLQUFLLDJCQUEyQixpQkFBaUIsd0JBQXdCO0FBQ2hGLG9CQUFZLEVBQUUsR0FBRyxXQUFXLFdBQVcsa0JBQWlCO01BQ3pEO0FBRUEsWUFBTSxVQUFVLDRCQUE0QixXQUFXLFFBQVEsT0FBTztBQUN0RSxNQUFBQSxRQUFPLE1BQU0scUJBQXFCLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxDQUFDLEVBQUU7QUFHcEUsWUFBTUMsaUJBQWdCLGlCQUFnQjtBQUN0QyxZQUFNLGFBQWFDLE1BQUssS0FBS0QsZ0JBQWUsUUFBUSxLQUFLLE9BQU87QUFDaEUsMEJBQW9CLFlBQVksT0FBTztBQUd2QywwQkFBbUI7QUFFbkIsTUFBQUQsUUFBTyxLQUFLLFNBQVMsS0FBSyx3Q0FBd0M7SUFDbkU7O0FBT0QsYUFBVyxDQUFDLFVBQVUsTUFBTSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDNUQsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxRQUFRO0FBR3hELFFBQUksVUFBVTtBQUFhO0FBRzNCLFVBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsVUFBTSxZQUFZLFFBQVEsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sTUFBTTtBQUUzRixpQkFBYSxRQUFRLElBQUk7TUFDeEIsR0FBRztNQUNILFVBQVUsT0FBTyxVQUFjO0FBQzlCLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBQ3pGLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTztBQUNuQyxjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxjQUFNLFlBQVksU0FBUztBQUUzQixjQUFNLEtBQUssYUFBYSxhQUFhLE9BQU8sT0FBTyxXQUFXLE9BQU8sRUFBRTtNQUN4RTs7RUFFRjtBQUtBLFFBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsTUFBSSxjQUFjO0FBQ2pCLFVBQU0sbUJBQW1CLGFBQWEsYUFBYSxDQUFBLEdBQUksS0FBSyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBRS9GLFFBQUksaUJBQWlCO0FBQ3BCLFlBQU0sV0FBVyxHQUFHLFdBQVc7QUFFL0IsbUJBQWEsUUFBUSxJQUFJO1FBQ3hCLE1BQU0sU0FBUyxXQUFXO1FBQzFCLFNBQVMsQ0FBQTtRQUNULFVBQVUsWUFBVztBQUNwQixnQkFBTSxLQUFLLEtBQUs7QUFDaEIsVUFBQUEsUUFBTyxLQUFLLHlCQUFvQixXQUFXLE1BQU0sRUFBRSxFQUFFO0FBQ3JELGdCQUFNLEtBQUssYUFBYSxjQUFjLEVBQUU7UUFDekM7O0lBRUY7RUFDRDtBQUVBLE9BQUsscUJBQXFCLFlBQVk7QUFFdEMsRUFBQUEsUUFBTyxLQUFLLGlDQUFpQyxPQUFPLEtBQUssWUFBWSxFQUFFLE1BQU0sRUFBRTtBQUNoRjs7O0FFbEhBLElBQU1HLFVBQVMsbUJBQW1CLFdBQVc7QUFLN0MsU0FBUyxpQkFDUixTQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQWE7QUFFYixRQUFNLFVBQVUscUJBQXFCLFNBQVMsT0FBTyxPQUFPLFNBQVM7QUFDckUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLFFBQVEsUUFBUSxPQUFPO0FBQUcsV0FBTztBQUd4RCxRQUFNLGNBQWMsUUFBUSxRQUFRLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3pFLE1BQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxRQUFRLFlBQVksT0FBTztBQUFHLFdBQU87QUFHaEUsUUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sS0FBSztBQUNsRSxTQUFPLFFBQVEsU0FBUztBQUN6QjtBQU1NLFNBQVUsZ0JBQWdCLE1BQW9CO0FBQ25ELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxlQUFlLGVBQWM7QUFDbkMsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0saUJBQXNCLENBQUE7QUFHNUIsUUFBTSxjQUFjLEtBQUs7QUFDekIsRUFBQUEsUUFBTyxLQUNOLGlDQUFpQyxXQUFXLHNCQUFzQixLQUFLLE9BQU8sY0FBYyxvQkFBb0IsS0FBSyxRQUFRLE1BQU0sRUFBRTtBQU90SSxhQUFXLENBQUMsWUFBWSxRQUFRLEtBQUssT0FBTyxRQUFRLFlBQVksR0FBRztBQUNsRSxVQUFNLEVBQUUsT0FBTyxPQUFPLE9BQU0sSUFBSyxlQUFlLFVBQVU7QUFHMUQsUUFBSSxVQUFVO0FBQWE7QUFHM0IsbUJBQWUsVUFBVSxJQUFJO01BQzVCLEdBQUc7TUFDSCxVQUFVLENBQUMsa0JBQXNCO0FBQ2hDLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxjQUFjLFFBQVEsT0FBTztBQUMzQyxjQUFNLFFBQVEsY0FBYyxRQUFRLE9BQU8sS0FBSztBQUNoRCxjQUFNLFlBQVksU0FBUztBQUMzQixjQUFNLFVBQVUsS0FBSyxhQUFhLGdCQUFnQixJQUFJLE9BQU8sV0FBVyxLQUFLO0FBRzdFLGNBQU0sWUFBWSxjQUFjLFFBQVEsV0FBVyxLQUFLO0FBRXhELFlBQUksYUFBYSxZQUFZLFFBQVc7QUFFdkMsaUJBQU8saUJBQWlCLFNBQVMsT0FBTyxPQUFPLFdBQVcsT0FBTztRQUNsRTtBQUdBLGVBQU8sV0FBVztNQUNuQjs7RUFFRjtBQUVBLE9BQUssdUJBQXVCLGNBQWM7QUFFMUMsRUFBQUEsUUFBTyxLQUFLLHFDQUFxQyxPQUFPLEtBQUssY0FBYyxFQUFFLE1BQU0sRUFBRTtBQUN0Rjs7O0FDbkZBLE9BQU9DLFlBQVc7OztBQ0FsQixPQUFPLFdBQVc7QUFDbEIsT0FBTyxRQUFRO0FBSWYsSUFBTUMsVUFBUyxtQkFBbUIsT0FBTztBQUtsQyxJQUFNLHlCQUF5QjtBQUUvQixJQUFNLDBCQUEwQjtBQWdCaEMsSUFBTSxxQkFBcUIsTUFBTztBQWlCbkMsU0FBVSx3QkFBcUI7QUFDcEMsUUFBTSxNQUFNLE9BQU8sTUFBTSxJQUFJLENBQUM7QUFDOUIsUUFBTSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU0sSUFBSyxLQUFNO0FBRTdDLE1BQUksY0FBYyxPQUFRLENBQUM7QUFDM0IsTUFBSSxjQUFjLHdCQUF3QixDQUFDO0FBQzNDLE1BQUksY0FBYyxLQUFLLENBQUM7QUFFeEIsUUFBTSxNQUFNLGlCQUFnQjtBQUM1QixNQUFJLEtBQUssS0FBSyxDQUFDO0FBRWYsU0FBTyxLQUFLLFlBQVksT0FBTyxFQUFFLEtBQUssS0FBSyxFQUFFO0FBQzdDLE1BQUksY0FBYyxNQUFRLEVBQUU7QUFDNUIsTUFBSSxjQUFjLEtBQVEsRUFBRTtBQUM1QixNQUFJLGNBQWMsS0FBWSxFQUFFO0FBRWhDLFNBQU87QUFDUjtBQUdNLFNBQVUsbUJBQWdCO0FBQy9CLE1BQUk7QUFDSCxVQUFNLFNBQVMsR0FBRyxrQkFBaUI7QUFDbkMsZUFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMsaUJBQVcsUUFBUSxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdEMsWUFBSSxDQUFDLEtBQUssWUFBWSxLQUFLLFdBQVcsVUFBVSxLQUFLLE9BQU8sS0FBSyxRQUFRLHFCQUFxQjtBQUM3RixpQkFBTyxPQUFPLEtBQUssS0FBSyxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFjLFNBQVMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUMzRTtNQUNEO0lBQ0Q7RUFDRCxRQUFRO0VBRVI7QUFDQSxTQUFPLE9BQU8sTUFBTSxHQUFHLENBQUM7QUFDekI7QUFpQk0sU0FBVSx1QkFBdUIsS0FBYSxPQUFhO0FBQ2hFLE1BQUksSUFBSSxTQUFTO0FBQW9CLFdBQU87QUFDNUMsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVEsV0FBTztBQUMzQyxNQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBeUIsV0FBTztBQUM1RCxNQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZLFdBQU87QUFFbEUsUUFBTSxVQUFVLENBQUMsUUFBZ0IsUUFDaEMsSUFDRSxTQUFTLFFBQVEsU0FBUyxHQUFHLEVBQzdCLFNBQVMsT0FBTyxFQUNoQixNQUFNLElBQUksRUFBRSxDQUFDLEVBQ2IsS0FBSTtBQUVQLFFBQU0sUUFBUSxJQUFJLFNBQVMsR0FBRyxFQUFFO0FBQ2hDLFFBQU0sV0FBVyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQzVFLFFBQU0sTUFBTSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUV6RSxRQUFNLE9BQU8sUUFBUSxJQUFNLEVBQUU7QUFDN0IsUUFBTSxlQUFlLFFBQVEsSUFBTSxFQUFFO0FBQ3JDLFFBQU0sV0FBVyxRQUFRLEtBQU0sRUFBRTtBQUNqQyxRQUFNLGdCQUFnQixHQUFHLElBQUksRUFBSSxDQUFDLElBQUksSUFBSSxFQUFJLENBQUM7QUFFL0MsTUFBSSxDQUFDO0FBQVUsV0FBTztBQUl0QixRQUFNLFFBQVEsU0FDWixRQUFRLGNBQWMsRUFBRSxFQUN4QixLQUFJLEVBQ0osTUFBTSxLQUFLLEVBQUUsQ0FBQztBQUVoQixTQUFPO0lBQ04sSUFBSTtJQUNKO0lBQ0E7SUFDQTtJQUNBLFdBQVc7O0lBQ1g7SUFDQTs7QUFFRjtBQU9BLGVBQXNCLHFCQUFxQixRQUFjO0FBQ3hELFNBQU8sSUFBSSxRQUFrQixDQUFDLFNBQVMsV0FBVTtBQUNoRCxVQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFFckMsUUFBSSxLQUFLLFNBQVMsQ0FBQyxRQUFPO0FBQ3pCLFVBQUksTUFBSztBQUNULGFBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQzdDLENBQUM7QUFFRCxRQUFJLFFBQVEsR0FBRyxRQUFRLE1BQUs7QUFDM0IsVUFBSTtBQUNILGNBQU0sT0FBTyxJQUFJLFFBQU87QUFDeEIsY0FBTSxZQUFZLEtBQUs7QUFDdkIsWUFBSSxNQUFLO0FBRVQsY0FBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLG1CQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxxQkFBVyxTQUFTLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN2QyxnQkFDQyxNQUFNLFdBQVcsVUFDakIsTUFBTSxZQUFZLGFBQ2xCLE1BQU0sT0FDTixNQUFNLFFBQVEscUJBQ2I7QUFDRCxxQkFBTyxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxTQUFTLEdBQUcsRUFBRSxJQUFJLEdBQUksQ0FBQztZQUN2RTtVQUNEO1FBQ0Q7QUFDQSxlQUFPLElBQUksTUFBTSx3Q0FBd0MsU0FBUyxFQUFFLENBQUM7TUFDdEUsU0FBUyxJQUFJO0FBQ1osZUFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztNQUM3QjtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7QUFNQSxlQUFzQiw4QkFBOEIsUUFBYztBQUNqRSxTQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksV0FBVztBQUNmLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLENBQUMsVUFBVTtBQUNkLG1CQUFXO0FBQ1gsWUFBSSxNQUFLO0FBQ1QsZUFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDN0M7SUFDRCxDQUFDO0FBR0QsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxrQkFBUSxTQUFTO1FBQ2xCO01BQ0QsU0FBUyxJQUFJO0FBQ1osWUFBSSxDQUFDLFVBQVU7QUFDZCxxQkFBVztBQUNYLGNBQUksTUFBSztBQUNULGlCQUFPLElBQUksTUFBTSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQzdCO01BQ0Q7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBV0EsZUFBc0IsZ0JBQ3JCLFVBQ0Esa0JBQ0EsWUFBWSxLQUFJO0FBRWhCLFFBQU0sdUJBQXVCO0FBQzdCLFFBQU0sc0JBQXNCO0FBQzVCLFFBQU0sZUFBZTtBQUVyQixRQUFNLGFBQWEsb0JBQUksSUFBRztBQUUxQixTQUFPLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDcEMsVUFBTSxpQkFBaUIsTUFBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBRTNFLFVBQU0sVUFBVSxNQUFLO0FBQ3BCLFVBQUk7QUFDSCx1QkFBZSxlQUFlLG9CQUFvQjtNQUNuRCxRQUFRO01BRVI7QUFDQSxVQUFJO0FBQ0gsdUJBQWUsTUFBSztNQUNyQixRQUFRO01BRVI7QUFDQSxjQUFPO0lBQ1I7QUFFQSxVQUFNLFFBQVEsV0FBVyxTQUFTLFNBQVM7QUFDM0MsVUFBTSxRQUFPO0FBRWIsbUJBQWUsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNsQyxNQUFBQSxRQUFPLEtBQUssMEJBQTBCLElBQUksT0FBTyxFQUFFO0lBQ3BELENBQUM7QUFFRCxtQkFBZSxHQUFHLFdBQVcsQ0FBQyxLQUFLLFVBQVM7QUFDM0MsWUFBTSxRQUFRLE1BQU07QUFFcEIsVUFBSSxJQUFJLFNBQVM7QUFBSTtBQUNyQixVQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBUTtBQUNwQyxVQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBRTNELFVBQUksV0FBVyxJQUFJLEtBQUs7QUFBRztBQUMzQixpQkFBVyxJQUFJLEtBQUs7QUFDcEIsTUFBQUEsUUFBTyxNQUFNLGlCQUFpQixLQUFLLCtCQUEwQjtBQUs3RCxZQUFNLFlBQVksWUFBVztBQUM1QixjQUFNLGlCQUFpQixLQUFLO0FBQzVCLGNBQU0sUUFBUSxzQkFBcUI7QUFDbkMsaUJBQVMsS0FBSyxPQUFPLGNBQWMsT0FBTyxDQUFDLFFBQU87QUFDakQsY0FBSTtBQUFLLFlBQUFBLFFBQU8sS0FBSyxvQkFBb0IsS0FBSyxZQUFZLElBQUksT0FBTyxFQUFFO1FBQ3hFLENBQUM7TUFDRjtBQUNBLGdCQUFTLEVBQUcsTUFBTSxDQUFDLFFBQVFBLFFBQU8sS0FBSyx1QkFBdUIsR0FBRyxFQUFFLENBQUM7SUFDckUsQ0FBQztBQUVELG1CQUFlLEtBQUsscUJBQXFCLE1BQUs7QUFDN0MsVUFBSTtBQUNILHVCQUFlLGNBQWMsb0JBQW9CO0FBQ2pELFFBQUFBLFFBQU8sS0FBSyxvQ0FBb0Msb0JBQW9CLElBQUksbUJBQW1CLEVBQUU7TUFDOUYsU0FBUyxLQUFLO0FBQ2IsUUFBQUEsUUFBTyxLQUFLLDRDQUE0QyxHQUFHLEVBQUU7TUFDOUQ7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGOzs7QURwUUEsSUFBTUMsVUFBUyxtQkFBbUIsY0FBYztBQUUxQyxJQUFPLGVBQVAsTUFBTyxjQUFZO0VBQ1AsY0FBc0I7RUFDdEIsaUJBQWlCO0VBQ2pCLFNBQVM7RUFFbEI7RUFDQTs7RUFDQSxjQUdKLG9CQUFJLElBQUc7RUFDSCxtQkFBZ0Msb0JBQUksSUFBRzs7O0VBR3ZDLFlBQTJCLFFBQVEsUUFBTzs7RUFHMUMsc0JBQXNCOztFQUd0Qjs7RUFHQSxRQUFnQjtFQUNoQixVQUFzQixDQUFBO0VBQ3RCLHNCQUErQjs7Ozs7Ozs7RUFRL0IsY0FBZ0Qsb0JBQUksSUFBRzs7Ozs7OztFQVF2RCxnQkFBNkIsb0JBQUksSUFBRzs7RUFHcEMscUJBQWdFLG9CQUFJLElBQUc7O0VBR3ZFOztFQUdBLFdBQWtDLG9CQUFJLElBQUc7RUFFakQsY0FBQTtBQUNDLElBQUFBLFFBQU8sS0FBSywwQkFBMEI7QUFJdEMsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDcEUsU0FBSyxVQUFVLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDNUMsV0FBSyxTQUFTLEtBQUssR0FBRyxNQUFLO0FBQzFCLFFBQUFELFFBQU8sTUFBTSwyQkFBNEIsS0FBSyxTQUFTLFFBQU8sRUFBd0IsSUFBSSxFQUFFO0FBQzVGLGdCQUFPO01BQ1IsQ0FBQztJQUNGLENBQUM7QUFDRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBR0QsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFcEUsU0FBSyxTQUFTLEdBQUcsYUFBYSxNQUFLO0FBQ2xDLFlBQU0sT0FBTyxLQUFLLFNBQVMsUUFBTztBQUNsQyxNQUFBRCxRQUFPLE1BQU0sMEJBQTBCLEtBQUssVUFBVSxJQUFJLENBQUMsRUFBRTtBQUM3RCxVQUFJO0FBQ0gsYUFBSyxTQUFTLHFCQUFxQixJQUFJO01BQ3hDLFNBQVMsSUFBSTtNQUViO0lBQ0QsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzFDLFVBQUk7QUFDSCxhQUFLLGVBQWUsS0FBSyxNQUFNLE9BQU87TUFDdkMsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxFQUFFLEVBQUU7TUFDdEQ7SUFDRCxDQUFDO0FBR0QsU0FBSyxTQUFTLEtBQUssRUFBRSxTQUFTLFdBQVcsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2xFLE1BQUFBLFFBQU8sTUFBTSw4QkFBOEIsS0FBSyxNQUFNLEVBQUU7SUFDekQsQ0FBQztFQUNGO0VBRU8sUUFBSztBQUNYLFFBQUk7QUFDSCxpQkFBVyxhQUFhLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixHQUFHO0FBQzFELFlBQUk7QUFDSCxlQUFLLFNBQVMsZUFBZSxLQUFLLGdCQUFnQixTQUFTO1FBQzVELFFBQVE7UUFFUjtNQUNEO0lBQ0QsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7RUFDRDs7Ozs7RUFNTyxTQUFTLE9BQWUsU0FBcUIsc0JBQStCLE1BQUk7QUFDdEYsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVO0FBQ2YsU0FBSyxzQkFBc0I7RUFDNUI7Ozs7O0VBTU8sb0JBQW9CLFVBQXNDO0FBQ2hFLFNBQUssbUJBQW1CO0VBQ3pCOztFQUdPLG1CQUFtQixJQUFVO0FBQ25DLFdBQU8sS0FBSyxjQUFjLElBQUksRUFBRTtFQUNqQzs7RUFHTyxnQkFBZ0IsSUFBVTtBQUNoQyxTQUFLLGNBQWMsSUFBSSxFQUFFO0FBQ3pCLElBQUFBLFFBQU8sTUFBTSx3QkFBd0IsRUFBRSxFQUFFO0VBQzFDOztFQUdPLGFBQWEsSUFBVTtBQUM3QixTQUFLLGNBQWMsT0FBTyxFQUFFO0FBQzVCLFNBQUssWUFBWSxPQUFPLEVBQUU7QUFDMUIsU0FBSyxTQUFTLE9BQU8sRUFBRTtBQUN2QixJQUFBQSxRQUFPLE1BQU0scUJBQXFCLEVBQUUsRUFBRTtFQUN2Qzs7Ozs7OztFQVFPLE1BQU0sWUFBWSxJQUFZLFlBQVksS0FBSTtBQUNwRCxXQUFPLElBQUksUUFBMkIsQ0FBQyxZQUFXO0FBQ2pELFlBQU0sTUFBTSxXQUFXLEVBQUU7QUFDekIsVUFBSSxXQUFXO0FBRWYsWUFBTSxTQUFTLENBQUMsV0FBNkI7QUFDNUMsWUFBSTtBQUFVO0FBQ2QsbUJBQVc7QUFDWCxhQUFLLG1CQUFtQixPQUFPLEdBQUc7QUFDbEMsZ0JBQVEsTUFBTTtNQUNmO0FBRUEsV0FBSyxtQkFBbUIsSUFBSSxLQUFLLENBQUMsV0FBc0I7QUFDdkQsWUFBSSxPQUFPLE9BQU87QUFBSSxpQkFBTyxNQUFNO01BQ3BDLENBQUM7QUFFRCxZQUFNLFFBQVEsV0FBVyxNQUFNLE9BQU8sSUFBSSxHQUFHLFNBQVM7QUFDdEQsWUFBTSxRQUFPO0FBRWIsWUFBTSxNQUFNLFlBQVc7QUFDdEIsY0FBTSxLQUFLLG9CQUFvQixFQUFFO0FBQ2pDLGNBQU0sS0FBSztBQUNYLGNBQU0sUUFBUSxzQkFBcUI7QUFDbkMsYUFBSyxTQUFTLEtBQUssT0FBTyxLQUFLLGFBQWEsSUFBSSxDQUFDLFFBQU87QUFDdkQsY0FBSSxLQUFLO0FBQ1IsWUFBQUEsUUFBTyxLQUFLLFlBQVksRUFBRSxZQUFZLElBQUksT0FBTyxFQUFFO0FBQ25ELHlCQUFhLEtBQUs7QUFDbEIsbUJBQU8sSUFBSTtVQUNaO1FBQ0QsQ0FBQztNQUNGO0FBRUEsVUFBRyxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQ2pCLFFBQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsRUFBRTtBQUN0RCxxQkFBYSxLQUFLO0FBQ2xCLGVBQU8sSUFBSTtNQUNaLENBQUM7SUFDRixDQUFDO0VBQ0Y7Ozs7O0VBTU8sTUFBTSxtQkFBbUIsVUFBZ0I7QUFDL0MsSUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxRQUFRLEVBQUU7QUFDdEQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLHNCQUFzQixRQUFXLFFBQVcsUUFBVyxVQUFVLEtBQUs7QUFFL0csV0FBTztFQUNSOzs7Ozs7Ozs7OztFQVlPLE1BQU0sZ0JBQWdCLFlBQVksS0FBSTtBQUU1QyxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLGVBQTZCLENBQUE7QUFFbkMsVUFBTSxnQkFBZ0IsQ0FBQyxXQUFzQjtBQUM1QyxVQUFJLENBQUMsYUFBYSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxFQUFFLEdBQUc7QUFDbEQscUJBQWEsS0FBSyxNQUFNO01BQ3pCO0lBQ0Q7QUFHQSxTQUFLLG1CQUFtQixJQUFJLGVBQWUsYUFBYTtBQUV4RCxRQUFJO0FBQ0gsWUFBTSxLQUFLO0FBR1gsWUFBTSxnQkFBZ0IsS0FBSyxVQUFVLE9BQU8sV0FBVyxLQUFLLG9CQUFvQixNQUFNLEdBQUcsU0FBUztBQUNsRyxhQUFPO0lBQ1I7QUFDQyxXQUFLLG1CQUFtQixPQUFPLGFBQWE7SUFDN0M7RUFDRDs7Ozs7RUFNTyxNQUFNLHVCQUF1QixVQUFnQjtBQUNuRCxJQUFBQSxRQUFPLEtBQUssb0NBQW9DLFFBQVEsRUFBRTtBQUMxRCxVQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsa0JBQWtCLFFBQVcsUUFBVyxRQUFXLFVBQVUsS0FBSztBQUkzRyxVQUFNLFlBQVk7QUFFbEIsUUFBSSxTQUFTLFNBQVMsWUFBWSxHQUFHO0FBQ3BDLE1BQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsU0FBUyxNQUFNLFFBQVE7QUFDbkUsYUFBTztJQUNSO0FBR0EsVUFBTSxRQUFRLFNBQVMsWUFBWSxDQUFDO0FBQ3BDLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUVwQyxVQUFNLFdBQ0wsUUFBUSxLQUNMLE1BQU0sU0FBUSxFQUFHLFNBQVMsR0FBRyxHQUFHLElBQ2hDLE1BQU0sU0FBUTtBQUVsQixVQUFNLFdBQVcsR0FBRyxLQUFLLElBQUksUUFBUTtBQUVyQyxJQUFBQSxRQUFPLEtBQUsscUJBQXFCLFFBQVEsRUFBRTtBQUMzQyxXQUFPO0VBQ1I7Ozs7O0VBTVEsTUFBTSxvQkFBb0IsUUFBYztBQUMvQyxRQUFJO0FBQ0gsWUFBTSxZQUFZLE1BQU0sOEJBQThCLE1BQU07QUFDNUQsVUFBSSxDQUFDLFdBQVc7QUFDZixRQUFBQSxRQUFPLEtBQUsscURBQXFELE1BQU0sRUFBRTtBQUN6RTtNQUNEO0FBRUEsVUFBSSxLQUFLLGlCQUFpQixJQUFJLFNBQVMsR0FBRztBQUV6QztNQUNEO0FBRUEsVUFBSTtBQUNILGFBQUssU0FBUyxjQUFjLEtBQUssZ0JBQWdCLFNBQVM7QUFDMUQsYUFBSyxpQkFBaUIsSUFBSSxTQUFTO0FBQ25DLFFBQUFBLFFBQU8sS0FBSyxvQkFBb0IsS0FBSyxjQUFjLE9BQU8sU0FBUyxFQUFFO01BQ3RFLFNBQVMsSUFBSTtBQUNaLFFBQUFBLFFBQU8sS0FBSywrQkFBK0IsU0FBUyxLQUFLLE9BQU8sRUFBRSxDQUFDLEVBQUU7TUFDdEU7SUFDRCxTQUFTLElBQUk7QUFDWixNQUFBQSxRQUFPLEtBQUssK0JBQStCLEVBQUUsRUFBRTtJQUNoRDtFQUNEO0VBRU8sTUFBTSxhQUNaLE9BQ0EsT0FDQSxXQUNBLE9BQ0EsUUFDQSxTQUFTLE1BQUk7QUFFYixTQUFLO0FBQ0wsV0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFdBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxZQUNwQyxLQUFLLGNBQWMsT0FBTyxPQUFPLFdBQVcsT0FBTyxRQUFRLE1BQU0sRUFDL0QsS0FBSyxDQUFDLFFBQU87QUFDYixhQUFLO0FBRUwsWUFBSSxLQUFLLHdCQUF3QixLQUFLLEtBQUssdUJBQXVCLGNBQWMsUUFBVztBQUMxRixlQUFLLG1CQUFtQixNQUFNLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDN0MsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGO0FBQ0EsZ0JBQVEsR0FBRztNQUNaLENBQUMsRUFDQSxNQUFNLENBQUMsUUFBTztBQUNkLGFBQUs7QUFDTCxlQUFPLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzNELENBQUMsQ0FBQztJQUVMLENBQUM7RUFDRjtFQUVRLE1BQU0sY0FDYixPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUFJO0FBRWIsVUFBTSxZQUFZO0FBSWxCLFFBQUksQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEdBQUc7QUFDcEMsWUFBTSxJQUFJLE1BQU0sYUFBYSxNQUFNLGlGQUE0RTtJQUNoSDtBQUdBLFVBQU0sS0FBSyxvQkFBb0IsTUFBTTtBQUVyQyxVQUFNLFlBQXNCLENBQUE7QUFDNUIsUUFBSSxjQUFjO0FBQVcsZ0JBQVUsS0FBSyxZQUFZLEdBQUk7QUFDNUQsUUFBSSxVQUFVO0FBQVcsZ0JBQVUsS0FBSyxHQUFHLGNBQWEsZ0JBQWdCLEtBQUssQ0FBQztBQUU5RSxVQUFNLGNBQXdCLENBQUMsSUFBTSxRQUFRLEdBQUk7QUFFakQsUUFBSSxVQUFVO0FBQVcsa0JBQVksS0FBSyxRQUFRLEdBQUk7QUFDdEQsUUFBSTtBQUFRLGtCQUFZLEtBQUssVUFBVSxNQUFNO0FBRTdDLFFBQUksVUFBVSxTQUFTO0FBQUcsa0JBQVksS0FBSyxHQUFHLFNBQVM7QUFFdkQsVUFBTSxNQUFNLGNBQWEsVUFBVSxXQUFXO0FBQzlDLFVBQU0saUJBQWlCLE9BQU8sS0FBSyxDQUFDLEdBQUcsYUFBYSxHQUFHLENBQUM7QUFFeEQsVUFBTSxXQUFXLEtBQUssZUFBZTtBQUNyQyxVQUFNLFNBQVMsTUFBTSxLQUFLLFlBQVksVUFBVSxNQUFNO0FBQ3RELFVBQU0sU0FBUyxPQUFPLE9BQU8sQ0FBQyxRQUFRLGNBQWMsQ0FBQztBQUdyRCxRQUFJLGNBQWMsVUFBYSxVQUFVLFFBQVc7QUFDbkQsWUFBTSxhQUFhLGNBQWEsZ0JBQWdCLEtBQUs7QUFDckQsWUFBTSxVQUF5QjtRQUM5QixRQUFRO1FBQ1IsSUFBSTtRQUNKO1FBQ0E7O0FBRUQsTUFBQUEsUUFBTyxLQUFLLE1BQU0sTUFBTSxNQUFNLG9CQUFvQixTQUFTLEtBQUssT0FBTyxDQUFDLEVBQUU7SUFDM0UsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxlQUFlLEtBQUssQ0FBQyxFQUFFO0lBQ3REO0FBQ0EsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixNQUFNLEtBQUssT0FBTyxTQUFTLEtBQUssQ0FBQyxFQUFFO0FBRXJFLFVBQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxLQUFLO0FBRTlCLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxZQUFNLFFBQVEsV0FBVyxNQUFLO0FBQzdCLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZUFBTyxJQUFJLE1BQU0sc0NBQXNDLEtBQUssS0FBSyxPQUFPLE1BQU0sT0FBTyxDQUFDO01BQ3ZGLEdBQUcsU0FBUztBQUVaLFdBQUssWUFBWSxJQUFJLEtBQUs7UUFDekIsU0FBUyxDQUFDLFFBQU87QUFDaEIsdUJBQWEsS0FBSztBQUNsQixrQkFBUSxHQUFHO1FBQ1o7UUFDQSxRQUFRLENBQUMsUUFBTztBQUNmLHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sR0FBRztRQUNYO1FBQ0E7T0FDQTtBQUVELFdBQUssU0FBUyxLQUFLLFFBQVEsS0FBSyxhQUFhLFFBQVEsQ0FBQyxRQUFPO0FBQzVELFlBQUksS0FBSztBQUNSLGVBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDN0M7TUFDRCxDQUFDO0lBQ0YsQ0FBQztFQUNGO0VBRVEsZUFBZSxLQUFhLE9BQWE7QUFDaEQsUUFBSSxJQUFJLFNBQVM7QUFBRztBQUNwQixRQUFJLElBQUksQ0FBQyxNQUFNLE9BQVEsSUFBSSxDQUFDLE1BQU07QUFBTTtBQUV4QyxVQUFNLFVBQVUsSUFBSSxhQUFhLENBQUM7QUFLbEMsUUFBSSxZQUFZLDJCQUEyQixLQUFLLG1CQUFtQixPQUFPLEdBQUc7QUFDNUUsWUFBTSxTQUFTLHVCQUF1QixLQUFLLEtBQUs7QUFDaEQsVUFBSSxRQUFRO0FBQ1gsUUFBQUEsUUFBTyxNQUNOLDRCQUE0QixLQUFLLGVBQ25CLE9BQU8sSUFBSSxhQUNkLE9BQU8sS0FBSyxpQkFDUixPQUFPLFNBQVMsb0JBQ2IsT0FBTyxZQUFZLEdBQUc7QUFJekMsWUFBSSxPQUFPLFNBQVMsWUFBWTtBQUMvQixxQkFBVyxNQUFNLEtBQUssbUJBQW1CLE9BQU0sR0FBSTtBQUNsRCxnQkFBSTtBQUNILGlCQUFHLE1BQU07WUFDVixRQUFRO1lBRVI7VUFDRDtRQUNELE9BQU87QUFDTixVQUFBQSxRQUFPLE1BQU0sc0RBQXNELE9BQU8sSUFBSSxPQUFPLEtBQUssRUFBRTtRQUM3RjtNQUNEO0FBQ0E7SUFDRDtBQUVBLFFBQUksSUFBSSxTQUFTO0FBQUk7QUFHckIsVUFBTSxNQUFNLElBQUksU0FBUyxJQUFJLEVBQUU7QUFDL0IsUUFBSSxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQVk7QUFJMUMsVUFBTSxZQUFZLElBQUksU0FBUyxFQUFFO0FBQ2pDLFFBQUksVUFBVSxTQUFTO0FBQUc7QUFDMUIsUUFBSSxVQUFVLENBQUMsTUFBTTtBQUFNO0FBRzNCLFVBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsVUFBTSxjQUFjLFlBQVksU0FBVTtBQUMxQyxVQUFNLGdCQUFnQixZQUFZO0FBR2xDLFFBQUksY0FBYyxrQkFBa0Isc0JBQXNCO0FBQ3pELE1BQUFBLFFBQU8sTUFBTSx3QkFBd0IsS0FBSyxLQUFLLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRTtJQUNyRTtBQUdBLFNBQUssYUFBYSxPQUFPLGVBQWUsS0FBSyxTQUFTO0FBR3RELFFBQUksWUFBWTtBQUNmLFlBQU0sTUFBTSxHQUFHLEtBQUssSUFBSSxhQUFhO0FBQ3JDLFlBQU0sVUFBVSxLQUFLLFlBQVksSUFBSSxHQUFHO0FBQ3hDLFVBQUksU0FBUztBQUNaLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZ0JBQVEsUUFBUSxHQUFHO01BQ3BCO0lBQ0Q7RUFFRDs7Ozs7Ozs7Ozs7O0VBYVEsYUFBYSxPQUFlLE9BQWUsS0FBYSxXQUFpQjtBQUNoRixVQUFNLFVBQVUsZUFBZSxLQUFLO0FBQ3BDLFVBQU0sT0FBTyxVQUFVLFNBQVMsR0FBRyxVQUFVLFNBQVMsQ0FBQztBQUd2RCxVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxDQUFDO0FBQzFDLFVBQU0sZ0JBQWdCLFFBQVEsTUFBTSxTQUFTLENBQUMsU0FBUyxLQUFLLFNBQVMsS0FBSyxDQUFDLFFBQVEsTUFBTSxHQUFHLENBQUM7QUFLN0YsUUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFJLENBQUMsS0FBSyxPQUFPO0FBQ2hCLFFBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxFQUFFO0FBQ3pEO01BQ0Q7QUFDQSxVQUFJO0FBQ0gsY0FBTSxXQUNMLFVBQVUsb0JBQ1Asc0JBQXNCLEtBQUssT0FBTyxHQUFHLElBQ3JDLDRCQUE0QixLQUFLLE9BQU8sR0FBRztBQUUvQyxjQUFNLFlBQVksS0FBSyxZQUFZLElBQUksS0FBSyxLQUFLLG9CQUFJLElBQUc7QUFDeEQsY0FBTSxXQUFXLElBQUksSUFBb0IsU0FBUztBQUVsRCxtQkFBVyxLQUFLLFVBQVU7QUFDekIsZ0JBQU0sV0FBVyxjQUFjLEtBQUssT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSztBQUVsRSxnQkFBTSxXQUNMLEVBQUUsV0FBVyxXQUFXLElBQ3BCLEVBQUUsV0FBVyxDQUFDLEtBQUssS0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLElBQUssRUFBRSxXQUFXLENBQUMsSUFDaEUsRUFBRSxXQUFXLENBQUMsS0FBSztBQUN4QixnQkFBTSxZQUFZLFVBQVUsSUFBSSxRQUFRO0FBQ3hDLGdCQUFNLFVBQVUsY0FBYyxVQUFhLGNBQWM7QUFFekQsbUJBQVMsSUFBSSxVQUFVLFFBQVE7QUFFL0IsZ0JBQU0sWUFBWSxvQkFBb0IsR0FBRyxLQUFLLE9BQU87QUFDckQsY0FBSSxTQUFTO0FBQ1osWUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLFNBQVMsRUFBRTtBQUV4QyxnQkFBSSxLQUFLLGtCQUFrQjtBQUMxQixvQkFBTSxrQkFBa0IsY0FBYyxLQUFLLE9BQU8sRUFBRSxRQUFRLEVBQUUsRUFBRTtBQUVoRSxtQkFBSyxpQkFBaUIsZUFBZTtZQUN0QyxPQUFPO0FBQ04sY0FBQUEsUUFBTyxLQUFLLGdFQUEyRCxRQUFRLEVBQUU7WUFDbEY7VUFDRCxPQUFPO0FBQ04sWUFBQUEsUUFBTyxNQUFNLE1BQU0sS0FBSyxNQUFNLFNBQVMsRUFBRTtVQUMxQztRQUNEO0FBQ0EsYUFBSyxZQUFZLElBQUksT0FBTyxRQUFRO01BQ3JDLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLG9CQUFvQixDQUFDLE1BQU0sYUFBYSxFQUFFO01BQy9FO0FBQ0E7SUFDRDtBQUdBLFVBQU0sVUFBVSxLQUFLLGFBQWEsT0FBTyxJQUFJO0FBQzdDLFFBQUksU0FBUztBQUNaLE1BQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxNQUFNLE9BQU8sRUFBRTtJQUN2RSxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7SUFDMUQ7RUFDRDs7Ozs7RUFNUSxhQUFhLE9BQWUsTUFBWTtBQUMvQyxRQUFJLEtBQUssV0FBVztBQUFHLGFBQU87QUFHOUIsUUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixVQUFJLEtBQUssQ0FBQyxNQUFNLEdBQU07QUFDckIsZUFBTztNQUNSLE9BQU87QUFDTixlQUFPLFNBQVMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO01BQy9CO0lBQ0Q7QUFFQSxZQUFRLE9BQU87Ozs7O01BS2QsS0FBSyxjQUFjO0FBQ2xCLFlBQUksS0FBSyxXQUFXLEdBQUc7QUFDdEIsaUJBQU8sS0FBSyxDQUFDLE1BQU0sSUFBTyxXQUFXLFdBQVcsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQy9EO0FBQ0EsWUFBSSxLQUFLLFVBQVUsR0FBRztBQUNyQixnQkFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixnQkFBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixnQkFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO0FBQ2xDLGdCQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBQ2hGLGdCQUFNLGNBQWMsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLENBQUM7QUFDL0QsZ0JBQU0sVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0FBQ3RDLGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGNBQWMsR0FBRyxXQUFXLEtBQUssTUFBTSxRQUFTLENBQUMsTUFBTSxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUM7QUFDekcsZ0JBQU0sU0FBUyxJQUFJLE1BQU0sS0FBSyxDQUFDLElBQUksTUFBTSxTQUFTLENBQUMsS0FBSyxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUMsQ0FBQztBQUMxRixpQkFBTyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUSxJQUFJLE1BQU07UUFDaEU7QUFDQSxlQUFPLFFBQVEsS0FBSyxTQUFTLEtBQUssQ0FBQztNQUNwQzs7TUFHQSxLQUFLLGlCQUFpQjtBQUVyQixZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLFVBQVUsUUFBUSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEdBQUc7QUFDaEUsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGVBQWUsS0FBSyxXQUFXLFNBQVMsS0FBSyxDQUFDO0FBQy9ELGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRO1FBQ3REO0FBQ0EsZUFBTztNQUNSOztNQUdBLEtBQUs7TUFDTCxLQUFLLGFBQWE7QUFDakIsWUFBSSxLQUFLLFNBQVM7QUFBRyxpQkFBTztBQUM1QixjQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGNBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsY0FBTSxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQzdCLGVBQU8sTUFBTSxLQUFLLFlBQVksTUFBTSxTQUFTLENBQUMsVUFBVSxNQUFNLFNBQVMsS0FBSyxDQUFDO01BQzlFO01BRUE7QUFDQyxlQUFPO0lBQ1Q7RUFDRDtFQUVRLE9BQU8sZ0JBQWdCLE9BQWM7QUFDNUMsUUFBSSxPQUFPLFVBQVU7QUFBVyxhQUFPLENBQUMsUUFBUSxJQUFJLENBQUM7QUFDckQsUUFBSSxNQUFNLFFBQVEsS0FBSztBQUFHLGFBQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxPQUFPLENBQUMsSUFBSSxHQUFJO0FBQ2xFLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDOUIsVUFBSSxRQUFRO0FBQU0sZUFBTyxDQUFFLFNBQVMsS0FBTSxLQUFPLFNBQVMsSUFBSyxLQUFNLFFBQVEsR0FBSTtBQUNqRixhQUFPLENBQUMsUUFBUSxHQUFJO0lBQ3JCO0FBQ0EsVUFBTSxJQUFJLE1BQU0sNENBQTRDLEtBQUssRUFBRTtFQUNwRTtFQUVRLE1BQU0sWUFBWSxVQUFrQixRQUFjO0FBQ3pELFFBQUksTUFBTSxLQUFLLFNBQVMsSUFBSSxNQUFNO0FBQ2xDLFFBQUksQ0FBQyxLQUFLO0FBQ1QsWUFBTSxNQUFNLHFCQUFxQixNQUFNO0FBQ3ZDLFdBQUssU0FBUyxJQUFJLFFBQVEsR0FBRztJQUM5QjtBQUVBLFdBQU8sT0FBTyxPQUFPO01BQ3BCLE9BQU8sS0FBSyxDQUFDLEtBQU0sS0FBTSxHQUFNLFdBQVcsS0FBTSxHQUFNLEtBQU0sR0FBTSxHQUFNLEdBQUcsS0FBSyxHQUFNLENBQUksQ0FBQztNQUMzRixPQUFPLEtBQUssWUFBWSxNQUFNO0tBQzlCO0VBQ0Y7RUFFUSxPQUFPLFVBQVUsTUFBYztBQUN0QyxRQUFJLE1BQU07QUFDVixlQUFXLEtBQUssTUFBTTtBQUNyQixhQUFPO0FBQ1AsZUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDM0IsZUFBTyxNQUFNLFNBQVUsS0FBTSxPQUFPLElBQUssT0FBUSxNQUFRLE9BQU8sSUFBSztNQUN0RTtJQUNEO0FBQ0EsV0FBTztFQUNSOzs7Ozs7Ozs7O0VBV08sZ0JBQWdCLElBQVksT0FBZSxXQUFtQixPQUFjO0FBQ2xGLFVBQU0sTUFBTSxjQUFjLEtBQUssT0FBTyxPQUFPLFdBQVcsS0FBSztBQUM3RCxXQUFPLEtBQUssWUFBWSxJQUFJLEVBQUUsR0FBRyxJQUFJLEdBQUc7RUFDekM7RUFFTyxNQUFNLFlBQVksUUFBYztBQUN0QyxXQUFPLEtBQUssYUFBYSxrQkFBa0IsUUFBVyxHQUFNLFFBQVcsUUFBUSxLQUFLO0VBQ3JGO0VBRU8sTUFBTSxjQUFjLFFBQWM7QUFDeEMsV0FBTyxLQUFLLGFBQWEscUJBQXFCLFFBQVcsUUFBVyxRQUFXLFFBQVEsS0FBSztFQUM3Rjs7OztBRS9zQkQsT0FBT0UsV0FBVTtBQUVqQixJQUFNQyxVQUFTLG1CQUFtQixnQkFBZ0I7QUFNbEQsSUFBcUIsaUJBQXJCLGNBQTRDLGFBQXlCO0VBQ3BFOztFQUNBOzs7RUFJUSxvQkFBa0MsQ0FBQTs7O0VBSTFDLGNBQXNCO0VBRXRCLFlBQVksVUFBaUI7QUFDNUIsVUFBTSxRQUFRO0VBQ2Y7RUFFQSxNQUFNLEtBQUssUUFBb0I7QUFDOUIsU0FBSyxTQUFTO0FBQ2QsUUFBSSxDQUFDLEtBQUssY0FBYztBQUN2QixXQUFLLGVBQWUsSUFBSSxhQUFZO0lBQ3JDO0FBQ0EsU0FBSyxhQUFhLGVBQWUsRUFBRTtBQUduQyxTQUFLLGFBQWEsb0JBQW9CLENBQUMsZUFBc0I7QUFDNUQsV0FBSyxlQUFlLFVBQVU7SUFDL0IsQ0FBQztBQUlELFNBQUssYUFBWSxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQy9CLE1BQUFBLFFBQU8sTUFBTSxxQkFBcUIsQ0FBQyxFQUFFO0lBQ3RDLENBQUM7RUFDRjs7Ozs7OztFQVFRLE1BQU0sZUFBWTtBQUN6QixJQUFBQSxRQUFPLEtBQUssOEJBQThCO0FBRTFDLFNBQUssb0JBQW9CLE1BQU0sS0FBSyxhQUFhLGdCQUFlO0FBR2hFLFFBQUk7QUFDSixRQUFJLEtBQUssa0JBQWtCLFdBQVcsR0FBRztBQUN4QyxZQUFNLGNBQWMsS0FBSyxPQUFPO0FBQ2hDLFVBQUksQ0FBQyxLQUFLLE9BQU8sUUFBUSxDQUFDLGFBQWE7QUFDdEMsUUFBQUEsUUFBTyxLQUFLLHlEQUF5RDtBQUNyRTtNQUNEO0FBQ0EsTUFBQUEsUUFBTyxLQUFLLHdFQUFtRTtBQUMvRSx1QkFBaUI7SUFDbEIsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxjQUFjLEtBQUssa0JBQWtCLE1BQU0sYUFBYTtBQUNwRSxpQkFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3ZDLFFBQUFBLFFBQU8sS0FBSyxhQUFhLEVBQUUsS0FBSyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRTtNQUNyRTtBQUtBLGlCQUFXLFVBQVUsS0FBSyxtQkFBbUI7QUFDNUMsYUFBSyxhQUFhLGdCQUFnQixPQUFPLEVBQUU7TUFDNUM7QUFHQSxpQkFBVyxVQUFVLEtBQUssbUJBQW1CO0FBQzVDLFlBQUk7QUFDSCxnQkFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLHVCQUF1QixPQUFPLEVBQUU7QUFDekUsaUJBQU8sZUFBZTtBQUN0QixVQUFBQSxRQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsY0FBYyxRQUFRLFdBQVcsT0FBTyxhQUFhLEVBQUU7UUFDcEYsU0FBUyxHQUFHO0FBQ1gsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLDZCQUE2QixDQUFDLEVBQUU7QUFDNUQsaUJBQU8sZUFBZTtRQUN2QjtNQUNEO0FBRUEsdUJBQWlCLGFBQWEsS0FBSyxRQUFRLEtBQUssaUJBQWlCO0lBQ2xFO0FBR0EsU0FBSyxVQUFVLGNBQWM7QUFJN0IsVUFBTSxhQUFhLEtBQUs7QUFDeEIsVUFBTSxLQUFLLG9CQUFvQixJQUFJLFVBQVU7QUFHN0MsU0FBSyxjQUFhO0FBQ2xCLFNBQUssZ0JBQWU7QUFDcEIsU0FBSywwQkFBeUI7QUFDOUIsU0FBSyxxQkFBb0I7QUFFekIsSUFBQUEsUUFBTyxLQUFLLDJCQUEyQjtFQUN4Qzs7RUFHQSxNQUFNLFVBQU87QUFDWixTQUFLLGNBQWMsTUFBSztBQUN4QixJQUFBQSxRQUFPLE1BQU0sU0FBUztFQUN2QjtFQUVBLE1BQU0sY0FBYyxRQUFvQjtBQUN2QyxVQUFNLGVBQWUsS0FBSztBQUMxQixTQUFLLFNBQVM7QUFDZCxVQUFNLGlCQUFpQixhQUFhLFFBQVEsS0FBSyxpQkFBaUI7QUFDbEUsU0FBSyxVQUFVLGNBQWM7QUFJN0IsU0FBSyxxQkFBb0I7QUFFekIsVUFBTSxVQUFVLEtBQUs7QUFJckIsVUFBTSxLQUFLLG9CQUFvQixjQUFjLE9BQU87QUFHcEQsU0FBSyxjQUFhO0FBQ2xCLFNBQUssZ0JBQWU7QUFDcEIsU0FBSywwQkFBeUI7QUFDOUIsU0FBSyxxQkFBb0I7RUFDMUI7Ozs7Ozs7Ozs7Ozs7RUFjUSxNQUFNLG9CQUFvQixjQUFzQixTQUFlO0FBQ3RFLFFBQUksQ0FBQyxTQUFTO0FBQ2IsVUFBSTtBQUFjLGFBQUssYUFBYSxhQUFhLFlBQVk7QUFDN0Q7SUFDRDtBQUVBLFFBQUksS0FBSyxPQUFPLGdCQUFnQjtBQUkvQixZQUFNLFdBQVcsS0FBSyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDcEUsVUFBSSxDQUFDLFVBQVU7QUFDZCxRQUFBQSxRQUFPLEtBQUssbUJBQW1CLE9BQU8sNkRBQXdEO0FBQzlGLGFBQUssYUFBYSxhQUFhLE9BQU87QUFDdEM7TUFDRDtBQUdBLFVBQUksZ0JBQWdCLGlCQUFpQixTQUFTO0FBQzdDLGFBQUssYUFBYSxhQUFhLFlBQVk7TUFDNUM7QUFDQSxZQUFNLGdCQUFnQixLQUFLLGFBQWEsbUJBQW1CLE9BQU87QUFDbEUsVUFBSSxDQUFDLGVBQWU7QUFDbkIsYUFBSyxhQUFhLGdCQUFnQixPQUFPO01BQzFDO0FBQ0EsVUFBSSxZQUFZLGdCQUFnQixDQUFDLGVBQWU7QUFDL0MsY0FBTSxRQUFRLGFBQWEsS0FBSyxRQUFRLEtBQUssaUJBQWlCO0FBQzlELGNBQU0sS0FBSyw2QkFBNkIsT0FBTyxPQUFPO01BQ3ZEO0FBQ0E7SUFDRDtBQUdBLFVBQU0sY0FBYyxLQUFLLE9BQU87QUFDaEMsVUFBTSxpQkFBaUIsS0FBSyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFFMUUsUUFBSSxnQkFBZ0I7QUFDbkIsVUFBSSxlQUFlLFVBQVUsYUFBYTtBQUN6QyxZQUFJLGdCQUFnQixpQkFBaUI7QUFBUyxlQUFLLGFBQWEsYUFBYSxZQUFZO0FBQ3pGLGNBQU0sZ0JBQWdCLEtBQUssYUFBYSxtQkFBbUIsT0FBTztBQUNsRSxZQUFJLENBQUMsZUFBZTtBQUNuQixlQUFLLGFBQWEsZ0JBQWdCLE9BQU87UUFDMUM7QUFDQSxZQUFJLFlBQVksZ0JBQWdCLENBQUMsZUFBZTtBQUMvQyxnQkFBTSxLQUFLLDZCQUE2QixhQUFhLE9BQU87UUFDN0Q7TUFDRCxPQUFPO0FBQ04sUUFBQUEsUUFBTyxNQUNOLDBCQUEwQixXQUFXLDJDQUEyQyxlQUFlLEtBQUssUUFBUSxPQUFPLDBCQUFxQjtBQUV6SSxhQUFLLGFBQWEsYUFBYSxPQUFPO01BQ3ZDO0FBQ0E7SUFDRDtBQUdBLElBQUFBLFFBQU8sS0FBSyxHQUFHLE9BQU8sd0NBQW1DO0FBQ3pELFFBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLFdBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsU0FBSyxhQUFhLGFBQWEsT0FBTztBQUV0QyxVQUFNLFNBQVMsTUFBTSxLQUFLLGFBQWEsWUFBWSxPQUFPO0FBQzFELFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxNQUFNLDBCQUEwQixPQUFPLDBCQUFxQjtJQUNwRSxXQUFXLE9BQU8sVUFBVSxhQUFhO0FBQ3hDLE1BQUFBLFFBQU8sTUFDTiwwQkFBMEIsV0FBVywyQ0FBMkMsT0FBTyxLQUFLLFFBQVEsT0FBTywwQkFBcUI7SUFFbEksT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxrQkFBa0IsT0FBTyxLQUFLLE9BQU8sT0FBTyxFQUFFO0FBQzFELFdBQUssYUFBYSxnQkFBZ0IsT0FBTztBQUN6QyxZQUFNLEtBQUssNkJBQTZCLGFBQWEsT0FBTztJQUM3RDtFQUNEOzs7OztFQU1RLE1BQU0sNkJBQTZCLE9BQWUsSUFBVTtBQUNuRSxRQUFJO0FBQ0gsWUFBTSxNQUFNLE1BQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFO0FBRXpELFVBQUksQ0FBQyxnQkFBZ0IsS0FBSyxHQUFHO0FBQzVCLFFBQUFBLFFBQU8sS0FBSyw2QkFBNkIsS0FBSyx1Q0FBa0M7QUFFaEYsY0FBTSxFQUFFLFVBQVUsUUFBUSxrQkFBaUIsSUFBSyxpQ0FBaUMsT0FBTyxHQUFHO0FBQzNGLFlBQUksT0FBTyxXQUFXLEdBQUc7QUFDeEIsVUFBQUEsUUFBTyxLQUFLLHNDQUFzQyxLQUFLLDRCQUF1QjtBQUM5RTtRQUNEO0FBRUEsY0FBTSxVQUFVLHFCQUFxQixpQkFBZ0IsQ0FBRTtBQUN2RCxjQUFNLFlBQVksRUFBRSxPQUFPLFdBQVcscUJBQXFCLE9BQU8sV0FBVyxDQUFBLEVBQVc7QUFDeEYsWUFBSSxzQkFBc0IsTUFBTTtBQUMvQixvQkFBVSxZQUFZO1FBQ3ZCO0FBQ0EsY0FBTSxVQUFVLDRCQUE0QixXQUFrQixRQUFRLE9BQWM7QUFFcEYsY0FBTSxhQUFhRCxNQUFLLEtBQUssaUJBQWdCLEdBQUksUUFBUSxLQUFLLE9BQU87QUFDckUsNEJBQW9CLFlBQVksT0FBTztBQUN2Qyw0QkFBbUI7QUFDbkIsUUFBQUMsUUFBTyxLQUFLLDRCQUE0QixLQUFLLE9BQU8sVUFBVSxFQUFFO0FBR2hFLGFBQUssVUFBVSxLQUFLO0FBQ3BCLGFBQUssY0FBYTtBQUNsQixhQUFLLGdCQUFlO0FBQ3BCLGFBQUssMEJBQXlCO01BQy9CO0lBQ0QsU0FBUyxHQUFHO0FBQ1gsTUFBQUEsUUFBTyxLQUFLLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxFQUFFO0lBQ3hEO0VBQ0Q7O0VBR1EsVUFBVSxPQUFhO0FBQzlCLFNBQUssY0FBYztBQUNuQixVQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsUUFBSSxDQUFDLFFBQVE7QUFDWixNQUFBQSxRQUFPLEtBQUssVUFBVSxLQUFLLCtCQUErQjtBQUMxRCxXQUFLLGFBQWEsU0FBUyxPQUFPLENBQUEsR0FBSSxJQUFJO0FBQzFDO0lBQ0Q7QUFFQSxVQUFNLFVBQVUsTUFBTSxRQUFRLE9BQU8sU0FBUyxJQUFJLE9BQU8sWUFBWSxDQUFBO0FBQ3JFLFVBQU0sc0JBQXNCLE9BQU8sdUJBQXVCO0FBRTFELFNBQUssYUFBYSxTQUFTLE9BQU8sU0FBUyxtQkFBbUI7QUFDOUQsUUFBSSxRQUFRLFdBQVcsR0FBRztBQUN6QixNQUFBQSxRQUFPLEtBQUssK0JBQStCLEtBQUssNkNBQXdDO0lBQ3pGLE9BQU87QUFDTixNQUFBQSxRQUFPLE1BQ04sVUFBVSxRQUFRLE1BQU0sdUJBQXVCLEtBQUssZ0JBQWdCLE9BQU8sU0FBUyx5QkFBeUIsbUJBQW1CLEVBQUU7SUFFcEk7RUFDRDtFQUVBLGtCQUFlO0FBQ2QsV0FBTyxnQkFBZ0IsS0FBSyxpQkFBaUI7RUFDOUM7O0VBR0EsSUFBSSxPQUFJO0FBQ1AsV0FBTyxZQUFZLEtBQUssTUFBTTtFQUMvQjs7RUFHQSxJQUFJLFVBQU87QUFDVixXQUFPLEtBQUs7RUFDYjtFQUVBLGdCQUFhO0FBQ1osa0JBQWMsSUFBSTtFQUNuQjtFQUVBLGtCQUFlO0FBQ2Qsb0JBQWdCLElBQUk7RUFDckI7RUFFQSw0QkFBeUI7QUFDeEIsOEJBQTBCLElBQUk7RUFDL0I7RUFFQSx1QkFBb0I7QUFDbkIseUJBQXFCLElBQUk7RUFDMUI7OyIsCiAgIm5hbWVzIjogWyJwYXRoIiwgIkluc3RhbmNlU3RhdHVzIiwgIlJlZ2V4IiwgInBhdGgiLCAiZnMiLCAibG9nZ2VyIiwgImxvZ2dlciIsICJmcyIsICJsb2dnZXIiLCAiZGV2aWNlc0ZvbGRlciIsICJwYXRoIiwgImxvZ2dlciIsICJkZ3JhbSIsICJsb2dnZXIiLCAibG9nZ2VyIiwgImRncmFtIiwgInBhdGgiLCAibG9nZ2VyIl0KfQo=
