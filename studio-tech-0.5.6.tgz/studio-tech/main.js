import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual (enter IP + model below)" },
    ...discoveredDevices.map((d) => ({
      id: d.mac ?? "",
      label: `Model ${d.model} [${d.mac}] @ ${d.ip}`
    }))
  ];
  return [
    // ── Device selection dropdown ────────────────────────────────────────
    // Stores the MAC so re-discovery with a changed IP still matches.
    {
      type: "dropdown",
      id: "deviceMac",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry — only visible in manual mode ────────────────────
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Manual model selector — only visible in manual mode ──────────────
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Select which Studio Technologies model is active for actions and feedbacks."
    }
  ];
}
function resolveHost(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    return device?.ip ?? "";
  }
  return String(config.host ?? "");
}
function resolveModel(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    logger.debug(`resolveModel: deviceMac="${config.deviceMac}", found device: ${device?.model ?? "none"}`);
    return device?.model ?? "";
  }
  logger.debug(`resolveModel: manual mode, activeModel="${config.activeModel}"`);
  return String(config.activeModel ?? "");
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_BUS_GET:
      return "Heartbeat";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "textinput":
    case "colorpicker":
    case "static-text":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  const idAddDeferRanges = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    for (const baseEntry of c.cmdSchema ?? []) {
      const idAddOpt = baseEntry.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        continue;
      const baseId = baseEntry.id;
      const cmdId = baseEntry.cmd_id;
      const key = `${cmdId}_${baseId}`;
      if (idAddDeferRanges.has(key))
        continue;
      const parsedOffsets = parsed.filter((p) => p.cmd_id === cmdId && p.id > baseId).map((p) => p.id - baseId).sort((a, b) => a - b);
      let maxSeq = 0;
      for (const off of parsedOffsets) {
        if (off === maxSeq + 1)
          maxSeq = off;
        else if (off > maxSeq + 1)
          break;
      }
      if (maxSeq > 0) {
        idAddDeferRanges.set(key, maxSeq);
        logger2.debug(`idAdd defer range for cmd_id=${toHex(cmdId)} base_id=${toHex(baseId)}: offsets 1\u2013${maxSeq}`);
      }
    }
  }
  const busChSeen = /* @__PURE__ */ new Map();
  for (const { cmd_id, id, busCh } of parsed) {
    if (busCh === void 0)
      continue;
    const key = `${cmd_id}_${id}`;
    if (!busChSeen.has(key))
      busChSeen.set(key, /* @__PURE__ */ new Set());
    busChSeen.get(key).add(busCh);
  }
  for (const { cmd_id, id, busCh, valueBytes } of parsed) {
    const existingExact = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (existingExact) {
      const opt = existingExact.options?.find((o) => o.id === "value");
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
      continue;
    }
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt = a.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        return false;
      if (id <= a.id)
        return false;
      const offset = id - a.id;
      return candidates.some((c) => {
        const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === a.id);
        const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
        return refIdAdd?.choices?.some((ch) => ch.id === offset);
      });
    });
    if (idAddBase) {
      const offset = id - idAddBase.id;
      const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
      if (idAddOpt?.choices && !idAddOpt.choices.some((c) => c.id === offset)) {
        let label = `Channel ${offset + 1}`;
        for (const c of candidates) {
          const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
          const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
          const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
          if (refChoice) {
            label = refChoice.label;
            break;
          }
        }
        idAddOpt.choices.push({ id: offset, label });
        logger2.info(`Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
      }
      continue;
    }
    let action;
    for (const c of candidates) {
      const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
      if (match) {
        action = structuredClone(match);
        const baseName = match.name.replace(/\s*\(inferred from Model [^)]+\)/g, "").trim();
        action.name = `${baseName} (inferred from Model ${c.model})`;
        logger2.info(`Inferred cmd_id=${toHex(cmd_id)} id=${toHex(id)} from Model ${c.model} (exact)`);
        break;
      }
    }
    if (!action) {
      let shouldDefer = false;
      for (const c of candidates) {
        const baseEntry = c.cmdSchema?.find((a) => {
          if (a.cmd_id !== cmd_id)
            return false;
          const idAddOpt = a.options?.find((o) => o.id === "idAdd");
          if (!idAddOpt?.choices)
            return false;
          if (id <= a.id)
            return false;
          const offset = id - a.id;
          const maxSeq = idAddDeferRanges.get(`${cmd_id}_${a.id}`) ?? 0;
          return offset <= maxSeq;
        });
        if (baseEntry) {
          shouldDefer = true;
          logger2.debug(`cmd_id=${toHex(cmd_id)} id=${toHex(id)} is an idAdd offset of candidate base id=${toHex(baseEntry.id)} \u2014 deferring to pass 2`);
          break;
        }
      }
      if (shouldDefer)
        continue;
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown cmd:${toHex(cmd_id)} id:${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      if (busCh !== void 0)
        action.busCh = busCh;
      logger2.warn(`Could not infer cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
    } else {
      action.options = action.options?.filter((o) => o.id !== "busCh") ?? [];
      delete action.busCh;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        if (maxBusCh === 0) {
          action.busCh = 0;
        } else {
          const busChChoices = Array.from({ length: maxBusCh + 1 }, (_, i) => ({
            id: i,
            label: `Channel ${i + 1}`
          }));
          action.options.unshift({
            id: "busCh",
            label: "Channel",
            type: "dropdown",
            choices: busChChoices,
            default: 0
          });
        }
      }
      const observedDefault = valueBytesToOption(valueBytes).default;
      const valueOpt = action.options?.find((o) => o.id === "value");
      if (valueOpt) {
        if (valueOpt.choices && Array.isArray(valueOpt.choices)) {
          const inChoices = valueOpt.choices.some((c) => c.id === observedDefault);
          if (!inChoices) {
            logger2.warn(`Inferred choices for cmd_id=${toHex(cmd_id)} id=${toHex(id)} don't contain observed value ${observedDefault} \u2014 discarding inherited choices`);
            valueOpt.type = "number";
            delete valueOpt.choices;
          }
        }
        valueOpt.default = observedDefault;
      }
    }
    out.cmdSchema.push(action);
  }
  for (const { cmd_id, id } of parsed) {
    const alreadyTopLevel = out.cmdSchema.some((a) => a.cmd_id === cmd_id && a.id === id);
    if (alreadyTopLevel)
      continue;
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt2 = a.options?.find((o) => o.id === "idAdd");
      return !!idAddOpt2?.choices && id > a.id;
    });
    if (!idAddBase)
      continue;
    const offset = id - idAddBase.id;
    const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
    if (!idAddOpt?.choices || idAddOpt.choices.some((c) => c.id === offset))
      continue;
    const refHasOffset = candidates.some((c) => {
      const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      return refIdAdd?.choices?.some((ch) => ch.id === offset);
    });
    const existingOffsets = idAddOpt.choices.map((c) => c.id).sort((a, b) => a - b);
    const isSequential = existingOffsets.length > 0 && offset === existingOffsets[existingOffsets.length - 1] + 1;
    if (!refHasOffset && !isSequential)
      continue;
    let label = `Channel ${offset + 1}`;
    for (const c of candidates) {
      const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
      if (refChoice) {
        label = refChoice.label;
        break;
      }
    }
    idAddOpt.choices.push({ id: offset, label });
    logger2.info(`Pass 2: Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("refreshAfterCommand" in jsonObj) {
      orderedObj.refreshAfterCommand = jsonObj.refreshAfterCommand;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema.map((entry) => {
        const orderedEntry = {};
        if ("cmd_id" in entry)
          orderedEntry.cmd_id = entry.cmd_id;
        if ("id" in entry)
          orderedEntry.id = entry.id;
        if ("busCh" in entry)
          orderedEntry.busCh = entry.busCh;
        if ("name" in entry)
          orderedEntry.name = entry.name;
        if ("options" in entry)
          orderedEntry.options = entry.options;
        for (const key of Object.keys(entry)) {
          if (!(key in orderedEntry))
            orderedEntry[key] = entry[key];
        }
        return orderedEntry;
      });
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  wiredActions["global_getAllSettings"] = {
    name: "GLOBAL: Get All Settings (Auto-Update JSON)",
    options: [],
    callback: async () => {
      const model = activeModel;
      const ip = self.host;
      const buf = await self.stController.requestAllSettings(ip);
      let modelJson = getDeviceSchema(model);
      const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
      logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
      if (!modelJson) {
        logger3.info(`Model ${model} has no schema \u2014 creating new JSON from settings`);
        modelJson = {
          model,
          sectioned: detectedSectioned ?? false,
          refreshAfterCommand: true,
          cmdSchema: []
        };
      } else if (detectedSectioned !== null) {
        logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
        modelJson = { ...modelJson, sectioned: detectedSectioned };
      }
      const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
      logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
      const devicesFolder2 = getDevicesFolder();
      const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
      saveModelJsonPretty(schemaPath, updated);
      reloadDeviceSchemas();
      logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
    }
  };
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
  logger3.info(`UpdateActions: wired actions: ${Object.keys(wiredActions).length}`);
}

// dist/feedbacks.js
var logger4 = createModuleLogger("Feedbacks");
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        let busCh = feedbackEvent.options["busCh"];
        if (busCh === void 0) {
          const schemaAction = findActionForSetting(schemas, model, cmdId, settingId);
          if (schemaAction?.busCh !== void 0) {
            busCh = schemaAction.busCh;
          }
        }
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
  logger4.info(`UpdateFeedbacks: wired feedbacks: ${Object.keys(wiredFeedbacks).length}`);
}

// dist/stcontroller.js
import dgram2 from "dgram";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger5 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const cleanup = () => {
      try {
        announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP);
      } catch {
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger5.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger5.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger5.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger5.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      try {
        announceSocket.addMembership(DANTE_ANNOUNCE_GROUP);
        logger5.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      } catch (err) {
        logger5.warn(`Could not join announce multicast group: ${err}`);
      }
    });
  });
}

// dist/stcontroller.js
var logger6 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  refreshAfterCommand = true;
  // Default to true (most devices need it)
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered by discoverDevices() — keyed by source IP */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  constructor() {
    logger6.info("StController initialized");
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger6.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger6.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger6.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger6.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger6.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger6.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
    });
  }
  close() {
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions, refreshAfterCommand = true) {
    this.model = model;
    this.actions = actions;
    this.refreshAfterCommand = refreshAfterCommand;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger6.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    logger6.debug(`Revoked device at ${ip}`);
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    return new Promise((resolve) => {
      const key = `__probe_${ip}__`;
      let resolved = false;
      const finish = (result) => {
        if (resolved)
          return;
        resolved = true;
        this.discoveryListeners.delete(key);
        resolve(result);
      };
      this.discoveryListeners.set(key, (device) => {
        if (device.ip === ip)
          finish(device);
      });
      const timer = setTimeout(() => finish(null), timeoutMs);
      timer.unref?.();
      const run = async () => {
        await this.ensureMembershipFor(ip);
        await this.txReady;
        const query = buildDanteInfoRequest();
        this.txSocket.send(query, this.defaultPort, ip, (err) => {
          if (err) {
            logger6.warn(`Probe to ${ip} failed: ${err.message}`);
            clearTimeout(timer);
            finish(null);
          }
        });
      };
      run().catch((e) => {
        logger6.warn(`probeDevice setup failed for ${ip}: ${e}`);
        clearTimeout(timer);
        finish(null);
      });
    });
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger6.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Strategy:
   *  Dante devices broadcast a 1-second announce to multicast 224.0.0.233:8708.
   *  We listen on that group, collect source IPs, then send a unicast device info
   *  request (0x0020) to each new IP on port 8700. The device responds to our IP
   *  on port 8702 (rxSocket), where handleIncoming() picks it up and fires the
   *  discoveryListeners callback.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    const onDeviceFound = (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    };
    this.discoveryListeners.set(DISCOVERY_KEY, onDeviceFound);
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger6.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger6.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger6.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger6.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger6.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger6.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger6.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && this.refreshAfterCommand && value !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger6.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    if (!this.authorizedIps.has(destIp)) {
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    await this.ensureMembershipFor(destIp);
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (busCh !== void 0)
      payloadBody.push(busCh & 255);
    if (addLen)
      payloadBody.push(dataBlock.length);
    if (dataBlock.length > 0)
      payloadBody.push(...dataBlock);
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger6.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger6.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    logger6.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger6.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger6.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse && originalCmdId === CMD_GET_ALL_SETTINGS) {
      logger6.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
    }
    this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger6.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger6.info(`RX ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, s.id);
              this.feedbackCallback(baseFeedbackKey);
            } else {
              logger6.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger6.debug(`RX ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger6.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    const logFn = cmdId === CMD_BUS_GET ? logger6.debug.bind(logger6) : logger6.info.bind(logger6);
    if (decoded) {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger7 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Connecting, "Discovering devices...");
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger7.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger7.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      if (this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger7.warn(`Saved device MAC "${this.config.deviceMac}" not found during discovery \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger7.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger7.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger7.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger7.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger7.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger7.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
      if (!effectiveModel && this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger7.warn(`Saved device MAC "${this.config.deviceMac}" not found among discovered devices \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    this.updateStatus(InstanceStatus.Ok);
    logger7.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger7.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current config is authorized to send commands.
   *
   * Auto mode (deviceMac set):
   *   - Find the discovered device with matching MAC → get its current IP
   *   - Revoke the previous IP, authorize the new IP
   *   - If MAC not found in discovery, revoke and block
   *
   * Manual mode (deviceMac empty):
   *   - Check discovered list by IP+model match, or probe directly
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.deviceMac) {
      const device = this.discoveredDevices.find((d) => d.mac === this.config.deviceMac);
      if (!device) {
        logger7.warn(`Device MAC "${this.config.deviceMac}" not found in current discovery \u2014 not authorizing`);
        if (previousHost)
          this.stController.revokeDevice(previousHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        await this.fetchSettingsAndEnsureSchema(device.model, newHost);
      }
      return;
    }
    const manualModel = String(this.config.activeModel ?? "");
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
      } else {
        logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
        this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${discoveredAtIp.model}`);
      }
      return;
    }
    logger7.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger7.error(`No device responded at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.UnknownWarning, `Device offline: ${newHost}`);
    } else if (probed.model !== manualModel) {
      logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${probed.model}`);
    } else {
      logger7.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
      this.updateStatus(InstanceStatus.Ok);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger7.warn(`No schema found for Model ${model} \u2014 run "GLOBAL: Get All Settings" to create one`);
        return;
      }
    } catch (e) {
      logger7.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger7.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, [], true);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    const refreshAfterCommand = schema.refreshAfterCommand ?? true;
    this.stController.setModel(model, actions, refreshAfterCommand);
    if (actions.length === 0) {
      logger7.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger7.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}, refreshAfterCommand=${refreshAfterCommand}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, resolved from MAC→IP via discoveredDevices (auto) or config.host (manual). */
  get host() {
    return resolveHost(this.config, this.discoveredDevices);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0LyoqIE1BQyBvZiB0aGUgc2VsZWN0ZWQgZGlzY292ZXJlZCBkZXZpY2UgKGUuZy4gXCIwMDoxZDpjMTo5YjphNjpjZFwiKSwgb3IgJycgZm9yIG1hbnVhbCBtb2RlICovXG5cdGRldmljZU1hYzogc3RyaW5nXG5cdC8qKiBNYW51YWwgSVAgYWRkcmVzcyBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGhvc3Q6IHN0cmluZ1xuXHQvKiogTWFudWFsIG1vZGVsIHNlbGVjdGlvbiBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcbn1cblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQ0VOVFJBTElaRUQgREVWSUNFIFNDSEVNQSBDQUNIRVxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQWxsIGRldmljZSBKU09OIGZpbGVzIGFyZSBsb2FkZWQgb25jZSBpbnRvIG1lbW9yeSBoZXJlLiBPdGhlciBtb2R1bGVzIHNob3VsZFxuLy8gdXNlIGdldERldmljZXNGb2xkZXIoKSwgZ2V0RGV2aWNlU2NoZW1hcygpLCBhbmQgZ2V0RGV2aWNlU2NoZW1hKCkgaW5zdGVhZCBvZlxuLy8gcmVhZGluZyBmaWxlcyBkaXJlY3RseS4gQ2FsbCByZWxvYWREZXZpY2VTY2hlbWFzKCkgYWZ0ZXIgd3JpdGluZyB0byBhIGZpbGUuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB0aGUgY29ycmVjdCBkZXZpY2VzIGZvbGRlciBwYXRoIHdpdGggZmFsbGJhY2sgc3VwcG9ydC5cbiAqIENoZWNrcyBwcmltYXJ5IHBhdGggZmlyc3QsIHRoZW4gZmFsbGJhY2ssIHRoZW4gdGhyb3dzIGVycm9yIGlmIG5laXRoZXIgZXhpc3RzLlxuICovXG5mdW5jdGlvbiByZXNvbHZlRGV2aWNlc0ZvbGRlcigpOiBzdHJpbmcge1xuXHRjb25zdCBwcmltYXJ5UGF0aCA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi4vZGV2aWNlcycpXG5cdGNvbnN0IGZhbGxiYWNrUGF0aCA9IHBhdGguam9pbihpbXBvcnQubWV0YS5kaXJuYW1lLCAnLi9kZXZpY2VzJylcblxuXHQvLyBDaGVjayBwcmltYXJ5IHBhdGhcblx0aWYgKGZzLmV4aXN0c1N5bmMocHJpbWFyeVBhdGgpKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBVc2luZyBkZXZpY2VzIGZvbGRlcjogJHtwcmltYXJ5UGF0aH1gKVxuXHRcdHJldHVybiBwcmltYXJ5UGF0aFxuXHR9XG5cblx0Ly8gQ2hlY2sgZmFsbGJhY2sgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhmYWxsYmFja1BhdGgpKSB7XG5cdFx0bG9nZ2VyLndhcm4oYFByaW1hcnkgZGV2aWNlcyBmb2xkZXIgbm90IGZvdW5kLCB1c2luZyBmYWxsYmFjazogJHtmYWxsYmFja1BhdGh9YClcblx0XHRyZXR1cm4gZmFsbGJhY2tQYXRoXG5cdH1cblxuXHQvLyBOZWl0aGVyIHBhdGggZXhpc3RzIC0gZmF0YWwgZXJyb3Jcblx0Y29uc3QgZXJyb3JNc2cgPSBgRGV2aWNlcyBmb2xkZXIgbm90IGZvdW5kIVxcblRyaWVkOlxcbiAgLSAke3ByaW1hcnlQYXRofVxcbiAgLSAke2ZhbGxiYWNrUGF0aH1cXG5Nb2R1bGUgY2Fubm90IGNvbnRpbnVlIHdpdGhvdXQgZGV2aWNlIHNjaGVtYXMuYFxuXHRsb2dnZXIuZXJyb3IoZXJyb3JNc2cpXG5cdHRocm93IG5ldyBFcnJvcihlcnJvck1zZylcbn1cblxuLy8gUmVzb2x2ZSB0aGUgZGV2aWNlcyBmb2xkZXIgcGF0aCAod2l0aCBleGlzdGVuY2UgY2hlY2sgYW5kIGZhbGxiYWNrKVxuY29uc3QgZGV2aWNlc0ZvbGRlciA9IHJlc29sdmVEZXZpY2VzRm9sZGVyKClcblxuLy8gSW4tbWVtb3J5IGNhY2hlIG9mIGFsbCBkZXZpY2Ugc2NoZW1hcywga2V5ZWQgYnkgbW9kZWwgbnVtYmVyXG5sZXQgZGV2aWNlU2NoZW1hc0NhY2hlOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgbnVsbCA9IG51bGxcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBhYnNvbHV0ZSBwYXRoIHRvIHRoZSBkZXZpY2VzIGZvbGRlci5cbiAqIFVzZSB0aGlzIGluc3RlYWQgb2YgcmVkZWZpbmluZyB0aGUgcGF0aCBpbiBldmVyeSBmaWxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlc0ZvbGRlcigpOiBzdHJpbmcge1xuXHRyZXR1cm4gZGV2aWNlc0ZvbGRlclxufVxuXG4vKipcbiAqIExvYWRzIGFsbCBkZXZpY2UgSlNPTiBmaWxlcyBmcm9tIHRoZSBkZXZpY2VzIGZvbGRlciBpbnRvIG1lbW9yeS5cbiAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uY2UgYXQgaW5pdGlhbGl6YXRpb24sIG9yIGFmdGVyIGEgZmlsZSBpcyB3cml0dGVuLlxuICovXG5mdW5jdGlvbiBsb2FkRGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0Y29uc3Qgc2NoZW1hczogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9XG5cdHRyeSB7XG5cdFx0Y29uc3QgZmlsZXMgPSBmcy5yZWFkZGlyU3luYyhkZXZpY2VzRm9sZGVyKS5maWx0ZXIoKGYpID0+IGYuZW5kc1dpdGgoJy5qc29uJykpXG5cblx0XHRmb3IgKGNvbnN0IGYgb2YgZmlsZXMpIHtcblx0XHRcdGNvbnN0IGZ1bGxQYXRoID0gcGF0aC5qb2luKGRldmljZXNGb2xkZXIsIGYpXG5cdFx0XHRjb25zdCBqc29uID0gSlNPTi5wYXJzZShmcy5yZWFkRmlsZVN5bmMoZnVsbFBhdGgsICd1dGY4JykpXG5cdFx0XHRpZiAoanNvbj8ubW9kZWwpIHtcblx0XHRcdFx0c2NoZW1hc1tTdHJpbmcoanNvbi5tb2RlbCldID0ganNvblxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGxvZ2dlci5kZWJ1ZyhgTG9hZGVkICR7T2JqZWN0LmtleXMoc2NoZW1hcykubGVuZ3RofSBkZXZpY2Ugc2NoZW1hcyBpbnRvIGNhY2hlYClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmFpbGVkIHRvIGxvYWQgZGV2aWNlIHNjaGVtYXM6ICR7ZX1gKVxuXHR9XG5cdHJldHVybiBzY2hlbWFzXG59XG5cbi8qKlxuICogUmV0dXJucyBhbGwgZGV2aWNlIHNjaGVtYXMgZnJvbSB0aGUgY2FjaGUuXG4gKiBJbml0aWFsaXplcyB0aGUgY2FjaGUgb24gZmlyc3QgY2FsbC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZVNjaGVtYXMoKTogUmVjb3JkPHN0cmluZywgYW55PiB7XG5cdGlmICghZGV2aWNlU2NoZW1hc0NhY2hlKSB7XG5cdFx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxuXHR9XG5cdHJldHVybiBkZXZpY2VTY2hlbWFzQ2FjaGVcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgc3BlY2lmaWMgZGV2aWNlIHNjaGVtYSBieSBtb2RlbCBudW1iZXIuXG4gKiBSZXR1cm5zIHVuZGVmaW5lZCBpZiB0aGUgbW9kZWwgZG9lc24ndCBleGlzdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZVNjaGVtYShtb2RlbDogc3RyaW5nKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRyZXR1cm4gc2NoZW1hc1ttb2RlbF1cbn1cblxuLyoqXG4gKiBSZWxvYWRzIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIGRpc2suXG4gKiBDYWxsIHRoaXMgYWZ0ZXIgd3JpdGluZyB0byBhIGRldmljZSBKU09OIGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZWxvYWREZXZpY2VTY2hlbWFzKCk6IHZvaWQge1xuXHRsb2dnZXIuaW5mbygnUmVsb2FkaW5nIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay4uLicpXG5cdGRldmljZVNjaGVtYXNDYWNoZSA9IGxvYWREZXZpY2VTY2hlbWFzKClcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgbGlzdCBvZiBhdmFpbGFibGUgbW9kZWwgbnVtYmVycywgc29ydGVkLlxuICovXG5mdW5jdGlvbiBsb2FkQXZhaWxhYmxlTW9kZWxzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRyZXR1cm4gT2JqZWN0LmtleXMoc2NoZW1hcykuc29ydCgpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBHZXRDb25maWdGaWVsZHMoZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSA9IFtdKTogU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkW10ge1xuXHRjb25zdCBtb2RlbHMgPSBsb2FkQXZhaWxhYmxlTW9kZWxzKClcblxuXHQvLyBEcm9wZG93biBpZCBpcyB0aGUgZGV2aWNlIE1BQyBcdTIwMTQgc3RhYmxlIGFjcm9zcyBJUCBjaGFuZ2VzLlxuXHQvLyBFbXB0eSBpZCA9IE1hbnVhbCBtb2RlLlxuXHRjb25zdCBkZXZpY2VDaG9pY2VzID0gW1xuXHRcdHsgaWQ6ICcnLCBsYWJlbDogJ01hbnVhbCAoZW50ZXIgSVAgKyBtb2RlbCBiZWxvdyknIH0sXG5cdFx0Li4uZGlzY292ZXJlZERldmljZXMubWFwKChkKSA9PiAoe1xuXHRcdFx0aWQ6IGQubWFjID8/ICcnLFxuXHRcdFx0bGFiZWw6IGBNb2RlbCAke2QubW9kZWx9IFske2QubWFjfV0gQCAke2QuaXB9YCxcblx0XHR9KSksXG5cdF1cblxuXHRyZXR1cm4gW1xuXHRcdC8vIFx1MjUwMFx1MjUwMCBEZXZpY2Ugc2VsZWN0aW9uIGRyb3Bkb3duIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFN0b3JlcyB0aGUgTUFDIHNvIHJlLWRpc2NvdmVyeSB3aXRoIGEgY2hhbmdlZCBJUCBzdGlsbCBtYXRjaGVzLlxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2RldmljZU1hYycsXG5cdFx0XHRsYWJlbDogJ0RldmljZScsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0Y2hvaWNlczogZGV2aWNlQ2hvaWNlcyxcblx0XHRcdHRvb2x0aXA6ICdTZWxlY3QgYW4gYXV0by1kaXNjb3ZlcmVkIFN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlLCBvciBjaG9vc2UgTWFudWFsIHRvIGVudGVyIGFuIElQIGFkZHJlc3MuJyxcblx0XHR9LFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIE1hbnVhbCBJUCBlbnRyeSBcdTIwMTQgb25seSB2aXNpYmxlIGluIG1hbnVhbCBtb2RlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdHtcblx0XHRcdHR5cGU6ICd0ZXh0aW5wdXQnLFxuXHRcdFx0aWQ6ICdob3N0Jyxcblx0XHRcdGxhYmVsOiAnVGFyZ2V0IElQJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRyZWdleDogUmVnZXguSVAsXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkZXZpY2VNYWMpYCxcblx0XHRcdHRvb2x0aXA6ICdFbnRlciB0aGUgSVAgYWRkcmVzcyBvZiB0aGUgZGV2aWNlIG1hbnVhbGx5LicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNYW51YWwgbW9kZWwgc2VsZWN0b3IgXHUyMDE0IG9ubHkgdmlzaWJsZSBpbiBtYW51YWwgbW9kZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHR7XG5cdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0aWQ6ICdhY3RpdmVNb2RlbCcsXG5cdFx0XHRsYWJlbDogJ0FjdGl2ZSBEZXZpY2UgTW9kZWwnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiBtb2RlbHNbMF0gPz8gJycsXG5cdFx0XHRjaG9pY2VzOiBtb2RlbHMubWFwKChtb2RlbCkgPT4gKHtcblx0XHRcdFx0aWQ6IG1vZGVsLFxuXHRcdFx0XHRsYWJlbDogYE1vZGVsICR7bW9kZWx9YCxcblx0XHRcdH0pKSxcblx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246IGAhJChvcHRpb25zOmRldmljZU1hYylgLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCB3aGljaCBTdHVkaW8gVGVjaG5vbG9naWVzIG1vZGVsIGlzIGFjdGl2ZSBmb3IgYWN0aW9ucyBhbmQgZmVlZGJhY2tzLicsXG5cdFx0fSxcblx0XVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLlxuICogQXV0byBtb2RlIChkZXZpY2VNYWMgc2V0KTogZmluZHMgdGhlIGN1cnJlbnQgSVAgb2YgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIHdpdGggdGhhdCBNQUMuXG4gKiBNYW51YWwgbW9kZSAoZGV2aWNlTWFjIGVtcHR5KTogcmV0dXJucyB0aGUgbWFudWFsbHkgZW50ZXJlZCBob3N0IElQLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUhvc3QoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRldmljZU1hYykge1xuXHRcdGNvbnN0IGRldmljZSA9IGRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQubWFjID09PSBjb25maWcuZGV2aWNlTWFjKVxuXHRcdHJldHVybiBkZXZpY2U/LmlwID8/ICcnXG5cdH1cblx0cmV0dXJuIFN0cmluZyhjb25maWcuaG9zdCA/PyAnJylcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgbW9kZWwuXG4gKiBBdXRvIG1vZGU6IHVzZXMgdGhlIG1vZGVsIGZyb20gdGhlIGRpc2NvdmVyZWQgZGV2aWNlIG1hdGNoaW5nIHRoZSBzdG9yZWQgTUFDLlxuICogTWFudWFsIG1vZGU6IHVzZXMgdGhlIG1hbnVhbGx5IHNlbGVjdGVkIGFjdGl2ZU1vZGVsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZU1vZGVsKGNvbmZpZzogTW9kdWxlQ29uZmlnLCBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdKTogc3RyaW5nIHtcblx0aWYgKGNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRjb25zdCBkZXZpY2UgPSBkaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gY29uZmlnLmRldmljZU1hYylcblx0XHRsb2dnZXIuZGVidWcoYHJlc29sdmVNb2RlbDogZGV2aWNlTWFjPVwiJHtjb25maWcuZGV2aWNlTWFjfVwiLCBmb3VuZCBkZXZpY2U6ICR7ZGV2aWNlPy5tb2RlbCA/PyAnbm9uZSd9YClcblx0XHRyZXR1cm4gZGV2aWNlPy5tb2RlbCA/PyAnJ1xuXHR9XG5cdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBtYW51YWwgbW9kZSwgYWN0aXZlTW9kZWw9XCIke2NvbmZpZy5hY3RpdmVNb2RlbH1cImApXG5cdHJldHVybiBTdHJpbmcoY29uZmlnLmFjdGl2ZU1vZGVsID8/ICcnKVxufVxuIiwgImltcG9ydCB0eXBlIE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcblxuLyoqXG4gKiBEZWZpbmUgQ29tcGFuaW9uIHZhcmlhYmxlcyBmb3IgdGhpcyBtb2R1bGUuXG4gKiBWYXJpYWJsZXMgY2FuIGJlIHVzZWQgdG8gZGlzcGxheSBkeW5hbWljIHN0YXRlIGluIGJ1dHRvbiBsYWJlbHMsIHRyaWdnZXJzLCBldGMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh7XG5cdFx0bW9kZWw6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOdW1iZXInIH0sXG5cdFx0bW9kZWxOYW1lOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTmFtZSAoRnVsbCBEZXNjcmlwdGlvbiknIH0sXG5cdFx0bWFudWZhY3R1cmVyOiB7IG5hbWU6ICdEZXZpY2UgTWFudWZhY3R1cmVyJyB9LFxuXHRcdGZpcm13YXJlOiB7IG5hbWU6ICdEZXZpY2UgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRkYW50ZUZXOiB7IG5hbWU6ICdEYW50ZSBNb2R1bGUgRmlybXdhcmUgVmVyc2lvbicgfSxcblx0XHRtYWM6IHsgbmFtZTogJ0RldmljZSBNQUMgQWRkcmVzcycgfSxcblx0XHRpcDogeyBuYW1lOiAnRGV2aWNlIElQIEFkZHJlc3MnIH0sXG5cdH0pXG59XG5cbmNvbnN0IENMRUFSRURfVkFSSUFCTEVTID0ge1xuXHRtb2RlbDogJycsXG5cdG1vZGVsTmFtZTogJycsXG5cdG1hbnVmYWN0dXJlcjogJycsXG5cdGZpcm13YXJlOiAnJyxcblx0ZGFudGVGVzogJycsXG5cdG1hYzogJycsXG5cdGlwOiAnJyxcbn1cblxuLyoqXG4gKiBVcGRhdGUgdmFyaWFibGUgdmFsdWVzIGZyb20gZGlzY292ZXJlZCBkZXZpY2UgaW5mb3JtYXRpb24uXG4gKiBPbmx5IHBvcHVsYXRlcyB2YXJpYWJsZXMgd2hlbiB0aGUgY3VycmVudCBob3N0IGlzIGF1dGhvcml6ZWQuXG4gKiBDbGVhcnMgYWxsIHZhcmlhYmxlcyBpZiB0aGUgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkIG9yIG5vdCBmb3VuZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IGN1cnJlbnRIb3N0ID0gc2VsZi5ob3N0XG5cblx0Ly8gQ2xlYXIgdmFyaWFibGVzIGlmIG5vIGhvc3QgY29uZmlndXJlZCBvciBkZXZpY2UgaXMgbm90IGF1dGhvcml6ZWRcblx0aWYgKCFjdXJyZW50SG9zdCB8fCAhc2VsZi5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKGN1cnJlbnRIb3N0KSkge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoQ0xFQVJFRF9WQVJJQUJMRVMpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBkZXZpY2UgPSBzZWxmLmRldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gY3VycmVudEhvc3QpXG5cdGlmIChkZXZpY2UpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdG1vZGVsOiBkZXZpY2UubW9kZWwgfHwgJycsXG5cdFx0XHRtb2RlbE5hbWU6IGRldmljZS5tb2RlbE5hbWUgfHwgJycsXG5cdFx0XHRtYW51ZmFjdHVyZXI6IGRldmljZS5tYW51ZmFjdHVyZXIgfHwgJycsXG5cdFx0XHRmaXJtd2FyZTogZGV2aWNlLmZpcm13YXJlTWFpbiB8fCAnJyxcblx0XHRcdGRhbnRlRlc6IGRldmljZS5kYW50ZUZpcm13YXJlIHx8ICcnLFxuXHRcdFx0bWFjOiBkZXZpY2UubWFjIHx8ICcnLFxuXHRcdFx0aXA6IGRldmljZS5pcCxcblx0XHR9KVxuXHR9IGVsc2Uge1xuXHRcdC8vIEF1dGhvcml6ZWQgYnV0IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgKG1hbnVhbCBJUCB0aGF0IHByb2JlZCBzdWNjZXNzZnVsbHkpXG5cdFx0Ly8gV2Uga25vdyBpdCdzIHRoZSByaWdodCBkZXZpY2UgYnV0IGRvbid0IGhhdmUgZnVsbCBpbmZvIHlldFxuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0Li4uQ0xFQVJFRF9WQVJJQUJMRVMsXG5cdFx0XHRpcDogY3VycmVudEhvc3QsXG5cdFx0fSlcblx0fVxufVxuIiwgImltcG9ydCB0eXBlIHsgQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG5leHBvcnQgY29uc3QgVXBncmFkZVNjcmlwdHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQ8TW9kdWxlQ29uZmlnPltdID0gW1xuXHQvKlxuXHQgKiBQbGFjZSB5b3VyIHVwZ3JhZGUgc2NyaXB0cyBoZXJlXG5cdCAqIFJlbWVtYmVyIHRoYXQgb25jZSBpdCBoYXMgYmVlbiBhZGRlZCBpdCBjYW5ub3QgYmUgcmVtb3ZlZCFcblx0ICovXG5cdC8vIGZ1bmN0aW9uIChjb250ZXh0LCBwcm9wcykge1xuXHQvLyBcdHJldHVybiB7XG5cdC8vIFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHQvLyBcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHQvLyBcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdC8vIFx0fVxuXHQvLyB9LFxuXVxuIiwgImV4cG9ydCB0eXBlIENvbXBhbmlvbklucHV0Q2hvaWNlID0ge1xuXHRpZDogc3RyaW5nIHwgbnVtYmVyXG5cdGxhYmVsOiBzdHJpbmdcbn1cblxuZXhwb3J0IHR5cGUgRGV2aWNlU2V0dGluZyA9IHtcblx0dHlwZTogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVmYXVsdDogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhblxuXHRjaG9pY2VzPzogQ29tcGFuaW9uSW5wdXRDaG9pY2VbXVxufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBIZWFydGJlYXQgLyBrZWVwYWxpdmUgcGluZ1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfU0VUID0gMHgwNCAvLyBTZXQgc2V0dGluZyBvbiBzcGVjaWZpYyBidXMvY2hhbm5lbFxuZXhwb3J0IGNvbnN0IENNRF9IRUFEUEhPTkUgPSAweDA1IC8vIEhlYWRwaG9uZSBjb250cm9scyAocmVzZXJ2ZWQgZm9yIGZ1dHVyZSB1c2UpXG5leHBvcnQgY29uc3QgQ01EX0JVVFRPTl9NT0RFID0gMHgwNyAvLyBCdXR0b24gbW9kZSBjb25maWd1cmF0aW9uIChyZXNlcnZlZCBmb3IgZnV0dXJlIHVzZSlcbmV4cG9ydCBjb25zdCBDTURfU1lTVEVNID0gMHgwOSAvLyBTeXN0ZW0tbGV2ZWwgY29tbWFuZHMgKHJlc2VydmVkIGZvciBmdXR1cmUgdXNlKVxuZXhwb3J0IGNvbnN0IENNRF9HRVRfQUxMX1NFVFRJTkdTID0gMHgwYSAvLyBSZXF1ZXN0IGFsbCBjdXJyZW50IHNldHRpbmdzIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX1NFVFRJTkdTX1BVU0ggPSAweDBiIC8vIFVuc29saWNpdGVkIHNldHRpbmdzIHVwZGF0ZSBmcm9tIGRldmljZVxuZXhwb3J0IGNvbnN0IENNRF9ERVZfU1BFQyA9IDB4MGQgLy8gRGV2aWNlLXNwZWNpZmljIHNldHRpbmcgZ2V0L3NldCB3aXRoIEFDS1xuZXhwb3J0IGNvbnN0IENNRF9SRVNFVF9ERVZJQ0UgPSAweDBlIC8vIEZhY3RvcnkgcmVzZXQgY29tbWFuZFxuZXhwb3J0IGNvbnN0IENNRF9HTE9CQUxfTUlDX0tJTEwgPSAweDEwIC8vIEVtZXJnZW5jeSBtaWMga2lsbCAoYWxsIGNoYW5uZWxzKVxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFX0JVUyA9IDB4MTIgLy8gTWljL3ByZWFtcCBzZXR0aW5ncyBwZXIgYnVzIChnYWluLCBwaGFudG9tLCBldGMpXG5leHBvcnQgY29uc3QgQ01EX0NIQU5ORUwgPSAweDE0IC8vIENoYW5uZWwtc3BlY2lmaWMgY29udHJvbHMgKHJlc2VydmVkIGZvciBmdXR1cmUgdXNlKVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQ29tbWFuZCBOYW1lIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbmV4cG9ydCBmdW5jdGlvbiBnZXRDb21tYW5kTmFtZShjbWRJZDogbnVtYmVyKTogc3RyaW5nIHtcblx0c3dpdGNoIChjbWRJZCkge1xuXHRcdGNhc2UgQ01EX0dFVF9GSVJNV0FSRTpcblx0XHRcdHJldHVybiAnR2V0IEZpcm13YXJlIFZlcnNpb24nXG5cdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdHJldHVybiAnSGVhcnRiZWF0J1xuXHRcdGNhc2UgQ01EX0JVU19TRVQ6XG5cdFx0XHRyZXR1cm4gJ1NldCBCdXMgU2V0dGluZydcblx0XHRjYXNlIENNRF9IRUFEUEhPTkU6XG5cdFx0XHRyZXR1cm4gJ0hlYWRwaG9uZSBDb250cm9sJ1xuXHRcdGNhc2UgQ01EX0JVVFRPTl9NT0RFOlxuXHRcdFx0cmV0dXJuICdCdXR0b24gTW9kZSdcblx0XHRjYXNlIENNRF9TWVNURU06XG5cdFx0XHRyZXR1cm4gJ1N5c3RlbSBDb21tYW5kJ1xuXHRcdGNhc2UgQ01EX0dFVF9BTExfU0VUVElOR1M6XG5cdFx0XHRyZXR1cm4gJ1JlcXVlc3QgQWxsIFNldHRpbmdzJ1xuXHRcdGNhc2UgQ01EX1NFVFRJTkdTX1BVU0g6XG5cdFx0XHRyZXR1cm4gJ1NldHRpbmdzIFB1c2gnXG5cdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6XG5cdFx0XHRyZXR1cm4gJ01pYy9QcmUgQnVzJ1xuXHRcdGNhc2UgQ01EX0RFVl9TUEVDOlxuXHRcdFx0cmV0dXJuICdEZXZpY2UgU2V0dGluZydcblx0XHRjYXNlIENNRF9DSEFOTkVMOlxuXHRcdFx0cmV0dXJuICdDaGFubmVsIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfUkVTRVRfREVWSUNFOlxuXHRcdFx0cmV0dXJuICdSZXNldCBEZXZpY2UnXG5cdFx0Y2FzZSBDTURfR0xPQkFMX01JQ19LSUxMOlxuXHRcdFx0cmV0dXJuICdHbG9iYWwgTWljIEtpbGwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgY21kXzB4JHtjbWRJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIEdlbmVyYXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDcmVhdGVzIGEgY29uc2lzdGVudCBJRCBmb3IgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgc3RhdGUga2V5cy5cbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2J1c0NofV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKGUuZy4sIFwiNTMwNF8xNF8wXzBcIilcbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGhvdXQgYnVzQ2ggKGUuZy4sIFwiNTMwNF8xMl9kXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWtlU2V0dGluZ0lkKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRzZXR0aW5nSWQ6IG51bWJlciB8IHN0cmluZyxcblx0YnVzQ2g/OiBudW1iZXIgfCBzdHJpbmcsXG4pOiBzdHJpbmcge1xuXHRjb25zdCBjbWQgPSB0eXBlb2YgY21kSWQgPT09ICdudW1iZXInID8gY21kSWQudG9TdHJpbmcoMTYpIDogY21kSWRcblx0Y29uc3QgaWQgPSB0eXBlb2Ygc2V0dGluZ0lkID09PSAnbnVtYmVyJyA/IHNldHRpbmdJZC50b1N0cmluZygxNikgOiBzZXR0aW5nSWRcblxuXHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IGNoID0gdHlwZW9mIGJ1c0NoID09PSAnbnVtYmVyJyA/IGJ1c0NoLnRvU3RyaW5nKDE2KSA6IGJ1c0NoXG5cdFx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtjaH1fJHtpZH1gXG5cdH1cblxuXHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2lkfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEhleCBGb3JtYXR0aW5nIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENvbnZlcnRzIGEgbnVtYmVyIHRvIGEgaGV4IHN0cmluZyB3aXRoIDB4IHByZWZpeCBhbmQgcGFkZGluZy5cbiAqIEBwYXJhbSB2YWx1ZSAtIFRoZSBudW1iZXIgdG8gY29udmVydFxuICogQHBhcmFtIHBhZExlbmd0aCAtIE51bWJlciBvZiBoZXggZGlnaXRzIHRvIHBhZCB0byAoZGVmYXVsdDogMilcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGRcIiwgXCIweGZmXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0hleCh2YWx1ZTogbnVtYmVyLCBwYWRMZW5ndGggPSAyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAweCR7dmFsdWUudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KHBhZExlbmd0aCwgJzAnKX1gXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gYXJyYXkgb2YgYnl0ZXMgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4LlxuICogQHBhcmFtIGJ5dGVzIC0gQXJyYXkgb2YgYnl0ZXMgb3IgQnVmZmVyXG4gKiBAcmV0dXJucyBGb3JtYXR0ZWQgaGV4IHN0cmluZyAoZS5nLiwgXCIweDBhZmYxMlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnl0ZXNUb0hleChieXRlczogbnVtYmVyW10gfCBCdWZmZXIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHtBcnJheS5mcm9tKGJ5dGVzKVxuXHRcdC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0LmpvaW4oJycpfWBcbn1cblxuLyoqXG4gKiBGb3JtYXRzIFJHQiBjb2xvciBieXRlcyBhcyBhIENTUyBoZXggY29sb3Igc3RyaW5nLlxuICogQHBhcmFtIHIgLSBSZWQgY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBnIC0gR3JlZW4gY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBiIC0gQmx1ZSBjb21wb25lbnQgKDAtMjU1KVxuICogQHJldHVybnMgQ1NTIGhleCBjb2xvciBzdHJpbmcgKGUuZy4sIFwiI0ZGMDBBQlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UmdiQ29sb3IocjogbnVtYmVyLCBnOiBudW1iZXIsIGI6IG51bWJlcik6IHN0cmluZyB7XG5cdHJldHVybiBgIyR7W3IsIGcsIGJdXG5cdFx0Lm1hcCgodikgPT4gdi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJylcblx0XHQudG9VcHBlckNhc2UoKX1gXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBJRCBQYXJzaW5nIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogUGFyc2VzIGEgc2V0dGluZyBJRCBzdHJpbmcgaW50byBpdHMgY29tcG9uZW50cy5cbiAqIEBwYXJhbSBpZCAtIFNldHRpbmcgSUQgc3RyaW5nIChlLmcuLCBcIjM5MV9kXzBcIiBvciBcIjUzMDRfMTRfMF8xXCIpXG4gKiBAcmV0dXJucyBQYXJzZWQgY29tcG9uZW50cyB3aXRoIGhleCBzdHJpbmdzIGNvbnZlcnRlZCB0byBudW1iZXJzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdJZChpZDogc3RyaW5nKTogeyBtb2RlbDogc3RyaW5nOyBjbWRJZDogbnVtYmVyOyBiYXNlSWQ6IG51bWJlciB9IHtcblx0Y29uc3QgW21vZGVsLCBjbWRJZFN0ciwgaWRTdHJdID0gaWQuc3BsaXQoJ18nKVxuXHRyZXR1cm4ge1xuXHRcdG1vZGVsLFxuXHRcdGNtZElkOiBwYXJzZUludChjbWRJZFN0ciwgMTYpLFxuXHRcdGJhc2VJZDogcGFyc2VJbnQoaWRTdHIsIDE2KSxcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgTW9kZWwgRGlzdGFuY2UgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDYWxjdWxhdGVzIG51bWVyaWMgZGlzdGFuY2UgYmV0d2VlbiB0d28gbW9kZWwgbnVtYmVycy5cbiAqIFVzZWQgZm9yIGZpbmRpbmcgc2ltaWxhciBtb2RlbHMgZm9yIHNldHRpbmcgaW5mZXJlbmNlLlxuICogQHBhcmFtIG1vZGVsQSAtIEZpcnN0IG1vZGVsIG51bWJlciAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBtb2RlbEIgLSBTZWNvbmQgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MlwiKVxuICogQHJldHVybnMgTnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIG1vZGVscywgb3IgSW5maW5pdHkgaWYgZWl0aGVyIGlzIG5vbi1udW1lcmljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb2RlbERpc3RhbmNlKG1vZGVsQTogc3RyaW5nLCBtb2RlbEI6IHN0cmluZyk6IG51bWJlciB7XG5cdGNvbnN0IG5hID0gcGFyc2VJbnQobW9kZWxBLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRjb25zdCBuYiA9IHBhcnNlSW50KG1vZGVsQi5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0aWYgKE51bWJlci5pc05hTihuYSkgfHwgTnVtYmVyLmlzTmFOKG5iKSkgcmV0dXJuIEluZmluaXR5XG5cdHJldHVybiBNYXRoLmFicyhuYSAtIG5iKVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU2NoZW1hIE5vcm1hbGl6YXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBOb3JtYWxpemVzIGRldmljZSBzY2hlbWFzIHRvIGVuc3VyZSBjbWRTY2hlbWEgaXMgYWx3YXlzIGFuIGFycmF5LlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgc2NoZW1hIHRyYW5zZm9ybWF0aW9uIGNvZGUuXG4gKiBAcGFyYW0gc2NoZW1hc1JhdyAtIFJhdyBzY2hlbWFzIGZyb20gZ2V0RGV2aWNlU2NoZW1hcygpXG4gKiBAcmV0dXJucyBOb3JtYWxpemVkIHNjaGVtYXMgd2l0aCBndWFyYW50ZWVkIGNtZFNjaGVtYSBhcnJheXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldE5vcm1hbGl6ZWRTY2hlbWFzKFxuXHRzY2hlbWFzUmF3OiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuKTogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+IHtcblx0Y29uc3Qgbm9ybWFsaXplZDogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+ID0ge31cblx0Zm9yIChjb25zdCBbbW9kZWwsIGpzb25dIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXNSYXcpKSB7XG5cdFx0bm9ybWFsaXplZFttb2RlbF0gPSB7XG5cdFx0XHRtb2RlbDoganNvbi5tb2RlbCxcblx0XHRcdGNtZFNjaGVtYTogQXJyYXkuaXNBcnJheShqc29uLmNtZFNjaGVtYSkgPyBqc29uLmNtZFNjaGVtYSA6IFtdLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4gbm9ybWFsaXplZFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQWN0aW9uIExvb2t1cCBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIEZpbmRzIGFuIGFjdGlvbi9zZXR0aW5nIGluIHRoZSBzY2hlbWEsIHN1cHBvcnRpbmcgYm90aCBleGFjdCBtYXRjaGVzIGFuZCBpZEFkZCBvZmZzZXRzLlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgYWN0aW9uIGxvb2t1cCBsb2dpYyBhY3Jvc3MgbXVsdGlwbGUgZmlsZXMuXG4gKiBAcGFyYW0gc2NoZW1hcyAtIE5vcm1hbGl6ZWQgZGV2aWNlIHNjaGVtYXNcbiAqIEBwYXJhbSBtb2RlbCAtIERldmljZSBtb2RlbCAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBjbWRJZCAtIENvbW1hbmQgSURcbiAqIEBwYXJhbSBzZXR0aW5nSWQgLSBTZXR0aW5nIElEIChtYXkgaW5jbHVkZSBpZEFkZCBvZmZzZXQpXG4gKiBAcmV0dXJucyBNYXRjaGluZyBhY3Rpb24vc2V0dGluZyBvciB1bmRlZmluZWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmRBY3Rpb25Gb3JTZXR0aW5nKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0aWYgKCFzY2hlbWEgfHwgIUFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkpIHJldHVybiB1bmRlZmluZWRcblxuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IHNjaGVtYS5jbWRTY2hlbWEuZmluZCgoczogYW55KSA9PiBzLmNtZF9pZCA9PT0gY21kSWQgJiYgcy5pZCA9PT0gc2V0dGluZ0lkKVxuXG5cdC8vIElmIG5vIGV4YWN0IG1hdGNoLCB0cnkgdG8gZmluZCBiYXNlIGFjdGlvbiB3aXRoIGlkQWRkXG5cdGlmICghYWN0aW9uKSB7XG5cdFx0YWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHtcblx0XHRcdGlmIChzLmNtZF9pZCAhPT0gY21kSWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBzLm9wdGlvbnM/LmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHNldHRpbmdJZCBtYXRjaGVzIGJhc2UgKyBhbnkgaWRBZGQgb2Zmc2V0XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBzZXR0aW5nSWQgLSBzLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvblxufVxuIiwgIi8qKlxuICogYnVpbGQtY29tbWFuZHMudHNcbiAqIC0gVXNlcyBjZW50cmFsaXplZCBkZXZpY2Ugc2NoZW1hIGNhY2hlIGZyb20gY29uZmlnLnRzXG4gKiAtIFByb2R1Y2VzIENvbXBhbmlvbiBhY3Rpb24gZGVmaW5pdGlvbnMgYW5kIGZlZWRiYWNrc1xuICovXG5cbmltcG9ydCB7XG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zLFxuXHRDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uLFxuXHRDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgbWFrZVNldHRpbmdJZCB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0gT3B0aW9uIEJ1aWxkZXIgLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZnVuY3Rpb24gYnVpbGRPcHRpb24obzogYW55KTogYW55IHtcblx0Y29uc3QgYmFzZSA9IHtcblx0XHR0eXBlOiBvLnR5cGUsXG5cdFx0aWQ6IG8uaWQsXG5cdFx0bGFiZWw6IG8ubGFiZWwsXG5cdFx0ZGVmYXVsdDogby5kZWZhdWx0LFxuXHRcdHRvb2x0aXA6IG8udG9vbHRpcCxcblx0fVxuXG5cdHN3aXRjaCAoby50eXBlKSB7XG5cdFx0Y2FzZSAnZHJvcGRvd24nOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgY2hvaWNlczogby5jaG9pY2VzID8/IFtdIH1cblxuXHRcdGNhc2UgJ251bWJlcic6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5iYXNlLFxuXHRcdFx0XHRtaW46IG8ubWluLFxuXHRcdFx0XHRtYXg6IG8ubWF4LFxuXHRcdFx0XHRzdGVwOiBvLnN0ZXAgPz8gMSxcblx0XHRcdFx0cmFuZ2U6IHRydWUsXG5cdFx0XHR9XG5cblx0XHRjYXNlICdjaGVja2JveCc6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBkZWZhdWx0OiBvLmRlZmF1bHQgPz8gZmFsc2UgfVxuXG5cdFx0Y2FzZSAndGV4dGlucHV0Jzpcblx0XHRjYXNlICdjb2xvcnBpY2tlcic6XG5cdFx0Y2FzZSAnc3RhdGljLXRleHQnOlxuXHRcdGRlZmF1bHQ6XG5cdFx0XHRyZXR1cm4gYmFzZVxuXHR9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0gQWN0aW9ucyAtLS0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkQWN0aW9ucygpOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgYWN0aW9uczogQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMgPSB7fVxuXG5cdGZvciAoY29uc3QgW21vZGVsLCBzY2hlbWFdIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXMpKSB7XG5cdFx0Y29uc3QgY21kU2NoZW1hID0gc2NoZW1hLmNtZFNjaGVtYVxuXHRcdGlmICghQXJyYXkuaXNBcnJheShjbWRTY2hlbWEpKSBjb250aW51ZVxuXG5cdFx0Zm9yIChjb25zdCBhIG9mIGNtZFNjaGVtYSkge1xuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBtYWtlU2V0dGluZ0lkKG1vZGVsLCBhLmNtZF9pZCwgYS5pZClcblxuXHRcdFx0Y29uc3Qgb3B0aW9ucyA9IChhLm9wdGlvbnMgPz8gW10pLm1hcChidWlsZE9wdGlvbilcblxuXHRcdFx0Y29uc3QgYWN0aW9uOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7YS5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnMsXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlQWN0aW9ucyAqL1xuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRhY3Rpb25zW2FjdGlvbklkXSA9IGFjdGlvblxuXHRcdH1cblx0fVxuXG5cdHJldHVybiBhY3Rpb25zXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0gRmVlZGJhY2tzIC0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRmVlZGJhY2tzKCk6IENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IGZlZWRiYWNrczogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IHNldHRpbmcgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHRjb25zdCBiYXNlRmVlZGJhY2tJZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIHNldHRpbmcuY21kX2lkLCBzZXR0aW5nLmlkKVxuXG5cdFx0XHQvLyBCdWlsZCBvcHRpb25zXG5cdFx0XHRjb25zdCBhbGxPcHRpb25zID0gKHNldHRpbmcub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHQvLyBGaWx0ZXIgb3V0ICd2YWx1ZScgb3B0aW9uIGZvciB2YWx1ZSBmZWVkYmFjayAoa2VlcCBvbmx5IGJ1c0NoL2lkQWRkKVxuXHRcdFx0Y29uc3QgdmFsdWVPcHRpb25zID0gYWxsT3B0aW9ucy5maWx0ZXIoKG9wdDogYW55KSA9PiBvcHQuaWQgIT09ICd2YWx1ZScpXG5cblx0XHRcdC8vIEFkZCBhIGNoZWNrYm94IG9wdGlvbiB0byByZXR1cm4gbGFiZWwgaW5zdGVhZCBvZiB2YWx1ZVxuXHRcdFx0dmFsdWVPcHRpb25zLnB1c2goe1xuXHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRpZDogJ3Nob3dMYWJlbCcsXG5cdFx0XHRcdGxhYmVsOiAnU2hvdyBMYWJlbCcsXG5cdFx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0XHR0b29sdGlwOiAnUmV0dXJuIHRoZSBsYWJlbCB0ZXh0IGluc3RlYWQgb2YgdGhlIG51bWVyaWMgdmFsdWUnLFxuXHRcdFx0fSlcblxuXHRcdFx0Ly8gVmFsdWUgZmVlZGJhY2sgZm9yIGFsbCBzZXR0aW5ncyAoYXBwZWFycyBpbiBWYXJpYWJsZXMgbGlzdClcblx0XHRcdGNvbnN0IHZhbHVlRmVlZGJhY2s6IGFueSA9IHtcblx0XHRcdFx0dHlwZTogJ3ZhbHVlJyxcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7bW9kZWx9XSAke3NldHRpbmcubmFtZX1gLFxuXHRcdFx0XHRvcHRpb25zOiB2YWx1ZU9wdGlvbnMsXG5cdFx0XHRcdGNhbGxiYWNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlRmVlZGJhY2tzICovXG5cdFx0XHRcdFx0cmV0dXJuIDBcblx0XHRcdFx0fSxcblx0XHRcdH1cblxuXHRcdFx0ZmVlZGJhY2tzW2Jhc2VGZWVkYmFja0lkXSA9IHZhbHVlRmVlZGJhY2tcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gZmVlZGJhY2tzXG59XG4iLCAiaW1wb3J0IE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcbmltcG9ydCB7IGJ1aWxkQWN0aW9ucyB9IGZyb20gJy4vYnVpbGQtY29tbWFuZHMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VzRm9sZGVyLCBnZXREZXZpY2VTY2hlbWEsIGdldERldmljZVNjaGVtYXMsIHJlbG9hZERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IHBhcnNlU2V0dGluZ0lkLCBnZXROb3JtYWxpemVkU2NoZW1hcyB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcblxuaW1wb3J0IHsgcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24sIHNhdmVNb2RlbEpzb25QcmV0dHksIHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyB9IGZyb20gJy4vc2V0dGluZ3NQYXJzZXIuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQWN0aW9ucycpXG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVBY3Rpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IHNjaGVtYXNSYXcgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgcmF3QWN0aW9ucyA9IGJ1aWxkQWN0aW9ucygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEFjdGlvbnM6IGFueSA9IHt9XG5cblx0Y29uc3QgYWN0aXZlTW9kZWwgPSBzZWxmLmFjdGl2ZU1vZGVsXG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBHTE9CQUw6IEdFVCBBTEwgU0VUVElOR1MgKEFVVE8gSlNPTiBVUERBVEUpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdHdpcmVkQWN0aW9uc1snZ2xvYmFsX2dldEFsbFNldHRpbmdzJ10gPSB7XG5cdFx0bmFtZTogJ0dMT0JBTDogR2V0IEFsbCBTZXR0aW5ncyAoQXV0by1VcGRhdGUgSlNPTiknLFxuXHRcdG9wdGlvbnM6IFtdLFxuXHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRjb25zdCBtb2RlbCA9IGFjdGl2ZU1vZGVsXG5cdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXG5cdFx0XHRjb25zdCBidWYgPSBhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApXG5cblx0XHRcdC8vIFVzZSBjZW50cmFsaXplZCBjYWNoZSB0byBnZXQgdGhlIHNjaGVtYSAobWF5IGJlIG51bGwgZm9yIG5ldy91bmtub3duIGRldmljZXMpXG5cdFx0XHRsZXQgbW9kZWxKc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXG5cdFx0XHQvLyBQYXJzZSB3aXRoIGF1dG8tZGV0ZWN0aW9uXG5cdFx0XHRjb25zdCB7IHNldHRpbmdzOiBwYXJzZWQsIGRldGVjdGVkU2VjdGlvbmVkIH0gPSBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbihtb2RlbCwgYnVmKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBwYXJzZWQgcmVwbHk6ICR7SlNPTi5zdHJpbmdpZnkocGFyc2VkKX1gKVxuXG5cdFx0XHRpZiAoIW1vZGVsSnNvbikge1xuXHRcdFx0XHQvLyBObyBzY2hlbWEgeWV0IFx1MjAxNCBjcmVhdGUgYSBtaW5pbWFsIG9uZSBmcm9tIHRoZSBwYXJzZWQgc2V0dGluZ3Ncblx0XHRcdFx0bG9nZ2VyLmluZm8oYE1vZGVsICR7bW9kZWx9IGhhcyBubyBzY2hlbWEgXHUyMDE0IGNyZWF0aW5nIG5ldyBKU09OIGZyb20gc2V0dGluZ3NgKVxuXHRcdFx0XHRtb2RlbEpzb24gPSB7XG5cdFx0XHRcdFx0bW9kZWwsXG5cdFx0XHRcdFx0c2VjdGlvbmVkOiBkZXRlY3RlZFNlY3Rpb25lZCA/PyBmYWxzZSxcblx0XHRcdFx0XHRyZWZyZXNoQWZ0ZXJDb21tYW5kOiB0cnVlLFxuXHRcdFx0XHRcdGNtZFNjaGVtYTogW10sXG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBpZiAoZGV0ZWN0ZWRTZWN0aW9uZWQgIT09IG51bGwpIHtcblx0XHRcdFx0Ly8gSWYgd2UgYXV0by1kZXRlY3RlZCB0aGUgZm9ybWF0LCBhZGQgaXQgdG8gdGhlIEpTT05cblx0XHRcdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgc2VjdGlvbmVkPSR7ZGV0ZWN0ZWRTZWN0aW9uZWR9LCBhZGRpbmcgdG8gbW9kZWwgSlNPTmApXG5cdFx0XHRcdG1vZGVsSnNvbiA9IHsgLi4ubW9kZWxKc29uLCBzZWN0aW9uZWQ6IGRldGVjdGVkU2VjdGlvbmVkIH1cblx0XHRcdH1cblxuXHRcdFx0Y29uc3QgdXBkYXRlZCA9IHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyhtb2RlbEpzb24sIHBhcnNlZCwgc2NoZW1hcylcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgbmV3IEFjdGlvbnMganNvbjogJHtKU09OLnN0cmluZ2lmeSh1cGRhdGVkLCBudWxsLCAyKX1gKVxuXG5cdFx0XHQvLyBTYXZlIHRoZSB1cGRhdGVkIEpTT04gdG8gZGlza1xuXHRcdFx0Y29uc3QgZGV2aWNlc0ZvbGRlciA9IGdldERldmljZXNGb2xkZXIoKVxuXHRcdFx0Y29uc3Qgc2NoZW1hUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBgTW9kZWwke21vZGVsfS5qc29uYClcblx0XHRcdHNhdmVNb2RlbEpzb25QcmV0dHkoc2NoZW1hUGF0aCwgdXBkYXRlZClcblxuXHRcdFx0Ly8gUmVsb2FkIHRoZSBjYWNoZSBhZnRlciB3cml0aW5nIHRvIGZpbGVcblx0XHRcdHJlbG9hZERldmljZVNjaGVtYXMoKVxuXG5cdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gSlNPTiBhdXRvLXVwZGF0ZWQgZnJvbSBnZXRBbGxTZXR0aW5nc2ApXG5cdFx0fSxcblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgQUNUSU9OUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFthY3Rpb25JZCwgYWN0aW9uXSBvZiBPYmplY3QuZW50cmllcyhyYXdBY3Rpb25zKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGFjdGlvbklkKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGFjdGlvbnMgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIEdldCB0aGUgcmF3IGFjdGlvbiBzY2hlbWEgdG8gYWNjZXNzIGZpeGVkIGJ1c0NoIHZhbHVlXG5cdFx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0XHRjb25zdCByYXdBY3Rpb24gPSBzY2hlbWE/LmNtZFNjaGVtYT8uZmluZCgoYTogYW55KSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gYmFzZUlkKVxuXG5cdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdC4uLmFjdGlvbixcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoZXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGV2ZW50Lm9wdGlvbnNbJ2J1c0NoJ10gIT09IHVuZGVmaW5lZCA/IGV2ZW50Lm9wdGlvbnNbJ2J1c0NoJ10gOiByYXdBY3Rpb24/LmJ1c0NoXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZXZlbnQub3B0aW9uc1sndmFsdWUnXVxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGV2ZW50Lm9wdGlvbnNbJ2lkQWRkJ10gPz8gMFxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBiYXNlSWQgKyBpZEFkZFxuXG5cdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnNlbmRBd2FpdEFjayhjbWRJZCwgYnVzQ2gsIHNldHRpbmdJZCwgdmFsdWUsIGlwKVxuXHRcdFx0fSxcblx0XHR9XG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IE1JQyBLSUxMIChPTkxZIElGIEFDVElWRSBNT0RFTCBTVVBQT1JUUyBJVClcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdGNvbnN0IGFjdGl2ZVNjaGVtYSA9IHNjaGVtYXNbYWN0aXZlTW9kZWxdXG5cdGlmIChhY3RpdmVTY2hlbWEpIHtcblx0XHRjb25zdCBzdXBwb3J0c01pY0tpbGwgPSAoYWN0aXZlU2NoZW1hLmNtZFNjaGVtYSA/PyBbXSkuc29tZSgoYTogYW55KSA9PiBhLm5hbWUuaW5jbHVkZXMoJ0tpbGwnKSlcblxuXHRcdGlmIChzdXBwb3J0c01pY0tpbGwpIHtcblx0XHRcdGNvbnN0IGFjdGlvbklkID0gYCR7YWN0aXZlTW9kZWx9X21pY0tpbGxgXG5cblx0XHRcdHdpcmVkQWN0aW9uc1thY3Rpb25JZF0gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke2FjdGl2ZU1vZGVsfV0gTWljIEtpbGxgLFxuXHRcdFx0XHRvcHRpb25zOiBbXSxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBNaWMgS2lsbCBcdTIxOTIgTW9kZWwgJHthY3RpdmVNb2RlbH0gQCAke2lwfWApXG5cdFx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIuZ2xvYmFsTWljS2lsbChpcClcblx0XHRcdFx0fSxcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEFjdGlvbkRlZmluaXRpb25zKHdpcmVkQWN0aW9ucylcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRlQWN0aW9uczogd2lyZWQgYWN0aW9uczogJHtPYmplY3Qua2V5cyh3aXJlZEFjdGlvbnMpLmxlbmd0aH1gKVxufVxuIiwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYSB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9CVVNfU0VULFxuXHRDTURfQ0hBTk5FTCxcblx0Q01EX0RFVl9TUEVDLFxuXHRDTURfR0VUX0FMTF9TRVRUSU5HUyxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdGZvcm1hdFJnYkNvbG9yLFxuXHRtb2RlbERpc3RhbmNlLFxufSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1NldHRpbmdzUGFyc2VyJylcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgVFlQRVNcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IHR5cGUgUGFyc2VkU2V0dGluZyA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRidXNDaD86IG51bWJlciAvLyBPcHRpb25hbDogb25seSBwcmVzZW50IGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoICgweDA0LCAweDEyLCAweDE0KVxuXHR2YWx1ZUJ5dGVzOiBudW1iZXJbXVxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbk9wdGlvbiA9IHtcblx0aWQ/OiBzdHJpbmdcblx0bGFiZWw6IHN0cmluZ1xuXHR0eXBlOiBzdHJpbmdcblx0ZGVmYXVsdDogdW5rbm93blxuXHR0b29sdGlwPzogc3RyaW5nXG5cdGNob2ljZXM/OiBBcnJheTx7IGlkOiBudW1iZXI7IGxhYmVsOiBzdHJpbmcgfT5cbn1cblxuZXhwb3J0IHR5cGUgU3RBY3Rpb24gPSB7XG5cdGNtZF9pZDogbnVtYmVyXG5cdGlkOiBudW1iZXJcblx0bmFtZTogc3RyaW5nXG5cdG9wdGlvbnM6IFN0QWN0aW9uT3B0aW9uW11cblx0YnVzQ2g/OiBudW1iZXIgLy8gRml4ZWQgY2hhbm5lbCB2YWx1ZSBmb3IgYWN0aW9ucyB0aGF0IGRvbid0IGhhdmUgYSBjaGFubmVsIG9wdGlvblxufVxuXG5leHBvcnQgdHlwZSBTdE1vZGVsSnNvbiA9IHtcblx0bW9kZWw6IHN0cmluZ1xuXHRzZWN0aW9uZWQ/OiBib29sZWFuXG5cdHJlZnJlc2hBZnRlckNvbW1hbmQ/OiBib29sZWFuXG5cdGNtZFNjaGVtYTogU3RBY3Rpb25bXVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGT1JNQVQgSEVMUEVSU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBnZXRNb2RlbENvbmZpZyhtb2RlbDogc3RyaW5nKTogeyBzZWN0aW9uZWQ6IGJvb2xlYW47IHJnYklkczogU2V0PG51bWJlcj4gfSB7XG5cdGNvbnN0IHJnYklkcyA9IG5ldyBTZXQ8bnVtYmVyPigpXG5cdGxldCBzZWN0aW9uZWQgPSBmYWxzZVxuXG5cdHRyeSB7XG5cdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIGluc3RlYWQgb2YgcmVhZGluZyBmcm9tIGRpc2tcblx0XHRjb25zdCBqc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghanNvbikge1xuXHRcdFx0Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgc2NoZW1hLCByZXR1cm4gZGVmYXVsdHNcblx0XHRcdHJldHVybiB7IHNlY3Rpb25lZCwgcmdiSWRzIH1cblx0XHR9XG5cblx0XHQvLyBSZWFkIHNlY3Rpb25lZCBwcm9wZXJ0eSAoZGVmYXVsdCB0byBmYWxzZSBpZiBub3Qgc3BlY2lmaWVkKVxuXHRcdHNlY3Rpb25lZCA9IGpzb24uc2VjdGlvbmVkID8/IGZhbHNlXG5cblx0XHQvLyBCdWlsZCBSR0IgSURzIHNldFxuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHQvLyBBZGQgdGhlIGJhc2UgSURcblx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQpXG5cblx0XHRcdFx0Ly8gSWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkIGNob2ljZXMsIGFkZCBhbGwgdGhlIG9mZnNldCBJRHMgdG9vXG5cdFx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjaG9pY2Ugb2YgaWRBZGRPcHRpb24uY2hvaWNlcykge1xuXHRcdFx0XHRcdFx0aWYgKHR5cGVvZiBjaG9pY2UuaWQgPT09ICdudW1iZXInKSB7XG5cdFx0XHRcdFx0XHRcdHJnYklkcy5hZGQoYWN0aW9uLmlkICsgY2hvaWNlLmlkKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCAoX2Vycikge1xuXHRcdC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHNjaGVtYSwgcmV0dXJuIGRlZmF1bHRzXG5cdH1cblxuXHRyZXR1cm4geyBzZWN0aW9uZWQsIHJnYklkcyB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZJTkQgVEhFIFJFQUwgNUEgUEFZTE9BRCBJTkRFWFxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmOiBCdWZmZXIpOiBudW1iZXIge1xuXHRjb25zdCBzaWdJbmRleCA9IGJ1Zi5pbmRleE9mKEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcpKVxuXHRpZiAoc2lnSW5kZXggPCAwKSB0aHJvdyBuZXcgRXJyb3IoJ05vIFN0dWRpby1UIHNpZ25hdHVyZSBpbiBwYWNrZXQnKVxuXG5cdGNvbnN0IHBheWxvYWRJbmRleCA9IHNpZ0luZGV4ICsgOFxuXHRpZiAoYnVmW3BheWxvYWRJbmRleF0gIT09IDB4NWEpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIDB4NUEgYWZ0ZXIgU3R1ZGlvLVQsIGZvdW5kICR7YnVmW3BheWxvYWRJbmRleF0udG9TdHJpbmcoMTYpfWApXG5cdH1cblxuXHRyZXR1cm4gcGF5bG9hZEluZGV4XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZMQVQgUEFSU0VSXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYmxvY2s6IEJ1ZmZlciwgcmdiSWRzOiBTZXQ8bnVtYmVyPiA9IG5ldyBTZXQoKSk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGxldCBwID0gMFxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0d2hpbGUgKHAgPCBibG9jay5sZW5ndGgpIHtcblx0XHRjb25zdCBpZCA9IGJsb2NrW3BdXG5cdFx0aWYgKHAgKyAxID49IGJsb2NrLmxlbmd0aCkgYnJlYWtcblxuXHRcdC8vIFJHQiBjYXNlIC0gY2hlY2sgaWYgdGhpcyBJRCBpcyBhIGtub3duIGNvbG9ycGlja2VyXG5cdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHAgKyAzIDwgYmxvY2subGVuZ3RoKSB7XG5cdFx0XHRvdXQucHVzaCh7XG5cdFx0XHRcdGNtZF9pZDogQ01EX0RFVl9TUEVDLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXSwgYmxvY2tbcCArIDJdLCBibG9ja1twICsgM11dLFxuXHRcdFx0fSlcblx0XHRcdHAgKz0gNFxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHRvdXQucHVzaCh7IGNtZF9pZDogQ01EX0RFVl9TUEVDLCBpZCwgdmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXV0gfSlcblx0XHRwICs9IDJcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Y29uc3QgYmxvY2tMZW4gPSBidWZbaWR4ICsgMl1cblx0Y29uc3Qgc3RhcnQgPSBpZHggKyAzXG5cdGNvbnN0IGVuZCA9IHN0YXJ0ICsgYmxvY2tMZW5cblx0aWYgKGVuZCA+IGJ1Zi5sZW5ndGgpIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBibG9jayBsZW5ndGgnKVxuXG5cdGNvbnN0IHsgcmdiSWRzIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYnVmLnN1YmFycmF5KHN0YXJ0LCBlbmQpLCByZ2JJZHMpXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNFQ1RJT05FRCBQQVJTRVJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZjogQnVmZmVyLCBtb2RlbDogc3RyaW5nKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgYSBnZXRBbGxTZXR0aW5ncyByZXBseScpXG5cdH1cblxuXHQvLyBDTURfR0VUX0FMTF9TRVRUSU5HUyBoYXMgYSB0b3RhbC1sZW5ndGggYnl0ZSBhdCBpZHgrMiBiZWZvcmUgdGhlIHNlY3Rpb25zOyBDTURfU0VUVElOR1NfUFVTSCBkb2VzIG5vdC5cblx0bGV0IHAgPSBjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgPyBpZHggKyAzIDogaWR4ICsgMlxuXHRjb25zdCBlbmQgPSBidWYubGVuZ3RoIC0gMVxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0Ly8gR2V0IFJHQiBJRHMgZm9yIHRoaXMgbW9kZWxcblx0Y29uc3QgeyByZ2JJZHMgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgaW4gdGhlaXIgc2VjdGlvbiBzdHJ1Y3R1cmVcblx0Y29uc3QgY29tbWFuZHNXaXRoQnVzQ2ggPSBbQ01EX0JVU19TRVQsIENNRF9NSUNfUFJFX0JVUywgQ01EX0NIQU5ORUxdXG5cblx0d2hpbGUgKHAgKyAyIDwgZW5kKSB7XG5cdFx0Y29uc3QgY21kTGVuID0gYnVmW3BdXG5cdFx0Y29uc3Qgc2VjdGlvbkNtZElkID0gYnVmW3AgKyAxXVxuXG5cdFx0Y29uc3Qgc2VjdGlvbkVuZCA9IHAgKyAxICsgY21kTGVuXG5cdFx0aWYgKHNlY3Rpb25FbmQgPiBlbmQpIGJyZWFrXG5cblx0XHQvLyBDaGVjayBpZiB0aGlzIGNvbW1hbmQgaW5jbHVkZXMgYSBidXNDaCBieXRlXG5cdFx0Y29uc3QgaGFzQnVzQ2ggPSBjb21tYW5kc1dpdGhCdXNDaC5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cblx0XHRsZXQgYnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZFxuXHRcdGxldCBkYXRhTGVuOiBudW1iZXJcblx0XHRsZXQgcTogbnVtYmVyXG5cblx0XHRpZiAoaGFzQnVzQ2gpIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRkYXRhTGVuID0gYnVmW3AgKyAzXVxuXHRcdFx0cSA9IHAgKyA0IC8vIERhdGEgc3RhcnRzIGFmdGVyIGNtZExlbiwgY21kSWQsIGJ1c0NoLCBkYXRhTGVuXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbZGF0YUxlbl0gW2lkOnZhbCBwYWlyc11cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDJdXG5cdFx0XHRxID0gcCArIDMgLy8gRGF0YSBzdGFydHMgYWZ0ZXIgY21kTGVuLCBjbWRJZCwgZGF0YUxlblxuXHRcdH1cblxuXHRcdGNvbnN0IHFFbmQgPSBxICsgZGF0YUxlblxuXG5cdFx0d2hpbGUgKHEgKyAxIDwgcUVuZCkge1xuXHRcdFx0Y29uc3QgaWQgPSBidWZbcV1cblx0XHRcdGxldCB2YWx1ZUJ5dGVzOiBudW1iZXJbXVxuXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIElEIGlzIGFuIFJHQiBjb2xvcnBpY2tlciAobmVlZHMgMyBieXRlcylcblx0XHRcdGlmIChyZ2JJZHMuaGFzKGlkKSAmJiBxICsgMyA8IHFFbmQpIHtcblx0XHRcdFx0dmFsdWVCeXRlcyA9IFtidWZbcSArIDFdLCBidWZbcSArIDJdLCBidWZbcSArIDNdXVxuXHRcdFx0XHRxICs9IDRcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXV1cblx0XHRcdFx0cSArPSAyXG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHNldHRpbmc6IFBhcnNlZFNldHRpbmcgPSB7XG5cdFx0XHRcdGNtZF9pZDogc2VjdGlvbkNtZElkLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdHNldHRpbmcuYnVzQ2ggPSBidXNDaFxuXHRcdFx0fVxuXHRcdFx0b3V0LnB1c2goc2V0dGluZylcblx0XHR9XG5cblx0XHRwID0gc2VjdGlvbkVuZFxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBHRU5FUklDIFNFVFRJTkdTIFJFU1BPTlNFIFBBUlNFUiAoMHgwYSBnZXQtYWxsICsgMHgwYiB1bnNvbGljaXRlZCBwdXNoKVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBhbnkgZnVsbCBzZXR0aW5ncyBibG9jayByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhlIGNtZElkIGlzIDB4MGFcbiAqIChyZXNwb25zZSB0byBHZXQgQWxsIFNldHRpbmdzKSBvciAweDBiICh1bnNvbGljaXRlZCBwdXNoIGFmdGVyIGEgc2V0KS5cbiAqIEJvdGggdXNlIHRoZSBzYW1lIHNlY3Rpb25lZCBvciBmbGF0IGJsb2NrIGxheW91dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ3NSZXNwb25zZShtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgTm90IGEgc2V0dGluZ3MgYmxvY2sgKGNtZElkPTB4JHtjbWRJZC50b1N0cmluZygxNil9KWApXG5cdH1cblx0Y29uc3QgeyBzZWN0aW9uZWQgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gc2VjdGlvbmVkID8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbCkgOiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcbn1cblxuLyoqXG4gKiBGb3JtYXRzIGEgc2luZ2xlIHBhcnNlZCBzZXR0aW5nIGludG8gYSBodW1hbi1yZWFkYWJsZSBzdHJpbmcgdXNpbmcgYWN0aW9uXG4gKiBkZWZpbml0aW9ucyBmcm9tIHRoZSBkZXZpY2UgSlNPTi4gRmFsbHMgYmFjayB0byBoZXggSURzIHdoZW4gdW5rbm93bi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZzogUGFyc2VkU2V0dGluZywgYWN0aW9uczogU3RBY3Rpb25bXSk6IHN0cmluZyB7XG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gc2V0dGluZy5jbWRfaWQgJiYgYS5pZCA9PT0gc2V0dGluZy5pZClcblxuXHQvLyBJZiBubyBleGFjdCBtYXRjaCBhbmQgaWQgPiBiYXNlIGlkLCB0cnkgdG8gZmluZCBhY3Rpb24gd2l0aCBpZEFkZCBvcHRpb25cblx0Ly8gVGhpcyBoYW5kbGVzIGNhc2VzIGxpa2UgQ01EX0hFQURQSE9ORSAoMHgwNSwgZS5nLiBQaG9uZXMgUm91dGluZykgYW5kXG5cdC8vIENNRF9CVVRUT05fTU9ERSAoMHgwNywgZS5nLiBCdXR0b25zKSB3aGVyZSBpZCAwLTMgcmVwcmVzZW50cyBjaGFubmVscyAxLTRcblx0aWYgKCFhY3Rpb24pIHtcblx0XHRjb25zdCBiYXNlQWN0aW9uID0gYWN0aW9ucy5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IHNldHRpbmcuY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHRoaXMgYWN0aW9uIGhhcyBhbiBpZEFkZCBvcHRpb24gKGluZGljYXRpbmcgY2hhbm5lbCBzZWxlY3Rpb24pXG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGEub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHRoZSBzZXR0aW5nLmlkIG9mZnNldCBtYXRjaGVzIG9uZSBvZiB0aGUgaWRBZGQgY2hvaWNlIElEc1xuXHRcdFx0Y29uc3QgY2hhbm5lbE9mZnNldCA9IHNldHRpbmcuaWQgLSBhLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdH0pXG5cdFx0aWYgKGJhc2VBY3Rpb24pIHtcblx0XHRcdGFjdGlvbiA9IGJhc2VBY3Rpb25cblx0XHR9XG5cdH1cblxuXHRjb25zdCBjbWRIZXggPSB0b0hleChzZXR0aW5nLmNtZF9pZClcblx0Y29uc3QgaWRIZXggPSB0b0hleChzZXR0aW5nLmlkKVxuXHRjb25zdCB2YWxIZXggPSBieXRlc1RvSGV4KHNldHRpbmcudmFsdWVCeXRlcylcblx0Y29uc3QgdmFsRGVjID1cblx0XHRzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHQ/IGZvcm1hdFJnYkNvbG9yKHNldHRpbmcudmFsdWVCeXRlc1swXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzFdLCBzZXR0aW5nLnZhbHVlQnl0ZXNbMl0pXG5cdFx0XHQ6IHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDFcblx0XHRcdFx0PyBzZXR0aW5nLnZhbHVlQnl0ZXNbMF1cblx0XHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMuam9pbignLCcpXG5cblx0Ly8gQnVpbGQgdGhlIHByZWZpeDogY21kOjB4MTIgY2g6MCBpZDoweDAxIHZhbDoweDE0IChjaCBvbmx5IGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoKVxuXHRjb25zdCBidXNDaFN0ciA9IHNldHRpbmcuYnVzQ2ggIT09IHVuZGVmaW5lZCA/IGAgY2g6JHtzZXR0aW5nLmJ1c0NofWAgOiAnJ1xuXHRjb25zdCBwcmVmaXggPSBgY21kOiR7Y21kSGV4fSR7YnVzQ2hTdHJ9IGlkOiR7aWRIZXh9IHZhbDoke3ZhbEhleH1gXG5cblx0Ly8gSWYgd2UgaGF2ZSBhbiBhY3Rpb24gd2l0aCBhIG5hbWUgYW5kIGNob2ljZSBsYWJlbCwgdXNlIGl0XG5cdGlmIChhY3Rpb24pIHtcblx0XHRsZXQgbmFtZSA9IGFjdGlvbi5uYW1lXG5cblx0XHQvLyBJZiBzZXR0aW5nIGhhcyBidXNDaCwgYWRkIGNoYW5uZWwgaW5mbyB0byBuYW1lXG5cdFx0aWYgKHNldHRpbmcuYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0bmFtZSA9IGAke25hbWV9IENoJHtzZXR0aW5nLmJ1c0NoICsgMX1gXG5cdFx0fVxuXHRcdC8vIE90aGVyd2lzZSwgaWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkLCBpbmNsdWRlIHRoZSBpZEFkZCBsYWJlbFxuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoaWRBZGRPcHRpb24/LmNob2ljZXMpIHtcblx0XHRcdFx0Y29uc3QgY2hhbm5lbE9mZnNldCA9IHNldHRpbmcuaWQgLSBhY3Rpb24uaWRcblx0XHRcdFx0Y29uc3QgaWRBZGRDaG9pY2UgPSBpZEFkZE9wdGlvbi5jaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IGNoYW5uZWxPZmZzZXQpXG5cdFx0XHRcdGlmIChpZEFkZENob2ljZSkge1xuXHRcdFx0XHRcdG5hbWUgPSBgJHtuYW1lfSAke2lkQWRkQ2hvaWNlLmxhYmVsfWBcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIExvb2sgZm9yIHRoZSB2YWx1ZSBvcHRpb24gKG5vdCBidXNDaCBvciBpZEFkZClcblx0XHRjb25zdCB2YWx1ZU9wdGlvbiA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0XHRpZiAodmFsdWVPcHRpb24/LmNob2ljZXMgJiYgc2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBzZXR0aW5nLnZhbHVlQnl0ZXNbMF0pXG5cdFx0XHRpZiAoY2hvaWNlKSB7XG5cdFx0XHRcdHJldHVybiBgJHtwcmVmaXh9IHwgJHtuYW1lfTogJHtjaG9pY2UubGFiZWx9ICgke3ZhbERlY30pYFxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7dmFsRGVjfWBcblx0fVxuXG5cdC8vIE5vIGFjdGlvbiBmb3VuZCAtIGp1c3Qgc2hvdyB0aGUgcmF3IHZhbHVlc1xuXHRyZXR1cm4gYCR7cHJlZml4fSB8IFVua25vd24gU2V0dGluZ2Bcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgUEFSU0VSIERJU1BBVENIIFdJVEggQVVUTy1ERVRFQ1RJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBQYXJzZXMgZ2V0QWxsU2V0dGluZ3MgcmVzcG9uc2Ugd2l0aCBhdXRvbWF0aWMgZm9ybWF0IGRldGVjdGlvbi5cbiAqXG4gKiBTdHJhdGVneTpcbiAqIDEuIElmIG1vZGVsIGhhcyBleHBsaWNpdCBcInNlY3Rpb25lZFwiIHByb3BlcnR5LCB1c2UgdGhhdFxuICogMi4gT3RoZXJ3aXNlLCB0cnkgRkxBVCBwYXJzZXIgZmlyc3QgKGl0J3Mgc2ltcGxlcilcbiAqIDMuIElmIEZMQVQgcmV0dXJucyAwIHNldHRpbmdzLCB0cnkgU0VDVElPTkVEIHBhcnNlclxuICogNC4gVXNlIHdoaWNoZXZlciBwYXJzZXIgcmV0dXJucyBtb3JlIHNldHRpbmdzXG4gKlxuICogQHJldHVybnMge3NldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10sIGRldGVjdGVkU2VjdGlvbmVkOiBib29sZWFuIHwgbnVsbH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRidWY6IEJ1ZmZlcixcbik6IHsgc2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXTsgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGJvb2xlYW4gfCBudWxsIH0ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdGNvbnN0IGRlY2xhcmVkU2VjdGlvbmVkID0gc2NoZW1hPy5zZWN0aW9uZWRcblxuXHQvLyBJZiBleHBsaWNpdGx5IGRlY2xhcmVkIGluIEpTT04sIHVzZSB0aGF0XG5cdGlmIChkZWNsYXJlZFNlY3Rpb25lZCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0Y29uc3Qgc2V0dGluZ3MgPSBkZWNsYXJlZFNlY3Rpb25lZFxuXHRcdFx0PyBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKVxuXHRcdFx0OiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcblx0XHRyZXR1cm4geyBzZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfSAvLyBudWxsID0gdXNlZCBkZWNsYXJlZCB2YWx1ZVxuXHR9XG5cblx0Ly8gTm8gZGVjbGFyYXRpb24gLSB0cnkgYm90aCBwYXJzZXJzIGFuZCBwaWNrIHRoZSBiZXN0IG9uZVxuXHRsZXQgZmxhdFNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXHRsZXQgc2VjdGlvbmVkU2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0dHJ5IHtcblx0XHRmbGF0U2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5kZWJ1ZyhgRmxhdCBwYXJzZXIgZmFpbGVkOiAke2V9YClcblx0fVxuXG5cdHRyeSB7XG5cdFx0c2VjdGlvbmVkU2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBTZWN0aW9uZWQgcGFyc2VyIGZhaWxlZDogJHtlfWApXG5cdH1cblxuXHQvLyBQaWNrIHRoZSBwYXJzZXIgdGhhdCByZXR1cm5lZCBtb3JlIHNldHRpbmdzXG5cdGlmIChzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGggPiBmbGF0U2V0dGluZ3MubGVuZ3RoKSB7XG5cdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgU0VDVElPTkVEIGZvcm1hdCAoc2VjdGlvbmVkPSR7c2VjdGlvbmVkU2V0dGluZ3MubGVuZ3RofSB2cyBmbGF0PSR7ZmxhdFNldHRpbmdzLmxlbmd0aH0pYClcblx0XHRyZXR1cm4geyBzZXR0aW5nczogc2VjdGlvbmVkU2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiB0cnVlIH1cblx0fSBlbHNlIGlmIChmbGF0U2V0dGluZ3MubGVuZ3RoID4gMCkge1xuXHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIEZMQVQgZm9ybWF0IChmbGF0PSR7ZmxhdFNldHRpbmdzLmxlbmd0aH0gdnMgc2VjdGlvbmVkPSR7c2VjdGlvbmVkU2V0dGluZ3MubGVuZ3RofSlgKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBmbGF0U2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiBmYWxzZSB9XG5cdH0gZWxzZSB7XG5cdFx0Ly8gQm90aCBwYXJzZXJzIHJldHVybmVkIDAgc2V0dGluZ3Ncblx0XHRsb2dnZXIud2FybihgV2FybmluZzogQm90aCBwYXJzZXJzIHJldHVybmVkIDAgc2V0dGluZ3MgZm9yIG1vZGVsICR7bW9kZWx9YClcblx0XHRyZXR1cm4geyBzZXR0aW5nczogW10sIGRldGVjdGVkU2VjdGlvbmVkOiBudWxsIH1cblx0fVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsKG1vZGVsOiBzdHJpbmcsIGJ1ZjogQnVmZmVyKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgeyBzZWN0aW9uZWQgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gc2VjdGlvbmVkID8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbCkgOiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcbn1cblxuLyogXHUyNzA1IGJhY2t3YXJkLWNvbXBhdGlibGUgZXhwb3J0ICovXG5leHBvcnQgY29uc3QgcGFyc2VHZXRBbGxTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbFxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBWQUxVRSBcdTIxOTIgT1BUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzOiBudW1iZXJbXSk6IFN0QWN0aW9uT3B0aW9uIHtcblx0aWYgKHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxKSB7XG5cdFx0cmV0dXJuIHsgaWQ6ICd2YWx1ZScsIGxhYmVsOiAnVmFsdWUnLCB0eXBlOiAnbnVtYmVyJywgZGVmYXVsdDogdmFsdWVCeXRlc1swXSB9XG5cdH1cblxuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDMpIHtcblx0XHRjb25zdCBbciwgZywgYl0gPSB2YWx1ZUJ5dGVzXG5cdFx0cmV0dXJuIHtcblx0XHRcdGlkOiAndmFsdWUnLFxuXHRcdFx0bGFiZWw6ICdDb2xvcicsXG5cdFx0XHR0eXBlOiAnY29sb3JwaWNrZXInLFxuXHRcdFx0ZGVmYXVsdDogZm9ybWF0UmdiQ29sb3IociwgZywgYiksXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIHsgaWQ6ICd2YWx1ZScsIGxhYmVsOiAnVmFsdWUnLCB0eXBlOiAncmF3JywgZGVmYXVsdDogWy4uLnZhbHVlQnl0ZXNdIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU01BUlQgSlNPTiBVUERBVEVcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyhcblx0bW9kZWxKc29uOiBTdE1vZGVsSnNvbixcblx0cGFyc2VkOiBQYXJzZWRTZXR0aW5nW10sXG5cdGFsbE1vZGVsczogUmVjb3JkPHN0cmluZywgU3RNb2RlbEpzb24+LFxuKTogU3RNb2RlbEpzb24ge1xuXHRjb25zdCBvdXQgPSBzdHJ1Y3R1cmVkQ2xvbmUobW9kZWxKc29uKVxuXG5cdC8vIEVuc3VyZSBjbWRTY2hlbWEgYXJyYXkgZXhpc3RzXG5cdGlmICghb3V0LmNtZFNjaGVtYSkge1xuXHRcdG91dC5jbWRTY2hlbWEgPSBbXVxuXHR9XG5cblx0Ly8gU29ydCBvdGhlciBtb2RlbHMgYnkgbnVtZXJpYyBkaXN0YW5jZSB0byBjdXJyZW50IG1vZGVsXG5cdGNvbnN0IGNhbmRpZGF0ZXMgPSBPYmplY3QudmFsdWVzKGFsbE1vZGVscylcblx0XHQuZmlsdGVyKChtKSA9PiBtLm1vZGVsICE9PSBtb2RlbEpzb24ubW9kZWwpIC8vIGV4Y2x1ZGUgc2VsZlxuXHRcdC5zb3J0KChhLCBiKSA9PiBtb2RlbERpc3RhbmNlKG1vZGVsSnNvbi5tb2RlbCwgYS5tb2RlbCkgLSBtb2RlbERpc3RhbmNlKG1vZGVsSnNvbi5tb2RlbCwgYi5tb2RlbCkpXG5cblx0bG9nZ2VyLmluZm8oYFVwZGF0aW5nIG1vZGVsOiAke21vZGVsSnNvbi5tb2RlbH1gKVxuXHRsb2dnZXIuZGVidWcoYENhbmRpZGF0ZXMgZm9yIGluZmVyZW5jZTogJHtjYW5kaWRhdGVzLm1hcCgoYykgPT4gYy5tb2RlbCkuam9pbignLCAnKX1gKVxuXG5cdC8vIFByZS1zY2FuOiBmb3IgZWFjaCBjYW5kaWRhdGUgaWRBZGQgYmFzZSBlbnRyeSwgZmluZCB0aGUgbWF4aW11bSBzZXF1ZW50aWFsXG5cdC8vIG9mZnNldCB0aGUgcGFja2V0IGNvbnRhaW5zIChldmVuIGJleW9uZCB3aGF0IHRoZSByZWZlcmVuY2UgbW9kZWwga25vd3MpLlxuXHQvLyBLZXk6IGAke2NtZF9pZH1fJHtiYXNlX2lkfWAsIHZhbHVlOiBtYXggc2VxdWVudGlhbCBvZmZzZXQgc2VlbiBpbiBwYXJzZWQgZGF0YS5cblx0Y29uc3QgaWRBZGREZWZlclJhbmdlcyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRmb3IgKGNvbnN0IGJhc2VFbnRyeSBvZiBjLmNtZFNjaGVtYSA/PyBbXSkge1xuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBiYXNlRW50cnkub3B0aW9ucz8uZmluZCgobzogYW55KSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcykgY29udGludWVcblx0XHRcdGNvbnN0IGJhc2VJZCA9IGJhc2VFbnRyeS5pZFxuXHRcdFx0Y29uc3QgY21kSWQgPSBiYXNlRW50cnkuY21kX2lkXG5cdFx0XHRjb25zdCBrZXkgPSBgJHtjbWRJZH1fJHtiYXNlSWR9YFxuXHRcdFx0aWYgKGlkQWRkRGVmZXJSYW5nZXMuaGFzKGtleSkpIGNvbnRpbnVlXG5cdFx0XHQvLyBGaW5kIHRoZSBtYXggc2VxdWVudGlhbCBvZmZzZXQgcHJlc2VudCBpbiB0aGUgcGFyc2VkIHBhY2tldCBmb3IgdGhpcyBiYXNlXG5cdFx0XHRjb25zdCBwYXJzZWRPZmZzZXRzID0gcGFyc2VkXG5cdFx0XHRcdC5maWx0ZXIoKHApID0+IHAuY21kX2lkID09PSBjbWRJZCAmJiBwLmlkID4gYmFzZUlkKVxuXHRcdFx0XHQubWFwKChwKSA9PiBwLmlkIC0gYmFzZUlkKVxuXHRcdFx0XHQuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cdFx0XHQvLyBXYWxrIGZyb20gMSB1cHdhcmQgXHUyMDE0IHN0b3AgYXQgZmlyc3QgZ2FwXG5cdFx0XHRsZXQgbWF4U2VxID0gMFxuXHRcdFx0Zm9yIChjb25zdCBvZmYgb2YgcGFyc2VkT2Zmc2V0cykge1xuXHRcdFx0XHRpZiAob2ZmID09PSBtYXhTZXEgKyAxKSBtYXhTZXEgPSBvZmZcblx0XHRcdFx0ZWxzZSBpZiAob2ZmID4gbWF4U2VxICsgMSkgYnJlYWtcblx0XHRcdH1cblx0XHRcdGlmIChtYXhTZXEgPiAwKSB7XG5cdFx0XHRcdGlkQWRkRGVmZXJSYW5nZXMuc2V0KGtleSwgbWF4U2VxKVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYGlkQWRkIGRlZmVyIHJhbmdlIGZvciBjbWRfaWQ9JHt0b0hleChjbWRJZCl9IGJhc2VfaWQ9JHt0b0hleChiYXNlSWQpfTogb2Zmc2V0cyAxXHUyMDEzJHttYXhTZXF9YClcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQvLyBQcmUtY29tcHV0ZSB0aGUgc2V0IG9mIGFsbCBidXNDaCB2YWx1ZXMgc2VlbiBwZXIgKGNtZF9pZCwgaWQpIHBhaXIgYWNyb3NzIHRoZSBmdWxsXG5cdC8vIHBhcnNlZCByZXNwb25zZSBcdTIwMTQgdXNlZCBsYXRlciB0byBkZWNpZGUgZml4ZWQgdnMuIHNlbGVjdGFibGUgYnVzQ2guXG5cdGNvbnN0IGJ1c0NoU2VlbiA9IG5ldyBNYXA8c3RyaW5nLCBTZXQ8bnVtYmVyPj4oKVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCwgYnVzQ2ggfSBvZiBwYXJzZWQpIHtcblx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkgY29udGludWVcblx0XHRjb25zdCBrZXkgPSBgJHtjbWRfaWR9XyR7aWR9YFxuXHRcdGlmICghYnVzQ2hTZWVuLmhhcyhrZXkpKSBidXNDaFNlZW4uc2V0KGtleSwgbmV3IFNldCgpKVxuXHRcdGJ1c0NoU2Vlbi5nZXQoa2V5KSEuYWRkKGJ1c0NoKVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBQQVNTIDE6IHJlc29sdmUgZWFjaCBwYXJzZWQgZW50cnkgXHUyMDE0IGV4YWN0IG1hdGNoLCBpbmZlcnJlZCxcblx0Ly8gaWRBZGQtZm9sZCAob2Zmc2V0IGludG8gYW4gYWxyZWFkeS1hZGRlZCBiYXNlIGVudHJ5KSwgb3IgdW5rbm93blxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdGZvciAoY29uc3QgeyBjbWRfaWQsIGlkLCBidXNDaCwgdmFsdWVCeXRlcyB9IG9mIHBhcnNlZCkge1xuXHRcdC8vIDFhLiBFeGFjdCBtYXRjaCBhbHJlYWR5IGluIG91dHB1dCBzY2hlbWEgXHUyMDE0IGp1c3QgcmVmcmVzaCB0aGUgZGVmYXVsdFxuXHRcdGNvbnN0IGV4aXN0aW5nRXhhY3QgPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0aWYgKGV4aXN0aW5nRXhhY3QpIHtcblx0XHRcdGNvbnN0IG9wdCA9IGV4aXN0aW5nRXhhY3Qub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJylcblx0XHRcdGlmIChvcHQpIG9wdC5kZWZhdWx0ID0gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpLmRlZmF1bHRcblx0XHRcdGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0Ly8gMWIuIENoZWNrIGlmIHRoaXMgaWQgZm9sZHMgaW50byBhbiBhbHJlYWR5LWFkZGVkIGJhc2UgZW50cnkgdmlhIGlkQWRkLlxuXHRcdC8vICAgICBHYXRlOiB0aGUgb2Zmc2V0IG11c3QgYWN0dWFsbHkgZXhpc3QgaW4gdGhlIHJlZmVyZW5jZSBtb2RlbCdzIGlkQWRkIGNob2ljZXNcblx0XHQvLyAgICAgdG8gYXZvaWQgc3dhbGxvd2luZyB1bnJlbGF0ZWQgc2FtZS1jbWRfaWQgZW50cmllcyAoZS5nLiBTaWRldG9uZSBhdCBpZD0yMSkuXG5cdFx0Y29uc3QgaWRBZGRCYXNlID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0aWYgKGlkIDw9IGEuaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBhLmlkXG5cdFx0XHQvLyBPbmx5IGZvbGQgaWYgYSByZWZlcmVuY2UgbW9kZWwgZXhwbGljaXRseSBsaXN0cyB0aGlzIG9mZnNldCBpbiBpdHMgaWRBZGQgY2hvaWNlc1xuXHRcdFx0cmV0dXJuIGNhbmRpZGF0ZXMuc29tZSgoYykgPT4ge1xuXHRcdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChyKSA9PiByLmNtZF9pZCA9PT0gY21kX2lkICYmIHIuaWQgPT09IGEuaWQpXG5cdFx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdHJldHVybiByZWZJZEFkZD8uY2hvaWNlcz8uc29tZSgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHRcdH0pXG5cdFx0fSlcblx0XHRpZiAoaWRBZGRCYXNlKSB7XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGlkQWRkQmFzZS5pZFxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBpZEFkZEJhc2Uub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmIChpZEFkZE9wdD8uY2hvaWNlcyAmJiAhaWRBZGRPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldCkpIHtcblx0XHRcdFx0bGV0IGxhYmVsID0gYENoYW5uZWwgJHtvZmZzZXQgKyAxfWBcblx0XHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdGNvbnN0IHJlZkNob2ljZSA9IHJlZklkQWRkPy5jaG9pY2VzPy5maW5kKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0XHRcdGlmIChyZWZDaG9pY2UpIHtcblx0XHRcdFx0XHRcdGxhYmVsID0gcmVmQ2hvaWNlLmxhYmVsXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRpZEFkZE9wdC5jaG9pY2VzLnB1c2goeyBpZDogb2Zmc2V0LCBsYWJlbCB9KVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhcblx0XHRcdFx0XHRgRm9sZGVkIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBpbnRvIGlkQWRkIGJhc2UgaWQ9JHt0b0hleChpZEFkZEJhc2UuaWQpfSBhcyBvZmZzZXQgJHtvZmZzZXR9IChcIiR7bGFiZWx9XCIpYCxcblx0XHRcdFx0KVxuXHRcdFx0fVxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHQvLyAxYy4gTm8gZXhhY3QgbWF0Y2ggXHUyMDE0IHRyeSBpbmZlcmVuY2UgZnJvbSBjYW5kaWRhdGUgbW9kZWxzXG5cdFx0bGV0IGFjdGlvbjogU3RBY3Rpb24gfCB1bmRlZmluZWRcblxuXHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdFx0aWYgKG1hdGNoKSB7XG5cdFx0XHRcdGFjdGlvbiA9IHN0cnVjdHVyZWRDbG9uZShtYXRjaClcblx0XHRcdFx0Ly8gU3RyaXAgYW55IGV4aXN0aW5nIFwiKGluZmVycmVkIGZyb20gTW9kZWwgWClcIiBzdWZmaXhlcyBiZWZvcmUgYWRkaW5nIG91ciBvd25cblx0XHRcdFx0Y29uc3QgYmFzZU5hbWUgPSBtYXRjaC5uYW1lLnJlcGxhY2UoL1xccypcXChpbmZlcnJlZCBmcm9tIE1vZGVsIFteKV0rXFwpL2csICcnKS50cmltKClcblx0XHRcdFx0YWN0aW9uLm5hbWUgPSBgJHtiYXNlTmFtZX0gKGluZmVycmVkIGZyb20gTW9kZWwgJHtjLm1vZGVsfSlgXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBJbmZlcnJlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gZnJvbSBNb2RlbCAke2MubW9kZWx9IChleGFjdClgKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIENoZWNrIGlmIHRoaXMgaWQgc2hvdWxkIGJlIGRlZmVycmVkIHRvIHBhc3MgMiBcdTIwMTRcblx0XHQvLyBpdCdzIGEgc2VxdWVudGlhbCBpZEFkZCBvZmZzZXQgb2YgYSBrbm93biBjYW5kaWRhdGUgYmFzZSBlbnRyeS5cblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0bGV0IHNob3VsZERlZmVyID0gZmFsc2Vcblx0XHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRcdGNvbnN0IGJhc2VFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IHtcblx0XHRcdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG86IGFueSkgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRpZiAoaWQgPD0gYS5pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBhLmlkXG5cdFx0XHRcdFx0Y29uc3QgbWF4U2VxID0gaWRBZGREZWZlclJhbmdlcy5nZXQoYCR7Y21kX2lkfV8ke2EuaWR9YCkgPz8gMFxuXHRcdFx0XHRcdHJldHVybiBvZmZzZXQgPD0gbWF4U2VxXG5cdFx0XHRcdH0pXG5cdFx0XHRcdGlmIChiYXNlRW50cnkpIHtcblx0XHRcdFx0XHRzaG91bGREZWZlciA9IHRydWVcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0XHRgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGlzIGFuIGlkQWRkIG9mZnNldCBvZiBjYW5kaWRhdGUgYmFzZSBpZD0ke3RvSGV4KGJhc2VFbnRyeS5pZCl9IFx1MjAxNCBkZWZlcnJpbmcgdG8gcGFzcyAyYCxcblx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKHNob3VsZERlZmVyKSBjb250aW51ZVxuXHRcdH1cblxuXHRcdC8vIEZhbGxiYWNrOiB1bmtub3duIHNldHRpbmdcblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0YWN0aW9uID0ge1xuXHRcdFx0XHRjbWRfaWQsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHRuYW1lOiBgVW5rbm93biBjbWQ6JHt0b0hleChjbWRfaWQpfSBpZDoke3RvSGV4KGlkKS50b1VwcGVyQ2FzZSgpfWAsXG5cdFx0XHRcdG9wdGlvbnM6IFt2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcyldLFxuXHRcdFx0fVxuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIGFjdGlvbi5idXNDaCA9IGJ1c0NoXG5cdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGluZmVyIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBGaXggMTogYnVzQ2ggaGFuZGxpbmcgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBTdHJpcCBhbnkgaW5oZXJpdGVkIGJ1c0NoIG9wdGlvbiBmcm9tIHRoZSBjYW5kaWRhdGUgXHUyMDE0IHdlJ2xsIHJlLWRlcml2ZVxuXHRcdFx0Ly8gaXQgZnJvbSB3aGF0IHRoZSBwYWNrZXQgYWN0dWFsbHkgcmVwb3J0ZWQgZm9yIHRoaXMgZGV2aWNlLlxuXHRcdFx0YWN0aW9uLm9wdGlvbnMgPSBhY3Rpb24ub3B0aW9ucz8uZmlsdGVyKChvKSA9PiBvLmlkICE9PSAnYnVzQ2gnKSA/PyBbXVxuXHRcdFx0ZGVsZXRlIGFjdGlvbi5idXNDaFxuXG5cdFx0XHRjb25zdCBzZWVuQnVzQ2hWYWx1ZXMgPSBidXNDaFNlZW4uZ2V0KGAke2NtZF9pZH1fJHtpZH1gKVxuXHRcdFx0aWYgKHNlZW5CdXNDaFZhbHVlcyAmJiBzZWVuQnVzQ2hWYWx1ZXMuc2l6ZSA+IDApIHtcblx0XHRcdFx0Y29uc3QgbWF4QnVzQ2ggPSBNYXRoLm1heCguLi5zZWVuQnVzQ2hWYWx1ZXMpXG5cdFx0XHRcdGlmIChtYXhCdXNDaCA9PT0gMCkge1xuXHRcdFx0XHRcdC8vIE9ubHkgZXZlciBzYXcgYnVzQ2g9MCBcdTIxOTIgZml4ZWQgcHJvcGVydHksIG5vdCBhbiBvcHRpb25cblx0XHRcdFx0XHRhY3Rpb24uYnVzQ2ggPSAwXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0Ly8gTXVsdGlwbGUgY2hhbm5lbHMgb2JzZXJ2ZWQgXHUyMTkyIHNlbGVjdGFibGUgb3B0aW9uXG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2hDaG9pY2VzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogbWF4QnVzQ2ggKyAxIH0sIChfLCBpKSA9PiAoe1xuXHRcdFx0XHRcdFx0aWQ6IGksXG5cdFx0XHRcdFx0XHRsYWJlbDogYENoYW5uZWwgJHtpICsgMX1gLFxuXHRcdFx0XHRcdH0pKVxuXHRcdFx0XHRcdGFjdGlvbi5vcHRpb25zLnVuc2hpZnQoe1xuXHRcdFx0XHRcdFx0aWQ6ICdidXNDaCcsXG5cdFx0XHRcdFx0XHRsYWJlbDogJ0NoYW5uZWwnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdFx0XHRcdGNob2ljZXM6IGJ1c0NoQ2hvaWNlcyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IDAsXG5cdFx0XHRcdFx0fSBhcyBhbnkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEZpeCAyOiBkZWZhdWx0IG11c3QgZXhpc3QgaW4gY2hvaWNlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIFNldCB0aGUgZGVmYXVsdCB0byB0aGUgb2JzZXJ2ZWQgdmFsdWUuIElmIHRoYXQgdmFsdWUgaXNuJ3QgaW4gdGhlXG5cdFx0XHQvLyBpbmhlcml0ZWQgY2hvaWNlcyBsaXN0LCB0aGUgY2hvaWNlcyBhcmUgZnJvbSBhIHN0cnVjdHVyYWxseSBkaWZmZXJlbnRcblx0XHRcdC8vIG1vZGVsIGFuZCBjYW4ndCBiZSB0cnVzdGVkIFx1MjAxNCBkaXNjYXJkIHRoZW0gYW5kIGZhbGwgYmFjayB0byBhIHBsYWluIG51bWJlci5cblx0XHRcdGNvbnN0IG9ic2VydmVkRGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cdFx0XHRjb25zdCB2YWx1ZU9wdCA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKVxuXHRcdFx0aWYgKHZhbHVlT3B0KSB7XG5cdFx0XHRcdGlmICh2YWx1ZU9wdC5jaG9pY2VzICYmIEFycmF5LmlzQXJyYXkodmFsdWVPcHQuY2hvaWNlcykpIHtcblx0XHRcdFx0XHRjb25zdCBpbkNob2ljZXMgPSB2YWx1ZU9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2JzZXJ2ZWREZWZhdWx0KVxuXHRcdFx0XHRcdGlmICghaW5DaG9pY2VzKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2Fybihcblx0XHRcdFx0XHRcdFx0YEluZmVycmVkIGNob2ljZXMgZm9yIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBkb24ndCBjb250YWluIG9ic2VydmVkIHZhbHVlICR7b2JzZXJ2ZWREZWZhdWx0fSBcdTIwMTQgZGlzY2FyZGluZyBpbmhlcml0ZWQgY2hvaWNlc2AsXG5cdFx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0XHQvLyBLZWVwIGxhYmVsL3Rvb2x0aXAgYnV0IGRyb3AgY2hvaWNlcywgc3dpdGNoIHRvIHBsYWluIG51bWJlclxuXHRcdFx0XHRcdFx0dmFsdWVPcHQudHlwZSA9ICdudW1iZXInXG5cdFx0XHRcdFx0XHRkZWxldGUgKHZhbHVlT3B0IGFzIGFueSkuY2hvaWNlc1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHR2YWx1ZU9wdC5kZWZhdWx0ID0gb2JzZXJ2ZWREZWZhdWx0XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0b3V0LmNtZFNjaGVtYS5wdXNoKGFjdGlvbilcblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gUEFTUyAyOiBmb2xkIGFueSBkZWZlcnJlZCBpZEFkZCBvZmZzZXRzIHdob3NlIGJhc2UgZW50cnlcblx0Ly8gaXMgbm93IHByZXNlbnQgaW4gdGhlIG91dHB1dCBzY2hlbWEuXG5cdC8vIEdhdGU6IHRoZSBvZmZzZXQgbXVzdCBlaXRoZXIgZXhpc3QgaW4gYSByZWZlcmVuY2UgbW9kZWwncyBjaG9pY2VzLFxuXHQvLyBPUiB0aGUgYmFzZSBlbnRyeSBpdHNlbGYgd2FzIGluZmVycmVkIChoYXMgaWRBZGQpIGFuZCB0aGUgb2Zmc2V0XG5cdC8vIGNvbnRpbnVlcyBzZXF1ZW50aWFsbHkgYmV5b25kIHRoZSByZWZlcmVuY2UgbW9kZWwncyBrbm93biByYW5nZS5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCB9IG9mIHBhcnNlZCkge1xuXHRcdGNvbnN0IGFscmVhZHlUb3BMZXZlbCA9IG91dC5jbWRTY2hlbWEuc29tZSgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZClcblx0XHRpZiAoYWxyZWFkeVRvcExldmVsKSBjb250aW51ZVxuXG5cdFx0Ly8gRmluZCBhIGJhc2UgZW50cnkgaW4gdGhlIG91dHB1dCB0aGF0IGhhcyBpZEFkZCBhbmQgd2hvc2UgaWQgPCB0aGlzIGlkXG5cdFx0Y29uc3QgaWRBZGRCYXNlID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdHJldHVybiAhIWlkQWRkT3B0Py5jaG9pY2VzICYmIGlkID4gYS5pZFxuXHRcdH0pXG5cdFx0aWYgKCFpZEFkZEJhc2UpIGNvbnRpbnVlXG5cblx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGlkQWRkQmFzZS5pZFxuXHRcdGNvbnN0IGlkQWRkT3B0ID0gaWRBZGRCYXNlLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcyB8fCBpZEFkZE9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KSkgY29udGludWVcblxuXHRcdC8vIEFjY2VwdCB0aGUgZm9sZCBpZjogYSByZWZlcmVuY2UgbW9kZWwgZXhwbGljaXRseSBoYXMgdGhpcyBvZmZzZXQsXG5cdFx0Ly8gT1IgdGhlIG9mZnNldHMgYXJlIHN0cmljdGx5IHNlcXVlbnRpYWwgZnJvbSAwIChkZXZpY2UgaGFzIG1vcmUgY2hhbm5lbHMgdGhhbiByZWZlcmVuY2UpXG5cdFx0Y29uc3QgcmVmSGFzT2Zmc2V0ID0gY2FuZGlkYXRlcy5zb21lKChjKSA9PiB7XG5cdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChyKSA9PiByLmNtZF9pZCA9PT0gY21kX2lkICYmIHIuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRyZXR1cm4gcmVmSWRBZGQ/LmNob2ljZXM/LnNvbWUoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0fSlcblx0XHRjb25zdCBleGlzdGluZ09mZnNldHMgPSBpZEFkZE9wdC5jaG9pY2VzLm1hcCgoYzogYW55KSA9PiBjLmlkIGFzIG51bWJlcikuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cdFx0Y29uc3QgaXNTZXF1ZW50aWFsID0gZXhpc3RpbmdPZmZzZXRzLmxlbmd0aCA+IDAgJiYgb2Zmc2V0ID09PSBleGlzdGluZ09mZnNldHNbZXhpc3RpbmdPZmZzZXRzLmxlbmd0aCAtIDFdICsgMVxuXG5cdFx0aWYgKCFyZWZIYXNPZmZzZXQgJiYgIWlzU2VxdWVudGlhbCkgY29udGludWVcblxuXHRcdC8vIEluaGVyaXQgbGFiZWwgZnJvbSByZWZlcmVuY2UgbW9kZWwgaWYgYXZhaWxhYmxlLCBvdGhlcndpc2UgZ2VuZXJhdGUgb25lXG5cdFx0bGV0IGxhYmVsID0gYENoYW5uZWwgJHtvZmZzZXQgKyAxfWBcblx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZEFkZEJhc2UuaWQpXG5cdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0Y29uc3QgcmVmQ2hvaWNlID0gcmVmSWRBZGQ/LmNob2ljZXM/LmZpbmQoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0XHRpZiAocmVmQ2hvaWNlKSB7XG5cdFx0XHRcdGxhYmVsID0gcmVmQ2hvaWNlLmxhYmVsXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWRBZGRPcHQuY2hvaWNlcy5wdXNoKHsgaWQ6IG9mZnNldCwgbGFiZWwgfSlcblx0XHRsb2dnZXIuaW5mbyhcblx0XHRcdGBQYXNzIDI6IEZvbGRlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gaW50byBpZEFkZCBiYXNlIGlkPSR7dG9IZXgoaWRBZGRCYXNlLmlkKX0gYXMgb2Zmc2V0ICR7b2Zmc2V0fSAoXCIke2xhYmVsfVwiKWAsXG5cdFx0KVxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTQVZFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBzYXZlTW9kZWxKc29uUHJldHR5KGZpbGVQYXRoOiBzdHJpbmcsIGpzb25PYmo6IFN0TW9kZWxKc29uKTogdm9pZCB7XG5cdHRyeSB7XG5cdFx0Ly8gRW5zdXJlIHByb3BlciBrZXkgb3JkZXJpbmc6IG1vZGVsLCBzZWN0aW9uZWQgKGlmIHByZXNlbnQpLCByZWZyZXNoQWZ0ZXJDb21tYW5kLCBjbWRTY2hlbWFcblx0XHRjb25zdCBvcmRlcmVkT2JqOiBhbnkgPSB7IG1vZGVsOiBqc29uT2JqLm1vZGVsIH1cblxuXHRcdC8vIEFkZCBzZWN0aW9uZWQga2V5IGlmIHByZXNlbnQgKHJpZ2h0IGFmdGVyIG1vZGVsKVxuXHRcdGlmICgnc2VjdGlvbmVkJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLnNlY3Rpb25lZCA9IGpzb25PYmouc2VjdGlvbmVkXG5cdFx0fVxuXG5cdFx0Ly8gQWRkIG90aGVyIGtleXMgaW4gb3JkZXJcblx0XHRpZiAoJ3JlZnJlc2hBZnRlckNvbW1hbmQnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmoucmVmcmVzaEFmdGVyQ29tbWFuZCA9IGpzb25PYmoucmVmcmVzaEFmdGVyQ29tbWFuZFxuXHRcdH1cblx0XHRpZiAoJ2NtZFNjaGVtYScgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5jbWRTY2hlbWEgPSBqc29uT2JqLmNtZFNjaGVtYS5tYXAoKGVudHJ5OiBhbnkpID0+IHtcblx0XHRcdFx0Ly8gRW5mb3JjZSBrZXkgb3JkZXIgd2l0aGluIGVhY2ggc2NoZW1hIGVudHJ5OiBjbWRfaWQsIGlkLCBidXNDaCwgbmFtZSwgb3B0aW9uc1xuXHRcdFx0XHRjb25zdCBvcmRlcmVkRW50cnk6IGFueSA9IHt9XG5cdFx0XHRcdGlmICgnY21kX2lkJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmNtZF9pZCA9IGVudHJ5LmNtZF9pZFxuXHRcdFx0XHRpZiAoJ2lkJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmlkID0gZW50cnkuaWRcblx0XHRcdFx0aWYgKCdidXNDaCcgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5idXNDaCA9IGVudHJ5LmJ1c0NoXG5cdFx0XHRcdGlmICgnbmFtZScgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5uYW1lID0gZW50cnkubmFtZVxuXHRcdFx0XHRpZiAoJ29wdGlvbnMnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkub3B0aW9ucyA9IGVudHJ5Lm9wdGlvbnNcblx0XHRcdFx0Ly8gQ29weSBhbnkgcmVtYWluaW5nIGtleXNcblx0XHRcdFx0Zm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoZW50cnkpKSB7XG5cdFx0XHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRFbnRyeSkpIG9yZGVyZWRFbnRyeVtrZXldID0gZW50cnlba2V5XVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBvcmRlcmVkRW50cnlcblx0XHRcdH0pXG5cdFx0fVxuXHRcdC8vIENvcHkgYW55IG90aGVyIGtleXMgdGhhdCBtaWdodCBleGlzdFxuXHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGpzb25PYmopKSB7XG5cdFx0XHRpZiAoIShrZXkgaW4gb3JkZXJlZE9iaikpIHtcblx0XHRcdFx0b3JkZXJlZE9ialtrZXldID0gKGpzb25PYmogYXMgYW55KVtrZXldXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ3VzdG9tIGZvcm1hdHRlcjoga2VlcCBjaG9pY2Ugb2JqZWN0cyBjb21wYWN0IG9uIG9uZSBsaW5lXG5cdFx0bGV0IGpzb24gPSBKU09OLnN0cmluZ2lmeShvcmRlcmVkT2JqLCBudWxsLCAyKVxuXG5cdFx0Ly8gUmVwbGFjZSBleHBhbmRlZCBjaG9pY2Ugb2JqZWN0cyB3aXRoIGNvbXBhY3Qgc2luZ2xlLWxpbmUgZm9ybWF0XG5cdFx0Ly8gTWF0Y2hlczoge1xcbiAgICAgICAgICAgIFwiaWRcIjogWCxcXG4gICAgICAgICAgICBcImxhYmVsXCI6IFwiWVwiXFxuICAgICAgICAgIH1cblx0XHQvLyBSZXBsYWNlcyB3aXRoOiB7IFwiaWRcIjogWCwgXCJsYWJlbFwiOiBcIllcIiB9XG5cdFx0anNvbiA9IGpzb24ucmVwbGFjZSgvXFx7XFxuXFxzK1wiaWRcIjpcXHMqKFxcZCspLFxcblxccytcImxhYmVsXCI6XFxzKlwiKFteXCJdKilcIlxcblxccytcXH0vZywgJ3sgXCJpZFwiOiAkMSwgXCJsYWJlbFwiOiBcIiQyXCIgfScpXG5cblx0XHRmcy53cml0ZUZpbGVTeW5jKGZpbGVQYXRoLCBqc29uICsgJ1xcbicsICd1dGY4Jylcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmlsZSBXcml0ZSBFcnJvcjogJHtlfWApXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgTE9BRCBERVZJQ0UgSlNPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIExvYWRzIHRoZSBhY3Rpb25zIGFycmF5IGZvciBhIGdpdmVuIG1vZGVsIGZyb20gdGhlIGNlbnRyYWxpemVkIGNhY2hlLlxuICogUmV0dXJucyBhbiBlbXB0eSBhcnJheSBpZiB0aGUgbW9kZWwgaXMgbm90IGZvdW5kLlxuICogQGRlcHJlY2F0ZWQgLSBUaGlzIGZ1bmN0aW9uIGlzIG5vIGxvbmdlciBuZWVkZWQuIFVzZSBnZXREZXZpY2VTY2hlbWEoKSBmcm9tIGNvbmZpZy50cyBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZEFjdGlvbnNGb3JNb2RlbChfZGV2aWNlc0ZvbGRlcjogc3RyaW5nLCBtb2RlbDogc3RyaW5nKTogU3RBY3Rpb25bXSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0cmV0dXJuIHNjaGVtYT8uY21kU2NoZW1hID8/IFtdXG59XG5cbi8qKlxuICogTG9hZHMgdGhlIG1vZGVsIGNvbmZpZ3VyYXRpb24gZnJvbSB0aGUgY2VudHJhbGl6ZWQgY2FjaGUuXG4gKiBAZGVwcmVjYXRlZCAtIFRoaXMgZnVuY3Rpb24gaXMgbm8gbG9uZ2VyIG5lZWRlZC4gVXNlIGdldERldmljZVNjaGVtYSgpIGZyb20gY29uZmlnLnRzIGluc3RlYWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsb2FkTW9kZWxDb25maWcoXG5cdF9kZXZpY2VzRm9sZGVyOiBzdHJpbmcsXG5cdG1vZGVsOiBzdHJpbmcsXG4pOiB7IGFjdGlvbnM6IFN0QWN0aW9uW107IHJlZnJlc2hBZnRlckNvbW1hbmQ6IGJvb2xlYW4gfSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0cmV0dXJuIHtcblx0XHRhY3Rpb25zOiBzY2hlbWE/LmNtZFNjaGVtYSA/PyBbXSxcblx0XHRyZWZyZXNoQWZ0ZXJDb21tYW5kOiBzY2hlbWE/LnJlZnJlc2hBZnRlckNvbW1hbmQgPz8gdHJ1ZSwgLy8gRGVmYXVsdCB0byB0cnVlIGlmIG5vdCBzcGVjaWZpZWRcblx0fVxufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQgeyBidWlsZEZlZWRiYWNrcyB9IGZyb20gJy4vYnVpbGQtY29tbWFuZHMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMsIGZpbmRBY3Rpb25Gb3JTZXR0aW5nIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRmVlZGJhY2tzJylcblxuLyoqXG4gKiBIZWxwZXIgZnVuY3Rpb24gdG8gZ2V0IGxhYmVsIGZyb20gY2hvaWNlcyBiYXNlZCBvbiB2YWx1ZVxuICovXG5mdW5jdGlvbiBnZXRMYWJlbEZvclZhbHVlKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuXHR2YWx1ZTogbnVtYmVyLFxuKTogc3RyaW5nIHwgbnVtYmVyIHtcblx0Y29uc3Qgc2V0dGluZyA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRpZiAoIXNldHRpbmcgfHwgIUFycmF5LmlzQXJyYXkoc2V0dGluZy5vcHRpb25zKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgJ3ZhbHVlJyBvcHRpb24gd2hpY2ggY29udGFpbnMgdGhlIGNob2ljZXNcblx0Y29uc3QgdmFsdWVPcHRpb24gPSBzZXR0aW5nLm9wdGlvbnMuZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0aWYgKCF2YWx1ZU9wdGlvbiB8fCAhQXJyYXkuaXNBcnJheSh2YWx1ZU9wdGlvbi5jaG9pY2VzKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgY2hvaWNlIHdpdGggbWF0Y2hpbmcgaWRcblx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjOiBhbnkpID0+IGMuaWQgPT09IHZhbHVlKVxuXHRyZXR1cm4gY2hvaWNlPy5sYWJlbCA/PyB2YWx1ZVxufVxuXG4vKipcbiAqIEJ1aWxkIGFuZCB3aXJlIENvbXBhbmlvbiBmZWVkYmFjayBkZWZpbml0aW9uc1xuICogUGF0dGVybiBtYXRjaGVzIGFjdGlvbnMudHMgLSBmaWx0ZXJzIGJ5IGFjdGl2ZSBtb2RlbCBhbmQgd2lyZXMgY2FsbGJhY2tzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVGZWVkYmFja3Moc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdGZWVkYmFja3MgPSBidWlsZEZlZWRiYWNrcygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEZlZWRiYWNrczogYW55ID0ge31cblxuXHQvLyBHZXQgdGhlIGFjdGl2ZSBtb2RlbCBmcm9tIHRoZSBjYWNoZWQgdmFsdWUgc2V0IGJ5IHN5bmNNb2RlbCgpXG5cdGNvbnN0IGFjdGl2ZU1vZGVsID0gc2VsZi5hY3RpdmVNb2RlbFxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgRkVFREJBQ0tTIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2ZlZWRiYWNrSWQsIGZlZWRiYWNrXSBvZiBPYmplY3QuZW50cmllcyhyYXdGZWVkYmFja3MpKSB7XG5cdFx0Y29uc3QgeyBtb2RlbCwgY21kSWQsIGJhc2VJZCB9ID0gcGFyc2VTZXR0aW5nSWQoZmVlZGJhY2tJZClcblxuXHRcdC8vIE9ubHkgaW5jbHVkZSBmZWVkYmFja3MgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIFZBTFVFIEZFRURCQUNLOiBSZXR1cm5zIGN1cnJlbnQgdmFsdWUgZm9yIGxvY2FsIHZhcmlhYmxlXG5cdFx0d2lyZWRGZWVkYmFja3NbZmVlZGJhY2tJZF0gPSB7XG5cdFx0XHQuLi5mZWVkYmFjayxcblx0XHRcdGNhbGxiYWNrOiAoZmVlZGJhY2tFdmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblxuXHRcdFx0XHQvLyBidXNDaCBmcm9tIG9wdGlvbnMgdGFrZXMgcHJpb3JpdHk7IGZhbGwgYmFjayB0byBmaXhlZCBidXNDaCBpbiBzY2hlbWFcblx0XHRcdFx0bGV0IGJ1c0NoID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydidXNDaCddXG5cdFx0XHRcdGlmIChidXNDaCA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc2NoZW1hQWN0aW9uID0gZmluZEFjdGlvbkZvclNldHRpbmcoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0aWYgKHNjaGVtYUFjdGlvbj8uYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdFx0YnVzQ2ggPSBzY2hlbWFBY3Rpb24uYnVzQ2hcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRjb25zdCBjdXJyZW50ID0gc2VsZi5zdENvbnRyb2xsZXIuZ2V0U2V0dGluZ1ZhbHVlKGlwLCBjbWRJZCwgc2V0dGluZ0lkLCBidXNDaClcblxuXHRcdFx0XHQvLyBDaGVjayBpZiB1c2VyIHdhbnRzIGxhYmVsIGluc3RlYWQgb2YgbnVtZXJpYyB2YWx1ZVxuXHRcdFx0XHRjb25zdCBzaG93TGFiZWwgPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ3Nob3dMYWJlbCddID8/IGZhbHNlXG5cblx0XHRcdFx0aWYgKHNob3dMYWJlbCAmJiBjdXJyZW50ICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHQvLyBSZXR1cm4gdGhlIGxhYmVsIGZyb20gY2hvaWNlc1xuXHRcdFx0XHRcdHJldHVybiBnZXRMYWJlbEZvclZhbHVlKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBjdXJyZW50KVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gUmV0dXJuIG51bWVyaWMgdmFsdWUgZGlyZWN0bHkgZm9yIGxvY2FsIHZhcmlhYmxlICh0eXBlOiAndmFsdWUnKVxuXHRcdFx0XHRyZXR1cm4gY3VycmVudCA/PyAwXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdHNlbGYuc2V0RmVlZGJhY2tEZWZpbml0aW9ucyh3aXJlZEZlZWRiYWNrcylcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRlRmVlZGJhY2tzOiB3aXJlZCBmZWVkYmFja3M6ICR7T2JqZWN0LmtleXMod2lyZWRGZWVkYmFja3MpLmxlbmd0aH1gKVxufVxuIiwgImltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSdcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQge1xuXHRDTURfQlVTX0dFVCxcblx0Q01EX0JVU19TRVQsXG5cdENNRF9ERVZfU1BFQyxcblx0Q01EX0dFVF9BTExfU0VUVElOR1MsXG5cdENNRF9HRVRfRklSTVdBUkUsXG5cdENNRF9HTE9CQUxfTUlDX0tJTEwsXG5cdENNRF9NSUNfUFJFX0JVUyxcblx0Q01EX1JFU0VUX0RFVklDRSxcblx0Q01EX1NFVFRJTkdTX1BVU0gsXG5cdGdldENvbW1hbmROYW1lLFxuXHRtYWtlU2V0dGluZ0lkLFxuXHR0b0hleCxcblx0Ynl0ZXNUb0hleCxcblx0dHlwZSBEZXZpY2VJbmZvLFxufSBmcm9tICcuL3R5cGVzLmpzJ1xuaW1wb3J0IHtcblx0cGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsLFxuXHRwYXJzZVNldHRpbmdzUmVzcG9uc2UsXG5cdGZvcm1hdFBhcnNlZFNldHRpbmcsXG5cdHR5cGUgU3RBY3Rpb24sXG5cdHR5cGUgUGFyc2VkU2V0dGluZyxcbn0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcbmltcG9ydCB7XG5cdERBTlRFX01TR19JTkZPX1JFU1BPTlNFLFxuXHRwYXJzZURhbnRlSW5mb1Jlc3BvbnNlLFxuXHRkaXNjb3ZlckRldmljZXMsXG5cdGJ1aWxkRGFudGVJbmZvUmVxdWVzdCxcblx0Z2V0TWFjRm9yRGVzdGluYXRpb24sXG5cdGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uLFxufSBmcm9tICcuL2RhbnRlLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1N0Q29udHJvbGxlcicpXG5cbmV4cG9ydCBjbGFzcyBTdENvbnRyb2xsZXIge1xuXHRwcml2YXRlIHJlYWRvbmx5IGRlZmF1bHRQb3J0OiBudW1iZXIgPSA4NzAwXG5cdHByaXZhdGUgcmVhZG9ubHkgbXVsdGljYXN0R3JvdXAgPSAnMjI0LjAuMC4yMzEnXG5cdHByaXZhdGUgcmVhZG9ubHkgcnhQb3J0ID0gODcwMlxuXG5cdHByaXZhdGUgdHhTb2NrZXQ6IGRncmFtLlNvY2tldFxuXHRwcml2YXRlIHJ4U29ja2V0OiBkZ3JhbS5Tb2NrZXQgLy8gZm9yIHJlY2VpdmluZyByZXNwb25zZXMgKDg3MDIpXG5cdHByaXZhdGUgcGVuZGluZ0Fja3M6IE1hcDxcblx0XHRzdHJpbmcsXG5cdFx0eyByZXNvbHZlOiAoYnVmOiBCdWZmZXIpID0+IHZvaWQ7IHJlamVjdDogKGU6IEVycm9yKSA9PiB2b2lkOyB0aW1lcjogTm9kZUpTLlRpbWVvdXQgfVxuXHQ+ID0gbmV3IE1hcCgpXG5cdHByaXZhdGUgam9pbmVkSW50ZXJmYWNlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KCkgLy8gbG9jYWwgSVBzIHdlJ3ZlIGpvaW5lZCBtdWx0aWNhc3Qgb25cblxuXHQvKiogU2VyaWFsaXplcyBvdXRnb2luZyBjb21tYW5kcyBzbyBlYWNoIHdhaXRzIGZvciBBQ0sgYmVmb3JlIHRoZSBuZXh0IGlzIHNlbnQgKi9cblx0cHJpdmF0ZSBzZW5kUXVldWU6IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKVxuXG5cdC8qKiBUcmFja3MgaG93IG1hbnkgY29tbWFuZHMgYXJlIHF1ZXVlZC9pbi1mbGlnaHQsIHRvIGRlZmVyIHJlcXVlc3RBbGxTZXR0aW5ncyAqL1xuXHRwcml2YXRlIHBlbmRpbmdDb21tYW5kQ291bnQgPSAwXG5cblx0LyoqIFJlc29sdmVzIG9uY2UgdHhTb2NrZXQgaXMgYm91bmQgYW5kIHJlYWR5IHRvIHNlbmQgKi9cblx0cHJpdmF0ZSB0eFJlYWR5OiBQcm9taXNlPHZvaWQ+XG5cblx0LyoqIEFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBmb3Igc2V0dGluZ3MgZGVjb2RpbmcgKi9cblx0cHJpdmF0ZSBtb2RlbDogc3RyaW5nID0gJydcblx0cHJpdmF0ZSBhY3Rpb25zOiBTdEFjdGlvbltdID0gW11cblx0cHJpdmF0ZSByZWZyZXNoQWZ0ZXJDb21tYW5kOiBib29sZWFuID0gdHJ1ZSAvLyBEZWZhdWx0IHRvIHRydWUgKG1vc3QgZGV2aWNlcyBuZWVkIGl0KVxuXG5cdC8qKlxuXHQgKiBLbm93biBzdGF0ZSBvZiBldmVyeSBzZXR0aW5nIHBlciBkZXZpY2UgSVAuXG5cdCAqIEtleWVkIGJ5IElQIFx1MjE5MiBNYXAgb2YgXCIke2NtZElkfS8ke3NldHRpbmdJZH1cIiBcdTIxOTIgY3VycmVudCB2YWx1ZSBieXRlLlxuXHQgKiBQb3B1bGF0ZWQgb24gY29ubmVjdCB2aWEgcmVxdWVzdEFsbFNldHRpbmdzKCksIHVwZGF0ZWQgb24gZXZlcnkgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpLlxuXHQgKiBVc2VkIHRvIGRpZmYgaW5jb21pbmcgcHVzaGVzIChjaGFuZ2VkID0gaW5mbywgdW5jaGFuZ2VkID0gZGVidWcpIGFuZCBmb3IgZmVlZGJhY2tzLlxuXHQgKi9cblx0cHJpdmF0ZSBkZXZpY2VTdGF0ZTogTWFwPHN0cmluZywgTWFwPHN0cmluZywgbnVtYmVyPj4gPSBuZXcgTWFwKClcblxuXHQvKipcblx0ICogSVBzIHRoYXQgaGF2ZSBiZWVuIHZlcmlmaWVkIGFnYWluc3QgdGhlIGNvbmZpZ3VyZWQgbW9kZWwgYW5kIGFyZSBhbGxvd2VkXG5cdCAqIHRvIHJlY2VpdmUgU3R1ZGlvLVQgY29tbWFuZHMuIFBvcHVsYXRlZCBieSBhdXRob3JpemVEZXZpY2UoKSBhZnRlciBhXG5cdCAqIHN1Y2Nlc3NmdWwgcHJvYmVEZXZpY2UoKSBtb2RlbCBtYXRjaCwgb3IgYWZ0ZXIgbXVsdGljYXN0IGRpc2NvdmVyeS5cblx0ICogX3NlbmRBd2FpdEFjaygpIHJlamVjdHMgYW55IGRlc3RJcCBub3QgaW4gdGhpcyBzZXQuXG5cdCAqL1xuXHRwcml2YXRlIGF1dGhvcml6ZWRJcHM6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpXG5cblx0LyoqIENhbGxiYWNrcyByZWdpc3RlcmVkIGJ5IGRpc2NvdmVyRGV2aWNlcygpIFx1MjAxNCBrZXllZCBieSBzb3VyY2UgSVAgKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcnlMaXN0ZW5lcnM6IE1hcDxzdHJpbmcsIChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQ+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrIHRvIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlcyB3aGVuIHN0YXRlIGNoYW5nZXMgKi9cblx0cHJpdmF0ZSBmZWVkYmFja0NhbGxiYWNrPzogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZFxuXG5cdC8qKiBDYWNoZSBvZiBsb2NhbCBpbnRlcmZhY2UgTUFDIGJ5dGVzIHBlciBkZXN0aW5hdGlvbiBJUCwgdG8gYXZvaWQgcmVwZWF0ZWQgT1MgbG9va3VwcyAqL1xuXHRwcml2YXRlIG1hY0NhY2hlOiBNYXA8c3RyaW5nLCBudW1iZXJbXT4gPSBuZXcgTWFwKClcblxuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRsb2dnZXIuaW5mbygnU3RDb250cm9sbGVyIGluaXRpYWxpemVkJylcblxuXHRcdC8vIFNlbmQgc29ja2V0IFx1MjAxNCBiaW5kIHRvIGVwaGVtZXJhbCBwb3J0LiBSZXNwb25zZXMgYWx3YXlzIGdvIHRvIHJ4U29ja2V0IG9uXG5cdFx0Ly8gcG9ydCA4NzAyIChEYW50ZSBoYXJkY29kZXMgdGhlIHJlc3BvbnNlIGRlc3RpbmF0aW9uIHBvcnQgdG8gODcwMikuXG5cdFx0dGhpcy50eFNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cdFx0dGhpcy50eFJlYWR5ID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuYmluZCgwLCAoKSA9PiB7XG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgVFggc29ja2V0IGJvdW5kIHRvIHBvcnQgJHsodGhpcy50eFNvY2tldC5hZGRyZXNzKCkgYXMgeyBwb3J0OiBudW1iZXIgfSkucG9ydH1gKVxuXHRcdFx0XHRyZXNvbHZlKClcblx0XHRcdH0pXG5cdFx0fSlcblx0XHR0aGlzLnR4U29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgVFggc29ja2V0IGVycm9yOiAke2Vycn1gKVxuXHRcdH0pXG5cblx0XHQvLyBSZWNlaXZlIHNvY2tldCAtIGJpbmQgdG8gYWxsIGFkZHJlc3NlcyBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHNcblx0XHR0aGlzLnJ4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2xpc3RlbmluZycsICgpID0+IHtcblx0XHRcdGNvbnN0IGFkZHIgPSB0aGlzLnJ4U29ja2V0LmFkZHJlc3MoKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgbGlzdGVuaW5nIG9uICR7SlNPTi5zdHJpbmdpZnkoYWRkcil9YClcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMucnhTb2NrZXQuc2V0TXVsdGljYXN0TG9vcGJhY2sodHJ1ZSlcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgUlggc29ja2V0IGVycm9yOiAke2Vycn1gKVxuXHRcdH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdtZXNzYWdlJywgKG1zZywgcmluZm8pID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMuaGFuZGxlSW5jb21pbmcobXNnLCByaW5mby5hZGRyZXNzKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLmVycm9yKGBFcnJvciBoYW5kbGluZyBpbmNvbWluZyBtZXNzYWdlOiAke19lfWApXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIEJpbmQgdG8gd2lsZGNhcmQgc28ga2VybmVsIGNhbiBkZWxpdmVyIG11bHRpY2FzdCBwYWNrZXRzIGZvciBqb2luZWQgaW50ZXJmYWNlc1xuXHRcdHRoaXMucnhTb2NrZXQuYmluZCh7IGFkZHJlc3M6ICcwLjAuMC4wJywgcG9ydDogdGhpcy5yeFBvcnQgfSwgKCkgPT4ge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgYm91bmQgdG8gMC4wLjAuMDoke3RoaXMucnhQb3J0fWApXG5cdFx0fSlcblx0fVxuXG5cdHB1YmxpYyBjbG9zZSgpOiB2b2lkIHtcblx0XHR0cnkge1xuXHRcdFx0Zm9yIChjb25zdCBsb2NhbEFkZHIgb2YgQXJyYXkuZnJvbSh0aGlzLmpvaW5lZEludGVyZmFjZXMpKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0dGhpcy5yeFNvY2tldC5kcm9wTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBsb2NhbEFkZHIpXG5cdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMucnhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnR4U29ja2V0LmNsb3NlKClcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBQcm92aWRlIHRoZSBhY3RpdmUgZGV2aWNlIG1vZGVsIGFuZCBhY3Rpb24gZGVmaW5pdGlvbnMgc28gaW5jb21pbmcgbWVzc2FnZXNcblx0ICogY2FuIGJlIGRlY29kZWQgaW50byBodW1hbi1yZWFkYWJsZSBuYW1lcy4gQ2FsbCBmcm9tIG1haW4udHMgYWZ0ZXIgY29uZmlnIGxvYWQuXG5cdCAqL1xuXHRwdWJsaWMgc2V0TW9kZWwobW9kZWw6IHN0cmluZywgYWN0aW9uczogU3RBY3Rpb25bXSwgcmVmcmVzaEFmdGVyQ29tbWFuZDogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcblx0XHR0aGlzLm1vZGVsID0gbW9kZWxcblx0XHR0aGlzLmFjdGlvbnMgPSBhY3Rpb25zXG5cdFx0dGhpcy5yZWZyZXNoQWZ0ZXJDb21tYW5kID0gcmVmcmVzaEFmdGVyQ29tbWFuZFxuXHR9XG5cblx0LyoqXG5cdCAqIFNldCBjYWxsYmFjayB0byB0cmlnZ2VyIHdoZW4gZGV2aWNlIHN0YXRlIGNoYW5nZXMgKGZvciBmZWVkYmFja3MpLlxuXHQgKiBDYWxsIGZyb20gbWFpbi50cyB0byB3aXJlIHVwIGNoZWNrRmVlZGJhY2tzLlxuXHQgKi9cblx0cHVibGljIHNldEZlZWRiYWNrQ2FsbGJhY2soY2FsbGJhY2s6IChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHZvaWQpOiB2b2lkIHtcblx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2sgPSBjYWxsYmFja1xuXHR9XG5cblx0LyoqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZGV2aWNlIGF0IHRoZSBnaXZlbiBJUCBoYXMgYmVlbiBhdXRob3JpemVkIHRvIHJlY2VpdmUgY29tbWFuZHMuICovXG5cdHB1YmxpYyBpc0RldmljZUF1dGhvcml6ZWQoaXA6IHN0cmluZyk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLmF1dGhvcml6ZWRJcHMuaGFzKGlwKVxuXHR9XG5cblx0LyoqIE1hcmsgYW4gSVAgYXMgdmVyaWZpZWQgYW5kIGFsbG93ZWQgdG8gcmVjZWl2ZSBTdHVkaW8tVCBjb21tYW5kcy4gKi9cblx0cHVibGljIGF1dGhvcml6ZURldmljZShpcDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hdXRob3JpemVkSXBzLmFkZChpcClcblx0XHRsb2dnZXIuZGVidWcoYEF1dGhvcml6ZWQgZGV2aWNlIGF0ICR7aXB9YClcblx0fVxuXG5cdC8qKiBSZW1vdmUgYXV0aG9yaXphdGlvbiBmb3IgYW4gSVAgKGUuZy4gb24gY29uZmlnIGNoYW5nZSBvciBtb2RlbCBtaXNtYXRjaCkuICovXG5cdHB1YmxpYyByZXZva2VEZXZpY2UoaXA6IHN0cmluZyk6IHZvaWQge1xuXHRcdHRoaXMuYXV0aG9yaXplZElwcy5kZWxldGUoaXApXG5cdFx0dGhpcy5kZXZpY2VTdGF0ZS5kZWxldGUoaXApXG5cdFx0dGhpcy5tYWNDYWNoZS5kZWxldGUoaXApXG5cdFx0bG9nZ2VyLmRlYnVnKGBSZXZva2VkIGRldmljZSBhdCAke2lwfWApXG5cdH1cblxuXHQvKipcblx0ICogU2VuZHMgYSB1bmljYXN0IERhbnRlIGluZm8gcmVxdWVzdCB0byBhIHNwZWNpZmljIElQIGFuZCB3YWl0cyBmb3IgdGhlXG5cdCAqIGRldmljZSBpbmZvIHJlc3BvbnNlLiBSZXR1cm5zIHRoZSBEZXZpY2VJbmZvIGlmIHRoZSBkZXZpY2UgcmVzcG9uZHMgd2l0aGluXG5cdCAqIHRpbWVvdXRNcywgb3IgbnVsbCBpZiBubyByZXNwb25zZS4gVXNlZCB0byB2ZXJpZnkgYSBtYW51YWxseSBjb25maWd1cmVkIElQLlxuXHQgKiBEb2VzIE5PVCByZXF1aXJlIGF1dGhvcml6YXRpb24gXHUyMDE0IHRoaXMgaXMgaG93IGF1dGhvcml6YXRpb24gaXMgZXN0YWJsaXNoZWQuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcHJvYmVEZXZpY2UoaXA6IHN0cmluZywgdGltZW91dE1zID0gMzAwMCk6IFByb21pc2U8RGV2aWNlSW5mbyB8IG51bGw+IHtcblx0XHRyZXR1cm4gbmV3IFByb21pc2U8RGV2aWNlSW5mbyB8IG51bGw+KChyZXNvbHZlKSA9PiB7XG5cdFx0XHRjb25zdCBrZXkgPSBgX19wcm9iZV8ke2lwfV9fYFxuXHRcdFx0bGV0IHJlc29sdmVkID0gZmFsc2VcblxuXHRcdFx0Y29uc3QgZmluaXNoID0gKHJlc3VsdDogRGV2aWNlSW5mbyB8IG51bGwpID0+IHtcblx0XHRcdFx0aWYgKHJlc29sdmVkKSByZXR1cm5cblx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHJlc29sdmUocmVzdWx0KVxuXHRcdFx0fVxuXG5cdFx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5zZXQoa2V5LCAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB7XG5cdFx0XHRcdGlmIChkZXZpY2UuaXAgPT09IGlwKSBmaW5pc2goZGV2aWNlKVxuXHRcdFx0fSlcblxuXHRcdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IGZpbmlzaChudWxsKSwgdGltZW91dE1zKVxuXHRcdFx0dGltZXIudW5yZWY/LigpXG5cblx0XHRcdGNvbnN0IHJ1biA9IGFzeW5jICgpID0+IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGlwKVxuXHRcdFx0XHRhd2FpdCB0aGlzLnR4UmVhZHlcblx0XHRcdFx0Y29uc3QgcXVlcnkgPSBidWlsZERhbnRlSW5mb1JlcXVlc3QoKVxuXHRcdFx0XHR0aGlzLnR4U29ja2V0LnNlbmQocXVlcnksIHRoaXMuZGVmYXVsdFBvcnQsIGlwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYFByb2JlIHRvICR7aXB9IGZhaWxlZDogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdFx0ZmluaXNoKG51bGwpXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KVxuXHRcdFx0fVxuXG5cdFx0XHRydW4oKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0XHRsb2dnZXIud2FybihgcHJvYmVEZXZpY2Ugc2V0dXAgZmFpbGVkIGZvciAke2lwfTogJHtlfWApXG5cdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0ZmluaXNoKG51bGwpXG5cdFx0XHR9KVxuXHRcdH0pXG5cdH1cblxuXHQvKipcblx0ICogU2VuZCBhIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSByZXF1ZXN0IHRvIHRoZSBkZXZpY2UgYW5kIHN0b3JlIHRoZSByZXNwb25zZVxuXHQgKiBpbiBkZXZpY2VTdGF0ZS4gUmV0dXJucyB0aGUgcmF3IHJlc3BvbnNlIGJ1ZmZlciBmb3IgcGFyc2luZy5cblx0ICovXG5cdHB1YmxpYyBhc3luYyByZXF1ZXN0QWxsU2V0dGluZ3MoZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgYWxsIHNldHRpbmdzIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soQ01EX0dFVF9BTExfU0VUVElOR1MsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRldmljZUlwLCBmYWxzZSlcblx0XHQvLyBkZXZpY2VTdGF0ZSBpcyBwb3B1bGF0ZWQgYnkgbG9nU3RQYXlsb2FkIHdoZW4gdGhlIENNRF9HRVRfQUxMX1NFVFRJTkdTIHJlc3BvbnNlIGFycml2ZXNcblx0XHRyZXR1cm4gcmVzcG9uc2Vcblx0fVxuXG5cdC8qKlxuXHQgKiBEaXNjb3ZlcnMgU3R1ZGlvIFRlY2hub2xvZ2llcyBEYW50ZSBkZXZpY2VzIG9uIHRoZSBsb2NhbCBuZXR3b3JrLlxuXHQgKlxuXHQgKiBTdHJhdGVneTpcblx0ICogIERhbnRlIGRldmljZXMgYnJvYWRjYXN0IGEgMS1zZWNvbmQgYW5ub3VuY2UgdG8gbXVsdGljYXN0IDIyNC4wLjAuMjMzOjg3MDguXG5cdCAqICBXZSBsaXN0ZW4gb24gdGhhdCBncm91cCwgY29sbGVjdCBzb3VyY2UgSVBzLCB0aGVuIHNlbmQgYSB1bmljYXN0IGRldmljZSBpbmZvXG5cdCAqICByZXF1ZXN0ICgweDAwMjApIHRvIGVhY2ggbmV3IElQIG9uIHBvcnQgODcwMC4gVGhlIGRldmljZSByZXNwb25kcyB0byBvdXIgSVBcblx0ICogIG9uIHBvcnQgODcwMiAocnhTb2NrZXQpLCB3aGVyZSBoYW5kbGVJbmNvbWluZygpIHBpY2tzIGl0IHVwIGFuZCBmaXJlcyB0aGVcblx0ICogIGRpc2NvdmVyeUxpc3RlbmVycyBjYWxsYmFjay5cblx0ICovXG5cdHB1YmxpYyBhc3luYyBkaXNjb3ZlckRldmljZXModGltZW91dE1zID0gNTAwMCk6IFByb21pc2U8RGV2aWNlSW5mb1tdPiB7XG5cdFx0Ly8gUmVnaXN0ZXIgbGlzdGVuZXIgXHUyMDE0IGhhbmRsZUluY29taW5nKCkgZmlyZXMgdGhpcyBmb3IgZWFjaCAweDAxNzAgcmVzcG9uc2Vcblx0XHRjb25zdCBESVNDT1ZFUllfS0VZID0gJ19fZGlzY292ZXJ5X18nXG5cdFx0Y29uc3QgZm91bmREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXVxuXG5cdFx0Y29uc3Qgb25EZXZpY2VGb3VuZCA9IChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdGlmICghZm91bmREZXZpY2VzLnNvbWUoKGQpID0+IGQuaXAgPT09IGRldmljZS5pcCkpIHtcblx0XHRcdFx0Zm91bmREZXZpY2VzLnB1c2goZGV2aWNlKVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIFJlZ2lzdGVyIHRoZSBjYWxsYmFjayBzbyBoYW5kbGVJbmNvbWluZygpIGNhbiBpbnZva2UgaXQgd2hlbiAweDAxNzAgYXJyaXZlc1xuXHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChESVNDT1ZFUllfS0VZLCBvbkRldmljZUZvdW5kKVxuXG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHRoaXMudHhSZWFkeVxuXHRcdFx0Ly8gZGlzY292ZXJEZXZpY2VzKCkgaW4gZGFudGUudHMgaGFuZGxlcyB0aGUgYW5ub3VuY2UgbGlzdGVuaW5nIGFuZCBxdWVyeSBzZW5kaW5nLlxuXHRcdFx0Ly8gUmVzcG9uc2VzIGNvbWUgYmFjayB0byByeFNvY2tldCBcdTIxOTIgaGFuZGxlSW5jb21pbmcoKSBcdTIxOTIgZGlzY292ZXJ5TGlzdGVuZXJzLlxuXHRcdFx0YXdhaXQgZGlzY292ZXJEZXZpY2VzKHRoaXMudHhTb2NrZXQsIGFzeW5jIChkZXN0SXApID0+IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApLCB0aW1lb3V0TXMpXG5cdFx0XHRyZXR1cm4gZm91bmREZXZpY2VzXG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLmRlbGV0ZShESVNDT1ZFUllfS0VZKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBSZXF1ZXN0cyBkZXZpY2UgZmlybXdhcmUgdmVyc2lvbiB2aWEgU3R1ZGlvLVQgcHJvdG9jb2wgKENNRF9HRVRfRklSTVdBUkUpLlxuXHQgKiBSZXR1cm5zIHRoZSBmaXJtd2FyZSB2ZXJzaW9uIHN0cmluZyAoZS5nLiwgXCIzLjAxXCIsIFwiMi4yXCIsIFwiMS4wNVwiKS5cblx0ICovXG5cdHB1YmxpYyBhc3luYyByZXF1ZXN0RmlybXdhcmVWZXJzaW9uKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRcdGxvZ2dlci5pbmZvKGBSZXF1ZXN0aW5nIGZpcm13YXJlIHZlcnNpb24gZnJvbSAke2RldmljZUlwfWApXG5cdFx0Y29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0VUX0ZJUk1XQVJFLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXZpY2VJcCwgZmFsc2UpXG5cblx0XHQvLyBSZXNwb25zZSBzdHJ1Y3R1cmU6IFtoZWFkZXJdIDB4NWEgMHg4MCBbZmlybXdhcmVfZGF0YV0gQ1JDXG5cdFx0Ly8gRmlybXdhcmUgZGF0YSBzdGFydHMgYXQgYnl0ZSAyNiAoMjQtYnl0ZSBoZWFkZXIgKyAweDVhICsgMHg4MClcblx0XHRjb25zdCBkYXRhU3RhcnQgPSAyNlxuXG5cdFx0aWYgKHJlc3BvbnNlLmxlbmd0aCA8IGRhdGFTdGFydCArIDMpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBGaXJtd2FyZSByZXNwb25zZSB0b28gc2hvcnQ6ICR7cmVzcG9uc2UubGVuZ3RofSBieXRlc2ApXG5cdFx0XHRyZXR1cm4gJ1Vua25vd24nXG5cdFx0fVxuXG5cdFx0Ly8gRmlybXdhcmUgZm9ybWF0OiBbdW5rbm93bl9ieXRlLCBtYWpvciwgbWlub3JdXG5cdFx0Y29uc3QgbWFqb3IgPSByZXNwb25zZVtkYXRhU3RhcnQgKyAxXVxuXHRcdGNvbnN0IG1pbm9yID0gcmVzcG9uc2VbZGF0YVN0YXJ0ICsgMl1cblxuXHRcdGNvbnN0IG1pbm9yU3RyID1cblx0XHRcdG1pbm9yIDwgMTBcblx0XHRcdFx0PyBtaW5vci50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJykgLy8gZS5nLiAxIFx1MjE5MiBcIjAxXCIsIDUgXHUyMTkyIFwiMDVcIlxuXHRcdFx0XHQ6IG1pbm9yLnRvU3RyaW5nKCkgLy8gZS5nLiAxMCBcdTIxOTIgXCIxMFwiXG5cblx0XHRjb25zdCBmaXJtd2FyZSA9IGAke21ham9yfS4ke21pbm9yU3RyfWBcblxuXHRcdGxvZ2dlci5pbmZvKGBGaXJtd2FyZSB2ZXJzaW9uOiAke2Zpcm13YXJlfWApXG5cdFx0cmV0dXJuIGZpcm13YXJlXG5cdH1cblxuXHQvKipcblx0ICogSm9pbnMgdGhlIG11bHRpY2FzdCByZXNwb25zZSBncm91cCBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIGRlc3RJcC5cblx0ICogT25seSBqb2lucyB0aGUgc3BlY2lmaWMgaW50ZXJmYWNlIHVzZWQgdG8gcmVhY2ggdGhlIGRldmljZSwgYW5kIG9ubHkgb25jZSBwZXIgaW50ZXJmYWNlLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBlbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGF3YWl0IGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblx0XHRcdGlmICghbG9jYWxBZGRyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgZGV0ZXJtaW5lIGxvY2FsIGFkZHJlc3MgZm9yIGRlc3RpbmF0aW9uICR7ZGVzdElwfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAodGhpcy5qb2luZWRJbnRlcmZhY2VzLmhhcyhsb2NhbEFkZHIpKSB7XG5cdFx0XHRcdC8vIGFscmVhZHkgam9pbmVkXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLnJ4U29ja2V0LmFkZE1lbWJlcnNoaXAodGhpcy5tdWx0aWNhc3RHcm91cCwgbG9jYWxBZGRyKVxuXHRcdFx0XHR0aGlzLmpvaW5lZEludGVyZmFjZXMuYWRkKGxvY2FsQWRkcilcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEpvaW5lZCBtdWx0aWNhc3QgJHt0aGlzLm11bHRpY2FzdEdyb3VwfSBvbiAke2xvY2FsQWRkcn1gKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBqb2luIG11bHRpY2FzdCBvbiAke2xvY2FsQWRkcn06ICR7U3RyaW5nKF9lKX1gKVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRsb2dnZXIud2FybihgZW5zdXJlTWVtYmVyc2hpcEZvciBmYWlsZWQ6ICR7X2V9YClcblx0XHR9XG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgc2VuZEF3YWl0QWNrKFxuXHRcdGNtZElkOiBudW1iZXIsXG5cdFx0YnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHRzZXR0aW5nSWQ6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHR2YWx1ZTogdW5rbm93bixcblx0XHRkZXN0SXA6IHN0cmluZyxcblx0XHRhZGRMZW4gPSB0cnVlLFxuXHQpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudCsrXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPEJ1ZmZlcj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0dGhpcy5zZW5kUXVldWUgPSB0aGlzLnNlbmRRdWV1ZS50aGVuKGFzeW5jICgpID0+XG5cdFx0XHRcdHRoaXMuX3NlbmRBd2FpdEFjayhjbWRJZCwgYnVzQ2gsIHNldHRpbmdJZCwgdmFsdWUsIGRlc3RJcCwgYWRkTGVuKVxuXHRcdFx0XHRcdC50aGVuKChidWYpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHQvLyBPbmx5IHRyaWdnZXIgcmVxdWVzdEFsbFNldHRpbmdzIGFmdGVyIGEgd3JpdGUgKFNFVCkgY29tbWFuZCwgbm90IGEgcmVhZC9wb2xsLlxuXHRcdFx0XHRcdFx0Ly8gQSB3cml0ZSBhbHdheXMgaGFzIGEgdmFsdWU7IHJlYWRzIChHRVQsIEJVU19HRVQpIG5ldmVyIGRvLlxuXHRcdFx0XHRcdFx0aWYgKHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudCA9PT0gMCAmJiB0aGlzLnJlZnJlc2hBZnRlckNvbW1hbmQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdFx0XHR0aGlzLnJlcXVlc3RBbGxTZXR0aW5ncyhkZXN0SXApLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0LmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHRyZWplY3QoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIgOiBuZXcgRXJyb3IoU3RyaW5nKGVycikpKVxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIF9zZW5kQXdhaXRBY2soXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0Y29uc3QgdGltZW91dE1zID0gMjAwMFxuXG5cdFx0Ly8gUmVqZWN0IGNvbW1hbmRzIHRvIHVudmVyaWZpZWQgZGV2aWNlcy4gcHJvYmVEZXZpY2UoKSBieXBhc3NlcyB0aGlzXG5cdFx0Ly8gYmVjYXVzZSBpdCB1c2VzIHRoZSBEYW50ZSBwcm90b2NvbCBkaXJlY3RseSB2aWEgdHhTb2NrZXQsIG5vdCBzZW5kQXdhaXRBY2suXG5cdFx0aWYgKCF0aGlzLmF1dGhvcml6ZWRJcHMuaGFzKGRlc3RJcCkpIHtcblx0XHRcdHRocm93IG5ldyBFcnJvcihgRGV2aWNlIGF0ICR7ZGVzdElwfSBpcyBub3QgYXV0aG9yaXplZCBcdTIwMTQgdmVyaWZ5IHRoZSBJUCBhbmQgbW9kZWwgbWF0Y2ggYmVmb3JlIHNlbmRpbmcgY29tbWFuZHNgKVxuXHRcdH1cblxuXHRcdC8vIEVuc3VyZSB3ZSBhcmUgbGlzdGVuaW5nIGZvciByZXBsaWVzIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCB3aWxsIHJlY2VpdmUgdGhlbVxuXHRcdGF3YWl0IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApXG5cblx0XHRjb25zdCBkYXRhQmxvY2s6IG51bWJlcltdID0gW11cblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKHNldHRpbmdJZCAmIDB4ZmYpXG5cdFx0aWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKC4uLlN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpKVxuXG5cdFx0Y29uc3QgcGF5bG9hZEJvZHk6IG51bWJlcltdID0gWzB4NWEsIGNtZElkICYgMHhmZl1cblxuXHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBwYXlsb2FkQm9keS5wdXNoKGJ1c0NoICYgMHhmZilcblx0XHRpZiAoYWRkTGVuKSBwYXlsb2FkQm9keS5wdXNoKGRhdGFCbG9jay5sZW5ndGgpXG5cblx0XHRpZiAoZGF0YUJsb2NrLmxlbmd0aCA+IDApIHBheWxvYWRCb2R5LnB1c2goLi4uZGF0YUJsb2NrKVxuXG5cdFx0Y29uc3QgY3JjID0gU3RDb250cm9sbGVyLmNyYzhEdmJTMihwYXlsb2FkQm9keSlcblx0XHRjb25zdCBwYXlsb2FkV2l0aENyYyA9IEJ1ZmZlci5mcm9tKFsuLi5wYXlsb2FkQm9keSwgY3JjXSlcblxuXHRcdGNvbnN0IHRvdGFsTGVuID0gMjQgKyBwYXlsb2FkV2l0aENyYy5sZW5ndGhcblx0XHRjb25zdCBoZWFkZXIgPSBhd2FpdCB0aGlzLmJ1aWxkSGVhZGVyKHRvdGFsTGVuLCBkZXN0SXApXG5cdFx0Y29uc3QgcGFja2V0ID0gQnVmZmVyLmNvbmNhdChbaGVhZGVyLCBwYXlsb2FkV2l0aENyY10pXG5cblx0XHQvLyBIdW1hbi1yZWFkYWJsZSBpbmZvIGxvZyBmb3IgdGhlIG91dGdvaW5nIGNvbW1hbmRcblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IFN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IGNtZElkLFxuXHRcdFx0XHRpZDogc2V0dGluZ0lkLFxuXHRcdFx0XHRidXNDaCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKGBUWCAke2Rlc3RJcH0gfCAke2Zvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZywgdGhpcy5hY3Rpb25zKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtnZXRDb21tYW5kTmFtZShjbWRJZCl9YClcblx0XHR9XG5cdFx0bG9nZ2VyLmRlYnVnKGBTZW5kaW5nIHBhY2tldCB0byAke2Rlc3RJcH06ICR7cGFja2V0LnRvU3RyaW5nKCdoZXgnKX1gKVxuXG5cdFx0Y29uc3Qga2V5ID0gYCR7ZGVzdElwfToke2NtZElkfWBcblxuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgVGltZW91dCB3YWl0aW5nIGZvciBBQ0sgZnJvbSBNb2RlbCAke3RoaXMubW9kZWx9IGF0ICR7ZGVzdElwfTo4NzAwYCkpXG5cdFx0XHR9LCB0aW1lb3V0TXMpXG5cblx0XHRcdHRoaXMucGVuZGluZ0Fja3Muc2V0KGtleSwge1xuXHRcdFx0XHRyZXNvbHZlOiAoYnVmKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHRyZWplY3Q6IChlcnIpID0+IHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KGVycilcblx0XHRcdFx0fSxcblx0XHRcdFx0dGltZXIsXG5cdFx0XHR9KVxuXG5cdFx0XHR0aGlzLnR4U29ja2V0LnNlbmQocGFja2V0LCB0aGlzLmRlZmF1bHRQb3J0LCBkZXN0SXAsIChlcnIpID0+IHtcblx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgaGFuZGxlSW5jb21pbmcobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpIHtcblx0XHRpZiAobXNnLmxlbmd0aCA8IDQpIHJldHVyblxuXHRcdGlmIChtc2dbMF0gIT09IDB4ZmYgfHwgbXNnWzFdICE9PSAweGZmKSByZXR1cm5cblxuXHRcdGNvbnN0IG1zZ1R5cGUgPSBtc2cucmVhZFVJbnQxNkJFKDIpXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgKDB4MDE3MCkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gVGhlc2UgaGF2ZSBcIkF1ZGluYXRlXCIgYXQgb2Zmc2V0IDE2LCBub3QgXCJTdHVkaW8tVFwiIFx1MjAxNCBoYW5kbGUgYmVmb3JlXG5cdFx0Ly8gdGhlIFN0dWRpby1UIHNpZ25hdHVyZSBjaGVjayBiZWxvdy5cblx0XHRpZiAobXNnVHlwZSA9PT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgJiYgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2l6ZSA+IDApIHtcblx0XHRcdGNvbnN0IGRldmljZSA9IHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnLCBzcmNJcClcblx0XHRcdGlmIChkZXZpY2UpIHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKFxuXHRcdFx0XHRcdGBEYW50ZSBpbmZvIHJlc3BvbnNlIGZyb20gJHtzcmNJcH06IGAgK1xuXHRcdFx0XHRcdFx0YERldmljZUlEPVwiJHtkZXZpY2UubmFtZX1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTW9kZWw9XCIke2RldmljZS5tb2RlbH1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTW9kZWxOYW1lPVwiJHtkZXZpY2UubW9kZWxOYW1lfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNYW51ZmFjdHVyZXI9XCIke2RldmljZS5tYW51ZmFjdHVyZXJ9XCJgLFxuXHRcdFx0XHQpXG5cblx0XHRcdFx0Ly8gT25seSBhY2NlcHQgU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2VzIChpZGVudGlmaWVkIGJ5IERldmljZUlEIFwiU3R1ZGlvLVRcIilcblx0XHRcdFx0aWYgKGRldmljZS5uYW1lID09PSAnU3R1ZGlvLVQnKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjYiBvZiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy52YWx1ZXMoKSkge1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0Y2IoZGV2aWNlKVxuXHRcdFx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYElnbm9yaW5nIG5vbi1TdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZTogRGV2aWNlSUQ9XCIke2RldmljZS5uYW1lfVwiIEAgJHtzcmNJcH1gKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAobXNnLmxlbmd0aCA8IDI1KSByZXR1cm5cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBTdHVkaW8tVCBjb250cm9sIHByb3RvY29sIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGNvbnN0IHNpZyA9IG1zZy5zdWJhcnJheSgxNiwgMjQpXG5cdFx0aWYgKHNpZy50b1N0cmluZygnYXNjaWknKSAhPT0gJ1N0dWRpby1UJykgcmV0dXJuXG5cblx0XHQvLyBQYXlsb2FkIHN0YXJ0cyBhdCBvZmZzZXQgMjRcblx0XHQvLyBMYXlvdXQ6IFsweDVhXSBbY21kSWR8MHg4MF0gW2RhdGEuLi5dIFtjcmNdXG5cdFx0Y29uc3Qgc3RQYXlsb2FkID0gbXNnLnN1YmFycmF5KDI0KVxuXHRcdGlmIChzdFBheWxvYWQubGVuZ3RoIDwgMikgcmV0dXJuXG5cdFx0aWYgKHN0UGF5bG9hZFswXSAhPT0gMHg1YSkgcmV0dXJuXG5cblx0XHQvLyBEZXZpY2UgcmVwbGllcyB3aXRoIGNtZCB8IDB4ODBcblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBpc1Jlc3BvbnNlID0gKHJlc3BDbWRJZCAmIDB4ODApICE9PSAwXG5cdFx0Y29uc3Qgb3JpZ2luYWxDbWRJZCA9IHJlc3BDbWRJZCAmIDB4N2YgLy8gc3RyaXAgdGhlIHJlc3BvbnNlIGZsYWdcblxuXHRcdC8vIExvZyByYXcgcGFja2V0IGZvciBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgcmVzcG9uc2VzIGJlZm9yZSBwYXJzaW5nXG5cdFx0aWYgKGlzUmVzcG9uc2UgJiYgb3JpZ2luYWxDbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MpIHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUmVjZWl2ZWQgcGFja2V0IGZyb20gJHtzcmNJcH06ICR7bXNnLnRvU3RyaW5nKCdoZXgnKX1gKVxuXHRcdH1cblxuXHRcdC8vIExvZyB0aGUgcGF5bG9hZCAod29ya3MgZm9yIGJvdGggcmVxdWVzdHMgYW5kIHJlc3BvbnNlcylcblx0XHR0aGlzLmxvZ1N0UGF5bG9hZChzcmNJcCwgb3JpZ2luYWxDbWRJZCwgbXNnLCBzdFBheWxvYWQpXG5cblx0XHQvLyBPbmx5IHByb2Nlc3MgYXMgQUNLIGlmIHRoaXMgaXMgYSByZXNwb25zZSB0byBvdXIgcmVxdWVzdFxuXHRcdGlmIChpc1Jlc3BvbnNlKSB7XG5cdFx0XHRjb25zdCBrZXkgPSBgJHtzcmNJcH06JHtvcmlnaW5hbENtZElkfWBcblx0XHRcdGNvbnN0IHBlbmRpbmcgPSB0aGlzLnBlbmRpbmdBY2tzLmdldChrZXkpXG5cdFx0XHRpZiAocGVuZGluZykge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHBlbmRpbmcucmVzb2x2ZShtc2cpXG5cdFx0XHR9XG5cdFx0fVxuXHRcdC8vIFVuc29saWNpdGVkIG1lc3NhZ2VzIGFuZCByZXF1ZXN0cyBmcm9tIG90aGVyIHNvdXJjZXMgYXJlIGxvZ2dlZCBhYm92ZVxuXHR9XG5cblx0LyoqXG5cdCAqIERlY29kZXMgYW5kIGxvZ3MgYSBTdHVkaW8tVCByZXNwb25zZSBwYXlsb2FkLlxuXHQgKiBSZWNlaXZlcyBib3RoIHRoZSBmdWxsIG1zZyAoZm9yIHBhcnNlcnMgdGhhdCBuZWVkIHRoZSBTdHVkaW8tVCBoZWFkZXIpXG5cdCAqIGFuZCBzdFBheWxvYWQgKG1zZy5zdWJhcnJheSgyNCksIGZvciBkaXJlY3QgYnl0ZSBhY2Nlc3MpLlxuXHQgKlxuXHQgKiBzdFBheWxvYWQgbGF5b3V0OlxuXHQgKiAgIFswXSAgICAgIDB4NWEgIG1hZ2ljXG5cdCAqICAgWzFdICAgICAgY21kSWQgfCAweDgwXG5cdCAqICAgWzIuLi0yXSAgZGF0YSBieXRlc1xuXHQgKiAgIFstMV0gICAgIENSQy04L0RWQi1TMlxuXHQgKi9cblx0cHJpdmF0ZSBsb2dTdFBheWxvYWQoc3JjSXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgbXNnOiBCdWZmZXIsIHN0UGF5bG9hZDogQnVmZmVyKTogdm9pZCB7XG5cdFx0Y29uc3QgY21kTmFtZSA9IGdldENvbW1hbmROYW1lKGNtZElkKVxuXHRcdGNvbnN0IGRhdGEgPSBzdFBheWxvYWQuc3ViYXJyYXkoMiwgc3RQYXlsb2FkLmxlbmd0aCAtIDEpIC8vIHN0cmlwIG1hZ2ljK2NtZElkIGhlYWRlciBhbmQgQ1JDXG5cblx0XHQvLyBQYXlsb2FkIHN0cnVjdHVyZTogW2NtZDoweDhkXSBbZGF0YSBieXRlcy4uLl0gW2NyY11cblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBjcmMgPSBzdFBheWxvYWRbc3RQYXlsb2FkLmxlbmd0aCAtIDFdXG5cdFx0Y29uc3QgZnVsbFN0cnVjdHVyZSA9IGBbY21kOiR7dG9IZXgocmVzcENtZElkKX0gZGF0YToke2RhdGEudG9TdHJpbmcoJ2hleCcpfSBjcmM6JHt0b0hleChjcmMpfV1gXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIGFuZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gUGFyc2UgYWxsIHNldHRpbmdzLCBkaWZmIGFnYWluc3QgZGV2aWNlU3RhdGUsIGxvZyBjaGFuZ2VkIGF0IGluZm8gLyB1bmNoYW5nZWQgYXQgZGVidWcsXG5cdFx0Ly8gdGhlbiB1cGRhdGUgZGV2aWNlU3RhdGUuIENNRF9HRVRfQUxMX1NFVFRJTkdTIGFsc28gc2VydmVzIGFzIHRoZSBpbml0aWFsIHN0YXRlIHBvcHVsYXRpb24gb24gY29ubmVjdC5cblx0XHRpZiAoY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTIHx8IGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0aWYgKCF0aGlzLm1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5ncyA9XG5cdFx0XHRcdFx0Y21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIXG5cdFx0XHRcdFx0XHQ/IHBhcnNlU2V0dGluZ3NSZXNwb25zZSh0aGlzLm1vZGVsLCBtc2cpXG5cdFx0XHRcdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCh0aGlzLm1vZGVsLCBtc2cpXG5cblx0XHRcdFx0Y29uc3QgcHJldlN0YXRlID0gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoc3JjSXApID8/IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0XHRcdFx0Y29uc3QgbmV3U3RhdGUgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPihwcmV2U3RhdGUpIC8vIGNvcHkgXHUyMDE0IHVwZGF0ZSBpbiBwbGFjZVxuXG5cdFx0XHRcdGZvciAoY29uc3QgcyBvZiBzZXR0aW5ncykge1xuXHRcdFx0XHRcdGNvbnN0IHN0YXRlS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgcy5pZCwgcy5idXNDaClcblx0XHRcdFx0XHQvLyBGb3IgUkdCIGNvbG9ycyAoMyBieXRlcyksIHBhY2sgaW50byBzaW5nbGUgbnVtYmVyOiAoUiA8PCAxNikgfCAoRyA8PCA4KSB8IEJcblx0XHRcdFx0XHRjb25zdCBuZXdWYWx1ZSA9XG5cdFx0XHRcdFx0XHRzLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHRcdFx0XHRcdD8gKHMudmFsdWVCeXRlc1swXSA8PCAxNikgfCAocy52YWx1ZUJ5dGVzWzFdIDw8IDgpIHwgcy52YWx1ZUJ5dGVzWzJdXG5cdFx0XHRcdFx0XHRcdDogKHMudmFsdWVCeXRlc1swXSA/PyAwKVxuXHRcdFx0XHRcdGNvbnN0IHByZXZWYWx1ZSA9IHByZXZTdGF0ZS5nZXQoc3RhdGVLZXkpXG5cdFx0XHRcdFx0Y29uc3QgY2hhbmdlZCA9IHByZXZWYWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHByZXZWYWx1ZSAhPT0gbmV3VmFsdWVcblxuXHRcdFx0XHRcdG5ld1N0YXRlLnNldChzdGF0ZUtleSwgbmV3VmFsdWUpXG5cblx0XHRcdFx0XHRjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXRQYXJzZWRTZXR0aW5nKHMsIHRoaXMuYWN0aW9ucylcblx0XHRcdFx0XHRpZiAoY2hhbmdlZCkge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmluZm8oYFJYICR7c3JjSXB9IHwgJHtmb3JtYXR0ZWR9YClcblx0XHRcdFx0XHRcdC8vIFRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlIFx1MjAxNCB1c2UgYmFzZSBrZXkgd2l0aG91dCBidXNDaCBzbyBpdCBtYXRjaGVzIHRoZSBmZWVkYmFjayBkZWZpbml0aW9uIElEXG5cdFx0XHRcdFx0XHRpZiAodGhpcy5mZWVkYmFja0NhbGxiYWNrKSB7XG5cdFx0XHRcdFx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0tleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgcy5jbWRfaWQsIHMuaWQpXG5cdFx0XHRcdFx0XHRcdC8vbG9nZ2VyLmRlYnVnKGBUcmlnZ2VyaW5nIGZlZWRiYWNrIHVwZGF0ZSBmb3Iga2V5OiAke2Jhc2VGZWVkYmFja0tleX1gKVxuXHRcdFx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soYmFzZUZlZWRiYWNrS2V5KVxuXHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYGZlZWRiYWNrQ2FsbGJhY2sgbm90IHNldCBcdTIwMTQgc2tpcHBpbmcgZmVlZGJhY2sgdXBkYXRlIGZvciAke3N0YXRlS2V5fWApXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLmRldmljZVN0YXRlLnNldChzcmNJcCwgbmV3U3RhdGUpXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCBwYXJzZSBmYWlsZWQ6ICR7ZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBBbGwgb3RoZXIgY29tbWFuZHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Y29uc3QgZGVjb2RlZCA9IHRoaXMuZGVjb2RlU3REYXRhKGNtZElkLCBkYXRhKVxuXHRcdC8vIENNRF9CVVNfR0VUIChrZWVwYWxpdmUpIGlzIGhpZ2gtZnJlcXVlbmN5IG5vaXNlIFx1MjAxNCBsb2cgYXQgZGVidWcgb25seVxuXHRcdGNvbnN0IGxvZ0ZuID0gY21kSWQgPT09IENNRF9CVVNfR0VUID8gbG9nZ2VyLmRlYnVnLmJpbmQobG9nZ2VyKSA6IGxvZ2dlci5pbmZvLmJpbmQobG9nZ2VyKVxuXHRcdGlmIChkZWNvZGVkKSB7XG5cdFx0XHRsb2dGbihgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfSB8ICR7ZGVjb2RlZH1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dGbihgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEF0dGVtcHRzIHRvIGRlY29kZSB0aGUgZGF0YSBieXRlcyBvZiBhIFN0dWRpby1UIHJlc3BvbnNlIGludG8gYVxuXHQgKiBodW1hbi1yZWFkYWJsZSBzdHJpbmcuIFJldHVybnMgbnVsbCB0byBmYWxsIGJhY2sgdG8gcmF3IGhleC5cblx0ICovXG5cdHByaXZhdGUgZGVjb2RlU3REYXRhKGNtZElkOiBudW1iZXIsIGRhdGE6IEJ1ZmZlcik6IHN0cmluZyB8IG51bGwge1xuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMCkgcmV0dXJuICdBQ0snXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ2hlY2sgZm9yIHNpbmdsZS1ieXRlIHJlc3BvbnNlcyAoQUNLIG9yIGVycm9yKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdGlmIChkYXRhWzBdID09PSAweDAwKSB7XG5cdFx0XHRcdHJldHVybiAnQUNLIG9rJ1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0cmV0dXJuIGBFUlJPUiAke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdH1cblx0XHR9XG5cblx0XHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0RFVl9TUEVDICgweDBkKTogc2luZ2xlLWJ5dGUgQUNLIG9yIGVjaG8gb2YgYXBwbGllZCBzZXR0aW5nIFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gRGV2aWNlIHNlbmRzIHR3byBDTURfREVWX1NQRUMgcGFja2V0cyBpbiByZXNwb25zZSB0byBhIHNldDpcblx0XHRcdC8vICAgMS4gQUNLOiAgW3N0YXR1c10gICAgICAgICAgICAgICAoMSBieXRlLCAweDAwID0gb2spXG5cdFx0XHQvLyAgIDIuIEVjaG86IFtidXNDaF0gW3NldHRpbmdJZF0gW3ZhbHVlLi4uXSAgKGNvbmZpcm1pbmcgd2hhdCB3YXMgYXBwbGllZClcblx0XHRcdGNhc2UgQ01EX0RFVl9TUEVDOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0XHRcdHJldHVybiBkYXRhWzBdID09PSAweDAwID8gJ0FDSyBvaycgOiBgQUNLIGVycj0ke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlcyA9IGFjdGlvbj8ub3B0aW9ucz8uWzBdPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9XG5cdFx0XHRcdFx0XHRjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVN0ciA9IGNob2ljZUxhYmVsID8gYCR7Y2hvaWNlTGFiZWx9ICgke3RvSGV4KHZhbHVlTnVtISl9KWAgOiBieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpXG5cdFx0XHRcdFx0Y29uc3QgcmF3VGFnID0gYFske3RvSGV4KGNtZElkKX0vJHt0b0hleChzZXR0aW5nSWQpfV09JHtieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn0gJHtyYXdUYWd9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBgcmF3OiAke2RhdGEudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9NSUNfUFJFX0JVUyAoMHgxMik6IE11bHRpLWJ5dGUgZWNobyByZXNwb25zZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzoge1xuXHRcdFx0XHQvLyBBbHJlYWR5IGhhbmRsZWQgc2luZ2xlLWJ5dGUgYWJvdmUsIHNvIG11bHRpLWJ5dGUgbXVzdCBiZSBlY2hvXG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfWBcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/PyBgMHgke3ZhbHVlQnl0ZXMudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn1gXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIG51bGxcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEJ1cy1zY29wZWQgZ2V0L3NldCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdGNhc2UgQ01EX0JVU19HRVQ6XG5cdFx0XHRjYXNlIENNRF9CVVNfU0VUOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA8IDIpIHJldHVybiBudWxsXG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRyZXR1cm4gYGNoPSR7YnVzQ2h9IHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfSB2YWx1ZT0ke3ZhbHVlLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdHJldHVybiBudWxsIC8vIGZhbGwgdGhyb3VnaCB0byByYXcgaGV4XG5cdFx0fVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlOiB1bmtub3duKTogbnVtYmVyW10ge1xuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykgcmV0dXJuIFt2YWx1ZSA/IDEgOiAwXVxuXHRcdGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gTnVtYmVyKHYpICYgMHhmZilcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuXHRcdFx0aWYgKHZhbHVlID4gMHhmZikgcmV0dXJuIFsodmFsdWUgPj4gMTYpICYgMHhmZiwgKHZhbHVlID4+IDgpICYgMHhmZiwgdmFsdWUgJiAweGZmXVxuXHRcdFx0cmV0dXJuIFt2YWx1ZSAmIDB4ZmZdXG5cdFx0fVxuXHRcdHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgdmFsdWUgdHlwZSBmb3IgU1Rjb250cm9sbGVyOiAke3ZhbHVlfWApXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIGJ1aWxkSGVhZGVyKHRvdGFsTGVuOiBudW1iZXIsIGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRsZXQgbWFjID0gdGhpcy5tYWNDYWNoZS5nZXQoZGVzdElwKVxuXHRcdGlmICghbWFjKSB7XG5cdFx0XHRtYWMgPSBhd2FpdCBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHR0aGlzLm1hY0NhY2hlLnNldChkZXN0SXAsIG1hYylcblx0XHR9XG5cblx0XHRyZXR1cm4gQnVmZmVyLmNvbmNhdChbXG5cdFx0XHRCdWZmZXIuZnJvbShbMHhmZiwgMHhmZiwgMHgwMCwgdG90YWxMZW4gJiAweGZmLCAweDA3LCAweGUxLCAweDAwLCAweDAwLCAuLi5tYWMsIDB4MDAsIDB4MDBdKSxcblx0XHRcdEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcsICd1dGY4JyksXG5cdFx0XSlcblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGNyYzhEdmJTMihkYXRhOiBudW1iZXJbXSk6IG51bWJlciB7XG5cdFx0bGV0IGNyYyA9IDBcblx0XHRmb3IgKGNvbnN0IGIgb2YgZGF0YSkge1xuXHRcdFx0Y3JjIF49IGJcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgODsgaSsrKSB7XG5cdFx0XHRcdGNyYyA9IChjcmMgJiAweDgwKSAhPT0gMCA/ICgoY3JjIDw8IDEpIF4gMHhkNSkgJiAweGZmIDogKGNyYyA8PCAxKSAmIDB4ZmZcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGNyY1xuXHR9XG5cblx0LyoqXG5cdCAqIFJldHVybnMgdGhlIGN1cnJlbnQga25vd24gdmFsdWUgZm9yIGEgc2V0dGluZyBvbiBhIGRldmljZSwgb3IgdW5kZWZpbmVkIGlmIHVua25vd24uXG5cdCAqIFVzZSBmb3IgZmVlZGJhY2tzIFx1MjAxNCB2YWx1ZSBpcyB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBmcm9tIHRoZSBkZXZpY2UuXG5cdCAqXG5cdCAqIEBwYXJhbSBpcCAgICAgICAgRGV2aWNlIElQIGFkZHJlc3Ncblx0ICogQHBhcmFtIGNtZElkICAgICBDb21tYW5kIElEIChlLmcuIENNRF9ERVZfU1BFQylcblx0ICogQHBhcmFtIHNldHRpbmdJZCBTZXR0aW5nIElEIChlLmcuIDB4MDIgZm9yIENvbnRyb2wgU291cmNlKVxuXHQgKiBAcGFyYW0gYnVzQ2ggICAgIE9wdGlvbmFsIGJ1cy9jaGFubmVsIElEIGZvciBtdWx0aS1jaGFubmVsIGNvbW1hbmRzXG5cdCAqL1xuXHRwdWJsaWMgZ2V0U2V0dGluZ1ZhbHVlKGlwOiBzdHJpbmcsIGNtZElkOiBudW1iZXIsIHNldHRpbmdJZDogbnVtYmVyLCBidXNDaD86IG51bWJlcik6IG51bWJlciB8IHVuZGVmaW5lZCB7XG5cdFx0Y29uc3Qga2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBidXNDaClcblx0XHRyZXR1cm4gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoaXApPy5nZXQoa2V5KVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHJlc2V0RGV2aWNlKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5zZW5kQXdhaXRBY2soQ01EX1JFU0VUX0RFVklDRSwgdW5kZWZpbmVkLCAweDAwLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgZ2xvYmFsTWljS2lsbChkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HTE9CQUxfTUlDX0tJTEwsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdEYW50ZScpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBEYW50ZSBkaXNjb3ZlcnkgY29uc3RhbnRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBtZXNzYWdlIHR5cGUgKHNlbnQgdG8gcG9ydCA4NzAwKSAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX01TR19JTkZPX1JFUVVFU1QgPSAweDAwMjBcbi8qKiBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSBtZXNzYWdlIHR5cGUgKHJlY2VpdmVkIG9uIHBvcnQgODcwMikgKi9cbmV4cG9ydCBjb25zdCBEQU5URV9NU0dfSU5GT19SRVNQT05TRSA9IDB4MDE3MFxuXG4vKipcbiAqIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlIGxheW91dCAoYWxsIG9mZnNldHMgYXJlIGludG8gdGhlIFVEUCBwYXlsb2FkKTpcbiAqICAgMHgwMCAgdWludDE2QkUgIE1hZ2ljICgweGZmZmYpXG4gKiAgIDB4MDIgIHVpbnQxNkJFICBNZXNzYWdlIHR5cGUgKDB4MDE3MClcbiAqICAgMHgwNCAgdWludDE2QkUgIFNlcXVlbmNlIG51bWJlclxuICogICAweDA2ICAyIGJ5dGVzICAgUGFkZGluZ1xuICogICAweDA4ICA4IGJ5dGVzICAgRVVJLTY0IChzb3VyY2UgTUFDIHdpdGggZmY6ZmUgaW5zZXJ0ZWQgbWlkKVxuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIEFTQ0lJIGlkZW50aWZpZXJcbiAqICAgMHgxOCAgMiBieXRlcyAgIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uIChtYWpvciwgbWlub3IpXG4gKiAgIDB4MjAgIDMxIGJ5dGVzICBEZXZpY2UgbmFtZSwgbnVsbC1wYWRkZWQgQVNDSUkgKG1heCAzMSBjaGFycyBwZXIgRGFudGUgc3BlYylcbiAqICAgMHgyZSAgdWludDE2QkUgIFByb2R1Y3QgSURcbiAqICAgMHg0YyAgNjQgYnl0ZXMgIE1hbnVmYWN0dXJlciBzdHJpbmcsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKiAgIDB4Y2MgIDY0IGJ5dGVzICBNb2RlbCBzdHJpbmcsIG51bGwtcGFkZGVkIEFTQ0lJXG4gKi9cbmV4cG9ydCBjb25zdCBEQU5URV9JTkZPX01JTl9MRU4gPSAweGNjICsgNjQgLy8gMjY4IGJ5dGVzIFx1MjAxNCBuZWVkIGZ1bGwgbW9kZWwgZmllbGRcblxuLyoqXG4gKiBCdWlsZHMgYSBEYW50ZSBkZXZpY2UgaW5mbyByZXF1ZXN0IHBhY2tldCAodHlwZSAweDAwMjApLlxuICpcbiAqIFBhY2tldCBsYXlvdXQgKDMyIGJ5dGVzKSBcdTIwMTQgZGVyaXZlZCBmcm9tIGxpdmUgY2FwdHVyZSBhbmFseXNpczpcbiAqICAgMHgwMCAgdWludDE2QkUgIE1hZ2ljICgweGZmZmYpXG4gKiAgIDB4MDIgIHVpbnQxNkJFICBNZXNzYWdlIHR5cGUgKDB4MDAyMCA9IGRldmljZSBpbmZvIHJlcXVlc3QpXG4gKiAgIDB4MDQgIHVpbnQxNkJFICBTZXF1ZW5jZSBudW1iZXIgKHJhbmRvbSlcbiAqICAgMHgwNiAgMiBieXRlcyAgIFBhZGRpbmdcbiAqICAgMHgwOCAgNiBieXRlcyAgIFNvdXJjZSBNQUNcbiAqICAgMHgwZSAgMiBieXRlcyAgIFBhZGRpbmdcbiAqICAgMHgxMCAgOCBieXRlcyAgIFwiQXVkaW5hdGVcIiBBU0NJSSBpZGVudGlmaWVyXG4gKiAgIDB4MTggIDIgYnl0ZXMgICBQcm90b2NvbCB2ZXJzaW9uICgweDA3MzkpXG4gKiAgIDB4MWEgIDIgYnl0ZXMgICBTdWItdHlwZSAoMHgwMGMxKVxuICogICAweDFjICB1aW50MzJCRSAgQ2FwYWJpbGl0eSBtYXNrICgweDAwMGY0MjQwKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnVpbGREYW50ZUluZm9SZXF1ZXN0KCk6IEJ1ZmZlciB7XG5cdGNvbnN0IGJ1ZiA9IEJ1ZmZlci5hbGxvYygzMiwgMClcblx0Y29uc3Qgc2VxID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMHhmZmZmKVxuXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4ZmZmZiwgMClcblx0YnVmLndyaXRlVUludDE2QkUoREFOVEVfTVNHX0lORk9fUkVRVUVTVCwgMilcblx0YnVmLndyaXRlVUludDE2QkUoc2VxLCA0KVxuXG5cdGNvbnN0IG1hYyA9IGdldEZpcnN0TG9jYWxNYWMoKVxuXHRtYWMuY29weShidWYsIDgpXG5cblx0QnVmZmVyLmZyb20oJ0F1ZGluYXRlJywgJ2FzY2lpJykuY29weShidWYsIDE2KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDA3MzksIDI0KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDAwYzEsIDI2KVxuXHRidWYud3JpdGVVSW50MzJCRSgweDAwMGY0MjQwLCAyOClcblxuXHRyZXR1cm4gYnVmXG59XG5cbi8qKiBSZXR1cm5zIHRoZSBmaXJzdCBub24tbG9vcGJhY2sgTUFDIGFzIGEgNi1ieXRlIEJ1ZmZlciwgb3IgemVyb3MuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Rmlyc3RMb2NhbE1hYygpOiBCdWZmZXIge1xuXHR0cnkge1xuXHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMoaWZhY2VzKSkge1xuXHRcdFx0Zm9yIChjb25zdCBhZGRyIG9mIGlmYWNlc1tuYW1lXSA/PyBbXSkge1xuXHRcdFx0XHRpZiAoIWFkZHIuaW50ZXJuYWwgJiYgYWRkci5mYW1pbHkgPT09ICdJUHY0JyAmJiBhZGRyLm1hYyAmJiBhZGRyLm1hYyAhPT0gJzAwOjAwOjAwOjAwOjAwOjAwJykge1xuXHRcdFx0XHRcdHJldHVybiBCdWZmZXIuZnJvbShhZGRyLm1hYy5zcGxpdCgnOicpLm1hcCgoaDogc3RyaW5nKSA9PiBwYXJzZUludChoLCAxNikpKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIHtcblx0XHQvKiBpZ25vcmUgKi9cblx0fVxuXHRyZXR1cm4gQnVmZmVyLmFsbG9jKDYsIDApXG59XG5cbi8qKlxuICogUGFyc2VzIGEgRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgKHR5cGUgMHgwMTcwKSBpbnRvIGEgRGV2aWNlSW5mby5cbiAqXG4gKiBSZXNwb25zZSBsYXlvdXQgKGtleSBvZmZzZXRzKTpcbiAqICAgMHgwOCAgOCBieXRlcyAgIEVVSS02NCBcdTIwMTQgY29udmVydCB0byBNQUMgYnkgZHJvcHBpbmcgYnl0ZXMgWzNdIGFuZCBbNF0gKGZmOmZlKVxuICogICAweDEwICA4IGJ5dGVzICAgXCJBdWRpbmF0ZVwiIGlkZW50aWZpZXIgKHVzZWQgdG8gdmVyaWZ5IHRoaXMgaXMgYSByZWFsIHJlc3BvbnNlKVxuICogICAweDE4ICAxIGJ5dGUgICAgRGFudGUgRlcgbWFqb3JcbiAqICAgMHgxOSAgMSBieXRlICAgIERhbnRlIEZXIG1pbm9yXG4gKiAgIDB4MjAgIDMxIGJ5dGVzICBEZXZpY2UgbmFtZSAoRGFudGUgbGFiZWwpLCBudWxsLXBhZGRlZCBBU0NJSSAobWF4IDMxIGNoYXJzKVxuICogICAweDJlICB1aW50MTZCRSAgUHJvZHVjdCBJRFxuICogICAweDRjICA2NCBieXRlcyAgTWFudWZhY3R1cmVyLCBudWxsLXBhZGRlZCBBU0NJSVxuICogICAweGNjICA2NCBieXRlcyAgTW9kZWwgc3RyaW5nLCBudWxsLXBhZGRlZCBBU0NJSVxuICpcbiAqIFJldHVybnMgbnVsbCBpZiBidWZmZXIgaXMgdG9vIHNob3J0LCB3cm9uZyBtYWdpYywgb3IgbWlzc2luZyBtb2RlbCBzdHJpbmcuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKTogRGV2aWNlSW5mbyB8IG51bGwge1xuXHRpZiAobXNnLmxlbmd0aCA8IERBTlRFX0lORk9fTUlOX0xFTikgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZikgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5yZWFkVUludDE2QkUoMikgIT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVybiBudWxsXG5cblx0Y29uc3QgcmVhZFN0ciA9IChvZmZzZXQ6IG51bWJlciwgbGVuOiBudW1iZXIpOiBzdHJpbmcgPT5cblx0XHRtc2dcblx0XHRcdC5zdWJhcnJheShvZmZzZXQsIG9mZnNldCArIGxlbilcblx0XHRcdC50b1N0cmluZygnYXNjaWknKVxuXHRcdFx0LnNwbGl0KCdcXDAnKVswXVxuXHRcdFx0LnRyaW0oKVxuXG5cdGNvbnN0IGV1aTY0ID0gbXNnLnN1YmFycmF5KDgsIDE2KVxuXHRjb25zdCBtYWNCeXRlcyA9IFtldWk2NFswXSwgZXVpNjRbMV0sIGV1aTY0WzJdLCBldWk2NFs1XSwgZXVpNjRbNl0sIGV1aTY0WzddXVxuXHRjb25zdCBtYWMgPSBtYWNCeXRlcy5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJzonKVxuXG5cdGNvbnN0IG5hbWUgPSByZWFkU3RyKDB4MjAsIDMxKSAvLyBEYW50ZSBkZXZpY2UgbGFiZWwgKGNhbiBiZSB1cCB0byAzMSBjaGFycyBwZXIgRGFudGUgc3BlYylcblx0Y29uc3QgbWFudWZhY3R1cmVyID0gcmVhZFN0cigweDRjLCA2NCkgLy8gZS5nLiBcIlN0dWRpbyBUZWNobm9sb2dpZXMsIEluYy5cIlxuXHRjb25zdCBtb2RlbFJhdyA9IHJlYWRTdHIoMHhjYywgNjQpXG5cdGNvbnN0IGRhbnRlRmlybXdhcmUgPSBgJHttc2dbMHgxOF19LiR7bXNnWzB4MTldfWBcblxuXHRpZiAoIW1vZGVsUmF3KSByZXR1cm4gbnVsbFxuXG5cdC8vIEV4dHJhY3QganVzdCB0aGUgbW9kZWwgbnVtYmVyL2NvZGUgKGUuZy4gXCJNb2RlbCAzOTEgQWxlcnRpbmcgVW5pdFwiIFx1MjE5MiBcIjM5MVwiKVxuXHQvLyBTdHJpcCBcIk1vZGVsIFwiIHByZWZpeCwgdGhlbiB0YWtlIG9ubHkgdGhlIGZpcnN0IHdvcmQgKHRoZSBtb2RlbCBudW1iZXIpXG5cdGNvbnN0IG1vZGVsID0gbW9kZWxSYXdcblx0XHQucmVwbGFjZSgvXk1vZGVsXFxzKy9pLCAnJylcblx0XHQudHJpbSgpXG5cdFx0LnNwbGl0KC9cXHMrLylbMF1cblxuXHRyZXR1cm4ge1xuXHRcdGlwOiBzcmNJcCxcblx0XHRuYW1lLFxuXHRcdG1hbnVmYWN0dXJlcixcblx0XHRtb2RlbCxcblx0XHRtb2RlbE5hbWU6IG1vZGVsUmF3LCAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uXG5cdFx0bWFjLFxuXHRcdGRhbnRlRmlybXdhcmUsXG5cdH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBNQUMgYWRkcmVzcyBieXRlcyBvZiB0aGUgbG9jYWwgaW50ZXJmYWNlIHVzZWQgdG8gcm91dGUgdG8gZGVzdElwLlxuICogVXNlcyBhIHRlbXBvcmFyeSBVRFAgY29ubmVjdCB0byBsZXQgdGhlIE9TIHNlbGVjdCB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlLFxuICogdGhlbiBmaW5kcyB0aGUgbWF0Y2hpbmcgTUFDIGZyb20gb3MubmV0d29ya0ludGVyZmFjZXMoKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hY0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxudW1iZXJbXT4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8bnVtYmVyW10+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCB0bXAgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoJ3VkcDQnKVxuXG5cdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdH0pXG5cblx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cdFx0XHRcdHRtcC5jbG9zZSgpXG5cblx0XHRcdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdFx0XHRmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMoaWZhY2VzKSkge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgaWZhY2Ugb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdFx0XHRpZiAoXG5cdFx0XHRcdFx0XHRcdGlmYWNlLmZhbWlseSA9PT0gJ0lQdjQnICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLmFkZHJlc3MgPT09IGxvY2FsQWRkciAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnXG5cdFx0XHRcdFx0XHQpIHtcblx0XHRcdFx0XHRcdFx0cmV0dXJuIHJlc29sdmUoaWZhY2UubWFjLnNwbGl0KCc6JykubWFwKChiKSA9PiBwYXJzZUludChiLCAxNikgJiAweGZmKSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgTm8gaW50ZXJmYWNlIGZvdW5kIGZvciBsb2NhbCBhZGRyZXNzICR7bG9jYWxBZGRyfWApKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihTdHJpbmcoX2UpKSlcblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGxvY2FsIElQIGFkZHJlc3MgdXNlZCBieSB0aGUgT1MgdG8gcm91dGUgdG8gZGVzdElwLlxuICogVXNlcyBhIHRlbXBvcmFyeSBVRFAgc29ja2V0IGNvbm5lY3QgdG8gbGV0IHRoZSBPUyBzZWxlY3QgdGhlIG91dGdvaW5nIGludGVyZmFjZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPHN0cmluZz4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHQvLyBVc2UgYW4gYXJiaXRyYXJ5IHBvcnQgZm9yIGNvbm5lY3Q7IHdlIG9ubHkgbmVlZCB0aGUga2VybmVsIHRvIGFzc2lnbiBhIGxvY2FsIGFkZHJlc3MuXG5cdFx0dG1wLmNvbm5lY3QoOSwgZGVzdElwLCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGFkZHIuYWRkcmVzc1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZXNvbHZlKGxvY2FsQWRkcilcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihTdHJpbmcoX2UpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogTGlzdGVucyBmb3IgRGFudGUgZGV2aWNlIGFubm91bmNlcyBvbiB0aGUgbG9jYWwgbmV0d29yayBhbmQgc2VuZHMgdW5pY2FzdFxuICogaW5mbyByZXF1ZXN0cyB0byBlYWNoIGRpc2NvdmVyZWQgSVAuIFJlc3BvbnNlcyBhcnJpdmUgb24gdGhlIGNhbGxlcidzIHJ4U29ja2V0XG4gKiB2aWEgaGFuZGxlSW5jb21pbmcoKSBcdTIxOTIgZGlzY292ZXJ5TGlzdGVuZXJzLlxuICpcbiAqIEBwYXJhbSB0eFNvY2tldCAtIFRoZSBzb2NrZXQgdG8gdXNlIGZvciBzZW5kaW5nIGRpc2NvdmVyeSByZXF1ZXN0c1xuICogQHBhcmFtIGVuc3VyZU1lbWJlcnNoaXAgLSBDYWxsYmFjayB0byBlbnN1cmUgbXVsdGljYXN0IG1lbWJlcnNoaXAgYmVmb3JlIHF1ZXJ5aW5nXG4gKiBAcGFyYW0gdGltZW91dE1zIC0gSG93IGxvbmcgdG8gbGlzdGVuIGZvciBhbm5vdW5jZXMgYmVmb3JlIHJlc29sdmluZ1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGlzY292ZXJEZXZpY2VzKFxuXHR0eFNvY2tldDogZGdyYW0uU29ja2V0LFxuXHRlbnN1cmVNZW1iZXJzaGlwOiAoZGVzdElwOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD4sXG5cdHRpbWVvdXRNcyA9IDUwMDAsXG4pOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfR1JPVVAgPSAnMjI0LjAuMC4yMzMnXG5cdGNvbnN0IERBTlRFX0FOTk9VTkNFX1BPUlQgPSA4NzA4XG5cdGNvbnN0IERFRkFVTFRfUE9SVCA9IDg3MDBcblxuXHRjb25zdCBxdWVyaWVkSXBzID0gbmV3IFNldDxzdHJpbmc+KClcblxuXHRyZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcblx0XHRjb25zdCBhbm5vdW5jZVNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cblx0XHRjb25zdCBjbGVhbnVwID0gKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuZHJvcE1lbWJlcnNoaXAoREFOVEVfQU5OT1VOQ0VfR1JPVVApXG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhbm5vdW5jZVNvY2tldC5jbG9zZSgpXG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0XHRyZXNvbHZlKClcblx0XHR9XG5cblx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoY2xlYW51cCwgdGltZW91dE1zKVxuXHRcdHRpbWVyLnVucmVmPy4oKVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEFubm91bmNlIHNvY2tldCBlcnJvcjogJHtlcnIubWVzc2FnZX1gKVxuXHRcdH0pXG5cblx0XHRhbm5vdW5jZVNvY2tldC5vbignbWVzc2FnZScsIChtc2csIHJpbmZvKSA9PiB7XG5cdFx0XHRjb25zdCBzcmNJcCA9IHJpbmZvLmFkZHJlc3Ncblx0XHRcdC8vIFZhbGlkYXRlIGl0J3MgYSBEYW50ZSBhbm5vdW5jZSAobWFnaWMgMHhmZmZlICsgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNilcblx0XHRcdGlmIChtc2cubGVuZ3RoIDwgMjQpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZSkgcmV0dXJuXG5cdFx0XHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVyblxuXG5cdFx0XHRpZiAocXVlcmllZElwcy5oYXMoc3JjSXApKSByZXR1cm5cblx0XHRcdHF1ZXJpZWRJcHMuYWRkKHNyY0lwKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBBbm5vdW5jZSBmcm9tICR7c3JjSXB9IFx1MjAxNCBzZW5kaW5nIHVuaWNhc3QgcXVlcnlgKVxuXG5cdFx0XHQvLyBKb2luIDIyNC4wLjAuMjMxIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gdGhpcyBkZXZpY2UgQkVGT1JFIHNlbmRpbmdcblx0XHRcdC8vIHRoZSBxdWVyeS4gVGhlIGRldmljZSBtdWx0aWNhc3RzIGl0cyAweDAxNzAgcmVzcG9uc2UgdG8gMjI0LjAuMC4yMzE6ODcwMlxuXHRcdFx0Ly8gaW4gYWRkaXRpb24gdG8gdW5pY2FzdGluZyBpdCBcdTIwMTQgcnhTb2NrZXQgbXVzdCBiZSBhIG1lbWJlciB0byByZWNlaXZlIGl0LlxuXHRcdFx0Y29uc3Qgc2VuZFF1ZXJ5ID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRhd2FpdCBlbnN1cmVNZW1iZXJzaGlwKHNyY0lwKVxuXHRcdFx0XHRjb25zdCBxdWVyeSA9IGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpXG5cdFx0XHRcdHR4U29ja2V0LnNlbmQocXVlcnksIERFRkFVTFRfUE9SVCwgc3JjSXAsIChlcnIpID0+IHtcblx0XHRcdFx0XHRpZiAoZXJyKSBsb2dnZXIud2FybihgVW5pY2FzdCBxdWVyeSB0byAke3NyY0lwfSBmYWlsZWQ6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdFx0fSlcblx0XHRcdH1cblx0XHRcdHNlbmRRdWVyeSgpLmNhdGNoKChlcnIpID0+IGxvZ2dlci53YXJuKGBRdWVyeSBzZXR1cCBmYWlsZWQ6ICR7ZXJyfWApKVxuXHRcdH0pXG5cblx0XHRhbm5vdW5jZVNvY2tldC5iaW5kKERBTlRFX0FOTk9VTkNFX1BPUlQsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmFkZE1lbWJlcnNoaXAoREFOVEVfQU5OT1VOQ0VfR1JPVVApXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBMaXN0ZW5pbmcgZm9yIERhbnRlIGFubm91bmNlcyBvbiAke0RBTlRFX0FOTk9VTkNFX0dST1VQfToke0RBTlRFX0FOTk9VTkNFX1BPUlR9YClcblx0XHRcdH0gY2F0Y2ggKGVycikge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGpvaW4gYW5ub3VuY2UgbXVsdGljYXN0IGdyb3VwOiAke2Vycn1gKVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG4iLCAiaW1wb3J0IHtcblx0SW5zdGFuY2VUeXBlcyxcblx0SW5zdGFuY2VCYXNlLFxuXHRJbnN0YW5jZVN0YXR1cyxcblx0U29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkLFxuXHRjcmVhdGVNb2R1bGVMb2dnZXIsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBHZXRDb25maWdGaWVsZHMsIHJlc29sdmVIb3N0LCByZXNvbHZlTW9kZWwsIGdldERldmljZVNjaGVtYSwgdHlwZSBNb2R1bGVDb25maWcgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMsIFVwZGF0ZVZhcmlhYmxlVmFsdWVzIH0gZnJvbSAnLi92YXJpYWJsZXMuanMnXG5pbXBvcnQgeyBVcGdyYWRlU2NyaXB0cyB9IGZyb20gJy4vdXBncmFkZXMuanMnXG5pbXBvcnQgeyBVcGRhdGVBY3Rpb25zIH0gZnJvbSAnLi9hY3Rpb25zLmpzJ1xuaW1wb3J0IHsgVXBkYXRlRmVlZGJhY2tzIH0gZnJvbSAnLi9mZWVkYmFja3MuanMnXG5pbXBvcnQgeyBTdENvbnRyb2xsZXIgfSBmcm9tICcuL3N0Y29udHJvbGxlci5qcydcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignTW9kdWxlSW5zdGFuY2UnKVxuXG5leHBvcnQgdHlwZSBNb2R1bGVUeXBlcyA9IEluc3RhbmNlVHlwZXMgJiB7XG5cdGNvbmZpZzogTW9kdWxlQ29uZmlnXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1vZHVsZUluc3RhbmNlIGV4dGVuZHMgSW5zdGFuY2VCYXNlPE1vZHVsZVR5cGVzPiB7XG5cdGNvbmZpZyE6IE1vZHVsZUNvbmZpZyAvLyBTZXR1cCBpbiBpbml0KClcblx0c3RDb250cm9sbGVyITogU3RDb250cm9sbGVyXG5cblx0LyoqIENhY2hlZCBkaXNjb3ZlcnkgcmVzdWx0cyBcdTIwMTQgcGFzc2VkIGludG8gZ2V0Q29uZmlnRmllbGRzKCkgc28gdGhlIFVJXG5cdCAqICBjYW4gc2hvdyB0aGUgZGlzY292ZXJlZCBkZXZpY2UgZHJvcGRvd24gb24gc3Vic2VxdWVudCBjb25maWcgb3BlbnMuICovXG5cdHByaXZhdGUgZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSA9IFtdXG5cblx0LyoqIEN1cnJlbnRseSBhY3RpdmUgbW9kZWwgXHUyMDE0IHJlc29sdmVkIG9uY2UgaW4gc3luY01vZGVsKCkgYW5kIGNhY2hlZCBoZXJlXG5cdCAqICBzbyBVcGRhdGVBY3Rpb25zLCBVcGRhdGVGZWVkYmFja3MgZXRjLiBkb24ndCBlYWNoIGNhbGwgcmVzb2x2ZU1vZGVsIGluZGVwZW5kZW50bHkuICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmcgPSAnJ1xuXG5cdGNvbnN0cnVjdG9yKGludGVybmFsOiB1bmtub3duKSB7XG5cdFx0c3VwZXIoaW50ZXJuYWwpXG5cdH1cblxuXHRhc3luYyBpbml0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRpZiAoIXRoaXMuc3RDb250cm9sbGVyKSB7XG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlciA9IG5ldyBTdENvbnRyb2xsZXIoKVxuXHRcdH1cblx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW5nLCAnRGlzY292ZXJpbmcgZGV2aWNlcy4uLicpXG5cblx0XHQvLyBXaXJlIGZlZWRiYWNrIGNhbGxiYWNrIHNvIHN0Q29udHJvbGxlciBjYW4gdHJpZ2dlciBmZWVkYmFjayB1cGRhdGVzXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0RmVlZGJhY2tDYWxsYmFjaygoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB7XG5cdFx0XHR0aGlzLmNoZWNrRmVlZGJhY2tzKGZlZWRiYWNrSWQpXG5cdFx0fSlcblxuXHRcdC8vIFN0YXJ0IGRpc2NvdmVyeSBpbiB0aGUgYmFja2dyb3VuZCBcdTIwMTQgYWxsIG1vZGVsIHJlc29sdXRpb24sIHNjaGVtYSBzeW5jLFxuXHRcdC8vIGFuZCBVSSB1cGRhdGVzIGhhcHBlbiBpbnNpZGUgcnVuRGlzY292ZXJ5KCkgb25jZSB0aGUgZGV2aWNlIGxpc3QgaXMga25vd24uXG5cdFx0dGhpcy5ydW5EaXNjb3ZlcnkoKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBEaXNjb3ZlcnkgZmFpbGVkOiAke2V9YClcblx0XHR9KVxuXHR9XG5cblx0LyoqXG5cdCAqIFJ1biBkZXZpY2UgZGlzY292ZXJ5LCB0aGVuIHJlc29sdmUgdGhlIG1vZGVsIGFuZCB1cGRhdGUgYWxsIFVJLlxuXHQgKiAtIElmIGRpc2NvdmVyeSBmaW5kcyBkZXZpY2VzLCByZXNvbHZlTW9kZWwgcGlja3MgZnJvbSB0aG9zZS5cblx0ICogLSBPbmx5IGlmIHRoZSBsaXN0IGlzIGVtcHR5IGRvIHdlIGZhbGwgYmFjayB0byB0aGUgbWFudWFsIGNvbmZpZyBzZWxlY3Rpb24uXG5cdCAqIEFsbCBhY3Rpb25zL2ZlZWRiYWNrcy92YXJpYWJsZXMgYXJlIGJ1aWx0IGFmdGVyIHRoZSBtb2RlbCBpcyBrbm93bi5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgcnVuRGlzY292ZXJ5KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGxvZ2dlci5pbmZvKCdTdGFydGluZyBkZXZpY2UgZGlzY292ZXJ5Li4uJylcblxuXHRcdHRoaXMuZGlzY292ZXJlZERldmljZXMgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5kaXNjb3ZlckRldmljZXMoKVxuXG5cdFx0Ly8gRGV0ZXJtaW5lIGVmZmVjdGl2ZSBtb2RlbCBcdTIwMTQgZnJvbSBkaXNjb3ZlcmVkIGRldmljZXMgZmlyc3QsIG1hbnVhbCBjb25maWcgb25seSBhcyBmYWxsYmFja1xuXHRcdGxldCBlZmZlY3RpdmVNb2RlbDogc3RyaW5nXG5cdFx0aWYgKHRoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHQvLyBJZiBhIHNwZWNpZmljIGRldmljZSBNQUMgd2FzIHNhdmVkIGluIGNvbmZpZywgaXQgd2Fzbid0IGZvdW5kIFx1MjAxNCBzdG9wIGhlcmUuXG5cdFx0XHRpZiAodGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHRcdGNvbnN0IG1vZGVsTGFiZWwgPSB0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbCA/IGBNb2RlbCAke3RoaXMuY29uZmlnLmFjdGl2ZU1vZGVsfSBgIDogJydcblx0XHRcdFx0bG9nZ2VyLndhcm4oYFNhdmVkIGRldmljZSBNQUMgXCIke3RoaXMuY29uZmlnLmRldmljZU1hY31cIiBub3QgZm91bmQgZHVyaW5nIGRpc2NvdmVyeSBcdTIwMTQgc3RvcHBpbmdgKVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSwgYCR7bW9kZWxMYWJlbH1bJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XSBub3QgZm91bmRgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWxcblx0XHRcdGlmICghdGhpcy5jb25maWcuaG9zdCB8fCAhbWFudWFsTW9kZWwpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oJ05vIGRldmljZXMgZGlzY292ZXJlZCBhbmQgbm8gbWFudWFsIElQL21vZGVsIGNvbmZpZ3VyZWQnKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKCdObyBkZXZpY2VzIGRpc2NvdmVyZWQgXHUyMDE0IHdpbGwgcHJvYmUgbWFudWFsIElQIGR1cmluZyBhdXRob3JpemF0aW9uJylcblx0XHRcdGVmZmVjdGl2ZU1vZGVsID0gbWFudWFsTW9kZWxcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYERpc2NvdmVyZWQgJHt0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aH0gZGV2aWNlKHMpOmApXG5cdFx0XHRmb3IgKGNvbnN0IGQgb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtIE1vZGVsICR7ZC5tb2RlbH0gJHtkLm1hbnVmYWN0dXJlciA/PyAnJ30gQCAke2QuaXB9YClcblx0XHRcdH1cblxuXHRcdFx0Ly8gQXV0aG9yaXplIGFsbCBkaXNjb3ZlcmVkIGRldmljZXMgc28gZmlybXdhcmUgcmVxdWVzdHMgY2FuIHByb2NlZWQuXG5cdFx0XHQvLyB2ZXJpZnlBdXRob3JpemF0aW9uIChjYWxsZWQgYmVsb3cpIHdpbGwgcmV2b2tlIGFueSB0aGF0IGRvbid0IG1hdGNoXG5cdFx0XHQvLyB0aGUgY3VycmVudCBjb25maWcgc2VsZWN0aW9uLlxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UoZGV2aWNlLmlwKVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBSZXF1ZXN0IGZpcm13YXJlIHZlcnNpb24gZnJvbSBlYWNoIGRpc2NvdmVyZWQgZGV2aWNlXG5cdFx0XHRmb3IgKGNvbnN0IGRldmljZSBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0Y29uc3QgZmlybXdhcmUgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5yZXF1ZXN0RmlybXdhcmVWZXJzaW9uKGRldmljZS5pcClcblx0XHRcdFx0XHRkZXZpY2UuZmlybXdhcmVNYWluID0gZmlybXdhcmVcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtICR7ZGV2aWNlLmlwfTogRmlybXdhcmUgJHtmaXJtd2FyZX0sIERhbnRlICR7ZGV2aWNlLmRhbnRlRmlybXdhcmV9YClcblx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdGxvZ2dlci53YXJuKGAgIC0gJHtkZXZpY2UuaXB9OiBGYWlsZWQgdG8gZ2V0IGZpcm13YXJlOiAke2V9YClcblx0XHRcdFx0XHRkZXZpY2UuZmlybXdhcmVNYWluID0gJ1Vua25vd24nXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0ZWZmZWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwodGhpcy5jb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cblx0XHRcdC8vIElmIGEgc3BlY2lmaWMgTUFDIHdhcyBzYXZlZCBidXQgaXNuJ3QgaW4gdGhlIGRpc2NvdmVyZWQgbGlzdCwgc3RvcC5cblx0XHRcdGlmICghZWZmZWN0aXZlTW9kZWwgJiYgdGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHRcdGNvbnN0IG1vZGVsTGFiZWwgPSB0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbCA/IGBNb2RlbCAke3RoaXMuY29uZmlnLmFjdGl2ZU1vZGVsfSBgIDogJydcblx0XHRcdFx0bG9nZ2VyLndhcm4oYFNhdmVkIGRldmljZSBNQUMgXCIke3RoaXMuY29uZmlnLmRldmljZU1hY31cIiBub3QgZm91bmQgYW1vbmcgZGlzY292ZXJlZCBkZXZpY2VzIFx1MjAxNCBzdG9wcGluZ2ApXG5cdFx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLCBgJHttb2RlbExhYmVsfVske3RoaXMuY29uZmlnLmRldmljZU1hY31dIG5vdCBmb3VuZGApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIFN5bmMgbW9kZWwgc2NoZW1hIHRvIGNvbnRyb2xsZXJcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIFZlcmlmeSB0aGF0IHRoZSBjdXJyZW50bHkgY29uZmlndXJlZCBob3N0K21vZGVsIGlzIHZhbGlkIG5vdyB0aGF0XG5cdFx0Ly8gZGlzY292ZXJ5IHJlc3VsdHMgYXJlIGtub3duLiBUaGlzIGlzIHRoZSBzYW1lIGNoZWNrIGNvbmZpZ1VwZGF0ZWQgdXNlcy5cblx0XHRjb25zdCB0YXJnZXRIb3N0ID0gdGhpcy5ob3N0XG5cdFx0YXdhaXQgdGhpcy52ZXJpZnlBdXRob3JpemF0aW9uKCcnLCB0YXJnZXRIb3N0KVxuXG5cdFx0Ly8gQnVpbGQgYWxsIFVJIG5vdyB0aGF0IG1vZGVsIGFuZCBhdXRob3JpemF0aW9uIHN0YXRlIGFyZSBrbm93blxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cblx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Paylcblx0XHRsb2dnZXIuaW5mbygnRGV2aWNlIGRpc2NvdmVyeSBjb21wbGV0ZScpXG5cdH1cblxuXHQvLyBXaGVuIG1vZHVsZSBnZXRzIGRlbGV0ZWRcblx0YXN5bmMgZGVzdHJveSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLnN0Q29udHJvbGxlcj8uY2xvc2UoKVxuXHRcdGxvZ2dlci5kZWJ1ZygnZGVzdHJveScpXG5cdH1cblxuXHRhc3luYyBjb25maWdVcGRhdGVkKGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0Y29uc3QgcHJldmlvdXNIb3N0ID0gdGhpcy5ob3N0XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRjb25zdCBlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbChjb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdFx0dGhpcy5zeW5jTW9kZWwoZWZmZWN0aXZlTW9kZWwpXG5cblx0XHQvLyBDbGVhciB2YXJpYWJsZXMgaW1tZWRpYXRlbHkgXHUyMDE0IHRoZSBuZXcgc2VsZWN0aW9uIGlzbid0IGF1dGhvcml6ZWQgeWV0LlxuXHRcdC8vIFRoZXknbGwgYmUgcmVwb3B1bGF0ZWQgYmVsb3cgb25jZSB2ZXJpZnlBdXRob3JpemF0aW9uIGNvbXBsZXRlcy5cblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblxuXHRcdGNvbnN0IG5ld0hvc3QgPSB0aGlzLmhvc3RcblxuXHRcdC8vIFJlLXZlcmlmeSBhdXRob3JpemF0aW9uIG9uIGV2ZXJ5IGNvbmZpZyBjaGFuZ2UgKG1vZGVsIG9yIElQKS5cblx0XHQvLyBUaGlzIGhhbmRsZXMgc3dpdGNoaW5nIGZyb20gYSB2YWxpZCBkZXZpY2UgdG8gYW4gaW52YWxpZCBvbmUgYW5kIGJhY2suXG5cdFx0YXdhaXQgdGhpcy52ZXJpZnlBdXRob3JpemF0aW9uKHByZXZpb3VzSG9zdCwgbmV3SG9zdClcblxuXHRcdC8vIFJlYnVpbGQgVUkgYWZ0ZXIgYXV0aG9yaXphdGlvbiBzdGF0ZSBpcyBzZXR0bGVkXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblx0fVxuXG5cdC8qKlxuXHQgKiBSZS1ldmFsdWF0ZXMgd2hldGhlciB0aGUgY3VycmVudCBjb25maWcgaXMgYXV0aG9yaXplZCB0byBzZW5kIGNvbW1hbmRzLlxuXHQgKlxuXHQgKiBBdXRvIG1vZGUgKGRldmljZU1hYyBzZXQpOlxuXHQgKiAgIC0gRmluZCB0aGUgZGlzY292ZXJlZCBkZXZpY2Ugd2l0aCBtYXRjaGluZyBNQUMgXHUyMTkyIGdldCBpdHMgY3VycmVudCBJUFxuXHQgKiAgIC0gUmV2b2tlIHRoZSBwcmV2aW91cyBJUCwgYXV0aG9yaXplIHRoZSBuZXcgSVBcblx0ICogICAtIElmIE1BQyBub3QgZm91bmQgaW4gZGlzY292ZXJ5LCByZXZva2UgYW5kIGJsb2NrXG5cdCAqXG5cdCAqIE1hbnVhbCBtb2RlIChkZXZpY2VNYWMgZW1wdHkpOlxuXHQgKiAgIC0gQ2hlY2sgZGlzY292ZXJlZCBsaXN0IGJ5IElQK21vZGVsIG1hdGNoLCBvciBwcm9iZSBkaXJlY3RseVxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyB2ZXJpZnlBdXRob3JpemF0aW9uKHByZXZpb3VzSG9zdDogc3RyaW5nLCBuZXdIb3N0OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRpZiAoIW5ld0hvc3QpIHtcblx0XHRcdGlmIChwcmV2aW91c0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAodGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHQvLyBBdXRvIG1vZGUgXHUyMDE0IG1hdGNoIGJ5IE1BQywgdXNlIHdoYXRldmVyIElQIGRpc2NvdmVyeSBmb3VuZCBpdCBhdFxuXHRcdFx0Y29uc3QgZGV2aWNlID0gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gdGhpcy5jb25maWcuZGV2aWNlTWFjKVxuXHRcdFx0aWYgKCFkZXZpY2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYERldmljZSBNQUMgXCIke3RoaXMuY29uZmlnLmRldmljZU1hY31cIiBub3QgZm91bmQgaW4gY3VycmVudCBkaXNjb3ZlcnkgXHUyMDE0IG5vdCBhdXRob3JpemluZ2ApXG5cdFx0XHRcdGlmIChwcmV2aW91c0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0fVxuXHRcdFx0Y29uc3Qgd2FzQXV0aG9yaXplZCA9IHRoaXMuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChuZXdIb3N0KVxuXHRcdFx0aWYgKCF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0fVxuXHRcdFx0aWYgKG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCB8fCAhd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEoZGV2aWNlLm1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gTWFudWFsIG1vZGUgXHUyMDE0IGNvbmZpZy5ob3N0ICsgY29uZmlnLmFjdGl2ZU1vZGVsIG11c3QgbWF0Y2hcblx0XHRjb25zdCBtYW51YWxNb2RlbCA9IFN0cmluZyh0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbCA/PyAnJylcblx0XHRjb25zdCBkaXNjb3ZlcmVkQXRJcCA9IHRoaXMuZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gbmV3SG9zdClcblxuXHRcdGlmIChkaXNjb3ZlcmVkQXRJcCkge1xuXHRcdFx0aWYgKGRpc2NvdmVyZWRBdElwLm1vZGVsID09PSBtYW51YWxNb2RlbCkge1xuXHRcdFx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdFx0Y29uc3Qgd2FzQXV0aG9yaXplZCA9IHRoaXMuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChuZXdIb3N0KVxuXHRcdFx0XHRpZiAoIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAobmV3SG9zdCAhPT0gcHJldmlvdXNIb3N0IHx8ICF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1hbnVhbE1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtkaXNjb3ZlcmVkQXRJcC5tb2RlbH0pIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgLFxuXHRcdFx0XHQpXG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhcblx0XHRcdFx0XHRJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSxcblx0XHRcdFx0XHRgTW9kZWwgbWlzbWF0Y2g6IGV4cGVjdGVkICR7bWFudWFsTW9kZWx9LCBnb3QgJHtkaXNjb3ZlcmVkQXRJcC5tb2RlbH1gLFxuXHRcdFx0XHQpXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBJUCBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iZSBpdCBkaXJlY3RseSB2aWEgRGFudGVcblx0XHRsb2dnZXIuaW5mbyhgJHtuZXdIb3N0fSBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iaW5nYClcblx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UobmV3SG9zdClcblxuXHRcdGNvbnN0IHByb2JlZCA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnByb2JlRGV2aWNlKG5ld0hvc3QpXG5cdFx0aWYgKCFwcm9iZWQpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihgTm8gZGV2aWNlIHJlc3BvbmRlZCBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYClcblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLlVua25vd25XYXJuaW5nLCBgRGV2aWNlIG9mZmxpbmU6ICR7bmV3SG9zdH1gKVxuXHRcdH0gZWxzZSBpZiAocHJvYmVkLm1vZGVsICE9PSBtYW51YWxNb2RlbCkge1xuXHRcdFx0bG9nZ2VyLmVycm9yKFxuXHRcdFx0XHRgRGV2aWNlIHNlbGVjdGVkIChNb2RlbCAke21hbnVhbE1vZGVsfSkgZG9lcyBub3QgbWF0Y2ggZGV0ZWN0ZWQgZGV2aWNlIChNb2RlbCAke3Byb2JlZC5tb2RlbH0pIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgLFxuXHRcdFx0KVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoXG5cdFx0XHRcdEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLFxuXHRcdFx0XHRgTW9kZWwgbWlzbWF0Y2g6IGV4cGVjdGVkICR7bWFudWFsTW9kZWx9LCBnb3QgJHtwcm9iZWQubW9kZWx9YCxcblx0XHRcdClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFZlcmlmaWVkIE1vZGVsICR7cHJvYmVkLm1vZGVsfSBhdCAke25ld0hvc3R9YClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1hbnVhbE1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEZldGNoZXMgYWxsIHNldHRpbmdzIGZyb20gdGhlIGRldmljZS4gSWYgbm8gc2NoZW1hIGV4aXN0cyBmb3IgdGhlIG1vZGVsLFxuXHQgKiBjcmVhdGVzIG9uZSBmcm9tIHRoZSByZXNwb25zZSBhbmQgcmVsb2FkcyB0aGUgc2NoZW1hIGNhY2hlLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBmZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1vZGVsOiBzdHJpbmcsIGlwOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKGlwKVxuXG5cdFx0XHRpZiAoIWdldERldmljZVNjaGVtYShtb2RlbCkpIHtcblx0XHRcdFx0Ly8gTm8gc2NoZW1hIGV4aXN0cyBcdTIwMTQgZG8gTk9UIGF1dG8tY3JlYXRlIG9uZSBoZXJlLlxuXHRcdFx0XHQvLyBUaGUgdXNlciBtdXN0IHJ1biBcIkdMT0JBTDogR2V0IEFsbCBTZXR0aW5nc1wiIHRvIGNyZWF0ZSBpdC5cblx0XHRcdFx0bG9nZ2VyLndhcm4oYE5vIHNjaGVtYSBmb3VuZCBmb3IgTW9kZWwgJHttb2RlbH0gXHUyMDE0IHJ1biBcIkdMT0JBTDogR2V0IEFsbCBTZXR0aW5nc1wiIHRvIGNyZWF0ZSBvbmVgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIGZldGNoIHNldHRpbmdzIGZyb20gJHtpcH06ICR7ZX1gKVxuXHRcdH1cblx0fVxuXG5cdC8qKiBMb2FkcyB0aGUgZGV2aWNlIEpTT04gZm9yIHRoZSBnaXZlbiBtb2RlbCwgY2FjaGVzIGl0IGFzIGFjdGl2ZU1vZGVsLCBhbmQgcHVzaGVzIGl0IHRvIHRoZSBjb250cm9sbGVyLiAqL1xuXHRwcml2YXRlIHN5bmNNb2RlbChtb2RlbDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hY3RpdmVNb2RlbCA9IG1vZGVsXG5cdFx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghc2NoZW1hKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTW9kZWwgXCIke21vZGVsfVwiIG5vdCBmb3VuZCBpbiBkZXZpY2Ugc2NoZW1hc2ApXG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRNb2RlbChtb2RlbCwgW10sIHRydWUpXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRjb25zdCBhY3Rpb25zID0gQXJyYXkuaXNBcnJheShzY2hlbWEuY21kU2NoZW1hKSA/IHNjaGVtYS5jbWRTY2hlbWEgOiBbXVxuXHRcdGNvbnN0IHJlZnJlc2hBZnRlckNvbW1hbmQgPSBzY2hlbWEucmVmcmVzaEFmdGVyQ29tbWFuZCA/PyB0cnVlXG5cblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRNb2RlbChtb2RlbCwgYWN0aW9ucywgcmVmcmVzaEFmdGVyQ29tbWFuZClcblx0XHRpZiAoYWN0aW9ucy5sZW5ndGggPT09IDApIHtcblx0XHRcdGxvZ2dlci53YXJuKGBObyBhY3Rpb25zIGZvdW5kIGZvciBtb2RlbCBcIiR7bW9kZWx9XCIgXHUyMDE0IHNldHRpbmdzIGRlY29kaW5nIHdpbGwgdXNlIHJhdyBJRHNgKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdGBMb2FkZWQgJHthY3Rpb25zLmxlbmd0aH0gYWN0aW9ucyBmb3IgbW9kZWwgXCIke21vZGVsfVwiLCBzZWN0aW9uZWQ9JHtzY2hlbWEuc2VjdGlvbmVkfSwgcmVmcmVzaEFmdGVyQ29tbWFuZD0ke3JlZnJlc2hBZnRlckNvbW1hbmR9YCxcblx0XHRcdClcblx0XHR9XG5cdH1cblxuXHRnZXRDb25maWdGaWVsZHMoKTogU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkW10ge1xuXHRcdHJldHVybiBHZXRDb25maWdGaWVsZHModGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0fVxuXG5cdC8qKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgaG9zdCBJUCwgcmVzb2x2ZWQgZnJvbSBNQUNcdTIxOTJJUCB2aWEgZGlzY292ZXJlZERldmljZXMgKGF1dG8pIG9yIGNvbmZpZy5ob3N0IChtYW51YWwpLiAqL1xuXHRnZXQgaG9zdCgpOiBzdHJpbmcge1xuXHRcdHJldHVybiByZXNvbHZlSG9zdCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0fVxuXG5cdC8qKiBSZXR1cm5zIGRpc2NvdmVyZWQgZGV2aWNlcyBmb3IgdXNlIGluIGFjdGlvbnMvY29uZmlnICovXG5cdGdldCBkZXZpY2VzKCk6IERldmljZUluZm9bXSB7XG5cdFx0cmV0dXJuIHRoaXMuZGlzY292ZXJlZERldmljZXNcblx0fVxuXG5cdHVwZGF0ZUFjdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlQWN0aW9ucyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlRmVlZGJhY2tzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZUZlZWRiYWNrcyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZVZhbHVlcygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZVZhbHVlcyh0aGlzKVxuXHR9XG59XG5cbmV4cG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH1cbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7O0FBa0JBLElBQU0scUJBQWtDLENBQUMsUUFBUSxPQUFPLFlBQVc7QUFFbEUsVUFBUSxJQUFJLElBQUksTUFBTSxZQUFXLENBQUUsSUFBSSxTQUFTLEtBQUssTUFBTSxNQUFNLEVBQUUsSUFBSSxPQUFPLEVBQUU7QUFDakY7QUFFQSxTQUFTLFVBQVUsUUFBNEIsT0FBaUIsU0FBZTtBQUM5RSxRQUFNLE9BQU8sT0FBTyxPQUFPLHFCQUFxQixhQUFhLE9BQU8sbUJBQW1CO0FBQ3ZGLE9BQUssUUFBUSxPQUFPLE9BQU87QUFDNUI7QUFPTSxTQUFVLG1CQUFtQixRQUFlO0FBQ2pELFNBQU87SUFDTixPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTztJQUM5RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTzs7QUFFaEU7OztBQ1RNLFNBQVUsWUFBWSxNQUFXO0FBRXZDOzs7QUNoQ0EsU0FBUyxvQkFBb0I7QUEyRXZCLElBQU8sc0JBQVAsY0FBbUMsYUFBbUM7RUFDbEU7RUFDQTtFQUVULElBQVcsV0FBUTtBQUNsQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUNBLElBQVcsYUFBVTtBQUNwQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUVBLElBQVksYUFBVTtBQUNyQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0FBQ25ELGFBQU8sS0FBSztJQUNiLE9BQU87QUFDTixhQUFPO0lBQ1I7RUFDRDtFQUVBLFNBQXVFO0VBRXZFLFlBQVksU0FBeUMsU0FBK0I7QUFDbkYsVUFBSztBQUVMLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVcsRUFBRSxHQUFHLFFBQU87RUFDN0I7RUFFQSxLQUFLLE1BQWMsVUFBbUIsVUFBcUI7QUFDMUQsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSx5QkFBeUI7QUFDN0YsWUFBUSxLQUFLLFFBQVE7TUFDcEIsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG9DQUFvQztNQUNyRCxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0seUJBQXlCO01BQzFDLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxtQkFBbUI7TUFDcEMsS0FBSztBQUNKO01BQ0Q7QUFDQyxvQkFBWSxLQUFLLE1BQU07QUFDdkIsY0FBTSxJQUFJLE1BQU0sc0JBQXNCO0lBQ3hDO0FBRUEsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxhQUFhLFFBQVE7QUFFM0MsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixRQUFRLEtBQUssU0FBUztNQUN0QixZQUFZOztLQUVaLEVBQ0EsS0FDQSxDQUFDLGFBQVk7QUFDWixXQUFLLFNBQVMsRUFBRSxZQUFZLE1BQU0sU0FBUTtBQUMxQyxXQUFLLFNBQVMsd0JBQXdCLElBQUksVUFBVSxJQUFJO0FBQ3hELFdBQUssS0FBSyxXQUFXO0lBQ3RCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTO0FBQ2QsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxNQUFNLFVBQXFCO0FBQzFCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7SUFFcEQsT0FBTztBQUNOLGNBQVEsS0FBSyxRQUFRO1FBQ3BCLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0NBQW9DO1FBQ3JELEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQkFBb0I7UUFDckM7QUFDQyxzQkFBWSxLQUFLLE1BQU07QUFDdkIsZ0JBQU0sSUFBSSxNQUFNLHNCQUFzQjtNQUN4QztJQUNEO0FBRUEsVUFBTSxXQUFXLEtBQUssT0FBTztBQUM3QixTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLFNBQVMsUUFBUTtBQUV2QyxTQUFLLFNBQ0gscUJBQXFCO01BQ3JCO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssT0FBTztJQUNsQixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBV0EsS0FDQyxjQUNBLGNBQ0EsaUJBQ0EsZ0JBQ0EsU0FDQSxVQUFxQjtBQUVyQixRQUFJLE9BQU8saUJBQWlCO0FBQVUsWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ3pFLFFBQUksT0FBTyxvQkFBb0IsVUFBVTtBQUN4QyxVQUFJLE9BQU8sbUJBQW1CLFlBQVksT0FBTyxZQUFZO0FBQVUsY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQzFHLFVBQUksYUFBYSxVQUFhLE9BQU8sYUFBYTtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUVqRyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsY0FBYyxlQUFlO0FBQzlFLFdBQUssV0FBVyxRQUFRLGdCQUFnQixTQUFTLFFBQVE7SUFDMUQsV0FBVyxPQUFPLG9CQUFvQixVQUFVO0FBQy9DLFVBQUksbUJBQW1CLFVBQWEsT0FBTyxtQkFBbUI7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFN0csWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLEdBQUcsTUFBUztBQUM3RCxXQUFLLFdBQVcsUUFBUSxjQUFjLGlCQUFpQixjQUFjO0lBQ3RFLE9BQU87QUFDTixZQUFNLElBQUksTUFBTSxtQkFBbUI7SUFDcEM7RUFDRDtFQUVBLGVBQ0MsY0FDQSxRQUNBLFFBQTBCO0FBRTFCLFFBQUk7QUFDSixRQUFJLE9BQU8saUJBQWlCLFVBQVU7QUFDckMsZUFBUyxPQUFPLEtBQUssY0FBYyxPQUFPO0lBQzNDLFdBQVcsT0FBTyxTQUFTLFlBQVksR0FBRztBQUN6QyxlQUFTO0lBQ1YsV0FBVyxNQUFNLFFBQVEsWUFBWSxHQUFHO0FBRXZDLGFBQU8sT0FBTyxLQUFLLFlBQVk7SUFDaEMsT0FBTztBQUNOLGVBQVMsT0FBTyxLQUFLLGFBQWEsUUFBUSxhQUFhLFlBQVksYUFBYSxVQUFVO0lBQzNGO0FBRUEsV0FBTyxPQUFPLFNBQVMsUUFBUSxXQUFXLFNBQVksU0FBUyxTQUFTLE1BQVM7RUFDbEY7RUFFQSxXQUFXLFFBQWdCLE1BQWMsU0FBaUIsVUFBcUI7QUFDOUUsUUFBSSxDQUFDLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUV6RixTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFVBQVUsS0FBSyxPQUFPO01BQ3RCLFNBQVM7TUFFVDtNQUNBO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixpQkFBVTtJQUNYLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxxQkFBcUIsU0FBK0I7QUFDbkQsUUFBSTtBQUNILFdBQUssS0FBSyxXQUFXLFFBQVEsU0FBUyxRQUFRLE1BQU07SUFDckQsU0FBUyxJQUFJO0lBRWI7RUFDRDtFQUNBLG1CQUFtQixPQUFZO0FBQzlCLFNBQUssU0FBUztBQUVkLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFFBQUk7QUFBWSxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sV0FBVyxRQUFRO0FBRWhGLFFBQUk7QUFDSCxXQUFLLEtBQUssU0FBUyxLQUFLO0lBQ3pCLFNBQVMsSUFBSTtJQUViO0VBQ0Q7Ozs7QUM5UEssU0FBVSxrQkFBbUQsS0FBWTtBQUM5RSxRQUFNLE9BQU87QUFDYixTQUFPLENBQUMsQ0FBQyxRQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSyxPQUFPLFlBQVksS0FBSyx1QkFBdUI7QUFDekc7OztBQzZCTSxJQUFnQixlQUFoQixNQUE0QjtFQUN4QjtFQUNBO0VBRUE7RUFFVCxJQUFXLEtBQUU7QUFDWixXQUFPLEtBQUssU0FBUztFQUN0QjtFQUVBLElBQVcsa0JBQWU7QUFDekIsV0FBTyxLQUFLO0VBQ2I7Ozs7O0VBTUEsSUFBVyxRQUFLO0FBQ2YsV0FBTyxLQUFLLFNBQVM7RUFDdEI7Ozs7RUFLQSxZQUFZLFVBQWlCO0FBQzVCLFFBQUksQ0FBQyxrQkFBNkIsUUFBUSxLQUFLLENBQUMsU0FBUztBQUN4RCxZQUFNLElBQUksTUFDVCxtR0FBbUc7QUFHckcsU0FBSyxXQUFXO0FBRWhCLFNBQUssVUFBVSxtQkFBa0I7QUFFakMsU0FBSyx3QkFBd0IsS0FBSyxzQkFBc0IsS0FBSyxJQUFJO0FBRWpFLFNBQUssV0FBVztNQUNmLDJCQUEyQjtNQUMzQix3QkFBd0I7O0FBR3pCLFNBQUssSUFBSSxTQUFTLGNBQWM7RUFDakM7RUErQkEsV0FBVyxXQUE0QyxZQUFpQztBQUN2RixTQUFLLFNBQVMsV0FBVyxXQUFXLFVBQVU7RUFDL0M7Ozs7O0VBdUJBLHFCQUFxQixTQUF5RDtBQUM3RSxTQUFLLFNBQVMscUJBQXFCLE9BQU87RUFDM0M7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7O0VBT0EscUJBQ0MsV0FDQSxTQUE4QztBQUU5QyxTQUFLLFNBQVMscUJBQXFCLFdBQVcsT0FBTztFQUN0RDs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsUUFBSSxNQUFNLFFBQVEsU0FBUztBQUFHLFlBQU0sSUFBSSxNQUFNLHdEQUF3RDtBQUV0RyxTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7O0VBTUEsa0JBQWtCLFFBQXVDO0FBQ3hELFNBQUssU0FBUyxrQkFBa0IsTUFBTTtFQUN2Qzs7Ozs7O0VBT0EsaUJBQW1DLFlBQWE7QUFDL0MsV0FBTyxLQUFLLFNBQVMsaUJBQWlCLFVBQVU7RUFDakQ7Ozs7RUFLQSxvQkFBaUI7QUFDaEIsU0FBSyxTQUFTLGtCQUFpQjtFQUNoQzs7Ozs7OztFQVFBLGVBQ0MsaUJBQ0csZUFBbUQ7QUFFdEQsU0FBSyxTQUFTLGVBQWUsQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO0VBQzlEOzs7OztFQU1BLHNCQUFzQixhQUFxQjtBQUMxQyxTQUFLLFNBQVMsbUJBQW1CLFdBQVc7RUFDN0M7Ozs7OztFQU9BLG9CQUFvQixXQUFtQjtBQUN0QyxTQUFLLFNBQVMsaUJBQWlCLFNBQVM7RUFDekM7Ozs7OztFQU1BLHNCQUFzQixXQUFtQjtBQUN4QyxTQUFLLFNBQVMsbUJBQW1CLFNBQVM7RUFDM0M7Ozs7OztFQU9BLHdCQUF3QixhQUFxQjtBQUM1QyxTQUFLLFNBQVMscUJBQXFCLFdBQVc7RUFDL0M7Ozs7OztFQU9BLGFBQWEsUUFBaUMsY0FBcUI7QUFDbEUsU0FBSyxTQUFTLGFBQWEsUUFBUSxZQUFZO0VBQ2hEOzs7Ozs7OztFQVNBLFFBQVEsTUFBYyxNQUFjQSxPQUFjLE1BQXNCO0FBQ3ZFLFNBQUssU0FBUyxRQUFRLE1BQU0sTUFBTUEsT0FBTSxJQUFJO0VBQzdDOzs7Ozs7Ozs7OztFQVlBLGFBQWEsUUFBd0IsU0FBdUI7QUFDM0QsU0FBSyxTQUFTLGFBQWEsUUFBUSxXQUFXLElBQUk7RUFDbkQ7Ozs7OztFQU9BLElBQUksT0FBaUIsU0FBZTtBQUNuQyxZQUFRLE9BQU87TUFDZCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNEO0FBQ0Msb0JBQVksS0FBSztBQUNqQixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO0lBQ0Y7RUFDRDtFQVlBLHNCQUNDLGVBQ0EsVUFBeUM7QUFFekMsVUFBTSxVQUFrQyxPQUFPLGtCQUFrQixXQUFXLEVBQUUsTUFBTSxjQUFhLElBQUs7QUFFdEcsVUFBTSxTQUFTLElBQUksb0JBQW9CLEtBQUssVUFBVSxPQUFPO0FBQzdELFFBQUk7QUFBVSxhQUFPLEdBQUcsV0FBVyxRQUFRO0FBRTNDLFdBQU87RUFDUjs7OztBQy9VRCxJQUFZO0NBQVosU0FBWUMsaUJBQWM7QUFDekIsRUFBQUEsZ0JBQUEsSUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsWUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsbUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFdBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGdCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx1QkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEseUJBQUEsSUFBQTtBQUNELEdBVlksbUJBQUEsaUJBQWMsQ0FBQSxFQUFBO0FBYXBCLElBQVc7Q0FBakIsU0FBaUJDLFFBQUs7QUFFUixFQUFBQSxPQUFBLEtBQUs7QUFDTCxFQUFBQSxPQUFBLFdBQ1o7QUFDWSxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLE9BQ1o7QUFDWSxFQUFBQSxPQUFBLGNBQWM7QUFDZCxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLFFBQVE7QUFDUixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLFNBQVM7QUFDVCxFQUFBQSxPQUFBLGdCQUFnQjtBQUNoQixFQUFBQSxPQUFBLFlBQVk7QUFDWixFQUFBQSxPQUFBLFdBQ1o7QUFDRixHQWxCaUIsVUFBQSxRQUFLLENBQUEsRUFBQTs7O0FDakJ0QixPQUFPLFFBQVE7QUFDZixPQUFPLFVBQVU7QUFJakIsSUFBTSxTQUFTLG1CQUFtQixRQUFRO0FBdUIxQyxTQUFTLHVCQUFvQjtBQUM1QixRQUFNLGNBQWMsS0FBSyxLQUFLLFlBQVksU0FBUyxZQUFZO0FBQy9ELFFBQU0sZUFBZSxLQUFLLEtBQUssWUFBWSxTQUFTLFdBQVc7QUFHL0QsTUFBSSxHQUFHLFdBQVcsV0FBVyxHQUFHO0FBQy9CLFdBQU8sTUFBTSx5QkFBeUIsV0FBVyxFQUFFO0FBQ25ELFdBQU87RUFDUjtBQUdBLE1BQUksR0FBRyxXQUFXLFlBQVksR0FBRztBQUNoQyxXQUFPLEtBQUsscURBQXFELFlBQVksRUFBRTtBQUMvRSxXQUFPO0VBQ1I7QUFHQSxRQUFNLFdBQVc7O01BQTBDLFdBQVc7TUFBUyxZQUFZOztBQUMzRixTQUFPLE1BQU0sUUFBUTtBQUNyQixRQUFNLElBQUksTUFBTSxRQUFRO0FBQ3pCO0FBR0EsSUFBTSxnQkFBZ0IscUJBQW9CO0FBRzFDLElBQUkscUJBQWlEO0FBTS9DLFNBQVUsbUJBQWdCO0FBQy9CLFNBQU87QUFDUjtBQU1BLFNBQVMsb0JBQWlCO0FBQ3pCLFFBQU0sVUFBK0IsQ0FBQTtBQUNyQyxNQUFJO0FBQ0gsVUFBTSxRQUFRLEdBQUcsWUFBWSxhQUFhLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLE9BQU8sQ0FBQztBQUU3RSxlQUFXLEtBQUssT0FBTztBQUN0QixZQUFNLFdBQVcsS0FBSyxLQUFLLGVBQWUsQ0FBQztBQUMzQyxZQUFNLE9BQU8sS0FBSyxNQUFNLEdBQUcsYUFBYSxVQUFVLE1BQU0sQ0FBQztBQUN6RCxVQUFJLE1BQU0sT0FBTztBQUNoQixnQkFBUSxPQUFPLEtBQUssS0FBSyxDQUFDLElBQUk7TUFDL0I7SUFDRDtBQUVBLFdBQU8sTUFBTSxVQUFVLE9BQU8sS0FBSyxPQUFPLEVBQUUsTUFBTSw0QkFBNEI7RUFDL0UsU0FBUyxHQUFHO0FBQ1gsV0FBTyxNQUFNLGtDQUFrQyxDQUFDLEVBQUU7RUFDbkQ7QUFDQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLG1CQUFnQjtBQUMvQixNQUFJLENBQUMsb0JBQW9CO0FBQ3hCLHlCQUFxQixrQkFBaUI7RUFDdkM7QUFDQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLGdCQUFnQixPQUFhO0FBQzVDLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsU0FBTyxRQUFRLEtBQUs7QUFDckI7QUFNTSxTQUFVLHNCQUFtQjtBQUNsQyxTQUFPLEtBQUssdUNBQXVDO0FBQ25ELHVCQUFxQixrQkFBaUI7QUFDdkM7QUFLQSxTQUFTLHNCQUFtQjtBQUMzQixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFNBQU8sT0FBTyxLQUFLLE9BQU8sRUFBRSxLQUFJO0FBQ2pDO0FBRU0sU0FBVSxnQkFBZ0Isb0JBQWtDLENBQUEsR0FBRTtBQUNuRSxRQUFNLFNBQVMsb0JBQW1CO0FBSWxDLFFBQU0sZ0JBQWdCO0lBQ3JCLEVBQUUsSUFBSSxJQUFJLE9BQU8sa0NBQWlDO0lBQ2xELEdBQUcsa0JBQWtCLElBQUksQ0FBQyxPQUFPO01BQ2hDLElBQUksRUFBRSxPQUFPO01BQ2IsT0FBTyxTQUFTLEVBQUUsS0FBSyxLQUFLLEVBQUUsR0FBRyxPQUFPLEVBQUUsRUFBRTtNQUMzQzs7QUFHSCxTQUFPOzs7SUFHTjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsU0FBUztNQUNULFNBQVM7OztJQUlWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxPQUFPLE1BQU07TUFDYixxQkFBcUI7TUFDckIsU0FBUzs7O0lBSVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUyxPQUFPLENBQUMsS0FBSztNQUN0QixTQUFTLE9BQU8sSUFBSSxDQUFDLFdBQVc7UUFDL0IsSUFBSTtRQUNKLE9BQU8sU0FBUyxLQUFLO1FBQ3BCO01BQ0YscUJBQXFCO01BQ3JCLFNBQVM7OztBQUdaO0FBT00sU0FBVSxZQUFZLFFBQXNCLG1CQUErQjtBQUNoRixNQUFJLE9BQU8sV0FBVztBQUNyQixVQUFNLFNBQVMsa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxPQUFPLFNBQVM7QUFDdkUsV0FBTyxRQUFRLE1BQU07RUFDdEI7QUFDQSxTQUFPLE9BQU8sT0FBTyxRQUFRLEVBQUU7QUFDaEM7QUFPTSxTQUFVLGFBQWEsUUFBc0IsbUJBQStCO0FBQ2pGLE1BQUksT0FBTyxXQUFXO0FBQ3JCLFVBQU0sU0FBUyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE9BQU8sU0FBUztBQUN2RSxXQUFPLE1BQU0sNEJBQTRCLE9BQU8sU0FBUyxvQkFBb0IsUUFBUSxTQUFTLE1BQU0sRUFBRTtBQUN0RyxXQUFPLFFBQVEsU0FBUztFQUN6QjtBQUNBLFNBQU8sTUFBTSwyQ0FBMkMsT0FBTyxXQUFXLEdBQUc7QUFDN0UsU0FBTyxPQUFPLE9BQU8sZUFBZSxFQUFFO0FBQ3ZDOzs7QUN4TU0sU0FBVSwwQkFBMEIsTUFBb0I7QUFDN0QsT0FBSyx1QkFBdUI7SUFDM0IsT0FBTyxFQUFFLE1BQU0sc0JBQXFCO0lBQ3BDLFdBQVcsRUFBRSxNQUFNLHVDQUFzQztJQUN6RCxjQUFjLEVBQUUsTUFBTSxzQkFBcUI7SUFDM0MsVUFBVSxFQUFFLE1BQU0sMEJBQXlCO0lBQzNDLFNBQVMsRUFBRSxNQUFNLGdDQUErQjtJQUNoRCxLQUFLLEVBQUUsTUFBTSxxQkFBb0I7SUFDakMsSUFBSSxFQUFFLE1BQU0sb0JBQW1CO0dBQy9CO0FBQ0Y7QUFFQSxJQUFNLG9CQUFvQjtFQUN6QixPQUFPO0VBQ1AsV0FBVztFQUNYLGNBQWM7RUFDZCxVQUFVO0VBQ1YsU0FBUztFQUNULEtBQUs7RUFDTCxJQUFJOztBQVFDLFNBQVUscUJBQXFCLE1BQW9CO0FBQ3hELFFBQU0sY0FBYyxLQUFLO0FBR3pCLE1BQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxhQUFhLG1CQUFtQixXQUFXLEdBQUc7QUFDdkUsU0FBSyxrQkFBa0IsaUJBQWlCO0FBQ3hDO0VBQ0Q7QUFFQSxRQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxXQUFXO0FBQzVELE1BQUksUUFBUTtBQUNYLFNBQUssa0JBQWtCO01BQ3RCLE9BQU8sT0FBTyxTQUFTO01BQ3ZCLFdBQVcsT0FBTyxhQUFhO01BQy9CLGNBQWMsT0FBTyxnQkFBZ0I7TUFDckMsVUFBVSxPQUFPLGdCQUFnQjtNQUNqQyxTQUFTLE9BQU8saUJBQWlCO01BQ2pDLEtBQUssT0FBTyxPQUFPO01BQ25CLElBQUksT0FBTztLQUNYO0VBQ0YsT0FBTztBQUdOLFNBQUssa0JBQWtCO01BQ3RCLEdBQUc7TUFDSCxJQUFJO0tBQ0o7RUFDRjtBQUNEOzs7QUMxRE8sSUFBTSxpQkFBK0Q7Ozs7Ozs7Ozs7Ozs7OztBQ3FCckUsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sY0FBYztBQUNwQixJQUFNLGdCQUFnQjtBQUN0QixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGFBQWE7QUFDbkIsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxvQkFBb0I7QUFDMUIsSUFBTSxlQUFlO0FBQ3JCLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sY0FBYztBQUdyQixTQUFVLGVBQWUsT0FBYTtBQUMzQyxVQUFRLE9BQU87SUFDZCxLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSO0FBQ0MsYUFBTyxTQUFTLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztFQUNyRDtBQUNEO0FBUU0sU0FBVSxjQUNmLE9BQ0EsT0FDQSxXQUNBLE9BQXVCO0FBRXZCLFFBQU0sTUFBTSxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzdELFFBQU0sS0FBSyxPQUFPLGNBQWMsV0FBVyxVQUFVLFNBQVMsRUFBRSxJQUFJO0FBRXBFLE1BQUksVUFBVSxRQUFXO0FBQ3hCLFVBQU0sS0FBSyxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzVELFdBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFO0VBQ25DO0FBRUEsU0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRTtBQUM3QjtBQVNNLFNBQVUsTUFBTSxPQUFlLFlBQVksR0FBQztBQUNqRCxTQUFPLEtBQUssTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLFdBQVcsR0FBRyxDQUFDO0FBQ3hEO0FBT00sU0FBVSxXQUFXLE9BQXdCO0FBQ2xELFNBQU8sS0FBSyxNQUFNLEtBQUssS0FBSyxFQUMxQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLENBQUM7QUFDWDtBQVNNLFNBQVUsZUFBZSxHQUFXLEdBQVcsR0FBUztBQUM3RCxTQUFPLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUNqQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLEVBQ1AsWUFBVyxDQUFFO0FBQ2hCO0FBUU0sU0FBVSxlQUFlLElBQVU7QUFDeEMsUUFBTSxDQUFDLE9BQU8sVUFBVSxLQUFLLElBQUksR0FBRyxNQUFNLEdBQUc7QUFDN0MsU0FBTztJQUNOO0lBQ0EsT0FBTyxTQUFTLFVBQVUsRUFBRTtJQUM1QixRQUFRLFNBQVMsT0FBTyxFQUFFOztBQUU1QjtBQVVNLFNBQVUsY0FBYyxRQUFnQixRQUFjO0FBQzNELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELE1BQUksT0FBTyxNQUFNLEVBQUUsS0FBSyxPQUFPLE1BQU0sRUFBRTtBQUFHLFdBQU87QUFDakQsU0FBTyxLQUFLLElBQUksS0FBSyxFQUFFO0FBQ3hCO0FBU00sU0FBVSxxQkFDZixZQUErQjtBQUUvQixRQUFNLGFBQWtFLENBQUE7QUFDeEUsYUFBVyxDQUFDLE9BQU8sSUFBSSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDdkQsZUFBVyxLQUFLLElBQUk7TUFDbkIsT0FBTyxLQUFLO01BQ1osV0FBVyxNQUFNLFFBQVEsS0FBSyxTQUFTLElBQUksS0FBSyxZQUFZLENBQUE7O0VBRTlEO0FBQ0EsU0FBTztBQUNSO0FBWU0sU0FBVSxxQkFDZixTQUNBLE9BQ0EsT0FDQSxXQUFpQjtBQUVqQixRQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLE1BQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxRQUFRLE9BQU8sU0FBUztBQUFHLFdBQU87QUFHeEQsTUFBSSxTQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUd2RixNQUFJLENBQUMsUUFBUTtBQUNaLGFBQVMsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFVO0FBQ3pDLFVBQUksRUFBRSxXQUFXO0FBQU8sZUFBTztBQUMvQixZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLFNBQVMsWUFBWSxFQUFFO0FBQzdCLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0lBQzVELENBQUM7RUFDRjtBQUVBLFNBQU87QUFDUjs7O0FDdE1BLFNBQVMsWUFBWSxHQUFNO0FBQzFCLFFBQU0sT0FBTztJQUNaLE1BQU0sRUFBRTtJQUNSLElBQUksRUFBRTtJQUNOLE9BQU8sRUFBRTtJQUNULFNBQVMsRUFBRTtJQUNYLFNBQVMsRUFBRTs7QUFHWixVQUFRLEVBQUUsTUFBTTtJQUNmLEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLENBQUEsRUFBRTtJQUUzQyxLQUFLO0FBQ0osYUFBTztRQUNOLEdBQUc7UUFDSCxLQUFLLEVBQUU7UUFDUCxLQUFLLEVBQUU7UUFDUCxNQUFNLEVBQUUsUUFBUTtRQUNoQixPQUFPOztJQUdULEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLE1BQUs7SUFFOUMsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0w7QUFDQyxhQUFPO0VBQ1Q7QUFDRDtBQU1NLFNBQVUsZUFBWTtBQUMzQixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sVUFBc0MsQ0FBQTtBQUU1QyxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLEtBQUssV0FBVztBQUMxQixZQUFNLFdBQVcsY0FBYyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7QUFFcEQsWUFBTSxXQUFXLEVBQUUsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRWpELFlBQU0sU0FBb0M7UUFDekMsTUFBTSxTQUFTLEtBQUssS0FBSyxFQUFFLElBQUk7UUFDL0I7UUFDQSxVQUFVLFlBQVc7UUFFckI7O0FBR0QsY0FBUSxRQUFRLElBQUk7SUFDckI7RUFDRDtBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsaUJBQWM7QUFDN0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxRQUFNLFlBQTBDLENBQUE7QUFFaEQsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxXQUFXLFdBQVc7QUFDaEMsWUFBTSxpQkFBaUIsY0FBYyxPQUFPLFFBQVEsUUFBUSxRQUFRLEVBQUU7QUFHdEUsWUFBTSxjQUFjLFFBQVEsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRzFELFlBQU0sZUFBZSxXQUFXLE9BQU8sQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBR3ZFLG1CQUFhLEtBQUs7UUFDakIsTUFBTTtRQUNOLElBQUk7UUFDSixPQUFPO1FBQ1AsU0FBUztRQUNULFNBQVM7T0FDVDtBQUdELFlBQU0sZ0JBQXFCO1FBQzFCLE1BQU07UUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtRQUNyQyxTQUFTO1FBQ1QsVUFBVSxNQUFLO0FBRWQsaUJBQU87UUFDUjs7QUFHRCxnQkFBVSxjQUFjLElBQUk7SUFDN0I7RUFDRDtBQUVBLFNBQU87QUFDUjs7O0FDNUhBLE9BQU9DLFdBQVU7OztBQ0xqQixPQUFPQyxTQUFRO0FBZ0JmLElBQU1DLFVBQVMsbUJBQW1CLGdCQUFnQjtBQXlDbEQsU0FBUyxlQUFlLE9BQWE7QUFDcEMsUUFBTSxTQUFTLG9CQUFJLElBQUc7QUFDdEIsTUFBSSxZQUFZO0FBRWhCLE1BQUk7QUFFSCxVQUFNLE9BQU8sZ0JBQWdCLEtBQUs7QUFDbEMsUUFBSSxDQUFDLE1BQU07QUFFVixhQUFPLEVBQUUsV0FBVyxPQUFNO0lBQzNCO0FBR0EsZ0JBQVksS0FBSyxhQUFhO0FBRzlCLGVBQVcsVUFBVSxLQUFLLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0saUJBQWlCLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBd0IsSUFBSSxTQUFTLGFBQWE7QUFDL0YsVUFBSSxnQkFBZ0I7QUFFbkIsZUFBTyxJQUFJLE9BQU8sRUFBRTtBQUdwQixjQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLE9BQU8sT0FBTztBQUNwRixZQUFJLGFBQWEsU0FBUztBQUN6QixxQkFBVyxVQUFVLFlBQVksU0FBUztBQUN6QyxnQkFBSSxPQUFPLE9BQU8sT0FBTyxVQUFVO0FBQ2xDLHFCQUFPLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRTtZQUNqQztVQUNEO1FBQ0Q7TUFDRDtJQUNEO0VBQ0QsU0FBUyxNQUFNO0VBRWY7QUFFQSxTQUFPLEVBQUUsV0FBVyxPQUFNO0FBQzNCO0FBTUEsU0FBUyxzQkFBc0IsS0FBVztBQUN6QyxRQUFNLFdBQVcsSUFBSSxRQUFRLE9BQU8sS0FBSyxVQUFVLENBQUM7QUFDcEQsTUFBSSxXQUFXO0FBQUcsVUFBTSxJQUFJLE1BQU0saUNBQWlDO0FBRW5FLFFBQU0sZUFBZSxXQUFXO0FBQ2hDLE1BQUksSUFBSSxZQUFZLE1BQU0sSUFBTTtBQUMvQixVQUFNLElBQUksTUFBTSx1Q0FBdUMsSUFBSSxZQUFZLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRTtFQUN4RjtBQUVBLFNBQU87QUFDUjtBQU1BLFNBQVMsdUJBQXVCLE9BQWUsU0FBc0Isb0JBQUksSUFBRyxHQUFFO0FBQzdFLE1BQUksSUFBSTtBQUNSLFFBQU0sTUFBdUIsQ0FBQTtBQUU3QixTQUFPLElBQUksTUFBTSxRQUFRO0FBQ3hCLFVBQU0sS0FBSyxNQUFNLENBQUM7QUFDbEIsUUFBSSxJQUFJLEtBQUssTUFBTTtBQUFRO0FBRzNCLFFBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTSxRQUFRO0FBQzNDLFVBQUksS0FBSztRQUNSLFFBQVE7UUFDUjtRQUNBLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQztPQUNyRDtBQUNELFdBQUs7QUFDTDtJQUNEO0FBRUEsUUFBSSxLQUFLLEVBQUUsUUFBUSxjQUFjLElBQUksWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFFO0FBQ2pFLFNBQUs7RUFDTjtBQUVBLFNBQU87QUFDUjtBQUVNLFNBQVUseUJBQXlCLEtBQWEsT0FBYTtBQUNsRSxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSw0QkFBNEI7RUFDN0M7QUFFQSxRQUFNLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFDNUIsUUFBTSxRQUFRLE1BQU07QUFDcEIsUUFBTSxNQUFNLFFBQVE7QUFDcEIsTUFBSSxNQUFNLElBQUk7QUFBUSxVQUFNLElBQUksTUFBTSxzQkFBc0I7QUFFNUQsUUFBTSxFQUFFLE9BQU0sSUFBSyxlQUFlLEtBQUs7QUFDdkMsU0FBTyx1QkFBdUIsSUFBSSxTQUFTLE9BQU8sR0FBRyxHQUFHLE1BQU07QUFDL0Q7QUFNTSxTQUFVLDhCQUE4QixLQUFhLE9BQWE7QUFDdkUsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0sNEJBQTRCO0VBQzdDO0FBR0EsTUFBSSxJQUFJLFVBQVUsdUJBQXVCLE1BQU0sSUFBSSxNQUFNO0FBQ3pELFFBQU0sTUFBTSxJQUFJLFNBQVM7QUFDekIsUUFBTSxNQUF1QixDQUFBO0FBRzdCLFFBQU0sRUFBRSxPQUFNLElBQUssZUFBZSxLQUFLO0FBR3ZDLFFBQU0sb0JBQW9CLENBQUMsYUFBYSxpQkFBaUIsV0FBVztBQUVwRSxTQUFPLElBQUksSUFBSSxLQUFLO0FBQ25CLFVBQU0sU0FBUyxJQUFJLENBQUM7QUFDcEIsVUFBTSxlQUFlLElBQUksSUFBSSxDQUFDO0FBRTlCLFVBQU0sYUFBYSxJQUFJLElBQUk7QUFDM0IsUUFBSSxhQUFhO0FBQUs7QUFHdEIsVUFBTSxXQUFXLGtCQUFrQixTQUFTLFlBQVk7QUFFeEQsUUFBSTtBQUNKLFFBQUk7QUFDSixRQUFJO0FBRUosUUFBSSxVQUFVO0FBRWIsY0FBUSxJQUFJLElBQUksQ0FBQztBQUNqQixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVCxPQUFPO0FBRU4sZ0JBQVUsSUFBSSxJQUFJLENBQUM7QUFDbkIsVUFBSSxJQUFJO0lBQ1Q7QUFFQSxVQUFNLE9BQU8sSUFBSTtBQUVqQixXQUFPLElBQUksSUFBSSxNQUFNO0FBQ3BCLFlBQU0sS0FBSyxJQUFJLENBQUM7QUFDaEIsVUFBSTtBQUdKLFVBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTTtBQUNuQyxxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ2hELGFBQUs7TUFDTixPQUFPO0FBQ04scUJBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ3hCLGFBQUs7TUFDTjtBQUVBLFlBQU0sVUFBeUI7UUFDOUIsUUFBUTtRQUNSO1FBQ0E7O0FBRUQsVUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQVEsUUFBUTtNQUNqQjtBQUNBLFVBQUksS0FBSyxPQUFPO0lBQ2pCO0FBRUEsUUFBSTtFQUNMO0FBRUEsU0FBTztBQUNSO0FBV00sU0FBVSxzQkFBc0IsT0FBZSxLQUFXO0FBQy9ELFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLGlDQUFpQyxNQUFNLFNBQVMsRUFBRSxDQUFDLEdBQUc7RUFDdkU7QUFDQSxRQUFNLEVBQUUsVUFBUyxJQUFLLGVBQWUsS0FBSztBQUMxQyxTQUFPLFlBQVksOEJBQThCLEtBQUssS0FBSyxJQUFJLHlCQUF5QixLQUFLLEtBQUs7QUFDbkc7QUFNTSxTQUFVLG9CQUFvQixTQUF3QixTQUFtQjtBQUU5RSxNQUFJLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsUUFBUSxVQUFVLEVBQUUsT0FBTyxRQUFRLEVBQUU7QUFLbkYsTUFBSSxDQUFDLFFBQVE7QUFDWixVQUFNLGFBQWEsUUFBUSxLQUFLLENBQUMsTUFBSztBQUNyQyxVQUFJLEVBQUUsV0FBVyxRQUFRO0FBQVEsZUFBTztBQUV4QyxZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQy9ELFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLGdCQUFnQixRQUFRLEtBQUssRUFBRTtBQUNyQyxhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtJQUM5RCxDQUFDO0FBQ0QsUUFBSSxZQUFZO0FBQ2YsZUFBUztJQUNWO0VBQ0Q7QUFFQSxRQUFNLFNBQVMsTUFBTSxRQUFRLE1BQU07QUFDbkMsUUFBTSxRQUFRLE1BQU0sUUFBUSxFQUFFO0FBQzlCLFFBQU0sU0FBUyxXQUFXLFFBQVEsVUFBVTtBQUM1QyxRQUFNLFNBQ0wsUUFBUSxXQUFXLFdBQVcsSUFDM0IsZUFBZSxRQUFRLFdBQVcsQ0FBQyxHQUFHLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsQ0FBQyxJQUNsRixRQUFRLFdBQVcsV0FBVyxJQUM3QixRQUFRLFdBQVcsQ0FBQyxJQUNwQixRQUFRLFdBQVcsS0FBSyxHQUFHO0FBR2hDLFFBQU0sV0FBVyxRQUFRLFVBQVUsU0FBWSxPQUFPLFFBQVEsS0FBSyxLQUFLO0FBQ3hFLFFBQU0sU0FBUyxPQUFPLE1BQU0sR0FBRyxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU07QUFHakUsTUFBSSxRQUFRO0FBQ1gsUUFBSSxPQUFPLE9BQU87QUFHbEIsUUFBSSxRQUFRLFVBQVUsUUFBVztBQUNoQyxhQUFPLEdBQUcsSUFBSSxNQUFNLFFBQVEsUUFBUSxDQUFDO0lBQ3RDLE9BRUs7QUFDSixZQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksYUFBYSxTQUFTO0FBQ3pCLGNBQU0sZ0JBQWdCLFFBQVEsS0FBSyxPQUFPO0FBQzFDLGNBQU0sY0FBYyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGFBQWE7QUFDMUUsWUFBSSxhQUFhO0FBQ2hCLGlCQUFPLEdBQUcsSUFBSSxJQUFJLFlBQVksS0FBSztRQUNwQztNQUNEO0lBQ0Q7QUFHQSxVQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFFBQUksYUFBYSxXQUFXLFFBQVEsV0FBVyxXQUFXLEdBQUc7QUFDNUQsWUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxXQUFXLENBQUMsQ0FBQztBQUM3RSxVQUFJLFFBQVE7QUFDWCxlQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNO01BQ3ZEO0lBQ0Q7QUFDQSxXQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxNQUFNO0VBQ3RDO0FBR0EsU0FBTyxHQUFHLE1BQU07QUFDakI7QUFpQk0sU0FBVSxpQ0FDZixPQUNBLEtBQVc7QUFFWCxRQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsUUFBTSxvQkFBb0IsUUFBUTtBQUdsQyxNQUFJLHNCQUFzQixRQUFXO0FBQ3BDLFVBQU0sV0FBVyxvQkFDZCw4QkFBOEIsS0FBSyxLQUFLLElBQ3hDLHlCQUF5QixLQUFLLEtBQUs7QUFDdEMsV0FBTyxFQUFFLFVBQVUsbUJBQW1CLEtBQUk7RUFDM0M7QUFHQSxNQUFJLGVBQWdDLENBQUE7QUFDcEMsTUFBSSxvQkFBcUMsQ0FBQTtBQUV6QyxNQUFJO0FBQ0gsbUJBQWUseUJBQXlCLEtBQUssS0FBSztFQUNuRCxTQUFTLEdBQUc7QUFDWCxJQUFBQSxRQUFPLE1BQU0sdUJBQXVCLENBQUMsRUFBRTtFQUN4QztBQUVBLE1BQUk7QUFDSCx3QkFBb0IsOEJBQThCLEtBQUssS0FBSztFQUM3RCxTQUFTLEdBQUc7QUFDWCxJQUFBQSxRQUFPLE1BQU0sNEJBQTRCLENBQUMsRUFBRTtFQUM3QztBQUdBLE1BQUksa0JBQWtCLFNBQVMsYUFBYSxRQUFRO0FBQ25ELElBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsa0JBQWtCLE1BQU0sWUFBWSxhQUFhLE1BQU0sR0FBRztBQUNuSCxXQUFPLEVBQUUsVUFBVSxtQkFBbUIsbUJBQW1CLEtBQUk7RUFDOUQsV0FBVyxhQUFhLFNBQVMsR0FBRztBQUNuQyxJQUFBQSxRQUFPLEtBQUssbUNBQW1DLGFBQWEsTUFBTSxpQkFBaUIsa0JBQWtCLE1BQU0sR0FBRztBQUM5RyxXQUFPLEVBQUUsVUFBVSxjQUFjLG1CQUFtQixNQUFLO0VBQzFELE9BQU87QUFFTixJQUFBQSxRQUFPLEtBQUssdURBQXVELEtBQUssRUFBRTtBQUMxRSxXQUFPLEVBQUUsVUFBVSxDQUFBLEdBQUksbUJBQW1CLEtBQUk7RUFDL0M7QUFDRDtBQUVNLFNBQVUsNEJBQTRCLE9BQWUsS0FBVztBQUNyRSxRQUFNLEVBQUUsVUFBUyxJQUFLLGVBQWUsS0FBSztBQUMxQyxTQUFPLFlBQVksOEJBQThCLEtBQUssS0FBSyxJQUFJLHlCQUF5QixLQUFLLEtBQUs7QUFDbkc7QUFTQSxTQUFTLG1CQUFtQixZQUFvQjtBQUMvQyxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFdBQU8sRUFBRSxJQUFJLFNBQVMsT0FBTyxTQUFTLE1BQU0sVUFBVSxTQUFTLFdBQVcsQ0FBQyxFQUFDO0VBQzdFO0FBRUEsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUM1QixVQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsSUFBSTtBQUNsQixXQUFPO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxNQUFNO01BQ04sU0FBUyxlQUFlLEdBQUcsR0FBRyxDQUFDOztFQUVqQztBQUVBLFNBQU8sRUFBRSxJQUFJLFNBQVMsT0FBTyxTQUFTLE1BQU0sT0FBTyxTQUFTLENBQUMsR0FBRyxVQUFVLEVBQUM7QUFDNUU7QUFNTSxTQUFVLDRCQUNmLFdBQ0EsUUFDQSxXQUFzQztBQUV0QyxRQUFNLE1BQU0sZ0JBQWdCLFNBQVM7QUFHckMsTUFBSSxDQUFDLElBQUksV0FBVztBQUNuQixRQUFJLFlBQVksQ0FBQTtFQUNqQjtBQUdBLFFBQU0sYUFBYSxPQUFPLE9BQU8sU0FBUyxFQUN4QyxPQUFPLENBQUMsTUFBTSxFQUFFLFVBQVUsVUFBVSxLQUFLLEVBQ3pDLEtBQUssQ0FBQyxHQUFHLE1BQU0sY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLElBQUksY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLENBQUM7QUFFbEcsRUFBQUMsUUFBTyxLQUFLLG1CQUFtQixVQUFVLEtBQUssRUFBRTtBQUNoRCxFQUFBQSxRQUFPLE1BQU0sNkJBQTZCLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxJQUFJLENBQUMsRUFBRTtBQUtyRixRQUFNLG1CQUFtQixvQkFBSSxJQUFHO0FBQ2hDLGFBQVcsS0FBSyxZQUFZO0FBQzNCLGVBQVcsYUFBYSxFQUFFLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE9BQU87QUFDckUsVUFBSSxDQUFDLFVBQVU7QUFBUztBQUN4QixZQUFNLFNBQVMsVUFBVTtBQUN6QixZQUFNLFFBQVEsVUFBVTtBQUN4QixZQUFNLE1BQU0sR0FBRyxLQUFLLElBQUksTUFBTTtBQUM5QixVQUFJLGlCQUFpQixJQUFJLEdBQUc7QUFBRztBQUUvQixZQUFNLGdCQUFnQixPQUNwQixPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLEtBQUssTUFBTSxFQUNqRCxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssTUFBTSxFQUN4QixLQUFLLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUV0QixVQUFJLFNBQVM7QUFDYixpQkFBVyxPQUFPLGVBQWU7QUFDaEMsWUFBSSxRQUFRLFNBQVM7QUFBRyxtQkFBUztpQkFDeEIsTUFBTSxTQUFTO0FBQUc7TUFDNUI7QUFDQSxVQUFJLFNBQVMsR0FBRztBQUNmLHlCQUFpQixJQUFJLEtBQUssTUFBTTtBQUNoQyxRQUFBQSxRQUFPLE1BQU0sZ0NBQWdDLE1BQU0sS0FBSyxDQUFDLFlBQVksTUFBTSxNQUFNLENBQUMsb0JBQWUsTUFBTSxFQUFFO01BQzFHO0lBQ0Q7RUFDRDtBQUlBLFFBQU0sWUFBWSxvQkFBSSxJQUFHO0FBQ3pCLGFBQVcsRUFBRSxRQUFRLElBQUksTUFBSyxLQUFNLFFBQVE7QUFDM0MsUUFBSSxVQUFVO0FBQVc7QUFDekIsVUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLEVBQUU7QUFDM0IsUUFBSSxDQUFDLFVBQVUsSUFBSSxHQUFHO0FBQUcsZ0JBQVUsSUFBSSxLQUFLLG9CQUFJLElBQUcsQ0FBRTtBQUNyRCxjQUFVLElBQUksR0FBRyxFQUFHLElBQUksS0FBSztFQUM5QjtBQU1BLGFBQVcsRUFBRSxRQUFRLElBQUksT0FBTyxXQUFVLEtBQU0sUUFBUTtBQUV2RCxVQUFNLGdCQUFnQixJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDbEYsUUFBSSxlQUFlO0FBQ2xCLFlBQU0sTUFBTSxjQUFjLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDL0QsVUFBSTtBQUFLLFlBQUksVUFBVSxtQkFBbUIsVUFBVSxFQUFFO0FBQ3REO0lBQ0Q7QUFLQSxVQUFNLFlBQVksSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFLO0FBQzFDLFVBQUksRUFBRSxXQUFXO0FBQVEsZUFBTztBQUNoQyxZQUFNLFdBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3hELFVBQUksQ0FBQyxVQUFVO0FBQVMsZUFBTztBQUMvQixVQUFJLE1BQU0sRUFBRTtBQUFJLGVBQU87QUFDdkIsWUFBTSxTQUFTLEtBQUssRUFBRTtBQUV0QixhQUFPLFdBQVcsS0FBSyxDQUFDLE1BQUs7QUFDNUIsY0FBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRSxFQUFFO0FBQzlFLGNBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsZUFBTyxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07TUFDN0QsQ0FBQztJQUNGLENBQUM7QUFDRCxRQUFJLFdBQVc7QUFDZCxZQUFNLFNBQVMsS0FBSyxVQUFVO0FBQzlCLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsVUFBSSxVQUFVLFdBQVcsQ0FBQyxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU0sR0FBRztBQUM3RSxZQUFJLFFBQVEsV0FBVyxTQUFTLENBQUM7QUFDakMsbUJBQVcsS0FBSyxZQUFZO0FBQzNCLGdCQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUU7QUFDdEYsZ0JBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsZ0JBQU0sWUFBWSxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07QUFDdkUsY0FBSSxXQUFXO0FBQ2Qsb0JBQVEsVUFBVTtBQUNsQjtVQUNEO1FBQ0Q7QUFDQSxpQkFBUyxRQUFRLEtBQUssRUFBRSxJQUFJLFFBQVEsTUFBSyxDQUFFO0FBQzNDLFFBQUFBLFFBQU8sS0FDTixpQkFBaUIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyx1QkFBdUIsTUFBTSxVQUFVLEVBQUUsQ0FBQyxjQUFjLE1BQU0sTUFBTSxLQUFLLElBQUk7TUFFN0g7QUFDQTtJQUNEO0FBR0EsUUFBSTtBQUVKLGVBQVcsS0FBSyxZQUFZO0FBQzNCLFlBQU0sUUFBUSxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDekUsVUFBSSxPQUFPO0FBQ1YsaUJBQVMsZ0JBQWdCLEtBQUs7QUFFOUIsY0FBTSxXQUFXLE1BQU0sS0FBSyxRQUFRLHFDQUFxQyxFQUFFLEVBQUUsS0FBSTtBQUNqRixlQUFPLE9BQU8sR0FBRyxRQUFRLHlCQUF5QixFQUFFLEtBQUs7QUFDekQsUUFBQUEsUUFBTyxLQUFLLG1CQUFtQixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLGVBQWUsRUFBRSxLQUFLLFVBQVU7QUFDNUY7TUFDRDtJQUNEO0FBSUEsUUFBSSxDQUFDLFFBQVE7QUFDWixVQUFJLGNBQWM7QUFDbEIsaUJBQVcsS0FBSyxZQUFZO0FBQzNCLGNBQU0sWUFBWSxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQVU7QUFDOUMsY0FBSSxFQUFFLFdBQVc7QUFBUSxtQkFBTztBQUNoQyxnQkFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTztBQUM3RCxjQUFJLENBQUMsVUFBVTtBQUFTLG1CQUFPO0FBQy9CLGNBQUksTUFBTSxFQUFFO0FBQUksbUJBQU87QUFDdkIsZ0JBQU0sU0FBUyxLQUFLLEVBQUU7QUFDdEIsZ0JBQU0sU0FBUyxpQkFBaUIsSUFBSSxHQUFHLE1BQU0sSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLO0FBQzVELGlCQUFPLFVBQVU7UUFDbEIsQ0FBQztBQUNELFlBQUksV0FBVztBQUNkLHdCQUFjO0FBQ2QsVUFBQUEsUUFBTyxNQUNOLFVBQVUsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyw0Q0FBNEMsTUFBTSxVQUFVLEVBQUUsQ0FBQyw2QkFBd0I7QUFFL0g7UUFDRDtNQUNEO0FBQ0EsVUFBSTtBQUFhO0lBQ2xCO0FBR0EsUUFBSSxDQUFDLFFBQVE7QUFDWixlQUFTO1FBQ1I7UUFDQTtRQUNBLE1BQU0sZUFBZSxNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxFQUFFLFlBQVcsQ0FBRTtRQUNoRSxTQUFTLENBQUMsbUJBQW1CLFVBQVUsQ0FBQzs7QUFFekMsVUFBSSxVQUFVO0FBQVcsZUFBTyxRQUFRO0FBQ3hDLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxFQUFFO0lBQ3RFLE9BQU87QUFJTixhQUFPLFVBQVUsT0FBTyxTQUFTLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEtBQUssQ0FBQTtBQUNwRSxhQUFPLE9BQU87QUFFZCxZQUFNLGtCQUFrQixVQUFVLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxFQUFFO0FBQ3ZELFVBQUksbUJBQW1CLGdCQUFnQixPQUFPLEdBQUc7QUFDaEQsY0FBTSxXQUFXLEtBQUssSUFBSSxHQUFHLGVBQWU7QUFDNUMsWUFBSSxhQUFhLEdBQUc7QUFFbkIsaUJBQU8sUUFBUTtRQUNoQixPQUFPO0FBRU4sZ0JBQU0sZUFBZSxNQUFNLEtBQUssRUFBRSxRQUFRLFdBQVcsRUFBQyxHQUFJLENBQUMsR0FBRyxPQUFPO1lBQ3BFLElBQUk7WUFDSixPQUFPLFdBQVcsSUFBSSxDQUFDO1lBQ3RCO0FBQ0YsaUJBQU8sUUFBUSxRQUFRO1lBQ3RCLElBQUk7WUFDSixPQUFPO1lBQ1AsTUFBTTtZQUNOLFNBQVM7WUFDVCxTQUFTO1dBQ0Y7UUFDVDtNQUNEO0FBTUEsWUFBTSxrQkFBa0IsbUJBQW1CLFVBQVUsRUFBRTtBQUN2RCxZQUFNLFdBQVcsT0FBTyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQzdELFVBQUksVUFBVTtBQUNiLFlBQUksU0FBUyxXQUFXLE1BQU0sUUFBUSxTQUFTLE9BQU8sR0FBRztBQUN4RCxnQkFBTSxZQUFZLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sZUFBZTtBQUM1RSxjQUFJLENBQUMsV0FBVztBQUNmLFlBQUFBLFFBQU8sS0FDTiwrQkFBK0IsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxpQ0FBaUMsZUFBZSxzQ0FBaUM7QUFHOUkscUJBQVMsT0FBTztBQUNoQixtQkFBUSxTQUFpQjtVQUMxQjtRQUNEO0FBQ0EsaUJBQVMsVUFBVTtNQUNwQjtJQUNEO0FBRUEsUUFBSSxVQUFVLEtBQUssTUFBTTtFQUMxQjtBQVNBLGFBQVcsRUFBRSxRQUFRLEdBQUUsS0FBTSxRQUFRO0FBQ3BDLFVBQU0sa0JBQWtCLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUNwRixRQUFJO0FBQWlCO0FBR3JCLFVBQU0sWUFBWSxJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQUs7QUFDMUMsVUFBSSxFQUFFLFdBQVc7QUFBUSxlQUFPO0FBQ2hDLFlBQU1DLFlBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3hELGFBQU8sQ0FBQyxDQUFDQSxXQUFVLFdBQVcsS0FBSyxFQUFFO0lBQ3RDLENBQUM7QUFDRCxRQUFJLENBQUM7QUFBVztBQUVoQixVQUFNLFNBQVMsS0FBSyxVQUFVO0FBQzlCLFVBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsUUFBSSxDQUFDLFVBQVUsV0FBVyxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU07QUFBRztBQUk5RSxVQUFNLGVBQWUsV0FBVyxLQUFLLENBQUMsTUFBSztBQUMxQyxZQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUU7QUFDdEYsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxhQUFPLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtJQUM3RCxDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsU0FBUyxRQUFRLElBQUksQ0FBQyxNQUFXLEVBQUUsRUFBWSxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBQzdGLFVBQU0sZUFBZSxnQkFBZ0IsU0FBUyxLQUFLLFdBQVcsZ0JBQWdCLGdCQUFnQixTQUFTLENBQUMsSUFBSTtBQUU1RyxRQUFJLENBQUMsZ0JBQWdCLENBQUM7QUFBYztBQUdwQyxRQUFJLFFBQVEsV0FBVyxTQUFTLENBQUM7QUFDakMsZUFBVyxLQUFLLFlBQVk7QUFDM0IsWUFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsWUFBTSxZQUFZLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtBQUN2RSxVQUFJLFdBQVc7QUFDZCxnQkFBUSxVQUFVO0FBQ2xCO01BQ0Q7SUFDRDtBQUVBLGFBQVMsUUFBUSxLQUFLLEVBQUUsSUFBSSxRQUFRLE1BQUssQ0FBRTtBQUMzQyxJQUFBRCxRQUFPLEtBQ04seUJBQXlCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsdUJBQXVCLE1BQU0sVUFBVSxFQUFFLENBQUMsY0FBYyxNQUFNLE1BQU0sS0FBSyxJQUFJO0VBRXJJO0FBRUEsU0FBTztBQUNSO0FBTU0sU0FBVSxvQkFBb0IsVUFBa0IsU0FBb0I7QUFDekUsTUFBSTtBQUVILFVBQU0sYUFBa0IsRUFBRSxPQUFPLFFBQVEsTUFBSztBQUc5QyxRQUFJLGVBQWUsU0FBUztBQUMzQixpQkFBVyxZQUFZLFFBQVE7SUFDaEM7QUFHQSxRQUFJLHlCQUF5QixTQUFTO0FBQ3JDLGlCQUFXLHNCQUFzQixRQUFRO0lBQzFDO0FBQ0EsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRLFVBQVUsSUFBSSxDQUFDLFVBQWM7QUFFM0QsY0FBTSxlQUFvQixDQUFBO0FBQzFCLFlBQUksWUFBWTtBQUFPLHVCQUFhLFNBQVMsTUFBTTtBQUNuRCxZQUFJLFFBQVE7QUFBTyx1QkFBYSxLQUFLLE1BQU07QUFDM0MsWUFBSSxXQUFXO0FBQU8sdUJBQWEsUUFBUSxNQUFNO0FBQ2pELFlBQUksVUFBVTtBQUFPLHVCQUFhLE9BQU8sTUFBTTtBQUMvQyxZQUFJLGFBQWE7QUFBTyx1QkFBYSxVQUFVLE1BQU07QUFFckQsbUJBQVcsT0FBTyxPQUFPLEtBQUssS0FBSyxHQUFHO0FBQ3JDLGNBQUksRUFBRSxPQUFPO0FBQWUseUJBQWEsR0FBRyxJQUFJLE1BQU0sR0FBRztRQUMxRDtBQUNBLGVBQU87TUFDUixDQUFDO0lBQ0Y7QUFFQSxlQUFXLE9BQU8sT0FBTyxLQUFLLE9BQU8sR0FBRztBQUN2QyxVQUFJLEVBQUUsT0FBTyxhQUFhO0FBQ3pCLG1CQUFXLEdBQUcsSUFBSyxRQUFnQixHQUFHO01BQ3ZDO0lBQ0Q7QUFHQSxRQUFJLE9BQU8sS0FBSyxVQUFVLFlBQVksTUFBTSxDQUFDO0FBSzdDLFdBQU8sS0FBSyxRQUFRLDBEQUEwRCw2QkFBNkI7QUFFM0csSUFBQUUsSUFBRyxjQUFjLFVBQVUsT0FBTyxNQUFNLE1BQU07RUFDL0MsU0FBUyxHQUFHO0FBQ1gsSUFBQUYsUUFBTyxNQUFNLHFCQUFxQixDQUFDLEVBQUU7RUFDdEM7QUFDRDs7O0FEcnVCQSxJQUFNRyxVQUFTLG1CQUFtQixTQUFTO0FBRXJDLFNBQVUsY0FBYyxNQUFvQjtBQUNqRCxRQUFNLGFBQWEsaUJBQWdCO0FBQ25DLFFBQU0sYUFBYSxhQUFZO0FBQy9CLFFBQU0sVUFBVSxxQkFBcUIsVUFBVTtBQUMvQyxRQUFNLGVBQW9CLENBQUE7QUFFMUIsUUFBTSxjQUFjLEtBQUs7QUFNekIsZUFBYSx1QkFBdUIsSUFBSTtJQUN2QyxNQUFNO0lBQ04sU0FBUyxDQUFBO0lBQ1QsVUFBVSxZQUFXO0FBQ3BCLFlBQU0sUUFBUTtBQUNkLFlBQU0sS0FBSyxLQUFLO0FBRWhCLFlBQU0sTUFBTSxNQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUd6RCxVQUFJLFlBQVksZ0JBQWdCLEtBQUs7QUFHckMsWUFBTSxFQUFFLFVBQVUsUUFBUSxrQkFBaUIsSUFBSyxpQ0FBaUMsT0FBTyxHQUFHO0FBQzNGLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSyxVQUFVLE1BQU0sQ0FBQyxFQUFFO0FBRXRELFVBQUksQ0FBQyxXQUFXO0FBRWYsUUFBQUEsUUFBTyxLQUFLLFNBQVMsS0FBSyx1REFBa0Q7QUFDNUUsb0JBQVk7VUFDWDtVQUNBLFdBQVcscUJBQXFCO1VBQ2hDLHFCQUFxQjtVQUNyQixXQUFXLENBQUE7O01BRWIsV0FBVyxzQkFBc0IsTUFBTTtBQUV0QyxRQUFBQSxRQUFPLEtBQUssMkJBQTJCLGlCQUFpQix3QkFBd0I7QUFDaEYsb0JBQVksRUFBRSxHQUFHLFdBQVcsV0FBVyxrQkFBaUI7TUFDekQ7QUFFQSxZQUFNLFVBQVUsNEJBQTRCLFdBQVcsUUFBUSxPQUFPO0FBQ3RFLE1BQUFBLFFBQU8sTUFBTSxxQkFBcUIsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLENBQUMsRUFBRTtBQUdwRSxZQUFNQyxpQkFBZ0IsaUJBQWdCO0FBQ3RDLFlBQU0sYUFBYUMsTUFBSyxLQUFLRCxnQkFBZSxRQUFRLEtBQUssT0FBTztBQUNoRSwwQkFBb0IsWUFBWSxPQUFPO0FBR3ZDLDBCQUFtQjtBQUVuQixNQUFBRCxRQUFPLEtBQUssU0FBUyxLQUFLLHdDQUF3QztJQUNuRTs7QUFPRCxhQUFXLENBQUMsVUFBVSxNQUFNLEtBQUssT0FBTyxRQUFRLFVBQVUsR0FBRztBQUM1RCxVQUFNLEVBQUUsT0FBTyxPQUFPLE9BQU0sSUFBSyxlQUFlLFFBQVE7QUFHeEQsUUFBSSxVQUFVO0FBQWE7QUFHM0IsVUFBTSxTQUFTLFFBQVEsS0FBSztBQUM1QixVQUFNLFlBQVksUUFBUSxXQUFXLEtBQUssQ0FBQyxNQUFXLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxNQUFNO0FBRTNGLGlCQUFhLFFBQVEsSUFBSTtNQUN4QixHQUFHO01BQ0gsVUFBVSxPQUFPLFVBQWM7QUFDOUIsY0FBTSxLQUFLLEtBQUs7QUFDaEIsY0FBTSxRQUFRLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBWSxNQUFNLFFBQVEsT0FBTyxJQUFJLFdBQVc7QUFDekYsY0FBTSxRQUFRLE1BQU0sUUFBUSxPQUFPO0FBQ25DLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxLQUFLO0FBQ3hDLGNBQU0sWUFBWSxTQUFTO0FBRTNCLGNBQU0sS0FBSyxhQUFhLGFBQWEsT0FBTyxPQUFPLFdBQVcsT0FBTyxFQUFFO01BQ3hFOztFQUVGO0FBS0EsUUFBTSxlQUFlLFFBQVEsV0FBVztBQUN4QyxNQUFJLGNBQWM7QUFDakIsVUFBTSxtQkFBbUIsYUFBYSxhQUFhLENBQUEsR0FBSSxLQUFLLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxNQUFNLENBQUM7QUFFL0YsUUFBSSxpQkFBaUI7QUFDcEIsWUFBTSxXQUFXLEdBQUcsV0FBVztBQUUvQixtQkFBYSxRQUFRLElBQUk7UUFDeEIsTUFBTSxTQUFTLFdBQVc7UUFDMUIsU0FBUyxDQUFBO1FBQ1QsVUFBVSxZQUFXO0FBQ3BCLGdCQUFNLEtBQUssS0FBSztBQUNoQixVQUFBQSxRQUFPLEtBQUsseUJBQW9CLFdBQVcsTUFBTSxFQUFFLEVBQUU7QUFDckQsZ0JBQU0sS0FBSyxhQUFhLGNBQWMsRUFBRTtRQUN6Qzs7SUFFRjtFQUNEO0FBRUEsT0FBSyxxQkFBcUIsWUFBWTtBQUV0QyxFQUFBQSxRQUFPLEtBQUssaUNBQWlDLE9BQU8sS0FBSyxZQUFZLEVBQUUsTUFBTSxFQUFFO0FBQ2hGOzs7QUVwSEEsSUFBTUcsVUFBUyxtQkFBbUIsV0FBVztBQUs3QyxTQUFTLGlCQUNSLFNBQ0EsT0FDQSxPQUNBLFdBQ0EsT0FBYTtBQUViLFFBQU0sVUFBVSxxQkFBcUIsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUNyRSxNQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sUUFBUSxRQUFRLE9BQU87QUFBRyxXQUFPO0FBR3hELFFBQU0sY0FBYyxRQUFRLFFBQVEsS0FBSyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFDekUsTUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLFFBQVEsWUFBWSxPQUFPO0FBQUcsV0FBTztBQUdoRSxRQUFNLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxLQUFLO0FBQ2xFLFNBQU8sUUFBUSxTQUFTO0FBQ3pCO0FBTU0sU0FBVSxnQkFBZ0IsTUFBb0I7QUFDbkQsUUFBTSxhQUFhLGlCQUFnQjtBQUNuQyxRQUFNLGVBQWUsZUFBYztBQUNuQyxRQUFNLFVBQVUscUJBQXFCLFVBQVU7QUFDL0MsUUFBTSxpQkFBc0IsQ0FBQTtBQUc1QixRQUFNLGNBQWMsS0FBSztBQU16QixhQUFXLENBQUMsWUFBWSxRQUFRLEtBQUssT0FBTyxRQUFRLFlBQVksR0FBRztBQUNsRSxVQUFNLEVBQUUsT0FBTyxPQUFPLE9BQU0sSUFBSyxlQUFlLFVBQVU7QUFHMUQsUUFBSSxVQUFVO0FBQWE7QUFHM0IsbUJBQWUsVUFBVSxJQUFJO01BQzVCLEdBQUc7TUFDSCxVQUFVLENBQUMsa0JBQXNCO0FBQ2hDLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxjQUFjLFFBQVEsT0FBTyxLQUFLO0FBQ2hELGNBQU0sWUFBWSxTQUFTO0FBRzNCLFlBQUksUUFBUSxjQUFjLFFBQVEsT0FBTztBQUN6QyxZQUFJLFVBQVUsUUFBVztBQUN4QixnQkFBTSxlQUFlLHFCQUFxQixTQUFTLE9BQU8sT0FBTyxTQUFTO0FBQzFFLGNBQUksY0FBYyxVQUFVLFFBQVc7QUFDdEMsb0JBQVEsYUFBYTtVQUN0QjtRQUNEO0FBRUEsY0FBTSxVQUFVLEtBQUssYUFBYSxnQkFBZ0IsSUFBSSxPQUFPLFdBQVcsS0FBSztBQUc3RSxjQUFNLFlBQVksY0FBYyxRQUFRLFdBQVcsS0FBSztBQUV4RCxZQUFJLGFBQWEsWUFBWSxRQUFXO0FBRXZDLGlCQUFPLGlCQUFpQixTQUFTLE9BQU8sT0FBTyxXQUFXLE9BQU87UUFDbEU7QUFHQSxlQUFPLFdBQVc7TUFDbkI7O0VBRUY7QUFFQSxPQUFLLHVCQUF1QixjQUFjO0FBRTFDLEVBQUFBLFFBQU8sS0FBSyxxQ0FBcUMsT0FBTyxLQUFLLGNBQWMsRUFBRSxNQUFNLEVBQUU7QUFDdEY7OztBQ3pGQSxPQUFPQyxZQUFXOzs7QUNBbEIsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sUUFBUTtBQUlmLElBQU1DLFVBQVMsbUJBQW1CLE9BQU87QUFLbEMsSUFBTSx5QkFBeUI7QUFFL0IsSUFBTSwwQkFBMEI7QUFnQmhDLElBQU0scUJBQXFCLE1BQU87QUFpQm5DLFNBQVUsd0JBQXFCO0FBQ3BDLFFBQU0sTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQzlCLFFBQU0sTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssS0FBTTtBQUU3QyxNQUFJLGNBQWMsT0FBUSxDQUFDO0FBQzNCLE1BQUksY0FBYyx3QkFBd0IsQ0FBQztBQUMzQyxNQUFJLGNBQWMsS0FBSyxDQUFDO0FBRXhCLFFBQU0sTUFBTSxpQkFBZ0I7QUFDNUIsTUFBSSxLQUFLLEtBQUssQ0FBQztBQUVmLFNBQU8sS0FBSyxZQUFZLE9BQU8sRUFBRSxLQUFLLEtBQUssRUFBRTtBQUM3QyxNQUFJLGNBQWMsTUFBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFRLEVBQUU7QUFDNUIsTUFBSSxjQUFjLEtBQVksRUFBRTtBQUVoQyxTQUFPO0FBQ1I7QUFHTSxTQUFVLG1CQUFnQjtBQUMvQixNQUFJO0FBQ0gsVUFBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLGVBQVcsUUFBUSxPQUFPLEtBQUssTUFBTSxHQUFHO0FBQ3ZDLGlCQUFXLFFBQVEsT0FBTyxJQUFJLEtBQUssQ0FBQSxHQUFJO0FBQ3RDLFlBQUksQ0FBQyxLQUFLLFlBQVksS0FBSyxXQUFXLFVBQVUsS0FBSyxPQUFPLEtBQUssUUFBUSxxQkFBcUI7QUFDN0YsaUJBQU8sT0FBTyxLQUFLLEtBQUssSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBYyxTQUFTLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDM0U7TUFDRDtJQUNEO0VBQ0QsUUFBUTtFQUVSO0FBQ0EsU0FBTyxPQUFPLE1BQU0sR0FBRyxDQUFDO0FBQ3pCO0FBaUJNLFNBQVUsdUJBQXVCLEtBQWEsT0FBYTtBQUNoRSxNQUFJLElBQUksU0FBUztBQUFvQixXQUFPO0FBQzVDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRLFdBQU87QUFDM0MsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQXlCLFdBQU87QUFDNUQsTUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWSxXQUFPO0FBRWxFLFFBQU0sVUFBVSxDQUFDLFFBQWdCLFFBQ2hDLElBQ0UsU0FBUyxRQUFRLFNBQVMsR0FBRyxFQUM3QixTQUFTLE9BQU8sRUFDaEIsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUNiLEtBQUk7QUFFUCxRQUFNLFFBQVEsSUFBSSxTQUFTLEdBQUcsRUFBRTtBQUNoQyxRQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztBQUM1RSxRQUFNLE1BQU0sU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUc7QUFFekUsUUFBTSxPQUFPLFFBQVEsSUFBTSxFQUFFO0FBQzdCLFFBQU0sZUFBZSxRQUFRLElBQU0sRUFBRTtBQUNyQyxRQUFNLFdBQVcsUUFBUSxLQUFNLEVBQUU7QUFDakMsUUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEVBQUksQ0FBQyxJQUFJLElBQUksRUFBSSxDQUFDO0FBRS9DLE1BQUksQ0FBQztBQUFVLFdBQU87QUFJdEIsUUFBTSxRQUFRLFNBQ1osUUFBUSxjQUFjLEVBQUUsRUFDeEIsS0FBSSxFQUNKLE1BQU0sS0FBSyxFQUFFLENBQUM7QUFFaEIsU0FBTztJQUNOLElBQUk7SUFDSjtJQUNBO0lBQ0E7SUFDQSxXQUFXOztJQUNYO0lBQ0E7O0FBRUY7QUFPQSxlQUFzQixxQkFBcUIsUUFBYztBQUN4RCxTQUFPLElBQUksUUFBa0IsQ0FBQyxTQUFTLFdBQVU7QUFDaEQsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLE1BQUs7QUFDVCxhQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztJQUM3QyxDQUFDO0FBRUQsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksTUFBSztBQUVULGNBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxtQkFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMscUJBQVcsU0FBUyxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdkMsZ0JBQ0MsTUFBTSxXQUFXLFVBQ2pCLE1BQU0sWUFBWSxhQUNsQixNQUFNLE9BQ04sTUFBTSxRQUFRLHFCQUNiO0FBQ0QscUJBQU8sUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSSxHQUFJLENBQUM7WUFDdkU7VUFDRDtRQUNEO0FBQ0EsZUFBTyxJQUFJLE1BQU0sd0NBQXdDLFNBQVMsRUFBRSxDQUFDO01BQ3RFLFNBQVMsSUFBSTtBQUNaLGVBQU8sSUFBSSxNQUFNLE9BQU8sRUFBRSxDQUFDLENBQUM7TUFDN0I7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBTUEsZUFBc0IsOEJBQThCLFFBQWM7QUFDakUsU0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFVBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUVyQyxRQUFJLFdBQVc7QUFDZixRQUFJLEtBQUssU0FBUyxDQUFDLFFBQU87QUFDekIsVUFBSSxDQUFDLFVBQVU7QUFDZCxtQkFBVztBQUNYLFlBQUksTUFBSztBQUNULGVBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzdDO0lBQ0QsQ0FBQztBQUdELFFBQUksUUFBUSxHQUFHLFFBQVEsTUFBSztBQUMzQixVQUFJO0FBQ0gsY0FBTSxPQUFPLElBQUksUUFBTztBQUN4QixjQUFNLFlBQVksS0FBSztBQUN2QixZQUFJLENBQUMsVUFBVTtBQUNkLHFCQUFXO0FBQ1gsY0FBSSxNQUFLO0FBQ1Qsa0JBQVEsU0FBUztRQUNsQjtNQUNELFNBQVMsSUFBSTtBQUNaLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxpQkFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM3QjtNQUNEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQVdBLGVBQXNCLGdCQUNyQixVQUNBLGtCQUNBLFlBQVksS0FBSTtBQUVoQixRQUFNLHVCQUF1QjtBQUM3QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLGVBQWU7QUFFckIsUUFBTSxhQUFhLG9CQUFJLElBQUc7QUFFMUIsU0FBTyxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQ3BDLFVBQU0saUJBQWlCLE1BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUUzRSxVQUFNLFVBQVUsTUFBSztBQUNwQixVQUFJO0FBQ0gsdUJBQWUsZUFBZSxvQkFBb0I7TUFDbkQsUUFBUTtNQUVSO0FBQ0EsVUFBSTtBQUNILHVCQUFlLE1BQUs7TUFDckIsUUFBUTtNQUVSO0FBQ0EsY0FBTztJQUNSO0FBRUEsVUFBTSxRQUFRLFdBQVcsU0FBUyxTQUFTO0FBQzNDLFVBQU0sUUFBTztBQUViLG1CQUFlLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDbEMsTUFBQUEsUUFBTyxLQUFLLDBCQUEwQixJQUFJLE9BQU8sRUFBRTtJQUNwRCxDQUFDO0FBRUQsbUJBQWUsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzNDLFlBQU0sUUFBUSxNQUFNO0FBRXBCLFVBQUksSUFBSSxTQUFTO0FBQUk7QUFDckIsVUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVE7QUFDcEMsVUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWTtBQUUzRCxVQUFJLFdBQVcsSUFBSSxLQUFLO0FBQUc7QUFDM0IsaUJBQVcsSUFBSSxLQUFLO0FBQ3BCLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSywrQkFBMEI7QUFLN0QsWUFBTSxZQUFZLFlBQVc7QUFDNUIsY0FBTSxpQkFBaUIsS0FBSztBQUM1QixjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGlCQUFTLEtBQUssT0FBTyxjQUFjLE9BQU8sQ0FBQyxRQUFPO0FBQ2pELGNBQUk7QUFBSyxZQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssWUFBWSxJQUFJLE9BQU8sRUFBRTtRQUN4RSxDQUFDO01BQ0Y7QUFDQSxnQkFBUyxFQUFHLE1BQU0sQ0FBQyxRQUFRQSxRQUFPLEtBQUssdUJBQXVCLEdBQUcsRUFBRSxDQUFDO0lBQ3JFLENBQUM7QUFFRCxtQkFBZSxLQUFLLHFCQUFxQixNQUFLO0FBQzdDLFVBQUk7QUFDSCx1QkFBZSxjQUFjLG9CQUFvQjtBQUNqRCxRQUFBQSxRQUFPLEtBQUssb0NBQW9DLG9CQUFvQixJQUFJLG1CQUFtQixFQUFFO01BQzlGLFNBQVMsS0FBSztBQUNiLFFBQUFBLFFBQU8sS0FBSyw0Q0FBNEMsR0FBRyxFQUFFO01BQzlEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjs7O0FEcFFBLElBQU1DLFVBQVMsbUJBQW1CLGNBQWM7QUFFMUMsSUFBTyxlQUFQLE1BQU8sY0FBWTtFQUNQLGNBQXNCO0VBQ3RCLGlCQUFpQjtFQUNqQixTQUFTO0VBRWxCO0VBQ0E7O0VBQ0EsY0FHSixvQkFBSSxJQUFHO0VBQ0gsbUJBQWdDLG9CQUFJLElBQUc7OztFQUd2QyxZQUEyQixRQUFRLFFBQU87O0VBRzFDLHNCQUFzQjs7RUFHdEI7O0VBR0EsUUFBZ0I7RUFDaEIsVUFBc0IsQ0FBQTtFQUN0QixzQkFBK0I7Ozs7Ozs7O0VBUS9CLGNBQWdELG9CQUFJLElBQUc7Ozs7Ozs7RUFRdkQsZ0JBQTZCLG9CQUFJLElBQUc7O0VBR3BDLHFCQUFnRSxvQkFBSSxJQUFHOztFQUd2RTs7RUFHQSxXQUFrQyxvQkFBSSxJQUFHO0VBRWpELGNBQUE7QUFDQyxJQUFBQSxRQUFPLEtBQUssMEJBQTBCO0FBSXRDLFNBQUssV0FBV0MsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ3BFLFNBQUssVUFBVSxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQzVDLFdBQUssU0FBUyxLQUFLLEdBQUcsTUFBSztBQUMxQixRQUFBRCxRQUFPLE1BQU0sMkJBQTRCLEtBQUssU0FBUyxRQUFPLEVBQXdCLElBQUksRUFBRTtBQUM1RixnQkFBTztNQUNSLENBQUM7SUFDRixDQUFDO0FBQ0QsU0FBSyxTQUFTLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDakMsTUFBQUEsUUFBTyxNQUFNLG9CQUFvQixHQUFHLEVBQUU7SUFDdkMsQ0FBQztBQUdELFNBQUssV0FBV0MsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBRXBFLFNBQUssU0FBUyxHQUFHLGFBQWEsTUFBSztBQUNsQyxZQUFNLE9BQU8sS0FBSyxTQUFTLFFBQU87QUFDbEMsTUFBQUQsUUFBTyxNQUFNLDBCQUEwQixLQUFLLFVBQVUsSUFBSSxDQUFDLEVBQUU7QUFDN0QsVUFBSTtBQUNILGFBQUssU0FBUyxxQkFBcUIsSUFBSTtNQUN4QyxTQUFTLElBQUk7TUFFYjtJQUNELENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBRUQsU0FBSyxTQUFTLEdBQUcsV0FBVyxDQUFDLEtBQUssVUFBUztBQUMxQyxVQUFJO0FBQ0gsYUFBSyxlQUFlLEtBQUssTUFBTSxPQUFPO01BQ3ZDLFNBQVMsSUFBSTtBQUNaLFFBQUFBLFFBQU8sTUFBTSxvQ0FBb0MsRUFBRSxFQUFFO01BQ3REO0lBQ0QsQ0FBQztBQUdELFNBQUssU0FBUyxLQUFLLEVBQUUsU0FBUyxXQUFXLE1BQU0sS0FBSyxPQUFNLEdBQUksTUFBSztBQUNsRSxNQUFBQSxRQUFPLE1BQU0sOEJBQThCLEtBQUssTUFBTSxFQUFFO0lBQ3pELENBQUM7RUFDRjtFQUVPLFFBQUs7QUFDWCxRQUFJO0FBQ0gsaUJBQVcsYUFBYSxNQUFNLEtBQUssS0FBSyxnQkFBZ0IsR0FBRztBQUMxRCxZQUFJO0FBQ0gsZUFBSyxTQUFTLGVBQWUsS0FBSyxnQkFBZ0IsU0FBUztRQUM1RCxRQUFRO1FBRVI7TUFDRDtJQUNELFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7QUFDQSxRQUFJO0FBQ0gsV0FBSyxTQUFTLE1BQUs7SUFDcEIsUUFBUTtJQUVSO0VBQ0Q7Ozs7O0VBTU8sU0FBUyxPQUFlLFNBQXFCLHNCQUErQixNQUFJO0FBQ3RGLFNBQUssUUFBUTtBQUNiLFNBQUssVUFBVTtBQUNmLFNBQUssc0JBQXNCO0VBQzVCOzs7OztFQU1PLG9CQUFvQixVQUFzQztBQUNoRSxTQUFLLG1CQUFtQjtFQUN6Qjs7RUFHTyxtQkFBbUIsSUFBVTtBQUNuQyxXQUFPLEtBQUssY0FBYyxJQUFJLEVBQUU7RUFDakM7O0VBR08sZ0JBQWdCLElBQVU7QUFDaEMsU0FBSyxjQUFjLElBQUksRUFBRTtBQUN6QixJQUFBQSxRQUFPLE1BQU0sd0JBQXdCLEVBQUUsRUFBRTtFQUMxQzs7RUFHTyxhQUFhLElBQVU7QUFDN0IsU0FBSyxjQUFjLE9BQU8sRUFBRTtBQUM1QixTQUFLLFlBQVksT0FBTyxFQUFFO0FBQzFCLFNBQUssU0FBUyxPQUFPLEVBQUU7QUFDdkIsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixFQUFFLEVBQUU7RUFDdkM7Ozs7Ozs7RUFRTyxNQUFNLFlBQVksSUFBWSxZQUFZLEtBQUk7QUFDcEQsV0FBTyxJQUFJLFFBQTJCLENBQUMsWUFBVztBQUNqRCxZQUFNLE1BQU0sV0FBVyxFQUFFO0FBQ3pCLFVBQUksV0FBVztBQUVmLFlBQU0sU0FBUyxDQUFDLFdBQTZCO0FBQzVDLFlBQUk7QUFBVTtBQUNkLG1CQUFXO0FBQ1gsYUFBSyxtQkFBbUIsT0FBTyxHQUFHO0FBQ2xDLGdCQUFRLE1BQU07TUFDZjtBQUVBLFdBQUssbUJBQW1CLElBQUksS0FBSyxDQUFDLFdBQXNCO0FBQ3ZELFlBQUksT0FBTyxPQUFPO0FBQUksaUJBQU8sTUFBTTtNQUNwQyxDQUFDO0FBRUQsWUFBTSxRQUFRLFdBQVcsTUFBTSxPQUFPLElBQUksR0FBRyxTQUFTO0FBQ3RELFlBQU0sUUFBTztBQUViLFlBQU0sTUFBTSxZQUFXO0FBQ3RCLGNBQU0sS0FBSyxvQkFBb0IsRUFBRTtBQUNqQyxjQUFNLEtBQUs7QUFDWCxjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGFBQUssU0FBUyxLQUFLLE9BQU8sS0FBSyxhQUFhLElBQUksQ0FBQyxRQUFPO0FBQ3ZELGNBQUksS0FBSztBQUNSLFlBQUFBLFFBQU8sS0FBSyxZQUFZLEVBQUUsWUFBWSxJQUFJLE9BQU8sRUFBRTtBQUNuRCx5QkFBYSxLQUFLO0FBQ2xCLG1CQUFPLElBQUk7VUFDWjtRQUNELENBQUM7TUFDRjtBQUVBLFVBQUcsRUFBRyxNQUFNLENBQUMsTUFBSztBQUNqQixRQUFBQSxRQUFPLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLEVBQUU7QUFDdEQscUJBQWEsS0FBSztBQUNsQixlQUFPLElBQUk7TUFDWixDQUFDO0lBQ0YsQ0FBQztFQUNGOzs7OztFQU1PLE1BQU0sbUJBQW1CLFVBQWdCO0FBQy9DLElBQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsUUFBUSxFQUFFO0FBQ3RELFVBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSxzQkFBc0IsUUFBVyxRQUFXLFFBQVcsVUFBVSxLQUFLO0FBRS9HLFdBQU87RUFDUjs7Ozs7Ozs7Ozs7RUFZTyxNQUFNLGdCQUFnQixZQUFZLEtBQUk7QUFFNUMsVUFBTSxnQkFBZ0I7QUFDdEIsVUFBTSxlQUE2QixDQUFBO0FBRW5DLFVBQU0sZ0JBQWdCLENBQUMsV0FBc0I7QUFDNUMsVUFBSSxDQUFDLGFBQWEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sRUFBRSxHQUFHO0FBQ2xELHFCQUFhLEtBQUssTUFBTTtNQUN6QjtJQUNEO0FBR0EsU0FBSyxtQkFBbUIsSUFBSSxlQUFlLGFBQWE7QUFFeEQsUUFBSTtBQUNILFlBQU0sS0FBSztBQUdYLFlBQU0sZ0JBQWdCLEtBQUssVUFBVSxPQUFPLFdBQVcsS0FBSyxvQkFBb0IsTUFBTSxHQUFHLFNBQVM7QUFDbEcsYUFBTztJQUNSO0FBQ0MsV0FBSyxtQkFBbUIsT0FBTyxhQUFhO0lBQzdDO0VBQ0Q7Ozs7O0VBTU8sTUFBTSx1QkFBdUIsVUFBZ0I7QUFDbkQsSUFBQUEsUUFBTyxLQUFLLG9DQUFvQyxRQUFRLEVBQUU7QUFDMUQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLGtCQUFrQixRQUFXLFFBQVcsUUFBVyxVQUFVLEtBQUs7QUFJM0csVUFBTSxZQUFZO0FBRWxCLFFBQUksU0FBUyxTQUFTLFlBQVksR0FBRztBQUNwQyxNQUFBQSxRQUFPLEtBQUssZ0NBQWdDLFNBQVMsTUFBTSxRQUFRO0FBQ25FLGFBQU87SUFDUjtBQUdBLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUNwQyxVQUFNLFFBQVEsU0FBUyxZQUFZLENBQUM7QUFFcEMsVUFBTSxXQUNMLFFBQVEsS0FDTCxNQUFNLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRyxJQUNoQyxNQUFNLFNBQVE7QUFFbEIsVUFBTSxXQUFXLEdBQUcsS0FBSyxJQUFJLFFBQVE7QUFFckMsSUFBQUEsUUFBTyxLQUFLLHFCQUFxQixRQUFRLEVBQUU7QUFDM0MsV0FBTztFQUNSOzs7OztFQU1RLE1BQU0sb0JBQW9CLFFBQWM7QUFDL0MsUUFBSTtBQUNILFlBQU0sWUFBWSxNQUFNLDhCQUE4QixNQUFNO0FBQzVELFVBQUksQ0FBQyxXQUFXO0FBQ2YsUUFBQUEsUUFBTyxLQUFLLHFEQUFxRCxNQUFNLEVBQUU7QUFDekU7TUFDRDtBQUVBLFVBQUksS0FBSyxpQkFBaUIsSUFBSSxTQUFTLEdBQUc7QUFFekM7TUFDRDtBQUVBLFVBQUk7QUFDSCxhQUFLLFNBQVMsY0FBYyxLQUFLLGdCQUFnQixTQUFTO0FBQzFELGFBQUssaUJBQWlCLElBQUksU0FBUztBQUNuQyxRQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssY0FBYyxPQUFPLFNBQVMsRUFBRTtNQUN0RSxTQUFTLElBQUk7QUFDWixRQUFBQSxRQUFPLEtBQUssK0JBQStCLFNBQVMsS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFO01BQ3RFO0lBQ0QsU0FBUyxJQUFJO0FBQ1osTUFBQUEsUUFBTyxLQUFLLCtCQUErQixFQUFFLEVBQUU7SUFDaEQ7RUFDRDtFQUVPLE1BQU0sYUFDWixPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUFJO0FBRWIsU0FBSztBQUNMLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxXQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssWUFDcEMsS0FBSyxjQUFjLE9BQU8sT0FBTyxXQUFXLE9BQU8sUUFBUSxNQUFNLEVBQy9ELEtBQUssQ0FBQyxRQUFPO0FBQ2IsYUFBSztBQUdMLFlBQUksS0FBSyx3QkFBd0IsS0FBSyxLQUFLLHVCQUF1QixVQUFVLFFBQVc7QUFDdEYsZUFBSyxtQkFBbUIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxRQUFPO0FBQzdDLFlBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsR0FBRyxFQUFFO1VBQy9ELENBQUM7UUFDRjtBQUNBLGdCQUFRLEdBQUc7TUFDWixDQUFDLEVBQ0EsTUFBTSxDQUFDLFFBQU87QUFDZCxhQUFLO0FBQ0wsZUFBTyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQztNQUMzRCxDQUFDLENBQUM7SUFFTCxDQUFDO0VBQ0Y7RUFFUSxNQUFNLGNBQ2IsT0FDQSxPQUNBLFdBQ0EsT0FDQSxRQUNBLFNBQVMsTUFBSTtBQUViLFVBQU0sWUFBWTtBQUlsQixRQUFJLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxHQUFHO0FBQ3BDLFlBQU0sSUFBSSxNQUFNLGFBQWEsTUFBTSxpRkFBNEU7SUFDaEg7QUFHQSxVQUFNLEtBQUssb0JBQW9CLE1BQU07QUFFckMsVUFBTSxZQUFzQixDQUFBO0FBQzVCLFFBQUksY0FBYztBQUFXLGdCQUFVLEtBQUssWUFBWSxHQUFJO0FBQzVELFFBQUksVUFBVTtBQUFXLGdCQUFVLEtBQUssR0FBRyxjQUFhLGdCQUFnQixLQUFLLENBQUM7QUFFOUUsVUFBTSxjQUF3QixDQUFDLElBQU0sUUFBUSxHQUFJO0FBRWpELFFBQUksVUFBVTtBQUFXLGtCQUFZLEtBQUssUUFBUSxHQUFJO0FBQ3RELFFBQUk7QUFBUSxrQkFBWSxLQUFLLFVBQVUsTUFBTTtBQUU3QyxRQUFJLFVBQVUsU0FBUztBQUFHLGtCQUFZLEtBQUssR0FBRyxTQUFTO0FBRXZELFVBQU0sTUFBTSxjQUFhLFVBQVUsV0FBVztBQUM5QyxVQUFNLGlCQUFpQixPQUFPLEtBQUssQ0FBQyxHQUFHLGFBQWEsR0FBRyxDQUFDO0FBRXhELFVBQU0sV0FBVyxLQUFLLGVBQWU7QUFDckMsVUFBTSxTQUFTLE1BQU0sS0FBSyxZQUFZLFVBQVUsTUFBTTtBQUN0RCxVQUFNLFNBQVMsT0FBTyxPQUFPLENBQUMsUUFBUSxjQUFjLENBQUM7QUFHckQsUUFBSSxjQUFjLFVBQWEsVUFBVSxRQUFXO0FBQ25ELFlBQU0sYUFBYSxjQUFhLGdCQUFnQixLQUFLO0FBQ3JELFlBQU0sVUFBeUI7UUFDOUIsUUFBUTtRQUNSLElBQUk7UUFDSjtRQUNBOztBQUVELE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxvQkFBb0IsU0FBUyxLQUFLLE9BQU8sQ0FBQyxFQUFFO0lBQzNFLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sZUFBZSxLQUFLLENBQUMsRUFBRTtJQUN0RDtBQUNBLElBQUFBLFFBQU8sTUFBTSxxQkFBcUIsTUFBTSxLQUFLLE9BQU8sU0FBUyxLQUFLLENBQUMsRUFBRTtBQUVyRSxVQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksS0FBSztBQUU5QixXQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsWUFBTSxRQUFRLFdBQVcsTUFBSztBQUM3QixhQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLGVBQU8sSUFBSSxNQUFNLHNDQUFzQyxLQUFLLEtBQUssT0FBTyxNQUFNLE9BQU8sQ0FBQztNQUN2RixHQUFHLFNBQVM7QUFFWixXQUFLLFlBQVksSUFBSSxLQUFLO1FBQ3pCLFNBQVMsQ0FBQyxRQUFPO0FBQ2hCLHVCQUFhLEtBQUs7QUFDbEIsa0JBQVEsR0FBRztRQUNaO1FBQ0EsUUFBUSxDQUFDLFFBQU87QUFDZix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLEdBQUc7UUFDWDtRQUNBO09BQ0E7QUFFRCxXQUFLLFNBQVMsS0FBSyxRQUFRLEtBQUssYUFBYSxRQUFRLENBQUMsUUFBTztBQUM1RCxZQUFJLEtBQUs7QUFDUixlQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQzdDO01BQ0QsQ0FBQztJQUNGLENBQUM7RUFDRjtFQUVRLGVBQWUsS0FBYSxPQUFhO0FBQ2hELFFBQUksSUFBSSxTQUFTO0FBQUc7QUFDcEIsUUFBSSxJQUFJLENBQUMsTUFBTSxPQUFRLElBQUksQ0FBQyxNQUFNO0FBQU07QUFFeEMsVUFBTSxVQUFVLElBQUksYUFBYSxDQUFDO0FBS2xDLFFBQUksWUFBWSwyQkFBMkIsS0FBSyxtQkFBbUIsT0FBTyxHQUFHO0FBQzVFLFlBQU0sU0FBUyx1QkFBdUIsS0FBSyxLQUFLO0FBQ2hELFVBQUksUUFBUTtBQUNYLFFBQUFBLFFBQU8sTUFDTiw0QkFBNEIsS0FBSyxlQUNuQixPQUFPLElBQUksYUFDZCxPQUFPLEtBQUssaUJBQ1IsT0FBTyxTQUFTLG9CQUNiLE9BQU8sWUFBWSxHQUFHO0FBSXpDLFlBQUksT0FBTyxTQUFTLFlBQVk7QUFDL0IscUJBQVcsTUFBTSxLQUFLLG1CQUFtQixPQUFNLEdBQUk7QUFDbEQsZ0JBQUk7QUFDSCxpQkFBRyxNQUFNO1lBQ1YsUUFBUTtZQUVSO1VBQ0Q7UUFDRCxPQUFPO0FBQ04sVUFBQUEsUUFBTyxNQUFNLHNEQUFzRCxPQUFPLElBQUksT0FBTyxLQUFLLEVBQUU7UUFDN0Y7TUFDRDtBQUNBO0lBQ0Q7QUFFQSxRQUFJLElBQUksU0FBUztBQUFJO0FBR3JCLFVBQU0sTUFBTSxJQUFJLFNBQVMsSUFBSSxFQUFFO0FBQy9CLFFBQUksSUFBSSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBSTFDLFVBQU0sWUFBWSxJQUFJLFNBQVMsRUFBRTtBQUNqQyxRQUFJLFVBQVUsU0FBUztBQUFHO0FBQzFCLFFBQUksVUFBVSxDQUFDLE1BQU07QUFBTTtBQUczQixVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sY0FBYyxZQUFZLFNBQVU7QUFDMUMsVUFBTSxnQkFBZ0IsWUFBWTtBQUdsQyxRQUFJLGNBQWMsa0JBQWtCLHNCQUFzQjtBQUN6RCxNQUFBQSxRQUFPLE1BQU0sd0JBQXdCLEtBQUssS0FBSyxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7SUFDckU7QUFHQSxTQUFLLGFBQWEsT0FBTyxlQUFlLEtBQUssU0FBUztBQUd0RCxRQUFJLFlBQVk7QUFDZixZQUFNLE1BQU0sR0FBRyxLQUFLLElBQUksYUFBYTtBQUNyQyxZQUFNLFVBQVUsS0FBSyxZQUFZLElBQUksR0FBRztBQUN4QyxVQUFJLFNBQVM7QUFDWixhQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLGdCQUFRLFFBQVEsR0FBRztNQUNwQjtJQUNEO0VBRUQ7Ozs7Ozs7Ozs7OztFQWFRLGFBQWEsT0FBZSxPQUFlLEtBQWEsV0FBaUI7QUFDaEYsVUFBTSxVQUFVLGVBQWUsS0FBSztBQUNwQyxVQUFNLE9BQU8sVUFBVSxTQUFTLEdBQUcsVUFBVSxTQUFTLENBQUM7QUFHdkQsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLE1BQU0sVUFBVSxVQUFVLFNBQVMsQ0FBQztBQUMxQyxVQUFNLGdCQUFnQixRQUFRLE1BQU0sU0FBUyxDQUFDLFNBQVMsS0FBSyxTQUFTLEtBQUssQ0FBQyxRQUFRLE1BQU0sR0FBRyxDQUFDO0FBSzdGLFFBQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBSSxDQUFDLEtBQUssT0FBTztBQUNoQixRQUFBQSxRQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsRUFBRTtBQUN6RDtNQUNEO0FBQ0EsVUFBSTtBQUNILGNBQU0sV0FDTCxVQUFVLG9CQUNQLHNCQUFzQixLQUFLLE9BQU8sR0FBRyxJQUNyQyw0QkFBNEIsS0FBSyxPQUFPLEdBQUc7QUFFL0MsY0FBTSxZQUFZLEtBQUssWUFBWSxJQUFJLEtBQUssS0FBSyxvQkFBSSxJQUFHO0FBQ3hELGNBQU0sV0FBVyxJQUFJLElBQW9CLFNBQVM7QUFFbEQsbUJBQVcsS0FBSyxVQUFVO0FBQ3pCLGdCQUFNLFdBQVcsY0FBYyxLQUFLLE9BQU8sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUs7QUFFbEUsZ0JBQU0sV0FDTCxFQUFFLFdBQVcsV0FBVyxJQUNwQixFQUFFLFdBQVcsQ0FBQyxLQUFLLEtBQU8sRUFBRSxXQUFXLENBQUMsS0FBSyxJQUFLLEVBQUUsV0FBVyxDQUFDLElBQ2hFLEVBQUUsV0FBVyxDQUFDLEtBQUs7QUFDeEIsZ0JBQU0sWUFBWSxVQUFVLElBQUksUUFBUTtBQUN4QyxnQkFBTSxVQUFVLGNBQWMsVUFBYSxjQUFjO0FBRXpELG1CQUFTLElBQUksVUFBVSxRQUFRO0FBRS9CLGdCQUFNLFlBQVksb0JBQW9CLEdBQUcsS0FBSyxPQUFPO0FBQ3JELGNBQUksU0FBUztBQUNaLFlBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxTQUFTLEVBQUU7QUFFeEMsZ0JBQUksS0FBSyxrQkFBa0I7QUFDMUIsb0JBQU0sa0JBQWtCLGNBQWMsS0FBSyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7QUFFaEUsbUJBQUssaUJBQWlCLGVBQWU7WUFDdEMsT0FBTztBQUNOLGNBQUFBLFFBQU8sS0FBSyxnRUFBMkQsUUFBUSxFQUFFO1lBQ2xGO1VBQ0QsT0FBTztBQUNOLFlBQUFBLFFBQU8sTUFBTSxNQUFNLEtBQUssTUFBTSxTQUFTLEVBQUU7VUFDMUM7UUFDRDtBQUNBLGFBQUssWUFBWSxJQUFJLE9BQU8sUUFBUTtNQUNyQyxTQUFTLEdBQUc7QUFDWCxRQUFBQSxRQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sT0FBTyxvQkFBb0IsQ0FBQyxNQUFNLGFBQWEsRUFBRTtNQUMvRTtBQUNBO0lBQ0Q7QUFHQSxVQUFNLFVBQVUsS0FBSyxhQUFhLE9BQU8sSUFBSTtBQUU3QyxVQUFNLFFBQVEsVUFBVSxjQUFjQSxRQUFPLE1BQU0sS0FBS0EsT0FBTSxJQUFJQSxRQUFPLEtBQUssS0FBS0EsT0FBTTtBQUN6RixRQUFJLFNBQVM7QUFDWixZQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLE1BQU0sT0FBTyxFQUFFO0lBQ2pFLE9BQU87QUFDTixZQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7SUFDcEQ7RUFDRDs7Ozs7RUFNUSxhQUFhLE9BQWUsTUFBWTtBQUMvQyxRQUFJLEtBQUssV0FBVztBQUFHLGFBQU87QUFHOUIsUUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixVQUFJLEtBQUssQ0FBQyxNQUFNLEdBQU07QUFDckIsZUFBTztNQUNSLE9BQU87QUFDTixlQUFPLFNBQVMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO01BQy9CO0lBQ0Q7QUFFQSxZQUFRLE9BQU87Ozs7O01BS2QsS0FBSyxjQUFjO0FBQ2xCLFlBQUksS0FBSyxXQUFXLEdBQUc7QUFDdEIsaUJBQU8sS0FBSyxDQUFDLE1BQU0sSUFBTyxXQUFXLFdBQVcsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQy9EO0FBQ0EsWUFBSSxLQUFLLFVBQVUsR0FBRztBQUNyQixnQkFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixnQkFBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixnQkFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO0FBQ2xDLGdCQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBQ2hGLGdCQUFNLGNBQWMsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLENBQUM7QUFDL0QsZ0JBQU0sVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0FBQ3RDLGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGNBQWMsR0FBRyxXQUFXLEtBQUssTUFBTSxRQUFTLENBQUMsTUFBTSxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUM7QUFDekcsZ0JBQU0sU0FBUyxJQUFJLE1BQU0sS0FBSyxDQUFDLElBQUksTUFBTSxTQUFTLENBQUMsS0FBSyxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUMsQ0FBQztBQUMxRixpQkFBTyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUSxJQUFJLE1BQU07UUFDaEU7QUFDQSxlQUFPLFFBQVEsS0FBSyxTQUFTLEtBQUssQ0FBQztNQUNwQzs7TUFHQSxLQUFLLGlCQUFpQjtBQUVyQixZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLFVBQVUsUUFBUSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEdBQUc7QUFDaEUsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGVBQWUsS0FBSyxXQUFXLFNBQVMsS0FBSyxDQUFDO0FBQy9ELGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRO1FBQ3REO0FBQ0EsZUFBTztNQUNSOztNQUdBLEtBQUs7TUFDTCxLQUFLLGFBQWE7QUFDakIsWUFBSSxLQUFLLFNBQVM7QUFBRyxpQkFBTztBQUM1QixjQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGNBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsY0FBTSxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQzdCLGVBQU8sTUFBTSxLQUFLLFlBQVksTUFBTSxTQUFTLENBQUMsVUFBVSxNQUFNLFNBQVMsS0FBSyxDQUFDO01BQzlFO01BRUE7QUFDQyxlQUFPO0lBQ1Q7RUFDRDtFQUVRLE9BQU8sZ0JBQWdCLE9BQWM7QUFDNUMsUUFBSSxPQUFPLFVBQVU7QUFBVyxhQUFPLENBQUMsUUFBUSxJQUFJLENBQUM7QUFDckQsUUFBSSxNQUFNLFFBQVEsS0FBSztBQUFHLGFBQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxPQUFPLENBQUMsSUFBSSxHQUFJO0FBQ2xFLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDOUIsVUFBSSxRQUFRO0FBQU0sZUFBTyxDQUFFLFNBQVMsS0FBTSxLQUFPLFNBQVMsSUFBSyxLQUFNLFFBQVEsR0FBSTtBQUNqRixhQUFPLENBQUMsUUFBUSxHQUFJO0lBQ3JCO0FBQ0EsVUFBTSxJQUFJLE1BQU0sNENBQTRDLEtBQUssRUFBRTtFQUNwRTtFQUVRLE1BQU0sWUFBWSxVQUFrQixRQUFjO0FBQ3pELFFBQUksTUFBTSxLQUFLLFNBQVMsSUFBSSxNQUFNO0FBQ2xDLFFBQUksQ0FBQyxLQUFLO0FBQ1QsWUFBTSxNQUFNLHFCQUFxQixNQUFNO0FBQ3ZDLFdBQUssU0FBUyxJQUFJLFFBQVEsR0FBRztJQUM5QjtBQUVBLFdBQU8sT0FBTyxPQUFPO01BQ3BCLE9BQU8sS0FBSyxDQUFDLEtBQU0sS0FBTSxHQUFNLFdBQVcsS0FBTSxHQUFNLEtBQU0sR0FBTSxHQUFNLEdBQUcsS0FBSyxHQUFNLENBQUksQ0FBQztNQUMzRixPQUFPLEtBQUssWUFBWSxNQUFNO0tBQzlCO0VBQ0Y7RUFFUSxPQUFPLFVBQVUsTUFBYztBQUN0QyxRQUFJLE1BQU07QUFDVixlQUFXLEtBQUssTUFBTTtBQUNyQixhQUFPO0FBQ1AsZUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDM0IsZUFBTyxNQUFNLFNBQVUsS0FBTSxPQUFPLElBQUssT0FBUSxNQUFRLE9BQU8sSUFBSztNQUN0RTtJQUNEO0FBQ0EsV0FBTztFQUNSOzs7Ozs7Ozs7O0VBV08sZ0JBQWdCLElBQVksT0FBZSxXQUFtQixPQUFjO0FBQ2xGLFVBQU0sTUFBTSxjQUFjLEtBQUssT0FBTyxPQUFPLFdBQVcsS0FBSztBQUM3RCxXQUFPLEtBQUssWUFBWSxJQUFJLEVBQUUsR0FBRyxJQUFJLEdBQUc7RUFDekM7RUFFTyxNQUFNLFlBQVksUUFBYztBQUN0QyxXQUFPLEtBQUssYUFBYSxrQkFBa0IsUUFBVyxHQUFNLFFBQVcsUUFBUSxLQUFLO0VBQ3JGO0VBRU8sTUFBTSxjQUFjLFFBQWM7QUFDeEMsV0FBTyxLQUFLLGFBQWEscUJBQXFCLFFBQVcsUUFBVyxRQUFXLFFBQVEsS0FBSztFQUM3Rjs7OztBRTV0QkQsSUFBTUUsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBTWxELElBQXFCLGlCQUFyQixjQUE0QyxhQUF5QjtFQUNwRTs7RUFDQTs7O0VBSVEsb0JBQWtDLENBQUE7OztFQUkxQyxjQUFzQjtFQUV0QixZQUFZLFVBQWlCO0FBQzVCLFVBQU0sUUFBUTtFQUNmO0VBRUEsTUFBTSxLQUFLLFFBQW9CO0FBQzlCLFNBQUssU0FBUztBQUNkLFFBQUksQ0FBQyxLQUFLLGNBQWM7QUFDdkIsV0FBSyxlQUFlLElBQUksYUFBWTtJQUNyQztBQUNBLFNBQUssYUFBYSxlQUFlLFlBQVksd0JBQXdCO0FBR3JFLFNBQUssYUFBYSxvQkFBb0IsQ0FBQyxlQUFzQjtBQUM1RCxXQUFLLGVBQWUsVUFBVTtJQUMvQixDQUFDO0FBSUQsU0FBSyxhQUFZLEVBQUcsTUFBTSxDQUFDLE1BQUs7QUFDL0IsTUFBQUEsUUFBTyxNQUFNLHFCQUFxQixDQUFDLEVBQUU7SUFDdEMsQ0FBQztFQUNGOzs7Ozs7O0VBUVEsTUFBTSxlQUFZO0FBQ3pCLElBQUFBLFFBQU8sS0FBSyw4QkFBOEI7QUFFMUMsU0FBSyxvQkFBb0IsTUFBTSxLQUFLLGFBQWEsZ0JBQWU7QUFHaEUsUUFBSTtBQUNKLFFBQUksS0FBSyxrQkFBa0IsV0FBVyxHQUFHO0FBRXhDLFVBQUksS0FBSyxPQUFPLFdBQVc7QUFDMUIsY0FBTSxhQUFhLEtBQUssT0FBTyxjQUFjLFNBQVMsS0FBSyxPQUFPLFdBQVcsTUFBTTtBQUNuRixRQUFBQSxRQUFPLEtBQUsscUJBQXFCLEtBQUssT0FBTyxTQUFTLDhDQUF5QztBQUMvRixhQUFLLGFBQWEsZUFBZSxtQkFBbUIsR0FBRyxVQUFVLElBQUksS0FBSyxPQUFPLFNBQVMsYUFBYTtBQUN2RztNQUNEO0FBQ0EsWUFBTSxjQUFjLEtBQUssT0FBTztBQUNoQyxVQUFJLENBQUMsS0FBSyxPQUFPLFFBQVEsQ0FBQyxhQUFhO0FBQ3RDLFFBQUFBLFFBQU8sS0FBSyx5REFBeUQ7QUFDckU7TUFDRDtBQUNBLE1BQUFBLFFBQU8sS0FBSyx3RUFBbUU7QUFDL0UsdUJBQWlCO0lBQ2xCLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssY0FBYyxLQUFLLGtCQUFrQixNQUFNLGFBQWE7QUFDcEUsaUJBQVcsS0FBSyxLQUFLLG1CQUFtQjtBQUN2QyxRQUFBQSxRQUFPLEtBQUssYUFBYSxFQUFFLEtBQUssSUFBSSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUU7TUFDckU7QUFLQSxpQkFBVyxVQUFVLEtBQUssbUJBQW1CO0FBQzVDLGFBQUssYUFBYSxnQkFBZ0IsT0FBTyxFQUFFO01BQzVDO0FBR0EsaUJBQVcsVUFBVSxLQUFLLG1CQUFtQjtBQUM1QyxZQUFJO0FBQ0gsZ0JBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSx1QkFBdUIsT0FBTyxFQUFFO0FBQ3pFLGlCQUFPLGVBQWU7QUFDdEIsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLGNBQWMsUUFBUSxXQUFXLE9BQU8sYUFBYSxFQUFFO1FBQ3BGLFNBQVMsR0FBRztBQUNYLFVBQUFBLFFBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSw2QkFBNkIsQ0FBQyxFQUFFO0FBQzVELGlCQUFPLGVBQWU7UUFDdkI7TUFDRDtBQUVBLHVCQUFpQixhQUFhLEtBQUssUUFBUSxLQUFLLGlCQUFpQjtBQUdqRSxVQUFJLENBQUMsa0JBQWtCLEtBQUssT0FBTyxXQUFXO0FBQzdDLGNBQU0sYUFBYSxLQUFLLE9BQU8sY0FBYyxTQUFTLEtBQUssT0FBTyxXQUFXLE1BQU07QUFDbkYsUUFBQUEsUUFBTyxLQUFLLHFCQUFxQixLQUFLLE9BQU8sU0FBUyxzREFBaUQ7QUFDdkcsYUFBSyxhQUFhLGVBQWUsbUJBQW1CLEdBQUcsVUFBVSxJQUFJLEtBQUssT0FBTyxTQUFTLGFBQWE7QUFDdkc7TUFDRDtJQUNEO0FBR0EsU0FBSyxVQUFVLGNBQWM7QUFJN0IsVUFBTSxhQUFhLEtBQUs7QUFDeEIsVUFBTSxLQUFLLG9CQUFvQixJQUFJLFVBQVU7QUFHN0MsU0FBSyxjQUFhO0FBQ2xCLFNBQUssZ0JBQWU7QUFDcEIsU0FBSywwQkFBeUI7QUFDOUIsU0FBSyxxQkFBb0I7QUFFekIsU0FBSyxhQUFhLGVBQWUsRUFBRTtBQUNuQyxJQUFBQSxRQUFPLEtBQUssMkJBQTJCO0VBQ3hDOztFQUdBLE1BQU0sVUFBTztBQUNaLFNBQUssY0FBYyxNQUFLO0FBQ3hCLElBQUFBLFFBQU8sTUFBTSxTQUFTO0VBQ3ZCO0VBRUEsTUFBTSxjQUFjLFFBQW9CO0FBQ3ZDLFVBQU0sZUFBZSxLQUFLO0FBQzFCLFNBQUssU0FBUztBQUNkLFVBQU0saUJBQWlCLGFBQWEsUUFBUSxLQUFLLGlCQUFpQjtBQUNsRSxTQUFLLFVBQVUsY0FBYztBQUk3QixTQUFLLHFCQUFvQjtBQUV6QixVQUFNLFVBQVUsS0FBSztBQUlyQixVQUFNLEtBQUssb0JBQW9CLGNBQWMsT0FBTztBQUdwRCxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtFQUMxQjs7Ozs7Ozs7Ozs7O0VBYVEsTUFBTSxvQkFBb0IsY0FBc0IsU0FBZTtBQUN0RSxRQUFJLENBQUMsU0FBUztBQUNiLFVBQUk7QUFBYyxhQUFLLGFBQWEsYUFBYSxZQUFZO0FBQzdEO0lBQ0Q7QUFFQSxRQUFJLEtBQUssT0FBTyxXQUFXO0FBRTFCLFlBQU0sU0FBUyxLQUFLLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsS0FBSyxPQUFPLFNBQVM7QUFDakYsVUFBSSxDQUFDLFFBQVE7QUFDWixRQUFBQSxRQUFPLEtBQUssZUFBZSxLQUFLLE9BQU8sU0FBUyx5REFBb0Q7QUFDcEcsWUFBSTtBQUFjLGVBQUssYUFBYSxhQUFhLFlBQVk7QUFDN0Q7TUFDRDtBQUVBLFVBQUksZ0JBQWdCLGlCQUFpQixTQUFTO0FBQzdDLGFBQUssYUFBYSxhQUFhLFlBQVk7TUFDNUM7QUFDQSxZQUFNLGdCQUFnQixLQUFLLGFBQWEsbUJBQW1CLE9BQU87QUFDbEUsVUFBSSxDQUFDLGVBQWU7QUFDbkIsYUFBSyxhQUFhLGdCQUFnQixPQUFPO01BQzFDO0FBQ0EsVUFBSSxZQUFZLGdCQUFnQixDQUFDLGVBQWU7QUFDL0MsY0FBTSxLQUFLLDZCQUE2QixPQUFPLE9BQU8sT0FBTztNQUM5RDtBQUNBO0lBQ0Q7QUFHQSxVQUFNLGNBQWMsT0FBTyxLQUFLLE9BQU8sZUFBZSxFQUFFO0FBQ3hELFVBQU0saUJBQWlCLEtBQUssa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBRTFFLFFBQUksZ0JBQWdCO0FBQ25CLFVBQUksZUFBZSxVQUFVLGFBQWE7QUFDekMsWUFBSSxnQkFBZ0IsaUJBQWlCO0FBQVMsZUFBSyxhQUFhLGFBQWEsWUFBWTtBQUN6RixjQUFNLGdCQUFnQixLQUFLLGFBQWEsbUJBQW1CLE9BQU87QUFDbEUsWUFBSSxDQUFDLGVBQWU7QUFDbkIsZUFBSyxhQUFhLGdCQUFnQixPQUFPO1FBQzFDO0FBQ0EsWUFBSSxZQUFZLGdCQUFnQixDQUFDLGVBQWU7QUFDL0MsZ0JBQU0sS0FBSyw2QkFBNkIsYUFBYSxPQUFPO1FBQzdEO01BQ0QsT0FBTztBQUNOLFFBQUFBLFFBQU8sTUFDTiwwQkFBMEIsV0FBVywyQ0FBMkMsZUFBZSxLQUFLLFFBQVEsT0FBTywwQkFBcUI7QUFFekksYUFBSyxhQUFhLGFBQWEsT0FBTztBQUN0QyxhQUFLLGFBQ0osZUFBZSxtQkFDZiw0QkFBNEIsV0FBVyxTQUFTLGVBQWUsS0FBSyxFQUFFO01BRXhFO0FBQ0E7SUFDRDtBQUdBLElBQUFBLFFBQU8sS0FBSyxHQUFHLE9BQU8sd0NBQW1DO0FBQ3pELFFBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLFdBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsU0FBSyxhQUFhLGFBQWEsT0FBTztBQUV0QyxVQUFNLFNBQVMsTUFBTSxLQUFLLGFBQWEsWUFBWSxPQUFPO0FBQzFELFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxNQUFNLDBCQUEwQixPQUFPLDBCQUFxQjtBQUNuRSxXQUFLLGFBQWEsZUFBZSxnQkFBZ0IsbUJBQW1CLE9BQU8sRUFBRTtJQUM5RSxXQUFXLE9BQU8sVUFBVSxhQUFhO0FBQ3hDLE1BQUFBLFFBQU8sTUFDTiwwQkFBMEIsV0FBVywyQ0FBMkMsT0FBTyxLQUFLLFFBQVEsT0FBTywwQkFBcUI7QUFFakksV0FBSyxhQUNKLGVBQWUsbUJBQ2YsNEJBQTRCLFdBQVcsU0FBUyxPQUFPLEtBQUssRUFBRTtJQUVoRSxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGtCQUFrQixPQUFPLEtBQUssT0FBTyxPQUFPLEVBQUU7QUFDMUQsV0FBSyxhQUFhLGdCQUFnQixPQUFPO0FBQ3pDLFlBQU0sS0FBSyw2QkFBNkIsYUFBYSxPQUFPO0FBQzVELFdBQUssYUFBYSxlQUFlLEVBQUU7SUFDcEM7RUFDRDs7Ozs7RUFNUSxNQUFNLDZCQUE2QixPQUFlLElBQVU7QUFDbkUsUUFBSTtBQUNILFlBQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFO0FBRTdDLFVBQUksQ0FBQyxnQkFBZ0IsS0FBSyxHQUFHO0FBRzVCLFFBQUFBLFFBQU8sS0FBSyw2QkFBNkIsS0FBSyxzREFBaUQ7QUFDL0Y7TUFDRDtJQUNELFNBQVMsR0FBRztBQUNYLE1BQUFBLFFBQU8sS0FBSyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsRUFBRTtJQUN4RDtFQUNEOztFQUdRLFVBQVUsT0FBYTtBQUM5QixTQUFLLGNBQWM7QUFDbkIsVUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxLQUFLLFVBQVUsS0FBSywrQkFBK0I7QUFDMUQsV0FBSyxhQUFhLFNBQVMsT0FBTyxDQUFBLEdBQUksSUFBSTtBQUMxQztJQUNEO0FBRUEsVUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSSxPQUFPLFlBQVksQ0FBQTtBQUNyRSxVQUFNLHNCQUFzQixPQUFPLHVCQUF1QjtBQUUxRCxTQUFLLGFBQWEsU0FBUyxPQUFPLFNBQVMsbUJBQW1CO0FBQzlELFFBQUksUUFBUSxXQUFXLEdBQUc7QUFDekIsTUFBQUEsUUFBTyxLQUFLLCtCQUErQixLQUFLLDZDQUF3QztJQUN6RixPQUFPO0FBQ04sTUFBQUEsUUFBTyxNQUNOLFVBQVUsUUFBUSxNQUFNLHVCQUF1QixLQUFLLGdCQUFnQixPQUFPLFNBQVMseUJBQXlCLG1CQUFtQixFQUFFO0lBRXBJO0VBQ0Q7RUFFQSxrQkFBZTtBQUNkLFdBQU8sZ0JBQWdCLEtBQUssaUJBQWlCO0VBQzlDOztFQUdBLElBQUksT0FBSTtBQUNQLFdBQU8sWUFBWSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7RUFDdkQ7O0VBR0EsSUFBSSxVQUFPO0FBQ1YsV0FBTyxLQUFLO0VBQ2I7RUFFQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSxrQkFBZTtBQUNkLG9CQUFnQixJQUFJO0VBQ3JCO0VBRUEsNEJBQXlCO0FBQ3hCLDhCQUEwQixJQUFJO0VBQy9CO0VBRUEsdUJBQW9CO0FBQ25CLHlCQUFxQixJQUFJO0VBQzFCOzsiLAogICJuYW1lcyI6IFsicGF0aCIsICJJbnN0YW5jZVN0YXR1cyIsICJSZWdleCIsICJwYXRoIiwgImZzIiwgImxvZ2dlciIsICJsb2dnZXIiLCAiaWRBZGRPcHQiLCAiZnMiLCAibG9nZ2VyIiwgImRldmljZXNGb2xkZXIiLCAicGF0aCIsICJsb2dnZXIiLCAiZGdyYW0iLCAibG9nZ2VyIiwgImxvZ2dlciIsICJkZ3JhbSIsICJsb2dnZXIiXQp9Cg==
